/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Set<Subject<any>>
}

export interface Subject<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<any>>
}

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  
  try {
    activeObserver = observer as Observer<any>
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  return observer.value!
}

export function trackSubject<T>(subject: Subject<T>): void {
  if (activeObserver && !subject.observers.has(activeObserver)) {
    subject.observers.add(activeObserver)
  }
}

export function notifySubject<T>(subject: Subject<T>): void {
  const currentObservers = [...subject.observers]
  currentObservers.forEach(observer => {
    if (observer) {
      updateObserver(observer as Observer<T>)
    }
  })
}
