/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    value,
    updateFn,
  }

  const read: GetterFn<T> = () => {
    // Set this observer as active to track dependencies
    const previousObserver = getActiveObserver()
    
    try {
      // Make this observer active
      setActiveObserver(o as any)
      
      // Calculate new value - this will track input dependencies
      value = updateFn(value)
    } finally {
      // Restore previous observer
      setActiveObserver(previousObserver)
    }
    
    return value!
  }

  return read
}
