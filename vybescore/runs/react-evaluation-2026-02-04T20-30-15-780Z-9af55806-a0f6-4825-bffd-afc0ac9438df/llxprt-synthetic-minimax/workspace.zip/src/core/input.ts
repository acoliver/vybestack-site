/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  trackSubject,
  notifySubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    // Track this subject as a dependency for the active observer
    trackSubject(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify observers when value changes
    notifySubject(s)
    
    return s.value
  }

  return [read, write]
}
