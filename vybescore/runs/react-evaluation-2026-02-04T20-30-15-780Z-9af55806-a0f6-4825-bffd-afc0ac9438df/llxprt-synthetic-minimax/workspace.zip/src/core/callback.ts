/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create an observer that wraps the update function
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Execute the callback to establish dependencies
  const executeCallback = () => {
    const previousObserver = getActiveObserver()
    try {
      setActiveObserver(observer as any)
      observer.updateFn(observer.value)
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Execute immediately to establish dependencies
  executeCallback()
  
  // Set up re-execution when dependencies change by making the observer observable
  observer.updateFn = (nextValue?: T) => {
    observer.value = updateFn(nextValue)
    return observer.value
  }
  
  return () => {
    if (disposed) return undefined
    disposed = true
    
    // Clean up the observer by removing from all subjects
    observer.value = undefined as T
    observer.updateFn = () => undefined as T
  }
}
