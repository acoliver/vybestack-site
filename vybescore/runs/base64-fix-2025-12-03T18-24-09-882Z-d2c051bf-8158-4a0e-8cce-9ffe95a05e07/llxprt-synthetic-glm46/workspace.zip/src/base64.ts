/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid input.
 */
export function decode(input: string): string {
  // Basic validation for Base64 format
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for valid Base64 characters (only A-Z, a-z, 0-9, +, /, and optional padding =)
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding if present
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding exists, it must be at the end and only 1 or 2 characters
    const paddingPart = input.substring(paddingIndex);
    if (!/^={1,2}$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Check that the total length is valid for Base64
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length for padding');
    }
  } else {
    // No padding: length must be divisible by 4, or we need to add padding
    if (input.length % 4 !== 0) {
      // Add padding to make length divisible by 4 for Buffer to handle
      const paddingNeeded = 4 - (input.length % 4);
      input += '='.repeat(paddingNeeded);
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}