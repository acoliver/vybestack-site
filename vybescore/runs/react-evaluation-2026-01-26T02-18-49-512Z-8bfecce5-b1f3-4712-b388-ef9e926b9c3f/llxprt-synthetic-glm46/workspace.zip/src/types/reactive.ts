/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  updateFn?: <T>(value?: T) => T
  observer?: ObserverR | undefined
  value?: unknown
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR<T> = {
  name?: string
  observer: Observer<T> | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR<T> & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as ObserverR
  try {
    observer.value = observer.updateFn(observer.value) as T
  } finally {
    activeObserver = previous
  }
}

// Global registry for tracking dependencies
const dependencyGraph = new Map<ObserverR, Set<ObserverR | Subject<unknown>>>()

export function addDependency(dependent: ObserverR, dependency: ObserverR | Subject<unknown>): void {
  if (!dependencyGraph.has(dependent)) {
    dependencyGraph.set(dependent, new Set())
  }
  dependencyGraph.get(dependent)!.add(dependency)
}

export function notifyDependents(observer: ObserverR | Subject<unknown>): void {
  // Find all observers that depend on this one
  for (const [dependent, dependencies] of dependencyGraph.entries()) {
    if (dependencies.has(observer)) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}
