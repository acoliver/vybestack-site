/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equal parameter - if true, use strict equality
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? (a: T, b: T) => a === b 
    : typeof equal === 'function' 
      ? equal 
      : undefined

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: updateFn as <U>(value?: U) => U,
  }

  const getter: GetterFn<T> = () => {
    // Register this computed as a dependency when accessed in an active observer context
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // For observers that need to know when this computed value changes
      o.observer = currentObserver;
      
      // Track the dependency relationship
      addDependency(currentObserver, o)
    }

    // When accessing the computed value, always recalculate
    updateObserver(o)
    
    return o.value as T
  }

  // Initialize the computed value only if we have an initial value
  // If no explicit value provided, let updateFunction use its default
  if (value !== undefined) {
    updateObserver(o)
  }

  return getter
}
