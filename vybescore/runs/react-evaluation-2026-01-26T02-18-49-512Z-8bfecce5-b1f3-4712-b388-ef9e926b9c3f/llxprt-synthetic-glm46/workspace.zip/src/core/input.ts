/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equal parameter - if true, use strict equality
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? (a: T, b: T) => a === b 
    : typeof equal === 'function' 
      ? equal 
      : undefined

  const s: Subject<T> & { observer?: Observer<T> } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      s.observer = observer as any
      // Track the dependency relationship
      // The current observer depends on this input
      addDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value should be updated based on equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // If we have an observer (computed or callback), notify it of the change
    if (s.observer) {
      updateObserver(s.observer)
      
      // Also notify any observers that depend on this input
      notifyDependents(s.observer)
    }
    
    return s.value
  }

  return [read, write]
}
