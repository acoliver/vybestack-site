/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Create a registry to track all active callbacks
const callbackRegistry = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: updateFn as <U>(value?: U) => U,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Add this callback to the global registry
  callbackRegistry.add(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from the registry
    callbackRegistry.delete(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    observer.updateFn = () => value as any
  }
}
