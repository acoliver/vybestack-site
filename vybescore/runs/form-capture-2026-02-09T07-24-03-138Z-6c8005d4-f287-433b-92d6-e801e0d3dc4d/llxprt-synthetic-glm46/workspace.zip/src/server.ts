import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
// eslint-disable-next-line @typescript-eslint/no-require-imports
const sqlite = require('sql.js');

// Get __dirname in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Database = {
  export: () => Uint8Array;
  exec: (sql: string) => void;
  run: (sql: string) => void;
  prepare: (sql: string) => {
    run: (...args: unknown[]) => void;
    free: () => void;
  };
  close: () => void;
};

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Create data directory if it doesn't exist
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize SQLite database
let db: Database | null = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let SQL: any = null;

const initDatabase = async (): Promise<void> => {
  try {
    // Initialize sql.js - it's a function that returns the SQL object
    SQL = await sqlite();
    const fileBuffer = fs.existsSync(dbPath) ? fs.readFileSync(dbPath) : null;
    db = new SQL.Database(fileBuffer);
    
    // Read and execute schema
    const schemaPath = path.resolve('db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      if (db) {
        db.exec(schema);
      }
    }
    
    // Test that the database is working
    try {
      if (db) {
        const result = db.exec('SELECT COUNT(*) FROM submissions');
        console.log('Database initialized successfully, submissions count:', result);
      }
    } catch (e) {
      console.log('Table might not exist yet, that is expected for a new DB');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

const closeDatabase = (): void => {
  if (db) {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      db.close();
    } catch (error) {
      console.error('Failed to close database:', error);
    }
    db = null;
  }
};

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
const validateForm = (formData: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];
  
  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else {
    // Allow alphanumeric strings, spaces, and common postal code characters
    if (!/^[A-Za-z0-9\s-]+$/.test(formData.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Invalid postal code format' });
    }
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else {
    // Simple email validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.push({ field: 'email', message: 'Invalid email format' });
    }
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else {
    // Phone validation: allow digits, spaces, parentheses, dashes, and leading +
    if (!/^[+\d\s()\\-]+$/.test(formData.phone)) {
      errors.push({ field: 'phone', message: 'Invalid phone number format' });
    }
  }
  
  return errors;
};

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: null, values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = req.body;
  console.log('Received form data:', formData);
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    console.log('Validation errors:', errors);
    return res.status(400).render('form', { 
      errors: errors.map(e => e.message), 
      values: formData 
    });
  }
  
  try {
    console.log('Database state before insert:', db ? 'exists' : 'null');
    
    // Insert into database using string queries instead of prepared statement
    const insertQuery = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (
        '${formData.firstName || ''}', 
        '${formData.lastName || ''}', 
        '${formData.streetAddress || ''}', 
        '${formData.city || ''}', 
        '${formData.stateProvince || ''}', 
        '${formData.postalCode || ''}', 
        '${formData.country || ''}', 
        '${formData.email || ''}', 
        '${formData.phone || ''}'
      )
    `;
    
    console.log('Insert query:', insertQuery);
    
    // Execute the query directly
    if (db) {
      db.run(insertQuery);
      
      // Save database to disk
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    }
    
    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
const startServer = async (): Promise<unknown> => {
  try {
    await initDatabase();
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = (): void => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        closeDatabase();
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Server startup failed:', error);
    process.exit(1);
  });
}

export { app, startServer, closeDatabase };
