import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
// @ts-expect-error - supertest doesn't have perfect types for Express 5
import request from 'supertest';
import { app, startServer, closeDatabase } from '../../src/server';

let server: unknown;
// eslint-disable-next-line @typescript-eslint/no-unused-vars
let appInstance: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = await startServer();
});

afterAll(async () => {
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  }
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Log the response to debug
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    
    if (response.status !== 302) {
      // If not a redirect, show the response body to debug
      console.log('Response body:', response.text);
    }
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    
    // Check that the database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check that we can access the thank you page
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('John');
  });
});
