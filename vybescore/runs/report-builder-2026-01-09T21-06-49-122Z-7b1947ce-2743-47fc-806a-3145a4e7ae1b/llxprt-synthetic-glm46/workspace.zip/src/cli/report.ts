#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  let format: string = '';
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else if (!args[i].startsWith('--')) {
      continue;
    } else {
      console.error(`Unknown argument: ${args[i]}`);
      process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataFile, format, output, includeTotals };
}

function validateData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid title');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid entries array');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid amount`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main(): void {
  const args = parseArgs();
  
  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Unsupported format: ${args.format}`);
    process.exit(1);
  }
  
  let dataJson: string;
  try {
    dataJson = readFileSync(args.dataFile, 'utf8');
  } catch (error) {
    console.error(`Error reading file ${args.dataFile}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
  
  let parsedData: unknown;
  try {
    parsedData = JSON.parse(dataJson);
  } catch (error) {
    console.error(`Error parsing JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
  
  let reportData: ReportData;
  try {
    reportData = validateData(parsedData);
  } catch (error) {
    console.error(`Error validating data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };
  
  const formatter = args.format === 'markdown' ? markdownFormatter : textFormatter;
  const output = formatter.render(reportData, options);
  
  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf8');
    } catch (error) {
      console.error(`Error writing to file ${args.output}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
