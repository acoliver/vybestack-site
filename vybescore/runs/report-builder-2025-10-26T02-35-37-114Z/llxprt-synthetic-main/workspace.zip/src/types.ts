/**
 * Interface for a report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the full report data
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Interface for report options
 */
export interface ReportOptions {
  includeTotals: boolean;
}

/**
 * Type for supported output formats
 */
export type ReportFormat = 'markdown' | 'text';

/**
 * Type for formatter functions
 */
export type ReportFormatter = (data: ReportData, options: ReportOptions) => string;