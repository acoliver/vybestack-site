import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';
import type { ReportFormatter, ReportFormat } from './types.js';

/**
 * Map of format names to their respective formatters
 */
export const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Checks if a format is supported
 */
export function isSupportedFormat(format: string): format is ReportFormat {
  return format in formatters;
}