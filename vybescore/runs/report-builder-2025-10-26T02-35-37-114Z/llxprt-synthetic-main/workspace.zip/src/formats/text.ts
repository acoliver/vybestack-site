import type { ReportData, ReportOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

/**
 * Renders a report in plain text format
 */
export const renderText = (
  data: ReportData,
  options: ReportOptions
): string => {
  const lines: string[] = [];

  // Add title
  lines.push(data.title);
  lines.push(''); // Empty line after title

  // Add summary
  lines.push(data.summary);
  lines.push(''); // Empty line after summary

  // Add entries heading
  lines.push('Entries:');

  // Add entries as bullet points
  data.entries.forEach((entry) => {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  });

  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};