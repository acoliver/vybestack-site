import type { ReportData, ReportOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

/**
 * Renders a report in Markdown format
 */
export const renderMarkdown = (
  data: ReportData,
  options: ReportOptions
): string => {
  const lines: string[] = [];

  // Add title as H1 heading
  lines.push(`# ${data.title}`);
  lines.push(''); // Empty line after title

  // Add summary
  lines.push(data.summary);
  lines.push(''); // Empty line after summary

  // Add entries heading
  lines.push('## Entries');

  // Add entries as bullet points
  data.entries.forEach((entry) => {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  });

  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};