#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { formatters, isSupportedFormat } from '../formatters.js';
import { validateReportData } from '../utils.js';
import type { ReportOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    printUsage();
    process.exit(1);
  }

  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const flag = args[i];

    if (flag === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip the next argument as it's the value for this flag
    } else if (flag === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument as it's the value for this flag
    } else if (flag === '--includeTotals') {
      includeTotals = true;
    }
  }

  // Check if required arguments are present
  if (!dataFile || !format) {
    printUsage();
    process.exit(1);
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function printUsage(): void {
  console.error(
    'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
  );
  console.error('');
  console.error('Options:');
  console.error('  <data.json>     Path to JSON data file');
  console.error('  --format        Output format (markdown, text)');
  console.error('  --output        Output file path (optional)');
  console.error('  --includeTotals Include total amount in output');
}

function readDataFile(filePath: string): unknown {
  try {
    const content = readFileSync(filePath, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON in file: ${filePath}`);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    } else {
      throw new Error(`Failed to read file: ${filePath}`);
    }
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf8');
      console.log(`Output written to: ${outputPath}`);
    } catch (error) {
      throw new Error(`Failed to write to output file: ${outputPath}`);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArgs();

    // Validate format
    if (!isSupportedFormat(format)) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Read and validate data
    const rawData = readDataFile(dataFile);
    const reportData = validateReportData(rawData);

    // Get formatter
    const formatter = formatters[format];
    if (!formatter) {
      throw new Error(`No formatter found for format: ${format}`);
    }

    // Render report
    const options: ReportOptions = { includeTotals };
    const output = formatter(reportData, options);

    // Write output
    writeOutput(output, outputPath);
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

// Run main if this is the entry point
main();