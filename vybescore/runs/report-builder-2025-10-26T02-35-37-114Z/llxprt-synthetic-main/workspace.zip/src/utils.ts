import type { ReportData, ReportEntry } from './types.js';

/**
 * Validates the report data structure
 */
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid data: Missing or invalid title property');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid data: Missing or invalid summary property');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: Missing or invalid entries property');
  }

  const entries: ReportEntry[] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (
      !entry ||
      typeof entry !== 'object' ||
      !('label' in entry) ||
      !('amount' in entry) ||
      typeof entry.label !== 'string' ||
      typeof entry.amount !== 'number'
    ) {
      throw new Error(`Invalid data: Entry at index ${i} is invalid`);
    }
    entries.push({
      label: entry.label,
      amount: entry.amount,
    });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

/**
 * Calculates the total amount from entries
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Formats an amount as a currency string with two decimal places
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}