import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';

/**
 * Render report data in Markdown format.
 */
export const renderMarkdown: FormatRenderer = (
  data: ReportData,
  options: ReportOptions,
): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);

  let output = `# ${data.title}

${data.summary}

## Entries
`;

  data.entries.forEach((entry) => {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  });

  if (options.includeTotals) {
    output += `\n**Total:** $${total.toFixed(2)}\n`;
  }

  return output;
};