#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs';
import { resolve } from 'node:path';

import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command-line arguments using only Node.js standard APIs.
 */
function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  let dataPath: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg.startsWith('--format')) {
      if (arg === '--format' && i + 1 < args.length) {
        format = args[i + 1];
        i++;
      } else if (arg.startsWith('--format=')) {
        format = arg.substring('--format='.length);
      }
    } else if (arg.startsWith('--output')) {
      if (arg === '--output' && i + 1 < args.length) {
        outputPath = args[i + 1];
        i++;
      } else if (arg.startsWith('--output=')) {
        outputPath = arg.substring('--output='.length);
      }
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--') && !dataPath) {
      dataPath = arg;
    }
  }

  if (!dataPath) {
    throw new Error('Data file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    dataPath: resolve(dataPath),
    format,
    outputPath: outputPath ? resolve(outputPath) : undefined,
    includeTotals,
  };
}

/**
 * Validate that the report data matches the expected schema.
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: expected object');
  }

  const reportData = data as Record<string, unknown>;

  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string' ||
    !Array.isArray(reportData.entries)
  ) {
    throw new Error(
      'Invalid report data: expected title, summary, and entries fields',
    );
  }

  const entries = reportData.entries as unknown[];

  if (
    !entries.every(
      (entry) =>
        entry &&
        typeof entry === 'object' &&
        typeof (entry as Record<string, unknown>).label === 'string' &&
        typeof (entry as Record<string, unknown>).amount === 'number',
    )
  ) {
    throw new Error(
      'Invalid report data: each entry must have label and amount fields',
    );
  }

  return data as ReportData;
}

/**
 * Main execution function.
 */
async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs(
      process.argv.slice(2),
    );

    // Validate format
    const formatters: Record<string, FormatRenderer> = {
      markdown: renderMarkdown,
      text: renderText,
    };

    if (!formatters[format]) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Read and parse data file
    try {
      const dataContent = await new Promise<string>((resolve, reject) => {
        readFile(dataPath, 'utf8', (err, data) => {
          if (err) {
            reject(err);
          } else {
            resolve(data);
          }
        });
      });

      const parsedData = JSON.parse(dataContent);
      const reportData = validateReportData(parsedData);

      // Render report
      const options: ReportOptions = { includeTotals };
      const output = formatters[format](reportData, options);

      // Output to file or stdout
      if (outputPath) {
        await new Promise<void>((resolve, reject) => {
          writeFile(outputPath, output, 'utf8', (err) => {
            if (err) {
              reject(err);
            } else {
              resolve();
            }
          });
        });
      } else {
        process.stdout.write(output);
      }
    } catch (readError) {
      if (readError instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${dataPath}: ${readError.message}`);
      } else {
        throw readError;
      }
    }
  } catch (error) {
    console.error(
      error instanceof Error ? error.message : String(error),
    );
    process.exit(1);
  }
}

// Run the CLI
main();
