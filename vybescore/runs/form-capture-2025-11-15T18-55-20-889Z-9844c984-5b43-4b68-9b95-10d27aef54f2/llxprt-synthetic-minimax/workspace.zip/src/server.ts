import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { validateContactForm } from './models/validation.js';
import { saveSubmission, initializeDatabase, closeDatabase } from './models/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, './public')));

// Routes
app.get('/', (req, res) => {
  res.render('contact-form', { 
    errors: [], 
    data: {},
    title: 'Contact Us'
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalZipCode: req.body.postalZipCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    const validation = validateContactForm(formData);

    if (!validation.isValid) {
      return res.status(400).render('contact-form', {
        errors: validation.errors,
        data: formData,
        title: 'Contact Us - Please Fix Errors'
      });
    }

    await saveSubmission(validation.data!);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('contact-form', {
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      data: req.body,
      title: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully');
  await closeDatabase();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await initializeDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();