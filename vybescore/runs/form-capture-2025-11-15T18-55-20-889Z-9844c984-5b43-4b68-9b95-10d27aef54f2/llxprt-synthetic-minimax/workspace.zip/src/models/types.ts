export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationError {
  field: keyof ContactFormData;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data?: ContactFormData;
}