import { ContactFormData, ValidationResult, ValidationError } from './types.js';

export function validateContactForm(data: Partial<ContactFormData>): ValidationResult {
  const errors: ValidationError[] = [];
  
  // Required field validation
  const requiredFields: (keyof ContactFormData)[] = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvinceRegion',
    'postalZipCode',
    'country',
    'email',
    'phoneNumber'
  ];

  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Only validate other fields if basic required validation passed
  if (errors.length === 0) {
    const formData = data as ContactFormData;
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (formData.email && !emailRegex.test(formData.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (formData.phoneNumber && !phoneRegex.test(formData.phoneNumber)) {
      errors.push({
        field: 'phoneNumber',
        message: 'Please enter a valid phone number'
      });
    }

    // Postal code validation - allow alphanumeric strings (handles UK "SW1A 1AA", US "12345", etc.)
    const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
    if (formData.postalZipCode && !postalCodeRegex.test(formData.postalZipCode)) {
      errors.push({
        field: 'postalZipCode',
        message: 'Please enter a valid postal/zip code'
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: errors.length === 0 ? (data as ContactFormData) : undefined
  };
}