import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';
import { ContactFormData } from './types.js';

let sqlJs: any = null;
let db: any = null;

export async function initializeDatabase(): Promise<void> {
  if (!sqlJs) {
    sqlJs = await initSqlJs({
      locateFile: (file: string) => `https://sql.js.org/dist/${file}`
    });
  }

  const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  
  try {
    if (existsSync(dbPath)) {
      const dbBuffer = readFileSync(dbPath);
      db = new sqlJs.Database(dbBuffer);
    } else {
      db = new sqlJs.Database();
      await createSchema();
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

async function createSchema(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const schemaPath = join(process.cwd(), 'db', 'schema.sql');
  const schema = readFileSync(schemaPath, 'utf-8');
  
  db.exec(schema);
}

export async function saveSubmission(data: ContactFormData): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province_region, 
      postal_zip_code, country, email, phone_number
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvinceRegion,
      data.postalZipCode,
      data.country,
      data.email,
      data.phoneNumber
    ]);
  } finally {
    stmt.free();
  }
  
  await persistDatabase();
}

async function persistDatabase(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  const dbBuffer = db.export();
  writeFileSync(dbPath, dbBuffer);
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}