declare module 'sql.js' {
  export default function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<{
    Database: new (data?: Uint8Array) => {
      run(sql: string, ...params: unknown[]): void;
      exec(sql: string, ...params: unknown[]): unknown[];
      prepare(sql: string): {
        run(params: unknown[]): void;
        step(): boolean;
        get(): unknown[];
        free(): void;
      };
      export(): Uint8Array;
      close(): void;
    };
  }>;
}