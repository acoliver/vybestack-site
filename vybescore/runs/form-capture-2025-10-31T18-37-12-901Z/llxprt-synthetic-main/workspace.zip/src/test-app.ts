// Basic test app that matches the expected test structure
import express from 'express';
import path from 'path';
import fs from 'fs';

const app = express();

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Serve static files
app.use(express.static(path.resolve('public')));

// Parse request bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Form validation function
function validateForm(body: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!body[field] || body[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').toLowerCase().replace(/^\s/g, '')} is required`);
    }
  }
  
  // Email validation with a simple regex
  if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone number validation (allow digits, spaces, parentheses, dashes, and a leading +)
  if (body.phone && !/^\+?[0-9\-\s()]+$/.test(body.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  
  // Postal code validation (accept alphanumeric characters)
  if (body.postalCode && !/^[a-zA-Z0-9\s]+$/.test(body.postalCode)) {
    errors.push('Postal code can only contain letters, numbers, and spaces');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Initialize database
async function initDb() {
  const initSqlJs = (await import('sql.js')).default;
  
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  let dbData: Uint8Array | undefined;
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    dbData = new Uint8Array(fileBuffer);
  }
  
  const SQL = await initSqlJs();
  const db = new SQL.Database(dbData);
  
  // Create table if it doesn't exist
  const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
  db.run(schema);
  
  return db;
}

// Set up routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req, res) => {
  const body = req.body as Record<string, string>;
  const { isValid, errors } = validateForm(body);
  
  if (!isValid) {
    return res.status(400).render('form', {
      errors,
      values: body
    });
  }
  
  try {
    const db = await initDb();
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      body.firstName,
      body.lastName,
      body.streetAddress,
      body.city,
      body.stateProvince,
      body.postalCode,
      body.country,
      body.email,
      body.phone
    ]);
    
    stmt.free();
    
    // Save the database to disk
    const dbPath = path.resolve('data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    
    // Redirect to the thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(body.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: body
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

export default app;