import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs from 'sql.js';

const port = process.env.PORT ?? 3000;
const app = express();

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Serve static files
app.use(express.static(path.join(process.cwd(), 'public')));

// Parse request bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Type definitions
type FormData = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

type FormErrors = {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
};

// Initialize SQLite database
let db: { 
  run: (sql: string, ...params: unknown[]) => void;
  exec: (sql: string, ...params: unknown[]) => unknown[];
  export: () => Uint8Array;
  close: () => void;
} | null = null;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();

    const exists = fs.existsSync(dbPath);
    let data: Uint8Array | undefined;

    if (exists) {
      console.log('Loading existing database from', dbPath);
      data = fs.readFileSync(dbPath);
    }

    db = new SQL.Database(data);

    if (!exists) {
      console.log('Creating new database with schema');
      const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      db.run(schema);
    }

    console.log('Database initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  if (db) {
    try {
      const data = db.export();
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Validation functions
const validateEmail = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const validatePhone = (phone: string): boolean => {
  return /^[+]?[0-9\-\s()]+$/.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  return /^[A-Za-z0-9+s-]+$/.test(postalCode);
};

const validateForm = (data: Partial<FormData>): { isValid: boolean; errors: FormErrors } => {
  const errors: FormErrors = {};
  let isValid = true;

  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
    isValid = false;
  }

  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
    isValid = false;
  }

  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
    isValid = false;
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
    isValid = false;
  }

  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
    isValid = false;
  }

  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
    isValid = false;
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Invalid postal code format';
    isValid = false;
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
    isValid = false;
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
    isValid = false;
  } else if (!validateEmail(data.email)) {
    errors.email = 'Invalid email address';
    isValid = false;
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
    isValid = false;
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Invalid phone number';
    isValid = false;
  }

  return { isValid, errors };
};

// Middleware to get form data from request
const getFormData = (req: Request): Partial<FormData> => ({
  firstName: req.body.firstName || '',
  lastName: req.body.lastName || '',
  streetAddress: req.body.streetAddress || '',
  city: req.body.city || '',
  stateProvince: req.body.stateProvince || '',
  postalCode: req.body.postalCode || '',
  country: req.body.country || '',
  email: req.body.email || '',
  phone: req.body.phone || ''
});

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    title: 'Contact Us (Definitely Not A Scam)',
    formData: null,
    errors: {},
    submitted: false
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = getFormData(req);
  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      title: 'Contact Us (Definitely Not A Scam)',
      formData,
      errors: validation.errors,
      submitted: false
    });
  }

  // Insert into database
  try {
    const now = new Date().toISOString();
    if (db) {
      db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
        now
      ]
    );

    saveDatabase();
    } else {
      throw new Error('Database not initialized');
    }
    console.log('Form submission saved:', formData.firstName);
    
    // Redirect to thank you page with first name in query
    res.redirect(`/thank-you?name=${encodeURIComponent(formData.firstName || 'friend')}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      title: 'Contact Us (Definitely Not A Scam)',
      formData,
      errors: { email: 'An error occurred while saving your submission' },
      submitted: false
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.name ? String(req.query.name) : 'friend';
  res.render('thank-you', { 
    title: 'Thank You!',
    firstName
  });
});

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('Received shutdown signal, closing database');
  if (db) {
    db.close();
  }
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  gracefulShutdown();
});