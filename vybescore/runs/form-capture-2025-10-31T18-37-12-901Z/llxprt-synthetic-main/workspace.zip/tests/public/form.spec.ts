import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the server module to get the app
  app = (await import('../../src/test-app')).default;  
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.statusCode).toBe(200);
    
    const $ = cheerio.load(response.text || '');
    
    // Check if all required form inputs exist
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check if labels are properly associated with inputs
    expect($('label[for="firstName"]').text()).toBe('First Name *');
    expect($('label[for="lastName"]').text()).toBe('Last Name *');
    expect($('label[for="streetAddress"]').text()).toBe('Street Address *');
    expect($('label[for="city"]').text()).toBe('City *');
    expect($('label[for="stateProvince"]').text()).toBe('State / Province / Region *');
    expect($('label[for="postalCode"]').text()).toBe('Postal / Zip Code *');
    expect($('label[for="country"]').text()).toBe('Country *');
    expect($('label[for="email"]').text()).toBe('Email Address *');
    expect($('label[for="phone"]').text()).toBe('Phone Number *');
    
    // Check if form has the correct method and action
    expect($('form[method="post"]')).toHaveLength(1);
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Prepare test data
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'SW1A 1AA',
      country: 'Test Country',
      email: 'test@example.com',
      phone: '+44 20 7946 0958'
    };
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(testData);
    
    // Should redirect to thank-you page
    expect(response.statusCode).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    expect(response.headers.location).toContain('firstName=John');
    
    // Verify the thank-you page works
    const thankYouResponse = await request(app).get('/thank-you?firstName=John');
    expect(thankYouResponse.statusCode).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text || '');
    expect($('h1').text()).toContain('Thank You, John!');
    
    // Verify data was saved to database
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});