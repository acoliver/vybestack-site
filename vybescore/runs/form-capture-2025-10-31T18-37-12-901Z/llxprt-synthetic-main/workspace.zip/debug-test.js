const testApp = async () => {
  try {
    console.log('Importing test app...');
    const app = await import('./src/test-app.js');
    
    console.log('Starting test server...');
    const server = app.default.listen(3001);
    
    console.log('Making requests...');
    const fetch = await import('node-fetch');
    
    // Test basic route
    const response = await fetch.default('http://localhost:3001/');
    console.log('Response status:', response.status);
    const text = await response.text();
    console.log('Response length:', text.length);
    console.log('First 200 characters:', text.substring(0, 200));
    
    // Test with form data
    const submitResponse = await fetch.default('http://localhost:3001/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1234567890'
      })
    });
    console.log('Submit response status:', submitResponse.status);
    
    server.close();
  } catch (error) {
    console.error('Error:', error);
  }
};

testApp();