import { defineConfig } from 'vitest/config';
import { resolve } from 'path';

export default defineConfig({
  test: {
    include: ['tests/public/**/*.spec.ts'],
    environment: 'node',
    globals: true,
    setupFiles: [],
    testTimeout: 10000,
    hookTimeout: 10000,
    bail: false
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src')
    }
  }
});
