import { readFileSync, writeFileSync } from 'fs';
import { formatters } from '../formats/index.js';
import { ReportData, ReportOptions, FormatType } from '../types/report.js';

function parseArguments(argv: string[]): { 
  dataPath: string; 
  format: FormatType; 
  outputPath?: string; 
  includeTotals: boolean;
} {
  const args = argv.slice(2);
  
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataPath = args[0];
  let format: FormatType = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse named arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && args[i + 1]) {
      format = args[i + 1] as FormatType;
      i++;
    } else if (arg === '--output' && args[i + 1]) {
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i] as Record<string, unknown>;
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "label" field (must be string)`);
    }
    
    if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "amount" field (must be number)`);
    }
  }
  
  return true;
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments(process.argv);
    
    // Validate format
    if (format !== 'markdown' && format !== 'text') {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    // Read and parse JSON file
    let rawData: string;
    try {
      rawData = readFileSync(dataPath, 'utf-8');
    } catch (error) {
      throw new Error(`Failed to read file "${dataPath}": ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    
    let reportData: unknown;
    try {
      reportData = JSON.parse(rawData);
    } catch (error) {
      throw new Error(`Invalid JSON in file "${dataPath}": ${error instanceof Error ? error.message : 'Parse error'}`);
    }
    
    // Validate report data structure
    validateReportData(reportData);
    
    // Format the report
    const formatter = formatters[format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    const options: ReportOptions = { includeTotals };
    const output = formatter.format(reportData as ReportData, options);
    
    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf-8');
      } catch (error) {
        throw new Error(`Failed to write output file "${outputPath}": ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    } else {
      process.stdout.write(output);
    }
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
