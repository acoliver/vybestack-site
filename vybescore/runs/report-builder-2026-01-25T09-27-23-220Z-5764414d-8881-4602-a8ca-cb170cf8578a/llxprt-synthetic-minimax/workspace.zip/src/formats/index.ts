import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { Formatter } from '../types/report.js';

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};