import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database configuration - use process.cwd() for consistent paths
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const DB_DIR = path.dirname(DB_PATH);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private server: ReturnType<typeof this.app.listen> | null = null;
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    // GET / - Render form
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req, res) => {
      try {
        const formData: FormData = {
          firstName: (req.body.firstName || '').trim(),
          lastName: (req.body.lastName || '').trim(),
          streetAddress: (req.body.streetAddress || '').trim(),
          city: (req.body.city || '').trim(),
          stateProvince: (req.body.stateProvince || '').trim(),
          postalCode: (req.body.postalCode || '').trim(),
          country: (req.body.country || '').trim(),
          email: (req.body.email || '').trim(),
          phone: (req.body.phone || '').trim()
        };

        const validationErrors = this.validateForm(formData);

        if (validationErrors.length > 0) {
          res.status(400).render('form', {
            errors: validationErrors.map(err => err.message),
            values: formData
          });
          return;
        }

        // Insert into database
        await this.insertSubmission(formData);

        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Error handling form submission:', error);
        res.status(500).render('form', {
          errors: ['An unexpected error occurred. Please try again.'],
          values: req.body
        });
      }
    });

    // GET /thank-you - Thank you page
    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you', {
        firstName: req.query.firstName || 'Friend'
      });
    });
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      if (!data[field]) {
        errors.push({
          field,
          message: `${this.formatFieldName(field)} is required.`
        });
      }
    });

    // Email validation
    if (data.email && !this.isValidEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address.'
      });
    }

    // Phone validation
    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number.'
      });
    }

    // Postal code validation
    if (data.postalCode && !this.isValidPostalCode(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code.'
      });
    }

    return errors;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  private isValidPostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings, spaces, and hyphens (for formats like SW1A 1AA)
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.length >= 3;
  }

  private formatFieldName(field: string): string {
    return field.replace(/([A-Z])/g, ' $1')
                .replace(/^./, str => str.toUpperCase())
                .trim();
  }

  private async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();

    // Save database to file
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) return;

    // Ensure directory exists
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  private async loadSchema(): Promise<void> {
    if (!this.db) return;

    // Try multiple possible paths for the schema file
    const possiblePaths = [
      path.join(__dirname, '..', '..', '..', 'db', 'schema.sql'), // From src/
      path.join(__dirname, '..', '..', 'db', 'schema.sql'),        // From dist/
      path.resolve(process.cwd(), 'db', 'schema.sql')              // From working directory
    ];
    
    let schema = '';
    let schemaFound = false;
    
    for (const schemaPath of possiblePaths) {
      try {
        schema = fs.readFileSync(schemaPath, 'utf-8');
        schemaFound = true;
        break;
      } catch (error) {
        // Continue to next path
        continue;
      }
    }
    
    if (!schemaFound) {
      throw new Error('Could not find schema.sql file in any of the expected locations');
    }

    // Execute schema statements (split by semicolon)
    const statements = schema.split(';').filter(stmt => stmt.trim());
    statements.forEach(statement => {
      if (statement.trim()) {
        this.db!.exec(statement);
      }
    });
  }

  public async start(): Promise<void> {
    try {
      // Initialize sql.js with local WASM files
      const SQL = await initSqlJs({
        locateFile: (file: string) => {
          // Use local WASM files instead of remote URL
          return path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file);
        }
      });
      this.sqlJs = SQL;

      // Load or create database
      if (fs.existsSync(DB_PATH)) {
        const dbBuffer = fs.readFileSync(DB_PATH);
        this.db = new this.sqlJs.Database(dbBuffer);
      } else {
        this.db = new this.sqlJs.Database();
        await this.loadSchema();
        await this.saveDatabase();
      }

      // Start server
      const port = process.env.PORT ? parseInt(process.env.PORT) : 3535;
      this.server = this.app.listen(port, () => {
        console.log(`Form server running on port ${port}`);
      });

      // Setup graceful shutdown
      this.setupGracefulShutdown();
    } catch (error) {
      console.error('Failed to start server:', error);
      // Don't exit in test environment
      if (process.env.NODE_ENV !== 'test') {
        process.exit(1);
      }
      throw error;
    }
  }

  private setupGracefulShutdown(): void {
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}. Starting graceful shutdown...`);
      
      if (this.server) {
        this.server.close();
      }

      if (this.db) {
        await this.saveDatabase();
        this.db.close();
      }

      console.log('Server closed successfully');
      process.exit(0);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }

  public getApp(): express.Application {
    return this.app;
  }

  public close(): void {
    if (this.server) {
      this.server.close();
    }
    if (this.db) {
      this.db.close();
    }
  }
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start().catch(error => {
    console.error('Failed to start server:', error);
    if (process.env.NODE_ENV !== 'test') {
      process.exit(1);
    }
  });
}

export default FormServer;
