import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import FormServer from '../../src/server.js';

let server: FormServer | null = null;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and start the server from TypeScript source
  const { default: FormServerClass } = await import('../../src/server.ts');
  const formServer = new FormServerClass();
  await formServer.start();
  
  server = formServer;
  app = formServer.getApp();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = load(response.text);
    
    // Check for all form fields
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      expect($(`#${field}`).length).toBe(1);
      expect($(`[name="${field}"]`).length).toBe(1);
      expect($(`label[for="${field}"]`).length).toBe(1);
    });

    // Check for form and submit button
    expect($('form').length).toBe(1);
    expect($('button[type="submit"]').length).toBe(1);
    expect($('form[method="post"]').length).toBe(1);
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects to thank-you page', async () => {
    // Submit form with valid data
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1-555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302); // Should redirect

    // Check redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');

    // Test thank-you page loads correctly
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    const $ = load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you');
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({}) // Empty form
      .expect(400); // Should return error status

    const $ = load(response.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('shows validation errors for invalid email', async () => {
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1-555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(400);

    const $ = load(response.text);
    expect($('.error-list li:contains("email")').length).toBeGreaterThan(0);
  });

  it('preserves form values on validation error', async () => {
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1-555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(400);

    const $ = load(response.text);
    expect($('#firstName').val()).toBe('John');
    expect($('#lastName').val()).toBe('Doe');
    expect($('#email').val()).toBe('invalid-email');
  });
});
