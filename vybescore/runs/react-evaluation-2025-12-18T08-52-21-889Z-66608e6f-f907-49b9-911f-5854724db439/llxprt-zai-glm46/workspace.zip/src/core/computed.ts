/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const dependentObservers = new Set<Observer<unknown>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: dependentObservers
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track the observer as dependent on this computed value
      dependentObservers.add(observer as Observer<unknown>)
    }
    return o.value!
  }
  
  // Initial computation
  updateObserver(o)
  
  return getter
}