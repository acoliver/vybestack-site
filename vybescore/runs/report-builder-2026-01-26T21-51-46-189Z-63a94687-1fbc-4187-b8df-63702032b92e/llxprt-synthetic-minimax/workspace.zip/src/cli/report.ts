#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import { ReportData, RenderOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }

  return {
    dataFile,
    format,
    output,
    includeTotals
  };
}

function validateFormat(format: string): void {
  const supportedFormats = ['markdown', 'text'];
  
  if (!supportedFormats.includes(format)) {
    console.error(`Error: Unsupported format '${format}'. Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }
}

function readAndValidateData(dataFile: string): ReportData {
  try {
    const content = readFileSync(dataFile, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (must be an array)');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'label' field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'amount' field (must be a number)`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file. Please check the file syntax.');
      process.exit(1);
    }
    
    if (error instanceof Error && error.message.startsWith('ENOENT:')) {
      console.error(`Error: Data file '${dataFile}' not found.`);
      process.exit(1);
    }
    
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    
    console.error('Error: Unknown error occurred while reading the data file.');
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: RenderOptions, format: string): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      // This should not happen due to validation, but as a safety check
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Validate format early
    validateFormat(args.format);
    
    // Read and validate data
    const data = readAndValidateData(args.dataFile);
    
    // Prepare render options
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    // Render report
    const output = renderReport(data, options, args.format);
    
    // Write output
    if (args.output) {
      try {
        writeFileSync(args.output, output, 'utf8');
      } catch (error) {
        console.error(`Error: Failed to write output file '${args.output}'.`);
        process.exit(1);
      }
    } else {
      // Write to stdout
      process.stdout.write(output);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error occurred.');
    }
    process.exit(1);
  }
}

// Run the CLI
main();
