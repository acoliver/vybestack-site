import { ReportData, RenderOptions } from '../types/index.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const { title, summary, entries } = data;
  
  // Format amount with two decimal places, no thousands separators
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  // Calculate total if needed
  const total = options.includeTotals 
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : null;

  let output = `${title}\n`;
  output += `${summary}\n\n`;
  output += `Entries:\n`;
  
  // Add bullet list entries
  for (const entry of entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }
  
  // Add total if requested
  if (options.includeTotals && total !== null) {
    output += `Total: ${formatAmount(total)}\n`;
  }
  
  return output;
}