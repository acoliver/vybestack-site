/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex to match words starting with the prefix
  // \b ensures we match whole words only, \w matches word characters
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    return !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase());
  });
  
  // Remove duplicates and return
  return [...new Set(result)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to find occurrences where the token is preceded by a digit
  // This will match the digit + token combination
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validate password strength with multiple criteria.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character classes
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212, etc.)
  // This is a simplified check that looks for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.slice(i, i + len);
      const nextPattern = value.slice(i + len, i + len * 2);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses without misidentifying IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if the entire string is an IPv6 address
  const ipv6FullPatterns = [
    // Full IPv6: 8 groups of 1-4 hex digits
    /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
    // Ending with ::
    /^(?:[0-9a-fA-F]{1,4}:){1,7}:$/,
    // Starting with ::
    /^:(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}$/,
    // One :: in middle
    /^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}$/,
    // Link-local IPv6
    /^fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+$/,
    // IPv4-mapped IPv6
    /^::ffff:(?::)?(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/,
    // General compressed format
    /^[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}$/
  ];
  
  // Check if the entire string matches any IPv6 pattern
  for (const pattern of ipv6FullPatterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // Then check if the string contains an IPv6 address
  // We need to be careful not to match IPv4 addresses
  const containsIPv6Regex = /(?:[0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4}|::[0-9a-fA-F]+|[0-9a-fA-F]+::/;
  
  // But first, exclude obvious IPv4 patterns
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/;
  
  // If it matches IPv4 pattern, it's not IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  return containsIPv6Regex.test(value);
}