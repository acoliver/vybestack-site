export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for common international formats.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that covers most valid cases while rejecting obviously invalid ones
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domain] = value.split('@');
  
  // Local part shouldn't start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain shouldn't contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with optional country code.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (10 digits for US number, 11 if starting with 1)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove the leading 1 for validation
    const normalizedDigits = digits.slice(1);
    return validateUSPhoneNumber(normalizedDigits);
  } else if (digits.length === 10) {
// Placeholder for future extension with options
  void options;
    return validateUSPhoneNumber(digits);
  }
  
  return false;
}

/**
 * Helper function to validate a 10-digit US phone number.
 */
function validateUSPhoneNumber(digits: string): boolean {
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code can't start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Exchange code (second 3 digits) can't start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with flexible formatting.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if it starts with country code 54
  if (digits.startsWith('54')) {
    const withoutCountry = digits.slice(2);
    return validateArgentineNumberWithoutCountry(withoutCountry, true);
  } else {
    // Must start with 0 (trunk prefix) if no country code
    return validateArgentineNumberWithoutCountry(digits, false);
  }
}

/**
 * Helper function to validate Argentine number components.
 */
function validateArgentineNumberWithoutCountry(digits: string, hasCountryCode: boolean): boolean {
  if (!hasCountryCode) {
    // Without country code, must start with trunk prefix 0
    if (!digits.startsWith('0')) {
      return false;
    }
    
    // Remove the 0 and validate the rest
    const withoutTrunk = digits.slice(1);
    return validateArgentineNumberCore(withoutTrunk);
  } else {
    // With country code, the next digit could be 9 (mobile) or area code directly
    if (digits.startsWith('9')) {
      // Mobile number, remove the 9
      const withoutMobile = digits.slice(1);
      return validateArgentineNumberCore(withoutMobile);
    } else {
      // Landline number, validate directly
      return validateArgentineNumberCore(digits);
    }
  }
}

/**
 * Core validation for Argentine phone number after removing prefixes.
 */
function validateArgentineNumberCore(digits: string): boolean {
  // Area code: 2-4 digits, leading digit 1-9
  let areaCode = '';
  
  // Try different area code lengths
  for (let len = 2; len <= 4; len++) {
    if (digits.length >= len + 6) {
      const potentialAreaCode = digits.slice(0, len);
      if (/^[2-9]\d*$/.test(potentialAreaCode)) {
        areaCode = potentialAreaCode;
        break;
      }
    }
  }
  
  if (!areaCode || digits.length < areaCode.length + 6) {
    return false;
  }
  
  const subscriberNumber = digits.slice(areaCode.length);
  
  // Subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates names with Unicode support, allowing letters, accents, apostrophes, hyphens, and spaces.
 */
export function isValidName(value: string): boolean {
  // Regex that matches Unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (like accents)
  const nameRegex = /^[\p{L}\p{M}'’\- ]+$/u;
  
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * Validates credit card numbers for major cards using Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length based on card type
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check Visa (starts with 4, length 13 or 16)
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16)) {
    return runLuhnCheck(digits);
  }
  
  // Check Mastercard (starts with 51-55 or 2221-2720, length 16)
  if (digits.length === 16) {
    if (/^5[1-5]/.test(digits) || 
        (/^2(2[2-9]|[3-6]\d|7[01])/.test(digits))) {
      return runLuhnCheck(digits);
    }
  }
  
  // Check American Express (starts with 34 or 37, length 15)
  if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    return runLuhnCheck(digits);
  }
  
  return false;
}

/**
 * Luhn checksum validation helper.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}