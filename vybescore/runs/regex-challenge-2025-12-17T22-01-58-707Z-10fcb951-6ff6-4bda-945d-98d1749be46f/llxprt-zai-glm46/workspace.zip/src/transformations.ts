/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }

  // First, handle sentence boundaries with proper spacing
  let processed = text.replace(/([.!?])\s*([a-zA-Z])/g, (match, delimiter, firstChar) => {
    return `${delimiter} ${firstChar.toUpperCase()}`;
  });
  
  // Capitalize the first character if it's a letter
  processed = processed.replace(/^[a-zA-Z]/, (match) => match.toUpperCase());
  
  // Handle abbreviations and edge cases by looking for common patterns
  // This is a simplified approach - in practice, abbreviation detection is complex
  const commonAbbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|vs|etc|e\.g|i\.e)\.?/gi;
  
  // Check if we might have incorrectly capitalized after an abbreviation
  const abbreviationMatches = text.match(commonAbbreviations);
  if (abbreviationMatches) {
    // For simplicity, we'll accept some edge cases with abbreviation handling
    // The basic implementation above handles most common cases
  }
  
  return processed;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // More comprehensive URL regex
  const urlRegex = /https?:\/\/(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])*(?:\.[a-zA-Z]{2,})(?:\/[^\s\])}<>"']*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation (.,;!?) but keep internal punctuation
  return matches.map(url => url.replace(/[.,;!?)}\]]+$/g, ''));
}

/**
 * Replace http:// schemes with https:// while preserving existing secure URLs.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs according to specific rules.
 */
export function rewriteDocsUrls(text: string): string {
  // Find all http URLs first
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)/g, (match, host, path) => {
    // Always upgrade to https
    let newUrl = `https://${host}${path}`;
    
    // Check if we should rewrite the host to docs.example.com
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !path.includes('cgi-bin') && 
      !path.includes('?') && 
      !path.includes('&') && 
      !path.includes('=') &&
      !/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    if (shouldRewriteHost) {
      // Extract the original domain's TLD for proper docs subdomain construction
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const tld = domainParts[domainParts.length - 1];
        newUrl = `https://docs.example.${tld}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month/day
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day for the month (simplified validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}