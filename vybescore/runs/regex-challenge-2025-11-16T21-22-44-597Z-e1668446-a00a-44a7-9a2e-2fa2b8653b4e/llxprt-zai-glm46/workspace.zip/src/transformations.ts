/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences using sentence-ending punctuation followed by whitespace
  const sentences = text.split(/([.!?]\s*)/);
  
  let result = '';
  let capitalizeNext = true; // Start of text should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.match(/^[.!?]\s*$/)) {
      // This is just punctuation followed by spaces, add as-is and set flag to capitalize next word
      result += part;
      capitalizeNext = true;
    } else if (part.trim() === '') {
      // Just whitespace, add as-is
      result += part;
    } else {
      // This is actual text content
      if (capitalizeNext) {
        // Capitalize the first character, preserve the rest
        const firstChar = part.charAt(0);
        const rest = part.slice(1);
        result += firstChar.toUpperCase() + rest;
        capitalizeNext = false;
      } else {
        // Add as-is (for abbreviations like "e.g.")
        result += part;
      }
    }
  }
  
  // Collapse multiple spaces into single spaces, but preserve sentence spacing
  result = result.replace(/ {2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // More comprehensive URL regex pattern
  // Matches http/https URLs with domains, subdomains, ports, paths, query strings, and fragments
  // Uses negative lookbehind and lookahead to avoid matching trailing punctuation
  const urlRegex = /(?<!\w)(https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s]*)?)(?![^\w\s])/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation like .,;:!? but preserve path separators
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Process all URLs in the text
  return text.replace(/https?:\/\/([^/]+)(\/[^\s]*)?/g, (match, domain, path = '') => {
    // Always upgrade to https first
    let result = `https://${domain}${path}`;
    
    // Check if this is a docs URL that should be rewritten
    if (path.startsWith('/docs/')) {
      // Check for dynamic content that should prevent host rewrite
      const hasDynamicContent = 
        path.includes('cgi-bin') ||
        path.includes('?') ||
        path.includes('&') ||
        path.includes('=') ||
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?&#]|$)/.test(path);
      
      if (!hasDynamicContent) {
        // Rewrite host to docs.{domain}
        result = `https://docs.${domain}${path}`;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month/day
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day range for specific months
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
