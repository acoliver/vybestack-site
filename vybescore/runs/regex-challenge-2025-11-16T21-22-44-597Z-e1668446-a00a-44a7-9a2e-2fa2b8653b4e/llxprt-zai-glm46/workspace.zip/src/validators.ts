export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that covers typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores, and other invalid forms
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Check basic format first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for common invalid patterns
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain parts starting or ending with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  // Reject if local part is empty
  if (localPart.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone validation.
 * Requirements are described in problem.md.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  let digits = value.replace(/\D/g, '');
  
  // Must have at least 10 digits
  if (digits.length < 10) {
    return false;
  }
  
  // If there are more than 10 digits, check for country code
  if (digits.length === 11) {
    // Must start with +1
    if (!digits.startsWith('1')) {
      return false;
    }
    // Remove the country code for further validation
    digits = digits.substring(1);
  } else if (digits.length > 11) {
    // Too many digits
    return false;
  }
  
  // Now we should have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if the format is valid (contains digits in reasonable places)
  const phoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone validation.
 * Requirements are described in problem.md.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with all requirements
  // Optional +54 country code
  // If country code is present, optional 9 mobile indicator and optional 0 trunk prefix
  // If country code is absent, required 0 trunk prefix
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54\s*)?(?:9\s*)?(0?[1-9]\d{1,3})\s*(\d{6,8})$/;
  
  const match = argentinePhoneRegex.exec(cleanValue);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // If country code is omitted, must begin with trunk prefix 0
  if (!value.includes('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits starting with 1-9 (after removing trunk prefix if present)
  const cleanAreaCode = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (cleanAreaCode.length < 2 || cleanAreaCode.length > 4 || !/^[1-9]/.test(cleanAreaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement name validation.
 * Requirements are described in problem.md.
 */
export function isValidName(value: string): boolean {
  // Name should contain unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and unusual names like X Æ A-12
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for forbidden symbols (except allowed ones)
  if (/[!@#$%^&*()_+=[\]{}|:";<>,.?/`~]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Ensure there's at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement credit card validation.
 * Requirements are described in problem.md.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits (typical credit card lengths)
  if (!/^\d{13,19}$/.test(cleanNumber)) {
    return false;
  }
  
  // Check Visa, Mastercard, AmEx prefixes
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^5[1-5][0-9]{14}$/;
  const amexRegex = /^3[47][0-9]{13}$/;
  
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}