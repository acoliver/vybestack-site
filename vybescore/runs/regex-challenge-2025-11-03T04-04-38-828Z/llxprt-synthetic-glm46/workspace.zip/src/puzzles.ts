/**
 * Finds words beginning with the specified prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to match words starting with the prefix
  // Word boundary (\b) ensures we match whole words only
  // [a-zA-Z]+ matches alphabetical characters only
  const wordPattern = new RegExp(`\\b(${prefix}[a-zA-Z]+)\\b`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1].toLowerCase();
    
    // Check if the word is not in the exceptions list
    const isException = exceptions.some(exception => 
      word === exception.toLowerCase()
    );
    
    if (!isException) {
      matches.push(match[1]);
    }
  }
  
  return matches;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use a simpler approach: find all tokens, then check if they have a digit before them
  const tokenPattern = new RegExp(token, 'g');
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    const index = match.index;
    
    // Check if there's a digit immediately before the token
    if (index > 0 && text[index - 1] >= '0' && text[index - 1] <= '9') {
      // Find all consecutive digits before the token
      let digitStart = index - 1;
      while (digitStart > 0 && text[digitStart - 1] >= '0' && text[digitStart - 1] <= '9') {
        digitStart--;
      }
      
      // Extract the digits + token
      const fullMatch = text.substring(digitStart, index) + match[0];
      matches.push(fullMatch);
    }
  }
  
  return matches;
}

/**
 * Validates password strength according to the policy requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, and no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check for minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for presence of required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // We'll look for patterns where a substring of 2-4 characters is repeated immediately
  // This pattern checks if any sequence of 2-4 characters appears twice in a row
  for (let i = 2; i <= 4; i++) {
    // Check if any sequence of length i is repeated immediately
    for (let j = 0; j <= value.length - 2 * i; j++) {
      const sequence = value.substring(j, j + i);
      if (value.substring(j + i, j + 2 * i) === sequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses, including shorthand notation.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern - simplified version without verbose comments
  // This matches standard IPv6 notation and shorthand with ::
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|::ffff(?::0{1,4}){0,1}:(?:25[0-5]|(?:2[0-4]|1?[0-9])?[0-9]){3}(?:25[0-5]|(?:2[0-4]|1?[0-9])?[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:25[0-5]|(?:2[0-4]|1?[0-9])?[0-9]){3}(?:25[0-5]|(?:2[0-4]|1?[0-9])?[0-9])/;
  
  // Test for IPv6
  return ipv6Regex.test(value);
}
