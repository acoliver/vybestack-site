/**
 * Capitalizes the first character of each sentence.
 * Handles multiple spaces between sentences and preserves spacing rules.
 */
export function capitalizeSentences(text: string): string {
  // If text is empty, return as is
  if (!text.trim()) {
    return text;
  }
  
  // First, ensure the first character of the text is capitalized
  let result = text;
  if (result.length > 0 && result.charAt(0) === result.charAt(0).toLowerCase()) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Insert a space after sentence-ending punctuation if there isn't one
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Regex to find positions after sentence-ending punctuation (.?!)
  // Use a lookbehind to check for the punctuation and ensure we're matching the right position
  const sentenceRegex = /([.!?])\s+([a-z])/g;
  
  // Replace each occurrence with capitalized letter
  result = result.replace(sentenceRegex, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Clean up multiple spaces after punctuation to exactly one space
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  return result;
}

/**
 * Extracts URLs from text while excluding trailing punctuation.
 * Returns an array of URLs found in the text.
 */
export function extractUrls(text: string): string[] {
  // Regex for matching URLs
  // Matches http/https protocols, www domains, and various TLDs
  // Excludes trailing punctuation like . , ; : ! ? ) ] } "
  const urlRegex = /((https?:\/\/|www\.)[^\s<>]+)(?=[,.!?;:)\]\}"']|[\s<>]|$)/g;
  
  let match;
  const urls: string[] = [];
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation if it's not part of the URL
    url = url.replace(/[,.!?;:)\]\}"']+$/g, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Replaces http:// URLs with https:// while preserving existing https:// URLs.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using regex
  // Make sure we don't match https:// (to avoid adding extra 's')
  const httpRegex = /http:\/\//g;
  
  return text.replace(httpRegex, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When path begins with /docs/, changes host to docs.example.com
 * Skips host rewrite for paths with dynamic hints (cgi-bin, query strings, or certain extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Match all http://example.com URLs
  const urlRegex = /http:\/\/example\.com(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, path) => {
    // Check for dynamic hints that would prevent host rewrite
    const dynamicHints = [
      'cgi-bin', '\?', '&', '=', '.jsp', '.php', '.asp', 
      '.aspx', '.do', '.cgi', '.pl', '.py'
    ];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // Always upgrade to HTTPS
    const httpsUrl = `https://example.com${path}`;
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      // Change the host to docs.example.com while preserving the path
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise, just upgrade the scheme
    return httpsUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns the four-digit year or 'N/A' if format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month/day combinations
  // February has 28 days (29 in leap years, but we'll keep it simple)
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // Months with 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // Other validation is already covered by the regex
  return year;
}
