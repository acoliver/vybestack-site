export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using comprehensive regex.
 * Accepts standard formats like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern for validation
  // Local part: alphanumeric characters plus allowed special chars, but not consecutive dots or trailing dot
  // Domain part: alphanumeric with hyphens, separated by dots, no underscores, valid TLD
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific requirements
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject leading/trailing hyphens in domain parts
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  // Reject invalid TLDs (should be 2-63 characters)
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2 || tld.length > 63) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, optional +1
 * Rejects impossible area codes (starting with 0 or 1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // US phone regex that handles standard formats:
  // 212-555-7890, (212) 555-7890, 2125557890, +1 212-555-7890
  const usPhoneRegex = /^(\+1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  
  // Check if format is correct
  if (!usPhoneRegex.test(value)) {
    return false;
  }
  
  // Extract the area code from the pattern match
  const match = value.match(usPhoneRegex);
  if (!match) return false;
  
  const areaCode = match[2]; // Second capture group is the area code
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex should be checked with more detailed logic
  // We'll parse manually to ensure validation rules are strictly followed
  
  // Check if the number starts with country code
  let remainingNumber = cleanNumber;
  let hasCountryCode = false;
  
  if (remainingNumber.startsWith('+54')) {
    hasCountryCode = true;
    remainingNumber = remainingNumber.substring(3);
  }
  
  // Check for mobile indicator (9)
  if (remainingNumber.startsWith('9')) {
    remainingNumber = remainingNumber.substring(1);
  }
  
  // Check for trunk prefix (0)
  let hasTrunkPrefix = false;
  if (remainingNumber.startsWith('0')) {
    hasTrunkPrefix = true;
    remainingNumber = remainingNumber.substring(1);
  }
  
  // If there's no country code, we must have a trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // If there's both country code and trunk prefix, this is invalid format
  if (hasCountryCode && hasTrunkPrefix) {
    return false;
  }
  
  // Extract area code (2-4 digits, starting with 1-9)
  const areaCodeMatch = remainingNumber.match(/^([1-7]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  remainingNumber = remainingNumber.substring(areaCode.length);
  
  // Remaining part should be the subscriber number (6-8 digits)
  if (remainingNumber.length < 6 || remainingNumber.length > 8) {
    return false;
  }
  
  if (!/^\d+$/.test(remainingNumber)) {
    return false;
  }
  
  // All validations passed
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unconventional names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Name regex pattern:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, and spaces
  // - At least one character is required
  // - Reject digits and symbols (except allowed ones)
  const nameRegex = /^[\p{L}'][\p{L}'\-\s]*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Ensure it contains at least one letter (not just symbols)
  const hasLetter = /\p{L}/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Check for unconventional patterns like "X Æ A-12" that contain digits
  const hasDigit = /\d/.test(value);
  if (hasDigit) {
    return false;
  }
  
  // Reject special symbols like Æ that might appear in unconventional names
  // This handles cases like Elon Musk's child name "X Æ A-12"
  // We'll allow most Unicode letters but reject unusual symbol combinations
  const hasUnusualSymbols = /[Ææ]/.test(value);
  if (hasUnusualSymbols) {
    // Allow Æ only if it's part of a conventional name pattern (e.g., Scandinavian names)
    // For simplicity, we'll reject it as it's uncommon in most contexts
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using length, prefix validation, and Luhn checksum.
 * Accepts Visa, Mastercard, and AmEx formats.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove non-digit characters (spaces, hyphens, etc.)
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check length based on card type
  // Visa: 13 or 16 digits, starts with 4
  // MasterCard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  // Visa validation
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // MasterCard validation
  const masterCardRegex1 = /^5[1-5]\d{14}$/; // 51-55
  const masterCardRegex2 = /^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|(7[01]|720)\d)\d{12}$/; // 2221-2720
  
  // AmEx validation
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanNumber) && 
      !masterCardRegex1.test(cleanNumber) && 
      !masterCardRegex2.test(cleanNumber) && 
      !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Luhn algorithm validation
  return luhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn algorithm checksum
 */
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    // Double every second digit from the right
    const isSecondFromRight = ((cardNumber.length - i) % 2) === 0;
    if (isSecondFromRight) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9; // Equivalent to summing the digits
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}