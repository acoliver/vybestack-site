/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Use word boundaries to ensure we match complete words
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex);
  
  if (!matches) return [];
  
  // Filter out exceptions (case insensitive comparison)
  return matches.filter(match => !exceptions.some(exception => 
    exception.toLowerCase() === match.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex that matches a digit followed by the token
  // This ensures we capture both the digit and the token
  const regex = new RegExp(`\\d${token}`, 'g');
  const matches = text.match(regex);
  
  return matches ? matches : [];
}

/**
 * Validates passwords according to the strong password policy.
 */
export function isStrongPassword(value: string): boolean {
  // Check basic requirements: length >= 10, has uppercase, lowercase, digit, symbol, no whitespace
  if (value.length < 10) return false;
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/\d/.test(value)) return false;
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) return false;
  if (/\s/.test(value)) return false;
  
  // Check for repeated sequences (e.g., abab)
  // Using a regex to detect repeating patterns of 2 or more characters
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that handles full and compressed formats
  // This pattern is simplified but should cover most common cases
  const ipv6Regex = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::|[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}/g;
  
  // IPv4 regex pattern
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  
  // Check if it matches IPv6 but not IPv4
  const hasIPv6 = ipv6Regex.test(value);
  const hasIPv4 = ipv4Regex.test(value);
  
  return hasIPv6 && !hasIPv4;
}