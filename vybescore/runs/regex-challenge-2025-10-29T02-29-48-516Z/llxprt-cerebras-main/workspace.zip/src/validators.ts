export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with common rules.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace and check for empty string
  const trimmed = value.trim();
  if (!trimmed) return false;

  // Check basic email structure with regex
  // Local part: alphanumeric, dots, hyphens, underscores, plus signs
  // Domain part: alphanumeric, dots, hyphens (no underscores, no trailing dots)
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(trimmed)) return false;
  
  // Additional checks for edge cases
  const parts = trimmed.split('@');
  if (parts.length !== 2) return false;
  
  const localPart = parts[0];
  const domainPart = parts[1];
  
  // Reject if local part starts or ends with a dot or has consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) return false;
  
  // Reject if domain has underscores or ends with a dot
  if (domainPart.includes('_') || domainPart.endsWith('.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if it's too short
  if (digits.length < 10) return false;
  
  // Handle optional country code prefix (+1 or 1)
  let phoneNumber = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    phoneNumber = digits.substring(1);
  } else if (digits.length === 12 && digits.startsWith('11')) {
    // Special case for +11 formats
    phoneNumber = digits.substring(2);
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) return false;
  
  // First digit of area code can't be 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') return false;
  
  // First digit of exchange code can't be 0 or 1
  if (phoneNumber[3] === '0' || phoneNumber[3] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except the plus sign
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +54 (country code) or 0 (trunk code)
  let phoneNumber = cleaned;
  let hasCountryCode = false;
  let hasTrunkCode = false;
  
  if (phoneNumber.startsWith('+54')) {
    phoneNumber = phoneNumber.substring(3);
    hasCountryCode = true;
  }
  
  if (phoneNumber.startsWith('0') && !hasCountryCode) {
    phoneNumber = phoneNumber.substring(1);
    hasTrunkCode = true;
  }
  
  // Check if number begins with trunk code when country code is omitted
  if (!hasCountryCode && !hasTrunkCode) return false;
  
  // For mobile numbers, check for 9 prefix after country/trunk code
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Area code must be 2-4 digits with first digit 1-9
  if (phoneNumber.length < 8 || phoneNumber.length > 12) return false;
  
  // Find where area code ends by checking first digit after trunk code
  const firstDigit = phoneNumber[0];
  if (firstDigit === '0') return false; // Area code can't start with 0
  
  // Look for valid area code lengths (2-4 digits)
  let areaCodeLength = 0;
  if (phoneNumber.length >= 8 && phoneNumber.length <= 12) {
    // Area codes in Argentina are typically 2-4 digits
    // We'll try all valid lengths: 2, 3, or 4 digits
    for (let i = 2; i <= 4; i++) {
      if (phoneNumber.length >= i + 6 && phoneNumber.length <= i + 8) {
        areaCodeLength = i;
        break;
      }
    }
  }
  
  if (areaCodeLength === 0) return false;
  
  // Extract subscriber number (after area code)
  const subscriberNumber = phoneNumber.substring(areaCodeLength);
  
  // Check subscriber number is 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for empty string
  if (!value || value.trim() === '') return false;
  
  // Check for digits and symbols (except allowed ones)
  // Allow unicode letters, spaces, hyphens, apostrophes
  const nameRegex = /^[\p{L}\s\-']+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names with whitespace only
  if (value.trim() === '') return false;
  
  // Reject names with consecutive spaces
  if (value.includes('  ')) return false;
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check card type by prefix and length
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12}$/; // 16 digits, starts with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  if (!(visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))) {
    return false;
  }
  
  // Luhn algorithm check
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}