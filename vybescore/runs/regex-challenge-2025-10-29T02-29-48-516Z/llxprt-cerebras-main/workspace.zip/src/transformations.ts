/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty input
  if (!text) return text;

  // Split text into sentences based on ., !, or ? followed by whitespace or end of string
  // Using a regex with capturing group to preserve the sentence ending punctuation
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  }).replace(/\s+/g, ' ').trim(); // Collapse multiple spaces into single space and trim
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match URLs with various protocols and domain structures
  // Improved regex to better match full URLs including the domain part
  const urlRegex = /\b(?:https?|ftp):\/\/[^\s/$.?#].[^\s,.;:!?)\]}]*/gi;
  const matches = text.match(urlRegex);
  
  return matches ? matches : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not if already https://
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs that start with http://, have a domain, and optionally a path
  // Upgrade scheme to https, and if path starts with /docs/, change host to docs.domain.com
  return text.replace(/\bhttp:\/\/([^\/\s]+)(\/[^\s,.;:!?)\]}]*)?/gi, (match, domain, path = '') => {
    // Check if path contains dynamic hints that should prevent host rewrite
    const hasDynamicHints = /(?:cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|\?|&|=)/i.test(path);
    
    // Check if path begins with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    // Always upgrade to https
    let newUrl = `https://${domain}${path}`;
    
    // Rewrite host only if it's a docs path and has no dynamic hints
    if (isDocsPath && !hasDynamicHints) {
      newUrl = `https://docs.${domain}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match dates in mm/dd/yyyy format with exactly 4 digits for year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}