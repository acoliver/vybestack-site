/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: ObserverR[] = []
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    observers,
    updateFn,
  }
  
  // Initial computation
  updateObserver(o)
  
  // After initial computation, notify observers
  notifyObservers(o)
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observers.includes(observer)) {
      observers.push(observer)
    }
    return o.value!
  }
  
  return read
}
