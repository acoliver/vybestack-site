/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<Observer<unknown>> // Observers that depend on this one
  // Keep track of whether this observer has been initialized
  initialized?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  const originalValue = observer.value
  
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    
    // Only notify dependents if the value actually changed
    if (newValue !== originalValue || !observer.initialized) {
      observer.initialized = true
      
      // Notify all dependents after this observer has been updated
      if (observer.dependents) {
        const dependentsCopy = new Set(observer.dependents)
        dependentsCopy.forEach(dependent => {
          updateObserver(dependent as Observer<unknown>)
        })
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function registerDependent<T>(observer: Observer<T>, dependent: Observer<unknown>): void {
  if (!observer.dependents) {
    observer.dependents = new Set()
  }
  observer.dependents.add(dependent)
}