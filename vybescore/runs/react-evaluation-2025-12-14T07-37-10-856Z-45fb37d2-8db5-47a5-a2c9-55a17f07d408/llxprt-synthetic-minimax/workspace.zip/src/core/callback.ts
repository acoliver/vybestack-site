/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      // For callbacks, always execute the side effect
      const result = updateFn(currentValue)
      return result
    },
    initialized: false
  }
  
  // Execute the callback initially to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up any dependencies
    if (observer.dependents) {
      observer.dependents.clear()
    }
  }
}