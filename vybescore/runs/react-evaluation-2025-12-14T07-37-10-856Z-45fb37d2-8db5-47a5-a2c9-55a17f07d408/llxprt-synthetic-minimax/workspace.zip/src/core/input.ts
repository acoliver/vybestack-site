/**
 * Input closure implementation for reactive primitives.
 */

import{
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
  }

  const dependents = new Set<Observer<unknown>>()

  const read: GetterFn<T> = () => {
    // When this input is read, register the active observer as a dependent
    const observer = getActiveObserver()
    if (observer) {
      dependents.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Always notify all dependents when value changes
    Array.from(dependents).forEach(observer => {
      updateObserver(observer)
    })
    
    return s.value
  }

  return [read, write]
}