/**
 * Encode plain text to Base64 using standard Base64 encoding.
 * Uses canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates input.
 */
export function decode(input: string): string {
  const normalized = input.trim();
  
  // Validate Base64 input format
  if (normalized.length === 0) {
    throw new Error('Base64 input cannot be empty');
  }
  
  // Check for invalid characters (only allow Base64 alphabet and padding)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Ensure proper padding if missing
  let paddedInput = normalized;
  const remainder = normalized.length % 4;
  if (remainder !== 0) {
    // Add missing padding
    paddedInput = normalized + '='.repeat(4 - remainder);
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
