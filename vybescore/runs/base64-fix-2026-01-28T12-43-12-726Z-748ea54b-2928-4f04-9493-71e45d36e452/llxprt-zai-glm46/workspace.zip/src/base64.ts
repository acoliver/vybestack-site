/**
 * Validate that a string is valid Base64.
 * Standard Base64 uses: A-Z, a-z, 0-9, +, /, and = for padding
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) return false;
  
  // Remove padding for validation
  const unpadded = input.replace(/=+$/, '');
  
  // Base64 regex: matches standard Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]+$/;
  if (!base64Regex.test(unpadded)) return false;
  
  // Padding, if present, must be at the end and can only be 1 or 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingCount = paddingMatch[0].length;
    if (paddingCount > 2) return false;
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if the decoding was successful by verifying the buffer is not empty
    // when input is not just padding
    const hasData = input.replace(/=+$/, '').length > 0;
    if (hasData && buffer.length === 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
