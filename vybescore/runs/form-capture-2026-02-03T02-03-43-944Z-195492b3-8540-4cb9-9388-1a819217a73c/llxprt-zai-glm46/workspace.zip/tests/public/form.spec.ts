import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase } from '../../src/server.js';

let dbInitialized = false;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  if (!dbInitialized) {
    await initializeDatabase();
    dbInitialized = true;
  }
});

afterAll(() => {
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get In Touch');

    const $ = cheerio.load(response.text);

    // Check for all required fields
    expect($('input[name="first_name"]')).toHaveLength(1);
    expect($('input[name="last_name"]')).toHaveLength(1);
    expect($('input[name="street_address"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="state_province"]')).toHaveLength(1);
    expect($('input[name="postal_code"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check for labels
    expect($('label[for="first_name"]').text()).toContain('First Name');
    expect($('label[for="email"]').text()).toContain('Email');
  });

  it('persists submission and redirects', async () => {
    // Clear database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'London',
      state_province: 'England',
      postal_code: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: '',
        last_name: '',
        email: 'invalid-email',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'Test',
        last_name: 'User',
        street_address: '123 Test St',
        city: 'Test City',
        state_province: 'Test State',
        postal_code: '12345',
        country: 'Test Country',
        email: 'not-an-email',
        phone: '+1 234 567 8900',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'Test',
        last_name: 'User',
        street_address: '123 Test St',
        city: 'Test City',
        state_province: 'Test State',
        postal_code: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: 'invalid-phone!@#',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('valid phone');
  });

  it('accepts international phone formats', async () => {
    const testPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
    ];

    for (const phone of testPhones) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          first_name: 'Test',
          last_name: 'User',
          street_address: '123 Test St',
          city: 'Test City',
          state_province: 'Test State',
          postal_code: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone,
        });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('accepts international postal codes', async () => {
    const testPostalCodes = ['SW1A 1AA', 'C1000', 'B1675', '12345'];

    for (const postal of testPostalCodes) {
      // Clear database between tests
      if (fs.existsSync(dbPath)) {
        fs.unlinkSync(dbPath);
      }

      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          first_name: 'Test',
          last_name: 'User',
          street_address: '123 Test St',
          city: 'Test City',
          state_province: 'Test State',
          postal_code: postal,
          country: 'Test Country',
          email: 'test@example.com',
          phone: '+1 234 567 8900',
        });

      expect(response.status).toBe(302);
    }
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank You');
    expect(response.text.toLowerCase()).toContain('spam');
  });

  it('preserves form data on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'Jane',
        last_name: '',
        email: 'jane@example.com',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('input[name="first_name"]').val()).toBe('Jane');
  });
});
