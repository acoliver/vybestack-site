import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(process.cwd(), 'public')));
app.set('view engine', 'ejs');

// Set views directory - check both src/views (development) and dist/views (production)
const possiblePaths = [
  path.resolve(process.cwd(), 'src', 'views'),
  path.resolve(process.cwd(), 'dist', 'views'),
  path.resolve(__dirname, 'views'),
];
const viewsPath = possiblePaths.find(p => fs.existsSync(p)) || path.resolve(process.cwd(), 'src', 'views');
app.set('views', viewsPath);

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow optional leading +, then digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateSubmission(data: SubmissionData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: (keyof SubmissionData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim().length === 0) {
      errors.push({
        field,
        message: `${field.replace('_', ' ')} is required`,
      });
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number',
    });
  }

  // Postal code validation
  if (data.postal_code && !validatePostalCode(data.postal_code)) {
    errors.push({
      field: 'postal_code',
      message: 'Please enter a valid postal code',
    });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  const errors: ValidationError[] = [];
  const formData: Partial<SubmissionData> = {};
  res.render('form', { errors, formData });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: SubmissionData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateSubmission(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('form', { errors, formData });
  }

  // Insert into database
  if (!db) {
    console.error('Database not initialized');
    return res.status(500).send('Internal server error');
  }

  try {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.first_name,
        formData.last_name,
        formData.street_address,
        formData.city,
        formData.state_province,
        formData.postal_code,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );

    // Save database to disk
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    let dbData: Uint8Array | null = null;

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      dbData = new Uint8Array(fileBuffer);
      db = new SQL.Database(dbData);
      console.log('Loaded existing database from', DB_PATH);
    } else {
      db = new SQL.Database();
      console.log('Created new database');
    }

    // Ensure schema exists
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server closed');
      process.exit(0);
    });

    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Export app for testing
export { app, initializeDatabase };

// Start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
