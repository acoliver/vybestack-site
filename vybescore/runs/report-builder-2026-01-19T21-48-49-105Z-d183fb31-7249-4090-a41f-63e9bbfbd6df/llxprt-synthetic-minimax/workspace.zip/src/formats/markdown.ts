import { ReportData } from '../types.js';

function formatAmount(amount: number): string {
  return amount.toFixed(2);
}

function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  let output = '';
  
  // Title
  output += `# ${data.title}\n\n`;
  
  // Summary
  output += `${data.summary}\n\n`;
  
  // Entries heading
  output += `## Entries\n\n`;
  
  // Entries list
  data.entries.forEach(entry => {
    output += `- **${entry.label}** — $${formatAmount(entry.amount)}\n`;
  });
  
  // Total if requested
  if (includeTotals) {
    const total = calculateTotal(data.entries);
    output += `\n**Total:** $${formatAmount(total)}`;
  }
  
  return output;
}