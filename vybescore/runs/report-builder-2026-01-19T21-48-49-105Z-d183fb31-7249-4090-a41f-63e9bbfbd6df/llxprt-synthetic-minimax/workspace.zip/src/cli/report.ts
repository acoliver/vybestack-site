#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): CliOptions {
  const args = argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('--format requires a value');
          process.exit(1);
        }
        format = args[i + 1] as 'markdown' | 'text';
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('--output requires a value');
          process.exit(1);
        }
        outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (arg.startsWith('--')) {
          console.error(`Unknown option: ${arg}`);
          process.exit(1);
        }
        break;
    }
  }
  
  if (!format) {
    console.error('--format is required');
    process.exit(1);
  }
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i] as Record<string, unknown>;
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const options = parseArgs(process.argv);
    
    // Read and parse JSON file
    const jsonContent = readFileSync(options.dataPath, 'utf-8');
    const data = JSON.parse(jsonContent);
    
    // Validate data structure
    const reportData = validateReportData(data);
    
    // Validate format
    const formatters: Record<string, (data: ReportData, includeTotals: boolean) => string> = {
      'markdown': renderMarkdown,
      'text': renderText
    };
    
    const formatter = formatters[options.format];
    
    if (!formatter) {
      console.error(`Unsupported format: ${options.format}`);
      process.exit(1);
    }
    
    // Render report
    const output = formatter(reportData, options.includeTotals);
    
    // Write output
    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
