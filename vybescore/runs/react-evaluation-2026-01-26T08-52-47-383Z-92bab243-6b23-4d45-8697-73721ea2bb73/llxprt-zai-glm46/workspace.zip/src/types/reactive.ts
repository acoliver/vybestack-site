/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: unknown[] // Track which subjects this observer depends on
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: unknown[] // Track which observers depend on this subject
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Track the current active observer being evaluated
let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Clear previous dependencies and re-track
    observer.subjects = []
    observer.value = observer.updateFn(observer.value)
    
    // For computed values, we need to notify our observers when we update
    if ('observers' in observer) {
      const subjectObserver = observer as Observer<T> & { observers?: unknown[] }
      // Notify all observers that depend on this computed value
      if (subjectObserver.observers) {
        for (const obs of subjectObserver.observers) {
          if (obs !== previous) { // Avoid re-entrant notifications
            updateObserver(obs as Observer<unknown>)
          }
        }
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (subject.observers) {
    for (const observer of [...subject.observers]) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
