/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Link this subject to the active observer
      // Track this subject in the observer's dependencies
      if (!activeObserver.subjects) {
        activeObserver.subjects = []
      }
      if (!activeObserver.subjects.includes(s)) {
        activeObserver.subjects.push(s)
      }
      // Track this observer in the subject's observers list
      if (!s.observers) {
        s.observers = []
      }
      if (!s.observers.includes(activeObserver)) {
        s.observers.push(activeObserver)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // When the value changes, notify all observers
    notifyObservers(s as unknown as Subject<unknown>)
    return s.value
  }

  return [read, write]
}
