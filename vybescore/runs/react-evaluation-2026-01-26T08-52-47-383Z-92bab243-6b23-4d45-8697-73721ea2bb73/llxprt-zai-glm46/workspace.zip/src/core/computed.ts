/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // The computed observer that will be updated when dependencies change
  // Also acts as a subject to observers that depend on this computed value
  const computedObserver: Observer<T> & Subject<T> = {
    name: options?.name,
    value: value as T,
    updateFn,
    subjects: [],
    observers: [],
  }
  
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // If someone is reading this computed value, track that dependency
      const obs = activeObserver as Observer<unknown>
      if (!obs.subjects) obs.subjects = []
      // Avoid duplicates
      if (!obs.subjects.includes(computedObserver as unknown)) {
        obs.subjects.push(computedObserver as unknown)
      }
      // Track this observer in the computed's observers list
      if (!computedObserver.observers) {
        computedObserver.observers = []
      }
      if (!computedObserver.observers.includes(activeObserver)) {
        computedObserver.observers.push(activeObserver)
      }
    }
    return computedObserver.value!
  }
  
  // Initialize the computed value by running updateObserver
  // This will track which subjects this computed depends on
  updateObserver(computedObserver)
  
  return read
}
