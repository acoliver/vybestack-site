

/**
 * Encode plain text to Base64 using the canonical RFC 4648 Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Basic validation: ensure only valid Base64 characters are present
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Ensure proper padding length (at most 2 '=' characters at the end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && input.length - paddingIndex > 2) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
