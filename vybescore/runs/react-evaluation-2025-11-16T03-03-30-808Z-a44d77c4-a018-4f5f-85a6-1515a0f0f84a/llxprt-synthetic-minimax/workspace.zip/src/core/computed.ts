/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const getter: GetterFn<T> = () => {
    // Mark this observer as active to track dependencies
    const previousActiveObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      const result = updateObserver(observer)
      return result
    } finally {
      setActiveObserver(previousActiveObserver)
    }
  }

  return getter
}
