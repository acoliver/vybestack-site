/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<Subject<unknown>>
  dependents?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  dependents?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    observer.value = result
    return result
  } finally {
    activeObserver = previous
  }
}

export function registerDependency<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
  
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject as Subject<unknown>)
}

export function notifyDependents<T>(subject: Subject<T>): void {
  if (subject.dependents) {
    // Ensure we have a copy in case the set changes during iteration
    const dependents = Array.from(subject.dependents)
    for (const dependent of dependents) {
      if ('updateFn' in dependent) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
  }
}
