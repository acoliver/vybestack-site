import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;
let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Validation functions
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return { field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  if (!postalRegex.test(postalCode)) {
    return { field: 'postalCode', message: 'Postal code can only contain letters, digits, spaces, and dashes' };
  }
  return null;
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  const requiredFields = [
    { value: formData.firstName, name: 'First name' },
    { value: formData.lastName, name: 'Last name' },
    { value: formData.streetAddress, name: 'Street address' },
    { value: formData.city, name: 'City' },
    { value: formData.stateProvince, name: 'State / Province / Region' },
    { value: formData.postalCode, name: 'Postal / Zip code' },
    { value: formData.country, name: 'Country' },
    { value: formData.email, name: 'Email' },
    { value: formData.phone, name: 'Phone number' }
  ];

  for (const field of requiredFields) {
    const error = validateRequired(field.value, field.name);
    if (error) errors.push(error);
  }

  const emailError = validateEmail(formData.email);
  if (emailError) errors.push(emailError);

  const phoneError = validatePhone(formData.phone);
  if (phoneError) errors.push(phoneError);

  const postalError = validatePostalCode(formData.postalCode);
  if (postalError) errors.push(postalError);

  return errors;
}

// Database initialization
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const fileData = fs.readFileSync(dbPath);
      dbData = new Uint8Array(fileData);
    }

    db = new SQL.Database(dbData);

    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    db.exec(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) return;

  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
  }

  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database error. Please try again.'],
      values: formData
    });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database insertion error:', error);
    res.status(500).render('form', {
      errors: ['Failed to save submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
      console.log(`Visit http://localhost:${port} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
