import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database configuration
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

// Form values type
interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Initialize database
let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  const { default: initSqlJs } = await import('sql.js');
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file),
  });

  try {
    const fs = await import('fs');
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      
      // Read and execute schema
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const fs = await import('fs');
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings, allow spaces
  const postalRegex = /^[A-Za-z0-9][A-Za-z0-9\s-]*$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateForm(values: FormValues): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Validate required fields
  if (!validateRequired(values.firstName || '')) {
    errors.push('First name is required');
  }
  if (!validateRequired(values.lastName || '')) {
    errors.push('Last name is required');
  }
  if (!validateRequired(values.streetAddress || '')) {
    errors.push('Street address is required');
  }
  if (!validateRequired(values.city || '')) {
    errors.push('City is required');
  }
  if (!validateRequired(values.stateProvince || '')) {
    errors.push('State/Province/Region is required');
  }
  if (!validateRequired(values.postalCode || '')) {
    errors.push('Postal code is required');
  }
  if (!validateRequired(values.country || '')) {
    errors.push('Country is required');
  }
  if (!validateRequired(values.email || '')) {
    errors.push('Email is required');
  } else if (!validateEmail(values.email || '')) {
    errors.push('Please enter a valid email address');
  }
  if (!validateRequired(values.phone || '')) {
    errors.push('Phone number is required');
  } else if (!validatePhone(values.phone || '')) {
    errors.push('Please enter a valid phone number');
  }

  // Validate postal code format
  if (values.postalCode && !validatePostalCode(values.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

// Express app
const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.status(200).render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateForm(values);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone,
    ]);
    
    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(values.firstName || '')}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || '';
  res.status(200).render('thank-you', {
    firstName,
  });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('\nShutting down gracefully...');
  
  if (db) {
    await saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();