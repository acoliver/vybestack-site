declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    exec(sql: string): void;
    close(): void;
    export(): Uint8Array;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    step(): boolean;
    get(params?: unknown[]): unknown[];
    free(): void;
  }

  export default class SQLJS {
    Database: new() => Database;
  }
}