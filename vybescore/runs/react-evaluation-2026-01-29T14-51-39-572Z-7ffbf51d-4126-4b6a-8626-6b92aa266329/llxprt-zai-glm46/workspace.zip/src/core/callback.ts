/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track observers (for cleanup)
  const observers: unknown[] = []
  let disposed = false
  
  // Register observer to track dependencies and run the initial callback
  updateObserver(observer)
  
  // Override the observer's update to prevent updates after disposal
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue: T | undefined): T => {
    if (disposed) {
      return prevValue as T
    }
    return originalUpdateFn(prevValue)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear all observers to stop further updates
    observers.length = 0
  }
}
