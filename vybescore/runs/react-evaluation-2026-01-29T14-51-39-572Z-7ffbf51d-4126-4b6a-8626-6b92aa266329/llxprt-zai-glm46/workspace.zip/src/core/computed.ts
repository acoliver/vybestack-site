/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track observers of this computed value
  const observers: unknown[] = []
  
  const read: GetterFn<T> = () => {
    // When this computed is being read, check if there's an active observer
    // (e.g., another computed or callback that depends on this one)
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register the active observer as depending on this computed value
      if (!observers.includes(activeObserver)) {
        observers.push(activeObserver)
      }
    }
    
    // Return the current value
    return o.value!
  }
  
  // Override the update function to notify observers after recalculation
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue) => {
    // First, run the original update function to recalculate the value
    // This happens while this observer is the active observer (set by updateObserver)
    const newValue = originalUpdateFn(prevValue)
    o.value = newValue
    
    // After the value is recalculated, notify all observers that depend on this computed
    for (const observer of observers) {
      updateObserver(observer as Observer<unknown>)
    }
    
    return newValue
  }
  
  // Initialize the computed value by running the update function
  // This will track any dependencies accessed during the update
  updateObserver(o)
  
  return read
}
