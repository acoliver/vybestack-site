#!/usr/bin/env node

import { readFileSync } from 'fs';
import { writeFile } from 'fs/promises';
import type { Format, ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as Format;
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }
  
  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }
  
  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid label field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid amount field`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArguments();
    
    let jsonData: string;
    try {
      jsonData = readFileSync(inputFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Cannot read file ${inputFile}`);
      process.exit(1);
    }
    
    let parsedData: unknown;
    try {
      parsedData = JSON.parse(jsonData);
    } catch (error) {
      console.error('Error: Invalid JSON in input file');
      process.exit(1);
    }
    
    const reportData: ReportData = validateReportData(parsedData);
    const options: RenderOptions = { includeTotals };
    
    let output: string;
    switch (format) {
      case 'markdown':
        output = renderMarkdown.render(reportData, options);
        break;
      case 'text':
        output = renderText.render(reportData, options);
        break;
    }
    
    if (outputPath) {
      writeFile(outputPath, output)
        .then(() => {
          console.log(`Report written to ${outputPath}`);
        })
        .catch((error) => {
          console.error(`Error writing to file ${outputPath}:`, error);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
