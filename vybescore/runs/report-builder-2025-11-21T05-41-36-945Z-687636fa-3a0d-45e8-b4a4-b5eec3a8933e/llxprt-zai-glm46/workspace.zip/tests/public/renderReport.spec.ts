import { describe, expect, it } from 'vitest';
import { execSync } from 'child_process';
import { readFileSync, unlinkSync, writeFileSync } from 'fs';
import { join } from 'path';

describe('report CLI (public smoke)', () => {
  const projectRoot = process.cwd();
  const cliPath = join(projectRoot, 'dist/cli/report.js');
  const fixturePath = join(projectRoot, 'fixtures/data.json');

  it('should build successfully', () => {
    execSync('npm run build', { cwd: projectRoot, stdio: 'pipe' });
  });

  it('should render markdown format', () => {
    const output = execSync(`node ${cliPath} ${fixturePath} --format markdown`, { 
      cwd: projectRoot, 
      encoding: 'utf-8' 
    });
    
    expect(output).toContain('# Quarterly Financial Summary');
    expect(output).toContain('Highlights include record revenue');
    expect(output).toContain('## Entries');
    expect(output).toContain('**North Region** — $12345.67');
    expect(output).toContain('**South Region** — $23456.78');
    expect(output).toContain('**West Region** — $34567.89');
    expect(output).not.toContain('Total:');
  });

  it('should render markdown format with totals', () => {
    const output = execSync(`node ${cliPath} ${fixturePath} --format markdown --includeTotals`, { 
      cwd: projectRoot, 
      encoding: 'utf-8' 
    });
    
    expect(output).toContain('**Total:** $70370.34');
  });

  it('should render text format', () => {
    const output = execSync(`node ${cliPath} ${fixturePath} --format text`, { 
      cwd: projectRoot, 
      encoding: 'utf-8' 
    });
    
    expect(output).toContain('Quarterly Financial Summary');
    expect(output).toContain('Highlights include record revenue');
    expect(output).toContain('Entries:');
    expect(output).toContain('- North Region: $12345.67');
    expect(output).toContain('- South Region: $23456.78');
    expect(output).toContain('- West Region: $34567.89');
    expect(output).not.toContain('Total:');
  });

  it('should render text format with totals', () => {
    const output = execSync(`node ${cliPath} ${fixturePath} --format text --includeTotals`, { 
      cwd: projectRoot, 
      encoding: 'utf-8' 
    });
    
    expect(output).toContain('Total: $70370.34');
  });

  it('should write to output file when specified', () => {
    const outputFile = join(projectRoot, 'test-output.txt');
    
    try {
      execSync(`node ${cliPath} ${fixturePath} --format text --output ${outputFile}`, { 
        cwd: projectRoot, 
        stdio: 'pipe' 
      });
      
      const output = readFileSync(outputFile, 'utf-8');
      expect(output).toContain('Quarterly Financial Summary');
      expect(output).toContain('North Region: $12345.67');
    } finally {
      try {
        unlinkSync(outputFile);
      } catch {
        // Ignore if file doesn't exist
      }
    }
  });

  it('should handle invalid format', () => {
    expect(() => {
      execSync(`node ${cliPath} ${fixturePath} --format invalid`, { 
        cwd: projectRoot, 
        stdio: 'pipe' 
      });
    }).toThrow();
  });

  it('should handle missing arguments', () => {
    expect(() => {
      execSync(`node ${cliPath}`, { 
        cwd: projectRoot, 
        stdio: 'pipe' 
      });
    }).toThrow();
  });

  it('should handle malformed JSON', () => {
    const malformedFile = join(projectRoot, 'test-malformed.json');
    
    try {
      writeFileSync(malformedFile, '{ invalid json }');
      
      expect(() => {
        execSync(`node ${cliPath} ${malformedFile} --format text`, { 
          cwd: projectRoot, 
          stdio: 'pipe' 
        });
      }).toThrow();
    } finally {
      try {
        unlinkSync(malformedFile);
      } catch {
        // Ignore if file doesn't exist
      }
    }
  });
});
