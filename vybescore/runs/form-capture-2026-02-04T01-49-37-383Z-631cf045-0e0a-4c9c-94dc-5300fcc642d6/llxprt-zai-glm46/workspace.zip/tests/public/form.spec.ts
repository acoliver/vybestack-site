import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer, closeServer } from '../../src/server.js';

beforeAll(async () => {
  await startServer();
});

afterAll(() => {
  closeServer();
});

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);

    // Check all required fields exist
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check labels are associated with inputs
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Check thank-you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('John');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'invalid-email',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'not-an-email',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email');
  });

  it('accepts international phone formats', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Another St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);
    expect(response.status).toBe(302);
  });

  it('accepts various postal code formats', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testCases = [
      { postal: 'SW1A 1AA', country: 'UK' },
      { postal: 'C1000', country: 'Argentina' },
      { postal: 'B1675', country: 'Argentina' },
      { postal: '12345', country: 'USA' },
    ];

    for (const testCase of testCases) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: testCase.postal,
        country: testCase.country,
        email: 'test@example.com',
        phone: '+1 234 567 8900',
      };

      const response = await request(app).post('/submit').send(formData);
      expect(response.status).toBe(302);

      // Clean up for next test
      if (fs.existsSync(dbPath)) {
        fs.unlinkSync(dbPath);
      }
    }
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'invalid-email',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('Test');
    expect($('input[name="email"]').val()).toBe('invalid-email');
  });
});
