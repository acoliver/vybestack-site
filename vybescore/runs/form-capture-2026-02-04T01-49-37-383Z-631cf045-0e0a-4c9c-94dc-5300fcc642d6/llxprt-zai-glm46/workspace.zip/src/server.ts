import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
// Templates are in src/templates - when running from dist, go up to src
// When running from src directly, use templates directly
const isDist = __dirname.endsWith('dist');
const viewsPath = isDist 
  ? path.join(__dirname, '..', 'src', 'templates')
  : path.join(__dirname, 'templates');
app.set('views', viewsPath);

// Initialize database
async function initializeDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  // Run schema to ensure table exists
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(values: FormValues): string[] {
  const errors: string[] = [];

  // Required fields
  const requiredFields: (keyof FormValues)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!values[field] || values[field].trim() === '') {
      const label = field
        .replace(/([A-Z])/g, ' $1')
        .toLowerCase()
        .trim();
      errors.push(`${label} is required`);
    }
  }

  // Email validation
  if (values.email && !validateEmail(values.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation
  if (values.phone && !validatePhone(values.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Postal code validation
  if (values.postalCode && !validatePostalCode(values.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    },
  });
});

app.post('/submit', (req, res) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(values);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', { errors, values });
    return;
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone,
    ]);

    stmt.free();
    saveDatabase();
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Get the most recent submission for personalization
  let firstName = 'friend';
  if (db) {
    const results = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    if (results.length > 0 && results[0].values.length > 0) {
      firstName = results[0].values[0][0] as string;
    }
  }

  res.render('thank-you', { firstName });
});

// Start server
const PORT = process.env.PORT || '3535';
let server: ReturnType<typeof app.listen>;

async function startServer() {
  await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  return server;
}

// Graceful shutdown
function closeServer(): void {
  if (db) {
    db.close();
    db = null;
  }
  if (server) {
    server.close(() => {
      console.log('Server closed');
    });
  }
}

// Handle SIGTERM
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  closeServer();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, closing server...');
  closeServer();
  process.exit(0);
});

// Start the server if this file is run directly
const isMainModule = import.meta.url === `file://${process.argv[1]}`;
if (isMainModule) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export for testing
export { app, startServer, closeServer, initializeDatabase };
