export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[\s()-]/g, '');
  
  const withCountryCode = /^\+?1?(\d{10})$/;
  const match = cleaned.match(withCountryCode);
  
  if (!match) {
    return false;
  }
  
  const digits = match[1];
  
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats like:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (Buenos Aires without country code)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline without country code)
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required when country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9 (cannot start with 0)
 * - Subscriber number: 6-8 digits total
 * - Allows single spaces or hyphens as separators
 * 
 * Note: When country code is present, trunk prefix 0 should NOT be included
 * (it's replaced by the country code), so +54 011... is invalid.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove only hyphens, keep spaces to validate format
  const cleaned = value.replace(/-/g, '');
  
  // Minimum length check: at least area code (2) + subscriber (6) = 8 digits
  if (cleaned.replace(/\s/g, '').length < 8) {
    return false;
  }
  
  // Check if there are multiple spaces (invalid format like "0 11 1234 5678")
  const parts = cleaned.split(/\s+/);
  if (parts.length > 4) {
    return false;
  }
  
  // Fully cleaned version for regex matching
  const fullyCleaned = cleaned.replace(/\s/g, '');
  
  // If no country code, must start with trunk prefix 0
  const withoutCountryRegex = /^0(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (fullyCleaned.startsWith('+54')) {
    const withoutCountry = fullyCleaned.substring(3);
    // After +54, we can have:
    // - Nothing (just area code): 11 1234 5678
    // - Just 9 (mobile): 9 11 1234 5678
    // But NOT 0 (trunk prefix) since country code replaces it
    const match = withoutCountry.match(/^(?:9)?([1-9]\d{1,3})(\d{6,8})$/);
    return match !== null;
  } else {
    const match = fullyCleaned.match(withoutCountryRegex);
    return match !== null;
  }
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}\p{M}'][\p{L}\p{M}'\s-]*[\p{L}\p{M}]$/u;
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers using format check and Luhn algorithm.
 * Accepts Visa (starts with 4, 13-16 digits), Mastercard (starts with 5 or 2[2-7], 16 digits),
 * and American Express (starts with 34 or 37, 15 digits).
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  const isVisa = /^4\d{12,15}$/.test(cleaned);
  const isMastercard = /^(?:5[1-5]\d{14}|2[2-7]\d{14})$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
