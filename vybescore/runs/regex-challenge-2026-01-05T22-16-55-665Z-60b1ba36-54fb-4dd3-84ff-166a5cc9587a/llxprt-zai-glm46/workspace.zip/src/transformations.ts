/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces sensibly while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  let result = text.replace(/\s+/g, ' ').trim();
  
  result = result.replace(/([.!?])\s*([a-z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  return result;
}

/**
 * Extracts all URLs from text, excluding trailing punctuation.
 * Matches http://, https://, and www-prefixed URLs.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /(https?:\/\/[^\s]+|(?:www\.)[^\s]+\.[^\s]+)/gi;
  const matches = text.matchAll(urlRegex);
  
  const results: string[] = [];
  for (const match of matches) {
    let url = match[0];
    
    while (url.length > 0 && /[.,!?;:]/.test(url.charAt(url.length - 1))) {
      url = url.slice(0, -1);
    }
    
    results.push(url);
  }
  
  return results;
}

/**
 * Replaces http:// schemes with https://.
 * Leaves existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/(https?:\/\/)/gi, '$1').replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites documentation URLs.
 * For http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  const urlRegex = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlRegex, (match, scheme, host, path = '') => {
    const newScheme = 'https://';
    const newPath = path || '';
    
    if (!newPath.startsWith('/docs/')) {
      return newScheme + host + newPath;
    }
    
    const dynamicHints = /(\?|&|=|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    if (dynamicHints.test(newPath)) {
      return newScheme + host + newPath;
    }
    
    const newHost = host.includes('.') ? 'docs.' + host.split('.').slice(-2).join('.') : 'docs.' + host;
    
    return newScheme + newHost + newPath;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
