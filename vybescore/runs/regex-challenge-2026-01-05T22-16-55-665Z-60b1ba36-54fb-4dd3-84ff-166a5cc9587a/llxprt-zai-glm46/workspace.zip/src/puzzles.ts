/**
 * Finds words starting with the given prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]+)\\b`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookbehind to ensure the token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10) {
    return false;
  }
  
  if (/\s/.test(value)) {
    return false;
  }
  
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  const symbolRegex = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/;
  if (!symbolRegex.test(value)) {
    return false;
  }
  
  for (let i = 0; i < value.length - 3; i++) {
    const len = 2;
    for (let l = len; l <= 4 && i + 2 * l <= value.length; l++) {
      const pattern = value.substring(i, i + l);
      const nextPart = value.substring(i + l, i + 2 * l);
      if (pattern === nextPart) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  const ipv6Pattern = /(?:^|[^a-fA-F0-9:])([a-fA-F0-9:]+:[a-fA-F0-9:]+)(?![a-fA-F0-9:])/;
  
  const match = value.match(ipv6Pattern);
  if (!match) {
    return false;
  }
  
  const candidate = match[1];
  
  if (candidate.includes('.')) {
    return false;
  }
  
  const validIPv6 = /^(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}$|^::$|^:(?::[a-fA-F0-9]{1,4}){1,7}$|^[a-fA-F0-9]{1,4}:(?::[a-fA-F0-9]{1,4}){1,6}$|^(?:[a-fA-F0-9]{1,4}:){1,7}:$|^(?:[a-fA-F0-9]{1,4}:){1,6}:[a-fA-F0-9]{1,4}$|^(?:[a-fA-F0-9]{1,4}:){1,5}(?::[a-fA-F0-9]{1,4}){1,2}$|^(?:[a-fA-F0-9]{1,4}:){1,4}(?::[a-fA-F0-9]{1,4}){1,3}$|^(?:[a-fA-F0-9]{1,4}:){1,3}(?::[a-fA-F0-9]{1,4}){1,4}$|^(?:[a-fA-F0-9]{1,4}:){1,2}(?::[a-fA-F0-9]{1,4}){1,5}$|^[a-fA-F0-9]{1,4}:(?::[a-fA-F0-9]{1,4}){1,6}$/;
  
  if (validIPv6.test(candidate)) {
    return true;
  }
  
  const shorthandPattern = /^([a-fA-F0-9]{1,4}:)*::([a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{0,4}$/;
  if (shorthandPattern.test(candidate)) {
    return true;
  }
  
  return false;
}
