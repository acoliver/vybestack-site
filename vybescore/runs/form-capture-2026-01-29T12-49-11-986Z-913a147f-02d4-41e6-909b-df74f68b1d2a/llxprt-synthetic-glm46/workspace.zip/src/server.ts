import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { openDatabase, closeDatabase, saveDatabase } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', async (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

interface FormSubmission {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  errors: string[];
  sanitized: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
  };
}

// Validation function
function validateForm(formData: FormSubmission): ValidationResult {
  const errors: string[] = [];
  const sanitized = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };

  // First name validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  } else {
    sanitized.firstName = formData.firstName.trim();
  }

  // Last name validation
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  } else {
    sanitized.lastName = formData.lastName.trim();
  }

  // Street address validation
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  } else {
    sanitized.streetAddress = formData.streetAddress.trim();
  }

  // City validation
  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  } else {
    sanitized.city = formData.city.trim();
  }

  // State/Province validation
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  } else {
    sanitized.stateProvince = formData.stateProvince.trim();
  }

  // Postal code validation (allow alphanumeric)
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  } else {
    sanitized.postalCode = formData.postalCode.trim();
  }

  // Country validation
  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  } else {
    sanitized.country = formData.country.trim();
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email || !emailRegex.test(formData.email)) {
    errors.push('A valid email address is required');
  } else {
    sanitized.email = formData.email.trim();
  }

  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (!formData.phone || !phoneRegex.test(formData.phone)) {
    errors.push('A valid phone number is required');
  } else {
    sanitized.phone = formData.phone.trim();
  }

  return { errors, sanitized };
}

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const db = await openDatabase();
    const { errors, sanitized } = validateForm(req.body);

    if (errors.length > 0) {
      // Re-render form with errors and submitted values
      return res.render('form', { errors, values: req.body });
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      sanitized.firstName,
      sanitized.lastName,
      sanitized.streetAddress,
      sanitized.city,
      sanitized.stateProvince,
      sanitized.postalCode,
      sanitized.country,
      sanitized.email,
      sanitized.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();

    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(sanitized.firstName)}`);
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', { 
      errors: ['An error occurred while processing your submission. Please try again.'], 
      values: req.body 
    });
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  try {
    await openDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

// Graceful shutdown
async function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);
