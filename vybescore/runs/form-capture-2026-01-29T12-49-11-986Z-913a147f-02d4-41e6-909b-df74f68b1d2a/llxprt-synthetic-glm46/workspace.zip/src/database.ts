import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js dynamically to avoid issues with ES modules
let initSqlJs: typeof import('sql.js') | null = null;

// We need to use a more flexible type for the database implementation
interface DatabaseInstance {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): StatementInstance;
  export(): Uint8Array;
  close(): void;
}

interface StatementInstance {
  run(...params: unknown[]): void;
  get(...params: unknown[]): unknown;
  all(...params: unknown[]): unknown[];
  free(): void;
}

let Database: new (data?: Uint8Array) => DatabaseInstance;

async function initializeDatabase() {
  try {
    // Use dynamic import for sql.js
    const sqlJsModule = await import('sql.js');
    initSqlJs = sqlJsModule.default || sqlJsModule;
    
    // Initialize SQL.js
    const SQL = await initSqlJs();
    Database = SQL.Database;
  } catch (error) {
    console.error('Failed to initialize sql.js:', error);
    throw error;
  }
}

const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

let db: DatabaseInstance | null = null;

export async function openDatabase(): Promise<DatabaseInstance> {
  if (db) return db;

  await initializeDatabase();

  if (!Database) {
    throw new Error('Database not initialized');
  }

  try {
    let fileBuffer = new Uint8Array(0);
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      fileBuffer = fs.readFileSync(dbPath);
    }

    // Create database instance
    db = new Database(fileBuffer);
    
    // If this is a new database, create the table
    if (fileBuffer.length === 0) {
      const schema = fs.readFileSync(
        path.join(__dirname, '..', 'db', 'schema.sql'),
        'utf8'
      );
      db.run(schema);
      saveDatabase();
    }

    return db;
  } catch (error) {
    console.error('Failed to open database:', error);
    throw error;
  }
}

export function saveDatabase(): void {
  if (!db) {
    console.error('Database not initialized');
    return;
  }

  try {
    // Ensure the data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export function getDatabaseInstance(): DatabaseInstance | null {
  return db;
}