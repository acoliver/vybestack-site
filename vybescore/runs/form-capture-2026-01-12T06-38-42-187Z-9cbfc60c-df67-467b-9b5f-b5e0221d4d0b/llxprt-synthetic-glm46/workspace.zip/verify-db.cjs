const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const dbPath = path.join(__dirname, 'data', 'submissions.sqlite');

// Check if database file exists and has data
function checkDatabaseFile() {
  console.log('Checking database file...');
  
  try {
    const stats = fs.statSync(dbPath);
    console.log(`Database file exists with size: ${stats.size} bytes`);
    
    if (stats.size > 0) {
      console.log('Database file contains data');
      return true;
    } else {
      console.log('Database file is empty');
      return false;
    }
  } catch (error) {
    console.error('Error accessing database file:', error.message);
    return false;
  }
}

// Query database to verify submissions were saved
function queryDatabase() {
  console.log('Querying database for submissions...');
  
  return new Promise((resolve, reject) => {
    // Create a new minimal server instance just to query the database
    const serverProcess = spawn('node', ['dist/server.js'], {
      stdio: ['ignore', 'pipe', 'pipe']
    });
    
    let serverReady = false;
    let submissions = [];
    
    serverProcess.stdout.on('data', (data) => {
      const output = data.toString();
      console.log('SERVER:', output.trim());
      
      if (output.includes('Server running on port') && !serverReady) {
        serverReady = true;
        console.log('Server is ready. Querying database...');
        
        // Wait a bit for server to fully start
        setTimeout(() => {
          // Create a simple test to query the database
          const server = require('./dist/server.js');
          
          // We need to manually query the database to verify persistence
          // This is a workaround to check the database content
          const dbTest = `
          const fs = require('fs');
          const path = require('path');
          const initSqlJs = require('sql.js');
          
          (async () => {
            try {
              const SQL = await initSqlJs();
              const dbPath = path.join(__dirname, 'data', 'submissions.sqlite');
              const dbData = fs.readFileSync(dbPath);
              const dbArrayBuffer = dbData.buffer.slice(dbData.byteOffset, dbData.byteOffset + dbData.byteLength);
              const db = new SQL.Database(dbArrayBuffer);
              
              const stmt = db.prepare('SELECT COUNT(*) AS count FROM submissions');
              const result = stmt.getAsObject();
              stmt.free();
              
              console.log('SUBMISSION COUNT:', result.count);
              
              if (result.count > 0) {
                const stmt2 = db.prepare('SELECT first_name, last_name, city, country FROM submissions ORDER BY created_at DESC LIMIT 5');
                let submission;
                let submissions = [];
                
                while ((submission = stmt2.getAsObject()) !== undefined) {
                  submissions.push(submission);
                }
                stmt2.free();
                
                console.log('RECENT SUBMISSIONS:', submissions);
                db.close();
                process.exit(0);
              } else {
                console.log('NO SUBMISSIONS FOUND');
                db.close();
                process.exit(1);
              }
            } catch (error) {
              console.error('QUERY ERROR:', error.message);
              process.exit(1);
            }
          })();
          `;
          
          // Write the test script
          fs.writeFileSync(path.join(__dirname, 'query-db.js'), server);
          
          // Run the test script
          const testProcess = spawn('node', [path.join(__dirname, 'query-db.js')], {
            stdio: 'inherit'
          });
          
          testProcess.on('exit', (code) => {
            if (code === 0) {
              console.log('Database persistence verified - submissions were saved');
              resolve();
            } else {
              reject(new Error('Database persistence check failed'));
            }
            
            // Clean up the script
            fs.unlinkSync(path.join(__dirname, 'query-db.js'));
            
            // Shutdown the server
            serverProcess.kill('SIGTERM');
          });
        }, 1000);
      }
    });
    
    serverProcess.stderr.on('data', (data) => {
      console.error('SERVER ERROR:', data.toString());
    });
    
    serverProcess.on('error', (error) => {
      reject(new Error(`Failed to start server for database check: ${error.message}`));
    });
    
    // Timeout if server doesn't respond
    setTimeout(() => {
      if (!serverReady) {
        reject(new Error('Server did not become ready within timeout'));
        serverProcess.kill('SIGTERM');
      }
    }, 5000);
  });
}

// Main verification function
async function verifyPersistence() {
  console.log('Verifying database persistence...');
  
  // First check if the file exists
  const hasData = checkDatabaseFile();
  
  if (!hasData) {
    console.log('Database file is empty or does not exist');
    process.exit(1);
  }
  
  // Then query the database to verify submissions
  try {
    await queryDatabase();
    console.log('Database persistence verification successful');
    process.exit(0);
  } catch (error) {
    console.error('Database persistence verification failed:', error.message);
    process.exit(1);
  }
}

// Run the verification
verifyPersistence();