const http = require('http');
const querystring = require('querystring');
const { spawn } = require('child_process');

const hostname = 'localhost';
const port = 3535;

// Start the server
const serverProcess = spawn('node', ['dist/server.js'], {
  stdio: ['ignore', 'pipe', 'pipe']
});

let serverStarted = false;

serverProcess.stdout.on('data', (data) => {
  const output = data.toString();
  console.log('SERVER:', output.trim());
  if (output.includes('Server running on port')) {
    serverStarted = true;
    console.log('Server is ready. Starting tests...');
    runTests();
  }
});

serverProcess.stderr.on('data', (data) => {
  console.error('SERVER ERROR:', data.toString());
});

// Test the form render
function testFormRender() {
  console.log('Testing form render...');
  
  return new Promise((resolve, reject) => {
    const options = {
      hostname: hostname,
      port: port,
      path: '/',
      method: 'GET'
    };
    
    const req = http.request(options, (res) => {
      console.log(`Form render - Status: ${res.statusCode}`);
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        if (res.statusCode === 200) {
          console.log('Form rendered successfully');
          if (data.includes('Friendly Contact Form')) {
            console.log('Form content verified');
            resolve();
          } else {
            reject(new Error('Form content not found'));
          }
        } else {
          reject(new Error(`Form render failed with status ${res.statusCode}`));
        }
      });
    });
    
    req.on('error', reject);
    req.end();
  });
}

// Test form submission
function testFormSubmission() {
  console.log('Testing form submission with international data...');
  
  return new Promise((resolve, reject) => {
    const postData = querystring.stringify({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    });
    
    const options = {
      hostname: hostname,
      port: port,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    const req = http.request(options, (res) => {
      console.log(`Form submission - Status: ${res.statusCode}`);
      
      if (res.statusCode === 302) {
        console.log('Form submitted and redirected successfully');
        resolve();
      } else {
        reject(new Error(`Form submission failed with status ${res.statusCode}`));
      }
    });
    
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

// Test thank you page
function testThankYouPage() {
  console.log('Testing thank you page...');
  
  return new Promise((resolve, reject) => {
    const options = {
      hostname: hostname,
      port: port,
      path: '/thank-you',
      method: 'GET'
    };
    
    const req = http.request(options, (res) => {
      console.log(`Thank you page - Status: ${res.statusCode}`);
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        if (res.statusCode === 200) {
          console.log('Thank you page rendered successfully');
          if (data.includes('Thank you')) {
            console.log('Thank you page content verified');
            resolve();
          } else {
            reject(new Error('Thank you page content not found'));
          }
        } else {
          reject(new Error(`Thank you page failed with status ${res.statusCode}`));
        }
      });
    });
    
    req.on('error', reject);
    req.end();
  });
}

// Test form validation
function testFormValidation() {
  console.log('Testing form validation...');
  
  return new Promise((resolve, reject) => {
    // Submit invalid data to trigger validation errors
    const postData = querystring.stringify({
      firstName: '', // Empty field should trigger error
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    });
    
    const options = {
      hostname: hostname,
      port: port,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    const req = http.request(options, (res) => {
      console.log(`Form validation test - Status: ${res.statusCode}`);
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        if (res.statusCode === 400 || res.statusCode === 200) {
          if (data.includes('error') || data.includes('required')) {
            console.log('Form validation working correctly');
            resolve();
          } else {
            reject(new Error('Form validation response does not contain expected errors'));
          }
        } else {
          reject(new Error(`Unexpected validation status ${res.statusCode}`));
        }
      });
    });
    
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

// Test with international phone number
function testInternationalFormat() {
  console.log('Testing with international phone and postal formats...');
  
  return new Promise((resolve, reject) => {
    const postData = querystring.stringify({
      firstName: 'Juan',
      lastName: 'Pérez',
      streetAddress: 'Av. Corrientes 1000',
      city: 'Buenos Aires',
      stateProvince: 'Capital Federal',
      postalCode: 'C1000', // Argentine postal format
      country: 'Argentina',
      email: 'juan.perez@example.com',
      phone: '+54 9 11 1234-5678' // Argentine phone format including country code
    });
    
    const options = {
      hostname: hostname,
      port: port,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    const req = http.request(options, (res) => {
      console.log(`International format test - Status: ${res.statusCode}`);
      
      if (res.statusCode === 302) {
        console.log('International formats accepted and redirected successfully');
        resolve();
      } else {
        reject(new Error(`International format test failed with status ${res.statusCode}`));
      }
    });
    
    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

// Run all tests
async function runTests() {
  try {
    await testFormRender();
    await testFormSubmission();
    await testThankYouPage();
    await testFormValidation();
    await testInternationalFormat();
    console.log('All tests passed!');
    
    // Give the server a moment to clean up
    setTimeout(() => {
      serverProcess.kill('SIGTERM');
      process.exit(0);
    }, 500);
  } catch (error) {
    console.error('Test failed:', error.message);
    serverProcess.kill('SIGTERM');
    process.exit(1);
  }
}

// Error handling
serverProcess.on('error', (error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Cleanup on exit
process.on('exit', () => {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
});

// Start server
console.log('Starting server...');