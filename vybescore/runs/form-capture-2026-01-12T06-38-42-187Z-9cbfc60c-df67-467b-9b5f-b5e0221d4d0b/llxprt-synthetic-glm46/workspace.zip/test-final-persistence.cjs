const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

console.log('Testing final database persistence...');

// Create a test script that runs after server shutdown
const verifyScript = `
import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    console.log('Verifying database persistence after server shutdown...');
    
    const SQL = await initSqlJs();
    const dbPath = path.join('data', 'submissions.sqlite');
    
    if (!fs.existsSync(dbPath)) {
      console.log('Database file does not exist');
      process.exit(1);
    }
    
    console.log('Database file found');
    
    const stats = fs.statSync(dbPath);
    console.log(\`Database file size: \${stats.size} bytes\`);
    
    const dbData = fs.readFileSync(dbPath);
    const dbArrayBuffer = dbData.buffer.slice(dbData.byteOffset, dbData.byteOffset + dbData.byteLength);
    const db = new SQL.Database(dbArrayBuffer);
    
    // Query for table information
    const masterQuery = db.exec(\`SELECT name, sql FROM sqlite_master WHERE type='table'\`);
    console.log('Tables in database:');
    if (masterQuery.length > 0 && masterQuery[0].values.length > 0) {
      masterQuery[0].values.forEach(row => {
        console.log(\`  - \${row[0]}: \${row[1] ? 'Has schema' : 'No schema found'}\`);
      });
    } else {
      console.log('  No tables found');
    }
    
    // Check specifically for submissions table
    const submissionsQuery = db.exec("SELECT sql FROM sqlite_master WHERE name='submissions'");
    if (submissionsQuery.length > 0 && submissionsQuery[0].values.length > 0) {
      console.log('Submissions table found with schema:', submissionsQuery[0].values[0][0]);
    } else {
      console.log('Submissions table not found');
    }
    
    db.close();
    process.exit(0);
  } catch (error) {
    console.error('Verification error:', error.message);
    process.exit(1);
  }
})();
`;

// Start the server, submit data, shut down, then verify
function runTest() {
  console.log('Starting server...');
  
  try {
    // Clean up any old database file
    const oldDbPath = path.join(__dirname, 'data', 'submissions.sqlite');
    if (fs.existsSync(oldDbPath)) {
      fs.unlinkSync(oldDbPath);
      console.log('Removed old database file');
    }
  } catch (e) {
    console.log('No old database file to remove');
  }
  
  const serverProcess = spawn('node', ['dist/server.js'], {
    stdio: ['ignore', 'pipe', 'pipe']
  });
  
  let serverStarted = false;
  
  serverProcess.stdout.on('data', (data) => {
    const output = data.toString();
    console.log('SERVER:', output.trim());
    
    if (output.includes('Database saved after schema init')) {
      console.log('Schema initialization and save completed');
    }
    
    if (output.includes('Server running on port') && !serverStarted) {
      serverStarted = true;
      console.log('Server ready, submitting form data...');
      
      // Submit a test form
      const http = require('http');
      const querystring = require('querystring');
      
      const postData = querystring.stringify({
        firstName: 'Maria',
        lastName: 'Gonzalez',
        streetAddress: 'Calle 123',
        city: 'Buenos Aires',
        stateProvince: 'Capital Federal',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria.gonzalez@example.com',
        phone: '+54 9 11 1234-5678'
      });
      
      const req = http.request({
        hostname: 'localhost',
        port: 3535,
        path: '/submit',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(postData)
        }
      }, (res) => {
        console.log(`Form submission response: ${res.statusCode}`);
        
        if (res.statusCode === 302) {
          console.log('Form submitted successfully, shutting down server...');
          
          // Give it a moment to save, then shut down
          setTimeout(() => {
            serverProcess.kill('SIGTERM');
            
            // Wait for server to completely shut down
            setTimeout(() => {
              // Now verify the database after shutdown
              console.log('Verifying database after shutdown...');
              
              // Write and run verification script
              const scriptPath = path.join(__dirname, 'verify-db.js');
              fs.writeFileSync(scriptPath, verifyScript);
              
              const verifyProcess = spawn('node', [scriptPath], {
                stdio: 'inherit'
              });
              
              verifyProcess.on('exit', (code) => {
                // Clean up
                fs.unlinkSync(scriptPath);
                
                if (code === 0) {
                  console.log('Final verification completed');
                  process.exit(0);
                } else {
                  console.error('Final verification failed');
                  process.exit(1);
                }
              });
            }, 1000);
          }, 1000);
        } else {
          console.error('Form submission failed');
          serverProcess.kill('SIGTERM');
          process.exit(1);
        }
      });
      
      req.on('error', (error) => {
        console.error('Submission error:', error.message);
        serverProcess.kill('SIGTERM');
        process.exit(1);
      });
      
      req.write(postData);
      req.end();
    }
  });
  
  serverProcess.stderr.on('data', (data) => {
    console.error('SERVER ERROR:', data.toString());
  });
  
  serverProcess.on('error', (error) => {
    console.error('Failed to start server:', error.message);
    process.exit(1);
  });
  
  // Timeout
  setTimeout(() => {
    console.error('Test timeout');
    serverProcess.kill('SIGTERM');
    process.exit(1);
  }, 15000);
}

runTest();