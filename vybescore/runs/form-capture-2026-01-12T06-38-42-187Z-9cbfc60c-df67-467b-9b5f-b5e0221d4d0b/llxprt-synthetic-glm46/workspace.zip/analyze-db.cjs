const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

console.log('Analyzing database behavior...');

// Create test script to see what happens during schema execution
const analyzeScript = `
import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    console.log('Starting database analysis...');
    const SQL = await initSqlJs();
    
    // Create fresh database
    const db = new SQL.Database();
    
    // Read schema
    const schemaPath = path.join('db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    console.log('Schema file content:', schema);
    console.log('---');
    
    // Execute schema
    try {
      console.log('Executing schema...');
      db.run(schema);
      console.log('Schema executed successfully');
    } catch (error) {
      console.error('Error executing schema:', error.message);
    }
    
    // Check tables
    const tables = db.exec("SELECT name FROM sqlite_master WHERE type='table'");
    console.log('Tables after schema:', tables);
    
    // Check submissions table details
    try {
      const tableInfo = db.exec("SELECT sql FROM sqlite_master WHERE name='submissions'");
      console.log('Submissions table definition:', tableInfo);
    } catch (error) {
      console.error('Error checking submissions:', error.message);
    }
    
    // Try with direct execution of just the SQL command
    console.log('Directly testing table creation...');
    try {
      db.run('CREATE TABLE IF NOT EXISTS test_table (id INTEGER)');
      const afterTest = db.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('Tables after CREATE TABLE test:', afterTest);
    } catch (error) {
      console.error('Error with CREATE TABLE:', error.message);
    }
    
    // Export and check database size
    const dbData = db.export();
    console.log('Database export size:', dbData.length, 'bytes');
    
    // Save to file
    const dbPath = path.join('data', 'test-submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(dbData));
    console.log('Test database saved to:', dbPath);
    
    // Load it back immediately
    const reloadData = fs.readFileSync(dbPath);
    const reloaded = new SQL.Database(reloadData.buffer.slice(reloadData.byteOffset, reloadData.byteOffset + reloadData.byteLength));
    
    try {
      const reloadedTables = reloaded.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('Tables in reloaded database:', reloadedTables);
    } catch (error) {
      console.error('Error checking reloaded tables:', error.message);
    }
    
    reloaded.close();
    db.close();
    
    console.log('Analysis complete');
    process.exit(0);
  } catch (error) {
    console.error('Analysis error:', error.message);
    process.exit(1);
  }
})();
`;

// Write the script
const scriptPath = path.join(__dirname, 'analyze-database.js');
fs.writeFileSync(scriptPath, analyzeScript);

// Run the script
const analyzeProcess = spawn('node', [scriptPath], {
  stdio: 'inherit'
});

analyzeProcess.on('exit', (code) => {
  fs.unlinkSync(scriptPath);
  
  if (code === 0) {
    console.log('Database analysis completed');
    
    // Check the test database that was created
    const testDbPath = path.join(__dirname, 'data', 'test-submissions.sqlite');
    if (fs.existsSync(testDbPath)) {
      console.log('Test database created successfully');
      const testDbContent = fs.readFileSync(testDbPath);
      console.log('Test database size:', testDbContent.length, 'bytes');
    }
    
    process.exit(0);
  } else {
    console.error('Database analysis failed');
    process.exit(1);
  }
});