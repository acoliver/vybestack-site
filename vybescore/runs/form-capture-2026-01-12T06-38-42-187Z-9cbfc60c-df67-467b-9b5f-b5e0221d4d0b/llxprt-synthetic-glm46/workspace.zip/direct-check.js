import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    console.log('Starting direct database check...');
    
    // Check if file exists
    const dbPath = path.join('data', 'submissions.sqlite');
    
    if (!fs.existsSync(dbPath)) {
      console.log('Database file does not exist');
      process.exit(1);
    }
    
    console.log(`Database file exists: ${dbPath}`);
    
    // Load and examine file
    const stats = fs.statSync(dbPath);
    console.log(`Database file size: ${stats.size} bytes`);
    
    // Load sql.js and open database
    const SQL = await initSqlJs();
    const dbData = fs.readFileSync(dbPath);
    const dbArrayBuffer = dbData.buffer.slice(dbData.byteOffset, dbData.byteOffset + dbData.byteLength);
    const db = new SQL.Database(dbArrayBuffer);
    
    console.log('Database opened successfully');
    
    // Test if we can run a query
    const tableQuery = "SELECT name FROM sqlite_master WHERE type='table'";
    
    try {
      const allTables = db.exec(tableQuery);
      console.log('Tables in database:', allTables);
      
      // Try to list what tables exist
      if (allTables.length > 0 && allTables[0].values.length > 0) {
        console.log('Table names:', allTables[0].values.flat());
        
        // See if submissions table exists
        const hasSubmissionsTable = allTables[0].values.flat().some((name) => name === 'submissions');
        
        if (!hasSubmissionsTable) {
          console.log('Submissions table not found. Creating it...');
          
          // Create the table
          db.run(`CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            street_address TEXT NOT NULL,
            city TEXT NOT NULL,
            state_province TEXT NOT NULL,
            postal_code TEXT NOT NULL,
            country TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
          )`);
          
          console.log('Table created successfully');
          
          // Try another query now
          const checkQuery = db.exec('SELECT COUNT(*) as count FROM sqlite_master WHERE type="table" AND name="submissions"');
          console.log('Check query result:', checkQuery);
          
          if (checkQuery.length > 0 && checkQuery[0].values.length > 0) {
            console.log('Submissions table now exists with count:', checkQuery[0].values[0]);
          }
        }
        
        // Try to check schema directly
        try {
          const schemaResult = db.exec('PRAGMA table_info(submissions)');
          console.log('Submissions table schema:', schemaResult);
        } catch (e) {
          console.log('Error getting table schema:', e.message);
        }
        
      } else {
        console.log('No tables found in database');
      }
    } catch (e) {
      console.error('Error running table query:', e.message);
    }
    
    // Try to execute test queries
    try {
      console.log('Trying a simple query...');
      const result = db.exec('SELECT 1 as test');
      console.log('Simple query result:', result);
    } catch (e) {
      console.error('Simple query failed:', e.message);
    }
    
    db.close();
    process.exit(0);
  } catch (error) {
    console.error('Error in direct check:', error.message);
    process.exit(1);
  }
})();