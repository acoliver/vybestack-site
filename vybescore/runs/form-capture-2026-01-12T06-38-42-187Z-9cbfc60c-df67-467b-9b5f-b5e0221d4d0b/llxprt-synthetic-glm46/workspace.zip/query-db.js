import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join('data', 'submissions.sqlite');
    const dbData = fs.readFileSync(dbPath);
    const dbArrayBuffer = dbData.buffer.slice(dbData.byteOffset, dbData.byteOffset + dbData.byteLength);
    const db = new SQL.Database(dbArrayBuffer);
    
    const stmt = db.prepare('SELECT COUNT(*) AS count FROM submissions');
    const result = stmt.getAsObject();
    stmt.free();
    
    console.log('SUBMISSION COUNT:', result.count);
    
    if (result.count > 0) {
      const stmt2 = db.prepare('SELECT first_name, last_name, city, country FROM submissions ORDER BY created_at DESC LIMIT 5');
      let submissions = [];
      
      for (;;) {
        const submission = stmt2.getAsObject();
        if (!submission) break;
        submissions.push(submission);
      }
      
      stmt2.free();
      
      console.log('RECENT SUBMISSIONS:', submissions);
      db.close();
      process.exit(0);
    } else {
      console.log('NO SUBMISSIONS FOUND');
      db.close();
      process.exit(1);
    }
  } catch (error) {
    console.error('QUERY ERROR:', error.message);
    process.exit(1);
  }
})();