const http = require('http');
const querystring = require('querystring');

const hostname = 'localhost';
const port = 3535;

// Test the form render
function testFormRender() {
  console.log('Testing form render...');
  
  const options = {
    hostname: hostname,
    port: port,
    path: '/',
    method: 'GET'
  };
  
  const req = http.request(options, (res) => {
    console.log(`Status: ${res.statusCode}`);
    if (res.statusCode === 200) {
      console.log('Form rendered successfully');
    }
    
    res.on('data', (data) => {
      // Just log that we received data, don't print the whole HTML
      if (data.toString().includes('Friendly Contact Form')) {
        console.log('Form content verified');
      }
    });
  });
  
  req.on('error', (e) => {
    console.error(`Problem with request: ${e.message}`);
  });
  
  req.end();
}

// Test form submission
function testFormSubmission() {
  console.log('Testing form submission...');
  
  const postData = querystring.stringify({
    firstName: 'John',
    lastName: 'Doe',
    streetAddress: '123 Main St',
    city: 'London',
    stateProvince: 'England',
    postalCode: 'SW1A 1AA',
    country: 'UK',
    email: 'john.doe@example.com',
    phone: '+44 20 7946 0958'
  });
  
  const options = {
    hostname: hostname,
    port: port,
    path: '/submit',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  const req = http.request(options, (res) => {
    console.log(`Status: ${res.statusCode}`);
    
    if (res.statusCode === 302) {
      console.log('Form submitted and redirected successfully');
    }
    
    res.on('data', (data) => {
      // We expect a redirect, so no HTML response
    });
  });
  
  req.on('error', (e) => {
    console.error(`Problem with request: ${e.message}`);
  });
  
  req.write(postData);
  req.end();
}

// Test thank you page
function testThankYouPage() {
  console.log('Testing thank you page...');
  
  const options = {
    hostname: hostname,
    port: port,
    path: '/thank-you',
    method: 'GET'
  };
  
  const req = http.request(options, (res) => {
    console.log(`Status: ${res.statusCode}`);
    if (res.statusCode === 200) {
      console.log('Thank you page rendered successfully');
    }
    
    res.on('data', (data) => {
      if (data.toString().includes('Thank you')) {
        console.log('Thank you page content verified');
      }
    });
  });
  
  req.on('error', (e) => {
    console.error(`Problem with request: ${e.message}`);
  });
  
  req.end();
}

// Wait a moment for the server to start, then run tests
setTimeout(() => {
  testFormRender();
  setTimeout(testFormSubmission, 1000);
  setTimeout(testThankYouPage, 2000);
  setTimeout(() => process.exit(0), 3000);
}, 1000);