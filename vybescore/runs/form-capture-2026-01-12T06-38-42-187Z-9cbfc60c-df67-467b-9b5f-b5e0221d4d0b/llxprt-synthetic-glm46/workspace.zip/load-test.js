import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    console.log('Testing database loading...');
    
    const SQL = await initSqlJs();
    const dbPath = path.join('data', 'submissions.sqlite');
    
    if (!fs.existsSync(dbPath)) {
      console.log('Database file does not exist');
      process.exit(1);
    }
    
    // Try different ways to create the ArrayBuffer
    console.log('Method 1: Standard Buffer approach');
    try {
      const fileData = fs.readFileSync(dbPath);
      const arrayBuffer = fileData.buffer.slice(fileData.byteOffset, fileData.byteOffset + fileData.byteLength);
      const db1 = new SQL.Database(arrayBuffer);
      const tables1 = db1.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('Method 1 tables found:', tables1.length > 0);
      if (tables1.length > 0 && tables1[0].values.length > 0) {
        console.log('Tables:', tables1[0].values.flat());
      }
      db1.close();
    } catch (e) {
      console.log('Method 1 failed:', e.message);
    }
    
    console.log('Method 2: Manual Uint8Array approach');
    try {
      const fileData = fs.readFileSync(dbPath);
      const arrayBuffer = new ArrayBuffer(fileData.length);
      const uint8Array = new Uint8Array(arrayBuffer);
      
      for (let i = 0; i < fileData.length; i++) {
        uint8Array[i] = fileData[i];
      }
      
      const db2 = new SQL.Database(arrayBuffer);
      const tables2 = db2.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('Method 2 tables found:', tables2.length > 0);
      if (tables2.length > 0 && tables2[0].values.length > 0) {
        console.log('Tables:', tables2[0].values.flat());
      }
      db2.close();
    } catch (e) {
      console.log('Method 2 failed:', e.message);
    }
    
    console.log('Method 3: File as ArrayBuffer');
    try {
      // First read and save as a new database to see if it can read its own
      const db0 = new SQL.Database();
      db0.run('CREATE TABLE test (id INTEGER)');
      db0.run('INSERT INTO test VALUES (1)');
      const exportData = db0.export();
      console.log('Export data type:', typeof exportData, 'length:', exportData.length);
      
      // Write to file
      const testPath = path.join('data', 'test-export.sqlite');
      const buffer = Buffer.from(exportData);
      fs.writeFileSync(testPath, buffer);
      
      // Try to read it back
      const readFile = fs.readFileSync(testPath);
      const newArrayBuffer = new ArrayBuffer(readFile.length);
      const newArray = new Uint8Array(newArrayBuffer);
      for (let i = 0; i < readFile.length; i++) {
        newArray[i] = readFile[i];
      }
      
      const db3 = new SQL.Database(newArrayBuffer);
      const result = db3.exec('SELECT * FROM test');
      console.log('Test data query result:', result[0].values);
      db3.close();
    } catch (e) {
      console.log('Method 3 failed:', e.message);
    }
    
    console.log('Testing complete');
    process.exit(0);
  } catch (error) {
    console.error('Test error:', error.message);
    process.exit(1);
  }
})();