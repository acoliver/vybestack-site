console.log('Testing buffer handling...');

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// Let's test the buffer saving directly
const testScript = `
import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    console.log('Testing buffer handling...');
    
    const SQL = await initSqlJs();
    const db = new SQL.Database();
    
    // Create submissions table
    db.run('CREATE TABLE IF NOT EXISTS submissions (id INTEGER PRIMARY KEY, name TEXT)');
    console.log('Table created in memory');
    
    // Insert some test data
    db.run('INSERT INTO submissions (name) VALUES (?)', ['Test User']);
    console.log('Test data inserted');
    
    // Get data as Uint8Array
    const dbData = db.export();
    console.log('Data exported as Uint8Array, length:', dbData.length, 'type:', typeof dbData);
    
    // Try Buffer.from on the Uint8Array
    const bufferData = Buffer.from(dbData);
    console.log('Converted to Buffer, length:', bufferData.length, 'type:', typeof bufferData);
    
    // Write to file
    const dbPath = path.join('data', 'buffer-test.sqlite');
    fs.writeFileSync(dbPath, bufferData);
    console.log('Written to file:', dbPath);
    
    // Load it back to verify
    const fileContent = fs.readFileSync(dbPath);
    console.log('File read back, length:', fileContent.length);
    
    // Create new buffer from the file content
    const newBuffer = Buffer.from(fileContent);
    console.log('New Buffer created, length:', newBuffer.length);
    
    // Create new array buffer for sql.js
    const newArrayBuffer = newBuffer.buffer.slice(newBuffer.byteOffset, newBuffer.byteOffset + newBuffer.byteLength);
    console.log('New array buffer created, byteLength:', newArrayBuffer.byteLength);
    
    // Create new database from saved data
    const newDb = new SQL.Database(newArrayBuffer);
    console.log('New database created from saved data');
    
    // Check if table exists now
    try {
      const tables = newDb.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('Tables found:', tables.length > 0 ? 'Yes' : 'No');
      if (tables.length > 0) {
        console.log('Table names:', tables[0].values.flat());
      }
    } catch (error) {
      console.error('Error checking tables:', error.message);
    }
    
    // Try to query the data
    try {
      const data = newDb.exec('SELECT * FROM submissions');
      console.log('Data query successful, rows:', data[0].values.length);
    } catch (error) {
      console.error('Error querying data:', error.message);
    }
    
    console.log('Buffer test completed');
    newDb.close();
    process.exit(0);
  } catch (error) {
    console.error('Buffer test error:', error.message);
    process.exit(1);
  }
})();
`;

const scriptPath = path.join(__dirname, 'buffer-test.js');
fs.writeFileSync(scriptPath, testScript);

const testProcess = spawn('node', [scriptPath], {
  stdio: 'inherit'
});

testProcess.on('exit', (code) => {
  fs.unlinkSync(scriptPath);
  
  if (code === 0) {
    console.log('Buffer test completed successfully');
    
    // Check the test file
    const testFile = path.join(__dirname, 'data', 'buffer-test.sqlite');
    if (fs.existsSync(testFile)) {
      const stats = fs.statSync(testFile);
      console.log(`Test database file size: ${stats.size} bytes`);
    }
    
    process.exit(0);
  } else {
    console.error('Buffer test failed');
    process.exit(1);
  }
});