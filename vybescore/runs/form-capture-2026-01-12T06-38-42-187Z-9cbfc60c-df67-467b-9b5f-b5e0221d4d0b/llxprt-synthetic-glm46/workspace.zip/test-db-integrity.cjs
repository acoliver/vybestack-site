const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// Start the server and submit a test form, then shut down to verify persistence
function startServerAndTest() {
  console.log('Starting server for database persistence test...');
  
  const serverProcess = spawn('node', ['dist/server.js'], {
    stdio: ['ignore', 'pipe', 'pipe']
  });
  
  let serverStarted = false;
  
  serverProcess.stdout.on('data', (data) => {
    const output = data.toString();
    console.log('SERVER:', output.trim());
    
    if (output.includes('Server running on port') && !serverStarted) {
      serverStarted = true;
      console.log('Server is ready. Submitting test data...');
      
      // Submit a test form
      const http = require('http');
      const querystring = require('querystring');
      
      const postData = querystring.stringify({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: 'T12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555 123 4567'
      });
      
      const req = http.request({
        hostname: 'localhost',
        port: 3535,
        path: '/submit',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(postData)
        }
      }, (res) => {
        console.log(`Submission response: ${res.statusCode}`);
        
        if (res.statusCode === 302) {
          console.log('Test data submitted successfully');
          
          // Wait a moment for database to be saved
          setTimeout(() => {
            // Shut down server
            serverProcess.kill('SIGTERM');
            
            // Wait for server to shut down completely
            setTimeout(() => {
              // Check database persistence
              checkDatabasePersistence();
            }, 500);
          }, 1000);
        } else {
          console.error('Submission failed');
          serverProcess.kill('SIGTERM');
          process.exit(1);
        }
      });
      
      req.on('error', (error) => {
        console.error('Submission request error:', error.message);
        serverProcess.kill('SIGTERM');
        process.exit(1);
      });
      
      req.write(postData);
      req.end();
    }
  });
  
  serverProcess.stderr.on('data', (data) => {
    console.error('SERVER ERROR:', data.toString());
  });
  
  serverProcess.on('error', (error) => {
    console.error('Failed to start server:', error.message);
    process.exit(1);
  });
  
  // Timeout in case something goes wrong
  setTimeout(() => {
    if (serverProcess) {
      serverProcess.kill('SIGTERM');
    }
    process.exit(1);
  }, 10000);
}

function checkDatabasePersistence() {
  console.log('Checking database persistence...');
  
  // Import the necessary modules
  const testScript = `
  import fs from 'fs';
  import path from 'path';
  import initSqlJs from 'sql.js';
  
  (async () => {
    try {
      const SQL = await initSqlJs();
      const dbPath = path.join('data', 'submissions.sqlite');
      
      if (!fs.existsSync(dbPath)) {
        console.log('Database file does not exist');
        process.exit(1);
      }
      
      const stats = fs.statSync(dbPath);
      console.log(\`Database file size: \${stats.size} bytes\`);
      
      const dbData = fs.readFileSync(dbPath);
      const dbArrayBuffer = dbData.buffer.slice(dbData.byteOffset, dbData.byteOffset + dbData.byteLength);
      const db = new SQL.Database(dbArrayBuffer);
      
      // Check if the table exists
      const tableCheck = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='submissions'");
      const tableResult = tableCheck.getAsObject();
      tableCheck.free();
      
      if (!tableResult) {
        console.log('Submissions table does not exist');
        db.close();
        process.exit(1);
      }
      
      // Count submissions
      const stmt = db.prepare('SELECT COUNT(*) AS count FROM submissions');
      const result = stmt.getAsObject();
      stmt.free();
      
      console.log(\`Submissions count: \${result.count}\`);
      
      if (result.count > 0) {
        const stmt2 = db.prepare('SELECT first_name, last_name, email FROM submissions ORDER BY created_at DESC LIMIT 1');
        const submission = stmt2.getAsObject();
        stmt2.free();
        
        console.log('Latest submission:', submission);
        
        if (submission.first_name === 'Test' && submission.last_name === 'User') {
          console.log('Database persistence verified - test submission found');
          db.close();
          process.exit(0);
        } else {
          console.log('Test submission not found');
          db.close();
          process.exit(1);
        }
      } else {
        console.log('No submissions found in database');
        db.close();
        process.exit(1);
      }
    } catch (error) {
      console.error('Database query error:', error.message);
      process.exit(1);
    }
  })();
  `;
  
  // Write the test script
  const scriptPath = path.join(__dirname, 'check-persistence.js');
  fs.writeFileSync(scriptPath, testScript);
  
  // Run the test script
  const checkProcess = spawn('node', [scriptPath], {
    stdio: 'inherit'
  });
  
  checkProcess.on('exit', (code) => {
    // Clean up
    fs.unlinkSync(scriptPath);
    
    if (code === 0) {
      console.log('Database persistence verification successful');
      process.exit(0);
    } else {
      console.error('Database persistence verification failed');
      process.exit(1);
    }
  });
}

// Run the test
startServerAndTest();