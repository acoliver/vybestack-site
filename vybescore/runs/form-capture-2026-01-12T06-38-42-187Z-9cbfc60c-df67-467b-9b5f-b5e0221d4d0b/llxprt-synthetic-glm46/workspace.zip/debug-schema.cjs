const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

console.log('Debugging schema initialization...');

// Schema file path
const schemaPath = path.join(__dirname, 'db', 'schema.sql');

try {
  const schema = fs.readFileSync(schemaPath, 'utf8');
  console.log('Schema content:');
  console.log(schema);
  console.log('---');
} catch (error) {
  console.error('Error reading schema:', error.message);
}

// Check database after server initialization
function startServerAndDebug() {
  console.log('Starting server to debug schema initialization...');
  
  const serverProcess = spawn('node', ['dist/server.js'], {
    stdio: ['ignore', 'pipe', 'pipe']
  });
  
  let serverStarted = false;
  
  serverProcess.stdout.on('data', (data) => {
    const output = data.toString();
    console.log('SERVER:', output.trim());
    
    // Look for specific messages
    if (output.includes('Database initialized successfully')) {
      console.log('Database initialization completed');
    }
    
    if (output.includes('Database saved successfully')) {
      console.log('Database was saved');
    }
    
    if (output.includes('Server running on port') && !serverStarted) {
      serverStarted = true;
      console.log('Server is ready. Checking database...');
      
      // Wait a moment, then shut down to check the database
      setTimeout(() => {
        serverProcess.kill('SIGTERM');
        setTimeout(() => {
          checkDatabaseAfterInit();
        }, 500);
      }, 1000);
    }
  });
  
  serverProcess.stderr.on('data', (data) => {
    console.error('SERVER ERROR:', data.toString());
  });
  
  serverProcess.on('error', (error) => {
    console.error('Failed to start server:', error.message);
    process.exit(1);
  });
  
  // Timeout
  setTimeout(() => {
    console.log('Server timeout');
    serverProcess.kill('SIGTERM');
    process.exit(1);
  }, 10000);
}

function checkDatabaseAfterInit() {
  console.log('Checking database after initialization...');
  
  // Create a script to check the database
  const checkScript = `
  import fs from 'fs';
  import path from 'path';
  import initSqlJs from 'sql.js';
  
  (async () => {
    try {
      const SQL = await initSqlJs();
      const dbPath = path.join('data', 'submissions.sqlite');
      
      if (!fs.existsSync(dbPath)) {
        console.log('Database file does not exist');
        process.exit(1);
      }
      
      const dbData = fs.readFileSync(dbPath);
      const dbArrayBuffer = dbData.buffer.slice(dbData.byteOffset, dbData.byteOffset + dbData.byteLength);
      const db = new SQL.Database(dbArrayBuffer);
      
      // List all tables
      const tablesResult = db.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('All tables:', tablesResult);
      
      // Try to check schema
      try {
        const schema = db.exec('SELECT sql FROM sqlite_master WHERE name="submissions"');
        console.log('Submissions schema:', schema);
      } catch (e) {
        console.error('Error checking submissions schema:', e.message);
      }
      
      // Try to run a direct query without needing tables
      try {
        const result = db.exec('SELECT count(*) FROM sqlite_master WHERE type="table" AND name="submissions"');
        console.log('Submission table exists check:', result);
      } catch (e) {
        console.error('Error checking if table exists:', e.message);
      }
      
      db.close();
      process.exit(0);
    } catch (error) {
      console.error('Database check error:', error.message);
      process.exit(1);
    }
  })();
  `;
  
  // Write and run the check script
  const scriptPath = path.join(__dirname, 'check-after-init.js');
  fs.writeFileSync(scriptPath, checkScript);
  
  const checkProcess = spawn('node', [scriptPath], {
    stdio: 'inherit'
  });
  
  checkProcess.on('exit', (code) => {
    fs.unlinkSync(scriptPath);
    if (code === 0) {
      console.log('Database check completed');
      process.exit(0);
    } else {
      console.error('Database check failed');
      process.exit(1);
    }
  });
}

startServerAndDebug();