declare module 'sql.js' {
  export interface DatabaseInstance {
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): StatementInstance;
  }
  
  export interface StatementInstance {
    get(): unknown;
    getAsObject(): { [key: string]: unknown };
    getAsObject(): { [key: string]: unknown };
    free(): void;
  }
  
  export class Database {
    constructor(data?: ArrayBuffer);
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): StatementInstance;
  }
  
  export function createDatabase(): DatabaseInstance;
}