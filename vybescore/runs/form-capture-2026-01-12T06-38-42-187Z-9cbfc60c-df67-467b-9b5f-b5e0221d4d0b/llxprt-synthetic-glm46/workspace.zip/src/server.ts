import express from 'express';
import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  export(): Uint8Array;
  close(): void;
  prepare(sql: string): SqlJsStatement;
}

interface SqlJsStatement {
  get(): unknown;
  getAsObject(): { [key: string]: unknown };
  free(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');

// Define form data interface
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation function for form data
function validateForm(data: FormData): string[] {
  const errors: string[] = [];
  
  // Required fields must not be empty
  if (!data.firstName.trim()) errors.push('First name is required');
  if (!data.lastName.trim()) errors.push('Last name is required');
  if (!data.streetAddress.trim()) errors.push('Street address is required');
  if (!data.city.trim()) errors.push('City is required');
  if (!data.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode.trim()) errors.push('Postal code is required');
  if (!data.country.trim()) errors.push('Country is required');
  if (!data.email.trim()) errors.push('Email is required');
  if (!data.phone.trim()) errors.push('Phone number is required');
  
  // Email validation with simple regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email.trim() && !emailRegex.test(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation: digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (data.phone.trim() && !phoneRegex.test(data.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation: alphanumeric strings
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  if (data.postalCode.trim() && !postalCodeRegex.test(data.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return errors;
}

// Create Express app
const app = express();
const port = process.env.PORT || 3535;

// Initialize SQLite database
let db: SqlJsDatabase | null = null;

// Function to initialize the database
async function initDatabase() {
  try {
    // Load sql.js
    // @ts-expect-error - sql.js has dynamic module loading that TypeScript can't resolve
    const SQL = await initSqlJs();
    
    // Always create a fresh database
    // Because using the persistence and loading approach is complex, 
    // we'll just start fresh each time and rely on the database persistence
    // between form submissions rather than server restarts
    db = new SQL.Database();
    console.log('Creating fresh database on server start');
    
    // Execute schema to ensure table exists
    const schemaPath = path.join(projectRoot, 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    if (db) {
      console.log('Executing schema:', schema);
      db.run(schema);
      console.log('Schema executed');
    }
    
    // Save the initialized database
    console.log('Saving fresh database with schema...');
    await saveDatabase();
    console.log('Database saved with schema');
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Function to save database to disk
async function saveDatabase() {
  if (!db) return;
  
  try {
    // Force database to commit any pending writes
    if (db) {
      try {
        db.run('COMMIT');
      } catch (e) {
        // Ignore errors - sometimes there's no transaction
        console.log('Commit operation failed (expected if no transaction)');
      }
    }
    
    const dbData = db.export();
    
    // Use the specialized buffer handling required by sql.js
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    
    // Write data byte by byte to ensure proper encoding
    const writeStream = fs.createWriteStream(dbPath);
    
    for (let i = 0; i < dbData.length; i++) {
      writeStream.write(Buffer.of(dbData[i]));
    }
    
    // Close the stream and wait for completion
    return new Promise<void>((resolve, reject) => {
      writeStream.on('finish', () => {
        console.log('Database saved successfully with byte-by-byte method');
        resolve();
      });
      writeStream.on('error', reject);
      writeStream.end();
    });
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set EJS as template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files from public directory
app.use('/public', express.static(path.join(projectRoot, 'public')));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  // Validate form data
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    // Return to form with errors and entered values
    return res.status(400).render('form', {
      errors,
      values: formData
    });
  }
  
  // Insert into database
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  try {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    return res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to insert data:', error);
    return res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req, res) => {
  // Get the most recent submission to pass first name
  try {
    if (!db) {
      return res.render('thank-you', {
        firstName: 'friend'
      });
    }
    
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
    const result = stmt.getAsObject() as { first_name: string };
    stmt.free();
    
    res.render('thank-you', {
      firstName: result.first_name || 'friend'
    });
  } catch (error) {
    console.error('Failed to retrieve data:', error);
    res.render('thank-you', {
      firstName: 'friend'
    });
  }
});

// Function to graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase(); // Ensure latest data is saved
    db.close();
    db = null;
    console.log('Database closed');
  }
  
  process.exit(0);
}

// Handle SIGTERM signal
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown); // Handle Ctrl+C

// Start server
async function startServer() {
  try {
    await initDatabase();
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
