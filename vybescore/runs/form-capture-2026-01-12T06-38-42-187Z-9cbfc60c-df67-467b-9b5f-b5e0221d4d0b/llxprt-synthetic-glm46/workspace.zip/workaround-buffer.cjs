console.log('Testing buffer handling workaround...');

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// Try the workaround that sql.js recommends
const testScript = `
import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

(async () => {
  try {
    console.log('Testing Buffer workaround...');
    
    const SQL = await initSqlJs();
    const db = new SQL.Database();
    
    // Create submissions table
    db.run('CREATE TABLE IF NOT EXISTS submissions (id INTEGER PRIMARY KEY, name TEXT)');
    console.log('Table created in memory');
    
    // Insert some test data
    db.run('INSERT INTO submissions (name) VALUES (?)', ['Test User'], function() {
      console.log('Test data inserted with ID:', this.lastID);
    });
    console.log('Test data inserted');
    
    // Get data as Uint8Array
    const dbData = db.export();
    console.log('Data exported as Uint8Array, length:', dbData.length);
    
    // Use the recommended workaround - create Uint8Array from Buffer then File
    const dbPath = path.join('data', 'workaround-test.sqlite');
    const writeStream = fs.createWriteStream(dbPath);
    
    // Convert each array entry to a buffer in chunks
    for (let i = 0; i < dbData.length; i++) {
      writeStream.write(Buffer.of(dbData[i]));
    }
    writeStream.end();
    
    // Wait for the write to complete
    await new Promise(resolve => writeStream.on('finish', resolve));
    console.log('Written to file byte by byte:', dbPath);
    
    // Load it back to verify - this is the critical test
    const fileContent = fs.readFileSync(dbPath);
    console.log('File read back, length:', fileContent.length);
    
    // Now, important - create a proper array buffer for sql.js
    // sql.js needs a proper ArrayBuffer, not a Buffer object
    const arrayBuffer = new ArrayBuffer(fileContent.length);
    const uint8Array = new Uint8Array(arrayBuffer);
    
    // Copy each byte into the array buffer
    for (let i = 0; i < fileContent.length; i++) {
      uint8Array[i] = fileContent[i];
    }
    
    // Create new database from saved data
    const newDb = new SQL.Database(arrayBuffer);
    console.log('New database created from saved data');
    
    // Check if table exists now
    try {
      const tables = newDb.exec("SELECT name FROM sqlite_master WHERE type='table'");
      console.log('Tables found:', tables.length > 0 ? 'Yes' : 'No');
      if (tables.length > 0) {
        console.log('Table names:', tables[0].values.flat());
      }
    } catch (error) {
      console.error('Error checking tables:', error.message);
    }
    
    // Try to query the data
    try {
      const data = newDb.exec('SELECT * FROM submissions');
      console.log('Data query successful, rows:', data[0].values.length);
      console.log('Sample data:', data[0].values[0]);
    } catch (error) {
      console.error('Error querying data:', error.message);
    }
    
    console.log('Buffer workaround test completed');
    newDb.close();
    process.exit(0);
  } catch (error) {
    console.error('Buffer workaround error:', error.message);
    process.exit(1);
  }
})();
`;

const scriptPath = path.join(__dirname, 'workaround-test.js');
fs.writeFileSync(scriptPath, testScript);

const testProcess = spawn('node', [scriptPath], {
  stdio: 'inherit'
});

testProcess.on('exit', (code) => {
  fs.unlinkSync(scriptPath);
  
  if (code === 0) {
    console.log('Buffer workaround test completed successfully');
    process.exit(0);
  } else {
    console.error('Buffer workaround test failed');
    process.exit(1);
  }
});