import { describe, expect, it } from 'vitest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // Test that the form template exists with expected structure
    const formTemplatePath = path.join(__dirname, '../../src/templates/form.ejs');
    expect(fs.existsSync(formTemplatePath)).toBe(true);
    
    const formContent = fs.readFileSync(formTemplatePath, 'utf8');
    const $ = load(formContent);
    
    // Check for required form fields
    expect($('form[method="post"]')).toHaveLength(1);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check that stylesheet reference exists
    expect($('link[href="/public/styles.css"]')).toHaveLength(1);
    
    // Check error handling mechanism
    expect(formContent).toMatch(/error-list/);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Just verify that the database schema exists and is valid
    const schemaPath = path.join(__dirname, '../../db/schema.sql');
    expect(fs.existsSync(schemaPath)).toBe(true);
    
    const schemaContent = fs.readFileSync(schemaPath, 'utf8');
    expect(schemaContent).toContain('CREATE TABLE IF NOT EXISTS submissions');
    expect(schemaContent).toContain('first_name');
    expect(schemaContent).toContain('last_name');
    
    // Verify the database directory exists
    const dataDir = path.join(__dirname, '../../data');
    expect(fs.existsSync(dataDir)).toBe(true);
  });

  it('thank you page exists', () => {
    const thankYouTemplatePath = path.join(__dirname, '../../src/templates/thank-you.ejs');
    expect(fs.existsSync(thankYouTemplatePath)).toBe(true);
    
    const thankYouContent = fs.readFileSync(thankYouTemplatePath, 'utf8');
    expect(thankYouContent).toContain('Thank you');
    
    // Check that stylesheet reference exists
    expect(thankYouContent).toContain('/public/styles.css');
    
    // Check for humorous content about data privacy
    expect(thankYouContent).toMatch(/spam|identity|stranger/i);
    
    // Verify there's a link back to the form
    expect(thankYouContent).toContain('href="/"');
  });
});
