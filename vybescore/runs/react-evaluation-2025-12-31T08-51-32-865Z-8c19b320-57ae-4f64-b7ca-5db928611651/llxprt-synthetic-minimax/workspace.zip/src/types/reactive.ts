/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T = unknown> {
  name?: string
  updateFn: UpdateFn<T>
  value?: T
}

export interface Subject<T = unknown> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  updateFn?: UpdateFn<T>
  observers: Set<Observer<unknown>>
}

// Reactive system state management
let activeObserver: Observer<unknown> | undefined = undefined
const observerSubscriptions = new Map<Observer<unknown>, Set<Subject<unknown>>>()
const subjectSubscribers = new Map<Subject<unknown>, Set<Observer<unknown>>>()

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver(observer: Observer<unknown>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value as unknown)
  } finally {
    activeObserver = previous
  }
}

export function registerDependency(observer: Observer<unknown>, subject: Subject<unknown>): void {
  // Track observer's subject dependencies
  if (!observerSubscriptions.has(observer)) {
    observerSubscriptions.set(observer, new Set())
  }
  observerSubscriptions.get(observer)!.add(subject)
  
  // Track subject's subscriber observers
  if (!subjectSubscribers.has(subject)) {
    subjectSubscribers.set(subject, new Set())
  }
  subjectSubscribers.get(subject)!.add(observer)
}

export function notifySubject(subject: Subject<unknown>): void {
  const subscribers = subjectSubscribers.get(subject)
  if (subscribers) {
    // Create a snapshot to avoid modification issues during iteration
    const subscribersCopy = new Set(subscribers)
    for (const subscriber of subscribersCopy) {
      try {
        updateObserver(subscriber as Observer<unknown>)
      } catch (error) {
        console.error('Observer notification failed:', error)
      }
    }
  }
}

export function unregisterObserver(observer: Observer<unknown>): void {
  // Clean up all subscriptions for this observer
  const subscriptions = observerSubscriptions.get(observer)
  if (subscriptions) {
    for (const subject of subscriptions) {
      const subscribers = subjectSubscribers.get(subject)
      if (subscribers) {
        subscribers.delete(observer)
        if (subscribers.size === 0) {
          subjectSubscribers.delete(subject)
        }
      }
    }
  }
  observerSubscriptions.delete(observer)
}

export function notifyAllSubjects(): void {
  // Notify all subjects (used for initialization)
  for (const subject of subjectSubscribers.keys()) {
    notifySubject(subject)
  }
}
