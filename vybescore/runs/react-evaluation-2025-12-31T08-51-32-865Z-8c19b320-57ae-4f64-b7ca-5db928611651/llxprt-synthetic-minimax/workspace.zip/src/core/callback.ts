/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver, 
  getActiveObserver,
  setActiveObserver,
  unregisterObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer = {
    value,
    updateFn: ((current) => {
      if (disposed) return current
      
      // Execute the user's callback function to perform side effects
      return updateFn(current as T)
    }) as UpdateFn<unknown>,
  }

  // Execute the callback to establish initial dependencies
  // This will trigger any reactive value access and establish dependencies
  const currentObserver = getActiveObserver()
  try {
    setActiveObserver(observer)
    updateObserver(observer)
  } finally {
    setActiveObserver(currentObserver)
  }

  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up all dependencies
    unregisterObserver(observer)
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
