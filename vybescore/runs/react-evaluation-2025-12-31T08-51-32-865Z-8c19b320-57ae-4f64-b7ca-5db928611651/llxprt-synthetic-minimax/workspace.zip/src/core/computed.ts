/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  Subject,
  EqualFn,
  registerDependency,
  notifySubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let currentValue = value

  // Create a subject to hold the computed value and manage observers
  const subject: Subject<T> = {
    name: options?.name,
    value: currentValue as T,
    observers: new Set(),
    updateFn: undefined,
    equalFn: undefined,
  }

  const observer: Observer = {
    name: options?.name,
    value: currentValue as T,
    updateFn: ((current: unknown) => {
      // Execute update function to compute new value
      const result = updateFn(current as T | undefined)
      subject.value = result
      currentValue = result
      
      return result
    }) as UpdateFn<unknown>,
  }

  const getter: GetterFn<T> = () => {
    // Set this observer as active to track dependencies during evaluation
    const previousObserver = getActiveObserver()
    let result
    
    try {
      setActiveObserver(observer)
      // Execute update function to compute new value
      result = updateFn(currentValue as T | undefined)
      
      // Check if value changed and notify dependents if needed
      if (result !== currentValue) {
        currentValue = result
        subject.value = result
        
        // Register dependencies and add to observer set
        const activeObserver = getActiveObserver()
        if (activeObserver) {
          registerDependency(activeObserver, subject as Subject<unknown>)
          subject.observers.add(activeObserver)
        }
        
        // Notify all observers that depend on this computed value
        notifySubject(subject as Subject<unknown>)
      } else {
        // Still register dependencies even when value doesn't change
        const activeObserver = getActiveObserver()
        if (activeObserver) {
          registerDependency(activeObserver, subject as Subject<unknown>)
          subject.observers.add(activeObserver)
        }
      }
      
    } finally {
      // Restore previous observer context
      setActiveObserver(previousObserver)
    }
    
    return result as T
  }

  return getter
}
