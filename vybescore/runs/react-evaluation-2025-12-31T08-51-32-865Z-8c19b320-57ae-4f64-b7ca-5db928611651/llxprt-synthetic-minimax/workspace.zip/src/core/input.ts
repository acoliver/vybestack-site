/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerDependency,
  notifySubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
    observers: new Set(),
    updateFn: () => value, // Make subject also an observer
  }

  const read: GetterFn<T> = () => {
    // Track dependencies when getter is called
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(observer, s as Subject<unknown>)
      // Also add the observer to this subject's observer set for notifications
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    
    if (shouldUpdate) {
      s.value = nextValue
      // Notify all dependent observers of the change
      notifySubject(s as Subject<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
