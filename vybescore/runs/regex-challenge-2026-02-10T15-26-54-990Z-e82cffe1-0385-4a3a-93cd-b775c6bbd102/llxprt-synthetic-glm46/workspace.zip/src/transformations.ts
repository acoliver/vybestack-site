/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted it,
 * and collapses extra spaces sensibly while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations to preserve (unused variable removed)
  
  // Split by sentence boundaries (. ? !) but not after abbreviations
  // This regex handles sentence ending followed by optional quotes/brackets
  const sentences = text.split(/(?<=[.!?])(?=\s+|$)(?![^)]*\))/).map(s => s.trim());
  
  const capitalizedSentences = sentences.map(sentence => {
    if (!sentence) return '';
    
    // Find the first alphabetic character to capitalize
    return sentence.replace(/^[^a-zA-Z]*([a-zA-Z])/, (_, firstChar) => {
      return firstChar.toUpperCase();
    });
  });
  
  // Join with single spaces and normalize multiple spaces
  let result = capitalizedSentences.join(' ');
  
  // Fix spacing after sentence boundaries - ensure exactly one space
  result = result.replace(/\s*([.!?])\s*/g, '$1 ');
  
  // Cleanup extra spaces
  result = result.replace(/\s{2,}/g, ' ').trim();
  
  return result;
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that captures http, https, and www urls
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"'`]+(?:\([^)]*\))*[^\s<>"'`.,;:!?)]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean trailing punctuation and parentheses
  return matches.map(url => {
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?)]+$/gi, '');
    
    // Balance parentheses - if we have more opening than closing, remove extra closing
    const openParens = (url.match(/\(/g) || []).length;
    const closeParens = (url.match(/\)/g) || []).length;
    
    if (closeParens > openParens) {
      // Remove extra closing parentheses from the end
      const extraCloseCount = closeParens - openParens;
      url = url.replace(new RegExp(`){${extraCloseCount}}$`), '');
    }
    
    return url;
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Find all http:// URLs and convert them to https://
  // Use negative lookahead to avoid matching https:// URLs
  return text.replace(/\bhttp:\/\/(?![s])/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs with specific transformations:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query params, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs from example.com domain
  const urlRegex = /https?:\/\/example\.com(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, path) => {
    // First, always upgrade to https
    let newUrl = match.replace(/^http:\/\//, 'https://');
    
    // Check for dynamic hints that should prevent host rewriting
    const dynamicHints = [
      /\/cgi-bin\//,
      /[?&]/,  // query string indicators
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i
    ];
    
    const hasDynamicHint = dynamicHints.some(hint => hint.test(path));
    
    // Only rewrite host for docs paths without dynamic hints
    if (!hasDynamicHint && path.startsWith('/docs/')) {
      newUrl = newUrl.replace('example.com', 'docs.example.com');
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy date strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month/day combinations (handle months with 30 days)
  const monthsWith30Days = [4, 6, 9, 11];
  if (monthsWith30Days.includes(month) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
