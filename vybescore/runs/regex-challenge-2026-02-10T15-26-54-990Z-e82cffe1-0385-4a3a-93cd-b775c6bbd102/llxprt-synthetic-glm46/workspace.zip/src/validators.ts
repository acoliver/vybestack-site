export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using a comprehensive regex.
 * Accepts typical addresses, rejects double dots, trailing dots, domain underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic validation first
  if (!emailRegex.test(value)) return false;
  
  // Additional validation for specific rules
  // No double dots anywhere
  if (value.includes('..')) return false;
  
  // No dots at the beginning or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  // TLD validation (at least 2 characters)
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;
  
  return true;
}

/**
 * Validates US phone numbers with common formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const cleanPhone = value.replace(/\D/g, '');
  
  // Check if it starts with 1 (country code) and remove it
  let phoneDigits = cleanPhone;
  if (phoneDigits.startsWith('1')) {
    phoneDigits = phoneDigits.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneDigits.length !== 10) return false;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if the original format is valid
  const validFormats = [
    /^\(\d{3}\) \d{3}-\d{4}$/, // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,    // 212-555-7890
    /^\d{10}$/,                // 2125557890
    /^1 \(\d{3}\) \d{3}-\d{4}$/, // 1 (212) 555-7890
    /^1 \d{3}-\d{3}-\d{4}$/,     // 1 212-555-7890
    /^1\d{10}$/                  // 12125557890
  ];
  
  // Handle extensions if allowed
  if (options?.allowExtensions) {
    validFormats.push(/^\d{10}x\d+$/);  // 2125557890x1234
  }
  
  return validFormats.some(format => format.test(value));
}

/**
 * Validates Argentine phone numbers including mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens)
  const cleanPhone = value.replace(/[ -]/g, '');
  
  // Argentine phone regex patterns
  // With country code: +54 9 XXXX XXXXXX or +54 XXXX XXXXXX
  // Without country code: 0 XXXX XXXXXX
  const argentinePhoneRegex = /^(\+54|0)?(9)?(\d{2,4})(\d{6,8})$/;
  
  const match = cleanPhone.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // If no country code, must start with 0 (trunk prefix)
  if (!countryCode && !cleanPhone.startsWith('0')) return false;
  
  // Area code validation: 2-4 digits, first digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and impossible names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, apostrophes, hyphens, and spaces
  // Reject digits and common symbols that shouldn't be in names
  // Name validation with Unicode support - using \p{L} for letters, \p{M} for combining marks
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional validation: reject names with digits or specific invalid patterns
  if (/\d/.test(value)) return false;
  
  // Reject names with too many consecutive special characters
  if (/['-]{2,}/.test(value)) return false;
  
  // Must contain at least one letter character
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject obviously invalid patterns (like "X Æ A-12")
  const invalidPatterns = [
    /^[Xx] [æÆ] [aA]-\d+$/  // Pattern for "X Æ A-12" style names
  ];
  
  return !invalidPatterns.some(pattern => pattern.test(value));
}

/**
 * Validates credit card numbers for major card types using format and Luhn checksum.
 * Accepts Visa, Mastercard, and American Express formats.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[ -]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanCard)) return false;
  
  // Card type validation based on prefix and length
  const visaRegex = /^4\d{12,15}$/;           // Visa: starts with 4, 13-19 digits
  const mastercardRegex = /^5[1-5]\d{14}$/;     // Mastercard: starts with 51-55, 16 digits
  const amexRegex = /^3[47]\d{13}$/;            // AmEx: starts with 34 or 37, 15 digits
  
  // Check if it matches any supported card type
  if (!visaRegex.test(cleanCard) && !mastercardRegex.test(cleanCard) && !amexRegex.test(cleanCard)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleanCard);
}

/**
 * Helper function to perform Luhn algorithm checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from rightmost digit and moving left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        doubledDigit = doubledDigit.toString().split('').reduce((acc, val) => acc + parseInt(val, 10), 0);
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
