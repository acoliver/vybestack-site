/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex pattern for words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredResults = matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
  
  // Remove duplicates while preserving order
  return Array.from(new Set(filteredResults));
}

/**
 * Returns occurrences where the token appears after a digit and not at the string start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Alternative approach without lookbehind: match digit+token and extract the digit+token
  const digitTokenRegex = new RegExp(`(\\d)(${escapedToken})`, 'g');
  const matches = [];
  let match;
  
  while ((match = digitTokenRegex.exec(text)) !== null) {
    // Check if this is not at the start of the string
    if (match.index > 0) {
      // Return the digit+token combined, not just the token
      matches.push(match[1] + match[2]);
    }
  }
  
  return Array.from(new Set(matches)); // Remove duplicates
}

/**
 * Validates passwords according to the policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_{[\]|:;"'<>?,./~`-]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (like abab) - use more specific pattern
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) return false;
  
  // Remove keyboard patterns check as it was interfering with valid passwords
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (including shorthand) - simpler approach
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*\b|\b[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*\b|\b::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*\b/g;
  
  // Extract potential IPv6 addresses
  const matches = value.match(ipv6Regex) || [];
  
  if (matches.length === 0) return false;
  
  // Check each match - ensure it's not IPv4
  for (const match of matches) {
    // IPv4 check - if it matches IPv4 pattern, skip
    const ipv4Regex = /^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
    if (!ipv4Regex.test(match)) {
      // Additional validation for IPv6 - check hex characters and colons
      if (match.includes(':') && /[0-9a-fA-F]/.test(match)) {
        return true;
      }
    }
  }
  
  return false;
}
