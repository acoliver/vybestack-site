/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const ERROR_PREFIX = 'Invalid Base64 format';

/**
 * Validate that Base64 input contains only valid characters.
 */
function validateBase64Characters(input: string): void {
  const base64Regex = /^[A-Za-z0-9+/=]+$/;
  
  if (!base64Regex.test(input)) {
    throw new Error(`${ERROR_PREFIX}: contains illegal characters`);
  }
}

/**
 * Validate Base64 padding format and position.
 */
function validateBase64Padding(input: string): void {
  const paddingIndices: number[] = [];
  for (let i = 0; i < input.length; i++) {
    if (input[i] === '=') {
      paddingIndices.push(i);
    }
  }
  
  if (paddingIndices.length === 0) {
    return;
  }
  
  const firstPaddingIndex = paddingIndices[0];
  
  // Check that padding only appears at the end
  if (firstPaddingIndex < input.length - paddingIndices.length) {
    throw new Error(`${ERROR_PREFIX}: padding in wrong position`);
  }
  
  // Check that padding length is correct (maximum 2)
  if (paddingIndices.length > 2) {
    throw new Error(`${ERROR_PREFIX}: too much padding`);
  }
  
  // Check that all padding characters are contiguous at the end
  for (let i = 0; i < paddingIndices.length; i++) {
    if (paddingIndices[i] !== firstPaddingIndex + i) {
      throw new Error(`${ERROR_PREFIX}: padding in wrong position`);
    }
  }
}

/**
 * Auto-pad Base64 strings to make them a multiple of 4 characters.
 */
function autoPadBase64(input: string): string {
  // Remove padding if it exists to avoid double padding
  const withoutPadding = input.replace(/=+$/, '');
  // Calculate how many padding characters are needed
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  return input + '='.repeat(paddingLength);
}

/**
 * Validate Base64 input format and reject clearly invalid payloads.
 * Accepts Base64 strings with or without padding.
 */
function validateBase64(input: string): string {
  if (!input) {
    throw new Error(`${ERROR_PREFIX}: empty input`);
  }
  
  validateBase64Characters(input);
  
  // Check for clearly invalid structure: padding in the middle of string
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && paddingIndex < input.length - 2) {
    throw new Error(`${ERROR_PREFIX}: padding in wrong position`);
  }
  
  // Auto-pad the input for processing if it doesn't have padding
  let processedInput = input;
  if (input.length % 4 !== 0) {
    // Only auto-pad if there's no existing padding
    if (!input.includes('=')) {
      processedInput = autoPadBase64(input);
      // Validate the padded result
      validateBase64Padding(processedInput);
    } else {
      // If there's padding but length is not multiple of 4, it's invalid
      throw new Error(`${ERROR_PREFIX}: incorrect string length`);
    }
  } else {
    validateBase64Padding(input);
  }
  
  return processedInput;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  try {
    const processedInput = validateBase64(input);
    return Buffer.from(processedInput, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes(ERROR_PREFIX)) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
