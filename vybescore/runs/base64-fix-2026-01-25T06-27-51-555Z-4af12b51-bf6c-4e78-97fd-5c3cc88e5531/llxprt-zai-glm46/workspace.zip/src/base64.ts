/**
 * Validate Base64 input string.
 * Checks for valid Base64 characters and proper structure.
 */
function validateBase64(input: string): void {
  // Remove whitespace for validation
  const trimmed = input.trim();
  
  // Empty input is invalid
  if (trimmed.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, =)
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /
  // Padding: = (only at the end)
  const validPattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validPattern.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check that padding only appears at the end and is properly formatted
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Everything after the first '=' must be '='
    const afterPadding = trimmed.slice(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: malformed padding');
    }
    
    // Padding can only be 1 or 2 characters
    if (afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: invalid padding length');
    }
  }
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original string.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  validateBase64(input);

  try {
    const buffer = Buffer.from(input.trim(), 'base64');
    
    // If the resulting buffer is empty but input wasn't just padding, it's invalid
    if (buffer.length === 0 && input.trim().length > 0) {
      throw new Error('Invalid Base64 input: no data decoded');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
