import { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Mapping of format names to their respective renderer functions.
 */
export const formatters: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Validates if a format is supported.
 */
export function isSupportedFormat(format: string): format is keyof typeof formatters {
  return format in formatters;
}