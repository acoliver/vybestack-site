#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { ReportData, ReportFormat, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

const parseArgs = (args: string[]): CliArgs => {
  if (args.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  let format: ReportFormat = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format' && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      format = formatValue as ReportFormat;
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
};

const validateReportData = (data: unknown): ReportData => {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const dataObj = data as Record<string, unknown>;

  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "title" field');
  }

  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "summary" field');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid report data: Missing or invalid "entries" field');
  }

  const entries = dataObj.entries.map((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: Expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: Missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: Missing or invalid "amount" field`);
    }

    return {
      label: (entry as { label: string }).label,
      amount: (entry as { amount: number }).amount,
    };
  });

  return {
    title: dataObj.title,
    summary: dataObj.summary,
    entries,
  };
};

const getRenderer = (format: ReportFormat): ReportRenderer => {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
};

const main = (): void => {
  try {
    const args = parseArgs(process.argv);
    
    const dataPath = path.resolve(args.dataFile);
    
    if (!fs.existsSync(dataPath)) {
      console.error(`Error: File not found: ${args.dataFile}`);
      process.exit(1);
    }

    const dataContent = fs.readFileSync(dataPath, 'utf8');
    
    let jsonData;
    try {
      jsonData = JSON.parse(dataContent);
    } catch (parseError) {
      console.error(`Error: Invalid JSON in file ${args.dataFile}: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
      process.exit(1);
    }

    const reportData: ReportData = validateReportData(jsonData);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    const renderer = getRenderer(args.format);
    const output = renderer.render(reportData, options);

    if (args.outputPath) {
      const outputPath = path.resolve(args.outputPath);
      fs.writeFileSync(outputPath, output);
      console.log(`Report written to: ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
};

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
