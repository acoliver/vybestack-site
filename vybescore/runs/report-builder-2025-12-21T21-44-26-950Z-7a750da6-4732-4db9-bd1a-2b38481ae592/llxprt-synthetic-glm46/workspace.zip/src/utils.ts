import { ReportData, type ReportOptions } from './types.js';

export type { ReportOptions };

/**
 * Validates the structure of report data.
 */
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "title"');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "summary"');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: Missing or invalid "entries"');
  }

  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: Expected an object');
    }

    const entryObj = entry as Record<string, unknown>;
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: Missing or invalid "label"');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: Missing or invalid "amount"');
    }
  }

  return data as ReportData;
}

/**
 * Formats a numeric amount as currency with two decimal places.
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total of all entry amounts.
 */
export function calculateTotal(data: ReportData): number {
  return data.entries.reduce((total, entry) => total + entry.amount, 0);
}