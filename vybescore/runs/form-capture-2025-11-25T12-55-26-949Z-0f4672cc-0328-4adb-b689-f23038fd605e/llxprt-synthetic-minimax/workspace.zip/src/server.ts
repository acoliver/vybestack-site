import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import * as pathModule from 'path';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Initialize SQL.js
let db: Database | null = null;

// Database initialization
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => {
      return pathModule.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file);
    }
  });

  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  
  try {
    if (fs.existsSync(dbPath)) {
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
    } else {
      db = new SQL.Database();
      
      // Read and execute schema
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf-8');
      db.exec(schema);
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

// Save database to file
function saveDatabase(): void {
  if (db !== null) {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const binary = db.export();
    fs.writeFileSync(dbPath, binary);
  }
}

// Close database on shutdown
function closeDatabase(): void {
  if (db !== null) {
    db.close();
    db = null;
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

// Validation function
function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
    }
  }

  // Email validation
  if (data.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }

  // Phone validation
  if (data.phone) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode) {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }
  }

  return errors;
}

// GET route for the form
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    formData: {} as FormData,
    title: 'Contact Us - Definitely Not A Scam'
  });
});

// POST route for form submission
app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Re-render form with errors and previously entered values
    res.status(400).render('form', {
      errors,
      formData,
      title: 'Contact Us - Please Fix Errors'
    });
    return;
  }

  // Insert into database
  try {
    if (db === null) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();
  } catch (error) {
    console.error('Error saving to database:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general' as keyof FormData, message: 'Internal server error. Please try again.' }],
      formData,
      title: 'Contact Us - Error'
    });
    return;
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

// GET route for thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    title: 'Thank You! - We Definitely Won\'t Spam You (Probably)',
    subtitle: 'Your information has been... safely stored'
  });
});

// Start server
async function startServer(): Promise<void> {
  await initDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Form available at http://localhost:${PORT}/`);
    console.log(`Thank you page at http://localhost:${PORT}/thank-you`);
  });
}

// Start the server
startServer().catch(console.error);

export default app;