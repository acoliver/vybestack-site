#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { basename } from 'node:path';
import { ReportData, RenderOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script path
  const argsList = argv.slice(2);
  
  let i = 0;
  while (i < argsList.length) {
    const arg = argsList[i];
    
    if (arg === '--format') {
      if (i + 1 >= argsList.length) {
        throw new Error('--format requires a value');
      }
      args.format = argsList[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= argsList.length) {
        throw new Error('--output requires a value');
      }
      args.output = argsList[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
      i += 1;
    } else if (!arg.startsWith('--')) {
      // Positional argument - data file
      args.dataFile = arg;
      i += 1;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  // Validate required arguments
  if (!args.dataFile) {
    throw new Error('Missing required argument: data file');
  }
  
  if (!args.format) {
    throw new Error('Missing required option: --format <format>');
  }

  return args;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label must be a string`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}].amount must be a number`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      }
      if (error.message.includes('JSON.parse')) {
        throw new Error(`Invalid JSON in file: ${filePath}`);
      }
      throw error;
    }
    throw new Error(`Failed to load data file: ${filePath}`);
  }
}

function getFormatter(format: string) {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  try {
    const args = parseArguments(process.argv);
    const data = loadReportData(args.dataFile);
    const formatter = getFormatter(args.format);
    
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    const rendered = formatter.format(data, options);
    
    if (args.output) {
      writeFileSync(args.output, rendered, 'utf-8');
    } else {
      process.stdout.write(rendered);
    }
    
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    const programName = basename(process.argv[1] || 'report');
    
    console.error(`${programName}: ${message}`);
    process.exit(1);
  }
}

main();
