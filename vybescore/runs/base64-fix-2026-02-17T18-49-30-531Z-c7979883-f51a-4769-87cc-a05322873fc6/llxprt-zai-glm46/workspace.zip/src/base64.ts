/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding).
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  try {
    // Remove any whitespace from the input
    const normalized = input.replace(/\s/g, '');
    
    // Check if the input is valid Base64 by attempting to decode it
    // Base64 should only contain A-Z, a-z, 0-9, +, /, and = (for padding)
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
      throw new Error('Invalid Base64 input: contains illegal characters');
    }
    
    // Attempt to decode
    const buffer = Buffer.from(normalized, 'base64');
    
    // If the buffer is empty and input wasn't just padding, it's likely invalid
    if (buffer.length === 0 && normalized.length > 0 && !/^=+$/.test(normalized)) {
      throw new Error('Invalid Base64 input: unable to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
