import { ReportData, FormatOptions } from '../types.js';

export function renderText(data: ReportData, options: FormatOptions): string {
  let output = '';

  // Add title
  output += `${data.title}\n\n`;

  // Add summary
  output += `${data.summary}\n\n`;

  // Add entries section
  output += `Entries:\n\n`;

  // Add each entry
  for (const entry of data.entries) {
    const formattedAmount = formatAmount(entry.amount);
    output += `- ${entry.label}: $${formattedAmount}\n`;
  }

  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = formatAmount(total);
    output += `\nTotal: $${formattedTotal}\n`;
  }

  return output;
}

function formatAmount(amount: number): string {
  return amount.toFixed(2);
}