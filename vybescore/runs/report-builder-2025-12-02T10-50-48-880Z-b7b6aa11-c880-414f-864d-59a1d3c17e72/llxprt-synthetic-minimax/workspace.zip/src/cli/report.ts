import { readFileSync, writeFileSync } from 'fs';
import { ReportData, FormatOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  let format: FormatType | undefined;
  let output: string | undefined;
  let includeTotals = false;

  // Parse flags
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      format = argv[i + 1] as FormatType;
      if (!format) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output') {
      output = argv[i + 1];
      if (!output) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      i++; // Skip next argument as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  // Validate format
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return { dataFile, format, output, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: "title" must be a string');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: "summary" must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: "entries" must be an array');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: "label" must be a string`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: "amount" must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}`);
      process.exit(1);
    }
    
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    
    console.error(`Error: Failed to read file ${filePath}`);
    process.exit(1);
  }
}

function getFormatter(format: FormatType) {
  const formatters = {
    markdown: renderMarkdown,
    text: renderText
  };
  
  return formatters[format];
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write to file ${outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = loadReportData(args.dataFile);
  const formatter = getFormatter(args.format);
  const options: FormatOptions = { includeTotals: args.includeTotals };
  
  const output = formatter(data, options);
  writeOutput(output, args.output);
}

main();