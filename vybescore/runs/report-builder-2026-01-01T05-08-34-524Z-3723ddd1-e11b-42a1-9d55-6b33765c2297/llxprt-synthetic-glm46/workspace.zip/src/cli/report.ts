#!/usr/bin/env node

import fs from "node:fs";
import type { ReportData, ReportFormat, ReportOptions } from "../types.js";
import { renderMarkdown } from "../formats/markdown.js";
import { renderText } from "../formats/text.js";

function parseArgs(argv: string[]): {
  dataPath: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = argv.slice(2); // Skip node and script name

  if (args.length < 3) {
    console.error(
      "Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]"
    );
    process.exit(1);
  }

  const dataPath = args[0];
  const formatIndex = args.indexOf("--format");
  const format = args[formatIndex + 1] as ReportFormat;
  const outputIndex = args.indexOf("--output");
  const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes("--includeTotals");

  if (!dataPath || !format) {
    console.error("Missing required arguments");
    process.exit(1);
  }

  if (format !== "markdown" && format !== "text") {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== "object") {
    return false;
  }

  const reportData = data as Record<string, unknown>;

  if (
    typeof reportData.title !== "string" ||
    typeof reportData.summary !== "string" ||
    !Array.isArray(reportData.entries)
  ) {
    return false;
  }

  for (const entry of reportData.entries) {
    if (
      !entry ||
      typeof entry !== "object" ||
      typeof (entry as Record<string, unknown>).label !== "string" ||
      typeof (entry as Record<string, unknown>).amount !== "number"
    ) {
      return false;
    }
  }

  return true;
}

async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs(process.argv);

    // Read and parse JSON data
    let data: unknown;
    try {
      const fileContent = await fs.promises.readFile(dataPath, "utf-8");
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading file "${dataPath}":`);
      if (error instanceof Error && "code" in error) {
        const nodeError = error as { code?: string };
        if (nodeError.code === "ENOENT") {
          console.error("File not found");
        } else if (nodeError.code === "EACCES") {
          console.error("Permission denied");
        } else {
          console.error("Unable to read file");
        }
      } else {
        console.error("Unable to read file");
      }
      process.exit(1);
    }

    // Validate data structure
    if (!validateReportData(data)) {
      console.error("Invalid report data structure. Expected format:");
      console.error('{ title: string, summary: string, entries: { label: string, amount: number }[] }');
      process.exit(1);
    }

    // Select formatter
    const formatters: Record<string, (data: ReportData, options?: ReportOptions) => string> = {
      markdown: renderMarkdown,
      text: renderText,
    };

    const formatter = formatters[format];

    if (!formatter) {
      console.error(`Internal error: No formatter for format "${format}"`);
      process.exit(1);
    }

    // Render report
    const options: ReportOptions = { includeTotals };
    const output = formatter(data, options);

    // Write output
    if (outputPath) {
      await fs.promises.writeFile(outputPath, output);
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error("Unexpected error:");
    if (error instanceof Error) {
      console.error(error.message);
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
