/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapeRegex(prefix)}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern);
  if (!matches) return [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find complete token occurrences that follow a digit (digit + token)
  // Pattern: any digit followed by token, excluding occurrences at string start
  const fullPattern = new RegExp(`(?<!^)\\d${escapeRegex(token)}`, 'g');
  
  const matches = text.match(fullPattern);
  if (!matches) return [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one of each: uppercase, lowercase, digit, symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[^A-Za-z0-9\s]/.test(value); // Any non-alphanumeric character
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (e.g., "abab" should fail)
  // Pattern to detect repeated 2-character or longer sequences
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes shorthand notation (::)
  // Must exclude IPv4 addresses (which contain only digits and dots)
  
  // First, check if this looks like an IPv4 address
  if (value.match(/^\d{1,3}(\.\d{1,3}){3}$/)) {
    return false; // IPv4 addresses should not match
  }
  
  // Check for IPv6 patterns within the string (not anchored to start/end)
  const ipv6Pattern = /[0-9a-fA-F:]+(?=\s|$|,|\]|\})/;
  
  // If there's what looks like an IPv6 address
  if (ipv6Pattern.test(value)) {
    // Extract candidate IPv6 portions
    const ipv6Candidates = value.match(/[0-9a-fA-F:]+/g) || [];
    
    for (const candidate of ipv6Candidates) {
      // Skip pure digit candidates (likely IPv4)
      if (/^\d+$/.test(candidate)) continue;
      
      // Check if this looks like an IPv6 address
      if (candidate.includes(':') && 
          (candidate.includes('::') || 
           candidate.split(':').length >= 2 ||
           candidate.split(':').length <= 8)) {
        return true;
      }
    }
  }
  
  return false;
}

function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
