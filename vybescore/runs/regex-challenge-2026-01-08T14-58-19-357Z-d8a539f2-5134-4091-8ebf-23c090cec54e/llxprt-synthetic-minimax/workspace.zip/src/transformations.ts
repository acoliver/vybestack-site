/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first letter of the string if it's a letter
  let result = text;
  
  // First, capitalize the very first letter if it's lowercase
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Pattern to match sentence boundaries (.?!)
  // This regex finds sentence endings followed by spaces (if any) and lowercase letters
  const sentencePattern = /([.!?])(\s*)([a-z])/g;
  
  return result.replace(sentencePattern, (match, punctuation, spaces, letter) => {
    // Keep the punctuation and original spacing
    // Capitalize the letter following the punctuation
    return punctuation + spaces + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https URLs
  // More comprehensive pattern to capture the full URL
  const urlPattern = /\bhttps?:\/\/[^\s"'<>()]*/gi;
  
  const matches = text.match(urlPattern);
  if (!matches) return [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  // Use word boundaries to avoid matching partial URLs
  const httpPattern = /\bhttp:\/\//gi;
  
  return text.replace(httpPattern, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlPattern = /\bhttp:\/\/[^\s,]+/gi;
  
  return text.replace(httpUrlPattern, (url) => {
    // Parse the URL to check if it's from example.com and has /docs/ path
    try {
      // For URLs starting with http://
      const urlObj = new URL(url);
      
      // Always upgrade to https
      let rewrittenUrl = 'https://';
      
      // Check for dynamic hints or extensions that should skip host rewrite
      const hasDynamicHints = urlObj.pathname.includes('cgi-bin') || 
                               urlObj.search.includes('?') ||
                               urlObj.search.includes('&') ||
                               urlObj.search.includes('=') ||
                               urlObj.pathname.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i);
      
      if (!hasDynamicHints && urlObj.pathname.startsWith('/docs/')) {
        // Rewrite host to docs.example.com for /docs/ paths
        rewrittenUrl += 'docs.example.com';
      } else {
        // Use the original host
        rewrittenUrl += urlObj.host;
      }
      
      // Preserve the path
      rewrittenUrl += urlObj.pathname;
      
      // Preserve query string if any
      if (urlObj.search) {
        rewrittenUrl += urlObj.search;
      }
      
      // Preserve hash if any
      if (urlObj.hash) {
        rewrittenUrl += urlObj.hash;
      }
      
      return rewrittenUrl;
    } catch {
      // If URL parsing fails, just upgrade scheme
      return url.replace(/^http:\/\//, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February (not checking leap year)
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
