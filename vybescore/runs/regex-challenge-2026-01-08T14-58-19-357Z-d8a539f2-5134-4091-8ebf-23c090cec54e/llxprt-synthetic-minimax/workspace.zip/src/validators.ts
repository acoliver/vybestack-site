
/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Robust email validation
  // Accept typical addresses like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Additional validation checks
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots anywhere
  if (value.includes('..')) return false;
  
  // Reject domain with underscores
  if (value.includes('_@')) return false;
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  // Reject trailing dots in domain
  if (domain && domain.endsWith('.')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional leading +
  const hasPlus = cleaned.startsWith('+');
  const phoneNumber = hasPlus ? cleaned.slice(1) : cleaned;
  
  // Must be 10 digits for US numbers (excluding country code)
  if (hasPlus && phoneNumber.length === 11 && phoneNumber.startsWith('1')) {
    // +1 followed by 10 digits
    const tenDigits = phoneNumber.slice(1);
    if (tenDigits.length === 10) {
      // Area code cannot start with 0 or 1
      return tenDigits.length === 10 && tenDigits[0] !== '0' && tenDigits[0] !== '1';
    }
  } else if (!hasPlus && phoneNumber.length === 10) {
    // Plain 10 digits
    // Area code cannot start with 0 or 1
    return phoneNumber.length === 10 && phoneNumber[0] !== '0' && phoneNumber[0] !== '1';
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and punctuation, keep only digits, +, and -
  const cleaned = value.replace(/[^\d+ -]/g, '');
  
  // Remove spaces and hyphens
  const digitsOnly = cleaned.replace(/[ -]/g, '');
  
  // Check for country code
  if (digitsOnly.startsWith('+54')) {
    // +54 format
    const rest = digitsOnly.slice(3);
    return validateArgentineNumber(rest);
  } else if (digitsOnly.startsWith('0')) {
    // Local format starting with trunk prefix
    return validateArgentineNumber(digitsOnly);
  }
  
  return false;
}

function validateArgentineNumber(rest: string): boolean {
  if (rest.length === 0) return false;
  
  let remaining = rest;
  
  // Check for mobile indicator '9'
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Must have area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = remaining.match(/^[1-9]\d{1,3}/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[0];
  remaining = remaining.slice(areaCode.length);
  
  // Check for subscriber number (6-8 total remaining digits)
  if (remaining.length < 6 || remaining.length > 8) return false;
  if (!remaining.match(/^\d{6,8}$/)) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), spaces, apostrophes, hyphens
  // Reject digits, symbols, and names like "X Æ A-12"
  // Must be at least 2 characters and not start/end with space
  if (value.length < 2) return false;
  if (value.trim() !== value) return false; // No leading/trailing spaces
  
  // Pattern: unicode letters, spaces, apostrophes, hyphens
  // Reject anything with digits or symbols
  const namePattern = /^[\p{L}][\p{L} '\x2D]*[\p{L}]$/u;
  return namePattern.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check for valid card type prefixes
  const firstDigit = cleaned[0];
  const firstTwo = parseInt(cleaned.slice(0, 2));
  const firstFour = parseInt(cleaned.slice(0, 4));
  
  let isValidCardType = false;
  
  // Visa: starts with 4, length 13, 16, 19
  if (firstDigit === '4' && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValidCardType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((firstTwo >= 51 && firstTwo <= 55) || (firstFour >= 2221 && firstFour <= 2720)) {
    isValidCardType = cleaned.length === 16;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((firstTwo === 34 || firstTwo === 37) && cleaned.length === 15) {
    isValidCardType = true;
  }
  
  if (!isValidCardType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
