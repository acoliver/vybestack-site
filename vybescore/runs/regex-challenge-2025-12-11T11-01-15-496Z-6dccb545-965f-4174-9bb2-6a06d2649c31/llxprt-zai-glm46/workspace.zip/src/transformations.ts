/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Split by sentence endings (., ?, !) and process
  return normalized.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  }).replace(/^[a-z]/, (letter) => letter.toUpperCase());
}

/**
 * Extracts URLs from the given text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/(?:[-\w.])+(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g, (url) => {
    // Always upgrade to https
    const rewrittenUrl = url.replace(/^http:/, 'https:');
    
    // Parse URL components
    const urlMatch = rewrittenUrl.match(/^https?:\/\/([^\/]+)(\/.*)?$/);
    if (!urlMatch) return rewrittenUrl;
    
    const [, host, path = ''] = urlMatch;
    
    // Skip host rewrite for dynamic content
    const dynamicPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/
    ];
    
    const isDynamic = dynamicPatterns.some(pattern => pattern.test(path));
    
    // Rewrite docs.example.com when path starts with /docs/ and not dynamic
    if (!isDynamic && path.startsWith('/docs/')) {
      return rewrittenUrl.replace(host, `docs.${host}`);
    }
    
    return rewrittenUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle February leap years (simplified - doesn't account for all edge cases)
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  if (monthNum === 2 && (isLeapYear ? dayNum > 29 : dayNum > 28)) {
    return 'N/A';
  }
  
  if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}