export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using comprehensive regex.
 * Supports typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional validation for common issues
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject leading or trailing dots in local or domain parts
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  const withCountryCode = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned;
  
  // Check if we have exactly 10 digits
  if (withCountryCode.length !== 10) return false;
  
  // Validate area code (first 3 digits) - can't start with 0 or 1
  if (withCountryCode[0] === '0' || withCountryCode[0] === '1') return false;
  
  // Check if the original format matches one of the supported patterns
  const usPhoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[-\s]?)?\d{3}[-\s]?\d{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  const argentinePhoneRegex = /^(?:\+54)?(?:0?)(?:9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = argentinePhoneRegex.exec(cleaned);
  if (!match) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[A-Za-z\u00C0-\u024F'-\s]+$/;
  
  // Basic format check
  if (!nameRegex.test(value)) return false;
  
  // Reject names with only special characters or spaces
  const lettersOnly = value.replace(/[A-Za-z\u00C0-\u024F]/g, '');
  if (lettersOnly.trim().length > 0 && /^['-\s]+$/.test(lettersOnly)) {
    // Check if there are actually letters present
    const hasLetters = /[A-Za-z\u00C0-\u024F]/.test(value);
    if (!hasLetters) return false;
  }
  
  // Reject obviously problematic patterns
  if (/\d/.test(value)) return false;
  if (/[^A-Za-z\u00C0-\u024F'-\s]/.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Accepts appropriate prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55, 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check Visa
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  if (visaRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Check Mastercard (51-55, 2221-2720)
  const mastercardRegex = /^(?:5[1-5]\d{14})|(?:2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12})$/;
  if (mastercardRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Check AmEx
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  return false;
}