/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 * Uses word boundaries to match whole words only.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern for words starting with prefix
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => word.toLowerCase() === exception.toLowerCase())
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validates passwords according to the specified policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=\[\]{};':"\\|,.<>\/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // Look for patterns of 2+ characters that repeat immediately
  const repeatedPattern = /(.+?)\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 * Returns true if IPv6 is detected, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude obvious IPv4 patterns
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 patterns including shorthand (::)
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 4 hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with :: (compressed zeros)
    /\b(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with leading :: or trailing ::
    /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b/,
    // IPv4-mapped IPv6
    /\b(?:[0-9a-fA-F]{1,4}:){5,6}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  return ipv6Patterns.some(pattern => pattern.test(value));
}