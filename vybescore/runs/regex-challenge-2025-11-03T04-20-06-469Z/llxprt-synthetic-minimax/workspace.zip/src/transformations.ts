/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Pattern to match sentence boundaries followed by optional whitespace
  // Capitalize first character after sentence end (.?!)
  return normalized.replace(/([.!?])(\s*\S)/g, (match, punctuation, nextChar) => {
    return punctuation + nextChar.toUpperCase();
  }).replace(/^(\s*\S)/, (match, firstChar) => {
    return firstChar.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s.,;!?)]+[^\s.,;!?)]*/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?)]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)/g;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    const isDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    // Always upgrade to https
    let newUrl = 'https://';
    
    if (isDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.' + host + path;
    } else {
      // Keep original host, just upgrade scheme
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}