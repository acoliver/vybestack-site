/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // Word boundary ensures we match whole words
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => lowerMatch === exception.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use negative lookbehind to ensure it's not at the start
  // Use positive lookbehind to ensure it follows a digit
  const pattern = new RegExp(`(?<!^)(?<=\\d)${token}`, 'g');
  const matches = text.match(new RegExp(token, 'g')) || [];
  
  // Now filter to only include those that follow a digit and not at start
  const result: string[] = [];
  const regex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'g');
  let match;
  while ((match = regex.exec(text)) !== null) {
    result.push(match[0]);
  }
  
  return result;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like abab
  // Check for any 2-character sequence repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    const seq = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === seq) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses can be in various formats:
  // - Full: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shortened with :: : 2001:db8::1
  // - IPv4-mapped: ::ffff:192.0.2.1
  
  // First, check if there's an IPv4 pattern (to exclude)
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern:
  // - Contains colons
  // - Hex digits (0-9, a-f, A-F) separated by colons
  // - May use :: for zero compression
  // - 8 groups max, or less with ::
  
  // Pattern that matches IPv6 including ::
  const ipv6Pattern = /(^|[^a-fA-F0-9:])([a-fA-F0-9:]+:+)+[a-fA-F0-9]+(?![a-fA-F0-9:])/;
  
  // Also match the :: shorthand pattern
  const doubleColonPattern = /(^|[^a-fA-F0-9:])([a-fA-F0-9:]*::[a-fA-F0-9:]*)/;
  
  return ipv6Pattern.test(value) || doubleColonPattern.test(value);
}