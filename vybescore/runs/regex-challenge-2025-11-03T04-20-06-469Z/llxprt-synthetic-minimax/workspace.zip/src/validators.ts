export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to validate credit card using Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\s+/g, '');
  
  if (!/^\d+$/.test(digits)) {
    return false;
  }

  let sum = 0;
  let shouldDouble = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove extra spaces
  const email = value.trim();
  
  // Basic structure check
  // Local part: alphanumeric, dots, underscores, plus signs, hyphens
  // Domain: alphanumeric, dots, hyphens (no underscores)
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // Check for double dots
  if (email.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  const parts = email.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const localPart = parts[0];
  const domainPart = parts[1];
  
  // Local part can't start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain part can't start or end with dot
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  const phone = value.trim();
  
  // Remove all non-digit characters temporarily to check length
  const digits = phone.replace(/\D/g, '');
  
  // Must have 10 or 11 digits (11 if starts with 1)
  if (digits.length !== 10 && !(digits.length === 11 && digits.startsWith('1'))) {
    return false;
  }
  
  // Area code (first 3 digits) can't start with 0 or 1
  const areaCodeStart = digits.length === 10 ? 0 : 1;
  const areaCode = digits.substring(areaCodeStart, areaCodeStart + 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Match various US phone formats
  const phoneRegex = /^(\+1[\s.-]?)?(\(?[2-9]\d{2}\)?[\s.-]?[2-9]\d{2}[\s.-]?\d{4})$/;
  
  if (!phoneRegex.test(phone)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const phone = value.trim();
  
  // Remove all separators (spaces and hyphens)
  const cleanPhone = phone.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // Optional +54 (country code)
  // Optional 0 (trunk prefix)
  // Optional 9 (mobile indicator, only if country code present)
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits total
  
  const arPhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanPhone.match(arPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const countryCode = match[1] || '';
  const trunkPrefix = match[2] || '';
  const mobileIndicator = match[3] || '';
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // When country code is omitted, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // If mobile indicator present, must have country code
  if (mobileIndicator && !countryCode) {
    return false;
  }
  
  // Total subscriber number should be 6-8 digits
  const subscriberLength = subscriberNumber.length;
  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }
  
  // Area code validation: 2-4 digits starting with 1-9
  const areaCodeLength = areaCode.length;
  if (areaCodeLength < 2 || areaCodeLength > 4) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  const name = value.trim();
  
  // Empty name is invalid
  if (!name) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Must start with a letter
  // Cannot contain digits or other symbols
  const nameRegex = /^[\p{L}]([\p{L}\p{M}'\-\s]*[\p{L}\p{M}])?$/u;
  
  if (!nameRegex.test(name)) {
    return false;
  }
  
  // Reject X Æ A-12 style names (contains digits or unusual symbols)
  if (/\d/.test(name)) {
    return false;
  }
  
  // Reject unusual symbols like Æ
  if (/[^\p{L}\p{M}'\-\s]/u.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const card = value.replace(/\s+/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(card)) {
    return false;
  }
  
  // Check length (Visa: 13-19, Mastercard: 16, AmEx: 15)
  const length = card.length;
  const isValidLength = 
    (length >= 13 && length <= 19) || // Visa
    length === 16 || // Mastercard
    length === 15;   // AmEx
  
  if (!isValidLength) {
    return false;
  }
  
  // Check prefix
  const startsWithValidPrefix = 
    /^4/.test(card) || // Visa
    /^(5[1-5]|2[2-7])/.test(card) || // Mastercard
    /^3[47]/.test(card); // AmEx
  
  if (!startsWithValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(card);
}