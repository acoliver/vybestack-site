import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    if (this.sqlJs) {
      return; // Already initialized
    }

    this.sqlJs = await initSqlJs.default({
      locateFile: (file: string) => {
        // Load WASM file from node_modules
        return path.resolve(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });

    await this.loadDatabase();
  }

  private async loadDatabase(): Promise<void> {
    try {
      if (fs.existsSync(DB_PATH)) {
        // Load existing database
        const dbBuffer = fs.readFileSync(DB_PATH);
        this.db = new this.sqlJs!.Database(dbBuffer);
      } else {
        // Create new database
        this.db = new this.sqlJs!.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to load database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      this.db.exec(schema);
      await this.saveDatabase();
    } catch (error) {
      console.error('Failed to create schema:', error);
      throw error;
    }
  }

  async insertSubmission(data: {
    first_name: string;
    last_name: string;
    street_address: string;
    city: string;
    state_province: string;
    postal_code: string;
    country: string;
    email: string;
    phone: string;
  }): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();

    // Get the last inserted row ID
    const idResult = this.db.exec('SELECT last_insert_rowid() as id');
    const idValue = idResult[0]?.values?.[0]?.[0];
    const id = typeof idValue === 'number' ? idValue : 0;

    await this.saveDatabase();
    return id;
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data = this.db.export();
      const dir = path.dirname(DB_PATH);
      
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(DB_PATH, data);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Singleton instance
export const dbManager = new DatabaseManager();