// Type definitions for the form application

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: FormErrors;
}

export interface SubmissionData {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}