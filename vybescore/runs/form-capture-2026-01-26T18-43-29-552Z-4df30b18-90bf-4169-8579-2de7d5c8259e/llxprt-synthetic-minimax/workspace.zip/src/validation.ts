import { FormData, FormErrors, ValidationResult } from './types.js';

export function validateForm(data: FormData): ValidationResult {
  const errors: FormErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field]?.trim();
    if (!value) {
      const fieldName = String(field);
      errors[field] = `${fieldName} is required`;
    }
  });

  // Email validation
  if (data.email && data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim()) {
    // Allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation - allow alphanumeric
  if (data.postalCode && data.postalCode.trim()) {
    // UK SW1A 1AA, US 12345, Argentina C1000, B1675 format
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode.trim())) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export function formatFieldName(field: string): string {
  // Convert camelCase to readable format
  return field
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, str => str.toUpperCase())
    .trim();
}