import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load as cheerioLoad } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { ChildProcess, spawn } from 'child_process';

let server: ChildProcess | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Start the built server for testing
  process.env.NODE_ENV = 'test';
  server = spawn('npm', ['run', 'start'], { 
    stdio: 'pipe',
    cwd: process.cwd(),
    detached: false
  });
  
  // Wait for server to start
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  // Use direct HTTP requests since server import is complex
});

afterAll(async () => {
  if (server) {
    server.kill('SIGTERM');
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);

    const $ = cheerioLoad(response.text);
    
    // Check for all form fields
    expect($('#firstName').length).toBeGreaterThan(0);
    expect($('#lastName').length).toBeGreaterThan(0);
    expect($('#streetAddress').length).toBeGreaterThan(0);
    expect($('#city').length).toBeGreaterThan(0);
    expect($('#stateProvince').length).toBeGreaterThan(0);
    expect($('#postalCode').length).toBeGreaterThan(0);
    expect($('#country').length).toBeGreaterThan(0);
    expect($('#email').length).toBeGreaterThan(0);
    expect($('#phone').length).toBeGreaterThan(0);
    
    // Check for submit button
    expect($('button[type="submit"]').length).toBeGreaterThan(0);
    
    // Check for stylesheet
    expect($('link[href="/public/styles.css"]').length).toBeGreaterThan(0);
  });

  it('persists submission and redirects', async () => {
    // Ensure database is clean
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62704',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1-555-0123'
      })
      .expect(302); // Should redirect

    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      })
      .expect(400); // Should return 400 for validation errors

    const $ = cheerioLoad(response.text);
    expect($('.error-list').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62704',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1-555-0123'
      })
      .expect(400); // Should return 400 for validation errors

    const $ = cheerioLoad(response.text);
    expect($('.error-list').text()).toContain('email');
  });

  it('accepts international phone formats', async () => {
    // Clean database first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302); // Should redirect

    expect(response.headers.location).toBe('/thank-you');
  });

  it('renders thank-you page with form submission', async () => {
    const response = await request('http://localhost:3535')
      .get('/thank-you')
      .expect(200);

    const $ = cheerioLoad(response.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('a[href="/"]').length).toBeGreaterThan(0);
    
    // Check for the playful scam warning text
    expect($('p').text()).toMatch(/identity theft|stranger on the internet|spam/);
  });
});
