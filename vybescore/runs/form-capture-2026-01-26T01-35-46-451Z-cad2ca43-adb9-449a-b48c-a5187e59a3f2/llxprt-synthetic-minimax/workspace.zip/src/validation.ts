export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  values: Partial<FormData>;
  completeData?: FormData;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[+]?[0-9\s()\-@]*$/;

export function validateFormData(data: Record<string, unknown>): ValidationResult {
  const errors: string[] = [];
  
  // Preserve user input for re-display on validation failure
  const values: Partial<FormData> = {};
  if (data.firstName && typeof data.firstName === 'string') values.firstName = data.firstName.trim();
  if (data.lastName && typeof data.lastName === 'string') values.lastName = data.lastName.trim();
  if (data.streetAddress && typeof data.streetAddress === 'string') values.streetAddress = data.streetAddress.trim();
  if (data.city && typeof data.city === 'string') values.city = data.city.trim();
  if (data.stateProvince && typeof data.stateProvince === 'string') values.stateProvince = data.stateProvince.trim();
  if (data.postalCode && typeof data.postalCode === 'string') values.postalCode = data.postalCode.trim();
  if (data.country && typeof data.country === 'string') values.country = data.country.trim();
  if (data.email && typeof data.email === 'string') values.email = data.email.trim();
  if (data.phone && typeof data.phone === 'string') values.phone = data.phone.trim();

  let completeData: FormData | undefined;

  // Validate first name
  if (!data.firstName || typeof data.firstName !== 'string' || data.firstName.trim() === '') {
    errors.push('First name is required');
  }

  // Validate last name
  if (!data.lastName || typeof data.lastName !== 'string' || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }

  // Validate street address
  if (!data.streetAddress || typeof data.streetAddress !== 'string' || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  // Validate city
  if (!data.city || typeof data.city !== 'string' || data.city.trim() === '') {
    errors.push('City is required');
  }

  // Validate state/province
  if (!data.stateProvince || typeof data.stateProvince !== 'string' || data.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }

  // Validate postal code (alphanumeric)
  if (!data.postalCode || typeof data.postalCode !== 'string' || data.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  } else {
    const postalCode = data.postalCode.trim();
    // Allow alphanumeric with optional spaces/hyphens
    if (!/^[A-Za-z0-9\s-]+$/.test(postalCode)) {
      errors.push('Postal/Zip code contains invalid characters');
    }
  }

  // Validate country
  if (!data.country || typeof data.country !== 'string' || data.country.trim() === '') {
    errors.push('Country is required');
  }

  // Validate email
  if (!data.email || typeof data.email !== 'string' || data.email.trim() === '') {
    errors.push('Email is required');
  } else {
    const email = data.email.trim();
    if (!EMAIL_REGEX.test(email)) {
      errors.push('Please enter a valid email address');
    }
  }

  // Validate phone (international format support)
  if (!data.phone || typeof data.phone !== 'string' || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else {
    const phone = data.phone.trim();
    if (!PHONE_REGEX.test(phone)) {
      errors.push('Please enter a valid phone number');
    }
  }

  // If validation passes, create complete data for database submission
  if (errors.length === 0 && 
      data.firstName && data.lastName && data.streetAddress && data.city && 
      data.stateProvince && data.postalCode && data.country && data.email && data.phone) {
    
    const firstName = data.firstName as string;
    const lastName = data.lastName as string;
    const streetAddress = data.streetAddress as string;
    const city = data.city as string;
    const stateProvince = data.stateProvince as string;
    const postalCode = data.postalCode as string;
    const country = data.country as string;
    const email = data.email as string;
    const phone = data.phone as string;

    completeData = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      streetAddress: streetAddress.trim(),
      city: city.trim(),
      stateProvince: stateProvince.trim(),
      postalCode: postalCode.trim(),
      country: country.trim(),
      email: email.trim(),
      phone: phone.trim()
    };
  }

  return {
    isValid: errors.length === 0,
    errors,
    values: values,
    completeData
  };
}