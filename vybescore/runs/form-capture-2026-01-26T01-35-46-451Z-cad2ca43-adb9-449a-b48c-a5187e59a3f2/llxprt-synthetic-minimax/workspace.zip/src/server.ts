import express from 'express';
import path from 'path';
import { dbManager } from './database.js';
import { validateFormData } from './validation.js';

export function createApp(): express.Express {
  const app = express();

  // Configure Express
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // Set EJS as the view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));

  // Serve static files from public directory
  app.use('/public', express.static(path.join(process.cwd(), 'public')));

  // Routes

  // GET / - Render the contact form
  app.get('/', (req, res) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });

  // POST /submit - Handle form submission
  app.post('/submit', async (req, res) => {
    try {
      const validationResult = validateFormData(req.body);

      if (!validationResult.isValid) {
        // Return form with errors and previously entered values
        return res.status(400).render('form', {
          errors: validationResult.errors,
          values: validationResult.values
        });
      }

      // If validation passes, insert into database
      // Use completeData when validation passes (all fields validated)
      const submission = validationResult.completeData!;
      await dbManager.insertSubmission(submission);

      // Redirect to thank you page
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error processing form submission:', error);
      res.status(500).render('form', {
        errors: ['Internal server error. Please try again later.'],
        values: req.body
      });
    }
  });

  // GET /thank-you - Thank you page
  app.get('/thank-you', (req, res) => {
    res.render('thank-you');
  });

  return app;
}

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    const app = createApp();
    const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to access the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Only start server if this file is being run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
