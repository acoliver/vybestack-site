import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

export type ContactSubmission = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    
    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  }

  async initialize(): Promise<void> {
    if (this.sqlJs) {
      return;
    }

    // Initialize sql.js
    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(fileBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: ContactSubmission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    await this.saveToDisk();
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const binaryArray = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(binaryArray));
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.saveToDisk();
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();