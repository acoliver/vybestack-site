import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start the server
  const { dbManager } = await import('../../dist/database.js');
  
  // Initialize database
  await dbManager.initialize();
  
  // Create server using Node's http module
  const http = await import('node:http');
  const { createApp } = await import('../../dist/server.js');
  
  const expressApp = createApp();
  server = http.createServer(expressApp);
  
  app = expressApp;
  
  return new Promise((resolve) => {
    server.listen(0, () => {
      resolve(true);
    });
  });
});

afterAll(async () => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close database
  const { dbManager } = await import('../../dist/database.js');
  await dbManager.close();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '555-1234'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('accepts valid submission and redirects', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555-1234'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('renders thank you page', async () => {
    // First submit a form to get redirected
    await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Othertown',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'jane@example.com',
        phone: '555-5678'
      });
    
    // Then get the thank you page
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
  });

  it('serves CSS from public directory', async () => {
    const response = await request(app).get('/public/styles.css');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/css/);
    expect(response.text).toContain('.form-shell');
  });
});
