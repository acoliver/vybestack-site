/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Common abbreviations to preserve
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K'];
  
  // First, let's handle sentence boundaries more intelligently
  // We'll split on sentence-ending punctuation followed by space and non-space
  // But we'll preserve abbreviations
  
  let result = text.trim();
  
  // Replace multiple spaces with a single space
  result = result.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence-ending punctuation
  result = result.replace(/([.?!])(?=([A-Z]))/g, '$1 ');
  
  // Split into sentences
  const sentences = result.split(/(?<=[.?!])\s+/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Skip empty sentences
    if (!sentence.trim()) return sentence;
    
    // Check if this might be an abbreviation followed by punctuation
    // Look for patterns like "Mr.", "Dr.", "i.e."
    for (const abbr of abbreviations) {
      if (sentence.toLowerCase().startsWith(abbr.toLowerCase() + '.')) {
        return sentence; // Don't capitalize - it's likely part of the ongoing sentence
      }
    }
    
    // Capitalize the first character of the sentence
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join sentences with single space
  return processedSentences.join(' ');
}

/**
 * Extract all URLs from the given text.
 * Returns an array of URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // URL pattern to match:
  // http:// or https://
  // www. (with implied http://)
  // domain names with various TLDs
  // optional paths, query strings, fragments
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,?,!,:;,'" that's not part of the URL
    return url.replace(/[.,!?;:'")\]\}]+$/g, '');
  });
}

/**
 * Replace all http:// schemes with https://.
 * Leaves existing https:// URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Replace all http:// with https://
  // This uses a word boundary to avoid replacing parts of other words
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite URLs from example.com domain following specific rules.
 * Always upgrades to https://.
 * When the path begins with /docs/, rewrites the host to docs.example.com.
 * Skips host rewrite when path contains dynamic hints.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Pattern to match URLs from example.com
  const exampleUrlPattern = /(https?):\/\/(example\.com)(\/[^\s]*)?/gi;
  
  // List of patterns that indicate a dynamic URL (should not trigger host rewrite)
  const dynamicPatterns = [
    /\/cgi-bin\//i,
    /[?&=]/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i
  ];
  
  return text.replace(exampleUrlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https';
    
    // If there's no path or path doesn't start with /docs/, just upgrade scheme
    if (!path || !path.startsWith('/docs/')) {
      return `${newScheme}://${host}${path || ''}`;
    }
    
    // Check if the path contains dynamic hints
    for (const pattern of dynamicPatterns) {
      if (pattern.test(path)) {
        // Dynamic path detected - just upgrade scheme
        return `${newScheme}://${host}${path}`;
      }
    }
    
    // Static docs path - rewrite host
    return `${newScheme}://docs.example.com${path}`;
  });
}

/**
 * Extract the year from a date in mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = parseInt(dateMatch[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (simple validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  const febDays = isLeapYear ? 29 : 28;
  
  // Update days in February for leap years
  if (month === 2) {
    if (day < 1 || day > febDays) {
      return 'N/A';
    }
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Everything is valid, return the year
  return dateMatch[3];
}
