/**
 * Find all words starting with the given prefix.
 * Excludes any words that are in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape the prefix for regex and create a pattern to match words starting with it
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match whole words starting with the prefix
  // \b ensures we're matching whole words
  // \w* matches the remaining characters in the word
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Convert to lowercase for case-insensitive comparison with exceptions
  const lowerExceptions = exceptions.map(word => word.toLowerCase());
  
  // Filter out the exceptions
  const filteredMatches = matches.filter(word => 
    !lowerExceptions.includes(word.toLowerCase())
  );
  
  // Return unique words
  return Array.from(new Set(filteredMatches));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to match the token in the right context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find token when preceded by a digit
  // The pattern uses a positive lookbehind to check for a digit
  // We also need to ensure it's not at the beginning of the string by checking the first character
  const tokenPattern = new RegExp(`(?:\\d)(${escapedToken})`, 'gi');
  
  // Find all matches - we need to extract the digit+token part
  const matches = text.match(tokenPattern) || [];
  
  // Return unique matches
  return Array.from(new Set(matches));
}

/**
 * Check if a password meets the strength requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace and no immediate repeated sequences (e.g., abab).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^a-zA-Z0-9]/.test(value); // Any non-alphanumeric character
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This looks for any 2-character repeated pattern
  for (let i = 0; i < value.length - 4; i++) {
    const substring = value.substring(i, i + 2);
    const nextSubstring = value.substring(i + 2, i + 4);
    
    if (substring === nextSubstring) {
      return false;
    }
  }
  
  // Also check for character repetitions like "aaa" or "111"
  if (/(.)\1\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect if the string contains IPv6 addresses.
 * Checks for full IPv6 addresses and shorthand notation (e.g., ::1).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Full IPv6 pattern with optional shorthand
  // This pattern captures:
  // - Standard colon-separated hex groups
  // - Shorthand notation with ::
  // - IPv4-mapped IPv6 addresses
  
  const ipv6Pattern = /(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}|::|(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?::(?:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})?|(?:(?:[0-9a-f]{1,4}:){1,7}:)|(?:::(?:[0-9a-f]{1,4}:){1,7})|(?:[0-9a-f]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}|:(?::[0-9a-f]{1,4}){1,7}|[0-9a-f]{1,4}:(?:(?::[0-9a-f]{1,4}){1,6})|:(?:[0-9a-f]{1,4}){1,7}:/i;
  
  // First try to identify any IPv6-like patterns
  const potentialIPv6Matches = value.match(ipv6Pattern);
  if (!potentialIPv6Matches) {
    return false;
  }
  
  // Now verify that each match is not actually an IPv4 address
  for (const match of potentialIPv6Matches) {
    // Exclude if it's actually an IPv4 address
    if (!ipv4Pattern.test(match)) {
      // Additional check: ensure it has the characteristics of IPv6
      // (contains at least one colon and valid hex characters)
      if (/:/.test(match) && match.length > 4) {
        return true;
      }
    }
  }
  
  return false;
}