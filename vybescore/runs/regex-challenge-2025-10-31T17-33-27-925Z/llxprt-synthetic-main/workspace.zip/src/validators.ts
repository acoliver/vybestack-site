export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to common patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that handles most common cases
  // Local part supports letters, digits, +, -, ., and _
  // Domain part supports letters, digits, -, and .
  // Rejects double dots in both local and domain parts
  // Rejects underscores in domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick check for invalid patterns
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Reject consecutive dots anywhere in the email
  if (/\.\./.test(value)) {
    return false;
  }
  
  // Reject dots at the start or end of local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  const domain = value.substring(value.indexOf('@') + 1);
  if (domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value.trim());
}

/**
 * Validate US phone numbers with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Clean the input by removing common separators and spaces
  const cleaned = value.trim().replace(/[\s\-\(\)]/g, '');
  
  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // A valid US phone number should have exactly 10 digits after removing
  // country code and formatting
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }
  
  // Extract area code (first 3 digits) and check it doesn't start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Additional validation for phone number format
  // Original format check (with optional +1, parentheses, etc.)
  const phoneRegex = /^(\+1[\s\-]?)?(\(?([2-9]\d{2})\)?[\s\-]?)?([2-9]\d{2})[\s\-]?(\d{4})$/;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces, hyphens, and other punctuation for validation
  const cleaned = value.trim().replace(/[\s\-]/g, '');
  
  // Argentine phone regex components:
  // Optional +54 country code
  // If country code is omitted, must start with trunk prefix 0
  // Optional 9 for mobile numbers after country code or trunk prefix
  // Area code: 2-4 digits, leading digit should be 1-9
  // Subscriber number: 6-8 digits
  
  const argentinePhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$|^0([1-9]\d{1,3})(9)?(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Validate components more precisely
  const withCountryCode = cleaned.match(/^(\+54)(9)?([1-9]\d{1,3})(\d{6,8})$/);
  if (withCountryCode) {
    const areaCode = withCountryCode[3];
    const subscriber = withCountryCode[4];
    
    // Area code should be 2-4 digits, subscriber should be 6-8 digits
    if (areaCode.length < 2 || areaCode.length > 4 || 
        subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  const withTrunkPrefix = cleaned.match(/^0([1-9]\d{1,3})(9)?(\d{6,8})$/);
  if (withTrunkPrefix) {
    const areaCode = withTrunkPrefix[1];
    const subscriber = withTrunkPrefix[3];
    
    // Area code should be 2-4 digits, subscriber should be 6-8 digits
    if (areaCode.length < 2 || areaCode.length > 4 || 
        subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

/**
 * Validate personal names based on character rules.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  const trimmed = value.trim();
  
  // Names with only whitespace are invalid
  if (!trimmed) {
    return false;
  }
  
  // Unicode character classes:
  // \p{L} - all kinds of letters
  // \p{M} - combining marks (accents)
  // allowing apostrophes, hyphens, and spaces
  const nameRegex = /^[a-zA-Z\u00C0-\u024F'\-\s]+$/;
  
  // Basic pattern check
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Reject digits specifically
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Reject certain special symbols that might be allowed by the broad regex
  if (/[`~!@#$%^&*()+=\[\]{}|\\;:'",.<>\/?¿§°£¥€¢©®™±¹²³¼½¾×÷Øø]/.test(trimmed)) {
    return false;
  }
  
  // No consecutive spaces, hyphens or apostrophes
  if (/[ \-'']{2,}/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Perform Luhn checksum algorithm validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for major card types.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces and hyphens
  const cardNumber = value.trim().replace(/[\s\-]/g, '');
  
  // Should be all digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Card type patterns (prefix and length)
  const cardPatterns = [
    // Visa: starts with 4, length 13 or 16
    { regex: /^4(\d{12}|\d{15})$/, type: 'Visa' },
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    { regex: /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-1]\d|5[0-9]\d|6[0-7]\d|71[0-9]|72[0-9]|730)\d{12})$/, type: 'Mastercard' },
    // AmEx: starts with 34 or 37, length 15
    { regex: /^(34|37)\d{13}$/, type: 'AmEx' }
  ];
  
  // Check if card matches any known pattern
  let isValidPattern = false;
  for (const pattern of cardPatterns) {
    if (pattern.regex.test(cardNumber)) {
      isValidPattern = true;
      break;
    }
  }
  
  if (!isValidPattern) {
    return false;
  }
  
  // Run Luhn algorithm validation
  return runLuhnCheck(cardNumber);
}
