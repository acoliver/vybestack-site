import { ReportData, RenderOptions } from "../types.js";
import { formatAmount, calculateTotal } from "../utils/validation.js";

export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  lines.push(data.title);
  lines.push("");
  lines.push(data.summary);
  lines.push("");
  lines.push("Entries:");
  lines.push("");

  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push("");
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join("\n");
}