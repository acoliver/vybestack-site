# Report Formatters

This directory contains the format-specific rendering modules for reports.

Each formatter module should export a function with the following signature:

```typescript
function renderFormat(data: ReportData, options: RenderOptions): string;
```

The function should take report data and rendering options and return a formatted string.