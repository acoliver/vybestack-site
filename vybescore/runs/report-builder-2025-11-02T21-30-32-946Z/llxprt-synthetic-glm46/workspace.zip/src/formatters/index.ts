import { ReportData, RenderOptions, FormatType } from "../types.js";
import { renderMarkdown } from "../formats/markdown.js";
import { renderText } from "../formats/text.js";

type RendererFn = (data: ReportData, options: RenderOptions) => string;

export const formatters: Record<FormatType, RendererFn> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: FormatType): RendererFn {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}