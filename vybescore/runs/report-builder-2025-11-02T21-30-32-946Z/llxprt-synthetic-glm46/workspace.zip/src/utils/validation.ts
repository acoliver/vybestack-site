import fs from "fs";
import { ReportData } from "../types.js";

export function validateAndParseReportData(filePath: string): ReportData {
  try {
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }

    const fileContent = fs.readFileSync(filePath, "utf8");
    let parsedData: unknown;

    try {
      parsedData = JSON.parse(fileContent);
    } catch (parseError) {
      throw new Error("Invalid JSON format");
    }

    const data = parsedData as Record<string, unknown>;

    if (!data.title || typeof data.title !== "string") {
      throw new Error("Missing or invalid 'title' field");
    }

    if (!data.summary || typeof data.summary !== "string") {
      throw new Error("Missing or invalid 'summary' field");
    }

    if (!Array.isArray(data.entries)) {
      throw new Error("Missing or invalid 'entries' field");
    }

    if (data.entries.length === 0) {
      throw new Error("'entries' array cannot be empty");
    }

    for (const entry of data.entries) {
      if (!entry || typeof entry !== "object") {
        throw new Error("Each entry must be an object");
      }

      const entryObj = entry as Record<string, unknown>;

      if (!entryObj.label || typeof entryObj.label !== "string") {
        throw new Error("Each entry must have a valid 'label' field");
      }

      if (typeof entryObj.amount !== "number" || isNaN(entryObj.amount)) {
        throw new Error("Each entry must have a valid 'amount' field");
      }
    }

    return {
      title: data.title,
      summary: data.summary,
      entries: data.entries.map((entry: { label: string; amount: number }) => ({
        label: entry.label,
        amount: entry.amount,
      })),
    };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error(`Unexpected error: ${String(error)}`);
  }
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}