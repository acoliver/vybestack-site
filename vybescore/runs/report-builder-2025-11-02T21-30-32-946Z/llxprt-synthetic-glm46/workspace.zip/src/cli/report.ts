#!/usr/bin/env node
import fs from "fs";
import { FormatType, RenderOptions } from "../types.js";
import { validateAndParseReportData } from "../utils/validation.js";
import { getFormatter } from "../formatters/index.js";

interface CliArguments {
  dataPath: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArguments {
  const defaultArgs: Partial<CliArguments> = {
    includeTotals: false,
  };

  if (args.length < 4) {
    showUsageAndExit();
  }

  const [dataPath, formatFlag, format] = args.slice(2);

  if (formatFlag !== "--format" || !format) {
    showUsageAndExit();
  }

  const result: CliArguments = {
    dataPath,
    format: format as FormatType,
    outputPath: undefined,
    includeTotals: defaultArgs.includeTotals as boolean,
  };

  for (let i = 5; i < args.length; i++) {
    const arg = args[i];

    if (arg === "--output" && i + 1 < args.length) {
      result.outputPath = args[i + 1];
      i++;
    } else if (arg === "--includeTotals") {
      result.includeTotals = true;
    }
  }

  return result;
}

function showUsageAndExit(): never {
  console.error("Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]");
  console.error("Supported formats: markdown, text");
  process.exit(1);
}

function main(): void {
  try {
    const args = process.argv;
    const cliArgs = parseArguments(args);

    if (!["markdown", "text"].includes(cliArgs.format)) {
      throw new Error(`Unsupported format: ${cliArgs.format}`);
    }

    const reportData = validateAndParseReportData(cliArgs.dataPath);

    const options: RenderOptions = {
      includeTotals: cliArgs.includeTotals,
    };

    const formatter = getFormatter(cliArgs.format);
    const output = formatter(reportData, options);

    if (cliArgs.outputPath) {
      fs.writeFileSync(cliArgs.outputPath, output, "utf8");
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error("An unexpected error occurred");
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}