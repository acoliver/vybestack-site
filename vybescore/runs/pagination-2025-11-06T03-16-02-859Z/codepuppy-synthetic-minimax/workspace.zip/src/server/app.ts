import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { validatePaginationParams, listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Use defaults if parameters not provided
      const pageToValidate = pageParam ?? DEFAULT_PAGE;
      const limitToValidate = limitParam ?? DEFAULT_LIMIT;

      // Validate parameters
      const { page, limit } = validatePaginationParams(pageToValidate, limitToValidate);

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
