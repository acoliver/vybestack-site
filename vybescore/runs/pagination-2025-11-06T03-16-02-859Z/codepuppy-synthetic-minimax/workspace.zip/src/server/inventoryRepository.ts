import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function validatePaginationParams(page: unknown, limit: unknown): { page: number; limit: number } {
  // Validate page parameter
  if (page === undefined || page === null || page === '') {
    throw new Error('Page parameter is required');
  }
  
  const pageNum = Number(page);
  if (isNaN(pageNum) || !Number.isInteger(pageNum) || pageNum <= 0) {
    throw new Error('Page must be a positive integer');
  }
  
  // Validate limit parameter
  if (limit === undefined || limit === null || limit === '') {
    throw new Error('Limit parameter is required');
  }
  
  const limitNum = Number(limit);
  if (isNaN(limitNum) || !Number.isInteger(limitNum) || limitNum <= 0 || limitNum > MAX_LIMIT) {
    throw new Error(`Limit must be a positive integer not exceeding ${MAX_LIMIT}`);
  }
  
  return { page: pageNum, limit: limitNum };
}

export function listInventory(
  db: Database,
  options: { page: number; limit: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Calculate offset correctly: (page - 1) * limit
  const offset = (options.page - 1) * options.limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: options.limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  // Calculate hasNext correctly: check if there are more items beyond current page
  const hasNext = offset + options.limit < total;

  return {
    items: rows,
    page: options.page,
    limit: options.limit,
    total,
    hasNext
  };
}
