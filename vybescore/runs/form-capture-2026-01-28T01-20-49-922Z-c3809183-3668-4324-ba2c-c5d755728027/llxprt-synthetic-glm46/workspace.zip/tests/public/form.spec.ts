import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

let server: { close: () => void } | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // placeholder test file - just ensuring clean state
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    expect(fs.existsSync(path.resolve('src', 'templates', 'form.ejs'))).toBe(true);
  });

  it('persists submission and redirects', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });
});
