import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import 'sql.js';
import type { Database, Module } from 'sql.js';

// Initialize sql.js with dynamic import since it's a WASM module
let initSqlJs: Module;
let Database: new(data?: Uint8Array) => Database;

// Database configuration
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

// Initialize database
async function initializeDatabase() {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const sqlJsImport = await import('sql.js');
    initSqlJs = await sqlJsImport.default();
  } catch (error) {
    console.error('Failed to load sql.js:', error);
    process.exit(1);
  }

  // Load existing database or create new one
  let dbData: Uint8Array | undefined;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbData = new Uint8Array(buffer);
  }
  
  // Initialize database
  Database = initSqlJs.Database;
  const db = new Database(dbData);
  
  // Load schema if database is new or doesn't have tables
  try {
    const result = db.exec('SELECT name FROM sqlite_master WHERE type="table"') as unknown[][];
    if (!result || result.length === 0 || !result[0] || (result[0] as unknown[]).length === 0) {
      // New database, load schema
      if (fs.existsSync(SCHEMA_PATH)) {
        const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
        db.exec(schema);
        console.log('Database schema loaded successfully');
      } else {
        console.error('Schema file not found:', SCHEMA_PATH);
      }
    }
  } catch (error) {
    // Load schema if there's any error
    if (fs.existsSync(SCHEMA_PATH)) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      console.log('Database schema loaded successfully');
    }
  }
  
  return db;
}

// Save database to disk
function saveDatabase(db: Database) {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading @
  const phoneRegex = /^@?[\d\s()--]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  const trimmed = postalCode.trim();
  return trimmed.length > 0 && postalRegex.test(trimmed);
}

// Express server setup
async function startServer() {
  const app = express();
  const port = process.env.PORT || 3535;
  
  // Initialize database
  let db: Database;
  try {
    db = await initializeDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
  
  // Configuration
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.resolve('public')));
  
  // Routes
  
  // GET / - render form
  app.get('/', (req, res) => {
    res.render('form', {
      errors: {},
      formData: {},
    });
  });
  
  // POST /submit - handle form submission
  app.post('/submit', (req, res) => {
    const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
    
    const errors: Record<string, string> = {};
    
    // Validate required fields
    if (!firstName || firstName.trim() === '') {
      errors.firstName = 'First name is required';
    }
    
    if (!lastName || lastName.trim() === '') {
      errors.lastName = 'Last name is required';
    }
    
    if (!streetAddress || streetAddress.trim() === '') {
      errors.streetAddress = 'Street address is required';
    }
    
    if (!city || city.trim() === '') {
      errors.city = 'City is required';
    }
    
    if (!stateProvince || stateProvince.trim() === '') {
      errors.stateProvince = 'State/Province/Region is required';
    }
    
    if (!postalCode || !validatePostalCode(postalCode)) {
      errors.postalCode = 'Postal/Zip code is required';
    }
    
    if (!country || country.trim() === '') {
      errors.country = 'Country is required';
    }
    
    if (!email || !validateEmail(email)) {
      errors.email = 'Valid email is required';
    }
    
    if (!phone || !validatePhone(phone)) {
      errors.phone = 'Valid phone number is required';
    }
    
    // If there are errors, re-render the form with error messages
    if (Object.keys(errors).length > 0) {
      return res.status(400).render('form', {
        errors,
        formData: {
          firstName,
          lastName,
          streetAddress,
          city,
          stateProvince,
          postalCode,
          country,
          email,
          phone,
        },
      });
    }
    
    // Insert into database
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        firstName.trim(),
        lastName.trim(),
        streetAddress.trim(),
        city.trim(),
        stateProvince.trim(),
        postalCode.trim(),
        country.trim(),
        email.trim(),
        phone.trim(),
      ]);
      
      stmt.free();
      
      // Save database to disk
      saveDatabase(db);
      
      // Redirect to thank you page
      return res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      return res.status(500).render('form', {
        errors: { general: 'An error occurred while saving your submission. Please try again.' },
        formData: {
          firstName,
          lastName,
          streetAddress,
          city,
          stateProvince,
          postalCode,
          country,
          email,
          phone,
        },
      });
    }
  });
  
  // GET /thank-you - render thank you page
  app.get('/thank-you', (req, res) => {
    res.render('thank-you');
  });
  
  // Graceful shutdown
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle SIGTERM
  const closeGracefully = () => {
    console.log('Shutting down server...');
    server.close(() => {
      console.log('Server closed');
      if (db) {
        db.close();
        console.log('Database closed');
      }
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', closeGracefully);
  process.on('SIGINT', closeGracefully);
  
  return server;
}

// Start server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default startServer;
