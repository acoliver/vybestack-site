declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): unknown;
    exec(sql: string): unknown[][];
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): Statement;
  }
  
  export interface Statement {
    run(params?: unknown[]): unknown;
    free(): void;
  }
  
  export interface Module {
    Database: new(data?: Uint8Array) => Database;
  }
  
  export default function(): Promise<Module>;
}