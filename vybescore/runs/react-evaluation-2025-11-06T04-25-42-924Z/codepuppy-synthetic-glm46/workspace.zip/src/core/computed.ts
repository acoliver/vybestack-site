/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  SubjectR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject-like interface for this computed value
  // so that other computed values can depend on it
  const subjectLike: SubjectR = {
    name: options?.name,
    observers: new Set()
  }
  

  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter = (): T => {
    // If called during computation (reactive context), establish dependency relationship
    const activeObs = getActiveObserver()
    if (activeObs && activeObs !== o) {
      // The active observer depends on this computed value
      // Add the active observer to this computed's observers
      if (!subjectLike.observers.has(activeObs)) {
        subjectLike.observers.add(activeObs)
      }
    }
    return o.value!
  }
  
  // Monkey-patch the update function to also notify our observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (currentValue?: T): T => {
    // Run the original update function to get the new value
    // Note: we DON'T call updateObserver here because that would re-establish dependencies
    // and mess up the notification cycle
    
    // Store the previous observer to avoid recursion
    const previousActive = getActiveObserver()
    
    // Clear dependencies by setting activeObserver to undefined temporarily
    setActiveObserver(undefined)
    const newValue = originalUpdateFn(currentValue)
    // Make sure to update the observer's value
    o.value = newValue
    setActiveObserver(previousActive)
    

    
    // Notify all observers of this computed value
    subjectLike.observers.forEach(observer => {
      const obs = observer as Observer<T>
      if (!obs.disposed) {
        updateObserver(obs)
      }
    })
    
    return newValue
  }
  
  return getter
}