/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = typeof equal === 'function' 
    ? equal 
    : (equal === false ? undefined : (a, b) => a === b)

  // Create a persistent subject for this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
    observers: new Set(),
  }

  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: () => {
      // When called, this will track dependencies and compute the new value
      const newValue = updateFn(observer.value)
      if (!equalFn || !equalFn(observer.value!, newValue)) {
        subject.value = newValue
        observer.value = newValue
        // Notify observers when the value changes
        notifyObservers(subject)
        return newValue
      }
      return observer.value!
    },
  }

  // Initial computation with dependency tracking
  updateObserver(observer)

  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Register as an observer of this computed value
      addObserver(subject, activeObs)
    }
    return subject.value
  }

  return getter
}
