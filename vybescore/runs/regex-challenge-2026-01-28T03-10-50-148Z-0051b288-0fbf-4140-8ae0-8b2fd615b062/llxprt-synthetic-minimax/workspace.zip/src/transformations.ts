/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, collapse multiple spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Handle sentence endings followed by sentence beginnings
  // Pattern: end of sentence (.?!), optional spaces, then start of next sentence
  result = result.replace(/([.!?])\s*([A-Za-z])/g, (match, punctuation, nextChar) => {
    return punctuation + ' ' + nextChar.toUpperCase();
  });
  
  // Capitalize the first character of the entire text
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Ensure exactly one space after sentence endings
  result = result.replace(/([.!?])\s{2,}/g, '$1 ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https) without trailing punctuation
  const urlPattern = /\bhttps?:\/\/[^\s]+/g;
  
  const matches = text.match(urlPattern);
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.,;!?]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but leave https:// untouched
  // Use negative lookbehind to avoid matching https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs that need rewriting
  // Groups: 1=scheme, 2=host, 3=path+query+fragment
  const urlPattern = /(https?):\/\/([^/\s]+)([^\s]*)/g;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade scheme to https
    const newScheme = 'https';
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions (must be complete extensions or query params)
      const hasDynamicHints = /(\.(jsp|php|asp|aspx|do|cgi|pl|py)|cgi-bin|\?|&|=)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.host (but preserve subdomains)
        let newHost;
        if (host.includes('.')) {
          // Multi-level domain: example.com -> docs.example.com
          newHost = `docs.${host}`;
        } else {
          // Single-level domain: docs
          newHost = `docs.${host}.com`; // fallback
        }
        return `${newScheme}://${newHost}${path}`;
      }
    }
    
    // For non-docs paths, just upgrade scheme
    return `${newScheme}://${host}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for days in month (simple check)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Check for invalid February dates
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  return year;
}
