export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Pattern: local@domain.tld where domain can have subdomains
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*@[a-zA-Z0-9][a-zA-Z0-9._-]*\.[a-zA-Z]{2,}$/;
  
  // Reject obvious invalid forms
  if (value.includes('..') || // No double dots
      value.endsWith('.') || // No trailing dots
      value.includes('@@') || // No double @
      !emailRegex.test(value)) {
    return false;
  }
  
  // Check for underscores in domain (not allowed in standard emails)
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Note: options parameter intentionally unused to satisfy interface
  void options;
  // Remove all non-digit characters except + for country code
  const cleanValue = value.replace(/\s+/g, '');
  
  // Pattern with optional +1 prefix
  // (?:\+?1)? - optional country code 1
  // \(?([2-9]\d{2})\)? - optional parentheses around area code
  // \(?[2-9]\d{2}\)? - exchange code with optional parentheses
  // [2-9]\d{2}-?[2-9]\d{2}-?\d{4} - full number with separators
  const phonePattern = /^(?:\+?1)?\(?[2-9]\d{2}\)?[-\s]?[2-9]\d{2}[-\s]?\d{4}$/;
  
  // Check length - too short inputs
  if (cleanValue.replace(/[^\d]/g, '').length < 10) {
    return false;
  }
  
  // Extract area code to check it's valid (not 0 or 1)
  const areaCodeMatch = value.match(/\(?([2-9]\d{2})\)?/);
  if (areaCodeMatch) {
    const areaCode = areaCodeMatch[1];
    // Area code can't start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
  }
  
  return phonePattern.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.trim();
  const digitsOnly = cleaned.replace(/[^\d]/g, '');
  
  // Check total length - should be 10-13 digits depending on format
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }
  
  // Extract area code and subscriber using flexible pattern
  // Pattern groups: 1=optional country+mobile, 2=area code, 3=subscriber part
  const areaPattern = /^(?:\+54\s*)?(?:\s*9\s*)?(?:0\s*)?([1-9]\d{1,3})\s*([\d\s]+)$/;
  const areaMatch = cleaned.match(areaPattern);
  
  if (!areaMatch) {
    return false;
  }
  
  const areaCode = areaMatch[1];
  const subscriberDigits = areaMatch[2].replace(/[^\d]/g, '');
  
  // Area code should be 2-4 digits (leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Area code cannot start with 0
  if (areaCode.startsWith('0')) {
    return false;
  }
  
  // Subscriber number should be 6-8 digits
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  // When country code is omitted, must begin with trunk prefix 0 OR mobile indicator 9 OR direct area
  if (!cleaned.startsWith('+54') && 
      !cleaned.match(/^\s*9/) && 
      !cleaned.match(/^0/) && 
      !cleaned.match(/^[1-9]/)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject if empty or too short
  if (!value || value.trim().length < 2) {
    return false;
  }
  
  // Reject obvious invalid patterns
  // 1. Can't contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // 2. Can't contain symbols (except allowed ones)
  if (/[^A-Za-zÀ-ÿ\s'’-]/.test(value)) {
    return false;
  }
  
  // 3. Reject patterns like "X Æ A-12" style names
  if (value.includes('Æ') || value.includes('A-12')) {
    return false;
  }
  
  // 4. Must contain at least some valid name structure
  // Pattern: starts with letter, allows spaces, hyphens, apostrophes
  const namePattern = /^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s'’-]*[A-Za-zÀ-ÿ]$/;
  
  // Also reject if starts/ends with separator unless reasonable
  const trimmed = value.trim();
  if (/^[\s'’-]/.test(trimmed) || /[\s'’-]$/.test(trimmed)) {
    return false;
  }
  
  return namePattern.test(trimmed);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55, length 16
  // American Express: starts with 34 or 37, length 15
  const isVisa = /^4/.test(digitsOnly) && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19);
  const isMastercard = /^(5[1-5])/.test(digitsOnly) && digitsOnly.length === 16;
  const isAmEx = /^(34|37)/.test(digitsOnly) && digitsOnly.length === 15;
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
