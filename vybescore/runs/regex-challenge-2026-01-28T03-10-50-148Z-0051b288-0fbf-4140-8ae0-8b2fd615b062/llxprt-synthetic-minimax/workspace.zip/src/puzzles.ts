/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with prefix
  // Word boundaries to ensure we match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp('\\b' + escapedPrefix + '\\w*\\b', 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const normalizedExceptions = exceptions.map(e => e.toLowerCase());
  const result = matches.filter(word => !normalizedExceptions.includes(word.toLowerCase()));
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to match token after a digit but not at start
  // Use negative lookbehind for start of string, positive lookbehind for digit
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // We need to return the complete token including the digit
  // So we'll match \d+token and return those matches
  const fullPattern = new RegExp('\\d' + escapedToken, 'g');
  return text.match(fullPattern) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-={};':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This pattern looks for repeated groups of 2 or more characters
  const repeatedPattern = /(..+)\1/g;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it's a pure IPv4 address - if so, return false
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns to match anywhere in the string
  // 1. Standard full IPv6: 8 groups of hex digits
  const ipv6Full = /\b(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}\b/;
  
  // 2. IPv6 with shorthand notation like 2001:db8::1
  const ipv6Shorthand = /\b(?:[A-Fa-f0-9]{1,4}:)*::(?:[A-Fa-f0-9]{1,4}:)*[A-Fa-f0-9]{1,4}\b/;
  
  // 3. IPv6 with mixed notation (partial double colon)
  const ipv6Mixed = /\b(?:[A-Fa-f0-9]{1,4}:){1,6}:(?:[A-Fa-f0-9]{1,4}:)*[A-Fa-f0-9]{1,4}\b/;
  
  // 4. IPv4-mapped IPv6
  const ipv6Embedded = /\b(?:[A-Fa-f0-9]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // 5. Double colon alone (simplest check for shorthand)
  const hasDoubleColon = /::/;
  
  // Check for any IPv6 patterns in the value
  const trimmed = value.trim();
  return ipv6Full.test(trimmed) || ipv6Shorthand.test(trimmed) || 
         ipv6Mixed.test(trimmed) || ipv6Embedded.test(trimmed) ||
         hasDoubleColon.test(trimmed);
}
