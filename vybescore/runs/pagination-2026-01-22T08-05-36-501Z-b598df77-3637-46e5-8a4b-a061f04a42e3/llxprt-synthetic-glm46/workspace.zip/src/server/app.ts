import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(pageParam?: string, limitParam?: string): { page: number; limit: number; error: null } | { page: undefined; limit: undefined; error: string } {
  const DEFAULT_PAGE = 1;
  const DEFAULT_LIMIT = 5;
  const MAX_LIMIT = 100;

  let page = DEFAULT_PAGE;
  let limit = DEFAULT_LIMIT;

  // Validate page parameter
  if (pageParam !== undefined) {
    if (!/^\d+$/.test(pageParam)) {
      return { error: 'Invalid page parameter: must be a positive integer', page: undefined, limit: undefined };
    }
    page = Number(pageParam);
    if (page <= 0) {
      return { error: 'Invalid page parameter: must be greater than 0', page: undefined, limit: undefined };
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    if (!/^\d+$/.test(limitParam)) {
      return { error: 'Invalid limit parameter: must be a positive integer', page: undefined, limit: undefined };
    }
    limit = Number(limitParam);
    if (limit <= 0) {
      return { error: 'Invalid limit parameter: must be greater than 0', page: undefined, limit: undefined };
    }
    if (limit > MAX_LIMIT) {
      return { error: 'Invalid limit parameter: must not exceed 100', page: undefined, limit: undefined };
    }
  }

  return { page, limit, error: null };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);
    
    if (validation.error) {
      return res.status(400).json({ error: validation.error });
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
