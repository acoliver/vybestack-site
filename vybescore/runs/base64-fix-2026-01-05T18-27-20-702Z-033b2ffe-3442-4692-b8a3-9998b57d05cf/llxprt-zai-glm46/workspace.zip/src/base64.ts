/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 * Output includes padding characters (=) when required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that a string is a valid Base64 string.
 * Accepts the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with optional padding.
 * Rejects strings containing characters outside the Base64 alphabet or invalid padding.
 */
function isValidBase64(input: string): boolean {
  // Remove all whitespace for validation
  const trimmed = input.replace(/\s/g, '');
  
  if (trimmed.length === 0) {
    return false;
  }

  // Check for valid Base64 characters (canonical alphabet)
  // Pattern: characters from the Base64 alphabet, with optional padding
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(trimmed)) {
    return false;
  }

  // Check that padding, if present, is only at the end and is valid
  const paddingMatch = trimmed.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    const nonPaddedLength = trimmed.length - paddingLength;
    
    // Padding can only be 0, 1, or 2 characters
    if (paddingLength > 2) {
      return false;
    }
    
    // The length before padding must be a multiple of 4 characters minus padding
    // i.e., total length must be a multiple of 4
    if (trimmed.length % 4 !== 0) {
      return false;
    }
    
    // If there's 2 padding chars, there must be at least 2 non-padding chars
    // If there's 1 padding char, there must be at least 3 non-padding chars
    // This ensures the encoded data is valid
    if (paddingLength === 2 && nonPaddedLength < 2) {
      return false;
    }
    if (paddingLength === 1 && nonPaddedLength < 3) {
      return false;
    }
  } else {
    // No padding - length should still be a multiple of 4 for valid Base64
    // though some implementations accept unpadded input
    // We'll accept unpadded input as long as the characters are valid
  }

  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) using the canonical alphabet.
 * Rejects invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  const trimmed = input.replace(/\s/g, '');

  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet or has invalid padding');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding actually succeeded
    // If the input was invalid, Buffer.from may return an empty buffer or garbage
    // A simple check is to verify the buffer isn't empty when input isn't just padding
    if (trimmed.length > 0 && buffer.length === 0 && !/^=+$/.test(trimmed)) {
      throw new Error('Failed to decode Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
