/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean to EqualFn if needed
  let equalFn: EqualFn<T> | undefined
  if (equal === undefined) {
    equalFn = undefined
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? 
      ((a: T, b: T) => a === b) as EqualFn<T> : 
      ((a: T, b: T) => a !== b) as EqualFn<T>
  } else {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // List of observers (dependents) that need to be notified when this computed value changes
  const dependents: Observer<unknown>[] = []

  let isUpdating = false

  const update = () => {
    if (isUpdating) return // Prevent recursive updates
    isUpdating = true
    
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      if (!dependents.includes(observer as Observer<unknown>)) {
        dependents.push(observer as Observer<unknown>)
      }
    }
    
    try {
      const newValue = updateFn(value)
      
      // Check if value actually changed using equal function
      if (equalFn) {
        if (equalFn(value as T, newValue)) {
          return // No change
        }
      }
      
      value = newValue
      
      // Notify all dependents that this computed value has changed
      dependents.forEach(dependent => {
        updateObserver(dependent)
      })
    } finally {
      isUpdating = false
    }
  }

  // Initial computation
  updateObserver(o)

  const read: GetterFn<T> = () => {
    update() // Re-compute if dependencies have changed
    return value as T
  }

  return read
}
