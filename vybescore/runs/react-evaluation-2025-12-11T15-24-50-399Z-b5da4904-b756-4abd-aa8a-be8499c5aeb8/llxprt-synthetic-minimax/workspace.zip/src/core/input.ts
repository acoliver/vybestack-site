/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean to EqualFn if needed
  let equalFn: EqualFn<T> | undefined
  if (equal === undefined) {
    equalFn = undefined
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? 
      ((a: T, b: T) => a === b) as EqualFn<T> : 
      ((a: T, b: T) => a !== b) as EqualFn<T>
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // List of observers (dependents) that need to be notified when value changes
  const dependents: Observer<unknown>[] = []

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Register this subject as a dependency of the active observer
      if (!dependents.includes(observer as Observer<unknown>)) {
        dependents.push(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equal function
    if (s.equalFn) {
      if (s.equalFn(s.value, nextValue)) {
        return s.value // No change, return current value
      }
    }
    
    s.value = nextValue
    
    // Notify all dependents that this value has changed
    dependents.forEach(observer => {
      updateObserver(observer)
    })
    
    return s.value
  }

  return [read, write]
}
