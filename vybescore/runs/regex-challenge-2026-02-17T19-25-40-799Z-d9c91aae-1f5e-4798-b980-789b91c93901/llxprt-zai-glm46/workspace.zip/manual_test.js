// Manual edge case testing
import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== MANUAL EDGE CASE TESTS ===\n');

// Email tests
console.log('EMAIL VALIDATION:');
const emailTests = [
  ['user@example.com', true],
  ['user+tag@example.co.uk', true],
  ['user..name@example.com', false],
  ['user.@example.com', false],
  ['.user@example.com', false],
  ['user@exa_mple.com', false],
  ['user@example..com', false],
];
emailTests.forEach(([email, expected]) => {
  const result = isValidEmail(email);
  const status = result === expected ? '[OK]' : '';
  console.log(`  ${status} "${email}" -> ${result} (expected ${expected})`);
});

// US Phone tests
console.log('\nUS PHONE VALIDATION:');
const usPhoneTests = [
  ['(212) 555-7890', true],
  ['212-555-7890', true],
  ['2125557890', true],
  ['+1 212-555-7890', true],
  ['012-555-7890', false],
  ['112-555-7890', false],
  ['212-055-7890', false],
  ['212-155-7890', false],
  ['212555789', false],
];
usPhoneTests.forEach(([phone, expected]) => {
  const result = isValidUSPhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`  ${status} "${phone}" -> ${result} (expected ${expected})`);
});

// Argentine Phone tests
console.log('\nARGENTINE PHONE VALIDATION:');
const arPhoneTests = [
  ['+54 9 11 1234 5678', true],
  ['011 1234 5678', true],
  ['+54 341 123 4567', true],
  ['0341 4234567', true],
  ['11 1234567', false], // No country code or trunk prefix
  ['+54 011 1234567', false], // Both country code and trunk prefix
  ['+54 9 341 1234567', true],
  ['011 12345678', true], // 8 digit subscriber
  ['+54 11 1234567', true], // 7 digit subscriber
  ['011 123456', true], // 6 digit subscriber
];
arPhoneTests.forEach(([phone, expected]) => {
  const result = isValidArgentinePhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`  ${status} "${phone}" -> ${result} (expected ${expected})`);
});

// Name tests
console.log('\nNAME VALIDATION:');
const nameTests = [
  ['Jane Doe', true],
  ['José María', true],
  ["O'Connor", true],
  ['Smith-Johnson', true],
  ['X Æ A-12', false],
  ['John123', false],
  ['John_Doe', false],
  ['a', true],
];
nameTests.forEach(([name, expected]) => {
  const result = isValidName(name);
  const status = result === expected ? '[OK]' : '';
  console.log(`  ${status} "${name}" -> ${result} (expected ${expected})`);
});

// Credit Card tests
console.log('\nCREDIT CARD VALIDATION:');
const ccTests = [
  ['4111111111111111', true], // Visa
  ['5500000000000004', true], // Mastercard
  ['340000000000009', true], // AmEx
  ['4111111111111112', false], // Luhn check fail
  ['1234567890123456', false], // Invalid prefix
];
ccTests.forEach(([cc, expected]) => {
  const result = isValidCreditCard(cc);
  const status = result === expected ? '[OK]' : '';
  console.log(`  ${status} "${cc}" -> ${result} (expected ${expected})`);
});

// Transformation tests
console.log('\nTRANSFORMATION TESTS:');
console.log('  capitalizeSentences:');
console.log(`    "${capitalizeSentences('hello.world')}"`);
console.log(`    "${capitalizeSentences('hello.  world')}"`);
console.log(`    "${capitalizeSentences('hello.world.how are you?i am fine')}"`);

console.log('\n  extractUrls:');
const urlText = 'Visit https://example.com/path and http://test.com. See www.google.com!';
const urls = extractUrls(urlText);
console.log(`    From: "${urlText}"`);
console.log(`    Extracted:`, urls);

console.log('\n  enforceHttps:');
console.log(`    "${enforceHttps('Visit http://example.com and https://secure.com')}"`);

console.log('\n  rewriteDocsUrls:');
console.log(`    "${rewriteDocsUrls('See http://example.com/docs/guide and http://example.com/api')}"`);
console.log(`    "${rewriteDocsUrls('See http://example.com/docs/api/v1 and http://example.com/cgi-bin/test')}"`);

console.log('\n  extractYear:');
const yearTests = [
  ['12/31/2024', '2024'],
  ['02/29/2024', '2024'],
  ['02/29/2023', 'N/A'], // Not a leap year
  ['13/01/2024', 'N/A'], // Invalid month
  ['01/32/2024', 'N/A'], // Invalid day
  ['not-a-date', 'N/A'],
];
yearTests.forEach(([input, expected]) => {
  const result = extractYear(input);
  const status = result === expected ? '[OK]' : '';
  console.log(`    ${status} "${input}" -> "${result}" (expected "${expected}")`);
});

// Puzzle tests
console.log('\nPUZZLE TESTS:');
console.log('  findPrefixedWords:');
const prefixed = findPrefixedWords('The uncompleted unfinished un UN', 'un', ['un']);
console.log(`    Found:`, prefixed);

console.log('\n  findEmbeddedToken:');
const embedded = findEmbeddedToken('test123abc 456abc abc', 'abc');
console.log(`    Found:`, embedded);

console.log('\n  isStrongPassword:');
const pwdTests = [
  ['Abc123!@#', false], // Too short (9 chars)
  ['Abc123!@#abc', true], // Good password
  ['Abc123!@#', false], // Too short
  ['abc123!@#', false], // No uppercase
  ['ABC123!@#', false], // No lowercase
  ['Abcdef!@#', false], // No digit
  ['Abc123456', false], // No symbol
  ['Abc 123!@#', false], // Has whitespace
  ['abab!@#AB1', false], // Repeated sequence
  ['Abc123!@#xyz', true], // Good password
];
pwdTests.forEach(([pwd, expected]) => {
  const result = isStrongPassword(pwd);
  const status = result === expected ? '[OK]' : '';
  console.log(`    ${status} "${pwd}" -> ${result} (expected ${expected})`);
});

console.log('\n  containsIPv6:');
const ipv6Tests = [
  ['2001:0db8:85a3:0000:0000:8a2e:0370:7334', true],
  ['2001:db8::1', true],
  ['::1', true],
  ['fe80::', true],
  ['192.168.1.1', false], // IPv4
  ['2001:db8::192.168.1.1', true], // IPv6 with embedded IPv4
];
ipv6Tests.forEach(([ip, expected]) => {
  const result = containsIPv6(ip);
  const status = result === expected ? '[OK]' : '';
  console.log(`    ${status} "${ip}" -> ${result} (expected ${expected})`);
});

console.log('\n=== ALL MANUAL TESTS COMPLETE ===');
