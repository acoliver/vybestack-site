const input = '011 1234 5678';
const cleaned = input.replace(/[\s\-()]/g, '');
console.log(`Input: "${input}"`);
console.log(`Cleaned: "${cleaned}"}`);

const fullPattern = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
const withTrunkPattern = /^0(\d{2,4})(\d{6,8})$/;

const fullMatch = cleaned.match(fullPattern);
const trunkMatch = cleaned.match(withTrunkPattern);

console.log('\nFull pattern match:', fullMatch);
console.log('Trunk pattern match:', trunkMatch);

if (fullMatch) {
  console.log('\nUsing full pattern:');
  console.log('  Area code:', fullMatch[3]);
  console.log('  Subscriber:', fullMatch[4]);
  console.log('  Area code valid:', /^[1-9]\d{1,3}$/.test(fullMatch[3]));
  console.log('  Subscriber valid:', /^\d{6,8}$/.test(fullMatch[4]));
} else if (trunkMatch) {
  console.log('\nUsing trunk pattern:');
  console.log('  Area code:', trunkMatch[1]);
  console.log('  Subscriber:', trunkMatch[2]);
  console.log('  Area code valid:', /^[1-9]\d{1,3}$/.test(trunkMatch[1]));
  console.log('  Subscriber valid:', /^\d{6,8}$/.test(trunkMatch[2]));
}
