import { isStrongPassword } from './dist/src/puzzles.js';

const pwd = 'Abc123!@#';
console.log(`Testing password: "${pwd}"`);
console.log(`Length: ${pwd.length} (>= 10: ${pwd.length >= 10})`);
console.log(`Has whitespace: ${/\s/.test(pwd)}`);
console.log(`Has uppercase: ${/[A-Z]/.test(pwd)}`);
console.log(`Has lowercase: ${/[a-z]/.test(pwd)}`);
console.log(`Has digit: ${/\d/.test(pwd)}`);
console.log(`Has symbol: ${/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(pwd)}`);

// Check repeated sequences
for (let len = 2; len <= 4; len++) {
  for (let i = 0; i <= pwd.length - len * 2; i++) {
    const segment = pwd.substring(i, i + len);
    const nextSegment = pwd.substring(i + len, i + len * 2);
    if (segment === nextSegment) {
      console.log(`Found repeated sequence of length ${len} at position ${i}: "${segment}"`);
    }
  }
}

console.log(`\nResult: ${isStrongPassword(pwd)}`);
