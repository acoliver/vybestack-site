const testCases = [
  '+54 9 11 1234 5678',
  '011 1234 5678',
  '+54 341 123 4567',
  '0341 4234567',
  '11 1234567',
  '+54 011 1234567',
];

testCases.forEach(input => {
  const cleaned = input.replace(/[\s\-()]/g, '');
  console.log(`Input: "${input}" -> Cleaned: "${cleaned}"`);

  const fullPattern = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
  const withTrunkPattern = /^0(\d{2,4})(\d{6,8})$/;

  const fullMatch = cleaned.match(fullPattern);
  const trunkMatch = cleaned.match(withTrunkPattern);

  console.log(`  Full pattern match:`, fullMatch);
  console.log(`  Trunk pattern match:`, trunkMatch);

  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = cleaned.startsWith('0');
  console.log(`  Has country code: ${hasCountryCode}, Has trunk prefix: ${hasTrunkPrefix}`);

  if (!hasCountryCode && !hasTrunkPrefix) {
    console.log(`  [ERROR] INVALID: No country code and no trunk prefix`);
  } else {
    console.log(`  [OK] Format check passed`);
  }
  console.log('');
});
