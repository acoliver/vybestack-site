import { isValidArgentinePhone } from './dist/src/validators.js';

const tests = [
  ['+54 9 11 1234 5678', true],
  ['011 1234 5678', true],
  ['+54 341 123 4567', true],
  ['0341 4234567', true],
  ['11 1234567', false],
  ['+54 011 1234567', false],
  ['+54 9 341 1234567', true],
  ['011 12345678', true],
  ['+54 11 1234567', true],
  ['011 123456', true],
];

console.log('Argentine Phone Validation Tests:\n');
tests.forEach(([phone, expected]) => {
  const result = isValidArgentinePhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} "${phone}" -> ${result} (expected ${expected})`);
});
