const cleaned = '01112345678';
const fullPattern = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
const match = cleaned.match(fullPattern);
console.log('Match:', match);
console.log('Area code:', match[3]);
console.log('Subscriber:', match[4]);
console.log('Area code validation:', /^[1-9]\d{1,3}$/.test(match[3]));
