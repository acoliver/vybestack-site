/**
 * Finds words in text that start with the given prefix, excluding words in the exceptions list.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  const uniqueMatches = new Set<string>();
  
  for (const match of matches) {
    const lowerMatch = match.toLowerCase();
    if (!exceptionsSet.has(lowerMatch)) {
      uniqueMatches.add(match);
    }
  }
  
  return Array.from(uniqueMatches);
}

/**
 * Finds occurrences of token that appear after a digit and not at the start of the string.
 * Returns the full match including all consecutive digits before the token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match one or more digits followed by the token
  // This captures the full number before the token
  const tokenPattern = new RegExp(`\\d+${escapedToken}`, 'gi');

  const matches = text.match(tokenPattern) || [];

  // Remove duplicates while preserving order
  const uniqueMatches = new Set(matches);

  return Array.from(uniqueMatches);
}

/**
 * Validates password strength:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab")
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // Look for patterns of length 2-4 that repeat
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation (::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it looks like a standalone IPv4 address and exclude those
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  if (fullIPv6.test(value.trim())) {
    return true;
  }
  
  // IPv6 with :: shorthand - various positions
  // :: at the beginning
  if (/^::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}$/.test(value.trim())) {
    return true;
  }
  
  // :: at the end
  if (/^(?:[0-9a-fA-F]{1,4}:){1,7}::$/.test(value.trim())) {
    return true;
  }
  
  // :: in the middle - this is the tricky case like 2001:db8::1
  // Match one or more groups, then ::, then one or more groups
  if (/^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}::$/.test(value.trim()) ||
      /^(?:[0-9a-fA-F]{1,4}:){1,6}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}$/.test(value.trim())) {
    return true;
  }
  
  // More permissive pattern to catch any valid IPv6 format with ::
  // This matches: any number of hex groups, ::, any number of hex groups
  const shorthandPattern = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/;
  if (shorthandPattern.test(value.trim())) {
    return true;
  }
  
  // Check if the string contains an IPv6 address (embedded in other text)
  const ipv6InText = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}/;
  const match = value.match(ipv6InText);
  
  if (match) {
    const extracted = match[0].trim();
    // Verify it's not just an IPv4
    if (!ipv4Pattern.test(extracted)) {
      return true;
    }
  }
  
  return false;
}
