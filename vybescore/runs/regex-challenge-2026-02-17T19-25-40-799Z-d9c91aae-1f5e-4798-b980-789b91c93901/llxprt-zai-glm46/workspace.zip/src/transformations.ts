/**
 * Capitalizes the first character of each sentence after .?! delimiters.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces to one
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure there's exactly one space after sentence endings
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Capitalize first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize after sentence-ending punctuation
  // Look for punctuation followed by space(s) and lowercase letter
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from text, excluding trailing punctuation.
 * Supports http, https, ftp, and www-prefixed URLs.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching common URL formats
  // More comprehensive pattern to capture full URLs including TLD
  const urlPattern = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"`{}|\\^[\]]+(?<![.,;!?)\]])/gi;
  
  const matches = text.match(urlPattern);
  
  if (!matches) {
    return [];
  }
  
  return matches;
}

/**
 * Replaces all http:// schemes with https:// while leaving existing https URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for URLs with dynamic hints (cgi-bin, query strings, legacy extensions).
 * Always upgrades scheme to https://.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match) => {
    // Parse the URL
    const url = new URL(match);
    const secureHost = 'https://example.com';
    const docsHost = 'https://docs.example.com';
    
    // Check if we should skip host rewrite
    const path = url.pathname + url.search;
    const skipHostRewrite = /\/cgi-bin/.test(path) ||
                           /[?&=]/.test(path) ||
                           /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (url.pathname.startsWith('/docs/') && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return `${docsHost}${url.pathname}${url.search}`;
    } else {
      // Just upgrade the scheme
      return `${secureHost}${url.pathname}${url.search}`;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' if the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  // Check for leap year if February
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const febDays = isLeapYear ? 29 : 28;

  if (month === 2) {
    if (day < 1 || day > febDays) {
      return 'N/A';
    }
  } else {
    if (day < 1 || day > daysInMonth[month - 1]) {
      return 'N/A';
    }
  }

  return match[3];
}
