export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to RFC 5322 with additional restrictions.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local part
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Reject leading dot in local part
  if (localPart.startsWith('.')) {
    return false;
  }
  
  // Reject double dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in domain
  if (domain.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject hyphen at start or end of domain labels
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Supports optional +1 country code.
 * Rejects invalid area codes (leading 0 or 1) and numbers that are too short.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Check that all characters are digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code must be 2-4 digits (leading digit 1-9). Subscriber number must be 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Check for parentheses first - invalid format
  if (value.includes('(') || value.includes(')')) {
    return false;
  }

  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // When country code is omitted, must have trunk prefix 0
  // Try to match with trunk prefix
  const withTrunkPattern = /^0[1-9]\d{0,2}\d{6,8}$/;
  // When country code +54 is present
  const withCountryPattern = /^\+54(?:9)?[1-9]\d{0,2}\d{6,8}$/;

  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }

  // Check basic format first
  if (cleaned.startsWith('0')) {
    if (!withTrunkPattern.test(cleaned)) {
      return false;
    }
  } else {
    if (!withCountryPattern.test(cleaned)) {
      return false;
    }
  }

  // Now extract and validate area code and subscriber number
  let digits: string;
  if (cleaned.startsWith('0')) {
    digits = cleaned.substring(1); // Remove the 0
  } else {
    digits = cleaned.substring(3); // Remove the +54
    if (digits.startsWith('9')) {
      digits = digits.substring(1); // Remove the 9
    }
  }

  // Total length should be area (2-4) + subscriber (6-8) = 8-12 digits
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }

  // Check if the original input had spaces that suggest the area code length
  const spaceCount = (value.match(/\s/g) || []).length;

  // If there are spaces, they might indicate grouping
  // Format like "+54 341 12345" suggests area code is "341"
  // Format like "+54 34 112345" suggests area code is "34"
  if (spaceCount >= 2) {
    const parts = value.trim().split(/\s+/);
    // +54 341 12345 -> parts = ['+54', '341', '12345']
    // +54 9 341 12345 -> parts = ['+54', '9', '341', '12345']
    let areaPart: string;
    let subscriberPart: string;

    if (parts[0] === '+54' && parts[1] === '9') {
      // +54 9 XXXXX XXXXX format
      areaPart = parts[2];
      subscriberPart = parts.slice(3).join('');
    } else if (parts[0] === '+54') {
      // +54 XXXXX XXXXX format
      areaPart = parts[1];
      subscriberPart = parts.slice(2).join('');
    } else if (parts[0].startsWith('0')) {
      // 0XXX XXXXX format
      areaPart = parts[0].substring(1); // Remove the 0
      subscriberPart = parts.slice(1).join('');
    } else {
      // Fall back to digit-based validation
      areaPart = '';
      subscriberPart = '';
    }

    if (areaPart && subscriberPart) {
      const areaCode = areaPart.replace(/[^\d]/g, '');
      const subscriber = subscriberPart.replace(/[^\d]/g, '');

      // Validate based on the space-delimited grouping
      if (areaCode.length >= 2 && areaCode.length <= 4 &&
          subscriber.length >= 6 && subscriber.length <= 8 &&
          /^[1-9]/.test(areaCode)) {
        return true;
      }
      // If space-delimited grouping is invalid, fail
      return false;
    }
  }

  // No clear space-based grouping, try to find a valid split
  // Try different area code lengths (2-4 digits), preferring shorter area codes
  // to match more subscribers
  for (let areaLen = 2; areaLen <= 4; areaLen++) {
    if (digits.length >= areaLen + 6 && digits.length <= areaLen + 8) {
      const areaCode = digits.substring(0, areaLen);
      const subscriber = digits.substring(areaLen);

      // Validate area code (must start with 1-9)
      if (!/^[1-9]/.test(areaCode)) {
        continue;
      }

      // Validate subscriber length (6-8 digits)
      if (subscriber.length >= 6 && subscriber.length <= 8) {
        // Valid combination found
        return true;
      }
    }
  }

  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual combinations like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, apostrophes, hyphens, and spaces
  // Reject digits, underscores, and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject if contains underscores
  if (value.includes('_')) {
    return false;
  }
  
  // Check for multiple consecutive special characters
  if (/'{2,}/.test(value) || /-{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that are too short (after trimming)
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }
  
  // Reject if starts or ends with apostrophe or hyphen
  if (trimmed.startsWith("'") || trimmed.endsWith("'") || 
      trimmed.startsWith('-') || trimmed.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks prefix, length, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7]\d{14})$/;
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  let validFormat = false;
  if (visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned)) {
    validFormat = true;
  }
  
  if (!validFormat) {
    return false;
  }
  
  // Perform Luhn checksum
  return luhnCheck(cleaned);
}

/**
 * Performs Luhn algorithm checksum validation.
 */
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
