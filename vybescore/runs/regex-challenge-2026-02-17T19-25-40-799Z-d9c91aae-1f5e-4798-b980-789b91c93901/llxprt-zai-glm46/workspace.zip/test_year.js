import { extractYear } from './dist/src/transformations.js';

const tests = [
  ['12/31/2024', '2024'],
  ['02/29/2024', '2024'],
  ['02/29/2023', 'N/A'],
  ['13/01/2024', 'N/A'],
  ['01/32/2024', 'N/A'],
  ['not-a-date', 'N/A'],
];

console.log('Extract Year Tests:\n');
tests.forEach(([input, expected]) => {
  const result = extractYear(input);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} "${input}" -> "${result}" (expected "${expected}")`);
});
