import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

interface ValidationError {
  field: string;
  message: string;
}

function validatePaginationParams(pageParam: string | undefined, limitParam: string | undefined): { errors: ValidationError[]; page?: number; limit?: number } {
  const errors: ValidationError[] = [];

  let page: number | undefined = undefined;
  let limit: number | undefined = undefined;

  if (pageParam !== undefined) {
    const pageNum = Number(pageParam);
    if (isNaN(pageNum)) {
      errors.push({ field: 'page', message: 'page must be a number' });
    } else if (!Number.isInteger(pageNum)) {
      errors.push({ field: 'page', message: 'page must be an integer' });
    } else if (pageNum <= 0) {
      errors.push({ field: 'page', message: 'page must be greater than 0' });
    } else if (pageNum > 1000) {
      errors.push({ field: 'page', message: 'page must not exceed 1000' });
    } else {
      page = pageNum;
    }
  }

  if (limitParam !== undefined) {
    const limitNum = Number(limitParam);
    if (isNaN(limitNum)) {
      errors.push({ field: 'limit', message: 'limit must be a number' });
    } else if (!Number.isInteger(limitNum)) {
      errors.push({ field: 'limit', message: 'limit must be an integer' });
    } else if (limitNum <= 0) {
      errors.push({ field: 'limit', message: 'limit must be greater than 0' });
    } else if (limitNum > 100) {
      errors.push({ field: 'limit', message: 'limit must not exceed 100' });
    } else {
      limit = limitNum;
    }
  }

  return { errors, page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);
    if (validation.errors.length > 0) {
      return res.status(400).json({
        error: 'Invalid pagination parameters',
        details: validation.errors
      });
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
