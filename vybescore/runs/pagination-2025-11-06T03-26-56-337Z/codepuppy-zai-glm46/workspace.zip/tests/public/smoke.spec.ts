import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Express } from 'express';
import type { Database } from 'sql.js';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBeGreaterThan(0);
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('validates page parameter', async () => {
    // Invalid page values
    const invalidPageValues = ['abc', '0', '-1', '1001', '1.5', ''];
    
    for (const pageValue of invalidPageValues) {
      const response = await request(app).get(`/inventory?page=${pageValue}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Invalid pagination parameters');
      expect(Array.isArray(response.body.details)).toBe(true);
    }
  });

  it('validates limit parameter', async () => {
    // Invalid limit values
    const invalidLimitValues = ['abc', '0', '-1', '101', '1.5', ''];
    
    for (const limitValue of invalidLimitValues) {
      const response = await request(app).get(`/inventory?limit=${limitValue}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Invalid pagination parameters');
      expect(Array.isArray(response.body.details)).toBe(true);
    }
  });

  it('respects custom pagination parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
  });

  it('correctly calculates hasNext flag', async () => {
    // Get first page with limit 1
    const response1 = await request(app).get('/inventory?page=1&limit=1');
    expect(response1.status).toBe(200);
    expect(response1.body.page).toBe(1);
    expect(response1.body.limit).toBe(1);
    expect(response1.body.items.length).toBe(1);
    
    // Check if there's a next page
    if (response1.body.total > 1) {
      expect(response1.body.hasNext).toBe(true);
      
      // Get the last page
      const lastPage = Math.ceil(response1.body.total / 1);
      const responseLast = await request(app).get(`/inventory?page=${lastPage}&limit=1`);
      expect(responseLast.status).toBe(200);
      expect(responseLast.body.hasNext).toBe(false);
    }
  });

  it('returns different data for different pages', async () => {
    const response1 = await request(app).get('/inventory?page=1&limit=1');
    const response2 = await request(app).get('/inventory?page=2&limit=1');
    
    if (response1.body.total > 1) {
      expect(response1.status).toBe(200);
      expect(response2.status).toBe(200);
      expect(response1.body.items[0].id).not.toBe(response2.body.items[0].id);
    }
  });
});
