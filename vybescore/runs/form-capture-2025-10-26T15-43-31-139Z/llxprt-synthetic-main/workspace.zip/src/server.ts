import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import initSqlJs from "sql.js";
import fs from "fs/promises";
import { createServer } from "http";

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "../public")));

// Set EJS as templating engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "templates"));

// Database initialization
let db: import('sql.js').Database;
const dbFilePath = path.join(__dirname, "../data/submissions.sqlite");

async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();
  
  try {
    const fileBuffer = await fs.readFile(dbFilePath);
    db = new SQL.Database(fileBuffer);
  } catch (error) {
    // File doesn't exist, create a new database
    db = new SQL.Database();
    console.log("Creating new database file");
  }
  
  // Run schema to ensure tables exist
  const schema = await fs.readFile(
    path.join(__dirname, "../db/schema.sql"),
    "utf-8"
  );
  db.exec(schema);
  
  // Save the database
  await saveDatabase();
}

async function saveDatabase(): Promise<void> {
  const data = db.export();
  await fs.writeFile(dbFilePath, data);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9()\s-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  if (!formData.firstName?.trim()) {
    errors.push({ field: "firstName", message: "First name is required" });
  }
  
  if (!formData.lastName?.trim()) {
    errors.push({ field: "lastName", message: "Last name is required" });
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: "streetAddress", message: "Street address is required" });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: "city", message: "City is required" });
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: "stateProvince", message: "State/Province is required" });
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push({ field: "postalCode", message: "Postal/Zip code is required" });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: "postalCode", message: "Invalid postal code format" });
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: "country", message: "Country is required" });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: "email", message: "Email is required" });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: "email", message: "Please enter a valid email address" });
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: "phone", message: "Phone number is required" });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: "phone", message: "Please enter a valid phone number" });
  }
  
  return errors;
}

// Routes
app.get("/", (req, res) => {
  res.render("form", {
    formData: {},
    errors: {},
  });
});

app.post("/submit", (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };
  
  const validationErrors = validateForm(formData);
  
  if (validationErrors.length > 0) {
    // Convert errors array to object for easier handling in template
    const errorsObject: Record<string, string> = {};
    validationErrors.forEach((error) => {
      errorsObject[error.field] = error.message;
    });
    
    res.status(400).render("form", {
      formData,
      errors: errorsObject,
    });
    return;
  }
  
  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase().catch((err) => {
      console.error("Failed to save database:", err);
    });
  } catch (error) {
    console.error("Database error:", error);
    res.status(500).render("form", {
      formData,
      errors: { general: "An error occurred. Please try again." },
    });
    return;
  }
  
  // Redirect to thank you page with the first name
  res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName || "")}`);
});

app.get("/thank-you", (req, res) => {
  const firstName = req.query.firstName as string || "friend";
  
  res.render("thank-you", {
    firstName,
  });
});

// Start server and initialize database
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = createServer(app);
  
  server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
  
  // Handle graceful shutdown
  const gracefulShutdown = (): void => {
    console.log("Shutting down server...");
    server.close(async () => {
      console.log("Server closed");
      
      try {
        // Close database
        if (db) db.close();
        console.log("Database connection closed");
      } catch (error) {
        console.error("Error closing database:", error);
      }
      
      process.exit(0);
    });
  };
  
  // Listen for termination signals
  process.on("SIGTERM", gracefulShutdown);
  process.on("SIGINT", gracefulShutdown);
}

// Start the server
startServer().catch((error) => {
  console.error("Failed to start server:", error);
  process.exit(1);
});