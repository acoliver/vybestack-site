// Type definitions for sql.js library
declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): unknown[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  export function init(): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;

  export default init;
}