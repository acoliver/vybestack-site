export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CLIOptions {
  dataPath: string;
  format: "markdown" | "text";
  outputPath?: string;
  includeTotals: boolean;
}

export interface Formatter {
  render(data: ReportData, includeTotals: boolean): string;
}
