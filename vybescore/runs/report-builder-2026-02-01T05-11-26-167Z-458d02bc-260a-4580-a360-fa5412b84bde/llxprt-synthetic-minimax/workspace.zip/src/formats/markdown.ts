import { ReportData } from "../types.js";

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const entries = data.entries.map(entry => `- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;
  output += entries.join("\n");
  
  if (includeTotals) {
    output += `\n\n**Total:** $${total.toFixed(2)}`;
  }
  
  return output;
}
