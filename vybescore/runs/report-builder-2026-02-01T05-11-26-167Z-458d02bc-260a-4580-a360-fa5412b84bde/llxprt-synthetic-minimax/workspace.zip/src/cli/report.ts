#!/usr/bin/env node

import { readFileSync, writeFileSync } from "fs";
import { resolve } from "path";
import { renderMarkdown } from "../formats/markdown.js";
import { renderText } from "../formats/text.js";
import { ReportData, CLIOptions } from "../types.js";

function parseArgs(args: string[]): CLIOptions {
  if (args.length < 3) {
    throw new Error("Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]");
  }

  const dataPath = resolve(args[2]);
  
  let format: "markdown" | "text" | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case "--format":
        format = args[i + 1] as "markdown" | "text";
        i++;
        break;
      case "--output":
        outputPath = args[i + 1];
        i++;
        break;
      case "--includeTotals":
        includeTotals = true;
        break;
      default:
        if (args[i].startsWith("--")) {
          throw new Error(`Unknown option: ${args[i]}`);
        }
        break;
    }
  }

  if (!format) {
    throw new Error("Missing required option: --format");
  }

  if (format !== "markdown" && format !== "text") {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, "utf8");
    const data = JSON.parse(content);

    // Validate required fields
    if (!data.title || !data.summary || !data.entries) {
      throw new Error("Invalid JSON structure: missing required fields (title, summary, entries)");
    }

    // Validate entries array
    if (!Array.isArray(data.entries)) {
      throw new Error("Invalid JSON structure: entries must be an array");
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.amount !== "number") {
        throw new Error(`Invalid entry at index ${i}: missing label or non-numeric amount`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to load report data: ${error.message}`);
    }
    throw new Error("Failed to load report data: Unknown error");
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case "markdown":
      return renderMarkdown(data, includeTotals);
    case "text":
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, "utf8");
  } else {
    process.stdout.write(content + "\n");
  }
}

// Main execution
try {
  const options = parseArgs(process.argv);
  const data = loadReportData(options.dataPath);
  const output = renderReport(data, options.format, options.includeTotals);
  writeOutput(output, options.outputPath);
} catch (error) {
  console.error(error instanceof Error ? error.message : "Unknown error");
  process.exit(1);
}
