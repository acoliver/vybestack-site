import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const MAX_LIMIT = 100;

  // Validate and parse page parameter
  let page: number;
  if (options.page === undefined || options.page === null) {
    page = 1;
  } else {
    const parsed = Number(options.page);
    if (isNaN(parsed) || !Number.isInteger(parsed) || parsed < 1) {
      throw new Error('page must be a positive integer greater than 0');
    }
    page = parsed;
  }

  // Validate and parse limit parameter
  let limit: number;
  if (options.limit === undefined || options.limit === null) {
    limit = DEFAULT_LIMIT;
  } else {
    const parsed = Number(options.limit);
    if (isNaN(parsed) || !Number.isInteger(parsed) || parsed < 1) {
      throw new Error('limit must be a positive integer greater than 0');
    }
    if (parsed > MAX_LIMIT) {
      throw new Error('limit must not exceed 100');
    }
    limit = parsed;
  }

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
