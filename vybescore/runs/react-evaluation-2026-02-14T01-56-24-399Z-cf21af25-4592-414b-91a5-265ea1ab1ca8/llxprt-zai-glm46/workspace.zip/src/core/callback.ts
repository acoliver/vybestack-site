/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const dependentObservers: ObserverR[] = []

  const observer: Observer<T> = {
    value,
    updateFn,
    notify: () => {
      // Re-run callback
      updateObserver(observer)
      
      // Notify all dependent observers
      for (const dep of dependentObservers) {
        if (dep.notify) {
          dep.notify()
        }
      }
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    observer.notify = undefined
  }
}
