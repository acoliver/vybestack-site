/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with
 * supplied function which computes current value
 * of closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store references to observers that depend on this computed
  const dependentObservers: ObserverR[] = []

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    notify: () => {
      // Re-compute this computed value
      updateObserver(observer)
      
      // Notify all dependent observers
      for (const dep of dependentObservers) {
        if (dep.notify) {
          dep.notify()
        }
      }
    }
  }

  // Initialize computed value
  updateObserver(observer)

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()

    // If there's an active observer (another computed or callback),
    // register this computed as a dependency
    if (activeObserver && !dependentObservers.includes(activeObserver)) {
      dependentObservers.push(activeObserver)
    }

    return observer.value!
  }

  return getter
}
