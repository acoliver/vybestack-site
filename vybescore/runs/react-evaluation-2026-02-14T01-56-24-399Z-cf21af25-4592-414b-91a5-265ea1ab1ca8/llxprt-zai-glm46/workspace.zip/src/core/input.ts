/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via accessor and changed via
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  // Store references to observers that depend on this input
  const dependentObservers: ObserverR[] = []

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !dependentObservers.includes(observer)) {
      dependentObservers.push(observer)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all dependent observers when value changes
    for (let i = dependentObservers.length - 1; i >= 0; i--) {
      const obs = dependentObservers[i]
      if (obs.notify) {
        obs.notify()
      }
    }
    
    return s.value
  }

  return [read, write]
}
