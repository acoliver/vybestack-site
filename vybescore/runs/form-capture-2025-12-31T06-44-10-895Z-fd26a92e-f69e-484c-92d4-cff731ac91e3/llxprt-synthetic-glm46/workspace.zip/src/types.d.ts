declare module "sql.js" {
  class Database {
    constructor(data?: Uint8Array);
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): void;
    export(): Uint8Array;
    close(): void;
  }
  
  interface SqlJsStatic {
    Database: typeof Database;
  }
  
  export default function(initOptions?: unknown): Promise<SqlJsStatic>;
}