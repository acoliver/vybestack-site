import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import type { Database } from "sql.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const initSqlJs = await import("sql.js");
    const initDb = initSqlJs.default;
    
    const dataDirPath = path.join(__dirname, "..", "..", "data");
    const dataPath = path.join(dataDirPath, "submissions.sqlite");
    const basePath = path.dirname(__dirname);
    const schemaPath = path.join(basePath, "db", "schema.sql");
    
    const SQL = await initDb();
    
    if (fs.existsSync(dataPath)) {
      const filebuffer = fs.readFileSync(dataPath);
      db = new SQL.Database(filebuffer);
    } else {
      db = new SQL.Database();
    }
    
    const schema = fs.readFileSync(schemaPath, "utf8");
    db.exec(schema);
  } catch (error) {
    console.error("Database initialization error:", error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  const dataDirPath = path.join(__dirname, "..", "..", "data");
  const dataPath = path.join(dataDirPath, "submissions.sqlite");
  
  if (!fs.existsSync(dataDirPath)) {
    fs.mkdirSync(dataDirPath, { recursive: true });
  }
  
  try {
    const data = db.export();
    fs.writeFileSync(dataPath, Buffer.from(data));
  } catch (error) {
    console.error("Error saving database:", error);
  }
}

function validateFormData(formData: FormData): FormErrors {
  const errors: FormErrors = {};
  
  if (!formData.firstName?.trim()) {
    errors.firstName = "First name is required";
  }
  
  if (!formData.lastName?.trim()) {
    errors.lastName = "Last name is required";
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.streetAddress = "Street address is required";
  }
  
  if (!formData.city?.trim()) {
    errors.city = "City is required";
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.stateProvince = "State/Province/Region is required";
  }
  
  if (!formData.postalCode?.trim()) {
    errors.postalCode = "Postal/Zip code is required";
  }
  
  if (!formData.country?.trim()) {
    errors.country = "Country is required";
  }
  
  if (!formData.email?.trim()) {
    errors.email = "Email is required";
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.email = "Please enter a valid email address";
    }
  }
  
  if (!formData.phone?.trim()) {
    errors.phone = "Phone number is required";
  } else {
    const phoneRegex = /^[+]?\d[\d\s\-()]*$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.phone = "Please enter a valid phone number";
    }
  }
  
  return errors;
}

function insertSubmission(formData: FormData): void {
  const sql = `
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  
  try {
    if (db) {
      db.run(sql, [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      saveDatabase();
    }
  } catch (error) {
    console.error("Error inserting submission:", error);
    throw error;
  }
}

const app = express();
const port = process.env.PORT || "3535";

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "templates"));

app.use(express.static(path.join(__dirname, "..", "..", "public")));
app.use(express.urlencoded({ extended: true }));

app.get("/", (_req, res) => {
  res.render("form", { errors: [], values: {} });
});

app.post("/submit", (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const errors = validateFormData(formData);
  
  if (Object.keys(errors).length > 0) {
    res.status(400).render("form", {
      errors,
      values: formData
    });
    return;
  }
  
  insertSubmission(formData);
  res.redirect("/thank-you");
});

app.get("/thank-you", (req, res) => {
  const firstName = req.body.firstName || "friend";
  res.render("thank-you", { firstName });
});

async function startServer(): Promise<express.Express> {
  try {
    await initializeDatabase();
    
    const server = app.listen(Number(port), () => {
      console.log(`Server running on port ${port}`);
    });
    
    const gracefulShutdown = () => {
      console.log("Shutting down gracefully...");
      if (db) {
        db.close();
        db = null;
      }
      server.close(() => {
        console.log("Server closed");
        process.exit(0);
      });
    };
    
    process.on("SIGTERM", gracefulShutdown);
    process.on("SIGINT", gracefulShutdown);
    
    return app;
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

// Only start the server if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  void startServer();
}

export { startServer };
export default app;
