/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Collapse multiple spaces into single spaces
  const processed = text.replace(/\s+/g, ' ').trim();
  
  // Step 2: Split by sentence terminators (.?!)
  // Use regex to capture the terminators and following text
  const sentences = processed.split(/([.!?])/);
  
  let result = '';
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const terminator = sentences[i + 1];
    
    if (sentence && sentence.trim()) {
      // Capitalize first letter of non-empty sentence
      let capitalizedSentence = sentence.trim();
      capitalizedSentence = capitalizedSentence.charAt(0).toUpperCase() + capitalizedSentence.slice(1);
      
      if (result && !result.endsWith(' ')) {
        result += ' ';
      }
      result += capitalizedSentence;
      
      if (terminator) {
        result += terminator;
      }
    } else if (terminator && !result.endsWith(terminator)) {
      result += terminator;
    }
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with various schemes and domains
  // Excludes trailing punctuation like . , ! ? 
  const urlRegex = /\b(?:https?|ftp):\/\/[^\s\)]+(?<![,.!?])/gi;
  
  const matches = text.match(urlRegex) || [];
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using negative lookahead to avoid matching https://
  return text.replace(/\bhttp:\/\/(?!\/)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This regex matches http://example.com/ URLs and captures domain and full path
  // We use a function replacement to handle the complex conditions
  return text.replace(
    /\bhttp:\/\/([a-zA-Z0-9.-]+)(\/[^\s\)]*)/gi,
    (match, domain, fullPath) => {
      // Always upgrade to https
      const secureScheme = 'https://';
      
      // Remove the leading slash from the path for easier processing
      const path = fullPath.substring(1);
      
      // Check if we should skip host rewrite due to dynamic hints
      const hasDynamicHints = /cgi-bin|[?&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(path);
      
      // Check if path starts with docs/
      const hasDocsPath = /^docs\//.test(path);
      
      if (!hasDynamicHints && hasDocsPath) {
        // Rewrite host to docs.example.com when conditions are met
        return `${secureScheme}docs.${domain}${fullPath}`;
      } else {
        // Just upgrade the scheme to https
        return `${secureScheme}${domain}${fullPath}`;
      }
    }
  );
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for days in month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  let maxDays = daysInMonth[month - 1];
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
      maxDays = 29;
    }
  }
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
