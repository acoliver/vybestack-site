export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic regex for email validation
  // Local part: letters, digits, ., _, %, +, -, but no consecutive dots or trailing dots
  // Domain: letters, digits, hyphens, but no underscores
  const emailRegex = /^[a-zA-Z0-9.%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks:
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Domain cannot contain underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }
  
  // No trailing dots in local or domain part
  const localPart = value.split('@')[0];
  if (localPart.endsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators for validation
  const cleaned = value.replace(/[\s\-\(\)]/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  }
  
  // US phone numbers should be 10 digits after removing country code
  if (!/^\d{10}$/.test(phoneNumber)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Basic format validation with common patterns
  // Accept formats like (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators for easier validation
  const cleaned = value.replace(/[\s\-]/g, '');
  
  let phoneNumber = cleaned;
  
  // Handle optional country code +54
  if (phoneNumber.startsWith('+54')) {
    phoneNumber = phoneNumber.substring(3);
  } else if (phoneNumber.startsWith('54')) {
    phoneNumber = phoneNumber.substring(2);
  } else {
    // If no country code, must have trunk prefix
    if (!phoneNumber.startsWith('0')) {
      return false;
    }
  }
  
  // Handle optional trunk prefix 0
  if (phoneNumber.startsWith('0')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Handle optional mobile indicator 9
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Now we should have area code + subscriber number
  // Area code must be 2-4 digits, leading digit 1-9
  let areaCodeLength = 0;
  for (let i = 2; i <= 4; i++) {
    if (phoneNumber.length >= i + 6 && /^[1-9]\d{0,2}$/.test(phoneNumber.substring(0, i))) {
      areaCodeLength = i;
      break;
    }
  }
  
  if (areaCodeLength === 0) {
    return false;
  }
  
  const areaCode = phoneNumber.substring(0, areaCodeLength);
  const subscriberNumber = phoneNumber.substring(areaCodeLength);
  
  // Area code validation
  if (!/^[1-9]\d{0,2}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // Simplified validation: the logic above should handle most cases
  // We already validated all the required components
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented), apostrophes, hyphens, spaces
  // Reject digits and symbols like '@', '#', '$', etc.
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  // Reject obvious invalid names like "X Æ A-12" (contain digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with hyphen or apostrophe
  if (/^[\-'\s]|[\-'\s]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces, hyphens, and other non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Validate card prefix and length for major card types
  const isVisa = /^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16);
  const isMastercard = /^5[1-5]/.test(cleaned) && cleaned.length === 16;
  const isAmex = /^3[47]/.test(cleaned) && cleaned.length === 15;
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}
