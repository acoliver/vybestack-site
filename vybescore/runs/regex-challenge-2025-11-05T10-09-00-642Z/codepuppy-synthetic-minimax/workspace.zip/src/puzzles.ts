/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple approach: split by word boundaries and filter
  const words = text.match(/\b\w+\b/g) || [];
  
  const prefixedWords = words.filter(word => {
    return word.toLowerCase().startsWith(prefix.toLowerCase());
  });
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = prefixedWords.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => exception.toLowerCase() === lowerMatch);
  });
  
  // Remove duplicates and return as array
  return [...new Set(filteredMatches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple approach: manual iteration to find tokens after digits
  const results: string[] = [];
  const tokenLength = token.length;
  
  for (let i = 0; i <= text.length - tokenLength; i++) {
    const substring = text.substring(i, i + tokenLength);
    
    if (substring === token) {
      // Check if it's not at the start and is preceded by a digit
      if (i > 0 && /\d/.test(text[i - 1])) {
        // Return the full match including the preceding digit
        const fullMatch = text.substring(i - 1, i + tokenLength);
        results.push(fullMatch);
        // Move past this occurrence to avoid overlapping matches
        i += tokenLength - 1;
      }
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // Look for any 2-character sequence repeated immediately
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern - look for hexadecimal digits separated by colons
  // This pattern will match IPv6 addresses but not pure IPv4 addresses
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}\b/g;
  
  // Also look for :: shorthand
  const ipv6ShortRegex = /\b::[0-9a-fA-F]+\b|\b[0-9a-fA-F]{1,4}::\b/g;
  
  // IPv4 pattern to exclude
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  
  // Find all potential IPv6 matches
  const ipv6Matches = value.match(ipv6Regex) || [];
  const ipv6ShortMatches = value.match(ipv6ShortRegex) || [];
  const allPotentialMatches = [...ipv6Matches, ...ipv6ShortMatches];
  
  if (allPotentialMatches.length === 0) {
    return false;
  }
  
  // Check if any match contains colons (characteristic of IPv6) and is not just IPv4
  for (const match of allPotentialMatches) {
    if (match.includes(':') && !ipv4Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}