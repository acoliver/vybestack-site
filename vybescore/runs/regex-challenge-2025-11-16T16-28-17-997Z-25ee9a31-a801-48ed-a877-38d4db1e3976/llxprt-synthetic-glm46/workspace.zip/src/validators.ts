export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that handles typical cases including
  // names with + tags, multiple subdomains, and various TLDs
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Quick format check first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // No consecutive dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // No underscores in domain part (after @)
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // No trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Must have at least one character before @ and after
  const parts = value.split('@');
  if (parts.length !== 2 || parts[0].length === 0 || parts[1].length === 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code and strip it if present
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // US phone numbers should be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check for invalid area codes
  // Some area codes are reserved or invalid
  const invalidAreaCodes = ['555'];
  if (invalidAreaCodes.includes(areaCode)) {
    return false;
  }
  
  // Central office code (digits 4-6) cannot start with 0 or 1
  const centralOfficeCode = phoneNumber.substring(3, 6);
  if (centralOfficeCode[0] === '0' || centralOfficeCode[0] === '1') {
    return false;
  }
  
  // Basic format validation to ensure the input looks like a phone number
  const phoneRegex = /^(?:\+?1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex supporting:
  // - Optional +54 country code
  // - Optional 0 trunk prefix
  // - Optional 9 mobile indicator
  // - Area code: 2-4 digits (leading 1-9)
  // - Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0|9)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits starting with 1-9 (already enforced by regex)
  // Subscriber number must be 6-8 digits (already enforced by regex)
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement name validation.
 * Requirements are described in problem.md.
 */
export function isValidName(value: string): boolean {
  // Accept unicode letters, accents, apostrophes, hyphens, spaces.
  // Reject X Æ A-12 type names (no digits, symbols)
  // Must contain at least one letter
  if (!value || value.length === 0) {
    return false;
  }

  // Check for invalid characters (digits and certain symbols)
  if (/[0-9<>\[\]{}`~@#$%^&*()+=|\\]/.test(value)) {
    return false;
  }

  // Must contain at least one letter (unicode supported)
  if (!/\p{L}/u.test(value)) {
    return false;
  }

  // Allow only letters (including accented), spaces, apostrophes, and hyphens
  const validNameRegex = /^[\p{L}\p{M}'\-\s\.]+$/u;
  
  return validNameRegex.test(value);
}

/**
 * TODO: Implement credit card validation with Luhn checksum.
 * Requirements are described in problem.md.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits first
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if the card number is empty
  if (!cardNumber) {
    return false;
  }
  
  // Check length based on card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  // Visa pattern
  const visaRegex = /^4(\d{12}|\d{15})$/;
  // Mastercard pattern (complex range checking)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|\d{3,4})\d{12}$/;
  // AmEx pattern
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card matches any of the known patterns
  const isValidFormat = visaRegex.test(cardNumber) || 
                       mastercardRegex.test(cardNumber) || 
                       amexRegex.test(cardNumber);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cardNumber);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}