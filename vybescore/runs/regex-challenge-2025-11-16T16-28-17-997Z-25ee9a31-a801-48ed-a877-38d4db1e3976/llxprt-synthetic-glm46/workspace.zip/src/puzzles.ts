/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to find words starting with the prefix
  // \b ensures we match whole words, \w+ matches the rest of the word
  const prefixedWordRegex = new RegExp(`\\b(${prefix}\\w+)`, 'g');
  
  const matches = text.match(prefixedWordRegex) || [];
  
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex in case it contains special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a lookbehind to ensure the token is preceded by a digit
  const embeddedTokenRegex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Use matchAll to ensure we capture the full matched token with its digit prefix
  const fullMatches = [...text.matchAll(new RegExp(`(\\d${escapedToken})`, 'g'))];
  
  return fullMatches.map(match => match[0]);
}

/**
 * TODO: Validate password strength according to complex requirements.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must not contain immediate repeated sequences (e.g., "abab", "1212")
  // This pattern checks for any 2-character sequence repeated immediately
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns that match various IPv6 formats including shorthand (::)
  // Standard IPv6 format: 8 groups of 4 hex digits separated by colons
  const standardIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressed zeros)
  const compressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with subnet notation (%)
  const ipv6WithSubnet = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}%\d+\b/;
  
  // IPv6 embedded in IPv4
  const ipv4EmbeddedIPv6 = /\b(?:0:){5}(ffff:)?(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Test if the string contains IPv6
  if (standardIPv6Regex.test(value) || compressedIPv6Regex.test(value) || ipv6WithSubnet.test(value) || ipv4EmbeddedIPv6.test(value)) {
    return true;
  }
  
  return false;
}