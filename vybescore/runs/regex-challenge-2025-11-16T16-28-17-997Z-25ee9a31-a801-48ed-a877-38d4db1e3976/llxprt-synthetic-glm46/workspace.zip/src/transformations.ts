/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize multiple spaces to a single space, but not within abbreviations
  let result = text;
  
  // Pattern to match sentence boundaries: positions preceded by .?! and possibly quote marks,
  // followed by optional whitespace, then a lowercase letter
  const sentenceRegex = /([.!?]\s*)([a-z])/g;
  
  // Capitalize the first letter after sentence endings
  result = result.replace(sentenceRegex, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize the very first character of the string
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Ensure exactly one space between sentences by replacing multiple spaces with single space
  // when they appear after sentence punctuation
  const punctuationSpaceRegex = /([.!?])\s+/g;
  result = result.replace(punctuationSpaceRegex, '$1 ');
  
  // Clean up any double spaces that may result from our transformations
  return result.replace(/\s{2,}/g, ' ').trim();
}

/**
 * TODO: Extract all URLs from the text, cleaning trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Enhanced regex pattern to match URLs with various protocols, subdomains, and path structures
  // This pattern captures URLs starting with http://, https://, www., or domain names with TLDs
  const urlRegex = /(https?:\/\/|www\.|[a-zA-Z0-9-]+\.[a-zA-Z]{2,})(?:[^\s<>"{}|^`[\]]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation: . , ; : ? ! ) ] } " ' 
    return url.replace(/[.,;:?!)\\]\}"']+$/, '');
  });
  
  // Filter out potential partial matches that are clearly not real URLs
  return cleanedUrls.filter(url => {
    // Must have at least one dot in the domain part (excluding www.)
    const hasValidDomain = /\..+\./.test(url) || /^www\./.test(url) || /^https?:\/\//.test(url);
    
    // If it starts with www., it should have at least one more dot
    if (url.startsWith('www.') && !url.includes('.', 4)) {
      return false;
    }
    
    return hasValidDomain;
  });
}

/**
 * TODO: Upgrade http:// to https://, leaving existing https:// untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// URLs with https://, but don't touch https:// URLs
  // This uses negative lookbehind to avoid matching https://
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite specific documentation URLs according to problem.md rules.
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = enforceHttps(text);
  
  // Pattern to match https://example.com URLs
  // We need to handle cases where path starts with /docs/ but skip when path contains cgi-bin, query strings, or certain extensions
  result = result.replace(/https:\/\/example\.com(\/[^?\s]*)/g, (match, path) => {
    // Extract the path part
    const fullPath = path;
    
    // Check if the path contains dynamic hints or legacy extensions
    const skipHostRewrite = /\/cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(fullPath);
    
    // If path starts with /docs/ and doesn't contain skip patterns, rewrite host to docs.example.com
    if (fullPath.startsWith('/docs/') && !skipHostRewrite) {
      return `https://docs.example.com${fullPath}`;
    }
    
    // Otherwise, keep the upgraded https:// URL with original host
    return `https://example.com${fullPath}`;
  });
  
  return result;
}

/**
 * TODO: Extract year from mm/dd/yyyy format, return N/A if invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Basic validation for day based on month
  // February (month 2)
  if (monthNum === 2) {
    // Check for leap year (simplified)
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    const maxDay = isLeapYear ? 29 : 28;
    if (dayNum > maxDay) {
      return 'N/A';
    }
  }
  // Months with 30 days: April, June, September, November
  else if ([4, 6, 9, 11].includes(monthNum) && dayNum > 30) {
    return 'N/A';
  }
  // Months with 31 days: January, March, May, July, August, October, December
  else if ([1, 3, 5, 7, 8, 10, 12].includes(monthNum) && dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}