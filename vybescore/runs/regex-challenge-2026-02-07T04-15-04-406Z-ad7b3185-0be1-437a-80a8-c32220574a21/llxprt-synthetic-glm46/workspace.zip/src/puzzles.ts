/**
 * Find words starting with the prefix but excluding the provided exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }

  /**
   * Word finding pattern breakdown:
   * - Use regex to find words starting with the prefix
   * - Implement word boundaries (\b) to match complete words
   * - Filter out words in the exceptions list
   */
  
  // Create the regex pattern dynamically based on the prefix
  const prefixRegex = new RegExp(`\\b${escapeRegExp(prefix)}[a-zA-Z]*`, 'g');
  

  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions and deduplicate
  const results = matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptions.some(ex => word === ex || word.startsWith(ex + ' ')))
    .reduce((unique: string[], word) => {
      if (!unique.includes(word)) {
        unique.push(word);
      }
      return unique;
    }, []);
  
  return results;
}

// Helper function to escape special regex characters
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  /**
   * Embedded token regex pattern breakdown:
   * - Use lookbehind to ensure the token is preceded by a digit
   * - Use lookahead to ensure it's not at the beginning of the string
   * - Dynamic regex construction based on the token parameter
   */
  
// Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern that looks for the token preceded by a digit
  // Using positive lookbehind: (?<=\d) ensures it comes after a digit
  // Using negative lookahead to ensure not at start: (?<!^)
 const embeddedTokenPattern = `(?<!^)(?<=\\d)${escapedToken}`;
  
  try {
    const regex = new RegExp(embeddedTokenPattern, 'g');
    const matches = text.match(regex) || [];
    
    return matches.reduce((unique: string[], match) => {
      if (!unique.includes(match)) {
        unique.push(match);
      }
      return unique;
    }, []);
  } catch (e) {
    // Fallback for environments that don't support lookbehind
    const fallbackPattern = new RegExp(`[0-9]${escapedToken}`, 'g');
    const rawMatches = text.match(fallbackPattern) || [];
    
    // Strip the leading digit from each match to return just the token
    return rawMatches
      .map(match => match.substring(1))
      .reduce((unique: string[], token) => {
        if (!unique.includes(token)) {
          unique.push(token);
        }
        return unique;
      }, []);
  }
}

/**
 * Validates password strength according to:
 * - At least 10 characters
 * - One uppercase, one lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab')
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // Basic length requirement
  if (value.length < 10) {
    return false;
  }

  /**
   * Password requirements breakdown:
   * 1. At least one uppercase letter
   * 2. At least one lowercase letter
   * 3. At least one digit
   * 4. At least one symbol (non-alphanumeric)
   * 5. No whitespace
   * 6. No immediate repeated sequences (e.g., 'abab')
   */
  
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=\[\]{};':"|,.<>\/?]/.test(value);
  const hasWhitespace = /\s/.test(value);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }

  // Check for repeated sequences like 'abab', '123123', etc.
  for (let i = 0; i < value.length - 3; i++) {
    const segment = value.substring(i, i + 4);
    const firstTwo = segment.substring(0, 2);
    
    if (segment.endsWith(firstTwo)) {
      return false;
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) and ensures IPv4 addresses don't trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  /**
   * IPv6 detection with regex breakdown:
   * 1. Check for IPv4 pattern to exclude
   * 2. Check for IPv6 patterns in increasing specificity
   * 3. Handle both standard and compressed forms with ::
   */
  
  // First, check if the entire string is an IPv4 address - if so, return false
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }

// IPv6 regex patterns
  
  // Use word boundaries to avoid partial matches
  const ipv6Pattern = /\b(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}|::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}:|(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})\b/;

  // Test if value contains IPv6 but not just IPv4
  return ipv6Pattern.test(value);
}
