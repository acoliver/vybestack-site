/**
 * Capitalizes the first character of each sentence.
 * Uses regex to detect sentence boundaries (., ?, !)
 * Maintains single spacing between sentences and handles abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') {
    return text;
  }

  /**
   * Process to capitalize each sentence:
   * 1. Find sentence boundaries using regex (., ?, !)
   * 2. Skip patterns that look like abbreviations (e.g., Mr., Dr., etc.)
   * 3. Capitalize the first letter after boundaries
   * 4. Ensure single spacing between sentences
   */

  // Normalize spacing
  const normalizedText = text.replace(/\s+/g, ' ').trim();
  
  if (normalizedText.length === 0) {
    return normalizedText;
  }

  // Common abbreviations to avoid breaking sentences at
  const abbreviations = ['mr', 'mrs', 'dr', 'prof', 'sr', 'jr', 'st', 'ms', 'sgt', 'capt', 'maj', 'gen', 'hon', 'rep', 'sen', 'pres', 'gov', 'pres', 'atty', 'pvt', 'lt', 'col', 'gen', 'adm', 'asst', 'rev', 'etc', 'vs', 'no', 'vol'];
  const abbreviationPattern = new RegExp(`\\b(?:${abbreviations.join('|')})\\.$`, 'i');

  const result = normalizedText.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, firstLetter, offset) => {
    // Check if this might be an abbreviation
    const precedingText = normalizedText.substring(0, offset);
    const words = precedingText.split(' ');
    const lastTwoWords = words.slice(-3).join(' ');
    
    // If this looks like an abbreviation, don't capitalize
    if (abbreviationPattern.test(lastTwoWords)) {
      return match;
    }
    
    return prefix + firstLetter.toUpperCase();
  });

  // Ensure first character is capitalized
  return result.charAt(0).toUpperCase() + result.slice(1);
}

/**
 * Extracts all URLs from the given text using regex.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string') {
    return [];
  }

  /**
   * URL extraction regex pattern:
   * - Starts with http:// or https://
   * - Captures everything until a word boundary URL terminator
   * - Handles domains, paths, protocols, subdomains
   */
  const urlPattern = /https?:\/\/(?:[\w-]+\.)+[a-zA-Z]{2,}(?:\/[\w.,@?^=%&:/~+#-]*(?!\w))?/g;
  
  // Find all URLs
  const urls = text.match(urlPattern) || [];
  
  // Clean up by removing trailing punctuation that isn't part of URL
  const cleanedUrls = urls.map(url => {
    // Remove trailing punctuation like . , ; : ! ? ) ] }
    // Keep only the URL string
    return url.replace(/[.,;:!?)]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Replaces all http:// URLs with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return text;
  }

  /**
   * HTTPS enforcement pattern:
   * - Matches http:// protocol only
   * - Replaces with https://
   */
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints like cgi-bin, query params, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return text;
  }

  /**
   * URL rewriting pattern breakdown:
   * 1. Match http://example.com URLs
   * 2. Upgrade to https://
   * 3. Check for /docs/ path to rewrite host
   * 4. Skip host rewrite for dynamic content (cgi-bin, ?, &, legacy extensions)
   */

  // First upgrade all http to https
  const withHttps = text.replace(/http:\/\/example\.com(\/[^ \n]*?)?/g, (match, path) => {
    if (!path) return 'https://example.com'; // Root path
    
    // Check if we should rewrite host to docs.example.com
    const isDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = /(?:cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path);
    
    if (isDocsPath && !hasDynamicHints) {
      return 'https://docs.example.com' + path;
    } else {
      return 'https://example.com' + path;
    }
  });

  return withHttps;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return 'N/A';
  }

  /**
   * Date format regex breakdown:
   * - Match mm/dd/yyyy pattern (2-digit month, 2-digit day, 4-digit year)
   * - Validate month (01-12) and day (01-31)
   */
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string as required
  
  // Additional validation for day based on month (and February leap year check)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // February leap year check
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    // Check if day exceeds days in the month
    return 'N/A';
  }
  
  return year;
}
