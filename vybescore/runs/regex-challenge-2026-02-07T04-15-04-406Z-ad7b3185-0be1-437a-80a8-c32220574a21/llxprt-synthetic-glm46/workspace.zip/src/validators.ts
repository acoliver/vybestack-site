export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like user@example.com and user.name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  /**
   * Email validation regex breakdown:
   * - Local part: letters, numbers, allowed symbols; cannot start or end with dot; cannot have consecutive dots
   * - Domain part: letters, numbers, hyphens; cannot start or end with hyphen; no underscores allowed
   * - TLD: 2-63 characters, letters only
   */
  const emailRegex = /^(?!.*\.\.)(?!.*\.$)(?!.*\.\.*@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;

  return emailRegex.test(value);
}

/**
 * Validates US phone numbers using regex.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890
 * Accepts optional +1 country code
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  // Remove all non-numeric characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional country code
  let normalizedDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    normalizedDigits = digitsOnly.substring(1);
  } else if (digitsOnly.length > 10) {
    // Too long - invalid format
    return false;
  }
  
  // Check for valid area code (can't start with 0 or 1)
  const areaCode = normalizedDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // US Phone Regex for format validation
  const phoneRegex = /^(\+1[\s-]{0,2})?(\(?\d{3}\)?[\s-]{0,2})?\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers using regex.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  /**
   * Argentine phone number validation breakdown:
   * - Country code: Optional +54
   * - Trunk prefix: Required 0 when country code is omitted
   * - Mobile indicator: Optional 9 between country/trunk and area code
   * - Area code: 2-4 digits, leading digit 1-9
   * - Subscriber number: 6-8 digits
   * - Separators: spaces or hyphens (ignored in validation)
   */
  
  // Remove all separators (spaces, hyphens) for validation
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Two main patterns:
  // 1. With country code: +54 9? areaCode subscriberNumber
  // 2. Without country code: 0 areaCode subscriberNumber
  
  const hasCountryCode = digitsOnly.startsWith('54');
  const hasTrunkPrefix = !hasCountryCode && digitsOnly.startsWith('0');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Extract components
  let subscriberNumber: string;
  
  if (hasCountryCode) {
    // Remove country code first
    const afterCountry = digitsOnly.substring(2);
    
    // Check for mobile indicator (optional)
    let remaining = afterCountry;
    if (remaining.startsWith('9')) {
      remaining = remaining.substring(1); // Remove mobile indicator
    }
    
    // Extract area code (2-4 digits starting with 1-9)
    let areaCodeLength = 0;
    let foundAreaCode = false;
    
    for (let len = 4; len >= 2; len--) {
      const potentialAreaCode = remaining.substring(0, len);
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode)) {
        areaCodeLength = len;
        foundAreaCode = true;
        break;
      }
    }
    
    if (!foundAreaCode) {
      return false;
    }
    
    // Extract subscriber number
    subscriberNumber = remaining.substring(areaCodeLength);
    
  } else {
    // Local format with trunk prefix
    // Remove trunk prefix first
    const afterTrunk = digitsOnly.substring(1);
    
    // Extract area code (2-4 digits starting with 1-9)
    let areaCodeLength = 0;
    let foundAreaCode = false;
    
    for (let len = 4; len >= 2; len--) {
      const potentialAreaCode = afterTrunk.substring(0, len);
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode)) {
        areaCodeLength = len;
        foundAreaCode = true;
        break;
      }
    }
    
    if (!foundAreaCode) {
      return false;
    }
    
    subscriberNumber = afterTrunk.substring(areaCodeLength);
  }
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // Check overall pattern with regex for complete validation
  const argentinePhonePattern = /^(?:\+54[\s-]*9?|0)[\s-]*\d{2,4}[\s-]*\d{6,8}$/;
  return argentinePhonePattern.test(value);
}

/**
 * Validates personal names using regex.
 * Permits unicode letters, accents, apostrophes, hyphens, and spaces
 * Rejects digits, symbols, and names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  /**
   * Name validation regex breakdown:
   * - \p{L}+: Unicode letters (including accented letters)
   * - ': apostrophes (for names like O'Connor)
   * - -: hyphens (for hyphenated names)
   * - \s: spaces (for names with multiple parts)
   * - Ensure at least one letter
   */
  const nameRegex = /^[\p{L}'\s-]+$/u;
  
  // Additional checks for edge cases
  // Ensure there's at least one letter (not just punctuation/symbols)
  const containsLetter = /\p{L}/u.test(value);
  
  // Reject names with obvious numbers or symbols
  const containsInvalidChars = /[0-9@#$%^&*()_+=\[\]{}<>~`|\\/:;.,?!]/.test(value);
  
  // Reject if it starts or ends with invalid characters
  const invalidStart = /^[ '\-]/.test(value);
  const invalidEnd = /[ '\-]$/g;
  
  return nameRegex.test(value) && containsLetter && !containsInvalidChars && !invalidStart && !invalidEnd;
}

/**
 * Helper function to perform Luhn algorithm checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber.charAt(i), 10);
    
    if (alternate) {
      const doubled = digit * 2;
      sum += (doubled > 9) ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using regex and Luhn checksum.
 * Accepts Visa (13 or 16 digits starting with 4), Mastercard (16 digits starting with 51-55 or 2221-2720), and AmEx (15 digits starting with 34 or 37)
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  // Remove spaces and dashes
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Ensure only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }

  /**
   * Card validation regex patterns:
   * - Visa: 13 or 16 digits starting with 4
   * - Mastercard: 16 digits starting with 51-55 or 2221-2720
   * - AmEx: 15 digits starting with 34 or 37
   */
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat = visaRegex.test(cleanNumber) || mastercardRegex.test(cleanNumber) || amexRegex.test(cleanNumber);
  
  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}
