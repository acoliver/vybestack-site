import { ReportData, CLIOptions, Renderer } from '../types.js';

export class MarkdownRenderer implements Renderer {
  render(data: ReportData, options: CLIOptions): string {
    const lines: string[] = [];
    
    // Title with heading
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('## Entries');
    
    // Bullet list for entries
    for (const entry of data.entries) {
      const amount = entry.amount.toFixed(2);
      lines.push(`- **${entry.label}** — $${amount}`);
    }
    
    // Optional totals
    if (options.includeTotals) {
      lines.push('');
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`**Total:** $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
}