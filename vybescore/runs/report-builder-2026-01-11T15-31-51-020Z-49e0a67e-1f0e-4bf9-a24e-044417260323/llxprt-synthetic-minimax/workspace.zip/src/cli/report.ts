#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';
import { ReportData, CLIOptions, Renderer } from '../types.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let dataFile = '';
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  let i = 2; // Skip node and script path
  while (i < args.length) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      // First positional argument should be data file
      if (!dataFile) {
        dataFile = arg;
      } else {
        console.error('Unexpected argument:', arg);
        process.exit(1);
      }
    } else if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('--format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('--output requires a value');
        process.exit(1);
      }
      output = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error('Unknown option:', arg);
      process.exit(1);
    }
    
    i++;
  }

  if (!dataFile) {
    console.error('Missing data file argument');
    process.exit(1);
  }

  if (!format) {
    console.error('Missing --format option');
    process.exit(1);
  }

  return { dataFile, format, output, includeTotals };
}

function parseAndValidateJSON(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: missing or invalid label`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: missing or invalid amount`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Invalid JSON:', error.message);
    } else if (error instanceof Error) {
      console.error('Validation error:', error.message);
    } else {
      console.error('Error reading file:', error);
    }
    process.exit(1);
  }
}

function createRenderer(format: string): { renderer: Renderer; formatName: string } {
  switch (format) {
    case 'markdown':
      return { renderer: new MarkdownRenderer(), formatName: 'markdown' };
    case 'text':
      return { renderer: new TextRenderer(), formatName: 'text' };
    default:
      console.error(`Unsupported format: ${format}. Supported formats: markdown, text`);
      process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const { dataFile, format, output, includeTotals } = parseArgs(args);
  
  const data = parseAndValidateJSON(dataFile);
  const { renderer, formatName } = createRenderer(format);
  
  const options: CLIOptions = {
    format: formatName as 'markdown' | 'text',
    output,
    includeTotals
  };
  
  const outputText = renderer.render(data, options);
  
  if (output) {
    writeFileSync(output, outputText);
  } else {
    console.log(outputText);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
