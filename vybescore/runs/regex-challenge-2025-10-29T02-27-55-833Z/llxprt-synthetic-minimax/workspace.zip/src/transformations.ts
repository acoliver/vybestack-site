/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Split text into sentences by finding sentence endings (.?!)
  // This regex captures the sentence ending punctuation
  const sentencePattern = /([.!?]+)(\s*)/g;
  
  let result = '';
  let lastEnd = 0;
  let match;
  let sentenceIndex = 0;
  
  // Process each sentence ending
  while ((match = sentencePattern.exec(text)) !== null) {
    // Add the text before this sentence ending
    result += text.substring(lastEnd, match.index);
    
    // Capitalize first letter of sentence if it's not already capitalized
    const sentenceStart = sentenceIndex === 0 ? 0 : result.lastIndexOf('.', match.index) + 1;
    const beforeSentence = result.substring(0, sentenceStart);
    const sentenceText = text.substring(sentenceStart, match.index);
    
    if (sentenceText.trim().length > 0) {
      // Capitalize first letter
      const capitalizedSentence = sentenceText.replace(/^\s*([a-záéíóúñü])/i, (match, p1) => match.toUpperCase());
      result += capitalizedSentence;
    } else {
      result += sentenceText;
    }
    
    // Add the sentence ending punctuation and normalize spacing
    const punctuation = match[1];
    const spacing = match[2];
    
    // Ensure exactly one space after sentence ending (if there's more text)
    if (sentencePattern.lastIndex < text.length) {
      result += punctuation + ' ';
    } else {
      result += punctuation;
    }
    
    lastEnd = sentencePattern.lastIndex;
    sentenceIndex++;
  }
  
  // Handle remaining text after last sentence
  if (lastEnd < text.length) {
    const remainingText = text.substring(lastEnd);
    if (remainingText.trim().length > 0) {
      // Capitalize first letter if needed
      result += remainingText.replace(/^\s*([a-záéíóúñü])/i, (match, p1) => match.toUpperCase());
    } else {
      result += remainingText;
    }
  }
  
  // Clean up multiple spaces (except single spaces after sentence endings)
  result = result.replace(/ {2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || text.length === 0) {
    return [];
  }
  
  // URL regex pattern that captures URLs and removes trailing punctuation
  const urlPattern = /\b((?:https?:\/\/|www\.)[^\s<>"')\]}.,;!?]+[^\s<>"')\]}.,;!?])/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation that commonly follows URLs
    url = url.replace(/[.,;:!?]+$/, '');
    
    // Add https:// prefix if missing for www URLs
    if (url.startsWith('www.')) {
      url = 'https://' + url;
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Replace http:// with https:// but leave https:// unchanged
  // Using word boundary to ensure we don't match partial matches
  const httpsPattern = /\bhttp:\/\//gi;
  
  return text.replace(httpsPattern, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Pattern to match http://example.com/ URLs
  const docsUrlPattern = /\bhttp:\/\/example\.com\/([^\s<>"')\]}]*)/gi;
  
  return text.replace(docsUrlPattern, (match, path) => {
    // Always upgrade to https
    let newUrl = 'https://example.com/' + path;
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/')) {
      // List of dynamic hints and legacy extensions to skip host rewrite
      const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
      
      const hasDynamicHints = dynamicHints.some(hint => 
        path.includes(hint) || path.toLowerCase().includes(hint.toLowerCase())
      );
      
      if (!hasQueryString && !hasDynamicHints) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com/' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  throw new Error('TODO: implement extractYear');
}
