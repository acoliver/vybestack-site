export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  value = value.trim();
  
  // Basic structure check - must have @ and not start/end with @
  if (!value.includes('@') || value.startsWith('@') || value.endsWith('@')) {
    return false;
  }

  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // Check for trailing dot before @
  const atIndex = value.indexOf('@');
  if (atIndex > 0 && value[atIndex - 1] === '.') {
    return false;
  }

  // Check for underscores in domain
  const domain = value.substring(atIndex + 1);
  if (domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  }
  
  // Must have exactly 10 digits for US phone number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check that all characters are digits
  if (!/^\d{10}$/.test(phoneNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other punctuation except digits and +
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Pattern breakdown:
  // ^(\+54)? - optional country code +54
  // (9)? - optional mobile indicator 9
  // (0)? - optional trunk prefix 0
  // ([1-9]\d{1,3}) - area code: 2-4 digits, first digit 1-9
  // (\d{6,8})$ - subscriber number: 6-8 digits
  const pattern = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!pattern.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }
  
  const [, countryCode, mobileIndicator, trunkPrefix] = match;
  
  // When country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Remove leading/trailing whitespace for validation
  const trimmed = value.trim();
  
  // Pattern allows:
  // - Unicode letters (including accented characters)
  // - Spaces
  // - Hyphens
  // - Apostrophes
  // Rejects digits and special symbols
  const namePattern = /^[\p{L}\s\-']+$/u;
  
  if (!namePattern.test(trimmed)) {
    return false;
  }
  
  // Additional check: cannot start or end with hyphen or apostrophe
  if (/^[-\s']|[-\s']$/.test(trimmed)) {
    return false;
  }
  
  // Check for consecutive special characters (not allowed)
  if (/[-']{2,}/.test(trimmed)) {
    return false;
  }
  
  // Check for patterns like "X Æ A-12" (should fail)
  if (/[ÆØÅ]/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length === 0) {
    return false;
  }
  
  // Check card type by prefix and length
  // Visa: starts with 4, length 13-19
  const visaPattern = /^4\d{12}(\d{3})?(\d{3})?$/;
  // Mastercard: starts with 5[1-5] or 2[2-7], length 16
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  
  let isValidType = false;
  let cardLength = digitsOnly.length;
  
  if (visaPattern.test(digitsOnly) && (cardLength >= 13 && cardLength <= 19)) {
    isValidType = true;
  } else if (mastercardPattern.test(digitsOnly) && cardLength === 16) {
    isValidType = true;
  } else if (amexPattern.test(digitsOnly) && cardLength === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
