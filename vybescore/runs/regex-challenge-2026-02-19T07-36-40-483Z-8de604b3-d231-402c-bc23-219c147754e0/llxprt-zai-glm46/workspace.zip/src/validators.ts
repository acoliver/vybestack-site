export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Check for double dots or leading/trailing dots in local part
  if (localPart.includes('..') || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot contain underscores or start/end with hyphen/dot
  if (domain.includes('_') || domain.includes('..') || domain.startsWith('-') || 
      domain.endsWith('-') || domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[\s()]/g, '').replace(/-/g, '');

  let digits = cleaned;

  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.substring(1);
  }

  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  const areaCode = digits.substring(0, 3);

  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  if (areaCode[1] === '1' && areaCode[2] === '1') {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code must be 2-4 digits (leading digit 1-9).
 * Subscriber number must contain 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.replace(/[\s\-+()]/g, '');
  
  const pattern = /^(\+?54)?(9)?0?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, _mobileIndicator, areaCode, subscriber] = match;
  
  if (areaCode[0] === '0') {
    return false;
  }
  
  if (!countryCode && !value.replace(/[\s\-+()]/g, '').startsWith('0')) {
    return false;
  }
  
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  void _mobileIndicator;
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}][\p{L}\p{M}'\-\s]*[\p{L}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}
