/**
 * Finds words beginning with the prefix, excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');

  const matches = text.match(wordPattern) || [];

  return matches.filter(word =>
    word.toLowerCase().startsWith(prefix.toLowerCase()) &&
    !exceptions.includes(word)
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  /* eslint-disable no-useless-escape */
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value);
  /* eslint-enable no-useless-escape */

  if (value.length < 10) {
    return false;
  }

  if (/\s/.test(value)) {
    return false;
  }

  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);

  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }

  for (let i = 0; i < value.length - 3; i++) {
    for (let len = 2; len <= (value.length - i) / 2; len++) {
      const first = value.substring(i, i + len);
      const second = value.substring(i + len, i + len * 2);

      if (first === second) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  /* eslint-disable no-useless-escape */
  const ipv6Pattern = /(?:^|[\s\[\]():,])([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}|[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::[0-9a-fA-F]{0,4}|::1|::)(?:$|[\s\[\]():,])/;
  /* eslint-enable no-useless-escape */

  if (!ipv6Pattern.test(value)) {
    return false;
  }

  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  const ipv4Matches = value.match(ipv4Pattern) || [];

  for (const ipv4 of ipv4Matches) {
    const parts = ipv4.split('.');
    const isEmbedded = parts.every(part => parseInt(part, 10) <= 255);
    if (isEmbedded) {
      return false;
    }
  }

  return true;
}
