/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences if missing.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  let result = text;

  result = result.replace(/\s+/g, ' ');

  result = result.replace(/([.!?])(\S)/g, '$1 $2');

  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });

  result = result.charAt(0).toUpperCase() + result.slice(1);

  return result;
}

/**
 * Extracts URLs from text.
 * Returns all URLs detected without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:www\.)?[^\s<>"()[\]{}|^`]+[^\s<>"()[\]{}|^`.,!?;:]/g;

  const matches = text.match(urlRegex) || [];

  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Converts http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  /* eslint-disable no-useless-escape */
  return text.replace(/http:\/\/([^\/\s]+)/gi, 'https://$1');
  /* eslint-enable no-useless-escape */
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  /* eslint-disable no-useless-escape */
  const urlPattern = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, scheme, host, path) => {
    const newScheme = 'https://';

    if (!path.startsWith('/docs/')) {
      return newScheme + host + path;
    }

    const dynamicHints = /\/cgi-bin\/|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|\?|$)/i;

    if (dynamicHints.test(path)) {
      return newScheme + host + path;
    }

    return newScheme + 'docs.' + host + path;
  });
  /* eslint-enable no-useless-escape */
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  if (month < 1 || month > 12) {
    return 'N/A';
  }

  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  let maxDay = daysInMonth[month - 1];

  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
    maxDay = 29;
  }

  if (day < 1 || day > maxDay) {
    return 'N/A';
  }

  return year;
}
