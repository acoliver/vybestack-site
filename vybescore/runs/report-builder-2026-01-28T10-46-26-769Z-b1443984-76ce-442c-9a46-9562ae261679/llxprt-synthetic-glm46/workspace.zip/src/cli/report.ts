#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const SUPPORTED_FORMATS = ['markdown', 'text'];
const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals?: boolean;
}

const parseArgs = (argv: string[]): CliArgs => {
  if (argv.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = argv[2];
  const args: CliArgs = {
    dataPath,
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  // Parse remaining arguments
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      args.format = argv[++i];
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      args.outputPath = argv[++i];
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!args.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (!SUPPORTED_FORMATS.includes(args.format)) {
    console.error(`Error: Unsupported format: ${args.format}`);
    process.exit(1);
  }

  return args;
};

const validateReportData = (data: unknown): ReportData => {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  const entries = reportData.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }
  }

  return reportData as unknown as ReportData;
};

const main = () => {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataPath, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error('Error: Invalid JSON syntax in input file');
      } else {
        console.error(`Error reading file: ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }

    // Validate data structure
    let reportData: ReportData;
    try {
      reportData = validateReportData(jsonData);
    } catch (error) {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }

    // Render report
    const renderOptions: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    
    const renderer = formatRenderers[args.format as keyof typeof formatRenderers];
    const output = renderer(reportData, renderOptions);

    // Output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
};

main();
