/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex to handle special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find words starting with the prefix
  // \b matches word boundaries to ensure we're matching whole words
  // \w+ matches one or more word characters
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w+)`, 'g');
  
  // Find all matches in the text
  const matches = text.match(wordRegex) || [];
  
  // Filter out the exceptions
  const filteredMatches = matches.filter(word => {
    // Check if the word is in the exceptions list
    return !exceptions.includes(word);
  });
  
  // Remove duplicates by converting to Set and back to array
  return [...new Set(filteredMatches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex to handle special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern using a positive lookbehind and lookahead
  // (?<=\d) - positive lookbehind to ensure token is preceded by a digit
  // (?<!^) - negative lookbehind to ensure we're not at the start of the string
  // However, JavaScript doesn't support negative lookbehind with positive lookbehind
  // So we'll use a workaround that captures the digit and then checks position
  
  const tokenRegex = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Check that this match is not at the start of the string
    if (match.index > 0) {
      matches.push(match[0]); // Return the full match including the digit
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check for minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (anything that's not alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (abab, abcabc, etc.)
  // We'll use a regex that captures any sequence of 2+ characters and checks if it repeats
  // immediately after
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  // If all checks pass, the password is strong
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // This pattern captures:
  // - Full IPv6 (8 groups of 4 hex digits)
  // - Shorthand IPv6 with :: for zeros
  // - IPv6 with embedded IPv4 addresses
  // But excludes plain IPv4 addresses
  
  // First, check for IPv4 pattern and exclude those
  const ipv4Regex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Use a simpler IPv6 pattern that covers most common cases
  // This pattern checks for:
  // 1. Eight groups of 4 hex digits (full form)
  // 2. Any number of groups with :: for compressed zeros
  // 3. IPv6 addresses with embedded IPv4
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9]))/;
  
  return ipv6Regex.test(value);
}