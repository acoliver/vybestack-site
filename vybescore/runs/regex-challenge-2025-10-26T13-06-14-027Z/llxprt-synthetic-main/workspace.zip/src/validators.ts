export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Define a comprehensive email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for double dots, leading/trailing dots, and underscores in domain
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in the domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all spaces and hyphens for validation
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Check for optional +1 country code
  let digitsOnly = cleanedValue;
  const hasCountryCode = cleanedValue.startsWith('+1');
  if (hasCountryCode) {
    digitsOnly = cleanedValue.substring(2);
  }
  
  // Remove remaining non-digit characters (like parentheses)
  digitsOnly = digitsOnly.replace(/[^\d]/g, '');
  
  // Check if we have exactly 10 digits (US phone number)
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits) and check it doesn't start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Define regex pattern for Argentine phone numbers
  // Pattern explanation:
  // ^(?:\+54)? - Optional country code +54
  // (?:0?)? - Optional trunk prefix 0
  // (?:9)? - Optional mobile prefix 9
  // ([1-9]\d{0,3}) - Area code (2-4 digits, starting with 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{0,3})(\d{6,8})$/;
  
  // Special case: when country code is omitted, number must begin with 0
  const hasCountryCode = value.includes('+54');
  if (!hasCountryCode && !cleanedValue.startsWith('0')) {
    return false;
  }
  
  const match = argentinePhoneRegex.exec(cleanedValue);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Regex pattern to match Unicode letters, spaces, apostrophes, and hyphens
  // \p{L} matches any Unicode letter (including accented characters)
  // Allow spaces, apostrophes, and hyphens
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check for at least one character
  if (value.trim().length === 0) {
    return false;
  }
  
  // Check that the name doesn't contain digits or special symbols
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Explicitly reject some obviously invalid patterns like "X Æ A-12"
  // This is a simplified check - in a real-world scenario, you might want more sophisticated rules
  if (/\d/.test(value) || /[^\p{L}\s'-]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Define patterns for major credit card brands
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5][0-9]{14}$/; // 16 digits, starts with 51-55
  const mastercardRegex2 = /^2[2-7][0-9]{14}$/; // New Mastercard format, starts with 2221-2720
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if the number matches any of the patterns
  const isValidFormat = visaRegex.test(digitsOnly) || 
                        mastercardRegex.test(digitsOnly) || 
                        mastercardRegex2.test(digitsOnly) || 
                        amexRegex.test(digitsOnly);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn algorithm check
  return luhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn algorithm validation
 */
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through the digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      // If the result is greater than 9, subtract 9
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // The card is valid if the sum is a multiple of 10
  return sum % 10 === 0;
}
