/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Ensure there's exactly one space after each sentence-ending punctuation
  // Also handle the case where there might not be a space after punctuation
  let result = text.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Split into sentences (including abbreviations)
  // We use a regex that captures sentence boundaries followed by whitespace
  // This is a simplified approach that works for most cases
  const sentences = result.split(/([.?!]\s+)/);
  
  // Process each sentence
  for (let i = 0; i < sentences.length; i++) {
    // Skip empty strings and just punctuation marks
    if (!sentences[i] || /^[.?!]+\s*$/.test(sentences[i])) {
      continue;
    }
    
    // Trim extra whitespace
    const sentence = sentences[i].trim();
    
    // Skip if sentence starts with a lowercase letter that might be part of an abbreviation
    // This is a simple heuristic to avoid capitalizing all-lowercase abbreviations
    // For a more robust solution, you'd need a list of common abbreviations
    if (/^[a-z]/.test(sentence) && sentence.length < 3) {
      continue;
    }
    
    // Capitalize the first letter of the sentence
    if (sentence.length > 0) {
      sentences[i] = sentence[0].toUpperCase() + sentence.substring(1);
    }
  }
  
  // Join sentences back together
  result = sentences.join('');
  
  // Collapse multiple spaces into a single space
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Define regex pattern for URLs
  // This pattern matches:
  // - http:// or https:// or ftp://
  // - www. (with implied http://)
  // - Domain names with various TLDs
  // - IP addresses
  // - Optional port numbers
  // - Optional paths, query strings, and fragments
  const urlRegex = /(?:(?:https?|ftp):\/\/|www\.)[^\s/$.?#].[^\s]*|[a-z0-9.]+\.[a-z]{2,}(?:\/[^\s]*)?|(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?(?:\/[^\s]*)?/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like ., ?! etc.
    return url.replace(/[.,?!;:]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all occurrences of http:// with https://
  // Use word boundary or negative lookbehind to ensure we're matching full URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Create match groups to capture:
  // 1. The protocol (http:// or https://)
  // 2. The domain (example.com)
  // 3. The entire path including leading slash
  const urlRegex = /((?:https?):\/\/)(example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade to HTTPS
    const secureProtocol = 'https://';
    
    // Check if we should rewrite to docs.example.com
    // Do this if:
    // 1. The path starts with /docs/
    // 2. The path does NOT contain cgi-bin
    // 3. The path does NOT contain query parameters (?, &)
    // 4. The path does NOT end with legacy extensions (.jsp, .php, etc.)
    
    const startsWithDocs = /^\/docs\//.test(path);
    const containsCgiBin = /cgi-bin/.test(path);
    const containsQueryParams = /[?&=]/.test(path);
    const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|\?|$)/.test(path);
    
    // Rewrite to docs.example.com if conditions are met
    if (startsWithDocs && !containsCgiBin && !containsQueryParams && !hasLegacyExtension) {
      return `${secureProtocol}docs.${domain}${path}`;
    }
    
    // Otherwise just upgrade the protocol
    return `${secureProtocol}${domain}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Define regex pattern for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = dateRegex.exec(value);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Additional validation for month/day combinations
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  if ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) {
    daysInMonth[2] = 29;
  }
  
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year.toString();
}
