import express, { Request, Response } from 'express';
import path from 'path';
import fsPromise from 'fs/promises';
import { fileURLToPath } from 'url';

// Import sql.js WASM build
import initSqlJs from 'sql.js';

// Set __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  general?: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: import('sql.js').Database | null = null;
  private isShuttingDown = false;

  constructor() {
    this.app = express();
    this.configureMiddleware();
  }

  private configureMiddleware(): void {
    // Parse JSON and URL-encoded bodies
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // Serve static files from public
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    
    // Set view engine to EJS
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Load sql.js
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });

      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      
      let fileBuffer: Uint8Array | null = null;
      try {
        // Try to load existing database
        fileBuffer = await fsPromise.readFile(dbPath);
      } catch (error: unknown) {
        if (error instanceof Error && (error as NodeJS.ErrnoException).code === 'ENOENT') {
          // Database doesn't exist, create a new one
          console.log('Database file not found, creating a new database');
          fileBuffer = null;
        } else {
          throw error;
        }
      }
      
      // Initialize database
      this.db = new SQL.Database(fileBuffer);
      
      if (!fileBuffer) {
        // Create the schema for a new database
        const schema = await fsPromise.readFile(
          path.join(__dirname, '..', 'db', 'schema.sql'),
          'utf-8'
        );
        this.db.run(schema);
        await this.saveDatabase();
      }
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    try {
      if (!this.db) throw new Error('Database not initialized');
      
      const data = this.db.export();
      const buffer = Buffer.from(data);
      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      
      // Ensure data directory exists
      await fsPromise.mkdir(path.dirname(dbPath), { recursive: true });
      
      await fsPromise.writeFile(dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateFormData(data: FormData): { isValid: boolean; errors: ValidationErrors } {
    const errors: ValidationErrors = {};
    
    // Required field validation
    if (!data.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }
    
    if (!data.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }
    
    if (!data.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }
    
    if (!data.city?.trim()) {
      errors.city = 'City is required';
    }
    
    if (!data.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }
    
    if (!data.postalCode?.trim()) {
      errors.postalCode = 'Postal code is required';
    }
    
    if (!data.country?.trim()) {
      errors.country = 'Country is required';
    }
    
    if (!data.email?.trim()) {
      errors.email = 'Email is required';
    } else {
      // Simple email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.email = 'Please enter a valid email address';
      }
    }
    
    if (!data.phone?.trim()) {
      errors.phone = 'Phone number is required';
    } else {
      // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
      const phoneRegex = /^\+?[0-9\s()-]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.phone = 'Please enter a valid phone number';
      }
    }
    
    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[a-zA-Z0-9\s]+$/.test(data.postalCode.replace(/\s/g, ''))) {
      errors.postalCode = 'Postal code must contain only letters and numbers';
    }
    
    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private setupRoutes(): void {
    // Home route - display the form
    this.app.get('/', (req: Request, res: Response) => {
      return res.render('form', {
        errors: [],
        values: {},
        title: 'Friendly Contact Form'
      });
    });

    // Form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone
      };

      // Validate form data
      const { isValid, errors } = this.validateFormData(formData);

      if (!isValid) {
        const errorsArray = Object.values(errors).filter((error): error is string => Boolean(error));
        return res.render('form', {
          errors: errorsArray,
          values: formData,
          title: 'Friendly Contact Form'
        });
      }

      try {
        if (!this.db) throw new Error('Database not initialized');
        
        // Insert data into the database
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          formData.firstName || '',
          formData.lastName || '',
          formData.streetAddress || '',
          formData.city || '',
          formData.stateProvince || '',
          formData.postalCode || '',
          formData.country || '',
          formData.email || '',
          formData.phone || ''
        ]);
        
        stmt.free();
        
        // Save the database
        await this.saveDatabase();
        
        // Redirect to thank you page
        res.redirect('/thank-you?' + `firstName=${encodeURIComponent(formData.firstName || '')}`);
      } catch (error) {
        console.error('Error saving form submission:', error);
        const errorsArray = ['An error occurred while saving your submission. Please try again.'];
        return res.render('form', {
          errors: errorsArray,
          values: formData,
          title: 'Friendly Contact Form'
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'friend';
      return res.render('thank-you', {
        firstName,
        title: 'Thank You!'
      });
    });

    // Error handling middleware
    this.app.use((err: Error, req: Request, res: Response) => {
      console.error('Unhandled error:', err);
      res.status(500).send('Internal Server Error');
    });

    // 404 handler
    this.app.use((req: Request, res: Response) => {
      res.status(404).send('Not Found');
    });
  }

  private setupGracefulShutdown(): void {
    const gracefulShutdown = async () => {
      if (this.isShuttingDown) return;
      this.isShuttingDown = true;
      
      console.log('Shutting down gracefully...');
      
      try {
        // Save database before exiting
        if (this.db) {
          await this.saveDatabase();
          this.db.close();
        }
        process.exit(0);
      } catch (error) {
        console.error('Error during graceful shutdown:', error);
        process.exit(1);
      }
    };

    // Set up signal handlers
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  }

  public async start(): Promise<void> {
    try {
      // Initialize database
      await this.initializeDatabase();
      
      // Setup routes
      this.setupRoutes();
      
      // Setup graceful shutdown
      this.setupGracefulShutdown();
      
      const port = process.env.PORT || 3535;
      const server = this.app.listen(port, () => {
        console.log(`Server running on http://localhost:${port}`);
      });
      
      // Handle server close during shutdown
      process.on('SIGTERM', () => {
        server.close();
      });
      process.on('SIGINT', () => {
        server.close();
      });
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }
}

// Start the application
const app = new FormCaptureApp();
app.start().catch(error => {
  console.error('Application failed to start:', error);
  process.exit(1);
});
