import { readFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from './types.js';

export function parseArgs(args: string[]): ReportOptions {
  const options: ReportOptions = {
    includeTotals: false,
    format: ''
  };

  let i = 3; // Skip node script path and data file path
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing format argument after --format');
      }
      options.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing output path argument after --output');
      }
      options.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
    
    i++;
  }

  if (!options.format) {
    throw new Error('--format argument is required');
  }

  return options;
}

export function getDataPath(args: string[]): string {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  return args[2];
}

export function loadAndValidateReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate structure
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate each entry
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid data: each entry must have a string label');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid data: each entry must have a number amount');
      }
    }
    
    return data as ReportData;
    
  } catch (error) {
    if (error instanceof Error && (error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath} - ${error.message}`);
    }
    throw error;
  }
}