#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { getDataPath, loadAndValidateReportData, parseArgs } from '../utils.js';
import { getFormatter } from '../formats/index.js';

function main(): void {
  try {
    const dataPath = getDataPath(process.argv);
    const options = parseArgs(process.argv);
    
    // Load and validate data
    const reportData = loadAndValidateReportData(dataPath);
    
    // Get formatter
    const formatter = getFormatter(options.format);
    
    // Generate report
    const output = formatter.render(reportData, { includeTotals: options.includeTotals });
    
    // Write output
    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
