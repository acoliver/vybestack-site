export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  includeTotals: boolean;
  format: string;
  outputPath?: string;
}

export interface Formatter {
  render(data: ReportData, options: { includeTotals: boolean }): string;
}
