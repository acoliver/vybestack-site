#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, RenderOptions } from '../formats/markdown.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Skip node and script name
  const flags = argv.slice(2);
  
  for (let i = 0; i < flags.length; i++) {
    const flag = flags[i];
    
    if (flag === '--format') {
      if (i + 1 < flags.length) {
        args.format = flags[i + 1];
        i++; // Skip next flag as it's the value
      }
    } else if (flag === '--output') {
      if (i + 1 < flags.length) {
        args.output = flags[i + 1];
        i++; // Skip next flag as it's the value
      }
    } else if (flag === '--includeTotals') {
      args.includeTotals = true;
    } else if (!flag.startsWith('--')) {
      // This is the data file (first non-flag argument)
      args.dataFile = flag;
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format "${args.format}". Supported formats: markdown, text`);
    process.exit(1);
  }
}

function loadData(dataFile: string): ReportData {
  try {
    const content = readFileSync(dataFile, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field (must be an array)');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File "${dataFile}" not found`);
      } else if (error.message.includes('JSON')) {
        console.error('Error: Invalid JSON format');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format "${format}"`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file "${outputPath}"`);
      process.exit(1);
    }
  } else {
    // Output to stdout
    process.stdout.write(content + '\n');
  }
}

// Main CLI logic
function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const data = loadData(args.dataFile);
  const options: RenderOptions = { includeTotals: args.includeTotals };
  
  try {
    const report = renderReport(data, args.format, options);
    writeOutput(report, args.output);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to render report');
    }
    process.exit(1);
  }
}

// Run the CLI
main();
