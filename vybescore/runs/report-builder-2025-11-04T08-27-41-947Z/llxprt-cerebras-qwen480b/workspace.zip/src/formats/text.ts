import { ReportData, FormatOptions } from './types.js';

export function renderText(data: ReportData, options: FormatOptions = {}): string {
  // Validate input data
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    throw new Error('Invalid report data: missing required fields');
  }
  
  // Check that all entries have required fields
  for (const entry of data.entries) {
    if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
      throw new Error('Invalid report data: entries must have label (string) and amount (number)');
    }
  }

  let output = `${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `Entries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\nTotal: $${total.toFixed(2)}\n`;
  }
  
  return output;
}