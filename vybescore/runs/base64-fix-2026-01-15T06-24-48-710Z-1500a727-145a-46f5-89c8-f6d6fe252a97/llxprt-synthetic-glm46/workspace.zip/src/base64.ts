/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates the input.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate Base64 format - only allow characters from standard Base64 alphabet
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  // Additional validation: check if padding is correct
  const paddingCount = (input.match(/=/g) || []).length;
  
  // Check for invalid padding placement
  if (paddingCount > 0) {
    // Padding must be at the end
    const paddingStart = input.indexOf('=');
    if (paddingStart !== input.length - paddingCount) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
    
    // Max 2 padding characters
    if (paddingCount > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding actually worked correctly
    // If the buffer is empty when it shouldn't be, it's likely invalid input
    const decodedString = buffer.toString('utf8');
    
    // Additional check: if we got unexpected null bytes, the input was likely invalid
    if (decodedString.includes('\0') && !input.includes('AA=')) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return decodedString;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
