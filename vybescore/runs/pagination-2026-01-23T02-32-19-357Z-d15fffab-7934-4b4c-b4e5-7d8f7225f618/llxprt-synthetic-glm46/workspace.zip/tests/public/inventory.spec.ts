import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { InventoryItem } from '../../src/shared/types';

describe('inventory API (comprehensive)', () => {
  let app: Awaited<ReturnType<typeof createApp>>;
  let db: Awaited<ReturnType<typeof createDatabase>>;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  describe('basic functionality', () => {
    it('returns some inventory rows with default pagination', async () => {
      const response = await request(app).get('/inventory');
      expect(response.status).toBe(200);
      expect(response.body.items).toBeDefined();
      expect(Array.isArray(response.body.items)).toBe(true);
      expect(response.body.items.length).toBeGreaterThan(0);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(5); // default limit
      expect(response.body.total).toBeGreaterThan(0);
      expect(typeof response.body.hasNext).toBe('boolean');
    });

    it('validates page parameter correctly', async () => {
      // Invalid page - zero
      const response1 = await request(app).get('/inventory?page=0');
      expect(response1.status).toBe(400);
      expect(response1.body.error).toContain('page');

      // Invalid page - negative
      const response2 = await request(app).get('/inventory?page=-1');
      expect(response2.status).toBe(400);
      expect(response2.body.error).toContain('page');

      // Invalid page - non-numeric
      const response3 = await request(app).get('/inventory?page=abc');
      expect(response3.status).toBe(400);
      expect(response3.body.error).toContain('page');

      // Valid page
      const response4 = await request(app).get('/inventory?page=2');
      expect(response4.status).toBe(200);
      expect(response4.body.page).toBe(2);
    });

    it('validates limit parameter correctly', async () => {
      // Invalid limit - zero
      const response1 = await request(app).get('/inventory?limit=0');
      expect(response1.status).toBe(400);
      expect(response1.body.error).toContain('limit');

      // Invalid limit - negative
      const response2 = await request(app).get('/inventory?limit=-5');
      expect(response2.status).toBe(400);
      expect(response2.body.error).toContain('limit');

      // Invalid limit - non-numeric
      const response3 = await request(app).get('/inventory?limit=xyz');
      expect(response3.status).toBe(400);
      expect(response3.body.error).toContain('limit');

      // Invalid limit - too large
      const response4 = await request(app).get('/inventory?limit=101');
      expect(response4.status).toBe(400);
      expect(response4.body.error).toContain('limit');

      // Valid limit
      const response5 = await request(app).get('/inventory?limit=10');
      expect(response5.status).toBe(200);
      expect(response5.body.limit).toBe(10);
    });
  });

  describe('pagination behavior', () => {
    it('correctly handles pagination with custom limit', async () => {
      const response1 = await request(app).get('/inventory?limit=3');
      expect(response1.status).toBe(200);
      expect(response1.body.items.length).toBeLessThanOrEqual(3);
      expect(response1.body.page).toBe(1);
      expect(response1.body.limit).toBe(3);

      // Get second page
      const response2 = await request(app).get('/inventory?limit=3&page=2');
      expect(response2.status).toBe(200);
      expect(response2.body.page).toBe(2);
      expect(response2.body.items.length).toBeLessThanOrEqual(3);
      
      // Ensure no overlapping items between pages
      const firstPageIds = response1.body.items.map((item: InventoryItem) => item.id);
      const secondPageIds = response2.body.items.map((item: InventoryItem) => item.id);
      const overlappingIds = firstPageIds.filter((id: number) => secondPageIds.includes(id));
      expect(overlappingIds).toHaveLength(0);
    });

    it('correctly calculates hasNext flag', async () => {
      // Use a small limit to ensure multiple pages
      const response = await request(app).get('/inventory?limit=2');
      expect(response.status).toBe(200);
      
      // If total is greater than limit, hasNext should be true
      if (response.body.total > 2) {
        expect(response.body.hasNext).toBe(true);
        
        // Test last page (should have hasNext: false)
        const lastPage = Math.ceil(response.body.total / 2);
        const lastPageResponse = await request(app).get(`/inventory?limit=2&page=${lastPage}`);
        expect(lastPageResponse.body.hasNext).toBe(false);
      } else {
        // If all items fit on first page, hasNext should be false
        expect(response.body.hasNext).toBe(false);
      }
    });

    it('handles page 1 correctly (offset should be 0)', async () => {
      const response = await request(app).get('/inventory?page=1&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      
      // Check that we get items starting from the beginning
      expect(response.body.items.length).toBeGreaterThan(0);
      
      // Items should be ordered by id
      for (let i = 1; i < response.body.items.length; i++) {
        expect(response.body.items[i].id).toBeGreaterThan(response.body.items[i - 1].id);
      }
    });
  });

  describe('pagination metadata structure', () => {
    it('returns properly structured pagination response', async () => {
      const response = await request(app).get('/inventory?page=2&limit=3');
      expect(response.status).toBe(200);
      
      expect(response.body).toHaveProperty('items');
      expect(response.body).toHaveProperty('page', 2);
      expect(response.body).toHaveProperty('limit', 3);
      expect(response.body).toHaveProperty('total');
      expect(response.body).toHaveProperty('hasNext');
      
      // Verify types
      expect(Array.isArray(response.body.items)).toBe(true);
      expect(typeof response.body.page).toBe('number');
      expect(typeof response.body.limit).toBe('number');
      expect(typeof response.body.total).toBe('number');
      expect(typeof response.body.hasNext).toBe('boolean');
      
      // Verify item structure
      if (response.body.items.length > 0) {
        const item = response.body.items[0];
        expect(item).toHaveProperty('id');
        expect(item).toHaveProperty('name');
        expect(item).toHaveProperty('sku');
        expect(item).toHaveProperty('priceCents');
        expect(item).toHaveProperty('createdAt');
      }
    });
  });
});