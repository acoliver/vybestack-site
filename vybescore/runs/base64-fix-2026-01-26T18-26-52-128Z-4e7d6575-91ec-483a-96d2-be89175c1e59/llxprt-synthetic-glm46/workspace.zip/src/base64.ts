/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Remove any whitespace from input
  const sanitizedInput = input.replace(/\s/g, '');
  
  // Validate the input is valid Base64 format
  // Contains only valid Base64 characters: A-Z, a-z, 0-9, +, /, and optional padding =
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(sanitizedInput)) {
    throw new Error('Invalid Base64 input format');
  }
  
  // Check if padding is correct (max two '=' at the end)
  const paddingMatch = sanitizedInput.match(/=+$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error('Invalid Base64 padding');
  }
  
  try {
    // Try to decode the input
    const buffer = Buffer.from(sanitizedInput, 'base64');
    
    // If the input is invalid, Node.js will not throw an error but will produce
    // empty result. We need to verify the decode was successful
    const testDecode = Buffer.from(sanitizedInput, 'base64').toString('base64');
    
    // Check if the re-encoded data matches the input (ignoring padding)
    const normalizedInput = sanitizedInput.replace(/=+$/, '');
    const normalizedTestDecode = testDecode.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedTestDecode) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
