/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> & { dependencies: Set<ObserverR> } = {
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all dependencies' dependents sets
    for (const dep of observer.dependencies) {
      const depWithDependents = dep as unknown as { dependents?: Set<ObserverR> }
      if (depWithDependents.dependents) {
        depWithDependents.dependents.delete(observer)
      }
    }
    
    // Clear the observer to stop further updates
    observer.dependencies.clear()
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
