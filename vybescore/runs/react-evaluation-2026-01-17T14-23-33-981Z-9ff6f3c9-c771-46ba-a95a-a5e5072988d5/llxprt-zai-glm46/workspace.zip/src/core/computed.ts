/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  ObserverR,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> & { dependents: Set<ObserverR> } & { dependencies: Set<ObserverR> } = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
    dependencies: new Set(),
  }
  
  const getter: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      const obsWithDeps = observer as unknown as { dependencies?: Set<ObserverR> }
      obsWithDeps.dependencies ??= new Set()
      obsWithDeps.dependencies.add(o)
      o.dependents.add(observer)
    }
    return o.value!
  }
  
  updateObserver(o)
  
  return getter
}
