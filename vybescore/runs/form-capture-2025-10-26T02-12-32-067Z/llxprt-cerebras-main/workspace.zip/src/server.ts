import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Get the directory name of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Database file path
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize database
let db: initSqlJs.Database;
let sqlJsInitialized = false;

async function initDatabase() {
  if (sqlJsInitialized) return;

  const SQL = await initSqlJs({
    locateFile: (file) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.0/${file}`
  });

  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(new Uint8Array(fileBuffer));
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    db.run(schema);
  }

  sqlJsInitialized = true;
}

// Validation functions
function validateEmail(email: string): boolean {
  // Simple email regex validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', async (req, res) => {
  await initDatabase();
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', async (req, res) => {
  await initDatabase();
  
  const formData = req.body;
  const errors: Record<string, string> = {};

  // Validation
  if (!formData.firstName) errors.firstName = 'First name is required';
  if (!formData.lastName) errors.lastName = 'Last name is required';
  if (!formData.streetAddress) errors.streetAddress = 'Street address is required';
  if (!formData.city) errors.city = 'City is required';
  if (!formData.stateProvince) errors.stateProvince = 'State/Province is required';
  if (!formData.postalCode) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Invalid postal code format';
  }
  if (!formData.country) errors.country = 'Country is required';
  if (!formData.email) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Invalid email address';
  }
  if (!formData.phone) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Invalid phone number format';
  }

  // If there are errors, re-render the form with error messages and previous data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }

  // Insert data into database
  const statement = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  statement.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  statement.free();
  
  // Write database back to file
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);

  // Redirect to thank-you page
  res.redirect('/thank-you');
});

app.get('/thank-you', async (req, res) => {
  await initDatabase();
  res.render('thank-you');
});

// Graceful shutdown
let server: express.Application | null = null;

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    // In Express, server.close() takes a callback, but we don't have direct access to the HTTP server here
    // The callback shows how to handle closing, but let's just log for now
    console.log('Express server closed');
  }
  
  if (db) {
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
});

// Start server
async function startServer() {
  await initDatabase();
  server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  }) as unknown as express.Application;
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});