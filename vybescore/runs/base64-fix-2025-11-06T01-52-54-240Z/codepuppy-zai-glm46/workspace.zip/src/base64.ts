/**
 * Encode plain text to Base64 using RFC 4648 standard encoding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  // Use standard Base64 encoding which includes proper padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Accepts valid Base64 input with or without padding.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate Base64 input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validates if input is proper Base64 format according to RFC 4648.
 * Accepts standard Base64 alphabet with optional padding.
 * Rejects clearly invalid payloads by checking for invalid characters.
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (input.length === 0) {
    return false;
  }

  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /) and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Basic padding rule: padding can only appear at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // All characters after the first '=' must also be '='
    const paddingSection = input.substring(paddingIndex);
    if (!paddingSection.match(/^=+$/)) {
      return false;
    }
  }

  // Let Node.js' Buffer reject actual invalid Base64 during decoding
  // We just need to catch obviously invalid character patterns
  return true;
}
