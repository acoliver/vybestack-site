export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Accept typical addresses such as name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  
  // Email regex pattern:
  // Local part: letters, digits, and special characters but not starting/ending with dot
  // No consecutive dots
  // Domain: no underscores, no trailing dots
  const emailRegex: RegExp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Enhanced validation checks
  // No consecutive dots in local part or domain
  const noDoubleDots: boolean = !value.includes('..');
  // No leading or trailing dot in local part
  const localPart: string = value.split('@')[0] || '';
  const noLeadingTrailingDotLocal: boolean = !localPart.startsWith('.') && !localPart.endsWith('.');
  // No domain has underscores
  const domainPart: string = value.split('@')[1] || '';
  const noUnderscoresInDomain: boolean = !domainPart.includes('_');
  // No trailing dot in domain
  const noTrailingDotDomain: boolean = !domainPart.endsWith('.');
  
  return emailRegex.test(value) && 
         noDoubleDots && 
         noLeadingTrailingDotLocal && 
         noUnderscoresInDomain && 
         noTrailingDotDomain;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits: string = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number) or 11 if with country code
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with +1 (country code)
  if (digits.length === 11 && digits[0] !== '1') {
    return false;
  }
  
  // Extract the last 10 digits (area code + exchange number + subscriber number)
  const phoneNumber: string = digits.length === 10 ? digits : digits.substring(1);
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode: string = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode: string = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate basic format with optional separators and optional country code
  // Supported formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phonePattern: RegExp = /^(\+1\s?)?(\(\d{3}\)\s?|\d{3}[-.\s]?)\d{3}[-.\s]?\d{4}$/;
  return phonePattern.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits: string = value.replace(/\D/g, '');
  
  // Must have valid number of digits for Argentine phone numbers
  // Minimum: 6 (subscriber) + 2 (area) = 8 digits
  // Maximum: 8 (subscriber) + 4 (area) + 1 (trunk) + 2 (country) = 15 digits
  if (digits.length < 8 || digits.length > 15) {
    return false;
  }
  
  let areaCodeDigits = '';
  let subscriberDigits = '';
  let hasCountryCode = false;
  
  let remainingDigits = digits;
  
  // Check for country code +54
  if (remainingDigits.startsWith('54')) {
    hasCountryCode = true;
    remainingDigits = digits.substring(2); // Remove 54
  }
  
  // Check for trunk prefix 0 (only if no country code)
  if (!hasCountryCode && remainingDigits.startsWith('0')) {
    remainingDigits = remainingDigits.substring(1); // Remove the 0
  }
  
  // Check for mobile indicator 9
  if (remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.substring(1); // Remove the 9
  }
  
  // Now we need to extract area code and subscriber number
  // Try different area code lengths from 4 to 2 (try longer first)
  for (let areaCodeLen = 4; areaCodeLen >= 2; areaCodeLen--) {
    if (remainingDigits.length >= areaCodeLen + 6) { // Minimum subscriber is 6 digits
      const potentialAreaCode = remainingDigits.substring(0, areaCodeLen);
      const potentialSubscriber = remainingDigits.substring(areaCodeLen);
      
      // Check if area code is valid (2-4 digits, leading digit 1-9)
      if (potentialAreaCode[0] >= '1' && potentialAreaCode[0] <= '9' && 
          potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
        areaCodeDigits = potentialAreaCode;
        subscriberDigits = potentialSubscriber;
        break;
      }
    }
  }
  
  // If we couldn't extract valid area code and subscriber, reject
  if (!areaCodeDigits || !subscriberDigits) {
    return false;
  }
  
  // Validate area code (already done above but double-check)
  if (areaCodeDigits.length < 2 || areaCodeDigits.length > 4) {
    return false;
  }
  if (areaCodeDigits[0] < '1' || areaCodeDigits[0] > '9') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits - already done above)
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode regex to accept letters, apostrophes, hyphens, and spaces
  // \p{L} - any kind of letter from any language
  // \p{M} - combining marks (accents, etc.)
  const nameRegex: RegExp = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Reject names with three or more consecutive same characters (like repeated symbols)
  const noRepeats: boolean = !/(.)\1{2,}/.test(value);
  
  // Ensure at least one letter (not just symbols/spaces)
  const hasLetter: boolean = /\p{L}/u.test(value);
  
  // Reject if more than 30 characters
  const reasonableLength: boolean = value.length > 0 && value.length <= 30;
  
  return nameRegex.test(value) && noRepeats && hasLetter && reasonableLength;
}

/**
 * Luhn algorithm implementation for credit card validation
 */
function runLuhnCheck(num: string): boolean {
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = num.length - 1; i >= 0; i--) {
    let digit = parseInt(num.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cardNumber: string = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex: RegExp = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 2221-2720 or 51-55, length 16
  const mastercardRegex: RegExp = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex: RegExp = /^3[47]\d{13}$/;
  
  // Check if card matches any supported format
  const isValidFormat: boolean = visaRegex.test(cardNumber) || 
                              mastercardRegex.test(cardNumber) || 
                              amexRegex.test(cardNumber);
  
  // Return false if format is invalid
  if (!isValidFormat) {
    return false;
  }
  
  // Pass through Luhn algorithm
  return runLuhnCheck(cardNumber);
}
