/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to find words with the prefix
  // Word boundary at start, then the prefix, then word characters
  const wordPattern = new RegExp(`\\b${escapedPrefix}[\\w-]+`, 'g');
  
  // Find all matches
  const allMatches = Array.from(text.matchAll(wordPattern));
  
  // Extract just the matched words
  const matchedWords = allMatches.map(match => match[0]);
  
  // Filter out exceptions
  const filteredWords = matchedWords.filter(word => 
    !exceptions.includes(word)
  );
  
  // Remove duplicates
  return [...new Set(filteredWords)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern explanation:
  // (\b)word boundary before token
  // (\d) - preceding character must be a digit
  const tokenPattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    // Ensure the token is not at the start of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  // Return the matched tokens (the full match)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab, 1212)
  // Check for repeating sequences of 2 characters or more
  for (let patternLength = 2; patternLength <= value.length / 2; patternLength++) {
    if (value.length % patternLength === 0) {
      const pattern = value.substring(0, patternLength);
      const repetitions = value.length / patternLength;
      let isRepeated = true;
      
      for (let i = 1; i < repetitions; i++) {
        const chunk = value.substring(i * patternLength, (i + 1) * patternLength);
        if (chunk !== pattern) {
          isRepeated = false;
          break;
        }
      }
      
      if (isRepeated) {
        return false;
      }
    }
    
    // Also check for partial sequences like "aaabbb" where pattern repeats at least twice
    for (let i = 0; i <= value.length - (patternLength * 2); i++) {
      const pattern = value.substring(i, i + patternLength);
      const nextChunk = value.substring(i + patternLength, i + (patternLength * 2));
      
      if (pattern === nextChunk) {
        // Check if this pattern continues throughout the password
        let isRepeatedPattern = true;
        for (let j = i + patternLength; j < value.length - patternLength; j += patternLength) {
          const currentChunk = value.substring(j, j + patternLength);
          if (currentChunk !== pattern) {
            isRepeatedPattern = false;
            break;
          }
        }
        
        if (isRepeatedPattern) {
          return false;
        }
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern - supports standard format and shorthand with ::
  // Simplified pattern focusing on core IPv6 features
  
  // Standard IPv6 format (hex groups separated by colons)
  // With optional compression using :: shorthand
  const ipv6Pattern = /([0-9a-fA-F]{1,4}:([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})|::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){0,2}:[0-9a-fA-F]{1,4}::/;
  
  // Pure IPv4 pattern to ensure we don't match IPv6 addresses that are actually only IPv4
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Extract potential IPv6 matches
  const matches = Array.from(value.matchAll(new RegExp(ipv6Pattern, 'g')));
  
  // If no matches, it's definitely not IPv6
  if (matches.length === 0) {
    return false;
  }
  
  // Check if any match is a valid IPv6 address and not pure IPv4
  for (const match of matches) {
    const potentialIp = match[0];
    
    // If it matches IPv4 pattern exactly, it's not IPv6
    if (ipv4Pattern.test(potentialIp.trim())) {
      continue;
    }
    
    // Otherwise, it's likely a valid IPv6 address
    return true;
  }
  
  return false;
}
