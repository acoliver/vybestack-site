/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences using regex that matches sentence delimiters 
  // and keeps them in the result array
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let shouldCapitalizeNext = true; // Start by capitalizing the first character
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    // Check if this is a sentence delimiter
    const isDelimiter = /[.?!]/.test(segment);
    
    if (isDelimiter) {
      // Add the delimiter and set flag to capitalize next segment
      result += segment;
      shouldCapitalizeNext = true;
    } else {
      // This is a text segment
      // Trim leading whitespace for processing but remember it
      const whitespaceMatch = segment.match(/^\s+/);
      const leadingWhitespace = whitespaceMatch ? whitespaceMatch[0] : '';
      const trimmedSegment = segment.replace(/^\s+/, '');
      
      // Capitalize the first character if flag is set and segment has content
      if (shouldCapitalizeNext && trimmedSegment.length > 0) {
        const firstChar = trimmedSegment[0];
        const restOfSegment = trimmedSegment.substring(1);
        
        // Check if the first character is a letter
        if (/[\p{L}]/u.test(firstChar)) {
          result += leadingWhitespace + firstChar.toUpperCase() + restOfSegment;
        } else {
          result += leadingWhitespace + trimmedSegment;
        }
      } else {
        // Don't capitalize, just add the segment as is
        result += segment;
      }
      
      shouldCapitalizeNext = false;
    }
  }
  
  // Ensure exactly one space between sentences while preserving original spacing elsewhere
  // Also collapse multiple consecutive spaces into single spaces
  result = result.replace(/([.?!])(\s+)/g, '$1 ');
  result = result.replace(/\s{2,}/g, ' ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern with protocol (http/https) and domain
  // Includes domains, IP addresses, optional ports, paths, query strings, fragments
  // Excludes trailing punctuation
  const urlRegex = /\b((https?:\/\/)|(www\.))(((?=[\p{L}\p{N}._%+-]).)+([.][\p{L}]{2,})|(\d{1,3}[.]\d{1,3}[.]\d{1,3}[.]\d{1,3}))(([/?#&][^\s]*)?)\b/gu;
  
  const matches = Array.from(text.matchAll(urlRegex));
  
  // Extract the full URL from each match and ensure no trailing punctuation
  return matches.map(match => {
    let url = match[0];
    
    // Remove trailing punctuation like period, comma, semicolon, etc.
    url = url.replace(/[.,;:!?)]+$/g, '');
    
    // If URL starts with 'www.', prepend 'http://' to make it valid
    if (url.startsWith('www.')) {
      url = 'http://' + url;
    }
    
    return url;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but NOT when already https://
  // Using negative lookahead to ensure we don't match https://
  const httpsRegex = /http:\/\/(?!https:)/g;
  
  // Replace all http:// with https:// (except https://)
  return text.replace(httpsRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Capture groups: protocol, domain, path
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*?)(?=[\s.,;:!?]|$)/g;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https://
    const secureProtocol = 'https://';
    
    // Only rewrite host if path starts with /docs/ and doesn't contain skip patterns
    const skipPatterns = [
      /\b(cgi-bin)\b/,
      /[?&=]/,  // Query strings
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[\s.,;:!?]|$)/  // Legacy extensions
    ];
    
    const shouldSkipHost = skipPatterns.some(pattern => pattern.test(path));
    
    if (path.startsWith('/docs/') && !shouldSkipHost) {
      // Rewrite host to docs.example.com while preserving the path
      return `${secureProtocol}docs.${domain}${path}`;
    } else {
      // Just upgrade to https://
      return `${secureProtocol}${domain}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy with exact format validation
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  // Extract month, day, and year
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month/day combinations
  // Short month: April (4), June (6), September (9), November (11) -> max 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // February: check for leap years
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && 
                        parseInt(year, 10) % 100 !== 0) || 
                       (parseInt(year, 10) % 400 === 0);
    if ((day > 29) || (!isLeapYear && day > 28)) {
      return 'N/A';
    }
  }
  
  return year;
}
