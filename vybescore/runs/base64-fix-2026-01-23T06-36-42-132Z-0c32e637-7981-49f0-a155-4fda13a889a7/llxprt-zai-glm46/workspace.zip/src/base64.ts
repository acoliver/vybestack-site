/**
 * Regular expression to validate Base64 strings.
 * Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, with optional padding (=)
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) and includes padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads (non-Base64 characters or malformed data).
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate input contains only valid Base64 characters
  if (!VALID_BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');

    // Check if the input was valid Base64 by verifying the buffer
    // Invalid Base64 will produce an empty buffer or partial data
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    // Verify that the decoded length is reasonable
    // Each 4 characters of Base64 should decode to 3 bytes (except with padding)
    const expectedByteLength = Math.floor((trimmed.replace(/=+$/, '').length * 3) / 4);
    if (buffer.length !== expectedByteLength && trimmed.length > 0) {
      // Additional validation: check if re-encoding matches
      const reEncoded = buffer.toString('base64').replace(/=+$/, '');
      const normalizedInput = trimmed.replace(/=+$/, '');
      if (reEncoded !== normalizedInput) {
        throw new Error('Invalid Base64 input: corrupted data');
      }
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
