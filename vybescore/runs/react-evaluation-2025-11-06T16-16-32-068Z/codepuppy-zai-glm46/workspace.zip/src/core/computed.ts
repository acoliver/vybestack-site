/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function - for computed values, we don't need equality checks
  // since derived values should always be recomputed when dependencies change
  
  // Add observer tracking for the computed value itself
  const observers = new Set<Observer<unknown>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // Execute the update function to compute new value
      const newValue = updateFn(prevValue)
      
      // Only notify observers if value actually changed
      const valueChanged = o.value !== newValue
      o.value = newValue
      
      if (valueChanged) {
        // Notify observers of this computed value
        for (const observer of observers) {
          updateObserver(observer)
        }
      }
      
      return newValue
    },
  }
  
  // Initialize the value by triggering an update
  if (o.value === undefined) {
    updateObserver(o)
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    if (observer && observer !== o) {
      // Register this observer as dependent on this computed value
      // Cast to Observer<any> since we know it has the required properties
      observers.add(observer as Observer<unknown>)
      
      // Recompute to establish dependency relationship
      updateObserver(o)
    } else if (!observer) {
      // No active observer, just ensure we have a value
      if (o.value === undefined) {
        updateObserver(o)
      }
    }
    
    return o.value as T
  }
  
  return getter
}