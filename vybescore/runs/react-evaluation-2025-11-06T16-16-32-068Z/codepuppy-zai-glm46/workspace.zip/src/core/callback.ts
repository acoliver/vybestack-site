/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      // Execute the callback function with the current value
      updateFn(prevValue)
      
      // Callbacks don't necessarily return a meaningful value,
      // so we keep the current value unchanged
      return observer.value as T
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => undefined as T
  }
  
  return unsubscribe
}