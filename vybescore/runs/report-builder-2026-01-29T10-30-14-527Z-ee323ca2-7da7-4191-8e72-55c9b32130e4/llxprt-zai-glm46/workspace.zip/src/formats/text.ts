import type { Formatter, ReportData, RenderOptions } from '../types.js';

/**
 * Formats a number as currency with exactly 2 decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total of all entry amounts
 */
function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Plain text formatter implementation
 */
export const textFormatter: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(data.title);
    lines.push('');

    // Summary
    lines.push(data.summary);
    lines.push('');

    // Entries section
    lines.push('Entries:');
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }

    // Optional total
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push(`Total: ${formatAmount(total)}`);
    }

    return lines.join('\n');
  },
};
