#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import type { Formatter, ReportData, RenderOptions } from '../types.js';

/**
 * Parsed CLI arguments
 */
interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Validates that the report data has all required fields
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

/**
 * Parses command line arguments
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 1) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Gets the formatter for the specified format
 */
function getFormatter(format: string): Formatter {
  const formatters: Record<string, Formatter> = {
    markdown: markdownFormatter,
    text: textFormatter,
  };

  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return formatter;
}

/**
 * Reads and parses JSON from a file
 */
function readJsonFile(filePath: string): unknown {
  const absolutePath = path.resolve(filePath);

  try {
    const content = fs.readFileSync(absolutePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

/**
 * Main entry point
 */
function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and parse input file
    const rawData = readJsonFile(args.inputFile);
    const data = validateReportData(rawData);

    // Get formatter
    const formatter = getFormatter(args.format);

    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    const output = formatter.render(data, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

main();
