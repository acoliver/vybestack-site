import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;
// Store the most recent submission's first name for the thank-you page
let lastSubmissionFirstName: string = '';

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and an optional leading +
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with spaces
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!validateRequired(data.firstName || '')) {
    errors.push('First name is required.');
  }
  if (!validateRequired(data.lastName || '')) {
    errors.push('Last name is required.');
  }
  if (!validateRequired(data.streetAddress || '')) {
    errors.push('Street address is required.');
  }
  if (!validateRequired(data.city || '')) {
    errors.push('City is required.');
  }
  if (!validateRequired(data.stateProvince || '')) {
    errors.push('State / Province / Region is required.');
  }
  if (!validateRequired(data.postalCode || '')) {
    errors.push('Postal / Zip code is required.');
  } else if (!validatePostalCode(data.postalCode || '')) {
    errors.push('Postal / Zip code must contain at least 3 characters (letters, numbers, spaces, and hyphens allowed).');
  }
  if (!validateRequired(data.country || '')) {
    errors.push('Country is required.');
  }
  if (!validateRequired(data.email || '')) {
    errors.push('Email is required.');
  } else if (!validateEmail(data.email || '')) {
    errors.push('Please enter a valid email address.');
  }
  if (!validateRequired(data.phone || '')) {
    errors.push('Phone number is required.');
  } else if (!validatePhone(data.phone || '')) {
    errors.push('Phone number must contain at least 7 digits (spaces, parentheses, dashes, and a leading + are allowed).');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

// Initialize database
export async function initDatabase(): Promise<void> {
  if (db !== null) {
    return; // Already initialized
  }

  const SQL = await initSqlJs();
  
  // Check if database file exists
  const fs = await import('node:fs/promises');
  let dbData: Uint8Array | null = null;

  try {
    const buffer = await fs.readFile(DB_PATH);
    dbData = new Uint8Array(buffer);
  } catch {
    // Database doesn't exist yet, will be created
  }

  db = new SQL.Database(dbData || undefined);

  // Initialize schema
  const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
  db.run(schema);
}

// Close database
export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    values: {},
    errors: []
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      values: formData,
      errors: validation.errors
    });
  }

  // Insert into database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      stmt.free();

      // Save database to disk
      const data = db.export();
      const buffer = Buffer.from(data);
      await import('node:fs/promises').then(fs => 
        fs.mkdir(path.dirname(DB_PATH), { recursive: true })
          .then(() => fs.writeFile(DB_PATH, buffer))
      );
      
      // Store the first name for the thank-you page
      lastSubmissionFirstName = formData.firstName;
    } catch (err) {
      console.error('Database error:', err);
      return res.status(500).render('form', {
        values: formData,
        errors: ['An error occurred while saving your submission. Please try again.']
      });
    }
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Use query parameter if provided, otherwise use the last submission
  const firstName = (req.query.firstName as string) || lastSubmissionFirstName || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  await initDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = async (signal: string): Promise<void> => {
    console.log(`\n${signal} received, shutting down gracefully...`);
    
    server.close(() => {
      console.log('HTTP server closed');
    });

    closeDatabase();

    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

// Export for testing
export default app;
