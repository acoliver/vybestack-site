import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app, { initDatabase, closeDatabase } from '../../dist/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await initDatabase();
});

afterAll(() => {
  closeDatabase();
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    // Handle both text and body properties
    const html = response.text || (typeof response.body === 'string' ? response.body : '');
    expect(html).toBeTruthy();
    expect(html.length).toBeGreaterThan(0);
    
    const $ = cheerio.load(html);
    
    // Check for form elements
    expect($('form[method="post"][action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app).post('/submit').type('form').send({
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Test Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958'
    });

    // Debug: if validation fails, log the error
    if (response.status !== 302) {
      console.log('Response status:', response.status);
      const html = response.text || (typeof response.body === 'string' ? response.body : '');
      if (html.includes('error-list')) {
        const match = html.match(/<ul[^>]*class="error-list"[^>]*>(.*?)<\/ul>/s);
        if (match) {
          console.log('Validation error:', match[1].replace(/<[^>]+>/g, '').trim());
        }
      }
    }

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Wait a bit for the database write to complete
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('displays validation errors for invalid email', async () => {
    const response = await request(app).post('/submit').type('form').send({
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Test Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'invalid-email',
      phone: '+44 20 7946 0958'
    });

    expect(response.status).toBe(400);
    
    const html = typeof response.body === 'string' ? response.body : response.text;
    const $ = cheerio.load(html);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list').text()).toContain('valid email');
  });

  it('displays validation errors for missing required fields', async () => {
    const response = await request(app).post('/submit').type('form').send({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    });

    expect(response.status).toBe(400);
    
    const html = typeof response.body === 'string' ? response.body : response.text;
    const $ = cheerio.load(html);
    expect($('.error-list').length).toBe(1);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('First name');
    expect(errorText).toContain('Last name');
    expect(errorText).toContain('Email');
  });

  it('accepts international phone formats', async () => {
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '123-456-7890'
    ];

    for (const phone of testCases) {
      const response = await request(app).post('/submit').type('form').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: phone
      });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('accepts international postal code formats', async () => {
    const testCases = [
      { postal: 'SW1A 1AA', country: 'United Kingdom' },
      { postal: 'C1000', country: 'Argentina' },
      { postal: 'B1675', country: 'Argentina' },
      { postal: '12345', country: 'United States' }
    ];

    for (const { postal, country } of testCases) {
      const response = await request(app).post('/submit').type('form').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: postal,
        country: country,
        email: 'test@example.com',
        phone: '+1 555-123-4567'
      });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('renders thank-you page with user name', async () => {
    const response = await request(app).get('/thank-you?firstName=Jane');

    expect(response.status).toBe(200);
    
    const html = typeof response.body === 'string' ? response.body : response.text;
    const $ = cheerio.load(html);
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain('Jane');
    expect($('body').text()).toContain('stranger on the internet');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app).post('/submit').type('form').send({
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Test Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'invalid-email',
      phone: '+44 20 7946 0958'
    });

    expect(response.status).toBe(400);
    
    const html = typeof response.body === 'string' ? response.body : response.text;
    const $ = cheerio.load(html);
    expect($('input[name="firstName"]').val()).toBe('Jane');
    expect($('input[name="lastName"]').val()).toBe('Doe');
    expect($('input[name="email"]').val()).toBe('invalid-email');
  });
});
