/**
 * Encode plain text to Base64.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate input structure using Base64 character set
  // This validates that the input only contains valid Base64 characters and padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check if padding is valid (can only appear at end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && /[A-Za-z0-9+/]/.test(input.slice(paddingIndex))) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }

  // Check if non-padding characters follow padding
  const nonPaddingAfterPadding = /=+[A-Za-z0-9+/]/.test(input);
  if (nonPaddingAfterPadding) {
    throw new Error('Invalid Base64 input: characters after padding');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify that the result is valid UTF-8
    // If the input contained invalid Base64 sequences, Node.js might not throw
    // but the result would be incorrect. We can check this by encoding back.
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    const normalizedInput = input.replace(/=+$/, '');
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: failed validation');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
