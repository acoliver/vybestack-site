/**
 * Encode plain text to Base64 using standard Base64 encoding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64 decoding.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const cleaned = input.replace(/\s/g, ''); // Remove whitespace
  
  // Validate input is not empty
  if (cleaned.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  // Validate character set and length
  const isValidBase64 = validateBase64(cleaned);
  if (!isValidBase64) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(cleaned, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

function validateBase64(input: string): boolean {
  // Character validation: only valid Base64 chars allowed
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Length validation: must be multiple of 4 (or handle padding)
  const remainder = input.length % 4;
  
  return base64Regex.test(input) && 
         remainder !== 1 && 
         (remainder === 0 || 
          (remainder === 2 && input.endsWith('=')) || 
          (remainder === 3 && input.slice(-2) === '=='));
}
