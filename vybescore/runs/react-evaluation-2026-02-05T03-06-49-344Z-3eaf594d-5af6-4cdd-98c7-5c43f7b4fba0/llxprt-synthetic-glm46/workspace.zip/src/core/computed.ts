/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
    dependents: new Set(),
  }
  
  // Add to global observer set
  addObserver(o)
  
  // Compute initial value
  updateObserver(o)
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && o.dependents) {
      // Track dependency relationship: this computed is dependent on the current observer
      if (!o.dependents.has(observer)) {
        o.dependents.add(observer)
      }
    }
    return o.value!
  }
  
  return getter
}
