/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  dependencies?: Set<SubjectR>
  dependents?: Set<ObserverR>
}

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Global storage for all observers to handle cascading updates
const allObservers = new Set<Observer<unknown>>()

export function getAllObservers(): Set<Observer<unknown>> {
  return allObservers
}

export function addObserver<T>(observer: Observer<T>): void {
  allObservers.add(observer as Observer<unknown>)
}

export function removeObserver<T>(observer: Observer<T>): void {
  allObservers.delete(observer as Observer<unknown>)
  // Clean up dependencies
  if (observer.dependencies) {
    observer.dependencies.clear()
  }
  if (observer.dependents) {
    observer.dependents.clear()
  }
}

export function addObserverDependent(observer: ObserverR, dependency: SubjectR): void {
  // Ensure the subject tracks this observer
  if (!dependency.observers) {
    dependency.observers = new Set()
  }
  dependency.observers.add(observer)
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // If we're in a callback (not a computed), we want to trigger all dependents
    if (observer.dependents && observer.dependents.size > 0) {
      // For callbacks, we need to cascade updates to all dependent observers
      for (const dependent of observer.dependents) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function propagateUpdate(subject: SubjectR): void {
  if (!subject.observers) return
  
  // Create a copy to avoid issues with concurrent modification
  const observers = new Set(subject.observers)
  for (const obs of observers) {
    updateObserver(obs as Observer<unknown>)
  }
}
