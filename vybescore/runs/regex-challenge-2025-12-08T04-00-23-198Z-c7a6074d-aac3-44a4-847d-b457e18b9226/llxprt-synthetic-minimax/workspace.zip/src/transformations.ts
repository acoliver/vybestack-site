/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Handle common abbreviations that should not end sentences
  const abbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Mt|Capt|Sgt|Col|Gen|Lt)\.$/i;
  
  // Find sentence boundaries and capitalize
  result = result.replace(/(^|[.!?]\s+)(\p{L})/gu, (match, prefix, letter) => {
    // Check if this is an abbreviation (avoid capitalizing after)
    const prevText = text.substring(0, text.indexOf(letter) - prefix.length);
    const lastWord = prevText.split(' ').pop();
    
    if (lastWord && abbreviations.test(lastWord)) {
      return match; // Don't capitalize after abbreviations
    }
    
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text and return them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http(s):// URLs
  const urlPattern = /\bhttps?:\/\/[^\s<>"]+[^\s<>".!?]/gi;
  
  const urls = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return urls.map(url => {
    // Remove trailing punctuation at the end of the URL
    return url.replace(/[.!?]+$/, '');
  });
}

/**
 * TODO: Replace http:// with https:// while leaving secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// (not https://) with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // URL pattern to match http://example.com/... (not https://)
  const httpUrlPattern = /http:\/\/([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlPattern, (match, host, path = '') => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|[?&]|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    // Always upgrade to https
    let newUrl = `https://${host}${path}`;
    
    // Only rewrite host for docs paths that don't have dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // For domains like example.com, transform to docs.example.com
      // For domains like sub.example.com, transform to docs.example.com  
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts[domainParts.length - 2];
        const tld = domainParts[domainParts.length - 1];
        newUrl = `https://docs.${domain}.${tld}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the four-digit year from mm/dd/yyyy format. Return 'N/A' if invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}