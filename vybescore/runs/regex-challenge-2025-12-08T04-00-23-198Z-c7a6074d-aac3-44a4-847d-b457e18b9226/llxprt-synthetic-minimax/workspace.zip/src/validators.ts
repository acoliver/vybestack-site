export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 * Requirements: Accept typical addresses like name+tag@example.co.uk
 * Reject double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  const trimmed = value.trim();
  
  // Email regex - must start and end with alphanumeric
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  // Check for double dots
  if (trimmed.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (trimmed.endsWith('.')) {
    return false;
  }
  
  // Check domain part for underscores
  const domainPart = trimmed.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + at the beginning
  let cleanValue = value.trim();
  
  // Handle optional +1 prefix
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  }
  
  // Remove all non-digit characters
  cleanValue = cleanValue.replace(/\D/g, '');
  
  // Must be exactly 10 digits
  if (cleanValue.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = cleanValue.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Handle Argentine phone numbers with flexible formatting.
 */
export function isValidArgentinePhone(value: string): boolean {
  const trimmed = value.trim();
  
  // Remove all spaces and hyphens for processing
  const cleanValue = trimmed.replace(/[\s-]/g, '');
  
  // Pattern for Argentine numbers
  const argentinaPhoneRegex = /^(\+54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  const match = cleanValue.match(argentinaPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // Extract just the digits for area code validation
  const areaCodeDigits = areaCode;
  
  // Area code must be 2-4 digits, first digit must be 1-9
  if (areaCodeDigits.length < 2 || areaCodeDigits.length > 4) {
    return false;
  }
  
  if (!/^[1-9]/.test(areaCodeDigits)) {
    return false;
  }
  
  // Subscriber number should be 6-8 digits total
  const totalSubscriberLength = subscriberNumber.length;
  if (totalSubscriberLength < 6 || totalSubscriberLength > 8) {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Permit unicode letters, accents, apostrophes, hyphens, spaces.
 * Reject digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Must not be empty
  if (trimmed.length === 0) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Check for problematic symbols (excluding apostrophes, hyphens, spaces)
  if (/[^A-Za-zÀ-ÖØ-öø-ÿ' -]/.test(trimmed)) {
    return false;
  }
  
  // Check for patterns like "X Æ A-12"
  if (/[A-Z]\s*[Æ]\s*[A-Z]-[0-9]+/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check card type prefixes
  const isVisa = /^4/.test(cleanValue) && (cleanValue.length === 13 || cleanValue.length === 16 || cleanValue.length === 19);
  const isMastercard = /^5[1-5]/.test(cleanValue) && cleanValue.length === 16;
  const isAmex = /^3[47]/.test(cleanValue) && cleanValue.length === 15;
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function for Luhn checksum algorithm.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}