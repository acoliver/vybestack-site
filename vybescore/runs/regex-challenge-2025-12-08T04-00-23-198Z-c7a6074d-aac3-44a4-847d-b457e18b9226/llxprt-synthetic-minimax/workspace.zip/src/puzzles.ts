/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with prefix
  const wordRegex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const allMatches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  return allMatches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !exceptions.some(exception => exception.toLowerCase() === normalizedMatch);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex pattern to find token when it appears after a digit and not at start
  // We need to capture the digit + token together
  const fullPattern = new RegExp(`(\\d${token})(?![a-zA-Z0-9])`, 'gi');
  const fullMatches: string[] = [];
  let match;
  while ((match = fullPattern.exec(text)) !== null) {
    fullMatches.push(match[1]); // match[1] is the captured group with digit+token
  }

  return fullMatches.length > 0 ? fullMatches : [];
}

/**
 * TODO: Validate password strength with specific requirements.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase, lowercase, digit, and symbol
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/\d/.test(value)) return false;
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab"
  if (/([A-Za-z0-9]{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses don't trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes shorthand notation
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b::1\b|\b::\b|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/i;
  
  return ipv6Pattern.test(value);
}