/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let isActive = true

  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T): T => {
      // Execute the actual callback function to perform side effects
      // This will access reactive values and establish dependencies
      if (!isActive) return currentValue!
      
      // Track dependencies by running the callback function
      // This will access reactive values and register this observer
      const result = updateFn(currentValue)
      return result
    },
  }
  
  // Register observer to track dependencies
  // This will call our updateFn which will access reactive values
  // and establish the subscription relationships
  updateObserver(observer)
  
  return () => {
    if (!isActive) return
    isActive = false
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}