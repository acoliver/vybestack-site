/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> = typeof equal === 'function' 
    ? equal 
    : equal === false 
      ? () => false 
      : (a: T, b: T) => a === b

  // Store observers that depend on this computed
  const dependents: ObserverR[] = []
  let isUpdating = false

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T): T => {
      if (isUpdating) return currentValue!
      
      isUpdating = true
      try {
        const oldValue = observer.value
        
        // Execute the update function to compute new value
        const result = updateFn(currentValue)
        
        // Store result in observer value
        observer.value = result
        
        // If value changed, notify all dependents
        if (oldValue === undefined || !equalFn(oldValue, result)) {
          // Notify all dependents
          const currentDependents = [...dependents]
          currentDependents.forEach(dep => {
            updateObserver(dep as Observer<unknown>)
          })
        }
        
        return result
      } finally {
        isUpdating = false
      }
    },
  }
  
  const compute = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // This computed is being accessed by another observer
      // Add that observer to our dependents list
      if (!dependents.includes(activeObserver)) {
        dependents.push(activeObserver)
      }
    }
    
    // Compute the current value - this will access dependencies
    // and register this computed as their observer
    updateObserver(observer)
    
    return observer.value!
  }
  
  return compute
}