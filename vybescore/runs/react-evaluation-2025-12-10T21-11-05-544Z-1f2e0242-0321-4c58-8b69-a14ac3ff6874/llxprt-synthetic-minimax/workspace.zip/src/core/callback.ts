/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      const result = updateFn(prevValue)
      observer.value = result
      return result
    },
  }
  
  function executeCallback() {
    if (disposed) return
    const previousObserver = getActiveObserver()
    
    // Set this callback as the active observer so dependencies can track it
    setActiveObserver(observer)
    try {
      const result = observer.updateFn(observer.value)
      observer.value = result
      return result
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Initially execute the callback to establish dependencies and get initial value
  executeCallback()
  
  return () => {
    if (disposed) return
    disposed = true
    // Clear dependencies when disposed
    observer.value = undefined
  }
}
