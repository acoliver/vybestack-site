/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  notifySubject,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  let lastComputedValue = value
  
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set<Observer<unknown>>(),
    value: computedValue!,
    equalFn: undefined,
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      computedValue = updateFn(prevValue)
      return computedValue!
    },
  }
  
  const getter: GetterFn<T> = () => {
    // Add the active observer to this subject's observer list for dependency tracking
    const activeObserver = getActiveObserver()
    if (activeObserver && !subject.observers.has(activeObserver)) {
      subject.observers.add(activeObserver)
    }
    
    const newValue = updateObserver(observer)
    subject.value = newValue
    
    // Check if value actually changed and notify if it did
    if (newValue !== lastComputedValue) {
      notifySubject(subject)
      lastComputedValue = newValue
    }
    
    return newValue
  }
  
  return getter
}
