import express, { Request, Response } from 'express';
import path from 'path';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

const __dirname = path.dirname(import.meta.url);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

// Database configuration
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
let db: Database | null = null;

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        return path.join(process.cwd(), `node_modules/sql.js/dist/${file}`);
      }
    });

    // Create data directory if it doesn't exist
    const fs = await import('fs/promises');
    const dataDir = path.dirname(DB_PATH);
    try {
      await fs.access(dataDir);
    } catch {
      await fs.mkdir(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    let existingDb = false;
    try {
      const dbBuffer = await fs.readFile(DB_PATH);
      db = new SQL.Database(new Uint8Array(dbBuffer));
      existingDb = true;
    } catch (error) {
      // File doesn't exist, create new database
      db = new SQL.Database();
    }

    // Initialize schema if needed
    if (!existingDb) {
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = await fsReadFile(schemaPath);
      db.exec(schema);
      await saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Helper functions for file system operations
const fsReadFile = async (filePath: string): Promise<string> => {
  const fs = await import('fs/promises');
  return fs.readFile(filePath, 'utf-8');
};

async function fsWriteFile(filePath: string, data: Uint8Array | string): Promise<void> {
  const fs = await import('fs/promises');
  if (typeof data === 'string') {
    await fs.writeFile(filePath, data);
  } else {
    await fs.writeFile(filePath, Buffer.from(data));
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const data = db.export();
    await fsWriteFile(DB_PATH, data);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validateFormData(data: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Check required fields
  const requiredFields: Array<keyof FormData> = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.trim() === '') {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
    }
  });

  // Validate email
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Validate phone
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Validate postal code (alphanumeric, support international formats)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Express app setup
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    formData: {} as FormData,
    title: 'Contact Us'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvince: (req.body.stateProvince || '').trim(),
    postalCode: (req.body.postalCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim(),
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    res.status(400).render('form', {
      errors: validation.errors,
      formData,
      title: 'Contact Us'
    });
    return;
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    await saveDatabase();
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'Failed to save submission. Please try again.' }],
      formData,
      title: 'Contact Us'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  if (db) {
    await saveDatabase();
    db.close();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  if (db) {
    await saveDatabase();
    db.close();
  }
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
