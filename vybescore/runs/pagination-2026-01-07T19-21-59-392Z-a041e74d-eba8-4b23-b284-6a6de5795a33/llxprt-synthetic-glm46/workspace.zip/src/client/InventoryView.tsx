import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No items found in inventory.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  onPageChange: (page: number) => void;
}): JSX.Element {
  const hasPrev = currentPage > 1;

  return (
    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
      <button
        disabled={!hasPrev}
        onClick={() => onPageChange(currentPage - 1)}
        aria-disabled={!hasPrev}
        aria-label="Previous page"
      >
        Previous
      </button>

      <span style={{ padding: '0 0.5rem' }}>
        Page {currentPage}
      </span>

      <button
        disabled={!hasNext}
        onClick={() => onPageChange(currentPage + 1)}
        aria-disabled={!hasNext}
        aria-label="Next page"
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      
      {data.items.length > 0 && (
        <>
          <InventoryList items={data.items} />
          
          <div style={{ marginTop: '1rem', fontSize: '0.875rem', color: '#666' }}>
            Showing {data.items.length} of {data.total} items
          </div>
          
          <PaginationControls
            currentPage={currentPage}
            hasNext={data.hasNext}
            onPageChange={setCurrentPage}
          />
        </>
      )}
      
      {data.items.length === 0 && (
        <p>No items found in inventory.</p>
      )}
    </section>
  );
}
