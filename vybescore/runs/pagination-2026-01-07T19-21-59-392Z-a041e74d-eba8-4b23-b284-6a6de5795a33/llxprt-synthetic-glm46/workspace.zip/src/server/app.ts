import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page = 1; // Default page
    if (pageParam !== undefined) {
      // Must be numeric
      if (!/^\d+$/.test(pageParam)) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
      page = Number(pageParam);
      
      // Must be positive and not zero
      if (page <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter: must be greater than 0' });
      }
      
      // Prevent excessive page values (security consideration)
      if (page > 10000) {
        return res.status(400).json({ error: 'Invalid page parameter: value too large' });
      }
    }

    // Validate limit parameter
    let limit = 5; // Default limit
    if (limitParam !== undefined) {
      // Must be numeric
      if (!/^\d+$/.test(limitParam)) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      limit = Number(limitParam);
      
      // Must be positive and not zero
      if (limit <= 0) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be greater than 0' });
      }
      
      // Prevent excessive limit values
      if (limit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: value too large (max 100)' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
