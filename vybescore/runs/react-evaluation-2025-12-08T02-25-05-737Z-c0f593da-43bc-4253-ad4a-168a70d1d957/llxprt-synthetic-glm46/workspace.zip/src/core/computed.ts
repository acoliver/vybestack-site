/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  EqualFn,
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>, // Type parameter accepted but not used in core implementation
  options?: { name?: string }
): GetterFn<T> {
  

  const observer: Observer<T> = {
    name: options?.name,
    value: value,
    updateFn,
  }

  const read: GetterFn<T> = () => {
    const active = getActiveObserver()
    if (active) {
      // Cast to access observer property for this observer
      const subject = observer as ObserverR & { observer?: ObserverR }
      subject.observer = active
    }
    
    // Execute the update function to compute current value
    updateObserver(observer)
    return observer.value as T
  }

  return read
}
