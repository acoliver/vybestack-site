#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportFormat, ReportRenderer, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map of format names to renderer functions
const formatRenderers: Record<ReportFormat, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText
};

// Parse command line arguments
function parseArguments(): { dataPath: string; output?: string; format: ReportFormat; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  const parsedArgs = {
    output: undefined as string | undefined,
    format: 'markdown' as ReportFormat,
    includeTotals: false
  };
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      const format = args[i + 1] as ReportFormat;
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Unsupported format: ${format}`);
        process.exit(1);
      }
      parsedArgs.format = format;
      i++; // Skip the format value
    } else if (args[i] === '--output' && i + 1 < args.length) {
      parsedArgs.output = args[i + 1];
      i++; // Skip the output path
    } else if (args[i] === '--includeTotals') {
      parsedArgs.includeTotals = true;
    }
  }
  
  return { dataPath, ...parsedArgs };
}

// Validate and parse the input JSON
function loadReportData(dataPath: string): ReportData {
  try {
    const content = readFileSync(dataPath, 'utf8');
    const data = JSON.parse(content) as unknown;
    
    // Type guard for ReportData
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON structure');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    const entries = obj.entries as unknown[];
    
    for (const entry of entries) {
      if (!entry || typeof entry !== 'object') {
        throw new Error('Invalid entry structure');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error('Missing or invalid "label" in entry');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Missing or invalid "amount" in entry');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Invalid JSON in file: ${dataPath}`);
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    console.error(`Error processing input: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Main execution
function main() {
  const { dataPath, output, format, includeTotals } = parseArguments();
  
  const data = loadReportData(dataPath);
  const renderer = formatRenderers[format];
  const options: ReportOptions = { includeTotals };
  
  const report = renderer.render(data, options);
  
  if (output) {
    writeFileSync(output, report);
  } else {
    console.log(report);
  }
}

main();
