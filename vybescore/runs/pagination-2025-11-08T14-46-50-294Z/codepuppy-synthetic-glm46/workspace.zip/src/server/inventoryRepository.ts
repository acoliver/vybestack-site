import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export interface ValidationError {
  code: string;
  message: string;
}

export interface PaginationOptions {
  page: number;
  limit: number;
}

export function validatePaginationOptions(
  pageParam?: string,
  limitParam?: string
): { options: PaginationOptions } | { error: ValidationError } {
  let page: number;
  let limit: number;

  // Parse and validate page
  if (pageParam === undefined || pageParam === '') {
    page = 1;
  } else {
    if (!/^\d+$/.test(pageParam)) {
      return { error: { code: 'INVALID_PAGE', message: 'Page must be a positive integer' } };
    }
    page = Number(pageParam);
    if (page < 1) {
      return { error: { code: 'INVALID_PAGE', message: 'Page must be greater than 0' } };
    }
  }

  // Parse and validate limit
  if (limitParam === undefined || limitParam === '') {
    limit = DEFAULT_LIMIT;
  } else {
    if (!/^\d+$/.test(limitParam)) {
      return { error: { code: 'INVALID_LIMIT', message: 'Limit must be a positive integer' } };
    }
    limit = Number(limitParam);
    if (limit < 1) {
      return { error: { code: 'INVALID_LIMIT', message: 'Limit must be greater than 0' } };
    }
    if (limit > MAX_LIMIT) {
      return { error: { code: 'LIMIT_TOO_LARGE', message: `Limit cannot exceed ${MAX_LIMIT}` } };
    }
  }

  return { options: { page, limit } };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // Fixed: offset should be (page - 1) * limit to properly paginate
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
