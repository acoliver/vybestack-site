import express, { Request, Response, Application } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { ContactFormData, ValidationError } from './types.js';
import { dbManager } from './database.js';
import { validateFormData, sanitizeFormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3535;

// Helper function to render form with errors
function renderForm(res: Response, data: ContactFormData, errors: ValidationError[] = []) {
  res.render('contact-form', {
    title: 'Friendly Contact Form',
    data,
    errors
  });
}

// Create Express app
export function createApp(): Application {
  const app = express();

  // Initialize database in background (don't block app creation)
  dbManager.initialize().catch(error => {
    console.error('Failed to initialize database:', error);
  });

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  // Set EJS as template engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '..', 'views'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    renderForm(res, {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phoneNumber: ''
    });
  });

  app.post('/submit', async (req: Request, res: Response) => {
    try {
      const formData: ContactFormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phoneNumber: req.body.phoneNumber || ''
      };

      const errors = validateFormData(formData);

      if (errors.length > 0) {
        return renderForm(res, formData, errors);
      }

      const sanitizedData = sanitizeFormData(formData);
      await dbManager.insertSubmission(sanitizedData);

      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error processing form:', error);
      renderForm(res, {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phoneNumber: req.body.phoneNumber || ''
      }, [{
        field: 'firstName',
        message: 'Sorry, there was an error processing your form. Please try again.'
      }]);
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  });

  return app;
}

// Create and configure app
const app = createApp();

// Start server only if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

async function startServer() {
  try {
    await dbManager.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});
