export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber?: string;
}

export interface ValidationError {
  field: keyof ContactFormData;
  message: string;
}

export interface FormState {
  data: ContactFormData;
  errors: ValidationError[];
}