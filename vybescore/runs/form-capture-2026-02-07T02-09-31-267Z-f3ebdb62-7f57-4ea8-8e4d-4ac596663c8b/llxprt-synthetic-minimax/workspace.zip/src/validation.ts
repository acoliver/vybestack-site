import { ContactFormData, ValidationError } from './types.js';

export function validateFormData(data: ContactFormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email'
  ] as const;

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Email validation
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone number validation (allow international formats)
  if (data.phoneNumber && data.phoneNumber.trim() !== '') {
    const phoneRegex = /^@?[\d\s\-()+]*$/;
    if (!phoneRegex.test(data.phoneNumber)) {
      errors.push({
        field: 'phoneNumber',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation (accept alphanumeric for international formats)
  if (data.postalCode && data.postalCode.trim() !== '') {
    const postalRegex = /^[a-zA-Z0-9\s-]*$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return errors;
}

export function sanitizeFormData(data: ContactFormData): ContactFormData {
  return {
    ...data,
    firstName: data.firstName.trim(),
    lastName: data.lastName.trim(),
    streetAddress: data.streetAddress.trim(),
    city: data.city.trim(),
    stateProvince: data.stateProvince.trim(),
    postalCode: data.postalCode.trim(),
    country: data.country.trim(),
    email: data.email.trim().toLowerCase(),
    phoneNumber: data.phoneNumber?.trim() || ''
  };
}