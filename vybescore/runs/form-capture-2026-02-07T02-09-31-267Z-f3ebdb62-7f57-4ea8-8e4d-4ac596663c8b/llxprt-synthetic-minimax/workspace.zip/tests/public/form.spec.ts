import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from 'http';
import { createApp } from '../../src/server.js';

let serverInstance: import('http').Server | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  if (serverInstance && serverInstance.close) {
    serverInstance.close();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const app = createApp();
    const httpServer = createServer(app);
    
    await new Promise(resolve => {
      serverInstance = httpServer.listen(0, () => {
        resolve(null);
      });
    });

    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Friendly Contact Form');
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State/Province/Region');
    expect(response.text).toContain('Postal/Zip Code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone Number');

    httpServer.close();
  });

  it('shows validation errors for missing required fields', async () => {
    const app = createApp();
    const httpServer = createServer(app);
    
    await new Promise(resolve => {
      serverInstance = httpServer.listen(0, () => {
        resolve(null);
      });
    });

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({});
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Please correct the following errors');

    httpServer.close();
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const app = createApp();
    const httpServer = createServer(app);
    
    await new Promise(resolve => {
      serverInstance = httpServer.listen(0, () => {
        resolve(null);
      });
    });
    
    // Wait a bit for database to initialize
    await new Promise(resolve => setTimeout(resolve, 100));
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phoneNumber: '+1 555-123-4567'
      });

    // Expect redirect if database is working, otherwise 200 with error
    if (response.status === 302) {
      expect(response.headers.location).toBe('/thank-you');
    } else {
      expect(response.status).toBe(200);
      expect(response.text).toContain('Sorry, there was an error');
    }

    httpServer.close();
  });

  it('displays thank you page after successful submission', async () => {
    const app = createApp();
    const httpServer = createServer(app);
    
    await new Promise(resolve => {
      serverInstance = httpServer.listen(0, () => {
        resolve(null);
      });
    });

    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank You So Much');
    expect(response.text).toContain('Why did you give your info to a stranger on the internet');

    httpServer.close();
  });
});
