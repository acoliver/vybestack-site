/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both standard Base64 and URL-safe variants, validates input properly.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Convert URL-safe Base64 to standard Base64
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  try {
    // Add padding if missing
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
