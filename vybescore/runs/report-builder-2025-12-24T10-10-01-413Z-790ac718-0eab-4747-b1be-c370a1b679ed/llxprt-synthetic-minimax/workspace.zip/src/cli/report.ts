#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatMap = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

function parseArgs(argv: string[]): {
  filePath?: string;
  format?: Format;
  outputPath?: string;
  includeTotals: boolean;
  error?: string;
} {
  // Skip node and script name
  const args = argv.slice(2);
  
  const result = {
    filePath: undefined as string | undefined,
    format: undefined as Format | undefined,
    outputPath: undefined as string | undefined,
    includeTotals: false,
    error: undefined as string | undefined,
  };

  if (args.length < 1) {
    result.error = 'Missing required argument: <data.json>';
    return result;
  }

  if (args.length < 3) {
    result.error = 'Missing required argument: --format';
    return result;
  }

  result.filePath = args[0];

  // Parse --format
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1) {
    result.error = 'Missing --format argument';
    return result;
  }

  const formatValue = args[formatIndex + 1];
  if (!formatValue || !['markdown', 'text'].includes(formatValue)) {
    result.error = 'Unsupported format';
    return result;
  }

  result.format = formatValue as Format;

  // Parse optional --output
  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1 && args[outputIndex + 1]) {
    result.outputPath = args[outputIndex + 1];
  }

  // Parse --includeTotals
  result.includeTotals = args.includes('--includeTotals');

  return result;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const report = data as Record<string, unknown>;

  // Check required fields
  if (typeof report.title !== 'string') {
    throw new Error('Invalid data: "title" must be a string');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid data: "summary" must be a string');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid data: "entries" must be an array');
  }

  // Validate each entry
  report.entries.forEach((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: entry at index ${index} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: entry at index ${index} must have a string "label"`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid data: entry at index ${index} must have a numeric "amount"`);
    }
  });

  return true;
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    if (args.error) {
      console.error(`Error: ${args.error}`);
      process.exit(1);
    }

    if (!args.filePath || !args.format) {
      console.error('Error: Missing required arguments');
      process.exit(1);
    }

    // Load and parse JSON file
    let rawData: unknown;
    try {
      const fileContent = readFileSync(args.filePath, 'utf-8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.filePath}: ${error.message}`);
        process.exit(1);
      } else {
        console.error(`Error reading file ${args.filePath}: ${error}`);
        process.exit(1);
      }
    }

    // Validate data structure
    try {
      validateReportData(rawData);
    } catch (error) {
      console.error(`Error: ${error}`);
      process.exit(1);
    }

    const data = rawData as ReportData;

    // Render using appropriate formatter
    const formatter = formatMap[args.format];
    if (!formatter) {
      console.error('Error: Unsupported format');
      process.exit(1);
    }

    const output = formatter.format(data, {
      includeTotals: args.includeTotals,
    });

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to file ${args.outputPath}: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Unexpected error: ${error}`);
    process.exit(1);
  }
}

main();
