/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<ObserverR>
  isActive?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  dependents?: Set<ObserverR>
  isActive?: boolean
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
    return observer.value
  } finally {
    setActiveObserver(previous)
  }
}

// Debug function to help track dependency issues
export function debugObserver(observer: ObserverR, label: string) {
  console.log(`${label}:`, {
    name: observer.name,
    hasDependents: !!observer.dependents,
    dependentsCount: observer.dependents?.size || 0,
    dependents: observer.dependents ? Array.from(observer.dependents).map(d => d.name || 'unnamed') : []
  })
}

export function addDependency(source: ObserverR, dependent: ObserverR): void {
  if (!source.dependents) source.dependents = new Set()
  source.dependents.add(dependent)
}

export function removeDependency(source: ObserverR, dependent: ObserverR): void {
  if (source.dependents) {
    source.dependents.delete(dependent)
  }
}

export function notifyDependents(subject: ObserverR): void {
  if (subject.dependents) {
    // Create a copy to avoid issues with modification during iteration
    const dependents = Array.from(subject.dependents)
    for (const dependent of dependents) {
      if ('updateFn' in dependent) {
        // Use updateObserver to properly track dependencies
        updateObserver(dependent as Observer<unknown>)
      }
    }
  }
}
