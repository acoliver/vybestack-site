/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set(),
  }
  
  // Store original update function
  const originalUpdateFn = observer.updateFn

  // Execute callback to establish dependencies during initial setup
  const previousActive = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute the callback function - this will trigger addDependency calls
    observer.value = originalUpdateFn(observer.value)
  } finally {
    setActiveObserver(previousActive)
  }

  // Override updateFn to make it reactive
  observer.updateFn = (_currentValue?: T) => {
    const previousValue = observer.value
    
    // Re-execute the original callback function with proper dependency tracking
    const activeObserverBefore = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      observer.value = originalUpdateFn(previousValue)
      return observer.value
    } finally {
      setActiveObserver(activeObserverBefore)
    }
  }

  const unsubscribe = () => {
    // Remove callback from all dependencies' dependent lists
    // This is handled by the notification system automatically
    // when the callback's updateFn becomes a no-op
    
    // Disable callback by making it a no-op that returns current value
    observer.updateFn = () => observer.value!
  }

  return unsubscribe
}
