/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    dependents: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : 
              equal === false ? ((_a, _b) => false) : 
              undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== s) {
      // Register dependency: this input provides value to the current observer
      addDependency(s as ObserverR, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    const shouldUpdate = !s.equalFn || !s.equalFn(oldValue, nextValue)
    
    if (shouldUpdate) {
      s.value = nextValue
      // Notify all dependents that this input has changed
      notifyDependents(s as ObserverR)
    }
    return s.value
  }

  return [read, write]
}
