import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CliOptions {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    throw new Error('--format parameter is required');
  }

  if (formatIndex + 1 >= args.length) {
    throw new Error('--format parameter must have a value');
  }

  const format = args[formatIndex + 1] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error('Unsupported format');
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

function loadReportData(dataFile: string): ReportData {
  try {
    const content = readFileSync(dataFile, 'utf8');
    const data = JSON.parse(content);

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid JSON: title field is required and must be a string');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid JSON: summary field is required and must be a string');
    }

    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid JSON: entries field is required and must be an array');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid JSON: entries[${i}].label field is required and must be a string`);
      }

      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid JSON: entries[${i}].amount field is required and must be a number`);
      }
    }

    return {
      title: data.title,
      summary: data.summary,
      entries: data.entries
    };
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to load data file: ${error.message}`);
    }
    throw new Error('Failed to load data file: unknown error');
  }
}

function main() {
  try {
    const options = parseArgs(process.argv);
    const reportData = loadReportData(options.dataFile);
    
    let output: string;
    
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options.includeTotals);
        break;
      case 'text':
        output = renderText(reportData, options.includeTotals);
        break;
      default:
        throw new Error('Unsupported format');
    }

    if (options.outputPath) {
      writeFileSync(options.outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(error.message + '\n');
      process.exit(1);
    }
    process.stderr.write('Unknown error\n');
    process.exit(1);
  }
}

main();
