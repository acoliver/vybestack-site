/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input by checking for invalid characters and proper structure.
 */
function isValidBase64(input: string): boolean {
  // Base64 should only contain A-Z, a-z, 0-9, +, /, and padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check for proper padding: padding can only appear at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be contiguous and at the end
    const padding = input.slice(paddingIndex);
    if (!/^=+$/.test(padding)) {
      return false;
    }
    
    // Maximum 2 padding characters allowed
    if (padding.length > 2) {
      return false;
    }
    
    // Total length must be divisible by 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }
  
  // If no padding and not a multiple of 4, it might still be valid
  // but requires special handling during decoding
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64: empty input');
  }
  
  // Remove whitespace which is commonly allowed in Base64
  const normalized = input.replace(/\s+/g, '');
  
  if (!isValidBase64(normalized)) {
    throw new Error('Invalid Base64: input contains invalid characters or improper padding');
  }
  
  try {
    const result = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Validate the result - check for any null bytes which indicate corruption
    if (result.includes('\u0000')) {
      throw new Error('Invalid Base64: decoded result contains invalid characters');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64: failed to decode input');
  }
}
