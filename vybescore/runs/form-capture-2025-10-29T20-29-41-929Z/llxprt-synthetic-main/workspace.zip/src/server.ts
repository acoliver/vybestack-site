import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any;

async function initializeDatabase(): Promise<unknown> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const SQL: any = await initSqlJs();
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  
  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      db = new SQL.Database(fileBuffer);
    } else {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      db = new SQL.Database();
      const schema = fs.readFileSync(
        path.join(__dirname, '..', 'db', 'schema.sql'),
        'utf8'
      );
      db.run(schema);
      saveDatabase(db, dbPath);
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
  
  return db;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function saveDatabase(database: any, dbPath: string): void {
  try {
    const data = database.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function validateForm(formData: any): string[] {
  const errors: string[] = [];
  const requiredFields = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').trim()} is required`);
    }
  }
  
      if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
    if (formData.phone && !/^[\d\s+\-()]+$/.test(formData.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  
    if (formData.postalCode && !/^[A-Za-z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push('Postal code can only contain letters, numbers, spaces, and dashes');
  }
  
  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const errors = validateForm(req.body);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: req.body });
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);
    
    stmt.free();
    
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    saveDatabase(db, dbPath);
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { firstName: 'friend' });
});

// Start server
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let server: any;

async function startServer() {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

startServer();

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close(() => {
      if (db) {
        db.close();
      }
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);