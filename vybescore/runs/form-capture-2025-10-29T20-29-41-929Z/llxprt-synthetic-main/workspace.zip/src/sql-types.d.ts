// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare module 'sql.js' {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export default function initSqlJs(options?: unknown): Promise<SqlJs>;
  
  interface SqlJs {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Database: unknown;
  }
}