import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import type { Server } from 'http';
import type { Express } from 'express';

let server: Server;
let app: Express;
const dbPath = path.resolve(__dirname, '../../data/submissions.sqlite');

// Dynamically import the server module
beforeAll(async () => {
  const serverModule = await import('../../src/server');
  app = serverModule.app;
  server = app.listen(0); // Listen on a random port for testing
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('input[name="first_name"]')).toHaveLength(1);
    expect($('input[name="last_name"]')).toHaveLength(1);
    expect($('input[name="street_address"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="state_province"]')).toHaveLength(1);
    expect($('input[name="postal_code"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(server)
      .post('/submit')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'Anytown',
        state_province: 'State',
        postal_code: 'SW1A 1AA', // UK postal code
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958' // UK phone number
      })
      .expect(302);
      
    expect(response.header.location).toBe('/thank-you');
  });
  
  it('shows validation errors for invalid inputs', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'Anytown',
        state_province: 'State',
        postal_code: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'invalid-email', // Invalid email format
        phone: '+44 20 7946 0958'
      })
      .expect(400);
      
    const $ = cheerio.load(response.text);
    // There will be 9 error-message divs in the template (one for each field)
    // but only one will have content when we have one validation error
    const errorMessages = $('.error-message').filter((i, el) => $(el).text().trim() !== '');
    expect(errorMessages).toHaveLength(1);
    expect(errorMessages.eq(0).text()).toBe('Invalid email format');
  });
  
  it('shows validation errors for missing required fields', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        first_name: '', // Missing required field
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'Anytown',
        state_province: 'State',
        postal_code: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(400);
      
    const $ = cheerio.load(response.text);
    // There will be 9 error-message divs in the template (one for each field)
    // but only one will have content when we have one validation error
    const errorMessages = $('.error-message').filter((i, el) => $(el).text().trim() !== '');
    expect(errorMessages).toHaveLength(1);
    expect(errorMessages.eq(0).text()).toBe('First name is required');
  });
});