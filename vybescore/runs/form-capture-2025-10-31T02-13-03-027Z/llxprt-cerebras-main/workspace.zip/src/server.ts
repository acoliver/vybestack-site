import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import fs from 'fs';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

import type { Database } from 'sql.js';

class DatabaseManager {
  private db: Database | null = null;
  private filePath: string;

  constructor(filePath: string) {
    this.filePath = filePath;
  }

  async initialize(): Promise<void> {
    const SQL = await initSqlJs();
    let dbData: Uint8Array | null = null;
    
    try {
      dbData = fs.readFileSync(this.filePath);
      this.db = new SQL.Database(dbData);
    } catch (err) {
      // If file doesn't exist, create a new database
      this.db = new SQL.Database();
      this.db.run(fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8'));
      this.saveDatabase();
    }
  }

  saveDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(this.filePath, buffer);
  }

  insertSubmission(submission: Submission): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    const stmt = this.db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
    stmt.free();
    this.saveDatabase();
  }

  close(): void {
    if (this.db) {
      this.db.close();
    }
  }
}

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Initialize database
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const dbManager = new DatabaseManager(dbPath);
await dbManager.initialize();

// Validation functions
const validateEmail = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const validatePhone = (phone: string): boolean => {
  return /^[\d\s+()-]+$/.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  return /^[A-Za-z0-9\s-]+$/.test(postalCode);
};

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {},
    formData: {}
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body;
  const errors: Record<string, string> = {};

  // Validation
  if (!formData.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  if (!formData.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  if (!formData.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  if (!formData.city?.trim()) {
    errors.city = 'City is required';
  }
  if (!formData.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  if (!formData.postal_code?.trim()) {
    errors.postal_code = 'Postal code is required';
  } else if (!validatePostalCode(formData.postal_code)) {
    errors.postal_code = 'Invalid postal code format';
  }
  if (!formData.country?.trim()) {
    errors.country = 'Country is required';
  }
  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Invalid email format';
  }
  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Invalid phone number format';
  }

  // If validation errors exist, render form with errors
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { 
      errors,
      formData
    });
  }

  // Insert submission into database
  dbManager.insertSubmission({
    first_name: formData.first_name,
    last_name: formData.last_name,
    street_address: formData.street_address,
    city: formData.city,
    state_province: formData.state_province,
    postal_code: formData.postal_code,
    country: formData.country,
    email: formData.email,
    phone: formData.phone
  });

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  dbManager.close();
  process.exit(0);
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

export { app, dbManager };