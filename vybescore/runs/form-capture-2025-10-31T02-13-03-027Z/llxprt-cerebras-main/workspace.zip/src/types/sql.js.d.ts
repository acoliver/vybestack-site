declare module 'sql.js' {
  export interface QueryResults {
    [index: number]: unknown;
  }
  
  export interface Database {
    run(sql: string, params?: unknown[]): QueryResults;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    run(params?: unknown[]): QueryResults;
    free(): void;
  }
  
  export default function initSqlJs(config?: { locateFile: (file: string) => string }): Promise<{ Database: new (data?: Uint8Array) => Database }>;
}