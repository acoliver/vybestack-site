/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn,
  getActiveObserver,
  setActiveObserver,
  removeDependent,
  registerObserver
} from '../types/reactive.js'

// Global tracking of callback observers
const callbackObservers = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (oldValue?: T): T => {
      // Execute the callback function to track dependencies
      return updateFn(oldValue)
    },
  }
  
  // Register this observer globally and in set
  registerObserver(observer as Observer<unknown>)
  callbackObservers.add(observer as Observer<unknown>)
  
  // Initial execution to establish dependencies
  const prevObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Store initial value for the callback
    observer.value = updateFn(value)
  } finally {
    setActiveObserver(prevObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from tracking
    callbackObservers.delete(observer as Observer<unknown>)
    removeDependent(observer)
  }
}