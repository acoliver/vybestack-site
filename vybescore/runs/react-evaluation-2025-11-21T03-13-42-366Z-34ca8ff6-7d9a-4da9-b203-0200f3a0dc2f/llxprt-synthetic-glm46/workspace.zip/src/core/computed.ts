/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  getActiveObserver,
  setActiveObserver,
  registerObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> & { observer?: ObserverR; initialized?: boolean } = {
    name: options?.name,
    value,
    updateFn,
    initialized: false,
  }
  
  // Register this observer
  registerObserver(o)
  
  const getter = (): T => {
    // When accessed, set this computed as the active observer to track its dependencies
    const previousObserver = getActiveObserver()
    setActiveObserver(o)
    
    try {
      // Only recompute if we have dependencies that might have changed
      // or if this is the first access
      if (!o.initialized) {
        // First access - compute the value
        o.value = updateFn(o.value)
        o.initialized = true
      } else {
        // Recalculate to ensure reactive updates
        const oldValue = o.value
        const newValue = updateFn(oldValue)
        o.value = newValue
      }
      
      return o.value
    } finally {
      // Restore the previous observer
      setActiveObserver(previousObserver)
    }
  }
  
  return getter
}