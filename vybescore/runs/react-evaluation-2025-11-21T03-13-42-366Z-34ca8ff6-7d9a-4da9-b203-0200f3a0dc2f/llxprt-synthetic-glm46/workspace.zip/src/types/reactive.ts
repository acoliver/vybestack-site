/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function clearActiveObserver(): void {
  activeObserver = undefined
}

// Track dependent observers for cascade updates
const dependentObservers = new Set<Observer<unknown>>()

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    dependentObservers.add(observer as Observer<unknown>)
  } finally {
    activeObserver = previous
  }
}

// Store all registered observers for better dependency tracking
const allObservers = new Set<Observer<unknown>>()

export function registerObserver<T>(observer: Observer<T>): void {
  allObservers.add(observer as Observer<unknown>)
}

export function unregisterObserver<T>(observer: Observer<T>): void {
  allObservers.delete(observer as Observer<unknown>)
  dependentObservers.delete(observer as Observer<unknown>)
}

export function notifyDependents(): void {
  // Get all observers and update them
  const observers = Array.from(allObservers)
  
  for (const observer of observers) {
    // Don't update the current active observer to prevent infinite loops
    if (observer !== activeObserver) {
      const previous = activeObserver
      activeObserver = observer
      try {
        observer.value = observer.updateFn(observer.value)
      } finally {
        activeObserver = previous
      }
    }
  }
}

// Function to clear a specific observer from the dependents set
export function removeDependent<T>(observer: Observer<T>): void {
  allObservers.delete(observer as Observer<unknown>)
  dependentObservers.delete(observer as Observer<unknown>)
}