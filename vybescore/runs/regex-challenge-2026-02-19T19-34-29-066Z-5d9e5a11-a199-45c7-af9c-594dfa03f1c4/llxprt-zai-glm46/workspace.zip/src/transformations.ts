/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries after .!?, ensures proper spacing,
 * collapses extra spaces, and tries to preserve abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first character of the entire text
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Find and capitalize after sentence terminators (. ! ?)
  // Use a regex that matches the terminator followed by space(s) and a lowercase letter
  result = result.replace(/([.!?])\s+([a-z])/g, (match, terminator, letter) => {
    return terminator + ' ' + letter.toUpperCase();
  });
  
  // Also handle case where there's no space after terminator (e.g., "hello.how are you?")
  result = result.replace(/([.!?])([a-z])/g, (match, terminator, letter) => {
    return terminator + ' ' + letter.toUpperCase();
  });
  
  // Collapse any multiple spaces that might have been created
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * Extract all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /https?:\/\/(?:[-\w._~:/?#[\]@!$&'()*+,;=%]|%[0-9A-Fa-f]{2})+/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation: .,!?;:)( but keep legitimate URL characters
    return url.replace(/[.,!?;:)(-]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * Always upgrades to https, and rewrites docs paths to docs.example.com
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match: string) => {
    // First, upgrade to https
    let upgraded = match.replace(/^http:/, 'https:');
    
    // Parse the URL to check the path
    const urlObj = new URL(upgraded);
    const pathname = urlObj.pathname;
    const search = urlObj.search;
    
    // Check if path starts with /docs/
    if (pathname.startsWith('/docs/')) {
      // Check for exclusion patterns
      const hasDynamicHints = 
        pathname.includes('cgi-bin') ||
        pathname.includes('.jsp') ||
        pathname.includes('.php') ||
        pathname.includes('.asp') ||
        pathname.includes('.aspx') ||
        pathname.includes('.do') ||
        pathname.includes('.cgi') ||
        pathname.includes('.pl') ||
        pathname.includes('.py') ||
        search.includes('?') ||
        search.includes('&') ||
        search.includes('=');
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        urlObj.hostname = 'docs.example.com';
        upgraded = urlObj.toString();
      }
    }
    
    return upgraded;
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  const maxDays = daysInMonth[month];
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return yearStr;
}
