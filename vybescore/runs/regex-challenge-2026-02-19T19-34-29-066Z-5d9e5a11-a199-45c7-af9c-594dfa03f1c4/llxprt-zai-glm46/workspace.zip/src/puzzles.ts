/**
 * Find words starting with the given prefix, excluding exception words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with the prefix
  const regex = new RegExp('\\b' + escapedPrefix + '\\w+', 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Returns the full match including the digit prefix.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, using word boundary to ensure complete token
  // Only match when not at position 0 (start of string)
  const regex = new RegExp('\\d' + escapedToken + '\\b', 'g');
  
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.substring(i, i + len);
      const next = value.substring(i + len, i + len * 2);
      if (pattern === next) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern - matches various formats including shorthand
  // This pattern handles:
  // - Full IPv6: 8 groups of hex digits
  // - Shorthand with ::
  // - Mixed IPv4 at the end (::ffff:192.168.1.1)
  
  const ipv6Pattern = /(?:^|[\s[\]:])(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}?|::(?:ffff:)?:?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/;
  
  return ipv6Pattern.test(value);
}
