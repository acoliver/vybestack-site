/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  SubjectR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a combined observer/subject structure
  const computed: Observer<T> & SubjectR = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Initial update to track dependencies and compute value
  updateObserver(computed)
  
  // Return a getter that:
  // 1. Registers the caller as an observer of this computed value
  // 2. Returns the current value
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      computed.observers.add(observer)
    }
    return computed.value!
  }
  
  return getter
}
