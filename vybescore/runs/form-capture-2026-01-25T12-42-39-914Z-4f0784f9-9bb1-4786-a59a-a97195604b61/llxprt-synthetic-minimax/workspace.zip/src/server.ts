import express from 'express';
import path from 'node:path';
import fs from 'node:fs/promises';
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface ValidationResult {
  errors: ValidationError[];
  values: Partial<FormData>;
}

class DatabaseManager {
  private db: import('sql.js').Database | null = null;
  private dbPath: string;

  constructor(dbPath: string) {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    try {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      await fs.mkdir(dataDir, { recursive: true });

      // Load existing database or create new one
      const sqljs = await initSqlJs();
      
      let dbBuffer: Uint8Array | null = null;
      try {
        const fileBuffer = await fs.readFile(this.dbPath);
        dbBuffer = new Uint8Array(fileBuffer);
      } catch {
        // File doesn't exist, will create new
      }

      this.db = new sqljs.Database(dbBuffer || undefined);
      
      // Initialize schema if needed
      const schema = await fs.readFile(path.join(process.cwd(), 'db', 'schema.sql'), 'utf-8');
      this.db.exec(schema);
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const binaryArray = this.db.export();
    const buffer = Buffer.from(binaryArray);
    await fs.writeFile(this.dbPath, buffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

function validateFormData(data: FormData): ValidationResult {
  const errors: ValidationError[] = [];
  const values: Partial<FormData> = { ...data };

  // Email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // Required field validation
  const requiredFields = [
    { field: 'firstName', label: 'First name' },
    { field: 'lastName', label: 'Last name' },
    { field: 'streetAddress', label: 'Street address' },
    { field: 'city', label: 'City' },
    { field: 'stateProvince', label: 'State / Province / Region' },
    { field: 'postalCode', label: 'Postal / Zip code' },
    { field: 'country', label: 'Country' },
    { field: 'email', label: 'Email' },
    { field: 'phone', label: 'Phone number' }
  ];

  requiredFields.forEach(({ field, label }) => {
    const value = data[field as keyof FormData]?.trim();
    if (!value) {
      errors.push({
        field,
        message: `${label} is required`
      });
    }
  });

  // Email format validation
  if (data.email && !emailRegex.test(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone number validation (accepts international formats)
  if (data.phone && !/^[+]?[\d\s\-()]{7,}$/.test(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]{3,10}$/.test(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return { errors, values };
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('views', path.join(process.cwd(), 'src', 'templates'));
app.set('view engine', 'ejs');

// Database manager
const dbManager = new DatabaseManager(path.join(process.cwd(), 'data', 'submissions.sqlite'));

// Routes
app.get('/', (_req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvince: (req.body.stateProvince || '').trim(),
    postalCode: (req.body.postalCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim()
  };

  const validation = validateFormData(formData);

  if (validation.errors.length > 0) {
    return res.status(200).render('form', {
      errors: validation.errors.map(e => e.message),
      values: formData
    });
  }

  try {
    await dbManager.insertSubmission(formData);
    await dbManager.saveToDisk();
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = (req.query.firstName as string) || '';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Initialize and start server
async function startServer() {
  try {
    await dbManager.initialize();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Initialize database manager when module is loaded
dbManager.initialize().catch(error => {
  console.error('Failed to initialize database on startup:', error);
});

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  await startServer();
}

export { app as default, dbManager };
