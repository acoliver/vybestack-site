declare module 'sql.js' {
  export class Database {
    constructor(buffer?: ArrayLike<number> | null);
    prepare(sql: string): Statement;
    run(sql: string, params?: unknown[]): Database;
    exec(sql: string): void;
    export(): Uint8Array;
    close(): void;
  }

  export class Statement {
    free(): void;
    run(params?: unknown[]): void;
    step(): unknown;
    get(params?: unknown[]): unknown[];
  }

  export interface SqlJsStatic {
    Database: typeof Database;
  }

  export interface InitSqlJsStatic {
    (config?: unknown): Promise<SqlJsStatic>;
    readonly default: this;
  }

  const initSqlJs: InitSqlJsStatic;
  export default initSqlJs;
  export { Database, Statement } from './dist/sql-wasm.js';
}