/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes padding characters (=) as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error if the input is invalid Base64.
 */
export function decode(input: string): string {
  // Validate Base64 format before attempting to decode
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, and optional padding (=)
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Verify the decode was successful by checking if we got any data
    // and the input wasn't just garbage
    if (input.length > 0 && buffer.length === 0 && !/^[A-Za-z0-9+/]+={0,2}$/.test(input)) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
