#!/usr/bin/env node

import { readFile, writeFile } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { getFormatter } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  // Find --format flag
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format flag is required and must specify a format');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  // Find --output flag (optional)
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  // Check for --includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }
  
  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "amount" field (expected number)`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Read and parse JSON file
    readFile(args.dataFile, 'utf8', (err, jsonString) => {
      if (err) {
        console.error(`Error reading file ${args.dataFile}:`, err.message);
        process.exit(1);
      }
      
      let parsedData: unknown;
      try {
        parsedData = JSON.parse(jsonString);
      } catch (parseErr) {
        console.error(`Error parsing JSON in file ${args.dataFile}:`, parseErr instanceof Error ? parseErr.message : 'Unknown error');
        process.exit(1);
      }
      
      let reportData: ReportData;
      try {
        reportData = validateReportData(parsedData);
      } catch (validationErr) {
        console.error(`Error validating report data:`, validationErr instanceof Error ? validationErr.message : 'Unknown error');
        process.exit(1);
      }
      
      // Get formatter and render report
      try {
        const formatter = getFormatter(args.format);
        const options: RenderOptions = {
          includeTotals: args.includeTotals,
        };
        const output = formatter(reportData, options);
        
        // Write output
        if (args.outputPath) {
          writeFile(args.outputPath, output, 'utf8', (writeErr) => {
            if (writeErr) {
              console.error(`Error writing to file ${args.outputPath}:`, writeErr.message);
              process.exit(1);
            }
          });
        } else {
          console.log(output);
        }
      } catch (formatterErr) {
        console.error(formatterErr instanceof Error ? formatterErr.message : 'Unknown formatter error');
        process.exit(1);
      }
    });
  } catch (parseErr) {
    console.error('Error parsing command line arguments:', parseErr instanceof Error ? parseErr.message : 'Unknown error');
    process.exit(1);
  }
}

main();