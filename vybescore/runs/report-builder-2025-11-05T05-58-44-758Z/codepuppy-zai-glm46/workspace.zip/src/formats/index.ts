import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { ReportFormatter } from '../types.js';

export const formatters: Record<string, ReportFormatter['render']> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}

export function getFormatter(format: string): ReportFormatter['render'] {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}