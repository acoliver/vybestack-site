/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers = new Set<Observer<unknown>>()
  
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    observers
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this subject as a dependency of the active observer
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      observer.subjects.add(s)
      observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Notify all dependent observers
    if (oldValue !== nextValue) {
      const toUpdate = Array.from(observers)
      toUpdate.forEach(obs => {
        if (!obs.disposed) {
          updateObserver(obs as Observer<unknown>)
        }
      })
    }
    return s.value
  }

  return [read, write]
}
