/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, updateObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false
  }
  
  // Execute callback immediately to establish dependencies and get initial value
  const previousActive = getActiveObserver()
  setActiveObserver(undefined)
  try {
    observer.value = updateFn(observer.value)
  } finally {
    setActiveObserver(previousActive)
  }
  
  return () => {
    // Mark as disposed to prevent further updates
    observer.disposed = true
  }
}
