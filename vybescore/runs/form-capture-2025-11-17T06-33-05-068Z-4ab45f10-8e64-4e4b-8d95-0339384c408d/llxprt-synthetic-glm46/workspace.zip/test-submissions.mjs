#!/usr/bin/env node
// Test client to simulate form submissions
import http from 'http';

const host = 'localhost';
const port = 3535;

// Test data with international phone/postal formats
const testSubmissions = [
  {
    description: 'US-based submission',
    data: {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 212-555-1234'
    }
  },
  {
    description: 'UK-based submission',
    data: {
      firstName: 'James',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'james.smith@example.co.uk',
      phone: '+44 20 7946 0958'
    }
  },
  {
    description: 'Argentina-based submission',
    data: {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1000',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.garcia@example.com.ar',
      phone: '+54 9 11 1234-5678'
    }
  }
];

function postData(data) {
  return Object.entries(data)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join('&');
}

async function makeRequest(path, method = 'GET', postDataString = '') {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: host,
      port: port,
      path: path,
      method: method,
      headers: {
        'Content-Type': postDataString ? 'application/x-www-form-urlencoded' : 'text/html',
        'Content-Length': postDataString ? Buffer.byteLength(postDataString) : 0,
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          data: data
        });
      });
    });

    req.on('error', (e) => {
      reject(e);
    });

    if (postDataString) {
      req.write(postDataString);
    }
    req.end();
  });
}

async function testFormSubmissions() {
  console.log('Starting form submission tests...\n');
  
  try {
    // First, test the form page loads correctly
    console.log('Testing GET / (form page)...');
    const formPage = await makeRequest('/');
    console.log(`Status: ${formPage.statusCode}`);
    console.log(`Response contains form: ${formPage.data.includes('id="firstName"') ? '[OK]' : ''}\n`);
    
    // For each test submission
    for (const test of testSubmissions) {
      console.log(`Testing ${test.description}...`);
      
      // Submit the form
      const postResponse = await makeRequest('/submit', 'POST', postData(test.data));
      console.log(`Submit status: ${postResponse.statusCode}`);
      
      if (postResponse.statusCode === 302) {
        console.log('Redirect location:', postResponse.headers.location);
        
        // Follow redirect to thank-you page
        const thankYouPage = await makeRequest(postResponse.headers.location);
        console.log(`Thank-you page status: ${thankYouPage.statusCode}`);
        console.log(`Contains humorous text: ${thankYouPage.data.includes('stranger') ? '[OK]' : ''}`);
      } else {
        console.log('Error response:', postResponse.data.substring(0, 200));
      }
      
      console.log('[OK] Test completed\n');
    }
    
    // Check that the database file exists and has data
    console.log('Checking database file...');
    const fs = await import('fs');
    const path = await import('path');
    const dbPath = path.resolve('data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const stats = fs.statSync(dbPath);
      console.log(`Database file size: ${stats.size} bytes [OK]`);
    } else {
      console.log('Database file not found ');
    }
    
    console.log('All tests completed successfully!');
    
  } catch (error) {
    console.error('Test failed:', error.message);
    process.exit(1);
  }
}

// Start the tests
testFormSubmissions();