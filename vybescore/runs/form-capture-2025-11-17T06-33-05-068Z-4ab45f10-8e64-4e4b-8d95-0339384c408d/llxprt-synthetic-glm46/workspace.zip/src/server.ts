import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import initSqlJs from "sql.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Set up EJS as the view engine
app.set("view engine", "ejs");
// Use src/templates for views when in development, dist/templates when in production
if (__dirname.includes("dist")) {
  app.set("views", path.join(__dirname, "templates"));
} else {
  app.set("views", path.join(__dirname, "templates"));
}

// Serve static files
if (__dirname.includes("dist")) {
  app.use(express.static(path.join(__dirname, "public")));
} else {
  app.use(express.static(path.join(__dirname, "..", "public")));
}
app.use(express.urlencoded({ extended: true }));

// Database setup
let db: import("sql.js").Database | null = null;
let dbPath: string;
if (__dirname.includes("dist")) {
  dbPath = path.join(__dirname, "data", "submissions.sqlite");
} else {
  dbPath = path.join(__dirname, "..", "data", "submissions.sqlite");
}

async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Read schema file
    const schemaPath = __dirname.includes("dist") 
      ? path.join(__dirname, "db", "schema.sql")
      : path.join(__dirname, "..", "db", "schema.sql");
    const schema = fs.readFileSync(schemaPath, "utf-8");

    // Load or create the database
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }

    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    db = new SQL.Database(dbData || undefined);
    if (db) {
      db.run(schema);
    }

    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Failed to initialize database:", error);
    process.exit(1);
  }
}

function saveDatabase(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (db) {
      const data = db.export();
      fs.writeFile(dbPath, data, (err) => {
        if (err) {
          console.error("Error saving database:", err);
          reject(err);
        } else {
          resolve();
        }
      });
    } else {
      resolve();
    }
  });
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return false;
  }
  return true;
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /\+?[\d\s\-()]+/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalCodeRegex = /^[\dA-Za-z\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

type FormErrors = {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  form?: string;
};

// Routes
app.get("/", (req, res) => {
  res.render("form", {
    title: "Friendly Contact Form",
    errors: {},
    formData: {},
  });
});

app.post("/submit", async (req, res) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone,
  } = req.body;

  const errors: FormErrors = {};

  // Validation
  if (!firstName || firstName.trim() === "") {
    errors.firstName = "First name is required";
  }

  if (!lastName || lastName.trim() === "") {
    errors.lastName = "Last name is required";
  }

  if (!streetAddress || streetAddress.trim() === "") {
    errors.streetAddress = "Street address is required";
  }

  if (!city || city.trim() === "") {
    errors.city = "City is required";
  }

  if (!stateProvince || stateProvince.trim() === "") {
    errors.stateProvince = "State/Province is required";
  }

  if (!postalCode || postalCode.trim() === "") {
    errors.postalCode = "Postal code is required";
  } else if (!validatePostalCode(postalCode)) {
    errors.postalCode = "Please enter a valid postal code";
  }

  if (!country || country.trim() === "") {
    errors.country = "Country is required";
  }

  if (!email || email.trim() === "") {
    errors.email = "Email is required";
  } else if (!validateEmail(email)) {
    errors.email = "Please enter a valid email address";
  }

  if (!phone || phone.trim() === "") {
    errors.phone = "Phone number is required";
  } else if (!validatePhone(phone)) {
    errors.phone = "Please enter a valid phone number";
  }

  // If there are errors, re-render the form
  if (Object.keys(errors).length > 0) {
    res.status(400).render("form", {
      title: "Friendly Contact Form",
      errors,
      formData: {
        firstName,
        lastName,
        streetAddress,
        city,
        stateProvince,
        postalCode,
        country,
        email,
        phone,
      },
    });
    return;
  }

  // Save to database
  try {
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        firstName,
        lastName,
        streetAddress,
        city,
        stateProvince,
        postalCode,
        country,
        email,
        phone,
      ]);

      stmt.free();
      await saveDatabase();
    }
  } catch (error) {
    console.error("Error saving form submission:", error);
    errors.form = "An error occurred while saving your submission. Please try again.";
    res.status(500).render("form", {
      title: "Friendly Contact Form",
      errors,
      formData: {
        firstName,
        lastName,
        streetAddress,
        city,
        stateProvince,
        postalCode,
        country,
        email,
        phone,
      },
    });
    return;
  }

  res.redirect(302, "/thank-you");
});

app.get("/thank-you", (req, res) => {
  res.render("thank-you", {
    title: "Thank You!",
  });
});

// Start server
async function startServer(): Promise<import('http').Server> {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('SIGTERM received, shutting down gracefully');
    if (db) {
      await saveDatabase();
      db.close();
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });
  
  return server;
}

startServer().catch(console.error);