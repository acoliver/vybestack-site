declare module "sql.js" {
  export interface Database {
    run(sql: string): void;
    export(): Uint8Array;
    prepare(sql: string): Statement;
    close(): void;
  }
  
  export interface Statement<T = Record<string, unknown>> {
    run(params?: unknown[]): void;
    get(params?: unknown[]): T | null;
    free(): void;
    all(params?: unknown[]): T[];
  }
  
  export const initSqlJs: (options?: { locateFile?: (file: string) => string }) => Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
  
  export default initSqlJs;
}