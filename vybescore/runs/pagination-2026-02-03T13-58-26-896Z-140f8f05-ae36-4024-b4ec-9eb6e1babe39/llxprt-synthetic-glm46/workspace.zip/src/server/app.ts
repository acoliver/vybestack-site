import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;
      
      // Validate page parameter
      let page;
      if (pageParam === undefined) {
        page = 1; // Default page
      } else {
        // Check if page is a valid positive integer
        if (!/^\d+$/.test(pageParam)) {
          return res.status(400).json({ error: 'Page parameter must be a positive integer' });
        }
        page = Number(pageParam);
        if (page <= 0) {
          return res.status(400).json({ error: 'Page parameter must be greater than 0' });
        }
        // Prevent excessive page numbers
        if (page > 1000) {
          return res.status(400).json({ error: 'Page parameter too large' });
        }
      }
      
      // Validate limit parameter
      let limit;
      if (limitParam === undefined) {
        limit = 5; // Default limit
      } else {
        // Check if limit is a valid positive integer
        if (!/^\d+$/.test(limitParam)) {
          return res.status(400).json({ error: 'Limit parameter must be a positive integer' });
        }
        limit = Number(limitParam);
        if (limit <= 0) {
          return res.status(400).json({ error: 'Limit parameter must be greater than 0' });
        }
        // Prevent excessive limit values
        if (limit > 100) {
          return res.status(400).json({ error: 'Limit parameter too large' });
        }
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error processing inventory request:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
