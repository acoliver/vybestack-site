import express, { Express } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const publicPath = path.join(__dirname, '..', 'public');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
interface ServerState {
  db: {
    Database: any;
    db: any;
  } | null;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

const serverState: ServerState = {
  db: null,
};

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?\d[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  return postalCode.trim().length > 0 && /^[a-zA-Z0-9\s-]+$/.test(postalCode);
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    let db;

    if (fs.existsSync(dbPath)) {
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
    } else {
      db = new SQL.Database();
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      
      const data = db.export();
      if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
      }
      fs.writeFileSync(dbPath, Buffer.from(data));
    }

    serverState.db = { Database: SQL, db };
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (serverState.db) {
    try {
      const data = serverState.db.db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

app.use(express.static(publicPath));
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

function validateForm(formData: FormData): { errors: string[]; valid: boolean } {
  const errors: string[] = [];

  if (!formData.firstName.trim()) {
    errors.push('First name is required');
  }

  if (!formData.lastName.trim()) {
    errors.push('Last name is required');
  }

  if (!formData.streetAddress.trim()) {
    errors.push('Street address is required');
  }

  if (!formData.city.trim()) {
    errors.push('City is required');
  }

  if (!formData.stateProvince.trim()) {
    errors.push('State/Province/Region is required');
  }

  if (!formData.country.trim()) {
    errors.push('Country is required');
  }

  if (!validatePostalCode(formData.postalCode)) {
    errors.push('Invalid postal code format');
  }

  if (!validateEmail(formData.email)) {
    errors.push('Invalid email format');
  }

  if (!validatePhone(formData.phone)) {
    errors.push('Invalid phone number format');
  }

  return { errors, valid: errors.length === 0 };
}

app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);
  if (!validation.valid) {
    res.status(400).render('form', { errors: validation.errors, values: formData });
    return;
  }

  try {
    const stmt = serverState.db!.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();
    saveDatabase();
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['Database error occurred. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

async function startServer(): Promise<Express> {
  await initializeDatabase();

  return new Promise((resolve, reject) => {
    const server = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
      resolve(app);
    });

    server.on('error', (error) => {
      console.error('Server error:', error);
      reject(error);
    });

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    function gracefulShutdown(): void {
      console.log('Shutting down gracefully...');
      server.close(() => {
        console.log('Server closed');
        if (serverState.db) {
          try {
            serverState.db.db.close();
            saveDatabase();
            console.log('Database closed');
          } catch (error) {
            console.error('Error closing database:', error);
          }
        }
        process.exit(0);
      });
    }
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;
