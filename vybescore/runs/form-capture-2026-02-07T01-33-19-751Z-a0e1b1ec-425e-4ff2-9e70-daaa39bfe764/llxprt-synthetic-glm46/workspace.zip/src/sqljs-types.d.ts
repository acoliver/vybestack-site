declare module 'sql.js' {
  class Database {
    constructor(data?: ArrayBuffer);
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  class Statement {
    run(params?: unknown[]): void;
    free(): void;
  }
  
  function initSqlJs(): Promise<{Database: typeof Database, Statement: typeof Statement}>;
  
  export { Database, Statement, initSqlJs as default };
}