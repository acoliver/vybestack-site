import express from 'express';
import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.resolve('data', 'submissions.sqlite');

let db: import('sql.js').Database | null = null;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

// Initialize database
async function initDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    const dbExists = fs.existsSync(dbPath);

    if (dbExists) {
      const dbFile = fs.readFileSync(dbPath);
      db = new SQL.Database(dbFile.buffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  try {
    if (!db) throw new Error('Database not initialized');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateSubmission(formData: FormSubmission): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  // Required fields validation
  if (!formData.firstName.trim()) errors.firstName = 'First name is required';
  if (!formData.lastName.trim()) errors.lastName = 'Last name is required';
  if (!formData.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!formData.city.trim()) errors.city = 'City is required';
  if (!formData.stateProvince.trim()) errors.stateProvince = 'State is required';
  if (!formData.postalCode.trim()) errors.postalCode = 'Postal code is required';
  if (!formData.country.trim()) errors.country = 'Country is required';
  if (!formData.email.trim()) errors.email = 'Email is required';
  if (!formData.phone.trim()) errors.phone = 'Phone number is required';

  // Format validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (formData.phone && !validatePhone(formData.phone)) {
    errors.phone = 'Phone number should start with + and contain only digits, spaces, dashes, and parentheses';
  }

  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Postal code contains invalid characters';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: null, values: {} });
});

app.post('/submit', async (req, res) => {
  const formData: FormSubmission = req.body as FormSubmission;
  
  const validation = validateSubmission(formData);
  
  if (!validation.isValid) {
    return res.render('form', { 
      errors: Object.values(validation.errors), 
      values: formData 
    });
  }

  // Initialize database if not initialized
  if (!db) {
    await initDatabase();
  }

  try {
    // Insert into database
    const stmt = db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', { 
      errors: ['Database error occurred. Please try again.'], 
      values: formData 
    });
  }
});

app.get('/thank-you', (req, res) => {
  // We'll use a generic greeting since we're not passing the first name
  res.render('thank-you', { firstName: 'friend' });
});

// Graceful shutdown function
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      saveDatabase();
      db.close();
      console.log('Database closed.');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  if (server) {
    server.close(() => {
      console.log('Server closed.');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }

  // Force close if it takes too long
  setTimeout(() => {
    console.error('Forced shutdown');
    process.exit(1);
  }, 5000);
}

// Handle graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

export { app, initDatabase };

// Start server only when this file is run directly
let server: ReturnType<typeof app.listen> | null = null;

if (import.meta.url === `file://${process.argv[1]}`) {
  initDatabase().then(() => {
    server = app.listen(port, () => {
      console.log(`Server listening on port ${port}`);
    });
  });
}
