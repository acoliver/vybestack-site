import request from 'supertest';
import { app } from '../../src/server';
import { initDatabase } from '../../src/server';

// Initialize database before tests
before(async () => {
  await initDatabase();
});

export { request, app };