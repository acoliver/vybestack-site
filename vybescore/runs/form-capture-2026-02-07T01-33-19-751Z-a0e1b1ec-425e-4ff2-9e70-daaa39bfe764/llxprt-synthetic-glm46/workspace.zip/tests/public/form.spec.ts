import { describe, expect, it, beforeAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import { app, initDatabase } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

// Initialize database before all tests
beforeAll(async () => {
  await initDatabase();
});



describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const { app } = await import('../../src/server');
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const { app } = await import('../../src/server');
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555-123-4567'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify data was saved
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
