import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../../src/server.js';
import initSqlJs from 'sql.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  beforeAll(async () => {
    // Initialize the database manually and store it globally for the server to access
    const SQL = await initSqlJs();
    
    let data: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    } else {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }
    
    const db = new SQL.Database(data);
    
    // Load schema if database is new
    const schemaPath = path.resolve(__dirname, '../../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
    
    // Store database in global scope for the server to access during tests
    (global as unknown as { __test_db__: Database }).__test_db__ = db;
    
    // Save database to disk
    const exportData = db.export();
    fs.writeFileSync(dbPath, Buffer.from(exportData));
    
    console.log(`Database created at ${dbPath}`);
  });

  afterAll(() => {
    // Close the database connection after tests
    const db = (global as unknown as { __test_db__: Database }).__test_db__;
    if (db) {
      db.close();
    }
    
    // Debug: Check if file exists after tests
    console.log(`Database file exists at end: ${fs.existsSync(dbPath)}`);
  });

  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for form elements
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
    
    // Check for all required fields
    const requiredFields = [
      { id: 'firstName', name: 'firstName', label: 'First name' },
      { id: 'lastName', name: 'lastName', label: 'Last name' },
      { id: 'streetAddress', name: 'streetAddress', label: 'Street address' },
      { id: 'city', name: 'city', label: 'City' },
      { id: 'stateProvince', name: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', name: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', name: 'country', label: 'Country' },
      { id: 'email', name: 'email', label: 'Email' },
      { id: 'phone', name: 'phone', label: 'Phone number' }
    ];
    
    for (const field of requiredFields) {
      // Check for label with proper for attribute
      expect($(`label[for="${field.id}"]`).text().trim()).toContain(field.label);
      
      // Check for input with proper id and name
      expect($(`input[id="${field.id}"][name="${field.name}"]`)).toHaveLength(1);
    }
    
    // Check for submit button
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database file
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'Country',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form data
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Debug response content if it fails
    if (response.status !== 302) {
      console.log(`Response status: ${response.status}`);
      console.log(`Response text: ${response.text}`);
    }
    
    // Debug database file existence
    console.log(`Database path: ${dbPath}`);
    console.log(`Database file exists after submission: ${fs.existsSync(dbPath)}`);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=John/);
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check that the database is not empty (it has at least one submission)
    if (fs.existsSync(dbPath)) {
      const SQL = await initSqlJs();
      const dbData = fs.readFileSync(dbPath);
      const testDb = new SQL.Database(dbData);
      const result = testDb.exec('SELECT COUNT(*) as count FROM submissions');
      const count = result[0].values[0][0] as number;
      expect(count).toBeGreaterThan(0);
      console.log(`Found ${count} submissions in database`);
      testDb.close();
    }
    
    // Verify we can access the thank you page
    const thankYouResponse = await request(app).get('/thank-you?firstName=John');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('John');
  });
});