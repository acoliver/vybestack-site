import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 3000;

// Database setup
let db: Database | null = null;
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

// Make database globally accessible for tests
(global as unknown as { __test_db__: Database | null }).__test_db__ = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let data: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    } else {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }
    
    db = new SQL.Database(data);
    
    // Load schema if database is new
    const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
    
    // Store database globally for tests
    (global as unknown as { __test_db__: Database | null }).__test_db__ = db;
    
    saveDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  const currentDb = db || (global as unknown as { __test_db__: Database | null }).__test_db__;
  if (!currentDb) return;
  
  try {
    const data = currentDb.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Form validation
function validateForm(formData: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      errors.push(`${fieldName} is required`);
    }
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (formData.email && !emailRegex.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation - allows digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  if (formData.phone && !phoneRegex.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation - allows alphanumeric
  const postalCodeRegex = /^[a-zA-Z0-9\s]+$/;
  if (formData.postalCode && !postalCodeRegex.test(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const { isValid, errors } = validateForm(req.body);
  
  if (!isValid) {
    return res.status(400).render('form', { 
      errors, 
      values: req.body 
    });
  }
  
  // Try to get database from server or from global store
  const currentDb = db || (global as unknown as { __test_db__: Database | null }).__test_db__;
  
  if (!currentDb) {
    return res.status(500).send('Database not available');
  }
  
  // Insert into database
  const stmt = currentDb.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    stmt.free();
    res.status(500).send('Failed to save submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      const currentDb = db || (global as unknown as { __test_db__: Database | null }).__test_db__;
      if (currentDb) {
        currentDb.close();
        console.log('Database connection closed');
      }
      process.exit(0);
    });
  } else {
    const currentDb = db || (global as unknown as { __test_db__: Database | null }).__test_db__;
    if (currentDb) {
      currentDb.close();
      console.log('Database connection closed');
    }
    process.exit(0);
  }
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Export for testing
let server: ReturnType<typeof app.listen> | null = null;

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer()
    .then(() => {
      console.log('Server started successfully');
    })
    .catch((error) => {
      console.error('Failed to start server:', error);
      process.exit(1);
    });
}

export { app, server, shutdown };
