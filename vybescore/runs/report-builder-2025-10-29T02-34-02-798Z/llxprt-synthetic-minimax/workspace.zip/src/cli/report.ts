import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Skip 'node' and script name
  const argsList = argv.slice(2);

  for (let i = 0; i < argsList.length; i++) {
    const arg = argsList[i];

    switch (arg) {
      case '--format':
        if (i + 1 >= argsList.length) {
          throw new Error('Missing value for --format');
        }
        args.format = argsList[i + 1];
        i++; // Skip next item as it's the value
        break;

      case '--output':
        if (i + 1 >= argsList.length) {
          throw new Error('Missing value for --output');
        }
        args.output = argsList[i + 1];
        i++; // Skip next item as it's the value
        break;

      case '--includeTotals':
        args.includeTotals = true;
        break;

      default:
        // First non-flag argument is the data file
        if (!args.dataFile) {
          args.dataFile = arg;
        }
        break;
    }
  }

  if (!args.dataFile) {
    throw new Error('Missing data file argument');
  }

  if (!args.format) {
    throw new Error('Missing --format argument');
  }

  return args;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as Record<string, unknown>;

  // Validate title
  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  // Validate summary
  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  // Validate entries
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  const entries = report.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${index}].amount must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Read and parse JSON file
    const fileContent = readFileSync(args.dataFile, 'utf8');
    let jsonData: unknown;

    try {
      jsonData = JSON.parse(fileContent);
    } catch {
      throw new Error(`Failed to parse JSON file: ${args.dataFile}`);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Prepare render options
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    // Select formatter
    let formatter;
    switch (args.format) {
      case 'markdown':
        formatter = renderMarkdown;
        break;
      case 'text':
        formatter = renderText;
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }

    // Render the report
    const output = formatter(reportData, options);

    // Write output
    if (args.output) {
      writeFileSync(args.output, output);
    } else {
      process.stdout.write(output + '\n');
    }

  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(`Error: ${error.message}\n`);
    } else {
      process.stderr.write('An unknown error occurred\n');
    }
    process.exit(1);
  }
}

main();