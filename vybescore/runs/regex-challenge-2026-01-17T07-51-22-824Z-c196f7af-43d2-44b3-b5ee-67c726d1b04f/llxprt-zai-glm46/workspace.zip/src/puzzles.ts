/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix (word boundaries)
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const word = match[1];
    
    // Check if word is not in exceptions
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token preceded by a digit, capture the digit + token
  const pattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[1]);
  }
  
  return matches;
}

/**
 * Validate passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const regexString = `(.{${len}})\\1`;
    const pattern = new RegExp(regexString, 'g');
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that excludes IPv4 addresses
  // Supports shorthand :: notation
  // Groups of 1-4 hex digits separated by colons, allowing :: for consecutive zero groups
  const ipv6Pattern = /(?:^|[^0-9.])([0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){7}|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,7}:)(?:$|[^0-9a-fA-F:])/;
  
  // Also check for common IPv6 patterns more flexibly
  // Full IPv6: 8 groups of 1-4 hex digits
  const fullIpv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: (double colon shorthand)
  const shorthandIpv6 = /\b(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4})*\b/;
  
  // Ensure we're not matching IPv4 embedded in IPv6 notation (::ffff:192.168.1.1)
  const ipv4Embedded = /\[?::ffff:(?:\d{1,3}\.){3}\d{1,3}\]?/i;
  
  // If it looks like IPv4 embedded, it's still IPv6 format
  if (ipv4Embedded.test(value)) {
    return true;
  }
  
  // Check for plain IPv4 and exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value) && !ipv6Pattern.test(value)) {
    return false;
  }
  
  return fullIpv6.test(value) || shorthandIpv6.test(value);
}
