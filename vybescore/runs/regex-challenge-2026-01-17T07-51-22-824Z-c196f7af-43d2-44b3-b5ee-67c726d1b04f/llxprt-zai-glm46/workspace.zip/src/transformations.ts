/**
 * Capitalize the first character of each sentence.
 * Inserts one space between sentences and collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ');
  
  // Ensure exactly one space after sentence terminators (. ! ?)
  // But be careful with abbreviations (e.g., "Mr.", "Dr.", "etc.")
  // Add space after sentence terminators if missing, but skip common abbreviations
  normalized = normalized.replace(/([.!?])(?!\s)(?!(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|etc|eg|ie|approx|est)\.)/g, '$1 ');
  
  // Split into sentences, capitalize first letter of each
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  
  const capitalized = sentences.map(sentence => {
    if (sentence.length === 0) return '';
    
    // Capitalize first letter that's actually a letter
    return sentence.replace(/^[^a-zA-Z\u00C0-\uFFFF]*([a-zA-Z\u00C0-\uFFFF])/, (_, firstLetter) => {
      return firstLetter.toUpperCase();
    });
  });
  
  // Join with single spaces and trim trailing whitespace
  return capitalized.join(' ').trim();
}

/**
 * Find URLs in text. Returns array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: http:// or https:// followed by non-whitespace characters
  // Include dots in the URL, but stop at whitespace or certain punctuation
  const urlPattern = /https?:\/\/[^\s<]+/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:)]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade to https://
 * - Move /docs/ paths to docs.example.com
 * - Skip host rewrite for cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for http://example.com URLs
  const pattern = /(http:\/\/example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(pattern, (match, host, path = '') => {
    // Always upgrade scheme to https
    let newHost = 'https://example.com';
    
    // Check if we should rewrite the host (only for /docs/ paths without dynamic content)
    if (path && path.startsWith('/docs/')) {
      // Check for excluded patterns in the path
      const excludedPatterns = [
        /cgi-bin/,
        /\?/,
        /&/,
        /=/,
        /\.jsp$/,
        /\.php$/,
        /\.asp$/,
        /\.aspx$/,
        /\.do$/,
        /\.cgi$/,
        /\.pl$/,
        /\.py$/
      ];
      
      const shouldExclude = excludedPatterns.some(pattern => pattern.test(path));
      
      if (!shouldExclude) {
        // Rewrite host to docs.example.com
        newHost = 'https://docs.example.com';
      }
    }
    
    return newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Returns 'N/A' for invalid formats.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Basic year validation (should be reasonable)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) {
    return 'N/A';
  }
  
  return year;
}
