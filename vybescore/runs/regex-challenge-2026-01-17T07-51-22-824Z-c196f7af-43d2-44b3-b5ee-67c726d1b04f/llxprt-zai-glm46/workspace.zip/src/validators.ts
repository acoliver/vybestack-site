export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (localPart.endsWith('.') || localPart.startsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain starting or ending with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Reject consecutive dots in domain parts
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-') || part === '') {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common separators and optional +1 country code.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Clean the input - remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Extract country code if present
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits for US number
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, etc.) but keep digits and +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Match pattern: optional +54, optional 0 trunk, optional 9 mobile, area code (2-4 digits), subscriber (6-8 digits)
  // Area code must start with 1-9 (not 0)
  let digits = cleaned;
  let hasCountryCode = false;
  
  if (digits.startsWith('+54')) {
    digits = digits.substring(3);
    hasCountryCode = true;
  }
  
  // Check for optional trunk prefix 0 before area code
  let hasTrunkPrefix = false;
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
    hasTrunkPrefix = true;
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for optional mobile indicator 9
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Area code: 2-4 digits, must start with 1-9
  const areaCodeMatch = digits.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const [, areaCode, subscriber] = areaCodeMatch;
  
  // Validate area code length (2-4 digits total)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Total digits check: country (54) + trunk (0/1) + mobile (9/1) + area (2-4) + subscriber (6-8)
  // Should be: 10-13 digits total after + (or 10-12 without country code)
  const totalDigits = cleaned.replace(/\+/g, '').length;
  if (totalDigits < 10 || totalDigits > 13) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least 2 characters, no consecutive spaces
  const nameRegex = /^[\p{L}\p{M}'’-]+(?:[\p{L}\p{M}'’-]+(?:\s[\p{L}\p{M}'’-]+)*)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start/end with space, hyphen, or apostrophe
  if (/^[\s\-'’]|[\s\-'’]$/.test(value)) {
    return false;
  }
  
  // Reject names with symbols (except allowed apostrophes, hyphens)
  // Check for characters that are not letters, marks, spaces, hyphens, or apostrophes
  const invalidChars = /[^\p{L}\p{M}\s'’-]/u;
  if (invalidChars.test(value)) {
    return false;
  }
  
  // Must have at least 2 characters (after trimming)
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Run Luhn checksum validation on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa, Mastercard, Amex).
 * Checks length/prefix and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13-19 digits, starts with 4
  const visaRegex = /^4\d{12,18}$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // Amex: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || 
                       mastercardRegex.test(cleaned) || 
                       amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
