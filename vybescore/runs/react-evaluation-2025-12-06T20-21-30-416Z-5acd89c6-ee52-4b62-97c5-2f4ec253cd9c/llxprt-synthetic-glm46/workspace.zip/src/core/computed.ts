/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  trackDependency,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    update: false,
  }
  
  // Track dependencies by running initial computation
  updateObserver(o)
  
  // Return getter function
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Link this computed value to the active observer (callback or another computed)
      o.observer = observer
      
      // Track this dependency globally as well
      trackDependency(o as Observer<unknown>, observer as Observer<unknown>)
    }
    
    if (('update' in o && (o as Observer<T>).update) || o.value === undefined) {
      // Re-compute if value is stale or marked as needing update
      updateObserver(o)
      if ('update' in o) {
        (o as Observer<T>).update = false
      }
    }
    
    return o.value!
  }
  
  return getter
}
