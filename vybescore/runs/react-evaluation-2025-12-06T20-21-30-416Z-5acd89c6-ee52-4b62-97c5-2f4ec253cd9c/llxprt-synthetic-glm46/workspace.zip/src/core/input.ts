/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  trackDependency,
  getDependencies,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Parse equality function from boolean or custom function
  const equalFn: EqualFn<T> | undefined = equal === true
    ? (a: T, b: T) => a === b
    : equal === false || equal === undefined
    ? undefined
    : equal as EqualFn<T>

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: equalFn as EqualFn<T> | undefined,
  }
  
  // s represents this source signal (Subject)
  // Track dependencies globally instead of locally

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // Track dependency for global propagation
      trackDependency(s as Observer<unknown>, observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check equality to avoid unnecessary updates
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Trigger update for all subscribers
    if (s.observer && 'update' in s.observer) {
      // Mark computed values as dirty to force recalculation
      s.observer.update = true
    }
    
    // Notify dependent computed values that this input changed
    if (s.observer && 'updateFn' in s.observer) {
      // Mark computed values as dirty to force recalculation
      if ('update' in s.observer) {
        s.observer.update = true
      }
      
      // Trigger update of the observer - this will propagate through dependencies
      updateObserver(s.observer as Observer<T>)
    }
    
    // Also notify directly all dependent callbacks through global tracking
    const dependents = getDependencies(s as Observer<unknown>)
    if (dependents) {
      for (const dependent of dependents) {
        if ('updateFn' in dependent) {
          dependent.update = true
          updateObserver(dependent as Observer<unknown>)
        }
      }
    }
    
    // Also notify through the subscriber mechanism if provided
    if (options?.subscribers) {
      for (const subscriber of options.subscribers) {
        if ('updateFn' in subscriber) {
          subscriber.updateFn(s.value)
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
