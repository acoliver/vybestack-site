/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
  subscribers?: Set<Observer<unknown>>
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observer?: ObserverR | undefined
  update?: boolean | undefined
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T> | undefined
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
// const notifying = false // Prevent recursive notifications (unused but kept for reference)

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Global tracking of dependencies
const globalDependencies = new Map<Observer<unknown>, Set<Observer<unknown>>>()

export function trackDependency(source: Observer<unknown>, target: Observer<unknown>): void {
  if (!globalDependencies.has(source)) {
    globalDependencies.set(source, new Set())
  }
  globalDependencies.get(source)!.add(target)
}

export function getDependencies(source: Observer<unknown>): Set<Observer<unknown>> | undefined {
  return globalDependencies.get(source)
}

export function removeDependency(source: Observer<unknown>, target: Observer<unknown>): void {
  const dependencies = globalDependencies.get(source)
  if (dependencies) {
    dependencies.delete(target)
    if (dependencies.size === 0) {
      globalDependencies.delete(source)
    }
  }
}

export function removeAllDependencies<T>(target: Observer<T>): void {
  // First, remove target as a dependent from all sources
  for (const [source, dependencies] of globalDependencies.entries()) {
    dependencies.delete(target as Observer<unknown>)
    if (dependencies.size === 0) {
      globalDependencies.delete(source)
    }
  }
  
  // Then, remove all dependencies of the target itself
  globalDependencies.delete(target as Observer<unknown>)
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Execute the update function to recalculate the value
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    // Reset the update flag if it exists
    if ('update' in observer) {
      observer.update = false
    }
    
    // Notify all dependent observers
    const dependents = getDependencies(observer as Observer<unknown>)
    if (dependents) {
      for (const dependent of dependents) {
        if ('update' in dependent) {
          dependent.update = true
        }
        // Recursively update dependent values
        updateObserver(dependent as Observer<unknown>)
      }
    }
    
    // If this observer has a parent observer, propagate the update
    if (observer.observer && observer.observer !== previous) {
      const parentObserver = observer.observer as Observer<unknown>
      if ('update' in parentObserver) {
        parentObserver.update = true
      }
      // Trigger recalculation of the parent observer
      updateObserver(parentObserver)
    }
  } finally {
    activeObserver = previous
  }
}