/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> & { observers: unknown[] } = {
    name: options?.name,
    value,
    updateFn,
    observers: [],
  }
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer to the list if not already present
      if (!o.observers.includes(observer)) {
        o.observers.push(observer)
      }
    }
    return o.value!
  }
  
  return read
}
