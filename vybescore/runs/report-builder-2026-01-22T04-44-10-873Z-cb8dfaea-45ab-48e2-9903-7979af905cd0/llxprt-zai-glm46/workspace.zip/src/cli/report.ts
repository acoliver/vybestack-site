#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!result.inputFile) {
      result.inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }

    i++;
  }

  if (!result.inputFile) {
    throw new Error('Input file is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

function getRenderer(format: string): ReportRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${i} missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${i} missing or invalid "amount" field (expected number)`
      );
    }
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const absoluteInputPath = path.resolve(args.inputFile);

    let fileContent: string;
    try {
      fileContent = fs.readFileSync(absoluteInputPath, 'utf-8');
    } catch (error) {
      const NodeError = error as { code?: string };
      if (NodeError.code === 'ENOENT') {
        throw new Error(`Input file not found: ${args.inputFile}`);
      }
      throw error;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Invalid JSON in input file: ${args.inputFile}`);
    }

    validateReportData(jsonData);
    const reportData = jsonData as ReportData;

    const renderer = getRenderer(args.format);
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = renderer(reportData, options);

    if (args.outputPath) {
      const absoluteOutputPath = path.resolve(args.outputPath);
      fs.writeFileSync(absoluteOutputPath, output, 'utf-8');
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }
}

main();
