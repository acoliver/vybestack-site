/**
 * Finds words beginning with the specified prefix but excludes the listed exceptions.
 * Uses regex with word boundaries to match complete words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !lowerExceptions.includes(word.toLowerCase())
  );
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses positive lookbehind to require a preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to match token preceded by a digit
  // and ensure it's not at the start of the string
  const tokenRegex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validates password strength according to comprehensive rules:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (like "abab")
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like "abab", "1212")
  // Look for any 2-character pattern that repeats immediately
  if (/(..)\1/.test(value)) return false;
  
  // Check for longer repeated sequences (like "abcabc")
  for (let i = 2; i <= 4; i++) {
    const pattern = new RegExp(`(.{${i}})\\1`);
    if (pattern.test(value)) return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses in the text while ensuring IPv4 addresses don't trigger false positives.
 * Supports both full and shorthand IPv6 notation including ::.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for IPv4 pattern first to exclude false positives
  const ipv4Regex = /\b(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Regex.test(value) && !value.includes('::')) return false;
  
  // IPv6 regex patterns
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  const shorthandIPv6 = /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}\b/;
  const linkLocalIPv6 = /\bfe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}\b/;
  
  // Check if any IPv6 pattern is found
  return fullIPv6.test(value) || shorthandIPv6.test(value) || linkLocalIPv6.test(value);
}