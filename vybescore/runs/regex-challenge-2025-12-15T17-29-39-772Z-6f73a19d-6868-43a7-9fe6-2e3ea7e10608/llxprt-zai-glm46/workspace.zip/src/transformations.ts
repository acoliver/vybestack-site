/**
 * Capitalizes the first character of each sentence in the text.
 * Handles sentence boundaries (. ? !), ensures proper spacing,
 * and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Normalize whitespace around sentence punctuation
  let normalized = text
    // Ensure exactly one space after sentence-ending punctuation
    .replace(/([.!?])(?!\s|$)/g, '$1 ')
    // Collapse multiple spaces to single spaces
    .replace(/\s+/g, ' ')
    // Remove leading/trailing whitespace
    .trim();
  
  // Handle common abbreviations to avoid incorrect sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'Ln', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K', 'U.N', 'E.U'];
  
  // Protect abbreviations by temporarily replacing them
  const tempReplacements: string[] = [];
  let placeholderIndex = 0;
  
  abbreviations.forEach(abbr => {
    const abbrRegex = new RegExp(`\\b${abbr}\\.[^.!?]*`, 'g');
    normalized = normalized.replace(abbrRegex, (match) => {
      const placeholder = `__PLACEHOLDER_${placeholderIndex++}__`;
      tempReplacements.push(match);
      return placeholder;
    });
  });
  
  // Capitalize first letter after sentence boundaries
  normalized = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  // Restore original abbreviations
  tempReplacements.forEach((original, index) => {
    const placeholder = `__PLACEHOLDER_${index}__`;
    normalized = normalized.replace(placeholder, original);
  });
  
  return normalized;
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 * Supports http, https, ftp, and www protocols.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+\/?(?:\?[^\s<>"']*)?(?:#[^\s<>"']*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation: . , ; : ? ! ) ] } " '
    return url.replace(/[.,;:!?)]\]}"']*$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://, but be careful not to double-convert
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * 1. Always upgrade scheme to https://
 * 2. When path begins with /docs/, rewrite host to docs.example.com
 * 3. Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * 4. Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  return text.replace(/(https?:\/\/)([^\/\s]+)(\/[^\s]*)/g, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Skip host rewrite for dynamic content
    const dynamicPatterns = [
      /\/cgi-bin\//i,
      /[?&=]/,  // Query strings
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i
    ];
    
    const isDynamic = dynamicPatterns.some(pattern => pattern.test(path));
    
    // If path starts with /docs/ and not dynamic content, rewrite host
    if (path.startsWith('/docs/') && !isDynamic && host.includes('example.com')) {
      const newHost = host.replace(/^example\./, 'docs.example.');
      return newScheme + newHost + path;
    }
    
    // Otherwise just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format. Returns "N/A" if format is invalid
 * or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Strict mm/dd/yyyy format validation
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) return 'N/A';
  } else if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}