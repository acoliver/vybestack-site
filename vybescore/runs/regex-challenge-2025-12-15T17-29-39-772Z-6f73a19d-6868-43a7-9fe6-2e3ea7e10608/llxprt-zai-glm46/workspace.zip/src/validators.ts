export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive regex and edge case handling.
 * Supports typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure: local@domain
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) return false;
  
  const [localPart, domain] = value.split('@');
  
  // Reject empty local part or domain
  if (!localPart || !domain) return false;
  
  // Reject dots at the beginning or end of local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject consecutive dots anywhere
  if (value.includes('..')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Domain cannot start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Domain must have at least one dot and valid structure
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  // Each domain part must be valid (no empty parts, no invalid chars)
  for (const part of domainParts) {
    if (!part || !/^[a-zA-Z0-9-]+$/.test(part)) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  // TLD must be at least 2 characters and only letters
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;
  
  // Local part: allow letters, numbers, and allowed special characters
  // Cannot start or end with special characters other than + (which can be at the end of local part)
  const localRegex = /^[a-zA-Z0-9]+[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*[a-zA-Z0-9]+$|^[a-zA-Z0-9]+[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*\+[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*$/;
  if (!localRegex.test(localPart)) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove common separators, spaces, and parentheses
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Check for optional country code +1
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits for US phone number
  if (!/^\d{10}$/.test(phoneNumber)) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Disallow area codes starting with 0 or 1 (not valid in North America)
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules: Optional +54 country code, optional trunk prefix 0 before area code, optional mobile indicator 9,
 * area code 2-4 digits (leading 1-9), subscriber number 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for numbers with country code +54
  // When using +54, the area code should not have trunk prefix 0
  const withCountryCodeRegex = /^\+54(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Pattern for numbers without country code (must start with trunk prefix 0)
  const withoutCountryCodeRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  let match;
  
  // Try matching with country code first
  match = cleaned.match(withCountryCodeRegex);
  
  // If that fails, try without country code (must start with 0)
  if (!match) {
    match = cleaned.match(withoutCountryCodeRegex);
  }
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits, first digit not 0)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid celebrity-style names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Must have at least one character
  if (!trimmed) return false;
  
  // Allow unicode letters (including accents), spaces, apostrophes, and hyphens
  // Reject digits, symbols, and invalid patterns
  const nameRegex = /^[\p{L}\p{M}'’\- ]+$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Reject names that are just symbols or have invalid patterns
  // No consecutive spaces or special characters
  if (trimmed.includes('  ') || trimmed.includes("''") || trimmed.includes('--')) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(trimmed)) return false;
  
  // Reject names that are too short (less than 1 letter character)
  const letterCount = (trimmed.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letterCount < 1) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Performs prefix and length validation, plus Luhn checksum verification.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length based on card type
  let isValidLength = false;
  let isValidPrefix = false;
  
  // Visa: 13 or 16 digits, starts with 4
  if (/^4\d{12}(?:\d{3})?$/.test(cleaned)) {
    isValidLength = cleaned.length === 13 || cleaned.length === 16;
    isValidPrefix = cleaned.startsWith('4');
  }
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  else if (/^(5[1-5]\d{14})$/.test(cleaned) || /^(2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/.test(cleaned)) {
    isValidLength = cleaned.length === 16;
    isValidPrefix = /^(5[1-5]|2(2[2-9]|[3-6]\d|7([01]\d|20)))\d*/.test(cleaned);
  }
  // American Express: 15 digits, starts with 34 or 37
  else if (/^3[47]\d{13}$/.test(cleaned)) {
    isValidLength = cleaned.length === 15;
    isValidPrefix = cleaned.startsWith('34') || cleaned.startsWith('37');
  }
  
  if (!isValidLength || !isValidPrefix) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}