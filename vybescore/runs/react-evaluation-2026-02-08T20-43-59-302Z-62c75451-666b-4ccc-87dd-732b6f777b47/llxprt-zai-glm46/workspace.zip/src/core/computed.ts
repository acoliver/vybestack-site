/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track observers that depend on this computed value
  const observers: Set<Observer<unknown>> = new Set()
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If there's an active observer (callback or another computed), 
    // register it as depending on this computed value
    if (activeObserver && 'updateFn' in activeObserver) {
      observers.add(activeObserver as Observer<unknown>)
    }
    
    return o.value!
  }
  
  // Override the updateFn to notify observers when this computed value changes
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    o.value = result
    
    // Notify all observers that depend on this computed value
    for (const observer of Array.from(observers)) {
      updateObserver(observer)
    }
    
    return result
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  return getter
}
