/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input contains only valid Base64 characters and proper padding.
 */
export function decode(input: string): string {
  // Validate that input contains only Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Validate padding rules
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, it must be at the end and can only be 1 or 2 '=' chars
    if (paddingIndex !== input.length - 1 && paddingIndex !== input.length - 2) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
    
    // Check that the padding characters are only '=' at the end
    const paddingSection = input.substring(paddingIndex);
    if (!/^={1,2}$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    
    // Check that total length is valid for Base64 (must be divisible by 4)
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  } else {
    // No padding: if length is not divisible by 4, it's still valid for unpadded Base64
    // Node.js Buffer can handle unpadded Base64 strings, so we don't need to reject them
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid data');
  }
}
