/**
 * Capitalizes the first character of each sentence (after .?!), inserts exactly one space 
 * between sentences even if the input omitted it, and collapses extra spaces sensibly 
 * while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') return "";
  
  // First, reduce multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence terminators (!?.) if there's text following
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Capitalize after sentence terminators
  result = result.replace(/(^|[.!?]\s)([a-z])/g, (match, p1, p2) => p1 + p2.toUpperCase());
  
  // Capitalize the very first character if it's a letter
  if (result.length > 0 && result[0] === result[0].toLowerCase() && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * Finds URLs in the text and returns them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string') return [];
  
  // URL regex pattern that matches common URL formats
  const urlRegex = /(https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*))(\W)?/g;
  
  const urls: string[] = [];
  
  // Execute regex to find all matches
  let match;
  while ((match = urlRegex.exec(text)) !== null) {
    const fullUrl = match[1];
    const urlWithoutTrailing = fullUrl.replace(/[.,;:!?)+\]}]+$/g, '');
    urls.push(urlWithoutTrailing);
  }
  
  return [...new Set(urls)]; // Remove duplicates
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') return "";
  
  // Replace http:// with https:// using regex with word boundaries to avoid partial matches
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings, or legacy extensions
   but still upgrade the scheme to https://
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') return "";
  
  // Pattern to match URLs from example.com domain
  const urlPattern = /(https?):\/\/(?:www\.)?example\.com(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, protocol, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if the path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      return `${newProtocol}://docs.example.com${path}`;
    }
    
    // For all other URLs, just upgrade the scheme
    return `${newProtocol}://example.com${path}`;
  });
}

/**
 * Returns the four-digit year for mm/dd/yyyy format.
 * If the format doesn't match or month/day are invalid, returns 'N/A'.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') return 'N/A';
  
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (simple validation, not exhaustive)
  const maxDaysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if ((isLeapYear && day > 29) || (!isLeapYear && day > 28)) {
      return 'N/A';
    }
  } else if (day > maxDaysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
