/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create regex for words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Remove exceptions and filter unique values
  return matches
    .filter(word => !exceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index);
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to match token that comes after a digit but not at start of string
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  while ((match = pattern.exec(text)) !== null) {
    // Get the full match including the digit
    matches.push(match[0]);
    
    // Prevent infinite loops for zero-length matches
    if (match[0].length === 0) {
      pattern.lastIndex++;
    }
  }
  
  return matches;
}

/**
 * Validates passwords: at least 10 characters, one uppercase, one lowercase, one digit, 
 * one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol
  const symbolPattern = new RegExp('[!@#$%^&*()_+\\-=\\[\\]{};\':"\\|,.<>\\/?]');
  if (!symbolPattern.test(value)) return false;
  
  // No immediate repeated sequences (like abab)
  // Check for any 2-character sequence repeated immediately
  if (/(.{2})\1/.test(value)) return false;
  
  // Check for any 3-character sequence repeated immediately
  if (/(.{3})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') return false;
  
  // IPv6 regex pattern (including shorthand)
  // This matches standard IPv6 addresses including :: shorthand
  const ipv6Pattern = /(?:^|[^0-9a-fA-F.:])(([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4})(?:$|[^0-9a-fA-F.:])/;
  
  // Check for IPv6 pattern
  if (ipv6Pattern.test(value)) {
    // Extract the IPv6 part and check if it's not actually an IPv4
    const matches = value.match(ipv6Pattern);
    if (matches && matches[1]) {
      // Check if the matched IPv6 part contains only IPv4 digits and dots
      if (!/^[0-9.]+$/.test(matches[1])) {
        return true;
      }
    }
  }
  
  // Check for shorthand IPv6 with :: (compressed zeros)
  const shorthandPattern = /(?:^|[^0-9a-fA-F.:])(([0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4})(?:$|[^0-9a-fA-F.:])/;
  
  if (shorthandPattern.test(value)) {
    // Extract the IPv shorthand part and check if it's not actually an IPv4
    const matches = value.match(shorthandPattern);
    if (matches && matches[1]) {
      // Check if the matched IPv6 part contains only IPv4 digits and dots
      if (!/^[0-9.]+$/.test(matches[1])) {
        return true;
      }
    }
  }
  
  return false;
}
