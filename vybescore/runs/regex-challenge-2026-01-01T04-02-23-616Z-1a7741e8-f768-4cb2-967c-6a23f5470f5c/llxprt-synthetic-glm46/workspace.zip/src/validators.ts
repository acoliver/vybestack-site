export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to RFC 5322 standards.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Basic email pattern with proper validation rules
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Check if it matches basic email format
  if (!emailRegex.test(value)) return false;
  
  // Additional validation rules
  // No consecutive dots in local part
  if (value.includes('..')) return false;
  
  // No leading or trailing dots in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain cannot start or end with hyphen
  const domain = value.split('@')[1];
  if (domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Domain cannot have underscores
  if (domain.includes('_')) return false;
  
  // No leading or trailing dots in domain parts
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (!part.length) return false;
    if (part.startsWith('.') || part.endsWith('.')) return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats with optional +1 prefix.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Remove non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Check if we have the right number of digits (10 for standard, 11 with country code)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Has country code, remove it for validation
    const withoutCountryCode = digitsOnly.slice(1);
    return isValidUSPhoneDigits(withoutCountryCode);
  } else if (digitsOnly.length === 10) {
    // Standard 10-digit number
    return isValidUSPhoneDigits(digitsOnly);
  }

  return false;
}

/**
 * Helper function to validate 10-digit US phone numbers
 */
function isValidUSPhoneDigits(digits: string): boolean {
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  if (digits[3] === '0' || digits[3] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers supporting landlines and mobiles.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Extract digits for more detailed validation
  const digitsOnly = normalized.replace(/\D/g, '');
  
  // Check if country code is present
  const hasCountryCode = digitsOnly.startsWith('54');
  const effectiveDigits = hasCountryCode ? digitsOnly.slice(2) : digitsOnly;
  
  // If no country code, must start with trunk prefix (0)
  if (!hasCountryCode && !effectiveDigits.startsWith('0')) {
    return false;
  }

  // Remove trunk prefix for further validation
  const afterTrunk = effectiveDigits.startsWith('0') ? effectiveDigits.slice(1) : effectiveDigits;

  // Check for mobile indicator (9) after country code and/or trunk prefix
  const hasMobileIndicator = afterTrunk.startsWith('9');
  const afterMobile = hasMobileIndicator ? afterTrunk.slice(1) : afterTrunk;

  // Area code should be 2-4 digits, leading digit not 0
  if (afterMobile.length < 8) return false; // Not enough digits after mobile indicator

  let areaCode: string;
  let subscriber: string;

  // Try to extract area code (2-4 digits)
  let areaCodeLength = 4;
  while (areaCodeLength >= 2) {
    areaCode = afterMobile.substring(0, areaCodeLength);
    subscriber = afterMobile.substring(areaCodeLength);

    // Check if area code starts with 1-9 (not 0) and subscriber has 6-8 digits
    if (/^[1-9]/.test(areaCode) && subscriber.length >= 6 && subscriber.length <= 8) {
      return true;
    }

    areaCodeLength--;
  }

  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and obviously invalid names.
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Name pattern allowing:
  // Unicode letters (\p{L})
  // Accents (included in \p{L})
  // Apostrophes and hyphens
  // Spaces
  // Not allowing digits or symbols
  
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  // Check if it matches the pattern
  if (!nameRegex.test(value)) return false;
  
  // Ensure it has at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject obviously problematic patterns
  if (value.startsWith(' ') || value.endsWith(' ')) return false;
  if (value.includes('  ')) return false; // Double spaces
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) using prefix/length verification and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[ -]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digitsOnly)) return false;
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  // Validate Visa
  if (digitsOnly.startsWith('4') && (digitsOnly.length === 13 || digitsOnly.length === 16)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Validate Mastercard (51-55)
  if (/^5[1-5]/.test(digitsOnly) && digitsOnly.length === 16) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Validate Mastercard (2221-2720)
  if (/^2(2[2-9]|[3-6]\d|7[01])/.test(digitsOnly) && digitsOnly.length === 16) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Validate AmEx
  if (/^3[47]/.test(digitsOnly) && digitsOnly.length === 15) {
    return runLuhnCheck(digitsOnly);
  }
  
  return false;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
