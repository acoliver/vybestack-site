/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words beginning with the prefix
  // \b ensures word boundary at the start
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences with their positions
  const matchesWithIndex: Array<{match: string, index: number}> = [];
  
  // Use RegExp with global flag to find all occurrences
  const regex = new RegExp(escapedToken, 'g');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matchesWithIndex.push({
      match: match[0],
      index: match.index
    });
  }
  
  // Filter matches to only include those that meet our criteria
  const filteredMatches = matchesWithIndex.filter(({index}) => {
    if (index === 0) return false; // Not at the beginning
    
    // Check if preceded by a digit
    const beforeChar = index > 0 ? text[index - 1] : '';
    return /\d/.test(beforeChar);
  });
  
  // Return the matched strings with the preceding digit
  return filteredMatches.map(({match, index}) => {
    // Include the digit character in the result
    return text[index - 1] + match;
  });
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?/]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., "abab")
  // Pattern to find any immediate repeated sequence
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, reject pure IPv4 addresses to avoid false positives
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Simple IPv6 detection - look for patterns that indicate IPv6
  // IPv6 patterns include hex digits, colons, and shorthand notation
  
  // Check for standard IPv6 notation (contains hex and multiple colons)
  const hasIPv6Pattern = /[a-fA-F0-9]*:[a-fA-F0-9]*:[a-fA-F0-9]*/.test(value) || /::/.test(value);
  
  // Must contain colon patterns and hex characters to be IPv6
  const containsColon = value.includes(':');
  const containsHex = /[a-fA-F0-9]/.test(value);
  
  // Return true if it has IPv6 characteristics but is not pure IPv4
  return hasIPv6Pattern && containsColon && containsHex;
}
