export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject strings with double dots
  if (/\.\./.test(value)) return false;
  
  // Reject trailing dots in domain
  if (/\.$/.test(value)) return false;
  
  // Email pattern: local part allows letters, numbers, dots, hyphens, underscores, and pluses
  // domain part allows letters, numbers, hyphens, dots but no underscores
  const emailPattern = /^[a-zA-Z0-9_]([a-zA-Z0-9._+-]*[a-zA-Z0-9_])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  let cleanValue = value;
  
  // If extensions are allowed, remove extension patterns for validation
  if (options?.allowExtensions) {
    cleanValue = value.replace(/\s*(?:ext\.?|extension|x)\s*\d+$/i, '');
  }
  
  // Remove all non-digits for basic length check
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  // Check minimum length (10 digits for local number, 11 for +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Reject numbers starting with 0 (impossible area codes or trunk prefixes)
  if (digitsOnly.startsWith('0')) return false;
  
  // For 11-digit numbers, the first digit should be 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // For 10-digit numbers, the first digit should not be 1 (can't start area code with 1)
  if (digitsOnly.length === 10 && digitsOnly.startsWith('1')) return false;
  
  // Pattern to match common US phone formats
  const phonePattern = /^(?:\+?1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4})$/;
  
  return phonePattern.test(cleanValue);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 (country code)
  if (normalized.startsWith('+54')) {
    const rest = normalized.substring(3);
    
    // Mobile format: +54 9 [area] [subscriber]
    if (rest.startsWith('9')) {
      const afterMobile = rest.substring(1);
      
      // For mobile format, we need to parse area first, then subscriber
      // Try different area lengths: 2, 3, or 4 digits
      const areaPatterns = [
        /^(\d{2})(\d{8})$/,  // 2-digit area, 8-digit subscriber
        /^(\d{3})(\d{7})$/,  // 3-digit area, 7-digit subscriber
        /^(\d{4})(\d{6})$/   // 4-digit area, 6-digit subscriber
      ];
      
      let areaMatch = null;
      for (const pattern of areaPatterns) {
        const match = afterMobile.match(pattern);
        if (match) {
          areaMatch = match;
          break;
        }
      }
      
      if (!areaMatch) return false;
      
      const areaCode = areaMatch[1];
      const subscriberNumber = areaMatch[2];
      
      // Validate area code length (2-4 digits, leading digit 1-9)
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      if (areaCode[0] === '0') return false;
      
      // Mobile numbers must have exactly 8 digits in subscriber part
      if (subscriberNumber.length !== 8) return false;
      
      return true;
    } 
    // Landline format: +54 [area] [subscriber]
    else {
      const afterArea = rest;
      
      // Try different area lengths: 2, 3, or 4 digits
      const areaPatterns = [
        /^(\d{2})(\d{6,8})$/,  // 2-digit area, 6-8 digit subscriber
        /^(\d{3})(\d{6,8})$/,  // 3-digit area, 6-8 digit subscriber
        /^(\d{4})(\d{6,8})$/   // 4-digit area, 6-8 digit subscriber
      ];
      
      let areaMatch = null;
      for (const pattern of areaPatterns) {
        const match = afterArea.match(pattern);
        if (match) {
          areaMatch = match;
          break;
        }
      }
      
      if (!areaMatch) return false;
      
      const areaCode = areaMatch[1];
      const subscriberNumber = areaMatch[2];
      
      // Validate area code length (2-4 digits, leading digit 1-9)
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      if (areaCode[0] === '0') return false;
      
      // Landline subscriber must be 6-8 digits
      if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
      
      return true;
    }
  } 
  // Format without country code: must start with trunk '0'
  else if (normalized.startsWith('0')) {
    const afterTrunk = normalized.substring(1);
    
    // Try different area lengths: 2, 3, or 4 digits
    const areaPatterns = [
      /^(\d{2})(\d{6,8})$/,  // 2-digit area, 6-8 digit subscriber
      /^(\d{3})(\d{6,8})$/,  // 3-digit area, 6-8 digit subscriber
      /^(\d{4})(\d{6,8})$/   // 4-digit area, 6-8 digit subscriber
    ];
    
    let areaMatch = null;
    for (const pattern of areaPatterns) {
      const match = afterTrunk.match(pattern);
      if (match) {
        areaMatch = match;
        break;
      }
    }
    
    if (!areaMatch) return false;
    
    const areaCode = areaMatch[1];
    const subscriberNumber = areaMatch[2];
    
    // Validate area code length (2-4 digits, leading digit 1-9)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (areaCode[0] === '0') return false;
    
    // Subscriber must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject empty strings or just spaces
  if (!value.trim()) return false;
  
  // Pattern to match unicode letters, accents, apostrophes, hyphens, spaces
  // Exclude digits and symbols like the fictional name "X Æ A-12"
  const namePattern = /^[\p{L}\p{M}'\s-]+$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Additional check: no leading/trailing spaces
  if (value !== value.trim()) return false;
  
  // Check for patterns that look like "X Æ A-12" (contains non-letter symbols mixed with numbers)
  if (/[\p{L}\p{M}]*[\p{S}\p{N}][\p{L}\p{M}]*[\p{S}\p{N}]/u.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function to implement Luhn checksum
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (13 digits for most cards)
  if (digitsOnly.length < 13) return false;
  
  // Define patterns for different card types
  const patterns = [
    // Visa: starts with 4, length 13, 16, or 19
    /^4\d{12}(\d{3})?(\d{3})?$/,
    // Mastercard: starts with 5[1-5] or 2221-2720, length 16
    /^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/,
    // AmEx: starts with 34 or 37, length 15
    /^(34|37)\d{13}$/
  ];
  
  // Test against all patterns
  const isValidPattern = patterns.some(pattern => pattern.test(digitsOnly));
  
  if (!isValidPattern) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
