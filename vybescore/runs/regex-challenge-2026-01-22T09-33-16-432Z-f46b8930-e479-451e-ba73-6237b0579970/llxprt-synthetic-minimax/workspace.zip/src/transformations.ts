/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to find sentence endings followed by spaces and the next sentence
  const pattern = /([.!?]+)([\s]*)([A-Za-z0-9])/g;
  
  // First, normalize multiple spaces to single spaces (but preserve sentence structure)
  const normalized = text.replace(/[\s]{2,}/g, ' ');
  
  // Replace sentence endings with the same punctuation, required spaces, and capitalized letter
  const result = normalized.replace(pattern, (match, punctuation, spaces, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Also capitalize the first letter of the entire text if it's a letter
  const finalResult = result.replace(/^([A-Za-z])/, (match, letter) => letter.toUpperCase());
  
  return finalResult;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs, capturing them and removing trailing punctuation
  const urlPattern = /(https?:\/\/[^\s<>"'()]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[^\s<>"'()]*)(?=[<>"'()\s.,!?;]|$)/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation and normalize
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation common in text
    return url.replace(/[.,!?;]+$/g, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// (not https://)
  const httpPattern = /http:\/\//g;
  
  // Replace http:// with https://
  return text.replace(httpPattern, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpPattern = /http:\/\/([a-zA-Z0-9.-]+)(\/[^\s<>"'()]*)/g;
  
  return text.replace(httpPattern, (match, host, path) => {
    // Check for dynamic hints or legacy extensions that should skip host rewrite
    const skipRewritePatterns = [
      /cgi-bin/i,
      /\?/,  // query strings
      /&/,   // query parameters
      /=/,   // query parameters
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    // If path contains dynamic hints, just upgrade scheme
    const shouldSkipRewrite = skipRewritePatterns.some(pattern => pattern.test(path));
    
    if (shouldSkipRewrite) {
      return 'https://' + host + path;
    }
    
    // If path begins with /docs/, rewrite host to docs.host
    if (path.startsWith('/docs/')) {
      const docsHost = 'docs.' + host;
      return 'https://' + docsHost + path;
    }
    
    // Default: just upgrade scheme
    return 'https://' + host + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for days per month (ignoring leap years for simplicity)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (month <= 12 && day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
