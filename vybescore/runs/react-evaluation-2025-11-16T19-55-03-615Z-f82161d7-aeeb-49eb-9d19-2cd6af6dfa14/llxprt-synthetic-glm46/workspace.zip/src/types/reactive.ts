/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

declare global {
  interface SetConstructor {
    new <T>(): Set<T>
  }
  // eslint-disable-next-line no-var
  var Set: SetConstructor
}

// Track all subjects dependent on a particular subject
export const subjectDependents = new WeakMap<Subject<any>, Set<Observer<any>>>()
export const computedObservers = new Set<Observer<any>>()
export const callbackObservers = new Set<Observer<any>>()

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Function to update an observer's value
export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  
  try {
    activeObserver = observer
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}


// Function to update all observers that depend on a subject
export function notifyObservers<T>(subject: Subject<T>): void {
  const dependents = subjectDependents.get(subject)
  if (dependents) {
    // Clone to avoid issues with modification during iteration
    const observers = Array.from(dependents)
    for (const observer of observers) {
      updateObserver(observer)
    }
  }
}

// Function to update all computed observers
export function notifyComputedObservers(): void {
  // Clone to avoid issues with modification during iteration
  const observers = Array.from(computedObservers)
  for (const observer of observers) {
    updateObserver(observer)
  }
}

// Function to update all callback observers
export function notifyCallbackObservers(): void {
  // Clone to avoid issues with modification during iteration
  const observers = Array.from(callbackObservers)
  for (const observer of observers) {
    updateObserver(observer)
  }
}
