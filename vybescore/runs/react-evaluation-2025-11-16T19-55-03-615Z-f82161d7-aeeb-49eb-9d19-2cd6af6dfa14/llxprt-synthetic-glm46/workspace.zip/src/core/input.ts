/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  notifyComputedObservers,
  notifyCallbackObservers,
  subjectDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

declare global {
  interface SetConstructor {
    new <T>(): Set<T>
  }
  // eslint-disable-next-line no-var
  var Set: SetConstructor
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === true) {
    // Default strict equality
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // Track this dependency if this subject is being read by an observer
      // The observer will be notified when this subject's value changes
      if (!subjectDependents.has(s)) {
        subjectDependents.set(s, new Set())
      }
      subjectDependents.get(s)!.add(observer as Observer<any>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers that depend on this subject
    notifyObservers(s)
    
    // Also notify computed observers to ensure transitive dependencies are updated
    notifyComputedObservers()
    
    // Also notify callback observers that may depend on this subject
    notifyCallbackObservers()
    
    return s.value
  }

  return [read, write]
}
