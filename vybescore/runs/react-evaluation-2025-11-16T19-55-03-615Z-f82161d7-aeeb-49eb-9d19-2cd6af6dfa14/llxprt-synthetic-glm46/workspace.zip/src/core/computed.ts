/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver,
  subjectDependents,
  computedObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Register this computed observer so we can track it
  computedObservers.add(o)
  
  // Store the computed observer on a pseudo-subject for dependency tracking
  const pseudoSubject = { 
    value: o.value, 
    observer: undefined,
    equalFn: undefined
  } as Subject<any>
  
  // Register this computed observer with its own pseudo-subject
  if (!subjectDependents.has(pseudoSubject)) {
    subjectDependents.set(pseudoSubject, new Set())
  }
  subjectDependents.get(pseudoSubject)!.add(o as Observer<any>)
  
  // Initial computation to establish dependencies and set value
  updateObserver(o)
  
  // Return a getter that always returns the current value
  const getter = (): T => {
    // If accessed during an update, this computed should register itself as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add the active observer as a dependent of our pseudo-subject
      // This creates the transitive dependency chain
      if (!subjectDependents.has(pseudoSubject)) {
        subjectDependents.set(pseudoSubject, new Set())
      }
      subjectDependents.get(pseudoSubject)!.add(activeObserver as Observer<any>)
    }
    
    // If no value has been computed yet, we need to compute it
    if (o.value === undefined) {
      updateObserver(o)
    }
    return o.value!
  }
  
  return getter
}
