/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, callbackObservers } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: undefined, // Could be extended with options later
    value,
    updateFn,
  }
  
  // Register this callback observer so we can track it
  callbackObservers.add(observer)
  
  // Run the callback initially to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from the tracking set
    callbackObservers.delete(observer)
    
    // Remove the observer from all subject dependencies
    // This ensures proper cleanup and prevents memory leaks
    // Note: WeakMap doesn't have entries method, so we can't iterate directly
    // The observer will be garbage collected when there are no references left
    // and any subjects it depends on will be released from the WeakMap automatically
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    observer.updateFn = () => undefined as T
  }
}
