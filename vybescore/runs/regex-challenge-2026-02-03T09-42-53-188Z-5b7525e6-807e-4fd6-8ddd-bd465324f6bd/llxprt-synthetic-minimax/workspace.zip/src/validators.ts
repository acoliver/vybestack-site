export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Luhn checksum implementation for credit card validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').reverse().map(Number);
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
  }
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject obvious invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.startsWith('.') || value.includes('@.')) {
    return false;
  }
  
  // Domain validation - no underscores allowed
  const domain = value.split('@')[1];
  if (domain?.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Options parameter for future extensibility (currently unused)
  void _options;
  
  // Must have at least 10 digits
  const digitsOnly = cleanValue.replace(/\D/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Pattern for US phone numbers
  // Optional +1, then area code (2-9 for first digit), exchange code, and number
  const usPhoneRegex = /^\+?1?[\s\-.]*\(?([2-9][0-9]{2})\)?[\s\-.]*([2-9][0-9]{2})[\s\-.]*([0-9]{4})$/;
  
  const match = cleanValue.match(usPhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, exchangeCode] = match;
  
  // Validate area code (2-9 for first digit)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate exchange code (2-9 for first digit)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit, non-+ characters to clean the input
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Extract digits only for validation
  const digitsOnly = cleanValue.replace(/\D/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Pattern for Argentine phone numbers
  // Groups:
  // 1. Optional +54 (country code)
  // 2. Optional 9 (mobile indicator)
  // 3. Optional 0 (trunk prefix)
  // 4. Area code: 2-4 digits, first digit 1-9
  // 5. Subscriber number: remaining digits should be 6-8 total
  
  const arPhoneRegex = /^(?:\+54)?(?:\d{0,1})?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(arPhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Area code validation: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation: should be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must start with trunk prefix 0
  if (!cleanValue.startsWith('+54')) {
    if (!value.match(/^\s*0/)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u024F]/.test(value)) {
    return false;
  }
  
  // Reject names with digits or suspicious patterns
  if (/\d/.test(value) || /X\s*Æ\s*A-12/.test(value)) {
    return false;
  }
  
  // Pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Spaces, apostrophes, hyphens allowed
  // - Must start with a letter or apostrophe (but apostrophe-only names are invalid)
  const nameRegex = /^[\p{L}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]?$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: no consecutive special characters like apostrophes or hyphens
  if (/['-]\s*['-]/.test(value) || /['-]{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid card prefixes and lengths
  // Visa: starts with 4, length 13, 16, 19
  const visaPattern = /^4\d{12}(\d{3})?(\d{3})?$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  // American Express: starts with 34 or 37, length 15
  const amexPattern = /^(3[47]\d{13})$/;
  
  if (!visaPattern.test(digitsOnly) && !mastercardPattern.test(digitsOnly) && !amexPattern.test(digitsOnly)) {
    return false;
  }
  
  // Apply Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}
