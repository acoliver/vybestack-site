/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern to match words starting with the prefix
  // \b ensures word boundaries to match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive matching)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => {
    const wordLower = word.toLowerCase();
    return !exceptionsLower.includes(wordLower);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find pattern where token comes after a digit
  const pattern = new RegExp(`(\\d${token})`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Return the full matched context (digit + token)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for one symbol
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab")
  const immediateRepeatPattern = /([a-zA-Z0-9])\1{2,}/;
  if (immediateRepeatPattern.test(value)) {
    return false;
  }
  
  // Check for alternating patterns like "abab"
  const alternatingPattern = /([a-zA-Z0-9]{2,})\1/;
  if (alternatingPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses contain colons and typically patterns like 2001:db8::1
  // Pattern to match typical IPv6 address formats including :: shorthand
  const ipv6Pattern = /(?:\b[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{0,4}\b|\b::[0-9a-fA-F:]*\b/;
  
  // Check if the string contains an IPv6 pattern
  if (ipv6Pattern.test(value)) {
    // Exclude obvious IPv4 addresses that might match the pattern
    const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
    if (ipv4Pattern.test(value)) {
      // If we find both IPv4 and IPv6 patterns, check more specifically
      // Look for the :: shorthand which is unique to IPv6
      if (value.includes('::')) {
        return true;
      }
      // Otherwise, this might be just an IPv4 address
      return false;
    }
    // Found IPv6 pattern and no IPv4 conflict
    return true;
  }
  
  return false;
}
