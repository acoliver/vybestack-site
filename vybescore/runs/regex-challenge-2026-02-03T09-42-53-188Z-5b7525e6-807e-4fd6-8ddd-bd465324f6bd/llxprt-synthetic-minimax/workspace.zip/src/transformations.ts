/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences by common sentence terminators
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  return sentences.map(sentence => {
    // Trim leading spaces and capitalize first letter
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return sentence;
    
    // Capitalize first character while preserving the rest
    const firstChar = trimmed.charAt(0).toUpperCase();
    const rest = trimmed.slice(1);
    
    return firstChar + rest;
  }).join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching common HTTP/HTTPS URLs
  const urlPattern = /https?:\/\/[^\s"']+[^\s"'.!?,)]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation while keeping the URL intact
    return url.replace(/[.!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\/([^"'\s]+)/gi, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http:// scheme
  const httpUrlPattern = /http:\/\/([^/"\s]+)([^\s"']*)/gi;
  
  return text.replace(httpUrlPattern, (fullUrl, host, path) => {
    const newHost = host;
    const newPath = path;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions in the path
      const hasDynamicHints = /(\?|&|=|cgi-bin)/.test(path);
      const hasLegacyExtensions = /(\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      // Only rewrite host if no dynamic hints or legacy extensions
      if (!hasDynamicHints && !hasLegacyExtensions) {
        // Rewrite host to docs.example.com
        const finalHost = 'docs.' + host;
        // Always upgrade scheme to https://
        return `https://${finalHost}${newPath}`;
      }
    }
    
    // Always upgrade scheme to https://
    return `https://${newHost}${newPath}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (01-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31) - simple validation, not checking month-specific days
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  // Return the year if format and values are valid
  return year;
}
