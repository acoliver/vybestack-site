import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Form data interface
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors interface
interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization
let db: Database | null = null;

async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    const fs = await import('fs/promises');
    
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    try {
      const fileBuffer = await fs.readFile(dbPath);
      db = new SQL.Database(fileBuffer);
    } catch (error) {
      // Database doesn't exist, create it
      db = new SQL.Database();
      const schema = await fs.readFile(path.join(__dirname, '../db/schema.sql'), 'utf8');
      db.exec(schema);
      await saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  return import('fs/promises').then(fs => {
    const data = db!.export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    return fs.writeFile(dbPath, Buffer.from(data));
  });
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields validation
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }
  
  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email.trim() || !emailRegex.test(formData.email)) {
    errors.push({ field: 'email', message: 'Valid email is required' });
  }
  
  // Phone validation (digits, spaces, parentheses, dashes, and leading +)
  const phoneRegex = /^[+]?[\d\s()()-]+$/;
  if (!formData.phone.trim() || !phoneRegex.test(formData.phone)) {
    errors.push({ field: 'phone', message: 'Valid phone number is required' });
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} as FormData 
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  
  const validationErrors = validateForm(formData);
  
  if (validationErrors.length > 0) {
    const errorMessages = validationErrors.map(err => err.message);
    return res.render('form', { 
      errors: errorMessages, 
      values: formData 
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    // Insert into database
    const stmt = db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    const errorMessages = ['An unexpected error occurred. Please try again.'];
    res.render('form', { 
      errors: errorMessages, 
      values: formData 
    });
  }
});

app.get('/thank-you', (req, res) => {
  // We don't have session data, so we'll use a generic greeting
  res.render('thank-you', { firstName: 'Friend' });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Handle shutdown signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

startServer();
