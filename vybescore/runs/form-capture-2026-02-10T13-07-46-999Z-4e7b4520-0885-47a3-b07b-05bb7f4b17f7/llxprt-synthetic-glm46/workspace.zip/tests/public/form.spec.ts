import { describe, expect, it, afterAll, beforeAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import request from 'supertest';

const dbPath = path.resolve('data', 'submissions.sqlite');
let serverProcess: any;

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Build the project
  const { execSync } = await import('node:child_process');
  try {
    execSync('npm run build', { timeout: 10000 });
  } catch (error) {
    console.error('Build failed:', error);
    throw error;
  }
  
  // Start the server
  return new Promise<void>((resolve, reject) => {
    serverProcess = spawn('node', ['dist/server.js'], {
      stdio: 'pipe',
      env: { ...process.env, PORT: '3535' }
    });
    
    serverProcess.stdout.on('data', (data: any) => {
      const output = data.toString();
      if (output.includes('Server running on port')) {
        console.log('Server started successfully');
        resolve();
      }
    });
    
    serverProcess.on('error', (error: any) => {
      reject(error);
    });
    
    // Timeout after 5 seconds
    setTimeout(() => {
      reject(new Error('Server start timeout'));
    }, 5000);
  });
});

afterAll(async () => {
  // Stop the server process
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
    // Give it a moment to close gracefully
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  // Cleanup test database if it exists
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

const BASE_URL = 'http://localhost:3535';

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(BASE_URL)
      .get('/')
      .expect(200);
    
    // Check that the response contains form elements
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('submits form and redirects to thank you page', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    // Submit form
    await request(BASE_URL)
      .post('/submit')
      .send(formData)
      .expect(302); // Expect redirect
    
    // Check thank you page is accessible
    const thankYouResponse = await request(BASE_URL)
      .get('/thank-you')
      .expect(200);
    
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('friendly messages');
    
    // Database file should now exist with the submission
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles validation errors properly', async () => {
    const invalidData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: ''
    };
    
    const response = await request(BASE_URL)
      .post('/submit')
      .send(invalidData)
      .expect(200); // Should return form with errors, not redirect
    
    // Should show error messages
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Valid email is required');
  });
});
