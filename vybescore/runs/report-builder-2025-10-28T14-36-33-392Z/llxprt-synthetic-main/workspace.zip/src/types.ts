/**
 * Interface for report entry data
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the complete report data
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report generation
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  includeTotals: boolean;
  outputPath?: string;
}