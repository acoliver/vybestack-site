/**
 * Interface for report formatters
 */
export type ReportRenderer = (
  data: import('../types.js').ReportData,
  options: { includeTotals: boolean }
) => string;