#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArgs(): ReportOptions & { inputPath: string } {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputPath = args[0];
  const formatFlag = args[1];

  if (formatFlag !== '--format') {
    throw new Error('Expected --format flag');
  }

  const format = args[2] as ReportOptions['format'];

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  const result: ReportOptions & { inputPath: string } = {
    inputPath,
    format,
    includeTotals: false,
  };

  // Parse remaining flags
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Expected path after --output');
      }
      result.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    }
  }

  return result;
}

/**
 * Validate and parse report data
 */
function loadReportData(inputPath: string): ReportData {
  const resolvedPath = path.resolve(inputPath);

  try {
    const fileContent = fs.readFileSync(resolvedPath, 'utf8');
    const data = JSON.parse(fileContent);

    // Validate basic structure
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected object');
    }

    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }

    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }

    if (!Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Missing or empty "entries" array');
    }

    // Validate entries
    for (const entry of data.entries) {
      if (!entry || typeof entry !== 'object') {
        throw new Error('Invalid entry: expected object');
      }

      if (typeof entry.label !== 'string') {
        throw new Error('Missing "label" field in entry');
      }

      if (typeof entry.amount !== 'number') {
        throw new Error('Missing "amount" field in entry');
      }
    }

    return data as ReportData;
  } catch (e) {
    if (e instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON: ${e.message}`);
    }
    throw e;
  }
}

/**
 * Write output to file or stdout
 */
function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    const resolvedPath = path.resolve(outputPath);
    fs.writeFileSync(resolvedPath, content, 'utf8');
  } else {
    process.stdout.write(content);
  }
}

/**
 * Main CLI function
 */
function main(): void {
  try {
    const { inputPath, format, includeTotals, outputPath } = parseArgs();
    const data = loadReportData(inputPath);

    const renderers = {
      markdown: renderMarkdown,
      text: renderText,
    };

    const renderer = renderers[format];
    const output = renderer(data, { includeTotals });

    writeOutput(output, outputPath);
  } catch (e) {
    const errorMsg = e instanceof Error ? e.message : String(e);
    console.error(errorMsg);
    process.exit(1);
  }
}

main();
