/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 * Includes proper padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const ERROR_MESSAGE = 'Failed to decode Base64 input';

function validateBase64Structure(input: string): void {
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error(ERROR_MESSAGE);
  }

  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    validatePadding(input, paddingIndex);
  }
  // Remove length validation - Node.js Buffer can handle unpadded base64
}

function validatePadding(input: string, paddingIndex: number): void {
  const padding = input.substring(paddingIndex);
  if (padding.length > 2 || !padding.match(/^={1,2}$/)) {
    throw new Error(ERROR_MESSAGE);
  }

  const mainPart = input.substring(0, paddingIndex);
  // Fixed padding validation:
  // - 1 padding character (=): main part should end with 3 characters (mod 4 = 3)
  // - 2 padding characters (==): main part should end with 2 characters (mod 4 = 2)
  // - No padding: no length requirement (already validated separately)
  const expectedModulo = padding.length === 1 ? 3 : 2;
  if (mainPart.length % 4 !== expectedModulo) {
    throw new Error(ERROR_MESSAGE);
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  try {
    // Test if input is valid base64 by attempting to decode
    const buffer = Buffer.from(input, 'base64');
    
    // Check if any characters were invalid by comparing lengths
    // Node.js ignores invalid characters, so we need to validate the structure
    validateBase64Structure(input);
    
    // Additional check: if Buffer couldn't decode anything but input is not empty
    if (buffer.length === 0 && input.length > 0) {
      throw new Error(ERROR_MESSAGE);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    // Re-throw any validation errors as our standard error
    throw new Error(ERROR_MESSAGE);
  }
}