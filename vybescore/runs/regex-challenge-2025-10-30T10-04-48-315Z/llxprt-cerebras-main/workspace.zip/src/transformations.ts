/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }
  
  // Pattern to match sentence endings followed by whitespace and the next character
  return text.replace(/(^|[.!?])\s*([a-z])/g, (match, p1, p2) => {
    // p1 is the sentence ending punctuation or start of string
    // p2 is the first letter of the next sentence
    return p1 + ' ' + p2.toUpperCase();
  }).trim();
}

/**
 * Extract all URLs from text and return them as an array.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string') {
    return [];
  }
  
  // Regex pattern to match URLs
  // Using a more comprehensive pattern to match full URLs
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/gi;
  const matches = text.match(urlRegex);
  
  // Filter out any matches that might be null
  return matches ? matches : [];
}

/**
 * Convert all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }
  
  // Pattern to match http:// URLs and replace with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite HTTP URLs to HTTPS and change host to docs.example.com when path begins with /docs/.
 * Skip host rewrite when path contains dynamic hints or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Pattern to match HTTP URLs with example.com host
  return text.replace(/http:\/\/example\.com(\/[^\s,.;:!?)\]}]*)/gi, (match, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /[?&=]|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise, just upgrade to HTTPS
    return `https://${match.substring(7)}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') {
    return 'N/A';
  }
  
  // Regex pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}