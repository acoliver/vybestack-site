export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using a comprehensive regex pattern.
 * Accepts typical addresses and rejects obviously invalid formats.
 */
export function isValidEmail(value: string): boolean {
  // Check if value is a string and not empty
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Comprehensive email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  // Additional checks for edge cases
  if (!value.includes('@')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('..')) return false;
  
  const [localPart, domain] = value.split('@');
  
  // Check local part
  if (!localPart || localPart.length > 64) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Check domain part
  if (!domain || domain.length > 255) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  if (domain.includes('_')) return false; // Reject domains with underscores
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Optional +1 prefix is allowed.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Check if value is a string and not empty
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Remove all non-digit characters except + at the beginning
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle +1 prefix
  if (cleaned.startsWith('+1') && cleaned.length > 10) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('+') && !cleaned.startsWith('+1')) {
    return false; // Only +1 is allowed as country code
  }
  
  // Check if cleaned value has exactly 10 digits
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleaned.substring(0, 3);
  
  // Validate area code (must not start with 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Check if value is a string and not empty
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Remove extra spaces and hyphens for easier processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Supports optional country code +54, optional trunk prefix 0, optional mobile indicator 9
  const argPhoneRegex = /^(\+54|0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const hasCountryCode = match[1] === '+54';
  const hasTrunkPrefix = match[1] === '0';
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must contain 6-8 digits in total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Check if value is a string and not empty
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Pattern for valid names: unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check if the name matches the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits or consecutive symbols
  if (/\d/.test(value) || /['-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject names starting or ending with symbols
  if (value.startsWith("'") || value.startsWith("-") || 
      value.endsWith("'") || value.endsWith("-")) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Check if value is a string and not empty
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type based on prefix and length
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits, starts with 51-55
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  if (!(visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Implementation of the Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}