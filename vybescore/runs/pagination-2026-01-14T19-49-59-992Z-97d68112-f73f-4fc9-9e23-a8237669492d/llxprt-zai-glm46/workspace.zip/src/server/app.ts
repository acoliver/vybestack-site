import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validatePageLimit(page: unknown, limit: unknown): { error?: string; page?: number; limit?: number } {
  const pageParam = page as string | undefined;
  const limitParam = limit as string | undefined;

  if (pageParam !== undefined && (pageParam === '' || isNaN(Number(pageParam)))) {
    return { error: 'Invalid page: must be a number' };
  }
  if (limitParam !== undefined && (limitParam === '' || isNaN(Number(limitParam)))) {
    return { error: 'Invalid limit: must be a number' };
  }

  const pageValue = pageParam ? Number(pageParam) : undefined;
  const limitValue = limitParam ? Number(limitParam) : undefined;

  if (pageValue !== undefined && (pageValue <= 0 || !Number.isInteger(pageValue))) {
    return { error: 'Invalid page: must be a positive integer' };
  }
  if (limitValue !== undefined && (limitValue <= 0 || !Number.isInteger(limitValue))) {
    return { error: 'Invalid limit: must be a positive integer' };
  }
  if (limitValue !== undefined && limitValue > MAX_LIMIT) {
    return { error: `Invalid limit: cannot exceed ${MAX_LIMIT}` };
  }

  return { page: pageValue, limit: limitValue };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const validation = validatePageLimit(req.query.page, req.query.limit);
    
    if (validation.error) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
