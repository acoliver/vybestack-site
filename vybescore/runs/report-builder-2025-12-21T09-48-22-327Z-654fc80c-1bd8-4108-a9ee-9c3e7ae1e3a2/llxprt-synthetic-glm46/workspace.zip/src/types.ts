interface ReportEntry {
  label: string;
  amount: number;
}

interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

interface FormatOptions {
  includeTotals: boolean;
}

export type { ReportData, ReportEntry, FormatOptions };