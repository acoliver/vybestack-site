#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Define available formatters
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

// Parse CLI arguments
const args = process.argv.slice(2);

// Display usage and exit
function showUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Options:');
  console.error('  data.json      Path to JSON file containing report data');
  console.error('  --format       Output format: markdown, text');
  console.error('  --output       Optional output file path (default: stdout)');
  console.error('  --includeTotals Include total sum of all amounts');
}

// Parse arguments
let inputFile = '';
let format = '';
let outputFile = '';
let includeTotals = false;

let currentArg = '';
for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  
  if (arg === '--format' || arg === '--output') {
    // Store the flag for next iteration
    currentArg = arg;
  } else if (arg === '--includeTotals') {
    includeTotals = true;
  } else if (currentArg === '--format') {
    format = arg;
    currentArg = '';
  } else if (currentArg === '--output') {
    outputFile = arg;
    currentArg = '';
  } else if (!inputFile) {
    // First non-flag argument is input file
    inputFile = arg;
  } else {
    console.error(`Unexpected argument: ${arg}`);
    showUsage();
    process.exit(1);
  }
}

// Validate required arguments
if (!inputFile || !format) {
  console.error('Missing required arguments');
  showUsage();
  process.exit(1);
}

// Validate format
if (!formatters[format as keyof typeof formatters]) {
  console.error(`Unsupported format: ${format}`);
  console.error(`Supported formats: ${Object.keys(formatters).join(', ')}`);
  process.exit(1);
}

// Load and validate JSON data
let reportData: ReportData;
try {
  const fileContent = readFileSync(inputFile, 'utf8');
  const parsed = JSON.parse(fileContent);
  
  // Validate required fields
  if (!parsed.title || typeof parsed.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }
  
  if (!parsed.summary || typeof parsed.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }
  
  if (!Array.isArray(parsed.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }
  
  // Validate entries
  for (let i = 0; i < parsed.entries.length; i++) {
    const entry = parsed.entries[i];
    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error(`Entry ${i} is missing or has an invalid "label" field (must be a string)`);
    }
    if (typeof entry.amount !== 'number') {
      throw new Error(`Entry ${i} is missing or has an invalid "amount" field (must be a number)`);
    }
  }
  
  reportData = {
    title: parsed.title,
    summary: parsed.summary,
    entries: parsed.entries,
  };
} catch (error) {
  if (error instanceof SyntaxError) {
    console.error(`Error: Invalid JSON in ${inputFile}: ${error.message}`);
  } else {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
  }
  process.exit(1);
}

// Generate report
const options: FormatOptions = { includeTotals };
const formatter = formatters[format as keyof typeof formatters];
const report = formatter(reportData, options);

// Output report
try {
  if (outputFile) {
    writeFileSync(outputFile, report, 'utf8');
  } else {
    process.stdout.write(report);
  }
} catch (error) {
  console.error(`Error writing output: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}
