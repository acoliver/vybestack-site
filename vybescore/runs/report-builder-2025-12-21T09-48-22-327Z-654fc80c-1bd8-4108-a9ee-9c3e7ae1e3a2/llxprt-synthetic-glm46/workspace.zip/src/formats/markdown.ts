import type { ReportData, FormatOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: FormatOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  // Calculate total if requested
  const total = includeTotals 
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : null;

  // Format amount with 2 decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  // Build output
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${title}`);
  lines.push('');
  
  // Summary
  lines.push(summary);
  lines.push('');
  
  // Entries heading
  lines.push('## Entries');
  
  // Entries list
  entries.forEach(entry => {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  });
  
  // Total if requested
  if (includeTotals && total !== null) {
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}