import type { ReportData, RenderOptions } from './types.js';

export type Formatter = (data: ReportData, options: RenderOptions) => string;

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}
