#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { getFormatter, type Format } from '../formatters.js';
import { validateReportData } from '../validator.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: 'markdown',
    includeTotals: false
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      result.format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      if (result.inputFile) {
        throw new Error(`Unexpected argument: ${arg}`);
      }
      result.inputFile = arg;
    }

    i++;
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  return result;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const inputPath = path.resolve(args.inputFile);

    let inputContent: string;
    try {
      inputContent = fs.readFileSync(inputPath, 'utf-8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        throw new Error(`Input file not found: ${inputPath}`);
      }
      throw error;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(inputContent);
    } catch (error) {
      throw new Error(`Invalid JSON in input file: ${args.inputFile}`);
    }

    const data = validateReportData(jsonData);

    const formatter = getFormatter(args.format);
    const output = formatter.render(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      const outputPath = path.resolve(args.outputPath);
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
