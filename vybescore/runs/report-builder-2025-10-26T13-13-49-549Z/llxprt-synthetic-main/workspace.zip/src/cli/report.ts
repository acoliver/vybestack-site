#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { parseArgs } from '../utils/args.js';
import { loadJsonData } from '../utils/validation.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { FormatOptions } from '../types.js';

type Formatter = (options: FormatOptions) => string;

// Map of format names to their respective formatter functions
const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};

function main(): void {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArgs(process.argv);
    
    // Validate format is supported
    if (!formatters[format]) {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Load and validate the JSON data
    const data = loadJsonData(inputFile);
    
    // Render the report
    const formatter = formatters[format];
    const report = formatter({
      data,
      options: { includeTotals }
    });
    
    // Output the report
    if (outputPath) {
      writeFileSync(outputPath, report, 'utf-8');
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();