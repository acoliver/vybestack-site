export interface ParsedArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Skip node and script name
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse the remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output') {
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}