/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Process equality parameter
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const observers = new Set<Observer<T>>()

  const computed: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track this observer for notification when computed value changes
      observers.add(observer as Observer<T>)
    }
    return o.value!
  }

  // Store original update function to wrap it
  const originalUpdateFn = updateFn
  
  // Wrap update function to handle observers and equality
  o.updateFn = (currentValue?: T) => {
    const newValue = originalUpdateFn(currentValue)
    
    // Check if value should be updated based on equality function
    if (equalFn && o.value !== undefined && equalFn(o.value, newValue)) {
      return o.value
    }
    
    const oldValue = o.value
    o.value = newValue
    
    // Notify all observers if value actually changed
    if (oldValue !== o.value) {
      observers.forEach(observer => {
        updateObserver(observer)
      })
    }
    
    return o.value
  }

  // Initial computation
  updateObserver(o)

  return computed
}