#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): { inputFile: string; options: CliOptions } {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[2];
  let format: FormatType = 'markdown';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        {
          const formatValue = args[i];
          if (formatValue !== 'markdown' && formatValue !== 'text') {
            console.error(`Error: Unsupported format "${formatValue}"`);
            process.exit(1);
          }
          format = formatValue as FormatType;
        }
        break;
      
      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        output = args[i];
        break;
      
      case '--includeTotals':
        includeTotals = true;
        break;
      
      default:
        console.error(`Error: Unknown argument "${args[i]}"`);
        process.exit(1);
    }
  }

  return { inputFile, options: { format, output, includeTotals } };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: must be an object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Missing or invalid "title" field (must be a string)');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field (must be a string)');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Missing or invalid "entries" field (must be an array)');
    }
    
    for (const [index, entry] of obj.entries.entries()) {
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${index}: must be an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field (must be a string)`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field (must be a number)`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

function renderReport(data: ReportData, options: CliOptions): string {
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals
  };

  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, renderOptions);
    case 'text':
      return renderText(data, renderOptions);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

async function main() {
  try {
    const { inputFile, options } = parseArgs(process.argv);
    const data = loadReportData(inputFile);
    const output = renderReport(data, options);

    if (options.output) {
      await writeFile(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

main();
