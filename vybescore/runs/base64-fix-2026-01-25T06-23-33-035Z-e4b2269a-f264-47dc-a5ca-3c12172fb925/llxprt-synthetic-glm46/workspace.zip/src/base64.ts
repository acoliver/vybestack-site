/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Base64 validation regex pattern.
 */
const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Base64 decode error message.
 */
const DECODE_ERROR_MESSAGE = 'Failed to decode Base64 input';

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Trim whitespace from input
  const trimmedInput = input.trim();
  
  // Check if input is non-empty
  if (!trimmedInput) {
    throw new Error(DECODE_ERROR_MESSAGE);
  }
  
  // Validate that the input contains only valid Base64 characters
  if (!BASE64_PATTERN.test(trimmedInput)) {
    throw new Error(DECODE_ERROR_MESSAGE);
  }
  
  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error(DECODE_ERROR_MESSAGE);
  }
}
