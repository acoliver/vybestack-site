import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const initSqlJs = require('sql.js');

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface SubmissionData extends FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
function getPort(): number {
  return parseInt(process.env.PORT || '3000', 10);
}

// Set up EJS and static files
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));
app.use('/public', express.static('public'));
app.use(express.urlencoded({ extended: true }));

// Database setup
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      saveDatabase();
    }
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    if (db) db.close();
    throw error;
  }
}

function saveDatabase(): void {
  try {
    // Ensure directory exists before saving
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validation functions
function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone.trim()) && phone.trim().length > 0;
}

function validatePostalCode(code: string): boolean {
  // Allow alphanumeric characters, spaces, and common separators
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(code.trim()) && code.trim().length > 0;
}

function validateForm(data: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!data.firstName || !validateRequired(data.firstName)) {
    errors.push('First name is required');
  }

  if (!data.lastName || !validateRequired(data.lastName)) {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || !validateRequired(data.streetAddress)) {
    errors.push('Street address is required');
  }

  if (!data.city || !validateRequired(data.city)) {
    errors.push('City is required');
  }

  if (!data.stateProvince || !validateRequired(data.stateProvince)) {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || !validateRequired(data.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal/Zip code contains invalid characters');
  }

  if (!data.country || !validateRequired(data.country)) {
    errors.push('Country is required');
  }

  if (!data.email || !validateRequired(data.email)) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!data.phone || !validateRequired(data.phone)) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number contains invalid characters');
  }

  return { isValid: errors.length === 0, errors };
}

function escapeSqlString(str: string): string {
  // Escape single quotes for SQL to prevent injection
  return str.replace(/'/g, "''");
}

function insertSubmission(data: SubmissionData): void {
  const sql = `
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (
      '${escapeSqlString(data.firstName.trim())}',
      '${escapeSqlString(data.lastName.trim())}',
      '${escapeSqlString(data.streetAddress.trim())}',
      '${escapeSqlString(data.city.trim())}',
      '${escapeSqlString(data.stateProvince.trim())}',
      '${escapeSqlString(data.postalCode.trim())}',
      '${escapeSqlString(data.country.trim())}',
      '${escapeSqlString(data.email.trim())}',
      '${escapeSqlString(data.phone.trim())}'
    )
  `;
  
  db.run(sql);
  saveDatabase();
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = req.body;
  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  // Cast to SubmissionData since we've validated all required fields
  const submissionData: SubmissionData = {
    firstName: formData.firstName!,
    lastName: formData.lastName!,
    streetAddress: formData.streetAddress!,
    city: formData.city!,
    stateProvince: formData.stateProvince!,
    postalCode: formData.postalCode!,
    country: formData.country!,
    email: formData.email!,
    phone: formData.phone!
  };

  insertSubmission(submissionData);

  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(submissionData.firstName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', {
    firstName: decodeURIComponent(firstName)
  });
});

// Health check endpoint for testing
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`\nReceived ${signal}, shutting down gracefully...`);
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<ReturnType<typeof app.listen>> {
  await initializeDatabase();
  
  const port = getPort();
  const server = app.listen(port, () => {
    console.log(`🚀 Server running on http://localhost:${port}`);
  });

  server.on('close', () => {
    if (db) {
      saveDatabase();
      db.close();
    }
  });

  return server;
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, startServer, gracefulShutdown };