import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import * as Express from 'express';
import { startServer } from '../../dist/server.js';

let server: ReturnType<typeof startServer>;
let app: Express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Use port 0 to let the system assign an available port
  const originalEnv = process.env.PORT;
  process.env.PORT = '0';
  server = await startServer();
  process.env.PORT = originalEnv;
  
  // Get the actual app for supertest
  const { app: serverApp } = await import('../../dist/server.js');
  app = serverApp;
});

afterAll(async () => {
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    
    // Verify database was created and has data
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow the redirect to check thank-you page
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you, John!');
  });
});
