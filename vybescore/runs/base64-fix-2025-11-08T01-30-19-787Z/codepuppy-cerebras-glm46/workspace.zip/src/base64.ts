/**
 * Encode plain text to Base64 using RFC 4648 standard Base64 alphabet.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  try {
    return Buffer.from(input, 'utf8').toString('base64');
  } catch (error) {
    throw new Error('Failed to encode text to Base64');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove whitespace from input
  const trimmedInput = input.trim();
  
  // Check for invalid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    // Buffer.from with 'base64' handles padding automatically
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}