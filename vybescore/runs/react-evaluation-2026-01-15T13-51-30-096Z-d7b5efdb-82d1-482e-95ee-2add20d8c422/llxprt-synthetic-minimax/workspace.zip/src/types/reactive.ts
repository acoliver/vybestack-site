/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Listener = () => void

// Observer pattern interfaces
export interface Observer<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface ObserverR<T> extends Observer<T> {}

export interface ObserverV<T> extends Observer<T> {}

export interface Subject<T> {
  value: T
  dependents: Set<() => void>
  read: GetterFn<T>
  write: SetterFn<T>
}

export interface SubjectR<T> extends Subject<T> {}

export interface SubjectV<T> extends Subject<T> {}

// Global state for reactive system
let activeComputation: (() => void) | null = null

export function setActiveComputation(computation: (() => void) | null): void {
  activeComputation = computation
}

export function getActiveComputation(): (() => void) | null {
  return activeComputation
}

// Global dependency tracking system
const dependencyMap = new Map<() => void, Set<() => void>>()

export function registerDependency(source: () => void, target: () => void): void {
  if (!dependencyMap.has(source)) {
    dependencyMap.set(source, new Set())
  }
  dependencyMap.get(source)!.add(target)
}

export function notifyDependents(source: () => void): void {
  const dependents = dependencyMap.get(source)
  if (dependents) {
    const dependentsCopy = new Set(dependents)
    for (const dependent of dependentsCopy) {
      if (typeof dependent === 'function') {
        dependent()
      }
    }
  }
}
