/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  EqualFn,
  getActiveComputation,
  setActiveComputation,
  registerDependency,
  notifyDependents
} from '../types/reactive.ts'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let currentValue: T | undefined = value
  let isInitialized = false

  const getter: GetterFn<T> = () => {
    const previous = getActiveComputation()
    setActiveComputation(getter)
    
    try {
      const oldValue = currentValue
      
      if (!isInitialized) {
        currentValue = updateFn()
        isInitialized = true
      } else {
        currentValue = updateFn(currentValue)
      }
      
      // If value changed, notify all dependents
      if (isInitialized && oldValue !== currentValue) {
        notifyDependents(getter)
      }
      
      return currentValue!
    } finally {
      setActiveComputation(previous)
    }
  }

  return getter
}
