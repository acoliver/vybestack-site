/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn, 
  getActiveComputation,
  setActiveComputation
} from '../types/reactive.ts'

// Track callback subscriptions for cleanup
const callbackSubscriptions = new Map<() => void, Set<() => void>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  let disposed = false
  
  const callback = () => {
    if (disposed) return
    
    // Set this callback as the active computation during execution
    const previous = getActiveComputation()
    setActiveComputation(callback)
    
    try {
      updateFn()
    } finally {
      // Restore previous computation context
      setActiveComputation(previous)
    }
  }
  
  // Initial execution to establish dependencies
  callback()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up subscription tracking
    callbackSubscriptions.delete(callback)
  }
}
