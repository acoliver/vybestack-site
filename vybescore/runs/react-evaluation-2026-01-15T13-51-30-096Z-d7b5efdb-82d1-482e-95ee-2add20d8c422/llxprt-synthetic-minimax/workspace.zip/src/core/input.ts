/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getActiveComputation,
  registerDependency,
  notifyDependents
} from '../types/reactive.ts'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue: T = value

  const read: GetterFn<T> = () => {
    const current = getActiveComputation()
    if (current) {
      registerDependency(read, current)
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = currentValue
    currentValue = nextValue
    
    if (oldValue !== nextValue) {
      notifyDependents(read)
    }
    return currentValue
  }

  return [read, write]
}
