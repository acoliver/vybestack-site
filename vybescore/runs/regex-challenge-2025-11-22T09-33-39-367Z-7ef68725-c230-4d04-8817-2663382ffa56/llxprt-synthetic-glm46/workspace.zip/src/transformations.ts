/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Check for empty text
  if (!text || text.trim() === '') {
    return text;
  }

  // Process the text to:
  // 1. Insert exactly one space between sentences even if input omitted it
  // 2. Collapse multiple consecutive spaces to single spaces
  // 3. Capitalize the first character after sentence termination marks

  // First, ensure spacing between sentences (.?! punctuation)
  let result = text.replace(/([.!?])(\S)/g, '$1 $2');

  // Collapse multiple spaces to a single space, but preserve single spaces
  result = result.replace(/\s{2,}/g, ' ');

  // Common abbreviations to avoid capitalizing after them
  const abbreviations = ['mr', 'mrs', 'dr', 'prof', 'sr', 'jr', 'st', 'ave', 'blvd', 'rd', 'etc', 'e.g', 'i.e'];

  // Capitalize after sentence termination marks, but preserve abbreviations
  // We need to be more careful with abbreviations by checking the context
  const sentencesRegex = /([.!?])(\s+)([a-z])/g;
  result = result.replace(sentencesRegex, (match, punct, space, letter) => {
    // Check if this follows an abbreviation by looking at the word before the punctuation
    const beforeMatch = result.substring(0, result.indexOf(match)).match(/(\w+)$/);
    if (beforeMatch) {
      const wordBefore = beforeMatch[1].toLowerCase();
      // If it's one of our abbreviations, don't capitalize
      if (abbreviations.includes(wordBefore)) {
        return match;
      }
    }
    return punct + space + letter.toUpperCase();
  });

  // Handle special case: first character should be capitalized
  if (result && result[0] && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to extract URLs, covering http, https, www, and domain patterns
  // We'll extract URLs without trailing punctuation
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:)\]]+$/, ''));
}

/**
 * Replace http:// URLs with https://, leaving already-secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave already https:// URLs
  return text.replace(/http:\/\/(?!\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Process URLs in the text
  return text.replace(/https?:\/\/(example\.com)(\/[^\s]*)?/g, (match, domain, path) => {
    // Always upgrade to https
    const secureDomain = 'https://' + domain;

    // If there's no path, just return the secure URL
    if (!path) {
      return secureDomain;
    }

    // Check if this is a docs path that should have its host rewritten
    const isDocsPath = path.startsWith('/docs/');

    // Check if the path contains dynamic hints that should prevent host rewrite
    // We need to check for cgi-bin, query strings, and legacy extensions
    const hasDynamicHints = /(?:\/(?:cgi-bin)|\?|&(?:.*=)|\.(?:jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);

    // If it's a docs path without dynamic hints, rewrite the host
    if (isDocsPath && !hasDynamicHints) {
      return 'https://docs.example.com' + path;
    }

    // Otherwise just upgrade the scheme to https
    return secureDomain + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;

  // Try to match the entire string
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  // Extract year, month, and day
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month/day combinations
  const daysInMonth = [
    31, // January
    month === 2 ? (isLeapYear(parseInt(year, 10)) ? 29 : 28) : 0, // February
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];

  // For months other than February, use the standard days
  if (month !== 2) {
    if (day > daysInMonth[month - 1]) {
      return 'N/A';
    }
  }

  return year;
}

/**
 * Helper function to determine if a year is a leap year
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}