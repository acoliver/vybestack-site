export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex using RFC 5322 simplified approach
  // Accept typical addresses such as name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores, and other invalid forms
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/;
  
  // Check if format is valid
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  // Reject consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject if local part starts or ends with dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Explicitly acknowledge the options parameter
  if (options?.allowExtensions) {
    // Handle extensions if needed in future
  }
  // Remove non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let normalizedDigits = digitsOnly;
  if (normalizedDigits.startsWith('1') && normalizedDigits.length === 11) {
    normalizedDigits = normalizedDigits.substring(1);
  }
  
  // Must be exactly 10 digits after normalization
  if (normalizedDigits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = normalizedDigits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Format validation regex
  const phoneRegex = /^(?:\+?1\s*)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))\s*[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[ -]/g, '');
  
  // Argentine phone regex patterns
  // Pattern 1: +54 9 XXXX XXXXXX (with country code)
  // Pattern 2: +54 XXXX XXXXXX (with country code, no mobile indicator)
  // Pattern 3: 0 XXXX XXXXXX (with trunk prefix)
  // Pattern 4: 011 1234 5678 (Buenos Aires specific case)
  // Pattern 5: 0341 4234567 (with trunk prefix and area code)
  
  const withCountryCode = /^\+54(?:9)?([2-9]\d{1,3})(\d{6,8})$/;
  const withTrunkPrefix = /^0([2-9]\d{1,3})(\d{6,8})$/;
  
  // Try both patterns
  return withCountryCode.test(normalized) || withTrunkPrefix.test(normalized);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and complex names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}.'\s-]+$/u;
  
  // Basic regex check first
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with consecutive special characters
  if (value.includes('--') || value.includes("..") || value.includes("  ")) {
    return false;
  }
  
  // Reject names that contain numbers
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with special characters like the AE symbol in "X Æ A-12"
  if (/Æ|[^\p{L}\p{M}.'\s\-çñáéíóúüàèìòù]/u.test(value)) {
    return false;
  }
  
  // Names should have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx with Luhn checksum verification.
 */
export function isValidCreditCard(value: string): boolean {
  // Check if input is all digits and valid length
  const digits = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any valid format
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Perform Luhn algorithm check
  return luhnCheck(digits);
}

/**
 * Helper function for Luhn checksum verification
 */
function luhnCheck(num: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = num.length - 1; i >= 0; i--) {
    let digit = parseInt(num[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
