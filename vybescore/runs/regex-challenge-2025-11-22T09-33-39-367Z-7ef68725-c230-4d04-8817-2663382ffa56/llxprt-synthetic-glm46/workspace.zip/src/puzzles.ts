/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Define word boundary and regex pattern
  const wordBoundary = '\\b';
  const regexPattern = `${wordBoundary}${escapedPrefix}\\w+`;
  
  // Find all words starting with the prefix
  const allMatches = text.match(new RegExp(regexPattern, 'g')) || [];
  
  // Filter out exceptions
  const result: string[] = [];
  const exceptionsSet = new Set(exceptions);
  
  allMatches.forEach(match => {
    if (!exceptionsSet.has(match)) {
      result.push(match);
    }
  });
  
  return result;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Standard approach without lookbehind to ensure compatibility and correct return values
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(pattern) || [];
  
  // Map matches to include the digit prefix as expected by tests
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (/\d/.test(value) === false) {
    return false;
  }
  
  // Must contain at least one symbol
  // Check for symbols individually for better debugging
  const requiredSymbols = '!@#$%^&*()_+=[]{};:\'"|,.<>/?';
  let hasSymbol = false;
  for (const char of requiredSymbols) {
    if (value.includes(char)) {
      hasSymbol = true;
      break;
    }
  }
  if (!hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns where a sequence of 2-4 characters repeats immediately
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that handles common formats
  const ipv6Pattern = 
    // Full IPv6 format (8 groups of 1-4 hex digits)
    '\\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\\b|' +
    // Pattern for :: compression between groups
    '\\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\\b|' +
    // Pattern for :: compression at start
    '\\b::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,7}\\b|' +
    // Pattern for :: compression in middle
    '\\b[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}\\b|' +
    // Pattern for :: compression at end
    '\\b[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){1,7}:\\b|' +
    // Just ::
    '\\b::\\b';
  
  // Check if value contains IPv6 pattern
  return new RegExp(ipv6Pattern).test(value);
}