import type { ReportData, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries
  lines.push('Entries:');
  
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }
  
  // Optional totals
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}