#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import type { ReportData, RenderOptions, ReportFormat } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): { dataPath: string; format: ReportFormat; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse format
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  const formatValue = args[formatIndex + 1];
  const format: ReportFormat = formatValue as ReportFormat;
  
  // Parse output
  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1 && outputIndex + 1 < args.length) {
    outputPath = args[outputIndex + 1];
  }
  
  // Parse includeTotals
  const totalsIndex = args.indexOf('--includeTotals');
  if (totalsIndex !== -1) {
    includeTotals = true;
  }
  
  // Validate format
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function parseData(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON structure');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string' || 
        typeof reportData.summary !== 'string' ||
        !Array.isArray(reportData.entries)) {
      throw new Error('Missing required fields');
    }
    
    for (const entry of reportData.entries) {
      if (!entry || typeof entry !== 'object' ||
          typeof (entry as Record<string, unknown>).label !== 'string' ||
          typeof (entry as Record<string, unknown>).amount !== 'number') {
        throw new Error('Invalid entry format');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    console.error(`Error parsing data file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs();
    const data = parseData(dataPath);
    const options: RenderOptions = { includeTotals };
    
    let output: string;
    if (format === 'markdown') {
      output = renderMarkdown(data, options);
    } else if (format === 'text') {
      output = renderText(data, options);
    } else {
      console.error('Unsupported format');
      process.exit(1);
    }
    
    if (outputPath) {
      const { writeFileSync } = await import('node:fs');
      writeFileSync(outputPath, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
