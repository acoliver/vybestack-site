#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { ReportData, RenderOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const cliArgs: CliArgs = {
    dataPath: args[0],
    format: '',
    includeTotals: false
  };
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        cliArgs.format = args[i + 1];
        i++;
        break;
      case '--output':
        cliArgs.outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        cliArgs.includeTotals = true;
        break;
    }
  }
  
  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return cliArgs;
}

function loadReportData(dataPath: string): ReportData {
  try {
    const absolutePath = path.resolve(dataPath);
    const fileContent = fs.readFileSync(absolutePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;
    
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      throw new Error('Invalid report data structure');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry structure');
      }
    }
    
    return data;
  } catch (error) {
    console.error(`Error loading report data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
}

function writeReport(report: string, outputPath?: string): void {
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, report);
      console.log(`Report written to ${outputPath}`);
    } catch (error) {
      console.error(`Error writing report: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(report);
  }
}

function main(): void {
  const cliArgs = parseArgs();
  const reportData = loadReportData(cliArgs.dataPath);
  const options: RenderOptions = { includeTotals: cliArgs.includeTotals };
  const report = renderReport(reportData, cliArgs.format, options);
  writeReport(report, cliArgs.outputPath);
}

main();
