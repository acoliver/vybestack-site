/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, CleanupFn, TrackedSubject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const cleanups: Array<CleanupFn> = []
  const dependencies: Set<TrackedSubject> = new Set()
  
  const observer: Observer<T> = {
    value,
    _dependencies: dependencies,
    updateFn: (prevValue?: T) => {
      // Run the update function with dependencies tracked
      const result = updateFn(prevValue)
      return result
    },
    onCleanup: (cleanup: CleanupFn) => {
      cleanups.push(cleanup)
    },
    _track: (subject: TrackedSubject, cleanup: CleanupFn) => {
      // Only register if not already tracked
      if (!dependencies.has(subject)) {
        cleanups.push(cleanup)
        dependencies.add(subject)
      }
    },
  }
  
  // Register observer to track dependencies and run initial callback
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all tracked subjects
    for (const subject of dependencies) {
      if (subject.removeObserver) {
        subject.removeObserver(observer as unknown as Observer<unknown>)
      }
    }
    
    // Clean up all dependencies
    for (const cleanup of cleanups) {
      cleanup()
    }
    cleanups.length = 0
    dependencies.clear()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
