/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  TrackedSubject
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers: Set<Observer<unknown>> = new Set()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }
  
  // Create a tracked subject wrapper that can be used for cleanup
  const trackedSubject: TrackedSubject = {
    observers,
    notify: () => {
      const observersToUpdate = Array.from(observers)
      for (const observer of observersToUpdate) {
        updateObserver(observer)
      }
    },
    removeObserver: (observerToRemove: Observer<unknown>) => {
      observers.delete(observerToRemove)
    }
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // Check if already tracking this observer
      if (!observers.has(observer as Observer<unknown>)) {
        observers.add(observer as Observer<unknown>)
        
        // Register cleanup function with the observer
        const cleanup = () => {
          observers.delete(observer as Observer<unknown>)
        }
        
        if (observer.onCleanup) {
          observer.onCleanup(cleanup)
        }
        
        // Also track using the _track method if available
        if (observer._track) {
          observer._track(trackedSubject, cleanup)
        }
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    trackedSubject.notify()
    return s.value
  }

  return [read, write]
}
