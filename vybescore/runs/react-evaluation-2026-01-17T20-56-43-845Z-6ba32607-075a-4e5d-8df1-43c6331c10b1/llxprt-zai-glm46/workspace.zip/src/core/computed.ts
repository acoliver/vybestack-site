/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  CleanupFn,
  TrackedSubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: Set<Observer<unknown>> = new Set()
  const cleanups: Array<CleanupFn> = []
  const dependencies: Set<TrackedSubject> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    _dependencies: dependencies,
    updateFn: (prevValue?: T) => {
      // Clean up previous dependencies
      for (const cleanup of cleanups) {
        cleanup()
      }
      cleanups.length = 0
      dependencies.clear()
      
      // Run the actual update function first to get new value
      const newValue = updateFn(prevValue)
      // Store the new value
      o.value = newValue
      
      // Dependencies are re-established during the updateFn call
      // Keep them for next update
      
      // Then notify all observers that depend on this computed value
      const observersToUpdate = Array.from(observers)
      for (const observer of observersToUpdate) {
        updateObserver(observer)
      }
      return newValue
    },
    onCleanup: (cleanup: CleanupFn) => {
      cleanups.push(cleanup)
    },
    _track: (subject: TrackedSubject, cleanupFn: CleanupFn) => {
      cleanups.push(cleanupFn)
      dependencies.add(subject)
    },
  }
  
  // Initialize the computed value by running the update function
  // This establishes the initial dependency tracking
  updateObserver(o)
  
  // Create a tracked subject wrapper for this computed value
  const trackedSubject: TrackedSubject = {
    observers,
    notify: () => {
      // Re-compute when a dependency changes
      updateObserver(o)
    },
    removeObserver: (observerToRemove: Observer<unknown>) => {
      observers.delete(observerToRemove)
    }
  }
  
  const getter: GetterFn<T> = (): T => {
    const activeObs = getActiveObserver()
    // If being accessed by another observer (callback or computed), register dependency
    if (activeObs) {
      if (!observers.has(activeObs as Observer<unknown>)) {
        observers.add(activeObs as Observer<unknown>)
        // Register cleanup function with the active observer
        if (activeObs.onCleanup) {
          activeObs.onCleanup(() => {
            observers.delete(activeObs as Observer<unknown>)
          })
        }
        // Also track using _track if available
        if (activeObs._track) {
          activeObs._track(trackedSubject, () => {
            observers.delete(activeObs as Observer<unknown>)
          })
        }
      }
    }
    return o.value!
  }
  
  return getter
}
