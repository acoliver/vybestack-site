#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportFormat } from '../types.js';

const renderers = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

interface ParsedArgs {
  dataFile: string;
  format: ReportFormat;
  output?: string;
  includeTotals?: boolean;
}

function parseArgs(): ParsedArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  let format: ReportFormat | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];
    
    if (arg === '--format') {
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = nextArg as ReportFormat;
      if (!['markdown', 'text'].includes(format)) {
        console.error(`Error: Unsupported format: ${nextArg}`);
        process.exit(1);
      }
      i++; // Skip next arg
    } else if (arg === '--output') {
      if (!nextArg) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      output = nextArg;
      i++; // Skip next arg
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    dataFile,
    format,
    output,
    includeTotals,
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    console.error('Error: Missing or invalid "title" field');
    return false;
  }
  
  if (typeof reportData.summary !== 'string') {
    console.error('Error: Missing or invalid "summary" field');
    return false;
  }
  
  if (!Array.isArray(reportData.entries)) {
    console.error('Error: Missing or invalid "entries" field');
    return false;
  }
  
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      console.error('Error: Invalid entry format');
      return false;
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string') {
      console.error('Error: Missing or invalid "label" in entry');
      return false;
    }
    
    if (typeof entryRecord.amount !== 'number') {
      console.error('Error: Missing or invalid "amount" in entry');
      return false;
    }
  }
  
  return true;
}

function main(): void {
  const { dataFile, format, output, includeTotals } = parseArgs();
  
  try {
    const fileContent = fs.readFileSync(dataFile, 'utf-8');
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in ${dataFile}`);
      process.exit(1);
    }
    
    if (!validateReportData(data)) {
      process.exit(1);
    }
    
    const renderer = renderers[format];
    const rendered = renderer(data, { includeTotals });
    
    if (output) {
      fs.writeFileSync(output, rendered);
      console.log(`Report written to ${output}`);
    } else {
      console.log(rendered);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
