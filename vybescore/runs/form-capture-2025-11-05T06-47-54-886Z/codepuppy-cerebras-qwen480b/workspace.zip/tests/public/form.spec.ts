import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, server, dbInitializationPromise } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

// Clean up database before tests and wait for initialization
beforeAll(async () => {
  // Wait for database initialization
  await dbInitializationPromise;
  
  // Remove existing database file if it exists
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Give the database a moment to reinitialize
  await new Promise(resolve => setTimeout(resolve, 200));
});

afterAll(async () => {
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close server if it's running
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that the form renders
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
    
    // Check for all required fields with proper labels and IDs
    const requiredFields = [
      { id: 'firstName', name: 'firstName', label: 'First name' },
      { id: 'lastName', name: 'lastName', label: 'Last name' },
      { id: 'streetAddress', name: 'streetAddress', label: 'Street address' },
      { id: 'city', name: 'city', label: 'City' },
      { id: 'stateProvince', name: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', name: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', name: 'country', label: 'Country' },
      { id: 'email', name: 'email', label: 'Email' },
      { id: 'phone', name: 'phone', label: 'Phone number' }
    ];
    
    requiredFields.forEach(({ id, name, label }) => {
      expect($( `#${id}`)).toHaveLength(1);
      expect($( `#${id}`).attr('name')).toBe(name);
      expect($( `label[for="${id}"]` )).toHaveLength(1);
      expect($( `label[for="${id}"]` ).text().trim()).toBe(label);
    });
    
    // Check for submit button
    expect($('button[type="submit"]')).toHaveLength(1);
    
    // Check CSS link
    expect($('link[rel="stylesheet"][href="/public/styles.css"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Wait a moment for database initialization
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    // Check redirect location
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify the data was persisted
    await new Promise(resolve => setTimeout(resolve, 100)); // Give database time to save
    
    // Check thank-you page content
    const thankYouResponse = await request(app)
      .get(response.headers.location)
      .expect(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John!');
    expect($('body').text()).toContain('stranger on the internet');
  });

  it('handles validation errors correctly', async () => {
    const invalidFormData = {
      firstName: '', // Empty - should fail validation
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'invalid-email', // Invalid email format
      phone: '12345'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidFormData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check that error messages are displayed
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list').text()).toContain('First name is required');
    expect($('.error-list').text()).toContain('Please enter a valid email address');
    
    // Check that form values are preserved
    expect($('#lastName').val()).toBe('Doe');
    expect($('#email').val()).toBe('invalid-email');
  });

  it('validates international formats', async () => {
    // Test UK postal code
    const ukFormData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA', // UK postal code
      country: 'United Kingdom',
      email: 'jane.smith@example.co.uk',
      phone: '+44 20 7946 0958' // UK phone number
    };
    
    const response = await request(app)
      .post('/submit')
      .send(ukFormData)
      .expect(302);
    
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
  });
});