export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 */
export function isValidEmail(value: string): boolean {
  // Remove whitespace
  value = value.trim();
  
  // Basic email pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks:
  // 1. No double dots
  // 2. No trailing dots in local part or domain
  // 3. No underscores in domain
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dots
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + for country code
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let processedValue = digitsOnly;
  if (processedValue.startsWith('+1')) {
    processedValue = processedValue.substring(2);
  } else if (processedValue.startsWith('1') && processedValue.length === 11) {
    processedValue = processedValue.substring(1);
  }
  
  // Check if it has exactly 10 digits now
  if (processedValue.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - should not start with 0 or 1
  const areaCode = processedValue.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Define regex patterns for Argentine phone numbers
  // Pattern 1: +54 9 11 1234 5678 or +54 341 123 4567
  // Pattern 2: 011 1234 5678 or 0341 4234567
  const internationalPattern = /^(\+54)(9)?(\d{2,4})(\d{6,8})$/;
  const localPattern = /^(0)(\d{2,4})(\d{6,8})$/;
  
  let match;
  if (digitsOnly.startsWith('+54')) {
    match = digitsOnly.match(internationalPattern);
    if (!match) return false;
    
    const mobileIndicator = match[2]; // '9' or undefined
    const areaCode = match[3];
    const subscriberNumber = match[4];
    
    // Area code must start with 1-9 and be 2-4 digits
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
      return false;
    }
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  } else if (digitsOnly.startsWith('0')) {
    match = digitsOnly.match(localPattern);
    if (!match) return false;
    
    const areaCode = match[2];
    const subscriberNumber = match[3];
    
    // Area code must start with 1-9 and be 2-4 digits
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
      return false;
    }
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

/**
 * Validates personal names.
 */
export function isValidName(value: string): boolean {
  // Check if the name contains digits or symbols (except allowed ones)
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[^\d\p{P}]*([\p{L}\p{M}'\-\s][^\d\p{P}]*)*$/u;
  
  // Reject X Æ A-12 style names (contains digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(value: string): boolean {
  // Remove non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = cleanValue.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanValue.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using Luhn algorithm.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check card type based on prefix and length
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12}$/; // 16 digits, starts with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanValue);
}