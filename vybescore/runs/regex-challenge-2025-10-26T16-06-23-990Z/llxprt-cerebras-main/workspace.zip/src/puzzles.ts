/**
 * Finds words starting with a prefix but excluding exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex that matches words starting with the prefix
  // but excludes those in the exceptions list
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  
  // This regex looks for words that start with the prefix but are not in the exceptions
  const regex = new RegExp(`\\b(?!(${escapedExceptions})\\b)${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(regex);
  return matches ? [...new Set(matches.map(word => word.toLowerCase()))] : [];
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to ensure the token appears after a digit
  // and is not at the beginning of the string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(regex);
  return matches ? matches : [];
}

/**
 * Validates passwords based on security requirements.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase, lowercase, digit, and symbol
  if (!/[A-Z]/.test(value) || !/[a-z]/.test(value) || !/\d/.test(value) || !/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while excluding IPv4.
 */
export function containsIPv6(value: string): boolean {
  // Basic IPv6 regex pattern that covers standard and compressed formats
  // It excludes IPv4 addresses by ensuring there are enough colons for IPv6
  const ipv6Regex = /(?:^|(?<=\s))(?=.*:)(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}(?:$|(?=\s)|(?=[^\w:])(?<!\/))/g;
  
  // Also match compressed IPv6 (::) but ensure it's not an IPv4 address
  const compressedIpv6Regex = /(?:^|(?<=\s))(?=.*::)([0-9a-fA-F]{1,4}:){1,6}:([0-9a-fA-F]{1,4})?(?:$|(?=\s)|(?=[^\w:])(?<!\/))/g;
  
  // Check if the text contains IPv6
  return ipv6Regex.test(value) || compressedIpv6Regex.test(value);
}