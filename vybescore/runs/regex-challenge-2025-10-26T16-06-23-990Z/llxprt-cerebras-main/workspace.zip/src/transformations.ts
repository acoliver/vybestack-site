/**
 * Capitalizes the first character of each sentence.
 */
export function capitalizeSentences(text: string): string {
  // First, insert space after sentence-ending punctuation if missing
  // This regex finds punctuation followed by a non-space character
  text = text.replace(/([.?!])(\S)/g, '$1 $2');

  // Then capitalize first letter of each sentence (after punctuation + space or at beginning)
  // This regex matches the first letter of a sentence and capitalizes it
  return text.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => p1 + p2.toUpperCase());
}

/**
 * Extracts URLs from text.
 */
export function extractUrls(text: string): string[] {
  // This regex matches URLs starting with http:// or https://
  // It allows for various characters in the URL but excludes trailing punctuation
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s,.;:!?)\]'"<>\u201d\u2019]*/gi;
  const matches = text.match(urlRegex);
  return matches ? matches : [];
}

/**
 * Enforces HTTPS for all URLs in text.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs with /docs/ path to docs subdomain.
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs that start with http:// and optionally have a path starting with /docs/
  // but exclude those with dynamic elements like query strings or certain extensions
  const regex = /http:\/\/([^\/\s]+)(\/docs\/[^\s?&=.jsp.php.asp.aspx.do.cgi.pl.py]*)/gi;
  
  return text.replace(regex, (match, host, path) => {
    return `https://docs.${host}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy dates.
 */
export function extractYear(value: string): string {
  // Check if the value is in mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}