/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function
  const equalFn: EqualFn<T> | undefined = 
    equal === false ? () => false :
    equal === true ? Object.is :
    typeof equal === 'function' ? equal :
    Object.is

  // Create a subject that will hold our computed value
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }

  // Create an observer that will recompute the value when dependencies change
  const observer: Observer<T> = {
    name: options?.name,
    value: subject.value,
    updateFn: (currentValue) => {
      // This function runs when dependencies change
      // Recompute by calling the original updateFn
      const newValue = updateFn(currentValue)
      
      // Check if value actually changed
      const changed = !equalFn || !equalFn(subject.value, newValue)
      
      // Update the subject's stored value
      subject.value = newValue
      
      // If value changed and we have observers, notify them
      if (changed && subject.observer) {
        updateObserver(subject.observer as Observer<unknown>)
      }
      
      return newValue
    },
  }

  // Initial computation to establish dependencies and set initial value
  updateObserver(observer)
  subject.value = observer.value!

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If we're being observed, register as dependency
    if (activeObserver) {
      subject.observer = activeObserver
      
      // Re-establish our own dependencies by recomputing under this observer context
      updateObserver(observer)
      subject.value = observer.value!
    }
    
    return subject.value
  }

  return read
}