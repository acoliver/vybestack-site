import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

// SQL.js imports
import initSqlJs from "sql.js";

// Get __dirname equivalent in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Type for validation errors
interface ValidationError {
  [key: string]: string;
}

let db: unknown;
let dbFileExists = false;

// Initialize database on startup
async function initializeDatabase() {
  try {
    const SQLModule = await initSqlJs() as { 
      Database: new (buffer?: Uint8Array) => { 
        exec(sql: string): void; 
      }; 
    };
    
    const dbPath = path.join(__dirname, "..", "data", "submissions.sqlite");
    
    // Check if database file exists
    dbFileExists = fs.existsSync(dbPath);
    
    // Read existing database or create new one
    let buffer: Uint8Array;
    if (dbFileExists) {
      const dbFile = fs.readFileSync(dbPath);
      buffer = new Uint8Array(dbFile);
      db = new SQLModule.Database(buffer);
      console.log("Loaded existing database");
    } else {
      db = new SQLModule.Database();
      // Read and execute schema
      const schemaPath = path.join(__dirname, "..", "db", "schema.sql");
      const schema = fs.readFileSync(schemaPath, "utf8");
      (db as { exec(sql: string): void }).exec(schema);
      console.log("Created new database from schema");
    }
  } catch (error) {
    console.error("Failed to initialize database:", error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  try {
    const data = (db as { export(): Uint8Array }).export();
    const dbPath = path.join(__dirname, "..", "data", "submissions.sqlite");
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log("Database saved to disk");
  } catch (error) {
    console.error("Failed to save database:", error);
  }
}

// Validation functions
function validateForm(formData: FormData): ValidationError {
  const errors: ValidationError = {};

  // Required fields validation
  if (!formData.firstName.trim()) {
    errors.firstName = "First name is required";
  }

  if (!formData.lastName.trim()) {
    errors.lastName = "Last name is required";
  }

  if (!formData.streetAddress.trim()) {
    errors.streetAddress = "Street address is required";
  }

  if (!formData.city.trim()) {
    errors.city = "City is required";
  }

  if (!formData.stateProvince.trim()) {
    errors.stateProvince = "State/Province is required";
  }

  if (!formData.postalCode.trim()) {
    errors.postalCode = "Postal/Zip code is required";
  }

  if (!formData.country.trim()) {
    errors.country = "Country is required";
  }

  if (!formData.email.trim()) {
    errors.email = "Email is required";
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = "Please enter a valid email address";
  }

  if (!formData.phone.trim()) {
    errors.phone = "Phone number is required";
  } else if (!/^[+]?[0-9\s\-()]+$/.test(formData.phone)) {
    errors.phone = "Please enter a valid phone number";
  }

  return errors;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));

// Set EJS as views engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "templates"));

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("form", { 
    errors: {},
    formData: {
      firstName: "",
      lastName: "",
      streetAddress: "",
      city: "",
      stateProvince: "",
      postalCode: "",
      country: "",
      email: "",
      phone: ""
    }
  });
});

app.post("/submit", (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || "",
    lastName: req.body.lastName || "",
    streetAddress: req.body.streetAddress || "",
    city: req.body.city || "",
    stateProvince: req.body.stateProvince || "",
    postalCode: req.body.postalCode || "",
    country: req.body.country || "",
    email: req.body.email || "",
    phone: req.body.phone || ""
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Return form with validation errors
    return res.status(400).render("form", { errors, formData });
  }

  // Insert into database
  try {
    const Database = db as { prepare(sql: string): { run(params: unknown[]): void; free(): void } };
    const stmt = Database.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();

    // Save database after insertion
    saveDatabase();

    // Redirect to thank you page
    return res.redirect(302, "/thank-you");
  } catch (error) {
    console.error("Database error:", error);
    errors.general = "An unexpected error occurred. Please try again.";
    return res.status(500).render("form", { errors, formData });
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  // Get the latest submission to personalize the thank you message
  try {
    const Database = db as { 
      prepare(sql: string): { getAsObject(params: unknown[]): { first_name?: string }; free(): void } 
    };
    const stmt = Database.prepare("SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1");
    const result = stmt.getAsObject([]);
    stmt.free();
    
    res.render("thank-you", { 
      firstName: result.first_name || "Friend"
    });
  } catch (error) {
    console.error("Database error:", error);
    res.render("thank-you", { 
      firstName: "Friend"
    });
  }
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Handle graceful shutdown
  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully`);
    if (db) {
      (db as { close(): void }).close();
      console.log("Database connection closed");
    }
    server.close(() => {
      console.log("Server closed");
      process.exit(0);
    });
  };

  // Register signal handlers
  process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
  process.on("SIGINT", () => gracefulShutdown("SIGINT"));
  
  return server;
}

// Start the server
startServer().catch(error => {
  console.error("Failed to start server:", error);
  process.exit(1);
});