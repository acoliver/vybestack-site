import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(args: string[]): { dataFile: string; options: CLIOptions } {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  const options: CLIOptions = { format: 'text', includeTotals: false };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--format': {
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        const format = args[i + 1];
        if (format !== 'markdown' && format !== 'text') {
          throw new Error(`Unsupported format: ${format}`);
        }
        options.format = format as 'markdown' | 'text';
        i++; // skip next argument as it's the format value
        break;
      }

      case '--output': {
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        options.output = args[i + 1];
        i++; // skip next argument as it's the output path
        break;
      }

      case '--includeTotals':
        options.includeTotals = true;
        break;

      default:
        throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return { dataFile, options };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }

  return true;
}

function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { dataFile, options } = parseArguments(args);

    // Read and parse JSON file
    const jsonContent = readFileSync(dataFile, 'utf8');
    const data = JSON.parse(jsonContent);

    // Validate data
    validateReportData(data);

    // Render report
    const output = renderReport(data, options);

    // Write output
    if (options.output) {
      writeFileSync(options.output, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(`Error: ${error.message}\n`);
      process.exit(1);
    } else {
      process.stderr.write('Error: Unknown error occurred\n');
      process.exit(1);
    }
  }
}

main();