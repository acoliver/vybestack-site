import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!Number.isInteger(pageNum) || pageNum < 1) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
      // Prevent excessive pagination requests
      if (pageNum > 1000) {
        return res.status(400).json({ error: 'Invalid page parameter: value too large' });
      }
      page = pageNum;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!Number.isInteger(limitNum) || limitNum < 1) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      // Prevent excessive limit requests
      if (limitNum > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: value too large' });
      }
      limit = limitNum;
    }

    // Get page and limit with defaults
    const finalPage = page ?? 1;
    const finalLimit = limit ?? 5;

    const payload = listInventory(db, { page: finalPage, limit: finalLimit });
    res.json(payload);
  });

  return app;
}
