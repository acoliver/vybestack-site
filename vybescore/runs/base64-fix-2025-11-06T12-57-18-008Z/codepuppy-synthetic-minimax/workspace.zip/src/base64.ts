/**
 * Encode plain text to canonical Base64 (RFC 4648).
 * Uses the standard Base64 alphabet with + and / characters,
 * and includes padding (=) when required.
 */
export function encode(input: string): string {
  // Use standard base64 encoding which includes proper padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) using the
 * standard Base64 alphabet (+ and /). Throws error for invalid input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove whitespace from input (Base64 shouldn't have whitespace,
  // but we'll be lenient and strip it)
  const normalized = input.replace(/\s+/g, '');

  // Check for invalid Base64 characters (excluding = for now, we'll validate padding separately)
  const validBase64CharsRegex = /^[A-Za-z0-9+/=]+$/;
  if (!validBase64CharsRegex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check if padding is properly formatted
  const paddingIndex = normalized.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingPart = normalized.substring(paddingIndex);
    if (!/^=+$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: invalid padding format');
    }
    // Padding can only appear at the end and max 2 chars
    if (paddingPart.length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    // Padding must be at the very end - no non-padding chars after padding
    if (paddingPart.length > 0 && paddingIndex + paddingPart.length !== normalized.length) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
  }

  try {
    const result = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Additional validation: if the result contains the replacement character,
    // it likely means the input was invalid Base64
    if (result.includes('\uFFFD')) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}