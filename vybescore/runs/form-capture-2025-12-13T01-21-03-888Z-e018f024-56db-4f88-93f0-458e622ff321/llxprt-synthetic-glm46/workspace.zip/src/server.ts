import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initDatabase, { SqlValue } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Setup middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');

// Configure views path to work in both development and compiled environments
app.set('views', path.join(__dirname, 'templates'));

// Validate email format
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Validate phone number format (international)
function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

// Validate postal code (alphanumeric)
function isValidPostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

// Validate form data
function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  if (!formData.first_name?.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }
  
  if (!formData.last_name?.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }
  
  if (!formData.street_address?.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!formData.state_province?.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }
  
  if (!formData.postal_code?.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  } else if (!isValidPostalCode(formData.postal_code)) {
    errors.push({ field: 'postal_code', message: 'Invalid postal code format' });
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!isValidEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!isValidPhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone number format' });
  }

  return errors;
}

// Initialize database and start server
async function startServer() {
  try {
    const db = await initDatabase();
    
    // Routes
    app.get('/', (req: Request, res: Response) => {
      const errors = req.query.errors ? JSON.parse(req.query.errors as string) : null;
      const formData = req.query.formData ? JSON.parse(req.query.formData as string) : {};
      
      res.render('form', { 
        errors, 
        formData,
        title: 'International Contact Form'
      });
    });

    app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = req.body;
      const errors = validateForm(formData);
      
      if (errors.length > 0) {
        return res.redirect(`/?errors=${encodeURIComponent(JSON.stringify(errors))}&formData=${encodeURIComponent(JSON.stringify(formData))}`);
      }
      
      try {
        // Prepare data with proper type conversion, replacing undefined with null
        const params: SqlValue[] = [
          formData.first_name || null,
          formData.last_name || null,
          formData.street_address || null,
          formData.city || null,
          formData.state_province || null,
          formData.postal_code || null,
          formData.country || null,
          formData.email || null,
          formData.phone || null
        ];

        db.run(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, params);
        
        // Export database to disk
        const data = db.export();
        fs.writeFileSync(path.join(__dirname, '../data/submissions.sqlite'), Buffer.from(data));
        
        res.redirect('/thank-you');
      } catch (dbError) {
        console.error('Database error:', dbError);
        errors.push({ field: 'general', message: 'A database error occurred. Please try again.' });
        return res.redirect(`/?errors=${encodeURIComponent(JSON.stringify(errors))}&formData=${encodeURIComponent(JSON.stringify(formData))}`);
      }
    });

    app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', { 
        title: 'Thank You!'
      });
    });

    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('Received SIGTERM, shutting down gracefully');
      server.close(() => {
        db.close();
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(console.error);