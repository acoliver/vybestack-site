import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../db/schema.sql');

// Define proper type for sql.js parameters
export type SqlValue = string | number | Uint8Array | null;
export type BindParams = readonly SqlValue[] | { readonly [key: string]: SqlValue };

// Define Database interface with proper types
interface Database {
  run: (query: string, params?: BindParams) => void;
  export: () => Uint8Array;
  close: () => void;
}

export default async function initDatabase(): Promise<Database> {
  try {
    // Initialize sql.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        // For sql.js, the WASM file will be loaded from node_modules
        return path.join(__dirname, `../node_modules/sql.js/dist/${file}`);
      }
    });

    let db: Database;

    // Check if database file exists
    if (fs.existsSync(DB_PATH)) {
      // Load existing database
      const data = fs.readFileSync(DB_PATH);
      db = new SQL.Database(data);
      console.log('Database loaded from disk');
    } else {
      // Create new database
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db = new SQL.Database();
      db.run(schema);
      
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Save new database to disk
      const exportData = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(exportData));
      console.log('New database created and saved to disk');
    }

    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}