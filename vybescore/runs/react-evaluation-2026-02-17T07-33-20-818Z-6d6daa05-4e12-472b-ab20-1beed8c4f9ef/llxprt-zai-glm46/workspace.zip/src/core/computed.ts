/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store observers that depend on this computed value
  const dependentObservers = new Set<Observer<unknown>>()
  
  // Return getter
  const getter = (): T => {
    // If this computed is being accessed by another observer,
    // register that observer as a dependent
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Only add if it's not this computed itself (avoid self-reference)
      if (activeObs !== o) {
        dependentObservers.add(activeObs as Observer<unknown>)
      }
    }
    
    return o.value!
  }
  
  // Override updateFn to handle recomputation and notification
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Recompute the value
    const result = originalUpdateFn(prevValue)
    
    // Update the cached value immediately
    o.value = result
    
    // Notify all observers that depend on this computed value
    for (const observer of dependentObservers) {
      updateObserver(observer as Observer<unknown>)
    }
    
    return result
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  return getter
}
