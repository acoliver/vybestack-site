/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Use a Set to track multiple observers
  const observers = new Set<Observer<unknown>>()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer to be notified of changes
      observers.add(observer as Observer<unknown>)
      // Also set the legacy observer field for backwards compatibility
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    const hasChanged = s.value !== nextValue
    s.value = nextValue
    
    // Notify all observers when value changes
    if (hasChanged) {
      for (const observer of observers) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    
    return s.value
  }

  return [read, write]
}
