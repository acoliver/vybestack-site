import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  hasNext, 
  total, 
  limit, 
  onPrevious, 
  onNext 
}: { 
  page: number; 
  hasNext: boolean; 
  total: number; 
  limit: number; 
  onPrevious: () => void; 
  onNext: () => void; 
}): JSX.Element {
  const totalPages = Math.ceil(total / limit);
  
  return (
    <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', marginTop: '1rem' }}>
      <button 
        onClick={onPrevious} 
        disabled={page <= 1}
        style={{ padding: '0.5rem 1rem' }}
      >
        Previous
      </button>
      
      <span>
        Page {page} of {totalPages}
      </span>
      
      <button 
        onClick={onNext} 
        disabled={!hasNext}
        style={{ padding: '0.5rem 1rem' }}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePrevious = (): void => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = (): void => {
    if (data?.hasNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  // Handle empty state
  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
        <PaginationControls 
          page={data.page}
          hasNext={data.hasNext}
          total={data.total}
          limit={data.limit}
          onPrevious={handlePrevious}
          onNext={handleNext}
        />
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        page={data.page}
        hasNext={data.hasNext}
        total={data.total}
        limit={data.limit}
        onPrevious={handlePrevious}
        onNext={handleNext}
      />
    </section>
  );
}
