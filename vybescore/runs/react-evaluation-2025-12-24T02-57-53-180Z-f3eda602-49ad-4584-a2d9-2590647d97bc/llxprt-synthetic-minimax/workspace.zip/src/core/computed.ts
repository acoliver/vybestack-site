/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  registerDependency,
  notifyDependents,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
    isComputed: true,
  }
  
  // Initially evaluate to establish dependencies
  updateObserver(observer)
  
  const getter = (): T => {
    // Re-evaluate the computed value when called
    const previousValue = observer.value
    console.log(`Computed '${observer.name || 'unnamed'}' evaluating, previous: ${previousValue}`)
    
    // Set this computed observer as active during evaluation so its dependencies
    // get properly tracked
    const previous = getActiveObserver()
    setActiveObserver(observer)
    try {
      updateObserver(observer)
    } finally {
      setActiveObserver(previous)
    }
    
    console.log(`Computed '${observer.name || 'unnamed'}' evaluated to: ${observer.value}, has ${observer.dependents.size} dependents`)
    
    // If the value changed, notify dependents
    if (previousValue !== observer.value) {
      console.log(`Computed '${observer.name || 'unnamed'}' value changed, notifying dependents`)
      notifyDependents(observer)
    }
    
    // Register this computed as a dependent of any currently active observer
    // This handles the case where something is reading this computed value
    const currentActive = getActiveObserver()
    if (currentActive) {
      console.log(`Computed '${observer.name || 'unnamed'}' registering as dependent of ${currentActive.name || 'unnamed'}`)
      registerDependency(observer, currentActive)
    }
    
    return observer.value!
  }
  
  return getter
}
