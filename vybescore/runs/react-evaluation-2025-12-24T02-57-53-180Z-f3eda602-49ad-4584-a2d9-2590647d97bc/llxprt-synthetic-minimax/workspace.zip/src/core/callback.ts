/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set(),
    name: 'callback',
  }
  
  // Set this callback as the active observer so it can establish dependencies
  console.log('Creating callback, setting as active observer')
  const previous = getActiveObserver()
  setActiveObserver(observer)
  try {
    // Execute the callback to establish dependencies
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
  
  return () => {
    // Remove all dependencies for this observer
    console.log('Unsubscribing callback, removing dependencies')
    observer.dependents.clear()
    observer.updateFn = () => value!
  }
}
