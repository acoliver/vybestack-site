/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  SubjectR,
  ObserverR,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    dependents: new Set(),
    value,
    equalFn: typeof equal === 'boolean' 
      ? (_a: T, _b: T) => equal
      : equal,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this input as a dependency of the active observer
      console.log(`Input '${s.name || 'unnamed'}' registering dependency on observer ${observer.name || 'unnamed'}`)
      registerDependency(observer, s as SubjectR)
    }
    console.log(`Input '${s.name || 'unnamed'}' read, value: ${s.value}, has ${s.dependents.size} dependents`)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (shouldUpdate) {
      console.log(`Input '${s.name || 'unnamed'}' changing from ${s.value} to ${nextValue}`)
      s.value = nextValue
      // Notify all dependents that this input has changed
      notifyDependents(s as any)
    }
    return s.value
  }

  return [read, write]
}
