/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  dependents: Set<ObserverR>
  dispose?: () => void
  isComputed?: boolean
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Observer<T> extends ObserverR, ObserverV<T> {}

export interface SubjectR {
  name?: string
  dependents: Set<ObserverR>
}

export interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
}

export interface Subject<T> extends SubjectR, SubjectV<T> {}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function registerDependency(observer: ObserverR, subject: SubjectR): void {
  // When an observer reads from a subject, it becomes dependent on that subject
  subject.dependents.add(observer)
}

export function unregisterDependency(observer: ObserverR, subject: SubjectR): void {
  subject.dependents.delete(observer)
}

export function notifyDependents(subject: SubjectR): void {
  console.log(`notifyDependents called on ${subject.name || 'unnamed'} with ${subject.dependents.size} dependents`)
  // Create a copy of the dependents set to avoid issues with modification during iteration
  const dependentsToNotify = new Set(subject.dependents)
  
  for (const dependent of dependentsToNotify) {
    console.log(`Notifying dependent of ${subject.name || 'unnamed'}: ${dependent.name || 'unnamed'}`)
    if ('updateFn' in dependent) {
      const observerT = dependent as Observer<unknown>
      const previous = activeObserver
      activeObserver = dependent
      try {
        const oldValue = observerT.value
        console.log(`  Updating dependent ${dependent.name || 'unnamed'}, old value: ${oldValue}`)
        observerT.value = observerT.updateFn(observerT.value)
        console.log(`  Dependent ${dependent.name || 'unnamed'} new value: ${observerT.value}`)
        
        // Always notify dependents of computed values, and notify others if value changed
        if (dependent.isComputed) {
          console.log(`  ${dependent.name || 'unnamed'} is computed, checking for dependents`)
          if (dependent.dependents.size > 0) {
            notifyDependents(dependent)
          } else {
            console.log(`  No dependents to notify for computed ${dependent.name || 'unnamed'}`)
          }
        } else if (oldValue !== observerT.value) {
          console.log(`  ${dependent.name || 'unnamed'} value changed, checking for dependents`)
          if (dependent.dependents.size > 0) {
            notifyDependents(dependent)
          }
        }
      } finally {
        activeObserver = previous
      }
    }
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}
