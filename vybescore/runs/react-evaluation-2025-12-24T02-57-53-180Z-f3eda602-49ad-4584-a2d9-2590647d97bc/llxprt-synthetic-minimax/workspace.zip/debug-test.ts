import { createInput, createComputed, createCallback } from './src/index.js'

// Simple debug test to understand what's happening
console.log('=== DEBUG TEST ===')

const [input, setInput] = createInput(1)
console.log('Input created with value:', input())

const output = createComputed(() => {
  const value = input()
  console.log('Computed function called with input value:', value)
  return value + 1
}, undefined, undefined, { name: 'output-computed' })
console.log('Computed created, initial value:', output())

let callbackCount = 0
const unsubscribe = createCallback(() => {
  callbackCount++
  const value = output()
  console.log(`Callback #${callbackCount} executed, output value:`, value)
})

console.log('Callback created')
console.log('Initial callback count:', callbackCount)

// Let's manually check the dependencies
console.log('=== DEPENDENCY CHECK ===')
// This is internal API, but let's see what's there
if ((input as any).__dependents) {
  console.log('Input dependents:', (input as any).__dependents.size)
}
console.log('=== END DEPENDENCY CHECK ===')

console.log('Changing input to 3...')
setInput(3)
console.log('Input after change:', input())
console.log('Output after change:', output())
console.log('Final callback count:', callbackCount)

console.log('=== END DEBUG ===')