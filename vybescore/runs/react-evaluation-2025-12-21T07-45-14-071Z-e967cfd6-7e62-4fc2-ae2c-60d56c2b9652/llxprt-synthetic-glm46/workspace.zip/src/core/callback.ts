/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, setCurrentObserver, CallbackObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  fn: () => void,
  _value?: T
): UnsubscribeFn {
  const observer = new CallbackObserver(fn)
  
  const oldObserver = setCurrentObserver(observer)
  try {
    observer.update() // Initial execution to track dependencies
  } finally {
    setCurrentObserver(oldObserver)
  }
  
  return () => {
    observer.active = false
  }
}
