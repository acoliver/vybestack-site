/**
 * Computed closure implementation for derived values.
 */

import { 
  type GetterFn, 
  ComputedCell,
  type EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  compute: () => T,
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const cell = new ComputedCell<T>(compute)
  cell.get() // Initial computation
  return () => cell.get()
}
