/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  ReactiveCell,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> = 
    equal === false ? () => false : 
    equal === true || equal === undefined ? Object.is : 
    typeof equal === 'function' ? equal : 
    Object.is

  const cell = new ReactiveCell(value, equalFn)
  
  const getter = () => cell.get()
  const setter = (value: T) => {
    cell.set(value)
    return value
  }
  
  return [getter, setter]
}
