/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string
}

export interface IReactiveCell {
  getUnknown(): unknown
  setUnknown(value: unknown): void
}

export interface Observer {
  update(): void
  active: boolean
  dependencies?: Set<IReactiveCell>
}

export class ReactiveCell<T> implements IReactiveCell {
  private value: T
  private equalFn: EqualFn<T>
  private observers = new Set<Observer>()
  
  constructor(value: T, equalFn?: EqualFn<T>) {
    this.value = value
    this.equalFn = equalFn || Object.is
  }
  
  get(): T {
    if (currentObserver) {
      this.observers.add(currentObserver)
      // Track the cell
      if (!currentObserver.dependencies) {
        currentObserver.dependencies = new Set()
      }
      currentObserver.dependencies.add(this)
    }
    return this.value
  }
  
  set(value: T): void {
    if (this.equalFn(this.value, value)) return
    
    this.value = value
    this.notify()
  }
  
  // Implementation for IReactiveCell
  getUnknown(): unknown {
    return this.get()
  }
  
  setUnknown(value: unknown): void {
    this.set(value as T)
  }
  
  private notify(): void {
    // Notify all observers (computed cells)
    this.observers.forEach(observer => {
      if (observer.active) {
        observer.update()
      }
    })
  }
}

export class ComputedCell<T> implements Observer {
  private value?: T
  private compute: () => T
  private observers = new Set<Observer>()
  dependencies = new Set<IReactiveCell>()
  private dirty = true
  active = true
  
  constructor(compute: () => T) {
    this.compute = compute
  }
  
  get(): T {
    if (this.dirty) {
      this.recompute()
    }
    
    if (currentObserver) {
      this.observers.add(currentObserver)
    }
    
    return this.value!
  }
  
  private recompute(): void {
    setCurrentObserver(this)
    this.dependencies.clear()
    try {
      this.value = this.compute()
      this.dirty = false
    } finally {
      setCurrentObserver(null)
    }
  }
  
  update(): void {
    // When a dependency updates, mark this as dirty and recompute
    this.dirty = true
    this.recompute()
    
    // Notify my observers
    this.notify()
  }
  
  private notify(): void {
    this.observers.forEach(observer => {
      if (observer.active) {
        observer.update()
      }
    })
  }
}

export class CallbackObserver implements Observer {
  active = true
  
  constructor(private fn: () => void) {}
  
  update(): void {
    if (this.active) {
      this.fn()
    }
  }
}

let currentObserver: Observer | null = null

export function getCurrentObserver(): Observer | null {
  return currentObserver
}

export function setCurrentObserver(observer: Observer | null): Observer | null {
  const old = currentObserver
  currentObserver = observer
  return old
}
