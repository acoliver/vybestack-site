import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing callbacks can be added and removed ===')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 called with:', output())
  values1.push(output())
})

const values2 = []
createCallback(() => {
  console.log('Callback 2 called with:', output())
  values2.push(output())
})

console.log('Before setInput(31): values1:', values1, 'values2:', values2)
setInput(31)
console.log('After setInput(31): values1:', values1, 'values2:', values2)

unsubscribe1()
console.log('After unsubscribe:', values1.length, values2.length)

setInput(41)
console.log('After setInput(41): values1:', values1, 'values2:', values2)

console.log('Final lengths:', values1.length, values2.length)
console.log('Test result: values2.length > values1.length?', values2.length > values1.length)