import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing compute cells fire callbacks ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
const callback = createCallback(() => {
  console.log('Callback called, output is:', output())
  value = output()
})

console.log('Initial value:', value) // Should show initial execution
setInput(3)
console.log('After setInput(3):', value) // Should show updated value