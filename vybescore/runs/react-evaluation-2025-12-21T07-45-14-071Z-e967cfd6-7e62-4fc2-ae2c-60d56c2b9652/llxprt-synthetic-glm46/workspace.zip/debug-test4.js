import { ReactiveCell, ComputedCell, createInput, createComputed, createCallback } from './src/index.js'

// Debug ReactiveCell notifications
const originalNotify = ReactiveCell.prototype.notify
ReactiveCell.prototype.notify = function() {
  console.log('ReactiveCell notify called')
  return originalNotify.call(this)
}

// Debug ComputedCell invalidation
const originalInvalidate = ComputedCell.prototype.invalidate
ComputedCell.prototype.invalidate = function() {
  console.log('ComputedCell invalidate called')
  return originalInvalidate.call(this)
}

// Debug ComputedCell updates
const originalUpdate = ComputedCell.prototype.update
ComputedCell.prototype.update = function() {
  console.log('ComputedCell update called')
  return originalUpdate.call(this)
}

console.log('=== Testing compute cells can depend on other compute cells ===')

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('timesTwo recomputed:', input() * 2)
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('timesThirty recomputed:', input() * 30)
  return input() * 30
})
const sum = createComputed(() => {
  console.log('sum recomputed:', timesTwo() + timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum())
console.log('Setting input to 3...')
setInput(3)
console.log('After setInput(3):', sum())