const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 strings.
 * Accepts both padded and unpadded Base64 input for compatibility.
 */
export function decode(input: string): string {
  // Remove whitespace characters
  let cleaned = input.replace(/\s/g, '');
  
  // Allow empty strings
  if (cleaned === '') {
    return '';
  }
  
  // If no padding, add appropriate padding to make length divisible by 4
  if (!cleaned.includes('=')) {
    const paddingLength = (4 - (cleaned.length % 4)) % 4;
    cleaned += '='.repeat(paddingLength);
  }
  
  // Validate Base64 format
  if (!VALID_BASE64_REGEX.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }
  
  try {
    return Buffer.from(cleaned, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
