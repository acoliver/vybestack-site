export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (value.includes('..') || value.endsWith('.') || value.includes('_.') || value.endsWith('_')) {
    return false;
  }
  
  // Email regex pattern
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]*@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check domain doesn't contain underscores
  const domainPart = value.split('@')[1];
  if (domainPart?.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to check length
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for valid US numbers)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Check for valid US formats with separators
  const phoneRegex = /^(\+?1[\s.-]?)?(\([2-9][0-9][0-9]\)|[2-9][0-9][0-9])[\s.-]?[2-9][0-9][0-9][\s.-]?[0-9]{4}$/;
  
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  // Extract area code for validation
  const areaCodeMatch = value.match(/\(([2-9][0-9][0-9])\)|([2-9][0-9][0-9])/);
  if (areaCodeMatch) {
    const areaCode = areaCodeMatch[1] || areaCodeMatch[2];
    if (areaCode) {
      // Area code can't start with 0 or 1 (handled by regex above)
      return true;
    }
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to check structure
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentina phone validation regex patterns
  // Mobile format: +54 9 XX XXXX XXXX or 9 XX XXXX XXXX
  const mobileRegex = /^(\+54)?9(\d{2})\s?(\d{6,8})$/;
  
  // Landline format: +54 XX XXXX XXXX or 0XX XXXX XXXX
  const landlineRegex = /^(\+54)?0?(\d{2,4})\s?(\d{6,8})$/;
  
  // Try mobile format first
  let match = cleanValue.match(mobileRegex);
  if (match) {
    const areaCode = match[2];
    const subscriberNumber = match[3];
    
    // Area code must be 2 digits for mobile
    if (areaCode.length === 2 && /^[1-9]/.test(areaCode) && 
        subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      return true;
    }
  }
  
  // Try landline format
  match = cleanValue.match(landlineRegex);
  if (match) {
    const areaCode = match[2];
    const subscriberNumber = match[3];
    
    // Area code must be 2-4 digits, first digit 1-9
    if (areaCode.length >= 2 && areaCode.length <= 4 && /^[1-9]/.test(areaCode) && 
        subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for obviously invalid patterns
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols that shouldn't be in names
  if (/[<>{}[\]|`~!@#$%^&*()+=,;'"]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Must start with a letter
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that are too short or too long
  if (value.length < 2 || value.length > 50) {
    return false;
  }
  
  // Reject names with only special characters
  if (/^[\s'-]+$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to validate credit card using Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove all non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all spaces and dashes for validation
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Check for valid card number patterns and prefixes
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^5[1-5][0-9]{14}$/;
  const mastercard2Pattern = /^2[2-7][0-9]{14}$/;
  // American Express: starts with 34 or 37, length 15
  const amexPattern = /^3[47][0-9]{13}$/;
  
  if (!(visaPattern.test(cleanCard) || 
        mastercardPattern.test(cleanCard) || 
        mastercard2Pattern.test(cleanCard) || 
        amexPattern.test(cleanCard))) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanCard);
}
