/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match words starting with prefix
  const prefixRegex = new RegExp(`\\b${prefix}[\\w-]*\\b`, 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    const cleanWord = word.toLowerCase().replace(/[^\w-]/g, '');
    return !exceptions.some(exception => 
      exception.toLowerCase() === cleanWord
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at start of string
  // Pattern: digit followed by token
  const results: string[] = [];
  const pattern = new RegExp(`\\d${token}`, 'gi');
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    results.push(match[0]); // Include the digit and token
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()\-_=+[{\]}|;:'",<.>/?`~]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Look for patterns like "abab", "123123", etc.
  for (let i = 0; i < value.length - 3; i++) {
    const seq = value.substring(i, i + 4);
    if (seq.length === 4 && (seq[0] === seq[2] && seq[1] === seq[3])) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv6 patterns within the text (not just the entire value being IPv6)
  const ipv6Patterns = [
    // Look for IPv6 with shorthand notation
    /[0-9a-fA-F]*::[0-9a-fA-F]*/,
    
    // Standard IPv6 notation with colons
    /[0-9a-fA-F:]+:[0-9a-fA-F:]+/,
    
    // IPv6 in URLs or mixed text
    /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:/,
    
    // Common IPv6 shorthand patterns
    /::[0-9a-fA-F]+/,
    /[0-9a-fA-F]+::/
  ];
  
  // If it's a pure IPv4 address, return false
  const pureIPv4Regex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (pureIPv4Regex.test(value)) {
    return false;
  }
  
  // Test if any IPv6 pattern matches within the text
  return ipv6Patterns.some(pattern => pattern.test(value));
}
