/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences based on ending punctuation
  const sentences = text.split(/([.!?]+)\s*/).filter(s => s.trim().length > 0);
  
  let result = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    // Check if this is ending punctuation followed by next sentence
    if (i % 2 === 1) { // This is ending punctuation
      result += sentence;
      // Add exactly one space after sentence ending punctuation
      if (i + 1 < sentences.length) {
        result += ' ';
      }
      continue;
    }
    
    // Skip if this is just whitespace or ending punctuation
    if (/^\s*$/.test(sentence) || /^[.!?]+$/.test(sentence)) {
      continue;
    }
    
    // Capitalize first letter of sentence
    const capitalizedSentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    result += capitalizedSentence;
  }
  
  // Clean up extra spaces and ensure proper sentence separation
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match http/https URLs
  const urlRegex = /https?:\/\/[^\s<>"'()]+[^\s<>"'().,!?;']/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation while preserving valid URL characters
    return url.replace(/[.!?;,]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/([^/\s]+)([^\s]*)/gi, (match, host, path) => {
    // Check for query strings and specific file extensions properly
    const hasQueryString = path.includes('?');
    const hasFileExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    const hasCgiBin = path.includes('cgi-bin');
    const hasAmpersand = path.includes('&');
    const hasEquals = path.includes('=');
    
    let newHost = host;
    const newPath = path;
    
    // Only rewrite host if path starts with /docs/ and has no dynamic hints
    if (!hasQueryString && !hasFileExtensions && !hasCgiBin && !hasAmpersand && !hasEquals && path.startsWith('/docs/')) {
      // Rewrite host for docs paths
      newHost = 'docs.' + host;
    }
    
    return 'https://' + newHost + newPath;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Check for leap year if February
  if (month === 2 && day === 29) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return year.toString();
}
