import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        // Fixed: include page and limit in the query string
        const url = `/inventory?page=${encodeURIComponent(page)}&limit=${encodeURIComponent(limit)}`;
        const response = await fetch(url);
        
        if (!response.ok) {
          // Handle server validation errors properly
          if (response.status === 400) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Invalid request parameters');
          }
          throw new Error(`Request failed with status ${response.status}`);
        }
        
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    // Fixed: always trigger a new request when page or limit changes
    load();

    return () => {
      cancelled = true;
    };
  }, [page, limit]);

  return state;
}
