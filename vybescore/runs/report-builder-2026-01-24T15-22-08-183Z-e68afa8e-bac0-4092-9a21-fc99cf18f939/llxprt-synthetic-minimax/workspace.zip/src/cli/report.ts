#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { stdout } from 'process';
import { loadReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { CLIOptions } from '../types.js';

function parseArgs(args: string[]): CLIOptions {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[2];

  // Parse flags
  let format: CLIOptions['format'] | null = null;
  let output: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const nextArg = args[++i];
      if (!nextArg || nextArg.startsWith('--')) {
        throw new Error('--format requires a value');
      }

      if (nextArg === 'markdown' || nextArg === 'text') {
        format = nextArg;
      } else {
        throw new Error(`Unsupported format: ${nextArg}`);
      }
    } else if (arg === '--output') {
      const nextArg = args[++i];
      if (!nextArg || nextArg.startsWith('--')) {
        throw new Error('--output requires a value');
      }
      output = nextArg;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown flag: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format flag is required');
  }

  return {
    dataPath,
    format,
    output,
    includeTotals
  };
}

function main(): void {
  try {
    const options = parseArgs(process.argv);
    const reportData = loadReportData(options.dataPath);

    let output: string;

    if (options.format === 'markdown') {
      output = renderMarkdown(reportData, options.includeTotals);
    } else if (options.format === 'text') {
      output = renderText(reportData, options.includeTotals);
    } else {
      throw new Error(`Unsupported format: ${options.format}`);
    }

    if (options.output) {
      writeFileSync(options.output, output);
    } else {
      stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
