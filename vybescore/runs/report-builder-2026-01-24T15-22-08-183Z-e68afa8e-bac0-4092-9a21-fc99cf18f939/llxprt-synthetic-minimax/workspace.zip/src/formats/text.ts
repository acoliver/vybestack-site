import { ReportData } from '../types.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  let output = '';

  // Title
  output += `${data.title}\n\n`;

  // Summary
  output += `${data.summary}\n\n`;

  // Entries section
  output += `Entries:\n\n`;

  // Bullet list of entries
  for (const entry of data.entries) {
    const formattedAmount = formatAmount(entry.amount);
    output += `- ${entry.label}: $${formattedAmount}\n`;
  }

  // Total if requested
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = formatAmount(total);
    output += `\nTotal: $${formattedTotal}\n`;
  }

  return output;
}

function formatAmount(amount: number): string {
  return amount.toFixed(2);
}