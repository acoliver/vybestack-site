import { readFileSync } from 'fs';
import { ReportData } from './types.js';

export function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid input: data must be an object');
  }

  const objData = data as Record<string, unknown>;

  if (typeof objData.title !== 'string' || objData.title.trim() === '') {
    throw new Error('Invalid input: title must be a non-empty string');
  }

  if (typeof objData.summary !== 'string' || objData.summary.trim() === '') {
    throw new Error('Invalid input: summary must be a non-empty string');
  }

  if (!Array.isArray(objData.entries)) {
    throw new Error('Invalid input: entries must be an array');
  }

  if (objData.entries.length === 0) {
    throw new Error('Invalid input: entries must not be empty');
  }

  for (const entry of objData.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid input: each entry must be an object');
    }

    const objEntry = entry as Record<string, unknown>;

    if (typeof objEntry.label !== 'string' || objEntry.label.trim() === '') {
      throw new Error('Invalid input: each entry label must be a non-empty string');
    }

    if (typeof objEntry.amount !== 'number' || isNaN(objEntry.amount)) {
      throw new Error('Invalid input: each entry amount must be a number');
    }
  }

  return true;
}

export function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    if (error instanceof Error) {
      throw new Error(`${filePath}: ${error.message}`);
    }
    throw new Error(`Failed to load data from ${filePath}: ${error}`);
  }
}

export function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}