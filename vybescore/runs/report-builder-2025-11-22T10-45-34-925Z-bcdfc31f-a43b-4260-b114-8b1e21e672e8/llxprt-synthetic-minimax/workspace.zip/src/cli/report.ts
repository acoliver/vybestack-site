import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

const parseArgs = (args: string[]): ParsedArgs => {
  const parsed: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      parsed.format = args[++i] || '';
    } else if (arg === '--output') {
      parsed.output = args[++i] || '';
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // This should be the data file
      parsed.dataFile = arg;
    }
  }

  return parsed;
};

const validateArgs = (args: ParsedArgs): void => {
  if (!args.dataFile) {
    console.error('Error: Data file path is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Format is required (--format <format>)');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Unsupported format: ${args.format}`);
    process.exit(1);
  }
};

const loadReportData = (filePath: string): ReportData => {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing "title" field');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing "summary" field');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing "entries" field (must be an array)');
    }

    // Validate each entry
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Each entry must have a valid "label" field');
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry "${entry.label}" must have a valid "amount" field`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
    } else if (error instanceof Error && error.message.startsWith('Error:')) {
      console.error(error.message);
    } else {
      console.error(`Error: Failed to read or parse file "${filePath}": ${error}`);
    }
    process.exit(1);
  }
};

const main = (): void => {
  const args = parseArgs(process.argv);
  validateArgs(args);

  const data = loadReportData(args.dataFile);
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  let output: string;
  if (args.format === 'markdown') {
    output = renderMarkdown.format(data, options);
  } else if (args.format === 'text') {
    output = renderText.format(data, options);
  } else {
    console.error(`Unsupported format: ${args.format}`);
    process.exit(1);
  }

  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to file "${args.output}": ${error}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
};

main();