import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { DatabaseManager, type SubmissionData } from './database.js';
import { validateFormData, type FormData } from './validation.js';

const PORT = process.env.PORT || 3535;

const app = express();
const dbManager = new DatabaseManager();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve('public')));

app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'views'));

interface FormRequest extends Request {
  body: Partial<FormData>;
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    formData: {}
  });
});

app.post('/submit', async (req: FormRequest, res: Response, next: NextFunction) => {
  const errors = validateFormData(req.body);

  if (errors.length > 0) {
    res.status(400).render('form.ejs', {
      errors,
      formData: req.body
    });
    return;
  }

  const submission: SubmissionData = {
    firstName: req.body.firstName!,
    lastName: req.body.lastName!,
    streetAddress: req.body.streetAddress!,
    city: req.body.city!,
    stateProvince: req.body.stateProvince!,
    postalCode: req.body.postalCode!,
    country: req.body.country!,
    email: req.body.email!,
    phone: req.body.phone!
  };

  try {
    dbManager.insertSubmission(submission);
    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you.ejs');
});

app.use((err: Error, _req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).render('form.ejs', {
    errors: [{ field: 'server', message: 'An unexpected error occurred. Please try again.' }],
    formData: {}
  });
});

let activeServer: import('http').Server | null = null;
let isShuttingDown = false;

async function startServer() {
  if (activeServer) {
    return activeServer;
  }

  if (isShuttingDown) {
    throw new Error('Server is shutting down');
  }

  await dbManager.initialize();

  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  }).on('error', (error: Error & { code?: string }) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} is already in use`);
      // Don't throw during vitest cleanup
      if (!process.env.VITEST) {
        throw error;
      }
    } else {
      throw error;
    }
  });

  activeServer = server;
  return server;
}

function shutdownServer(server: import('http').Server): void {
  if (isShuttingDown) {
    return;
  }
  
  isShuttingDown = true;
  
  server.close(() => {
    dbManager.close();
    console.log('Server shut down gracefully');
  });
  activeServer = null;
}

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down...');
  if (activeServer && !isShuttingDown) {
    shutdownServer(activeServer);
  }
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error: Error) => {
    // Ignore EADDRINUSE errors during vitest cleanup
    if ('code' in error && error.code !== 'EADDRINUSE') {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  });
}

export { startServer, shutdownServer, app };
