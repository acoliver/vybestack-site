export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!isValidPostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code must contain only letters, digits, and spaces'
    });
  }

  if (!data.country || data.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!isValidEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!isValidPhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +'
    });
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function isValidPhone(phone: string): boolean {
  const trimmed = phone.trim();
  const phoneRegex = /^[+]?\d[\d\s()-]*$/;
  return phoneRegex.test(trimmed);
}

function isValidPostalCode(postalCode: string): boolean {
  const trimmed = postalCode.trim();
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(trimmed);
}
