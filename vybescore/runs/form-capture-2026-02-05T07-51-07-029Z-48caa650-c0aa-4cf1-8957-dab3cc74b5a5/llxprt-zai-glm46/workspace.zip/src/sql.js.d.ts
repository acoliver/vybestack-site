declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export class Database {
    constructor(data?: ArrayLike<number> | Buffer | null);
    
    run(sql: string, params?: unknown[]): unknown;
    exec(sql: string): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export class Statement {
    run(values?: unknown[]): unknown;
    get(values?: unknown[]): unknown | undefined;
    all(values?: unknown[]): unknown[];
    free(): void;
  }

  export default function initSqlJs(config?: unknown): Promise<SqlJsStatic>;
}
