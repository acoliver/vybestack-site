import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, shutdownServer } from '../../src/server.js';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = await startServer();
});

afterAll(() => {
  if (server) {
    shutdownServer(server);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('displays validation errors for invalid data', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone'
      });

    expect([200, 400]).toContain(response.status);
    
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBeGreaterThan(0);
    expect($('input[name="email"]')).toHaveLength(1);
  });

  it('persists submission and redirects to thank-you page', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const submission = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(server)
      .post('/submit')
      .send(submission);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    expect(fs.existsSync(dbPath)).toBe(true);

    const thankYouResponse = await request(server).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank You');
  });

  it('accepts international phone formats', async () => {
    const internationalPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567'
    ];

    for (const phone of internationalPhones) {
      const response = await request(server)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone
        });

      expect(response.status).toBe(302);
    }
  });

  it('accepts international postal codes', async () => {
    const internationalPostalCodes = [
      'SW1A 1AA',
      'C1000',
      'B1675',
      '12345'
    ];

    for (const postalCode of internationalPostalCodes) {
      const response = await request(server)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode,
          country: 'Test Country',
          email: 'test@example.com',
          phone: '+1 555 123 4567'
        });

      expect(response.status).toBe(302);
    }
  });

  it('redisplay form with submitted values on validation error', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: '',
        email: 'john@example.com',
        phone: 'invalid!'
      });

    expect([200, 400]).toContain(response.status);
    
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('John');
    expect($('input[name="email"]').val()).toBe('john@example.com');
    expect($('.error-list').length).toBeGreaterThan(0);
  });
});
