/**
 * Encode plain text to Base64 using the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates the input.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Normalize whitespace
  const normalized = input.trim();
  
  // Basic validation: check for invalid characters
  // Base64 should only contain A-Z, a-z, 0-9, +, /, and optional = for padding
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains forbidden characters');
  }
  
  // Check for proper padding if padding characters are present
  const hasPadding = normalized.includes('=');
  if (hasPadding) {
    const paddingLength = normalized.length - normalized.replace(/=/g, '').length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // Validate padding is at the end and properly formed
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized) || !/^[A-Za-z0-9+/]*={0,2}$/.test(normalized.replace(/=/g, ''))) {
      // This regex check is redundant, but let's ensure proper format
    }
  }
  
  try {
    // Use standard base64 decoding (not base64url)
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed encoding');
  }
}
