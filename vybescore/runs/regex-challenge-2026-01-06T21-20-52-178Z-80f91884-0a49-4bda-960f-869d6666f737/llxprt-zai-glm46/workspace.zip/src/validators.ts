export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation using regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for specific invalid patterns
  if (/\.\./.test(value)) return false; // Double dots
  if (/^\.|\.$|@\./.test(value)) return false; // Leading/trailing dots, or @ followed immediately by dot
  if (/_/.test(value.split('@')[1])) return false; // Underscore in domain
  if (!/^[^@]+@[^@]+\.[^@]+$/.test(value)) return false; // Basic structure
  
  return emailRegex.test(value);
}

/**
 * US phone number validation supporting common separators and optional +1.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 prefix
  const hasCountryCode = digitsOnly.startsWith('1');
  const phoneNumber = hasCountryCode ? digitsOnly.slice(1) : digitsOnly;
  
  // Must have exactly 10 digits for US number
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if it matches one of the valid patterns
  const normalizedValue = value.trim();
  
  // Check if it matches any valid format with or without +1
  if (/^\+1/.test(normalizedValue)) {
    const withoutPrefix = normalizedValue.slice(2).trim();
    if (/^\d{10}$/.test(withoutPrefix.replace(/\D/g, '')) && 
        withoutPrefix.replace(/\D/g, '').length === 10) {
      const areaCodeCheck = withoutPrefix.replace(/\D/g, '').slice(0, 3);
      if (areaCodeCheck[0] !== '0' && areaCodeCheck[0] !== '1') {
        return true;
      }
    }
  }
  
  // Check standard formats
  if (!/^\+?1[\s-]?\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})$/.test(value)) {
    // Try without country code
    if (!/^\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})$/.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Argentine phone number validation covering mobile/landline formats.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone patterns:
  // 1. +54 9 XXX XXXX XXXX (mobile with country code)
  // 2. +54 XXX XXX XXXX (landline with country code)
  // 3. 0XXX XXX XXXX (without country code, must have trunk prefix 0)
  // 4. 0XXXXXXXXXX (compact format without country code)
  
  // Pattern with optional +54, optional mobile prefix 9, area code (2-4 digits, starts with 1-9), subscriber (6-8 digits)
  const withCountryCode = /^\+54\s?9?\s?(\d{2,4})[\s-]?(\d{6,8})$/;
  const withoutCountryCode = /^0(\d{2,4})[\s-]?(\d{6,8})$/;
  
  const matchWithCountry = cleaned.match(withCountryCode);
  const matchWithoutCountry = cleaned.match(withoutCountryCode);
  
  if (matchWithCountry) {
    const [, areaCode, subscriberNumber] = matchWithCountry;
    // Area code must be 2-4 digits, leading digit 1-9
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
    // Subscriber number must be 6-8 digits
    if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
    return true;
  }
  
  if (matchWithoutCountry) {
    const [, areaCode, subscriberNumber] = matchWithoutCountry;
    // Area code must be 2-4 digits, leading digit 1-9
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
    // Subscriber number must be 6-8 digits
    if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
    return true;
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and other invalid characters
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}'\s-]*[\p{L}\p{M}]$/u;
  
  // Must have at least 2 characters
  if (value.trim().length < 2) return false;
  
  // Check for invalid characters (digits, symbols like Æ, numbers)
  if (/\d/.test(value)) return false;
  if (/[^\p{L}\p{M}'\s-]/u.test(value)) return false;
  
  return nameRegex.test(value.trim());
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type
  const isValidPrefix = visaRegex.test(cleaned) || 
                       mastercardRegex.test(cleaned) || 
                       amexRegex.test(cleaned);
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
