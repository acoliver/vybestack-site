/**
 * Capitalize the first character of each sentence.
 * Capitalizes after .?! and inserts exactly one space between sentences.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing (before capital letters)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Capitalize first character of the string
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence terminators .!? (but avoid abbreviations)
  // We'll use a regex that looks for .?! followed by space and a lowercase letter
  normalized = normalized.replace(/([.!?])\s+([a-z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Removes trailing punctuation from URLs.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. without protocol
  const urlPattern = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https://.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s<>"']*)/gi;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHints = /\/cgi-bin\/|[?&=]|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)(\/|$)/i.test(path);
    
    let newHost = host;
    
    // Only rewrite host if it's a docs path AND no dynamic hints
    if (isDocsPath && !hasDynamicHints) {
      newHost = 'docs.' + host;
    }
    
    return newProtocol + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
