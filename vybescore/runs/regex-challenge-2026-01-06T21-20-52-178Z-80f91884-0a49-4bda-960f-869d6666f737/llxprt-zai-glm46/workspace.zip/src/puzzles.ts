/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const found = [...new Set(matches)] // Remove duplicates
    .filter(word => !exceptionsLower.includes(word.toLowerCase()));
  
  return found;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookbehind to ensure token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to match digit + token only when token appears after a digit
  // and not at the beginning of the string
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat
  const repeatPattern = /(.{2,4})\1+/;
  if (repeatPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * IPv6 addresses contain colons and hexadecimal digits, can use :: shorthand.
 */
export function containsIPv6(value: string): boolean {
  // First, filter out pure IPv4 addresses
  // IPv4: 4 groups of 1-3 digits separated by dots
  const pureIPv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (pureIPv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check if the value contains an IPv6 address
  // Look for IPv6 patterns anywhere in the string
  const testValue = value.trim();
  
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand
  const shorthandIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // Check if value matches any IPv6 pattern
  return fullIPv6.test(testValue) || shorthandIPv6.test(testValue);
}
