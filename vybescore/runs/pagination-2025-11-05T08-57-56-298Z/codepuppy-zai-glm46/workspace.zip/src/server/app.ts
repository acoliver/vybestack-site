import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Convert string parameters to numbers or undefined
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      const parsed = Number(pageParam);
      if (isNaN(parsed)) {
        return res.status(400).json({ error: 'Page parameter must be a valid number' });
      }
      page = parsed;
    }

    if (limitParam !== undefined) {
      const parsed = Number(limitParam);
      if (isNaN(parsed)) {
        return res.status(400).json({ error: 'Limit parameter must be a valid number' });
      }
      limit = parsed;
    }

    // Validate pagination parameters
    const validation = validatePaginationParams(page, limit);
    if ('error' in validation) {
      return res.status(400).json({ error: validation.error });
    }

    const payload = listInventory(db, validation);
    res.json(payload);
  });

  return app;
}