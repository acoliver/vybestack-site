import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function validatePaginationParams(page?: number, limit?: number): { page: number; limit: number } | { error: string } {
  // Validate page parameter
  if (page !== undefined) {
    if (typeof page !== 'number' || isNaN(page)) {
      return { error: 'Page parameter must be a valid number' };
    }
    if (page <= 0 || !Number.isInteger(page)) {
      return { error: 'Page parameter must be a positive integer' };
    }
    if (page > 1000) {
      return { error: 'Page parameter cannot exceed 1000' };
    }
  }

  // Validate limit parameter
  if (limit !== undefined) {
    if (typeof limit !== 'number' || isNaN(limit)) {
      return { error: 'Limit parameter must be a valid number' };
    }
    if (limit <= 0 || !Number.isInteger(limit)) {
      return { error: 'Limit parameter must be a positive integer' };
    }
    if (limit > MAX_LIMIT) {
      return { error: `Limit parameter cannot exceed ${MAX_LIMIT}` };
    }
  }

  const validatedPage = page && page > 0 ? Math.floor(page) : 1;
  const validatedLimit = limit && limit > 0 ? Math.floor(limit) : DEFAULT_LIMIT;

  return { page: validatedPage, limit: validatedLimit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // Fixed: offset should be (page - 1) * limit, not page * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = (page * limit) < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}