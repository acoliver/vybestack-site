import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination structure', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page', 1);
    expect(response.body).toHaveProperty('limit', 5);
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
  });

  it('accepts custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
  });

  it('returns correct items for page 2', async () => {
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    const response2 = await request(app).get('/inventory?page=2&limit=5');
    
    expect(response1.status).toBe(200);
    expect(response2.status).toBe(200);
    
    const page1Ids = response1.body.items.map((item: { id: number }) => item.id);
    const page2Ids = response2.body.items.map((item: { id: number }) => item.id);
    
    // Ensure no overlap between pages
    const intersection = page1Ids.filter((id: number) => page2Ids.includes(id));
    expect(intersection).toHaveLength(0);
    
    // Ensure page 2 items come after page 1 items
    const maxPage1Id = Math.max(...page1Ids);
    const minPage2Id = Math.min(...page2Ids);
    expect(minPage2Id).toBeGreaterThan(maxPage1Id);
  });

  it('validates non-numeric page parameter', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page must be a valid number');
  });

  it('validates negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page must be greater than 0');
  });

  it('validates zero page parameter', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page must be greater than 0');
  });

  it('validates excessive page parameter', async () => {
    const response = await request(app).get('/inventory?page=1001');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page must be less than or equal to 1000');
  });

  it('validates non-numeric limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit must be a valid number');
  });

  it('validates negative limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit must be greater than 0');
  });

  it('validates zero limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit must be greater than 0');
  });

  it('validates excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit must be less than or equal to 100');
  });

  it('returns empty items list for page beyond available data', async () => {
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.page).toBe(100);
    expect(response.body.hasNext).toBe(false);
  });
});
