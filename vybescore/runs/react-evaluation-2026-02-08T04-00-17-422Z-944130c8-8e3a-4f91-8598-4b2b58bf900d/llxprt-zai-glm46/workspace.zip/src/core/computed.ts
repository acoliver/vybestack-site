/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track observers for this computed value
  const observers: Set<ObserverR> = new Set()
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Track that this computed value is being observed
      o.observer = observer
      observers.add(observer)
    }
    return o.value!
  }
  
  // Wrap updateObserver to also notify our observers when we update
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // First compute our new value
    const result = originalUpdateFn(prevValue)
    // Update the value BEFORE notifying observers
    o.value = result
    // Then notify all our observers that we've changed
    // Use Array.from to avoid issues if the set is modified during iteration
    const observersArray = Array.from(observers)
    for (const obs of observersArray) {
      // We know that obs is actually a full Observer<T> because we only add Observer<T> objects
      // to this set (via getActiveObserver() during updateObserver calls)
      updateObserver(obs as Observer<unknown>)
    }
    return result
  }
  
  return getter
}
