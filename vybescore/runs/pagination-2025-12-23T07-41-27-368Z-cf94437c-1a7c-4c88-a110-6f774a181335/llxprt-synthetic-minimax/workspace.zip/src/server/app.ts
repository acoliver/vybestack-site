import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate query parameters
    const errors: string[] = [];

    // Validate page parameter
    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (isNaN(page) || page <= 0 || !Number.isInteger(page)) {
        errors.push('page');
      } else if (page > 1000000) {
        errors.push('page');
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (isNaN(limit) || limit <= 0 || !Number.isInteger(limit)) {
        errors.push('limit');
      } else if (limit > 100) {
        errors.push('limit');
      }
    }

    // Return validation errors
    if (errors.length > 0) {
      const errorMsg = `Invalid query parameters: ${errors.join(', ')}`;
      return res.status(400).json({ 
        error: errorMsg
      });
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
