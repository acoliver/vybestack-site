/**
 * Find words that begin with the given prefix, excluding those in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a set of exceptions for efficient lookup (case insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  // Find all word boundaries
  const words = text.match(/\b\w+\b/g) || [];
  
  // Filter words that start with the prefix and aren't in exceptions
  return words.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerPrefix = prefix.toLowerCase();
    
    return lowerWord.startsWith(lowerPrefix) && !exceptionSet.has(lowerWord);
  });
}

/**
 * Find all occurrences of token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Match digit followed by token at word boundary and return the full match
  const escapedToken = escapeRegExp(token);
  const pattern = new RegExp(`\\b\\d${escapedToken}(?!\\w)`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Check if a password meets strength requirements:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must have at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like "abab", "123123", etc.)
  // Split the password into halves and check if they're equal
  const halfLength = Math.floor(value.length / 2);
  const firstHalf = value.substring(0, halfLength);
  const secondHalf = value.substring(halfLength, halfLength * 2);
  
  // If the password consists of two identical consecutive parts it's weak
  if (firstHalf === secondHalf) return false;
  
  // Also check for repeating characters 3 or more times in a row
  if (/(.)\1{2,}/.test(value)) return false;
  
  return true;
}

/**
 * Detect if the string contains an IPv6 address.
 * Should not detect IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 pattern (including shorthand ::)
  // This is complex, so we'll use separate patterns for different formats
  const patterns = [
    // Full IPv6 with all 8 groups
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/g,
    // IPv6 with :: (compressed zeros)
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/g,
    /\b:(?:[0-9a-fA-F]{1,4}:){1,7}\b/g,
    // IPv6 with mixed :: and groups
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b/g,
    /\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b/g,
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b/g,
    /\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b/g,
    /\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b/g,
    /\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\b/g,
    /\b:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)\b/g,
    // IPv4-mapped IPv6 (should count as IPv6)
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}\b/g
  ];
  
  // Check for any IPv6 matches
  let hasIPv6 = false;
  for (const pattern of patterns) {
    const matches = value.match(pattern);
    if (matches) {
      hasIPv6 = true;
      break;
    }
  }
  
  return hasIPv6;
}

/**
 * Helper function to escape special regex characters in a string
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}