/**
 * Capitalize the first character of each sentence.
 * Sentences are separated by . ? or ! punctuation.
 * Insert exactly one space between sentences and collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize multiple spaces to a single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Add space after sentence-ending punctuation if missing
  normalized = normalized.replace(/([.?!])([A-Z])/g, '$1 $2');
  
  // Split into sentences, capitalize first letter of each (if it's a letter),
  // and join back with single space
  return normalized
    .split(/([.?!]\s*)/)
    .map((sentence, index) => {
      // Even indexes are the actual sentences, odd indexes are the punctuation + space
      if (index % 2 === 0 && sentence.trim()) {
        // For the first sentence, just capitalize the first letter
        // For subsequent sentences, they should already have a space after punctuation
        return sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
      return sentence;
    })
    .join('');
}

/**
 * Extract all URLs from the given text.
 * Returns URLs without trailing punctuation like commas or periods.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regex to match URLs with http/https/ftp schemes or www
  const urlRegex = /\b((https?|ftp):\/\/[^\s/$.?#].[^\s]*|www\.[^\s/$.?#].[^\s]*)/gi;
  
  // Find all matches, then strip trailing punctuation
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => url.replace(/[.,/#!$%^&*;:{}=\-_`~()]+$/, ''));
}

/**
 * Replace http:// schemes with https:// while leaving existing
 * secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace only http:// that's not preceded by a word character
  // This ensures we don't match https:// (we don't want to add another 's')
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs according to rules:
 * 1. Always upgrade scheme to https://
 * 2. When path begins with /docs/, rewrite host to docs.example.com
 * 3. Skip host rewrite when path contains cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Match URLs with http or https scheme
  return text.replace(
    /\b(https?):\/\/([^/]+)(\/[^\s]*)?/gi,
    (match, scheme, host, path = '') => {
      const httpsUrl = match.replace(/^https?:/, 'https:');
      
      // Check if we should skip host rewrite
      const skipHostRewrite = 
        path.includes('/cgi-bin') ||
        path.includes('?') ||
        path.includes('&') ||
        /\/(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      // If path starts with /docs/ and we're not skipping the rewrite
      if (path.startsWith('/docs/') && !skipHostRewrite) {
        return httpsUrl.replace(/https:\/\/[^/]+/, 'https://docs.example.com');
      }
      
      return httpsUrl;
    }
  );
}

/**
 * Extract the year from a mm/dd/yyyy format.
 * Returns N/A if the format is wrong or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // More specific validation for days per month (ignoring leap years for simplicity)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}