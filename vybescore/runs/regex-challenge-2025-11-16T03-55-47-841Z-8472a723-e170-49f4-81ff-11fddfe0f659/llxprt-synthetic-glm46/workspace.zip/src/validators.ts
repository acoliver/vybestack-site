export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation supporting aliases, various domain levels,
 * and rejecting common invalid patterns.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+([a-zA-Z0-9-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots
  if (/\.\./.test(value)) return false;
  
  // No trailing dots
  if (value.endsWith('.')) return false;
  
  // No underscores in domain (only allowed in local part)
  const [, domain] = value.split('@');
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * US phone number validation supporting common formats:
 * - (212) 555-7890
 * - 212-555-7890
 * - 2125557890
 * - Optional +1 prefix
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const phoneDigits = value.replace(/\D/g, '');
  
  // Remove US country code if present
  const digits = phoneDigits.startsWith('1') ? phoneDigits.substring(1) : phoneDigits;
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) return false;
  
  // Area code should not start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (/^0|^1/.test(areaCode)) return false;
  
  // Validate the full format with separators
  const phoneRegex = /^(\+?1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Argentine phone number validation supporting:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country code and area code
 * - Area codes: 2-4 digits, leading digit 1-9
 * - Subscriber numbers: 6-8 digits
 * - Allow spaces and hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[ -]/g, '');
  
  // Pattern 1: Mobile with country code (+54 9 [areaCode] [subscriberNumber])
  // Example: +54 9 11 1234 5678 -> +5491112345678
  let match = cleaned.match(/^\+549(\d{2,4})(\d{6,8})$/);
  if (match && /^[1-9]\d{1,3}$/.test(match[1]) && /^\d{6,8}$/.test(match[2])) {
    return true;
  }
  
  // Pattern 2: Landline with country code (+54 [areaCode] [subscriberNumber])
  // Example: +54 341 123 4567 -> +543411234567
  match = cleaned.match(/^\+54(\d{2,4})(\d{6,8})$/);
  if (match && /^[1-9]\d{1,3}$/.test(match[1]) && /^\d{6,8}$/.test(match[2])) {
    return true;
  }
  
  // Pattern 3: With trunk prefix but no country code (0 [areaCode] [subscriberNumber])
  // Example: 011 1234 5678 -> 01112345678
  match = cleaned.match(/^0(\d{2,4})(\d{6,8})$/);
  if (match && /^[1-9]\d{1,3}$/.test(match[1]) && /^\d{6,8}$/.test(match[2])) {
    return true;
  }
  
  return false;
}

/**
 * Name validation allowing:
 * - Unicode letters and accents
 * - Apostrophes and hyphens
 * - Spaces between name parts
 * - Rejects digits, symbols, and weird names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Check for digits first (quick reject)
  if (/\d/.test(value)) return false;
  
  // Check for unusual symbols that aren't allowed in normal names
  if (/[^\p{L}\s'-]/u.test(value)) return false;
  
  // Basic structure: sequences of name parts separated by spaces
  // Each part can contain letters, optionally with apostrophes or hyphens
  const namePartRegex = /^[\p{L}'-]+$/u;
  
  // Split by spaces and validate each part
  const parts = value.trim().split(/\s+/);
  
  // Must have at least one part
  if (parts.length === 0 || (parts.length === 1 && parts[0] === '')) {
    return false;
  }
  
  // Each part must be valid
  for (const part of parts) {
    if (!namePartRegex.test(part)) {
      return false;
    }
  }
  
  // Reject completely empty names
  return !/^[\s'-]*$/.test(value);
}

/**
 * Luhn algorithm implementation for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  // Double every second digit from the right
  for (let i = digits.length - 2; i >= 0; i -= 2) {
    const doubled = digits[i] * 2;
    digits[i] = doubled > 9 ? doubled - 9 : doubled;
  }
  
  const sum = digits.reduce((acc, d) => acc + d, 0);
  return sum % 10 === 0;
}

/**
 * Credit card validation supporting:
 * - Visa: starts with 4, 13 or 16 digits
 * - MasterCard: starts with 51-55 or 2221-2720, 16 digits
 * - American Express: starts with 34 or 37, 15 digits
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check against known card patterns
  const patterns = {
    visa: /^4(\d{12}|\d{15})$/,
    mastercard: /^(5[1-5]\d{14}|2[2-7]\d{13}|222[1-9]\d{12}|22[3-9]\d{13}|2[3-6]\d{14}|27[01]\d{13}|2720\d{12})$/,
    amex: /^3[47]\d{13}$/,
  };
  
  let isValidPattern = false;
  for (const pattern of Object.values(patterns)) {
    if (pattern.test(cardNumber)) {
      isValidPattern = true;
      break;
    }
  }
  
  if (!isValidPattern) return false;
  
  // Validate with Luhn checksum
  return runLuhnCheck(cardNumber);
}