import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have TypeScript definitions
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

class FormServer {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private server: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private SQL: any;

  private app: express.Application;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      this.SQL = await initSqlJs();
      
      // Ensure data directory exists
      await fs.mkdir(DATA_DIR, { recursive: true });
      
      // Load existing database or create new one
      let dbBuffer: Uint8Array | null = null;
      try {
        const dbFile = await fs.readFile(DB_PATH);
        dbBuffer = new Uint8Array(dbFile);
      } catch (error) {
        // Database doesn't exist yet, will create new one
      }
      
      this.db = new this.SQL.Database(dbBuffer);
      
      // Initialize schema if needed
      const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
      this.db.run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (this.db) {
      try {
        const data = this.db.export();
        await fs.writeFile(DB_PATH, Buffer.from(data));
      } catch (error) {
        console.error('Failed to save database:', error);
        throw error;
      }
    }
  }

  private validateForm(data: FormData): ValidationResult {
    const errors: string[] = [];

    // Required field validation
    if (!data.firstName?.trim()) errors.push('First name is required');
    if (!data.lastName?.trim()) errors.push('Last name is required');
    if (!data.streetAddress?.trim()) errors.push('Street address is required');
    if (!data.city?.trim()) errors.push('City is required');
    if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
    if (!data.postalCode?.trim()) errors.push('Postal/Zip code is required');
    if (!data.country?.trim()) errors.push('Country is required');
    if (!data.email?.trim()) errors.push('Email is required');
    if (!data.phone?.trim()) errors.push('Phone number is required');

    // Email validation
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push('Please enter a valid email address');
    }

    // Phone validation - supports international formats with +, digits, spaces, parentheses, dashes
    if (data.phone && !/^\+?[\d\s()-]+$/.test(data.phone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
    }

    // Postal code validation - alphanumeric with spaces allowed
    if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push('Postal code can only contain letters, digits, spaces, and hyphens');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private setupRoutes(): void {
    this.app.get('/', (req: express.Request, res: express.Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    this.app.post('/submit', async (req: express.Request, res: express.Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const validation = this.validateForm(formData);
      
      if (!validation.isValid) {
        return res.status(400).render('form', {
          errors: validation.errors,
          values: formData
        });
      }

      try {
        // Insert into database
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run(
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        );
        
        stmt.free();
        
        // Save database to disk
        await this.saveDatabase();
        
        // Redirect to thank you page
        res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An unexpected error occurred. Please try again.'],
          values: formData
        });
      }
    });

    this.app.get('/thank-you', (req: express.Request, res: express.Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT || 3000;
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  public async stop(): Promise<void> {
    if (this.db) {
      await this.saveDatabase();
      this.db.close();
    }
    
    if (this.server) {
      return new Promise<void>((resolve) => {
        this.server.close(() => {
          console.log('Server stopped');
          resolve();
        });
      });
    }
  }
}

// Graceful shutdown handling
const server = new FormServer();

process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await server.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await server.stop();
  process.exit(0);
});

// Start the server
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});