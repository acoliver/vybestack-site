export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Run Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for invalid characters like newlines first
  if (/\s/.test(value)) {
    return false;
  }
  
  // Improved email validation regex
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Clean the input - remove all non-digit, non-space, non-hyphen, non-parenthesis characters
  const cleaned = value.replace(/[^\d\s\-()+]/g, '');
  
  // Normalize spaces and remove common separators
  const normalized = cleaned.replace(/[\s-]+/g, ' ').replace(/[()]/g, ' ').replace(/\s+/g, ' ').trim();
  
  // Pattern to match US phone numbers
  // Optional +1, area code (3 digits), central office code (3 digits), line number (4 digits)
  const pattern = /^(?:\+1\s*)?(\d{3})\s+(\d{3})\s+(\d{4})$/;
  const match = normalized.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, centralOffice, lineNumber] = match;
  
  // Area code cannot start with 0 or 1 (NPA rules)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Central office code cannot start with 0 or 1 either
  if (centralOffice[0] === '0' || centralOffice[0] === '1') {
    return false;
  }
  
  // Basic length check (10 digits total for US numbers)
  const totalDigits = areaCode + centralOffice + lineNumber;
  if (totalDigits.length !== 10) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers supporting multiple formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input - remove all non-digit, non-space, non-hyphen, non-plus characters
  const cleaned = value.replace(/[^\d\s+-]/g, '');
  
  // Normalize spaces and hyphens to single spaces
  const normalized = cleaned.replace(/[\s-]+/g, ' ').trim();
  
  // Remove all spaces to get just digits and country code
  const digitsOnly = normalized.replace(/\s+/g, '');
  
  // Pattern to match Argentine phone numbers
  // Optional +54, optional 9, optional 0, area code (2-4 digits), subscriber number (6-8 digits)
  const pattern = /^(?:\+54)?(?:9)?0?(\d{2,4})(\d{6,8})$/;
  const match = digitsOnly.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Area code must be 2-4 digits, first digit must be 1-9 (not 0)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate names - allow unicode letters, accents, apostrophes, hyphens, spaces.
 * Reject digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.length === 0) {
    return false;
  }
  
  // Check for numbers
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for problematic symbols (but allow apostrophes, hyphens, spaces, and unicode letters)
  // This regex allows:
  // - Unicode letters (including accented characters)
  // - Spaces
  // - Apostrophes (')
  // - Hyphens (-)
  // - Periods (.) for names like "Jr."
  const namePattern = /^[\p{L}\s'\-.]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional check: reject common "malicious" patterns
  // Like X Æ A-12, numbers embedded in letters, etc.
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers using Luhn algorithm and card type patterns.
 */
export function isValidCreditCard(value: string): boolean {
  // Clean the input - only digits
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card type patterns (basic validation)
  const cardPatterns = [
    /^4/, // Visa
    /^5[1-5]/, // Mastercard
    /^3[47]/, // American Express
    /^6(?:011|5)/ // Discover
  ];
  
  // Must match at least one card type pattern
  if (!cardPatterns.some(pattern => pattern.test(cleaned))) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}