/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with prefix
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    const word = match.toLowerCase();
    return !exceptions.some(exception => exception.toLowerCase() === word);
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token occurrences that appear after a digit and not at start of string
  // Capture the digit and the token together
  const pattern = new RegExp(`(\\d${token})`, 'gi');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength according to requirements.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  // Check character requirements
  const checks = {
    uppercase: /[A-Z]/.test(value),
    lowercase: /[a-z]/.test(value),
    digit: /[0-9]/.test(value),
    symbol: /[!@#$%^&*()_+=[\]{};:'"|,.<>/]/.test(value)
  };
  
  if (!checks.uppercase || !checks.lowercase || !checks.digit || !checks.symbol) {
    return false;
  }
  
  return true;
}

/**
 * Check if the text contains IPv6 addresses (and not IPv4 addresses).
 */
export function containsIPv6(value: string): boolean {
  // Match IPv6 addresses including shorthand :: notation
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/g;
  
  // Match IPv4 addresses to exclude them
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  
  const ipv6Matches = value.match(ipv6Pattern) || [];
  const ipv4Matches = value.match(ipv4Pattern) || [];
  
  // Check if we have IPv6 matches but exclude any that are actually IPv4
  return ipv6Matches.some(match => {
    // If it looks like IPv4, exclude it
    return !ipv4Matches.some(ipv4Match => ipv4Match === match);
  });
}