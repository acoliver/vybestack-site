/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure we have proper spacing after sentence endings
  // Replace multiple spaces with single space and ensure there's a space after sentence endings
  let processed = text.replace(
    /([.!?])([^\s])/g,
    '$1 $2'
  ).replace(
    /([.!?])\s+/g,
    '$1 '
  );
  
  // Capitalize first letter of each sentence
  processed = processed.replace(
    /([.!?]\s+)([a-z])/g,
    (match, sentenceEnd, firstChar) => sentenceEnd + firstChar.toUpperCase()
  ).replace(
    /^([a-z])/,
    (match, firstChar) => firstChar.toUpperCase()
  );
  
  // Clean up any remaining extra spaces
  return processed.replace(/\s+/g, ' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that captures most common URL formats
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s"'<>]+?(?=[.,!?]?\s|$)/g;
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch existing https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /http:\/\/([^/\s]+)(\/[^\s]*)/g,
    (match, host, path) => {
      // Check if path has dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      // Always upgrade to https
      if (hasDynamicHints) {
        return `https://${host}${path}`;
      }
      
      // If path begins with /docs/, rewrite host to docs.host
      if (path.startsWith('/docs/')) {
        return `https://docs.${host}${path}`;
      }
      
      return `https://${host}${path}`;
    }
  );
}

/**
 * Extract the four-digit year from a date in mm/dd/yyyy format.
 * Return 'N/A' if the format doesn't match or if month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with validation for month (01-12) and day (01-31)
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr);
  const day = parseInt(dayStr);
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}