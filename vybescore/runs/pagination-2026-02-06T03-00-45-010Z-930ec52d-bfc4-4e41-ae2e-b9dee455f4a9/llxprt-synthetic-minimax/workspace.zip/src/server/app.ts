import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    let page = 1;
    let limit = 5;

    // Validate and parse page parameter
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (Number.isNaN(pageNum) || !Number.isInteger(pageNum) || pageNum < 1) {
        return res.status(400).json({ error: 'page must be a positive integer' });
      }
      page = pageNum;
    }

    // Validate and parse limit parameter
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (Number.isNaN(limitNum) || !Number.isInteger(limitNum) || limitNum < 1 || limitNum > 1000) {
        return res.status(400).json({ error: 'limit must be a positive integer (max 1000)' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
