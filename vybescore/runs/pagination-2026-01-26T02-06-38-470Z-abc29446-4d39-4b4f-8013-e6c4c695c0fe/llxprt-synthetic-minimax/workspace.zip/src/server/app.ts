import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Validate page parameter
      let page: number | undefined;
      if (pageParam !== undefined) {
        const pageNum = Number(pageParam);
        if (!Number.isFinite(pageNum) || pageNum <= 0) {
          return res.status(400).json({ error: 'page must be a positive number' });
        }
        page = Math.floor(pageNum);
      }

      // Validate limit parameter  
      let limit: number | undefined;
      if (limitParam !== undefined) {
        const limitNum = Number(limitParam);
        if (!Number.isFinite(limitNum) || limitNum <= 0) {
          return res.status(400).json({ error: 'limit must be a positive number' });
        }
        if (limitNum > 100) { // Reasonable maximum
          return res.status(400).json({ error: 'limit cannot exceed 100' });
        }
        limit = Math.floor(limitNum);
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error in /inventory endpoint:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
