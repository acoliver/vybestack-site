/**
 * Validates if a string contains only valid Base64 characters and proper padding.
 * Throws an error for invalid input.
 */
function validateBase64Input(input: string): void {
  // Check for valid Base64 characters only (A-Z, a-z, 0-9, +, /, =)
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding if present
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }

  // Check if padding characters are only at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && paddingIndex < input.length - paddingCount) {
    throw new Error('Invalid Base64 input: padding characters must be at the end');
  }
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and validates it.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Trim whitespace and validate input
  const trimmedInput = input.trim();
  
  if (trimmedInput === '') {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Validate the input format
  validateBase64Input(trimmedInput);

  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
