#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs } from '../parseArgs.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';
import type { ReportData } from '../types.js';

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" array');
  }
  
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: invalid entry format');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: entry missing or invalid "label" field');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: entry missing or invalid "amount" field');
    }
  }
  
  return data as ReportData;
}

export function main(): void {
  try {
    const args = process.argv.slice(2);
    const cliArgs = parseArgs(args);
    
    // Read and parse the data file
    let fileContent: string;
    try {
      fileContent = readFileSync(cliArgs.dataFile, { encoding: 'utf8' });
    } catch (error) {
      console.error(`Error: Could not read file "${cliArgs.dataFile}"`);
      process.exit(1);
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${cliArgs.dataFile}"`);
      process.exit(1);
    }
    
    const reportData = validateReportData(jsonData);
    
    // Select formatter
    const renderer = cliArgs.format === 'markdown' ? markdownRenderer : textRenderer;
    const output = renderer.render(reportData, cliArgs.options);
    
    // Write output
    if (cliArgs.outputPath) {
      try {
        writeFileSync(cliArgs.outputPath, output, { encoding: 'utf8' });
      } catch (error) {
        console.error(`Error: Could not write to file "${cliArgs.outputPath}"`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
