import type { ReportFormat, RenderOptions } from './types.js';

export interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  options: RenderOptions;
}

export function parseArgs(args: string[]): CliArgs {
  const result: Partial<CliArgs> = {
    options: {
      includeTotals: false,
    },
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      const formatArg = args[++i];
      if (formatArg !== 'markdown' && formatArg !== 'text') {
        throw new Error(`Unsupported format: ${formatArg}`);
      }
      result.format = formatArg;
    } else if (arg === '--output') {
      result.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      result.options!.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      result.dataFile = arg;
    }
    
    i++;
  }

  if (!result.dataFile) {
    throw new Error('Data file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result as CliArgs;
}