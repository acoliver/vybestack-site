/**
 * Shared utilities for reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { Observer, updateObserver } from '../types/reactive.js'

// Global registry for computed values
export const computedObservers: { observer: Observer<unknown>; getter: () => unknown }[] = []

// Global registry of all callbacks to ensure they run on updates
export const activeCallbacks: Observer<unknown>[] = []

/**
 * Updates all computed values
 */
export function updateAllComputedValues(): void {
  computedObservers.forEach(({ observer }) => {
    try {
      updateObserver(observer as Observer<unknown>)
    } catch (_e) {
      // Skip errors (likely circular dependencies)
    }
  })
}

/**
 * Runs all active callbacks
 */
export function runAllCallbacks(): void {
  activeCallbacks.forEach(observer => {
    try {
      updateObserver(observer as Observer<unknown>)
    } catch (_e) {
      // Skip errors
    }
  })
}

/**
 * Adds an observer to the computed registry
 */
export function addComputedObserver<T>(observer: Observer<T>, getter: () => T): void {
  computedObservers.push({ observer: observer as Observer<unknown>, getter })
}

/**
 * Removes an observer from the computed registry
 */
export function removeComputedObserver(observer: Observer<unknown>): void {
  const index = computedObservers.findIndex(({ observer: o }) => o === observer)
  if (index > -1) {
    computedObservers.splice(index, 1)
  }
}

/**
 * Adds an observer to the callback registry
 */
export function addCallbackObserver<T>(observer: Observer<T>): void {
  activeCallbacks.push(observer as Observer<unknown>)
}

/**
 * Removes an observer from the callback registry
 */
export function removeCallbackObserver(observer: Observer<unknown>): void {
  const index = activeCallbacks.indexOf(observer as Observer<unknown>)
  if (index > -1) {
    activeCallbacks.splice(index, 1)
  }
}