/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { updateAllComputedValues, runAllCallbacks } from './shared.js'

/**
 * Default equality function
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

// Global registry of all subjects and observers
const allSubjects: Subject<unknown>[] = []
const allObservers: Observer<unknown>[] = []

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = defaultEqual
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? defaultEqual : () => false
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Register this subject globally
  allSubjects.push(s as Subject<unknown>)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Trigger all computed values and callbacks that depend on this subject
    updateAllComputedValues()
    runAllCallbacks()
    
    return s.value
  }

  return [read, write]
}

// Export functions to manage global observer registry
export function addObserver(observer: Observer<unknown>): void {
  if (!allObservers.includes(observer)) {
    allObservers.push(observer)
  }
}

export function removeObserver(observer: Observer<unknown>): void {
  const index = allObservers.indexOf(observer)
  if (index > -1) {
    allObservers.splice(index, 1)
  }
}