/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'
import { addCallbackObserver, removeCallbackObserver } from './shared.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let initialValue: T | undefined = value
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T): T => {
      if (disposed) return prevValue as T
      
      const newValue = updateFn(prevValue)
      observer.value = newValue
      initialValue = newValue
      return newValue
    },
  }
  
  // Register this callback globally
  addCallbackObserver(observer)
  
  // Initialize dependencies (this will also run the callback initially)
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from the active callbacks registry
    removeCallbackObserver(observer as Observer<unknown>)
    
    // Clear the observer
    observer.value = undefined
    observer.updateFn = () => initialValue as T
  }
}