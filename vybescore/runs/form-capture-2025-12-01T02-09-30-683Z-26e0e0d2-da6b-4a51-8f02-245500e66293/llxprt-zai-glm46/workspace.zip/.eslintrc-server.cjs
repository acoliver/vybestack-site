module.exports = {
  ...require('./.eslintrc.cjs'),
  rules: {
    ...require('./.eslintrc.cjs').rules,
    '@typescript-eslint/no-explicit-any': 'off',
    '@typescript-eslint/no-require-imports': 'off'
  }
};