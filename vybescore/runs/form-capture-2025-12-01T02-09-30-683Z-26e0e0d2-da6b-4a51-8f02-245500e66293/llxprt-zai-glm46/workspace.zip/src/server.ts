import express, { Express, Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: Partial<FormData>;
}

// Type definitions for sql.js
interface Database {
  run(sql: string, params?: unknown[]): unknown;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(params?: unknown[]): unknown;
  free(): void;
}

const PORT = process.env.PORT || 3535;
let db: Database;

const app: Express = express();

// Initialize database
async function initializeDatabase() {
  try {
    // Use createRequire to enable require in ES modules
    const { createRequire } = await import('module');
    const require = createRequire(import.meta.url);
    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    // Try to load existing database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read schema and create tables
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Save initial database
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Created new database');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  try {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateFormData(data: FormData): ValidationResult {
  const errors: Partial<FormData> = {};
  
  // Required fields validation
  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }
  
  // Postal code validation - allow alphanumeric
  if (data.postal_code && !/^[a-zA-Z0-9\s-]+$/.test(data.postal_code)) {
    errors.postal_code = 'Postal code can only contain letters, numbers, spaces, and dashes';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = req.body;
  
  // Validate form data
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    // Render form with errors
    return res.render('form', {
      errors: validation.errors,
      formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
    
  } catch (error) {
    console.error('Database error:', error);
    res.render('form', {
      errors: { email: 'An error occurred while saving your submission. Please try again.' },
      formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
function shutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch(console.error);