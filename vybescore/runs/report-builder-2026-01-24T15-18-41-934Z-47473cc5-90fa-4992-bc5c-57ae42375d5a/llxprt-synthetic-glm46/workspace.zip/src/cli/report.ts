#!/usr/bin/env node

import fs from 'fs';
import { report } from '../report.js';

function parseArgs(): { dataFile: string; format: string; output?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  let dataFile = '';
  let format = '';
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[++i];
    } else if (arg === '--output') {
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--') && !dataFile) {
      dataFile = arg;
    }
  }
  
  if (!dataFile) {
    console.error('Error: Missing data file path');
    process.exit(1);
  }
  
  if (!format) {
    console.error('Error: Missing --format option');
    process.exit(1);
  }
  
  return { dataFile, format, output, includeTotals };
}

function main(): void {
  try {
    const { dataFile, format, output, includeTotals } = parseArgs();
    
    let data;
    try {
      const fileContent = fs.readFileSync(dataFile, 'utf8');
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing file "${dataFile}":`, error instanceof Error ? error.message : String(error));
      process.exit(1);
    }
    
    const result = report(data, format, { includeTotals });
    
    if (output) {
      fs.writeFileSync(output, result);
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
