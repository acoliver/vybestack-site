import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';
import type { ReportData, RenderOptions, FormatRenderer } from './types.js';

const formatRenderers: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: expected an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title (must be a string)');
  }
  
  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary (must be a string)');
  }
  
  if (!reportData.entries || !Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: missing or invalid entries (must be an array)');
  }
  
  for (const [index, entry] of reportData.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid label (must be a string)`);
    }
    
    if (!entryObj.amount || typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid amount (must be a number)`);
    }
  }
  
  return data as ReportData;
}

export function report(data: unknown, format: string, options: RenderOptions): string {
  if (!formatRenderers[format]) {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  const validatedData = validateReportData(data);
  const renderer = formatRenderers[format];
  
  return renderer(validatedData, options);
}