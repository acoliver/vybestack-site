export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email pattern: local@domain with constraints
  // Local: letters, digits, ., _, -, + (but not starting/ending with . or having double ..)
  // Domain: letters, digits, hyphens, dots (but not starting/ending with - or having double ..)
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional checks for common invalid patterns
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot in domain
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  if (domain.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to normalize
  const cleaned = value.replace(/\D/g, '');
  
  // Check length - must be 10 digits (standard US number) or 11 digits (with leading 1)
  if (cleaned.length === 11 && cleaned.startsWith('1')) {
    // Remove leading 1 for validation
    const number = cleaned.substring(1);
    return isValidUSNumber(number);
  } else if (cleaned.length === 10) {
    return isValidUSNumber(cleaned);
  }
  
  return false;
}

function isValidUSNumber(number: string): boolean {
  // Area code cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Total length check
  if (number.length !== 10) {
    return false;
  }
  
  // Check for invalid patterns in the original input
  // At minimum, we need area code + exchange + number (10 digits)
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input - remove separators and punctuation for validation
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Use regex to match the Argentine phone pattern
  // Allow various combinations with proper digit allocation
  const phonePattern = /^(\+54)?(0)?(9)?([1-9]\d{2})(\d{6,8})$/;
  const match = cleaned.match(phonePattern);
  
  if (!match) {
    return false;
  }
  
  const countryCode = match[1]; // +54 (optional)
  const trunkPrefix = match[2]; // 0 (optional)
  
  // Validation rules:
  // 1. When country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // 2. Area code and subscriber lengths are validated by regex pattern
  
  const totalDigits = cleaned.length;
  
  // Allow reasonable digit counts for various formats
  if (countryCode || trunkPrefix) {
    return totalDigits >= 9 && totalDigits <= 15;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name pattern: Unicode letters, spaces, apostrophes, hyphens only
  // Must not contain digits, symbols (except apostrophe and hyphen), or X Æ A-12 style
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional validation: must not be empty and should have reasonable length
  if (value.trim().length === 0 || value.length > 100) {
    return false;
  }
  
  // Reject names that start or end with space, apostrophe, or hyphen inappropriately
  const trimmed = value.trim();
  if (trimmed.startsWith("'") || trimmed.startsWith("-")) {
    return false;
  }
  if (trimmed.endsWith("'") || trimmed.endsWith("-")) {
    return false;
  }
  
  // Check for multiple consecutive spaces/apostrophes/hyphens
  if (/['-]{2,}/.test(value) || /\s{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Helper function to validate credit card using Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Clean the input - remove non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Must have reasonable length for credit card
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths for major card types
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/;
  // MasterCard: starts with 5[1-5] or 2221-2720, length 16
  const mastercardPattern = /^(5[1-5][0-9]{14}|2(2[2-9][0-9]|[3-6][0-9][0-9]|7[01][0-9]|720)[0-9]{12})$/;
  // American Express: starts with 34 or 37, length 15
  const amexPattern = /^(3[47][0-9]{13})$/;
  
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleaned);
}
