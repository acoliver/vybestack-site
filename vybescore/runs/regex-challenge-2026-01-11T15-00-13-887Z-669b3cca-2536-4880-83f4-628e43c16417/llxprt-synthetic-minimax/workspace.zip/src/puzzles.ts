/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with prefix
  // Word boundaries: start of word or non-word character, then prefix, then word characters
  const pattern = new RegExp(`\\b${prefix}[\\w]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exact matches from exceptions list
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches.filter(match => {
    return !exceptionsSet.has(match.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where the token appears after a digit and not at the start of the string
  // Pattern: digit followed by the token (to capture the full match including the digit)
  const pattern = new RegExp(`\\d${token}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like 'abab'
  // Pattern looks for repeated 2-character patterns
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  // Check for repeated characters (3 or more)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // We want to detect IPv6 addresses within text
  // Pattern to match IPv6 addresses (including shorthand ::)
  // Exclude pure IPv4 addresses
  
  // Check for IPv6 patterns within the string
  // Look for sequences of hex digits separated by colons
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}|[0-9a-fA-F]{0,4}::[0-9a-fA-F]{0,4}/;
  
  // Check for mixed IPv4/IPv6 patterns
  const mixedPattern = /::(?:[fF]{0,4}:)?(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check if the string contains IPv6 patterns
  if (!ipv6Pattern.test(value) && !mixedPattern.test(value)) {
    return false;
  }
  
  // Exclude pure IPv4 addresses (dotted decimal format)
  const pureIpv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If the entire string is just an IPv4 address, return false
  if (pureIpv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Also exclude if it looks like a pure IPv4 pattern even if embedded in text
  const hasOnlyDigitsAndDots = /^[\d.]+$/.test(value.replace(/[a-fA-F:]/g, ''));
  const hasColons = /:/.test(value);
  
  if (hasOnlyDigitsAndDots && !hasColons) {
    return false;
  }
  
  return true;
}
