/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and spacing
  let result = text.trim();
  
  // Collapse multiple spaces into single spaces
  result = result.replace(/\s+/g, ' ');
  
  // Capitalize first character of text
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Find sentence boundaries and capitalize after sentence endings
  // Pattern: end of sentence (.?!), followed by optional whitespace, then capitalize
  result = result.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    return punctuation + spaces + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Find all URLs in the text
  // Pattern matches http/https URLs with domain names
  const urlPattern = /\bhttps?:\/\/[^\s<>"']*[^\s<>"'.,!?;)]/g;
  
  const urls = text.match(urlPattern) || [];
  
  // Clean up URLs - remove trailing punctuation
  return urls.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?;)]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http:// scheme
  const httpUrlPattern = /http:\/\/([^/\s<>"']+)([^\s<>"']*)/g;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = /(\?|=|&)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))|cgi-bin/i.test(path);
    
    let newUrl;
    
    if (hasDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.example.com and upgrade to https
      newUrl = `https://docs.example.com${path}`;
    } else {
      // Just upgrade the scheme to https://, keep original host
      newUrl = `https://${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (considering leap years for February)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Check for reasonable year range (not in future, not too old)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}
