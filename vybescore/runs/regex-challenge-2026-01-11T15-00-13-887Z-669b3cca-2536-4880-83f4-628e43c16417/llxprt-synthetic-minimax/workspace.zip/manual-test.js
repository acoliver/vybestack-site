// Manual testing with tricky strings
import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard,
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear,
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './src/index.js';

console.log('=== Manual Testing with Tricky Strings ===\n');

// Test validators with edge cases
console.log('--- EMAIL VALIDATION (tricky cases) ---');
console.log('[OK] name+tag@example.co.uk:', isValidEmail('name+tag@example.co.uk'));
console.log(' double..dots@example.com:', isValidEmail('double..dots@example.com'));
console.log(' trailing.dot@example.com:', isValidEmail('trailing.dot@example.com'));
console.log(' user@domain_with_underscore.com:', isValidEmail('user@domain_with_underscore.com'));
console.log('[OK] normal.email@domain.com:', isValidEmail('normal.email@domain.com'));

console.log('\n--- US PHONE VALIDATION (tricky cases) ---');
console.log('[OK] (212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('[OK] 212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('[OK] 2125557890:', isValidUSPhone('2125557890'));
console.log('[OK] +1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log(' 212-555 (too short):', isValidUSPhone('212-555'));
console.log(' 012-555-7890 (area code starts with 0):', isValidUSPhone('012-555-7890'));
console.log(' 112-555-7890 (area code starts with 1):', isValidUSPhone('112-555-7890'));

console.log('\n--- ARGENTINE PHONE VALIDATION (tricky cases) ---');
console.log('[OK] +54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('[OK] 011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('[OK] +54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('[OK] 0341 4234567:', isValidArgentinePhone('0341 4234567'));
console.log(' 123 456 7890 (no country/trunk):', isValidArgentinePhone('123 456 7890'));

console.log('\n--- NAME VALIDATION (tricky cases) ---');
console.log('[OK] José María García-López:', isValidName('José María García-López'));
console.log('[OK] O\'Connor III:', isValidName('O\'Connor III'));
console.log('[OK] D\'Angelo-Smith:', isValidName('D\'Angelo-Smith'));
console.log(' User123:', isValidName('User123'));
console.log(' Name with!@#:', isValidName('Name with!@#'));

console.log('\n--- CREDIT CARD VALIDATION (tricky cases) ---');
console.log('[OK] Visa 4111111111111111:', isValidCreditCard('4111111111111111'));
console.log('[OK] MasterCard 5555555555554444:', isValidCreditCard('5555555555554444'));
console.log('[OK] AmEx 378282246310005:', isValidCreditCard('378282246310005'));
console.log(' too short 1234:', isValidCreditCard('1234'));
console.log(' invalid checksum 1234567890123456:', isValidCreditCard('1234567890123456'));

console.log('\n--- TEXT TRANSFORMATIONS (tricky cases) ---');
const trickyText = 'hello world.  this has  EXTRA   spaces!! https://example.com is here';
console.log('Original:', `'${trickyText}'`);
console.log('Capitalized:', `'${capitalizeSentences(trickyText)}'`);

const urlText = 'Visit http://example.com today. Also https://secure.com and http://docs.example.com/docs/api/v1!';
console.log('\nURL Text:', urlText);
console.log('Extracted URLs:', extractUrls(urlText));
console.log('HTTPS enforced:', enforceHttps(urlText));
console.log('Docs URLs rewritten:', rewriteDocsUrls(urlText));

console.log('\nYear extraction:');
console.log('[OK] 01/31/2024:', extractYear('01/31/2024'));
console.log(' invalid format 2024-01-31:', extractYear('2024-01-31'));
console.log(' invalid month 13/31/2024:', extractYear('13/31/2024'));
console.log(' invalid day 02/30/2024:', extractYear('02/30/2024'));

console.log('\n--- REGEX PUZZLES (tricky cases) ---');
const puzzleText = 'preview prevent prefix prediction preventer apple banana prefix';
console.log('Text:', `"${puzzleText}"`);
console.log('Prefixed with "pre", except "prevent":', findPrefixedWords(puzzleText, 'pre', ['prevent']));

const tokenText = 'foo 1foo foo2bar barfoo';
console.log('Text:', `"${tokenText}"`);
console.log('Embedded "foo" after digits:', findEmbeddedToken(tokenText, 'foo'));

console.log('\nPassword validation:');
console.log('[OK] strong password Abcdef!234:', isStrongPassword('Abcdef!234'));
console.log(' too short abc!1:', isStrongPassword('abc!1'));
console.log(' no uppercase abcdef!123:', isStrongPassword('abcdef!123'));
console.log(' no special chars Abcdef123:', isStrongPassword('Abcdef123'));
console.log(' has whitespace Abc def!234:', isStrongPassword('Abc def!234'));
console.log(' has repeated sequence ababdef!234:', isStrongPassword('ababdef!234'));

console.log('\nIPv6 detection:');
console.log('[OK] contains IPv6 2001:db8::1:', containsIPv6('Address: 2001:db8::1'));
console.log('[OK] contains IPv6 ::1:', containsIPv6('Loopback: ::1'));
console.log(' pure IPv4 192.168.1.1:', containsIPv6('Address: 192.168.1.1'));
console.log('[OK] embedded IPv6 IPv6 address 2001:0db8:0000:0000:0000:ff00:0042:8329 here:', 
  containsIPv6('IPv6 address 2001:0db8:0000:0000:0000:ff00:0042:8329 here'));

console.log('\n=== Manual Testing Complete ===');