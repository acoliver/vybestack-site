import express from 'express';
import * as path from 'path';
import { insertSubmission } from './utils/db.js';
import { validateFormData } from './utils/validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', async (req, res) => {
  try {
    const validation = validateFormData(req.body);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        values: req.body
      });
    }

    await insertSubmission({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvinceRegion: req.body.stateProvinceRegion,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phoneNumber: req.body.phoneNumber
    });

    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      errors: ['An error occurred. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  server.close(() => {
    console.log('Server closed.');
  });
});

export default app;
