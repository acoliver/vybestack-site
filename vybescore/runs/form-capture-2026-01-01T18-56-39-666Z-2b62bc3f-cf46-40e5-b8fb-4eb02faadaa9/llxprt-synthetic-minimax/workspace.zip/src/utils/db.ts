import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

let sql: SqlJsStatic | null = null;
let db: Database | null = null;

export async function initDatabase(): Promise<Database> {
  if (!sql) {
    sql = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });
  }

  const dbExists = fs.existsSync(DB_PATH);
  
  if (!db) {
    if (dbExists) {
      const filebuffer = fs.readFileSync(DB_PATH);
      db = new sql.Database(filebuffer);
    } else {
      db = new sql.Database();
      await seedDatabase();
    }
  }

  return db!;
}

async function seedDatabase(): Promise<void> {
  if (!db || !sql) return;

  const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  if (fs.existsSync(schemaPath)) {
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
  }
}

export function saveDatabase(): void {
  if (db && sql) {
    const data = db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(DB_PATH, buffer);
  }
}

export async function insertSubmission(submission: {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}): Promise<void> {
  const database = await initDatabase();
  
  const stmt = database.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province_region, postal_code, country, 
      email, phone_number
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvinceRegion,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phoneNumber
  ]);

  stmt.free();
  saveDatabase();
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

process.on('SIGTERM', () => {
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  closeDatabase();
  process.exit(0);
});