#!/usr/bin/env node

import fs from 'fs';
import type { ReportData, ReportOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: CliArgs = {
    dataFile: args[2],
    format: 'markdown',
    includeTotals: false,
  };

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format': {
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        const format = args[i] as Format;
        if (!formatters[format]) {
          console.error(`Error: Unsupported format "${format}"`);
          process.exit(1);
        }
        result.format = format;
        break;
      }
      case '--output': {
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        result.outputPath = args[i];
        break;
      }
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument "${args[i]}"`);
        process.exit(1);
    }
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "label" field (must be string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "amount" field (must be number)`);
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArguments(process.argv);

    let jsonData: unknown;
    try {
      const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${args.dataFile}": ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error: Could not read file "${args.dataFile}": ${error.message}`);
      } else {
        console.error(`Error: Could not read file "${args.dataFile}"`);
      }
      process.exit(1);
    }

    const reportData: ReportData = validateReportData(jsonData);
    const options: ReportOptions = { includeTotals: args.includeTotals };
    const formatter = formatters[args.format];
    const output = formatter(reportData, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.log(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
