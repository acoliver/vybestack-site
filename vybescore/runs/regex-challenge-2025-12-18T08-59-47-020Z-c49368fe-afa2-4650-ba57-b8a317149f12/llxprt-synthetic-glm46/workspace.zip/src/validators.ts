export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts common formats like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check for obvious invalid patterns first
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (value.includes('_')) {
    const [, domain] = value.split('@');
    if (domain && domain.includes('_')) {
      return false;
    }
  }
  
  // Email regex pattern:
  // - Local part: alphanumeric chars plus .!#$%&'*+/=?^_`{|}~- and dots (but not consecutive or at ends)
  // - @ symbol
  // - Domain: alphanumeric chars + hyphens, no underscores
  // - TLD: 2-63 chars
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?<!\.)@(?!-)[a-zA-Z0-9-]+(?<!-)(\.[a-zA-Z0-9-]+(?<!-))*\.[a-zA-Z]{2,63}$/;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers with various formats and optional extensions.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters except plus sign
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it's too short to be a valid US phone number
  if (cleaned.length < 10) {
    return false;
  }
  
  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // We should have exactly 10 digits for a valid US phone number
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - can't start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the original format using regex
  // This regex matches:
  // - Optional +1 country code
  // - Area code in parentheses or plain
  // - 7-digit subscriber number with various separators
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  // For extended validation, also check for extensions if allowed
  if (options?.allowExtensions) {
    const extendedPhoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}([\s-]*(ext|x|#)\s*\d+)?$/;
    return extendedPhoneRegex.test(value);
  }
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers with various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers:
  // - Optional +54 country code
  // - Optional trunk prefix 0 immediately before area code
  // - Optional mobile indicator 9 between country/trunk and area code
  // - Area code: 2-4 digits, leading digit 1-9
  // - Subscriber number: 6-8 digits
  // When country code is omitted, must start with trunk prefix 0
  const phoneRegex = /^(\+54)?(9)?(0?[2-9]\d{1,3})(\d{6,8})$/;
  
  // Additional validation to ensure proper structure
  // When country code is omitted, must start with 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return phoneRegex.test(cleaned);
}

/**
 * Validates names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Regex to match valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, spaces
  // - Must contain at least one letter
  // - Reject digits and symbols except allowed ones
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  // Check for at least one letter
  const hasLetter = /\p{L}/u.test(value);
  
  return nameRegex.test(value) && hasLetter;
}

/**
 * Luhn algorithm helper for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Accepts valid prefixes and lengths, and runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length: Visa (13 or 16), Mastercard (16), AmEx (15)
  if (digits.length < 13 || digits.length > 16) {
    return false;
  }
  
  // Check prefixes:
  // Visa: starts with 4
  // Mastercard: starts with 51-55 or 2221-2720
  // AmEx: starts with 34 or 37
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidPrefix = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(value);
}