/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences and collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Split by sentence terminators (?, !, .)
  const sentences = text.split(/([.!?])/);
  
  // Process pairs of [sentence, delimiter]
  const result: string[] = [];
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const delimiter = sentences[i + 1] || '';
    
    if (sentence.trim()) {
      // Clean up spacing and capitalize first character
      const cleaned = sentence.trim().replace(/\s+/g, ' ');
      const capitalized = cleaned.charAt(0).toUpperCase() + cleaned.slice(1).toLowerCase();
      
      result.push(capitalized);
      
      // Add delimiter with no space before but space after
      if (delimiter) {
        result.push(delimiter);
        result.push(' ');
      }
    } else if (delimiter) {
      // Handle cases where we have a delimiter without preceding text
      result.push(delimiter);
      result.push(' ');
    }
  }
  
  // Clean up trailing space
  return result.join('').replace(/\s+$/g, '');
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  const urlRegex = /https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return urls.map(url => url.replace(/[.,;:!?)\]}]+$/g, ''));
}

/**
 * Replaces all http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  return text.replace(/http:\/\//g, 'https://');
  return text.replace(/http:\/\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  // Pattern to match URLs and capture components
  // Use a string to create regex to avoid escape character issues
  const urlPattern = '(https?://)([^/]+)(/[^\\s]*)';
  const urlRegex = new RegExp(urlPattern, 'g');
  
  return text.replace(urlRegex, (match, protocol, host, path) => {
    // Always upgrade to HTTPS
    let newUrl = `https://${host}${path}`;
    
    // Check if path starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check for exclusion patterns
      const exclusionPatterns = [
        /\/cgi-bin\//,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=\/|$)/
      ];
      
      // Only rewrite host if no exclusion patterns match
      if (!exclusionPatterns.some(pattern => pattern.test(path))) {
        const domain = host.replace(/^www\./, '');
        newUrl = `https://docs.${domain}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from a mm/dd/yyyy formatted date string.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day for month (simple validation)
  if (
    (month === 2 && day > 29) || // February (simplified, ignoring leap years)
    ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) ||
    (day > 31)
  ) {
    return 'N/A';
  }
  
  return year;
}