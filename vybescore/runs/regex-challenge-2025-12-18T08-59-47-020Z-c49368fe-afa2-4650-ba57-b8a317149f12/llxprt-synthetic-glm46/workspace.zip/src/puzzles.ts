/**
 * Finds words beginning with the specified prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
  const exceptionsSet = new Set(exceptions);
  const words = text.match(/\b\w+\b/g) || [];
  
  return words
    .filter(word => word.startsWith(prefix))
    .filter(word => !exceptionsSet.has(word))
    .filter((word, index, array) => array.indexOf(word) === index); // Remove duplicates
}

/**
 * Returns occurrences of the token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Split text and find tokens that are preceded by a digit and not at the start
  const result = [];
  const parts = text.split(token);
  
  for (let i = 1; i < parts.length; i++) {
    const previousPart = parts[i-1];
    if (previousPart && /\d$/.test(previousPart)) {
      // Return the digit+token combination
      const digitMatch = previousPart.match(/\d+$/);
      if (digitMatch) {
        result.push(digitMatch[0] + token);
      }
    }
  }
  
  return result;
}

/**
 * Validates if a password is strong according to specific criteria:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const symbolChars = '!@#$%^&*()_+-=[]{};:"\\|,.<>/?';
  const hasSymbol = new RegExp('[' + symbolChars.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ']').test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated patterns (e.g., abab)
  if (/(.+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) while ensuring IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv6 regex pattern (simplified but covers common cases)
  const ipv6Regex = /((?=.*::)(?!.*::.+::)(::)?([\dA-F]{1,4}:(:|\b)|){5}|([\dA-F]{1,4}:){6}(([\dA-F]{1,4}((:\b)|(:([\dA-F]{1,4}:(:|\b)|$))|(:?))|(\b)|)))/i;
  
  // Test for IPv6
  const hasIPv6 = ipv6Regex.test(value);
  
  if (!hasIPv6) {
    return false;
  }
  
  // IPv4 regex pattern
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Make sure we don't have a pure IPv4 address
  return !ipv4Regex.test(value.trim());
}