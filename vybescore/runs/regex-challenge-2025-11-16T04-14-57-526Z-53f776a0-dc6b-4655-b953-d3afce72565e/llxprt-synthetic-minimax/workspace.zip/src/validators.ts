export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* options?: PhoneValidationOptions */): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (should be 10 or 11 digits with country code)
  if (cleaned.length < 10 || cleaned.length > 11) return false;
  
  // If 11 digits, first should be 1 (country code)
  if (cleaned.length === 11 && cleaned[0] !== '1') return false;
  
  // Extract area code (first 3 digits)
  const areaCode = cleaned.length === 11 ? cleaned.slice(1, 4) : cleaned.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation.
 * Supports various formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except + for validation
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Pattern matching Argentine phone number format
  // Optional country code +54
  // Optional mobile indicator 9 between country/trunk and area code
  // Optional trunk prefix 0 before area code
  // Area code: 2-4 digits (first digit 1-9)
  // Subscriber number: 6-8 digits total
  const pattern = /^(?:\+54\s*)?(?:9\s*)?(?:0\s*)?([1-9]\d{1,3})\s*(\d{6,8})$/;
  
  const match = cleaned.match(pattern);
  if (!match) return false;
  
  const subscriberNumber = match[2];
  
  // Area code validation: mobile should be 2-3 digits, landline 2-4 digits
  const areaCodeLength = match[1].length;
  
  // If area code is 2-3 digits, likely mobile
  // If area code is 4 digits, likely landline
  // Mobile numbers have the 9 mobile indicator
  if (areaCodeLength >= 2 && areaCodeLength <= 3) {
    // Mobile - should have mobile indicator 9
    if (!/^9/.test(match[0])) return false;
  } else if (areaCodeLength === 4) {
    // Landline - should not have mobile indicator
    if (/^9/.test(match[0])) return false;
  }
  
  // Subscriber number should be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate names - permit unicode letters, accents, apostrophes, hyphens, spaces.
 * Reject digits and symbols.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}\s'\-]+$/u;
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit cards using card prefixes and lengths, running Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check length (should be 13-19 digits)
  if (cardNumber.length < 13 || cardNumber.length > 19) return false;
  
  // Check card type and run Luhn algorithm
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cardNumber) && (cardNumber.length === 13 || cardNumber.length === 16 || cardNumber.length === 19)) {
    return runLuhnCheck(cardNumber);
  }
  // Mastercard: starts with 51-55, or 2221-2720, length 16
  else if (/^5[1-5]/.test(cardNumber) || /^2[2-7][2-9][0-1]/.test(cardNumber)) {
    if (cardNumber.length === 16) {
      return runLuhnCheck(cardNumber);
    }
    return false;
  }
  // AmEx: starts with 34 or 37, length 15
  else if (/^3[47]/.test(cardNumber) && cardNumber.length === 15) {
    return runLuhnCheck(cardNumber);
  }
  
  return false;
}

/**
 * Helper function to run Luhn algorithm checksum
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}