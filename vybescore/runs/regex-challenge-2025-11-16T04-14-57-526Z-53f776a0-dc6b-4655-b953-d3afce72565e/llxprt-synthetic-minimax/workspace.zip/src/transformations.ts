/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace between sentences
  let result = text.replace(/([.!?])\s*([A-Z])/g, '$1 $2');
  
  // Then capitalize the first letter of each sentence
  result = result.replace(/(^\s*[a-z])|([.!?]\s+[a-z])/g, match => {
    return match.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+\b/g;
  const matches = text.match(urlRegex) || [];
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/docs/... URLs to https://docs.example.com/...
 * - If path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite if path contains dynamic hints or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  const urlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, host, path) => {
    // Check if path contains dynamic hints that should skip host rewrite
    const hasDynamicHints = /(\?.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py|cgi-bin))/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Extract the domain part (for host rewriting)
      // For "example.com", we want "example.com"
      // For "sub.domain.example.com", we want "domain.example.com"
      const parts = host.split('.');
      let baseDomain: string;
      if (parts.length >= 2) {
        // Take the last two parts for the base domain
        baseDomain = parts.slice(-2).join('.');
      } else {
        baseDomain = host;
      }
      
      // Replace http:// with https:// and change host to docs.baseDomain
      return match.replace('http://', 'https://').replace(host, `docs.${baseDomain}`);
    }
    
    // If not a /docs/ path or has dynamic hints, just upgrade the scheme
    return match.replace('http://', 'https://');
  });
}

/**
 * TODO: Extract year from mm/dd/yyyy format. Return 'N/A' for invalid dates.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Basic day validation (1-31, not checking for month-specific days)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return match[3]; // Return the year part
}