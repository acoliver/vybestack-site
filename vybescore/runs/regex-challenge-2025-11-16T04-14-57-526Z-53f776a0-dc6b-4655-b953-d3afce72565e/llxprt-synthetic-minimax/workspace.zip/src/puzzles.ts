/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const wordRegex = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const matches = [];
  const regex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'g');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    // Get the preceding digit and the token
    const start = match.index - 1;
    const end = match.index + token.length;
    if (start >= 0) {
      matches.push(text.substring(start, end));
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check for at least 10 characters
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for one digit
  if (!/\d/.test(value)) return false;
  
  // Check for one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for no immediate repeated sequences (e.g., abab should fail)
  // This pattern looks for any sequence of characters that repeats immediately
  if (/([a-zA-Z0-9]{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern including shorthand notation
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // First check if there's a potential IPv6 match
  if (!ipv6Pattern.test(value)) return false;
  
  // Check if this is actually an IPv4 address (to exclude it)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) return false;
  
  return true;
}