#!/usr/bin/env python3

import re

# Fix line 39 in transformations.ts
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-11-16T04-14-57-526Z-53f776a0-dc6b-4655-b953-d3afce72565e/src/transformations.ts', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace the problematic line 39
old_line_39 = 'const urlRegex = /http:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)/g;'
new_line_39 = 'const urlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)/g;'

content = content.replace(old_line_39, new_line_39)

# Fix line 84 in validators.ts
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-11-16T04-14-57-526Z-53f776a0-dc6b-4655-b953-d3afce72565e/src/validators.ts', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace the problematic line 84
old_line_84 = 'const nameRegex = /^[\\p{L}\\p{M}\\s\'\\-]+$/u;'
new_line_84 = 'const nameRegex = /^[\p{L}\p{M}\s\'\-]+$/u;'

content = content.replace(old_line_84, new_line_84)

# Write back to validators.ts
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-11-16T04-14-57-526Z-53f776a0-dc6b-4655-b953-d3afce72565e/src/validators.ts', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed both lines!")