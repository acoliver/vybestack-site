/**
 * Validation error details.
 */
export interface ValidationError {
  field: string;
  message: string;
}

/**
 * Form input values.
 */
export interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

/**
 * Validate form submission.
 * Returns an array of errors (empty if valid).
 */
export function validateForm(values: FormValues): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!values.firstName || values.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required.' });
  }

  if (!values.lastName || values.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required.' });
  }

  if (!values.streetAddress || values.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required.' });
  }

  if (!values.city || values.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required.' });
  }

  if (!values.stateProvince || values.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required.' });
  }

  if (!values.postalCode || values.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required.' });
  } else if (!isValidPostalCode(values.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, and spaces.' });
  }

  if (!values.country || values.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required.' });
  }

  if (!values.email || values.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required.' });
  } else if (!isValidEmail(values.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address.' });
  }

  if (!values.phone || values.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required.' });
  } else if (!isValidPhone(values.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +.' });
  }

  return errors;
}

/**
 * Validate email format.
 * Simple regex that checks for basic email structure.
 */
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate phone number format.
 * Allows digits, spaces, parentheses, dashes, and an optional leading +.
 */
function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 5;
}

/**
 * Validate postal code format.
 * Allows alphanumeric characters, spaces, and hyphens (e.g., "SW1A 1AA", "C1000", "B1675", "150-0002").
 */
function isValidPostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length > 0;
}
