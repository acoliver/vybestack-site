import initSqlJs, { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

const DB_PATH = join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = join(process.cwd(), 'db', 'schema.sql');

let db: Database | null = null;

/**
 * Initialize the SQLite database.
 * Creates the data directory and database file if they don't exist.
 */
export async function initializeDatabase(): Promise<Database> {
  if (db) {
    return db;
  }

  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (existsSync(DB_PATH)) {
    const buffer = readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    
    // Read and execute schema
    const schema = readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    
    // Save the new database
    saveDatabase();
  }

  return db;
}

/**
 * Save the database to disk.
 */
export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  const buffer = Buffer.from(data);
  writeFileSync(DB_PATH, buffer);
}

/**
 * Insert a form submission into the database.
 */
export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(data: SubmissionData): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.first_name,
    data.last_name,
    data.street_address,
    data.city,
    data.state_province,
    data.postal_code,
    data.country,
    data.email,
    data.phone,
  ]);

  stmt.free();
  
  // Save after each insert
  saveDatabase();
}

/**
 * Close the database connection.
 */
export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

/**
 * Get the database instance (for testing purposes).
 */
export function getDatabase(): Database | null {
  return db;
}
