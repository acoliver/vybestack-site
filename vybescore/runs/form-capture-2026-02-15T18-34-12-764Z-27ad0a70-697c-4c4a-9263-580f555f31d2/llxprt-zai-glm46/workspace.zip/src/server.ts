import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  initializeDatabase,
  insertSubmission,
  closeDatabase,
  type SubmissionData,
} from './database.js';
import { validateForm, type FormValues } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || '3535';

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Initialize database on startup
let dbInitialized = false;

/**
 * GET / - Render the form
 */
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

/**
 * POST /submit - Handle form submission
 */
app.post('/submit', async (req: Request, res: Response) => {
  // Ensure database is initialized
  if (!dbInitialized) {
    await initializeDatabase();
    dbInitialized = true;
  }

  const values: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  // Validate form
  const errors = validateForm(values);

  if (errors.length > 0) {
    // Re-render form with errors
    const errorMessages = errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values,
    });
    return;
  }

  // Insert into database
  const submission: SubmissionData = {
    first_name: values.firstName!,
    last_name: values.lastName!,
    street_address: values.streetAddress!,
    city: values.city!,
    state_province: values.stateProvince!,
    postal_code: values.postalCode!,
    country: values.country!,
    email: values.email!,
    phone: values.phone!,
  };

  insertSubmission(submission);

  // Redirect to thank-you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(values.firstName!)}`);
});

/**
 * GET /thank-you - Render thank you page
 */
app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

/**
 * Graceful shutdown handler
 */
async function shutdown(signal: string): Promise<void> {
  console.log(`
${signal} received. Shutting down gracefully...`);
  
  closeDatabase();
  
  process.exit(0);
}

// Start server
async function start(): Promise<void> {
  try {
    // Initialize database
    await initializeDatabase();
    dbInitialized = true;
    console.log('Database initialized.');

    const server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });

    // Store server reference for potential use
    (globalThis as unknown as { server: unknown }).server = server;

    // Handle graceful shutdown
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
start();
