/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace and validate input contains only valid Base64 characters
  const normalized = input.replace(/\s/g, '').trim();
  
  // Basic validation for Base64 format
  if (normalized.length === 0) {
    throw new Error('Empty Base64 input');
  }
  
  // Check for invalid characters (only allow A-Z, a-z, 0-9, +, /, and = for padding)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains unsupported characters');
  }
  
  // Check that padding is only at the end (max 2 padding characters)
  const paddingMatch = normalized.match(/=+$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // Check that all padding is at the end (no = in non-padding positions)
  const basePart = normalized.replace(/=+$/, '');
  if (/=/.test(basePart)) {
    throw new Error('Invalid Base64 input: padding characters not at the end');
  }
  
  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
