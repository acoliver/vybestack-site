#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { formatReport } from '../formats/index.js';
import { ReportData, ReportOptions } from '../types.js';

function parseArgs(args: string[]): { dataPath: string; options: ReportOptions } {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let dataPath = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--') && !dataPath) {
      dataPath = arg;
    }
  }

  if (!dataPath) {
    console.error('Error: JSON file path is required');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format option is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  return {
    dataPath,
    options: {
      format,
      outputPath,
      includeTotals,
    },
  };
}

function loadAndValidateData(dataPath: string): ReportData {
  try {
    const content = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Missing or invalid "title" field in JSON');
      process.exit(1);
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Missing or invalid "summary" field in JSON');
      process.exit(1);
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      console.error('Error: Missing or invalid "entries" field in JSON');
      process.exit(1);
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        console.error(`Error: Missing or invalid "label" field in entry ${i + 1}`);
        process.exit(1);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        console.error(`Error: Missing or invalid "amount" field in entry ${i + 1}`);
        process.exit(1);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
      process.exit(1);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found - ${dataPath}`);
      process.exit(1);
    } else {
      console.error(`Error: Failed to read file - ${(error as Error)?.message || error}`);
      process.exit(1);
    }
  }
}

function main(): void {
  const args = process.argv;
  
  try {
    const { dataPath, options } = parseArgs(args);
    const data = loadAndValidateData(dataPath);
    
    const output = formatReport(options.format, data, options);
    
    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Unsupported format')) {
        console.error('Error: Unsupported format');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error(`Error: ${String(error)}`);
    }
    process.exit(1);
  }
}

main();
