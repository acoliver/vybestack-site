import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { ReportData, ReportOptions } from '../types.js';

export const formatters = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export type FormatterName = keyof typeof formatters;

export function formatReport(
  formatterName: FormatterName,
  data: ReportData,
  options: ReportOptions
): string {
  const formatter = formatters[formatterName];
  if (!formatter) {
    throw new Error(`Unsupported format: ${formatterName}`);
  }
  return formatter(data, options);
}