import { ReportData, ReportOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  const { title, summary, entries } = data;
  
  let result = `# ${title}\n\n`;
  result += `${summary}\n\n`;
  result += `## Entries\n`;
  
  for (const entry of entries) {
    const amount = entry.amount.toFixed(2);
    result += `- **${entry.label}** — $${amount}\n`;
  }
  
  if (options.includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n**Total:** $${total.toFixed(2)}\n`;
  }
  
  return result;
}