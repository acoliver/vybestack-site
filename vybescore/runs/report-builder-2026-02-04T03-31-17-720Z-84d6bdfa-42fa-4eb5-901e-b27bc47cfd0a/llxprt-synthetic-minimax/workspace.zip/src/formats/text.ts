import { ReportData, ReportOptions } from '../types.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  const { title, summary, entries } = data;
  
  let result = `${title}\n`;
  result += `${summary}\n`;
  result += `Entries:\n`;
  
  for (const entry of entries) {
    const amount = entry.amount.toFixed(2);
    result += `- ${entry.label}: $${amount}\n`;
  }
  
  if (options.includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `Total: $${total.toFixed(2)}\n`;
  }
  
  return result;
}