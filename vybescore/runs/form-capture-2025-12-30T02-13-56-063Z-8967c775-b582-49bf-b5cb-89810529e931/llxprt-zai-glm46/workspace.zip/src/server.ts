import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');
const PUBLIC_PATH = path.resolve(__dirname, '..', 'public');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
let db: Database | null = null;
let dbInitialized = false;

// Validation regex patterns
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\+?[\d\s\-()]+$/;
const POSTAL_CODE_REGEX = /^[\dA-Za-z\s-]+$/;

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required.');
  }
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required.');
  }
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required.');
  }
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required.');
  }
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required.');
  }
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required.');
  } else if (!POSTAL_CODE_REGEX.test(data.postalCode.trim())) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens.');
  }
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required.');
  }
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required.');
  } else if (!EMAIL_REGEX.test(data.email.trim())) {
    errors.push('Please enter a valid email address.');
  }
  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required.');
  } else if (!PHONE_REGEX.test(data.phone.trim())) {
    errors.push('Phone number may contain digits, spaces, parentheses, dashes, and an optional leading +.');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, buffer);
  }

  dbInitialized = true;
  return dbInstance;
}

function saveDatabase(): void {
  if (!db) return;
  
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use('/public', express.static(PUBLIC_PATH));

app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

app.get('/', (_req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  if (!db) {
    console.error('Database not initialized');
    return res.status(500).send('Internal server error');
  }

  try {
    db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]
    );

    saveDatabase();

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).send('Failed to save submission');
  }
});

app.get('/thank-you', (_req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

async function startServer(): Promise<void> {
  try {
    db = await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    const gracefulShutdown = (signal: string): void => {
      console.log(`\n${signal} received, shutting down gracefully...`);
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        console.log('Server closed.');
        process.exit(0);
      });

      setTimeout(() => {
        console.error('Forced shutdown after timeout.');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export a function to initialize the database for tests
export async function ensureDatabaseInitialized(): Promise<void> {
  if (!dbInitialized) {
    db = await initDatabase();
  }
}

// Only start the server when this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, db };
