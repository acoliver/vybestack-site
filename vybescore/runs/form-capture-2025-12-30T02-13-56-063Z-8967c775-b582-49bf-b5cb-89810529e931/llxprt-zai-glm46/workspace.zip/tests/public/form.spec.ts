import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: ReturnType<typeof import('http').createServer>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { app, ensureDatabaseInitialized } = await import('../../src/server.js');
  await ensureDatabaseInitialized();
  server = app.listen(0);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']?.includes('text/html')).toBe(true);

    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('label[for="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('label[for="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('label[for="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('label[for="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('label[for="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('label[for="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    expect($('label[for="phone"]')).toHaveLength(1);
  });

  it('shows validation errors for empty form submission', async () => {
    const response = await request(server).post('/submit').type('form').send({});
    expect(response.status).toBe(400);

    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('First name is required');
    expect(errorText).toContain('Last name is required');
    expect(errorText).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'not-an-email',
        phone: '+44 20 7946 0958'
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'john@example.com',
        phone: 'invalid-phone!'
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Another Rd',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'jane@example.com',
        phone: '+54 9 11 1234-5678'
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank you page', async () => {
    const response = await request(server).get('/thank-you');
    expect(response.status).toBe(200);

    const $ = cheerio.load(response.text);
    expect($('.thankyou-card').text()).toContain('Thank you');
    expect($('.thankyou-card').text()).toContain('stranger on the internet');
    expect($('a[href="/"]')).toHaveLength(1);
  });

  it('preserves form values on validation error', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test St',
        city: 'Paris',
        stateProvince: 'Île-de-France',
        postalCode: '75001',
        country: 'France',
        email: 'test@example.com',
        phone: ''
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('#firstName').val()).toBe('Test');
    expect($('#lastName').val()).toBe('User');
    expect($('#city').val()).toBe('Paris');
    expect($('#email').val()).toBe('test@example.com');
  });
});
