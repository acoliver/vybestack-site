/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure there's exactly one space after sentence-ending punctuation
  // This pattern handles multiple spaces and ensures one space
  let result = text.replace(/([.?!])\s+/g, '$1 ');
  
  // Add a space after sentence-ending punctuation if missing
  result = result.replace(/([.?!])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize the first letter of each sentence
  // This regex finds the first letter after sentence-ending punctuation or at the start of the string
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // This pattern matches URLs with http/https schemes
  // It excludes trailing punctuation like .,!,?,;,),]
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^\s.,!?)\];]/gi;
  const matches = text.match(urlRegex);
  return matches ? Array.from(new Set(matches)) : []; // Remove duplicates
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not if it's already https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs starting with http:// and check if the path begins with /docs/
  // It skips rewriting if the path contains dynamic indicators like cgi-bin, query strings, or legacy extensions
  return text.replace(
    /http:\/\/([a-zA-Z0-9.-]+)(\/docs\/[^\s.,!?)\];]*)/gi,
    (match, host, path) => {
      // Skip host rewrite for dynamic paths or paths with query parameters/legacy extensions
      if (path.match(/(cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i) || 
          match.includes('?') || match.includes('&') || match.includes('=')) {
        return `https://${host}${path}`;
      }
      
      // For docs paths, rewrite to docs.example.com
      return `https://docs.${host}${path}`;
    }
  );
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format with validation for month and day ranges
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Additional validation for realistic month/day combinations
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for days in month
  // This isn't comprehensive (doesn't account for leap years) but covers common cases
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}