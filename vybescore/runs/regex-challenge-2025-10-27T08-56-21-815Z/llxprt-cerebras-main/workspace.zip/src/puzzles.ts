/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // but excludes the exception words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const exceptionsPattern = exceptions.map(word => 
    word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  ).join('|');
  
  // Pattern explanation:
  // \b - word boundary
  // ${escapedPrefix} - the prefix we're looking for
  // \w* - zero or more word characters
  // Exclude exceptions with negative lookahead
  const regex = new RegExp(`\\b${escapedPrefix}(?!(${exceptionsPattern})\\b)\\w*`, 'gi');
  
  const matches = text.match(regex);
  return matches ? Array.from(new Set(matches)) : []; // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern explanation:
  // (?<=\\d) - positive lookbehind for a digit (ES2018 feature)
  // ${escapedToken} - the token we're looking for
  // Since test expects the matched result to include the digit, we should match both digit and token
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(regex);
  return matches ? Array.from(new Set(matches)) : []; // Remove duplicates
}

/**
 * Validate passwords according to the policy.
 */
export function isStrongPassword(value: string): boolean {
  // Check if at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase, lowercase, digit, and symbol
  if (!/[A-Z]/.test(value) || 
      !/[a-z]/.test(value) || 
      !/\d/.test(value) || 
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This pattern looks for any sequence of 2+ characters that immediately repeats
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it contains IPv4 pattern, if so return false
  const ipv4Regex = /(\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // This pattern matches IPv6 addresses including shorthand :: notation
  // It requires at least two colons to distinguish from IPv4
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/g;
  
  return ipv6Regex.test(value);
}