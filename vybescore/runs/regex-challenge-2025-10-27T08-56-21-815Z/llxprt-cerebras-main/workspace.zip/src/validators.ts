export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Pattern explanation:
  // - Local part: Allow letters, digits, and special characters +, -, _, . but not consecutive dots or trailing dots
  // - Domain part: Allow letters, digits, hyphens but not underscores or consecutive dots
  // - TLD: At least 2 characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for consecutive dots or trailing dots in local part
  if (value.includes('..') || value.startsWith('.') || value.split('@')[0].endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common separators and optional +1 prefix.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if too short (must be at least 10 digits)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Check if it has 11 digits and starts with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Check if it has more than 11 digits
  if (digitsOnly.length > 11) {
    return false;
  }
  
  // Impossible area codes (leading 0 or 1)
  const areaCode = digitsOnly.length === 11 ? digitsOnly.substring(1, 4) : digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Pattern for US phone number formats
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for digit analysis
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const argPhoneRegex = /^(\+54\s?)?(0?[9]?\s?)?([1-9]\d{1,3})\s?(\d{6,8})$/;
  
  // Check if pattern matches
  if (!argPhoneRegex.test(cleanValue)) {
    return false;
  }
  
  // Extract area code and subscriber number
  const match = cleanValue.match(argPhoneRegex);
  if (!match) return false;
  
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode.charAt(0) === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, the number must begin with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern to match unicode letters, spaces, hyphens, and apostrophes
  const nameRegex = /^[\p{L}\s\-']+$/u;
  
  // Reject names with digits or symbols (except the allowed ones)
  // This will reject names like "X Æ A-12" which contain digits
  return nameRegex.test(value) && !/\d/.test(value);
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Visa: Starts with 4, 13 or 16 digits
  // Mastercard: Starts with 5, 16 digits
  // AmEx: Starts with 34 or 37, 15 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the card patterns
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanValue);
}