import { ReportData, CLIOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function renderMarkdown(data: ReportData, options: CLIOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('## Entries');
  
  // Bullet list of entries
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Optional total
  if (options.includeTotals) {
    lines.push('');
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}