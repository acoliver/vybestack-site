import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  options: CLIOptions;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  if (args.length < 3) {
    console.error('Error: format value is required');
    process.exit(1);
  }
  
  const format = args[2] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }
  
  const options: CLIOptions = {
    format,
    includeTotals: false
  };
  
  // Parse remaining arguments
  let i = 3;
  while (i < args.length) {
    switch (args[i]) {
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path value');
          process.exit(1);
        }
        options.output = args[i + 1];
        i += 2;
        break;
      case '--includeTotals':
        options.includeTotals = true;
        i += 1;
        break;
      default:
        console.error(`Error: Unknown argument '${args[i]}'`);
        process.exit(1);
    }
  }
  
  return { dataFile, options };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Report data must be a JSON object');
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Report data missing required field: title (string)');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Report data missing required field: summary (string)');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Report data missing required field: entries (array)');
  }
  
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i] as Record<string, unknown>;
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Entry ${i + 1} missing required field: label (string)`);
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error(`Entry ${i + 1} missing required field: amount (number)`);
    }
  }
  
  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    validateReportData(data);
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        console.error(`Error: Cannot find file '${filePath}'`);
      } else if (error.message.startsWith('Unexpected token')) {
        console.error(`Error: Invalid JSON in file '${filePath}'`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error(`Error: Failed to read or parse file '${filePath}'`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to file '${outputPath}'`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const { dataFile, options } = parseArgs(process.argv);
  const data = loadReportData(dataFile);
  const output = renderReport(data, options);
  writeOutput(output, options.output);
}

main();