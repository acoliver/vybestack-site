import type { ReportData, RenderOptions } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

/**
 * Supported report formats
 */
export type ReportFormat = 'markdown' | 'text';

/**
 * Map of format names to their renderer functions
 */
export const formatters: Record<ReportFormat, (data: ReportData, options?: RenderOptions) => string> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Validates and returns a format name
 * @throws Error if the format is not supported
 */
export function validateFormat(format: string): ReportFormat {
  if (format === 'markdown' || format === 'text') {
    return format;
  }
  throw new Error(`Unsupported format: ${format}`);
}
