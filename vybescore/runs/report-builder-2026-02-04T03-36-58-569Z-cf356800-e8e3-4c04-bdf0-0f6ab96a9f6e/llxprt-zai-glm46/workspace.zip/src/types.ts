/**
 * Represents a single entry in the report
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * The structure of the input JSON data for reports
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering the report
 */
export interface RenderOptions {
  includeTotals?: boolean;
}

/**
 * Validates and parses report data from an unknown object
 * @throws Error if the data is invalid or missing required fields
 */
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid input: data must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid input: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid input: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid input: missing or invalid "entries" field (must be an array)');
  }

  const entries: ReportEntry[] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid input: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid input: entry at index ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid input: entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }

    entries.push({ label: entryObj.label, amount: entryObj.amount });
  }

  return { title: obj.title, summary: obj.summary, entries };
}

/**
 * Calculates the total of all entry amounts
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Formats a number as currency with exactly 2 decimal places
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}
