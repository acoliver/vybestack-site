#!/usr/bin/env node

import * as fs from 'node:fs/promises';
import { validateReportData } from '../types.js';
import { formatters, validateFormat } from '../formatters.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command line arguments using Node's standard library
 */
function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2); // Skip node executable and script path

  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  const options: CliArgs = {
    inputFile,
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  // Parse options
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      options.format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      options.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!options.format) {
    throw new Error('--format is required');
  }

  return options;
}

/**
 * Main CLI execution function
 */
async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const args = parseArgs(process.argv);

    // Read and parse the input JSON file
    let jsonData: unknown;
    try {
      const fileContent = await fs.readFile(args.inputFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Failed to parse JSON file: ${error.message}`);
      }
      const err = error as NodeJS.ErrnoException;
      if (err.code === 'ENOENT') {
        throw new Error(`File not found: ${args.inputFile}`);
      }
      throw error;
    }

    // Validate the report data
    const reportData = validateReportData(jsonData);

    // Validate the format and get the renderer
    const format = validateFormat(args.format);

    // Render the report
    const renderOptions: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    const output = formatters[format](reportData, renderOptions);

    // Write output
    if (args.outputPath) {
      await fs.writeFile(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }
}

// Run the CLI
main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});
