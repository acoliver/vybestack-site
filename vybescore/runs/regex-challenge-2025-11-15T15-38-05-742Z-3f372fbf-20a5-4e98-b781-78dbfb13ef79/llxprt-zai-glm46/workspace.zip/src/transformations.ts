/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!), insert exactly one space between sentences even if the input omitted it,
  // and collapse extra spaces sensibly while leaving abbreviations intact when possible.
  
  // First, normalize spacing: replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing (but not for common abbreviations)
  // Look for punctuation followed by lowercase letter without space, but exclude common abbreviations
  const abbreviationPattern = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|etc|e\.g|i\.e|vs|U\.S|U\.K)\.?/i;
  
  normalized = normalized.replace(/([.!?])([a-z])/g, (match, punctuation, letter, offset, fullText) => {
    // Check if the punctuation is part of an abbreviation
    const beforeMatch = fullText.substring(0, offset + punctuation.length);
    if (abbreviationPattern.test(beforeMatch)) {
      return punctuation + letter; // Don't add space if it's an abbreviation
    }
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Capitalize first letter of each sentence
  // Sentence starts: beginning of string or after .!? followed by whitespace
  normalized = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  // Ensure first character is capitalized
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  return normalized;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Return all URLs detected in the text without trailing punctuation
  // This regex matches URLs with query parameters, fragments, and paths
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?:\/[^\s)]*)?(?:\?[^\s)]*)?(?:#[^\s)]*)?/g;
  
  const matches = text.match(urlRegex);
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation but keep query parameters and fragments
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    // Only remove punctuation at the very end, not within the URL
    return url.replace(/[.,;!?)\]}]+$/g, '');
  });
}

/**
 * TODO: Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  return text.replace(/http:\/\//g, 'https://');
}
/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://
  // - When the path begins with /docs/, rewrite the host to docs.example.com
  // - Skip the host rewrite when the path contains dynamic hints (cgi-bin, query strings, legacy extensions)
  // - Preserve nested paths
  
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)?/g, (match, domain, path) => {
    // Always upgrade to https
    let result = 'https://' + domain;
    
    if (path) {
      // Check if we should skip host rewrite
      const skipPatterns = [
        /\/cgi-bin/,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/
      ];
      
      const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
      
      // Check if path starts with /docs and we shouldn't skip
      if (path.startsWith('/docs') && !shouldSkip) {
        // Rewrite to docs.example.com keeping the rest of the path
        result = 'https://docs.' + domain + path;
      } else {
        // Just upgrade the scheme, keep original domain and path
        result = 'https://' + domain + path;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy. If the string doesn't match that format or month/day are invalid, return 'N/A'.
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day ranges for specific months (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Adjust for leap year (February 29th)
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  if (isLeapYear) {
    daysInMonth[1] = 29; // February
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
