/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  const wordRegex = new RegExp(`\\b${prefix}\\w+\\b`, 'g');
  
  const matchedWords = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(word => word.toLowerCase());
  
  return matchedWords
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string (use lookaheads/lookbehinds)
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences
  
  // Minimum length 10
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab)
  // Check for any 2-4 character pattern that repeats immediately
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
  
  // IPv6 pattern includes:
  // - Full form: 8 groups of 4 hex digits separated by colons
  // - Compressed form: with :: for consecutive zero groups
  // - Mixed form: IPv4 embedded in IPv6
  // - Leading zeros can be omitted
  // - Single colon separator
  
  const ipv6Regex = /(?<![\d.])((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?![\d.])/g;
  
  // First, exclude IPv4 addresses that might match partial patterns
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If the entire value is a valid IPv4, return false
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // Check for IPv6 patterns
  return ipv6Regex.test(value);
}
