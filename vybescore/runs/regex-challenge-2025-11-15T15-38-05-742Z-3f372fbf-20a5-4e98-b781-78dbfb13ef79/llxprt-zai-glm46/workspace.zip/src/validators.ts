export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject double dots, trailing dots, domains with underscores, and other obviously invalid forms
  // Accept typical addresses such as name+tag@example.co.uk
  
  // Basic email structure with stricter rules
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Split email into local part and domain
  const [localPart, domain] = value.split('@');
  
  // No consecutive dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Domain should not start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Local part should not start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Local part should not have consecutive dots
  if (localPart.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
// Check for extensions if allowed in options
  if (options?.allowExtensions) {
    const extensionRegex = /^(.+?)(?:\s+(?:ext\.?|x|#)\s*(\d+))?$/i;
    const extensionMatch = value.match(extensionRegex);
    if (extensionMatch && extensionMatch[2]) {
      // Strip extension for base validation
      value = extensionMatch[1];
    }
  }
  // Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  // Remove all non-digit characters for basic length check
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be at least 10 digits (US number) or 11 if starting with 1 (country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(?([2-9]\d{2})\)?[\s-]?)([2-9]\d{2})[\s-]?(\d{4})$/;
  const match = value.match(phoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  
  // Area code should not start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  // - Optional country code +54
  // - Optional trunk prefix 0 immediately before the area code
  // - Optional mobile indicator 9 between country/trunk and the area code
  // - Area code must be 2-4 digits (leading digit 1-9)
  // - Subscriber number (after the area code) must contain 6-8 digits in total
  // - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
  // - Allow single spaces or hyphens as separators; ignore punctuation when validating
  
  // Remove all spaces and hyphens for validation
  const clean = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  let remaining = clean;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check for optional trunk prefix 0
  let hasTrunkPrefix = false;
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }
  
  // Check for optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  remaining = remaining.slice(areaCode.length);
  
  // Remaining should be the subscriber number (6-8 digits)
  const subscriberNumber = remaining;
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix 0 before area code
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Validate that we've consumed the entire input
  if (subscriberNumber.match(/\D/)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must match the basic pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  const trimmed = value.trim();
  
  // Must not be empty
  if (!trimmed) {
    return false;
  }
  
  // Should not have consecutive apostrophes or hyphens
  if (trimmed.includes("''") || trimmed.includes('--')) {
    return false;
  }
  
  // Should not start or end with apostrophe or hyphen
  if (trimmed.startsWith("'") || trimmed.endsWith("'") || 
      trimmed.startsWith("-") || trimmed.endsWith("-")) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers using Luhn checksum and basic format checks.
 */
export function isValidCreditCard(value: string): boolean {
  // Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check against known card patterns
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
