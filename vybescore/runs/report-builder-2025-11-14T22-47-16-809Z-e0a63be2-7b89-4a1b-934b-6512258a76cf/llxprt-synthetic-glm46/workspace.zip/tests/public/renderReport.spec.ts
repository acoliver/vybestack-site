import { describe, expect, it, afterEach } from 'vitest';
import { execSync } from 'child_process';
import { readFileSync, unlinkSync, existsSync } from 'fs';
import { join } from 'path';

describe('report CLI (public smoke)', () => {
  const cliPath = 'dist/cli/report.js';
  const testDataPath = 'fixtures/data.json';
  const tempOutputPath = join('/tmp', 'test-report-output.md');

  afterEach(() => {
    if (existsSync(tempOutputPath)) {
      unlinkSync(tempOutputPath);
    }
  });

  it('renders markdown format', () => {
    const output = execSync(`node ${cliPath} ${testDataPath} --format markdown`, {
      encoding: 'utf8',
    });
    
    expect(output).toContain('# Quarterly Financial Summary');
    expect(output).toContain('Highlights include record revenue');
    expect(output).toContain('## Entries');
    expect(output).toContain('**North Region** — $12345.67');
  });

  it('renders text format', () => {
    const output = execSync(`node ${cliPath} ${testDataPath} --format text`, {
      encoding: 'utf8',
    });
    
    expect(output).toContain('Quarterly Financial Summary');
    expect(output).toContain('Highlights include record revenue');
    expect(output).toContain('Entries:');
    expect(output).toContain('- North Region: $12345.67');
  });

  it('includes totals when requested', () => {
    const output = execSync(`node ${cliPath} ${testDataPath} --format markdown --includeTotals`, {
      encoding: 'utf8',
    });
    
    expect(output).toContain('**Total:** $70370.34');
  });

  it('writes to output file when specified', () => {
    execSync(`node ${cliPath} ${testDataPath} --format markdown --output ${tempOutputPath}`);
    
    const output = readFileSync(tempOutputPath, 'utf8');
    expect(output).toContain('# Quarterly Financial Summary');
    expect(output).toContain('## Entries');
  });

  it('fails with invalid format', () => {
    expect(() => {
      execSync(`node ${cliPath} ${testDataPath} --format unknown`, {
        encoding: 'utf8',
      });
    }).toThrow();
  });

  it('fails with missing file', () => {
    expect(() => {
      execSync(`node ${cliPath} fixtures/nonexistent.json --format markdown`, {
        encoding: 'utf8',
      });
    }).toThrow();
  });

  it('fails with invalid JSON', () => {
    expect(() => {
      execSync(`node ${cliPath} fixtures/bad-file.json --format markdown`, {
        encoding: 'utf8',
      });
    }).toThrow();
  });
});
