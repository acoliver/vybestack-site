#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[2];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the output value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: must be an object');
  }

  const dataObj = data as Record<string, unknown>;

  if (!dataObj.title || typeof dataObj.title !== 'string') {
    throw new Error('Invalid JSON: title is required and must be a string');
  }

  if (!dataObj.summary || typeof dataObj.summary !== 'string') {
    throw new Error('Invalid JSON: summary is required and must be a string');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid JSON: entries is required and must be an array');
  }

  for (let i = 0; i < dataObj.entries.length; i++) {
    const entry = dataObj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} must have a string label`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry at index ${i} must have a valid number amount`);
    }
  }

  return dataObj as unknown as ReportData;
}

function main() {
  try {
    const args = parseArgs(process.argv);

    // Read and validate JSON data
    let data;
    try {
      const jsonData = readFileSync(args.dataPath, 'utf8');
      data = JSON.parse(jsonData);
    } catch (error) {
      if (error instanceof Error && error.message.includes('ENOENT')) {
        console.error(`Error: File not found: ${args.dataPath}`);
      } else if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file: ${args.dataPath}`);
      } else {
        console.error(`Error reading file: ${error}`);
      }
      process.exit(1);
    }

    const reportData = validateReportData(data);

    // Select renderer based on format
    let renderer;
    switch (args.format) {
      case 'markdown':
        renderer = markdownRenderer;
        break;
      case 'text':
        renderer = textRenderer;
        break;
      default:
        console.error(`Error: Unsupported format: ${args.format}`);
        process.exit(1);
    }

    // Render report
    const renderOptions: RenderOptions = { includeTotals: args.includeTotals };
    const output = renderer.render(reportData, renderOptions);

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}