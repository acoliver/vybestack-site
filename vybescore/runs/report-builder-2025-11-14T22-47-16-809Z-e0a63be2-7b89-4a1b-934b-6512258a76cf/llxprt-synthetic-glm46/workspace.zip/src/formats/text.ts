import { ReportData, ReportRenderer, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options?: RenderOptions): string {
  let output = '';

  // Add title
  output += `${data.title}\n\n`;

  // Add summary
  output += `${data.summary}\n\n`;

  // Add entries section
  output += `Entries:\n`;
  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    output += `- ${entry.label}: ${formattedAmount}\n`;
  }

  // Add total if requested
  if (options?.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    output += `\nTotal: ${formattedTotal}\n`;
  }

  return output;
}

export const textRenderer: ReportRenderer = {
  render: renderText,
};