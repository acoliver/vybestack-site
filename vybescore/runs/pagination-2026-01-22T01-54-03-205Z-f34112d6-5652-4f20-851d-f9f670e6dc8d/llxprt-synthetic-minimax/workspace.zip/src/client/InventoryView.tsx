import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  onPrevious, 
  onNext 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  onPrevious: () => void; 
  onNext: () => void; 
}): JSX.Element {
  return (
    <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
      <button 
        onClick={onPrevious}
        disabled={currentPage <= 1}
        style={{ 
          padding: '0.5rem 1rem', 
          background: currentPage <= 1 ? '#ccc' : '#007bff',
          color: currentPage <= 1 ? '#666' : 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: currentPage <= 1 ? 'not-allowed' : 'pointer'
        }}
      >
        Previous
      </button>
      
      <span style={{ padding: '0.5rem' }}>Page {currentPage}</span>
      
      <button 
        onClick={onNext}
        disabled={!hasNext}
        style={{ 
          padding: '0.5rem 1rem', 
          background: !hasNext ? '#ccc' : '#007bff',
          color: !hasNext ? '#666' : 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: !hasNext ? 'not-allowed' : 'pointer'
        }}
      >
        Next
      </button>
    </div>
  );
}

function ErrorDisplay({ error }: { error: string }): JSX.Element {
  return (
    <div role="alert" style={{ color: 'red', marginTop: '1rem' }}>
      <strong>Error:</strong> {error}
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePrevious = (): void => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = (): void => {
    if (data?.hasNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        {error && <ErrorDisplay error={error} />}
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      
      <PaginationControls 
        currentPage={currentPage}
        hasNext={data.hasNext}
        onPrevious={handlePrevious}
        onNext={handleNext}
      />
      
      <p style={{ marginTop: '0.5rem', color: '#666', fontSize: '0.9rem' }}>
        Showing page {data.page} of {Math.ceil(data.total / data.limit)} 
        ({data.items.length} of {data.total} items)
      </p>
    </section>
  );
}
