import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate query parameters
    const errors: string[] = [];
    
    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (Number.isNaN(pageNum)) {
        errors.push('page must be a number');
      } else if (pageNum < 1) {
        errors.push('page must be greater than 0');
      } else if (!Number.isInteger(pageNum)) {
        errors.push('page must be an integer');
      } else if (pageNum > 10000) {
        errors.push('page is too large');
      } else {
        page = Math.floor(pageNum);
      }
    }

    // Validate limit parameter  
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (Number.isNaN(limitNum)) {
        errors.push('limit must be a number');
      } else if (limitNum < 1) {
        errors.push('limit must be greater than 0');
      } else if (!Number.isInteger(limitNum)) {
        errors.push('limit must be an integer');
      } else if (limitNum > 100) {
        errors.push('limit is too large (maximum 100)');
      } else {
        limit = Math.floor(limitNum);
      }
    }

    // Return 400 for validation errors
    if (errors.length > 0) {
      res.status(400).json({
        error: 'Invalid query parameters',
        details: errors
      });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
