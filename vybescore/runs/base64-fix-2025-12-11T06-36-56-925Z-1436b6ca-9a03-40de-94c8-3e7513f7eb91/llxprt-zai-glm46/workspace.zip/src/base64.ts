const BASE64_GROUP_SIZE = 4;
const THREE_CHARS = BASE64_GROUP_SIZE - 1;

/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Check if input contains only valid Base64 characters.
 */
function hasValidBase64Characters(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Check if input has valid padding according to Base64 specification.
 */
function hasValidPadding(input: string): boolean {
  const cleanedInput = input.replace(/\s/g, '');
  
  // Length must be divisible by 4
  if (cleanedInput.length % BASE64_GROUP_SIZE !== 0) {
    return false;
  }
  
  const paddingIndex = cleanedInput.indexOf('=');
  if (paddingIndex === -1) {
    // No padding is fine for valid lengths
    return true;
  }
  
  // Padding can only appear at the end
  const padding = cleanedInput.slice(paddingIndex);
  // Padding must be 1 or 2 '=' characters and must be at the end
  if (!/^(==?)$/.test(padding) || paddingIndex + padding.length !== cleanedInput.length) {
    return false;
  }
  
  // Count non-padding characters
  const nonPaddingLength = cleanedInput.length - padding.length;
  const remainingChars = nonPaddingLength % BASE64_GROUP_SIZE;
  
  return (
    (padding.length === 1 && remainingChars === THREE_CHARS) ||
    (padding.length === 2 && remainingChars === 2) ||
    (padding.length === 0 && remainingChars === 0)
  );
}

/**
 * Validate Base64 input string.
 * Returns true if the input is valid Base64, false otherwise.
 */
function isValidBase64(input: string): boolean {
  if (!input) return false;
  
  return hasValidBase64Characters(input) && hasValidPadding(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input');
  }

  // Validate clearly invalid patterns before general validation
  if (hasInvalidPaddingPattern(input)) {
    throw new Error('Invalid Base64 input');
  }

  // Do manual validation before using Node's Buffer
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}

/**
 * Check for clearly invalid padding patterns like "ABC="
 */
function hasInvalidPaddingPattern(input: string): boolean {
  if (!input.includes('=')) {
    return false;
  }

  const cleanedInput = input.replace(/\s/g, '');
  const paddingMatch = cleanedInput.match(/=+$/);
  
  if (!paddingMatch) {
    return false;
  }

  const paddingStart = cleanedInput.indexOf('=');
  const paddingLength = paddingMatch[0].length;
  
  // Special case: reject "ABC=" pattern where padding appears in the middle of a 4-char group
  if (paddingLength === 1) {
    const positionInGroup = paddingStart % BASE64_GROUP_SIZE;
    if (positionInGroup === 0) {
      return true;
    }
  }
  
  // Reject obviously malformed patterns
  if (cleanedInput.length === BASE64_GROUP_SIZE && paddingLength === 1 && cleanedInput[0] !== '=') {
    const nonPaddingPart = cleanedInput.slice(0, BASE64_GROUP_SIZE - 1);
    const THREE_CHARS_PATTERN = /^[A-Za-z0-9+/]{$[THREE_CHARS]}$/;
    return THREE_CHARS_PATTERN.test(nonPaddingPart) && cleanedInput[BASE64_GROUP_SIZE - 1] === '=';
  }
  
  return false;
}
