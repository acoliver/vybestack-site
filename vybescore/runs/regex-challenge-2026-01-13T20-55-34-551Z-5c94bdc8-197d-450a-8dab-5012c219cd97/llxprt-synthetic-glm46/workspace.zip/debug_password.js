function isStrongPassword(value) {
  if (!value || value.length < 10) {
    console.log('Failed length check', value?.length);
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    console.log('Failed whitespace check');
    return false;
  }
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!"#$%&'()*+,\-./:;<=>?@[\\]^_`{|}~]/.test(value);
  
  console.log('Checks:', { hasUpper, hasLower, hasDigit, hasSymbol });
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    console.log('Failed character type check');
    return false;
  }
  
  // Only check for very obvious repeated patterns - disabled for now
  // if (/(..)\1/.test(value)) return false;
  
  return true;
}

console.log(isStrongPassword('Abcdef!234'));