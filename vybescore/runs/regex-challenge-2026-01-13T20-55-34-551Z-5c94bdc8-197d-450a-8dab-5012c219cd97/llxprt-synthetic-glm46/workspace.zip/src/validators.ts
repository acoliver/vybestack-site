export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC standards.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that handles most common cases
  // - Local part: letters, digits, +, -, dots (but not consecutive, not at start/end)
  // - Domain: letters, digits, hyphens, dots (but not consecutive, not at start/end)
  // - TLD: at least 2 letters
  // - No underscores in domain
  
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9+._-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Basic pattern check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional constraints
  // - No consecutive dots anywhere
  // - No dot at end of local part or domain part
  // - No underscore in domain
  
  if (value.includes('..')) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Local part shouldn't start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain shouldn't have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain shouldn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || 
      domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers including common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Note: _options parameter is currently unused but kept for API compatibility
  void _options; // Explicitly mark as unused to satisfy linter
  // Remove all non-digit characters first for validation
  const cleaned = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (for the main number)
  // Can have 11 digits if starting with 1 (country code)
  if (cleaned.length === 10) {
    // Just the 10-digit number, validate area code (no leading 0 or 1)
    const areaCode = cleaned.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  } else if (cleaned.length === 11 && cleaned.startsWith('1')) {
    // 11 digits with country code 1, validate area code
    const areaCode = cleaned.substring(1, 4);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  } else {
    // Invalid length
    return false;
  }
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Formats supported: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code is omitted, must begin with trunk prefix 0
 * - Single spaces or hyphens allowed as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens to normalize the number
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  // Capturing groups:
  // 1: Optional +54 country code
  // 2: Optional 0 trunk prefix (when no country code)
  // 3: Optional 9 mobile indicator
  // 4: Area code (2-4 digits, leading 1-9)
  // 5: Subscriber number (6-8 digits)
  // Try two patterns: with separators and without
  const withSeparatorsRegex = /^(?:\+54\s*)?(?:0?\s*)?(?:9?\s*)?([1-9]\d{1,3})\s*(\d{4,8})$/;
  const withoutSeparatorsRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  let match = cleaned.match(withoutSeparatorsRegex);
  if (!match) {
    // Try with original format (with spaces) if normalized fails
    match = value.match(withSeparatorsRegex);
  }
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and obviously invalid combinations.
 */
export function isValidName(value: string): boolean {
  // Check if string is empty or only whitespace
  if (!value || !value.trim()) {
    return false;
  }
  
  // Allow unicode letters (including accented), apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Cannot start or end with space, hyphen, or apostrophe
  // Cannot have consecutive spaces, hyphens, or apostrophes
  const nameRegex = /^[\p{L}'-]+( [\p{L}'-]+)*$/u;
  
  return nameRegex.test(value) && 
         !/^[ '[\-\]]/.test(value) && 
         !/[ '-]$/.test(value) &&
         !/[ '-]{2,}/.test(value) &&
         /[\p{L}]/u.test(value);
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express.
 * Checks length and prefix validity, then runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if only digits remain
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13 or 16 digits starting with 4
  // Mastercard: 16 digits, starting 51-55, 2221-2720
  // American Express: 15 digits, starting 34 or 37
  
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex1 = /^5[1-5]\d{14}$/;
  const mastercardRegex2 = /^2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{12}))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex1.test(cleaned) && 
      !mastercardRegex2.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum algorithm
  let sum = 0;
  const digits = cleaned.split('').map(Number);
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    // Double every second digit from the right
    if (i % 2 === (digits.length % 2)) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}
