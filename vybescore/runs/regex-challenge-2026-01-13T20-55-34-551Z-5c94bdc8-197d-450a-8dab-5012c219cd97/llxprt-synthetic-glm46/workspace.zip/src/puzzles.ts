/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex pattern to find words with the specified prefix
  // Word boundaries to capture完整 words
  const wordPattern = new RegExp(`\\b(${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*)`, 'g');
  
  const matches = text.match(wordPattern);
  if (!matches) return [];
  
  // Remove duplicates and filter out exceptions
  const uniqueWords = [...new Set(matches)]
    .filter(word => !exceptions.includes(word.toLowerCase()));
  
  return uniqueWords;
}

/**
 * Find occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to find the token in the right context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create regex pattern to find token that:
  // 1. Is not at the start of the string
  // 2. Has a digit immediately before it
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern);
  return matches ? [...matches] : [];
}

/**
 * Validate password strength based on criteria:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*(),.?":{}|<>]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // Only check for very obvious repeated patterns - disabled for now
  // if (/(..)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 address patterns:
  // 1. Full format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. Shorthand with :: compression
  // 3. Can include IPv4 style suffix (e.g., ::ffff:192.168.1.1)
  // 4. Leading zeros optional, can be lowercase
  
  // Full IPv6 pattern (8 groups of 1-4 hex digits)
  const fullIPv6Regex = /^([0-9a-f]{1,4}:){7}[0-9a-f]{1,4}$/i;
  
  // Compressed IPv6 with :: (at least one group collapsed)
  const compressedIPv6Regex = /^([0-9a-f]{1,4}:)*:[0-9a-f]{0,4}(:[0-9a-f]{1,4})*$/i;
  
  // IPv6 with embedded IPv4
  const ipv6WithIpv4Regex = /^([0-9a-f]{1,4}:)*:([0-9]{1,3}\.){3}[0-9]{1,3}$/i;
  const compressedIPv6WithIPv4Regex = /^([0-9a-f]{1,4}:)*:([0-9]{1,3}\.){3}[0-9]{1,3}$/i;
  
  // Extract potential IP addresses from text
  const potentialIPRegex = /\b[0-9a-f:.]+\b/gi;
  const matches = value.match(potentialIPRegex);
  
  if (!matches) return false;
  
  // Check each match for IPv6 pattern
  for (const match of matches) {
    // Skip if it looks like an IPv4 address
    const ipv4Regex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
    if (ipv4Regex.test(match)) continue;
    
    // Check if it matches IPv6 patterns
    if (fullIPv6Regex.test(match) || 
        compressedIPv6Regex.test(match) || 
        ipv6WithIpv4Regex.test(match) || 
        compressedIPv6WithIPv4Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}
