/**
 * Capitalize the first character of each sentence.
 * Rules:
 * - Capitalize after . ? ! punctuation marks
 * - Insert exactly one space between sentences if missing
 * - Collapse extra spaces intelligently
 * - Keep abbreviations intact when possible (common short ones)
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Common abbreviations to preserve (short ones) - simplified for regex safety
  const commonAbbrs = /(?:(?:Mr|Mrs|Ms|Dr|St|Ave|Blvd|Rd|Lt|Col|Gen|Hon|Jr|Sr|Rep|Sen|Rev|Fr|Prof|Capt|Cmdr|Lt|Pvt|Pfc|Maj|Sgt|Adm|Vice|Pres|Gov|Atty|U\.S|A\.M|P\.M|B\.C|A\.D|etc|vs|al|ie|eg|cf|ibid|viz|ft|oz|lb|mm|kg|km|mph|hp|tv|cd|dvd|pc|cpu|ram|usb|pdf|jpg|png|gif|html|css|js|ts|xml|json|api|url|http|https|www|com|org|net|edu|gov|mil|int|ai|ml|nlp|ui|ux|cli|ide|sdk|git|svn|css|html|js|ts|sql|db|ci|cd|devops|aws|azure|gcp|ios|android|windows|mac|linux|unix|posix|utf|ascii|base64|md5|sha|rsa|aes|ssl|tls|tcp|ip|dns|dhcp|nat|vpn|vlan|wifi|bluetooth|usb|hdmi|typec|lightning|firewire|parallel|serial|vga|rj45|rj11|bnc|sma|smb|pcie|agp|isa|pci|eisa|vhdl|verilog|spice|matlab|python|java|javascript|typescript|c|cpp|php|ruby|perl|bash|shell|powershell|batch|swift|kotlin|scala|rust|go|dart|flutter|react|angular|vue|svelte|backbone|ember|jquery|bootstrap|tailwind|material|bulma|foundation|semantic|ant|prime|element|chakra|mui|next|nuxt|gatsby|remix|sveltekit|astro|solid|qwik|alpine|stimulus|hotwire|rails|django|flask|express|koa|hapi|nest|laravel|symfony|cake|codeigniter|yii|spring|play|asp|wp|drupal|joomla|magento|shopify|bigcommerce|woocommerce|opencart|zen|cubecart|prestashop|bigcartel|ecwid|squarespace|wix|weebly|webflow|bubble|adalo|bravo|glide|appsheet|powerapps|outsystems|mendix|bettyblocks|appian|kissflow|quickbase|airtable|notion|clickup|asana|trello|jira|confluence|slack|teams|zoom|meet|webex|skype|whatsapp|telegram|signal|discord|twitter|facebook|instagram|linkedin|tiktok|snapchat|pinterest|reddit|youtube|vimeo|twitch|spotify|apple|music|soundcloud|deezer|pandora|iheartradio|tunein|lastfm|napster|bandcamp|mixcloud|audiomack|musicbed|artlist|epidemic|audiojungle|pond5|shutterstock|getty|istock|adobe|stock|unsplash|pexels|pixabay|freeimages|photobucket|flickr|behance|dribbble)\.)/i;
  
  // Step 1: Normalize whitespace around punctuation
  let result = text
    // Replace multiple spaces with single space
    .replace(/[ \t]+/g, ' ')
    // Add space after punctuation if missing (keep common abbreviations)
    .replace(/([.!?])(?![ \n])/g, (_, punct) => {
      // Look ahead to check if this is an abbreviation
      const beforeMatch = text.substring(0, text.indexOf(punct) + 1).match(/\w+$/);
      if (beforeMatch && commonAbbrs.test(beforeMatch[0] + punct)) {
        return punct; // No space after abbreviation
      }
      return punct + ' ';
    })
    // Remove space before punctuation
    .replace(/ ([.!?])/g, (_, punct) => punct)
    // Replace multiple spaces with single space
    .replace(/ +/g, ' ')
    // Trim leading/trailing spaces
    .trim();
  
  // Step 2: Capitalize first letter of sentences
  if (result.length > 0) {
    // Always capitalize first character
    result = result[0].toUpperCase() + result.substring(1);
    
    // Capitalize after sentence punctuation (considering abbreviations)
    const punctuationRegex = /([.!?])([^.!?]*)/g;
    result = result.replace(punctuationRegex, (match, punct, followingText) => {
      // Get the context before this punctuation to check if it's an abbreviation
      const fullStopIndex = result.indexOf(match);
      if (fullStopIndex > 0) {
        const beforePunct = result.substring(0, fullStopIndex);
        const wordBeforePunct = beforePunct.match(/\w+$/);
        
        // If the word before punctuation looks like an abbreviation, don't capitalize
        if (wordBeforePunct && commonAbbrs.test(wordBeforePunct[0] + punct)) {
          return match;
        }
      }
      
      // Find the first letter and capitalize it
      const firstLetter = followingText.match(/[a-zA-Z\u00C0-\u00FF]/);
      if (firstLetter) {
        const index = followingText.indexOf(firstLetter[0]);
        return punct + followingText.substring(0, index) + firstLetter[0].toUpperCase() + followingText.substring(index + 1);
      }
      
      return match;
    });
  }
  
  return result;
}

/**
 * Extract URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern - matches http/https, www, domain TLDs
  const urlRegex = /(?:https?:\/\/|www\.)[^<>'"()\s]+/g;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation but keep the URL structure
    return url.replace(/[).!?;:,]+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but don't affect existing https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs according to rules:
 * - Always upgrade http to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, or legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/https?:\/\/([^/\s]+)(\/[^\s]*)?/g, (match, host, path = '') => {
    // Always upgrade to https
    const httpsUrl = match.startsWith('http://') ? `https://` + match.substring(7) : match;
    
    // Check if we should rewrite the host for docs paths
    if (path && path.startsWith('/docs/')) {
      // Check for exclusions that prevent host rewrite
      const excludedPatterns = [/\/cgi-bin\//, /[?&=]/, /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/];
      const shouldSkipRewrite = excludedPatterns.some(pattern => pattern.test(path));
      
      if (!shouldSkipRewrite) {
        // Rewrite host to docs.example.com
        return httpsUrl.replace(/^https:\/\/[^/]+/, `https://docs.${host}`);
      }
    }
    
    return httpsUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Check for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Additional validation for month/day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Basic validation for days per month (ignoring leap years for simplicity)
  const daysInMonth = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > (daysInMonth[monthNum as keyof typeof daysInMonth] || 0)) {
    return 'N/A';
  }
  
  return year;
}
