import type { ReportData, RenderOptions } from '../types/index.js';

export function formatText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];
  
  // Add title
  lines.push(data.title);
  lines.push(''); // blank line
  
  // Add summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Add entries heading
  lines.push('Entries:');
  
  // Add each entry as bullet list
  data.entries.forEach(entry => {
    const amount = entry.amount.toFixed(2);
    lines.push(`- ${entry.label}: $${amount}`);
  });
  
  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}