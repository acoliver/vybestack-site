export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CliOptions {
  inputPath: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}