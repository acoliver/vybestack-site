import { readFileSync, writeFileSync } from 'node:fs';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';
import type { ReportData, CliOptions } from '../types/index.js';

function parseArgs(args: string[]): CliOptions {
  const options: Partial<CliOptions> & { dataFile?: string } = { includeTotals: false };
  
  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format': {
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value (markdown or text)');
        }
        const format = args[i + 1];
        if (format !== 'markdown' && format !== 'text') {
          throw new Error(`Unsupported format: ${format}`);
        }
        options.format = format;
        i++; // skip next argument as it's the format value
        break;
      }
      case '--output': {
        if (i + 1 >= args.length) {
          throw new Error('--output requires a file path');
        }
        options.output = args[i + 1];
        i++; // skip next argument as it's the output path
        break;
      }
      case '--includeTotals': {
        options.includeTotals = true;
        break;
      }
      default: {
        if (!options.dataFile) {
          options.dataFile = arg;
        }
        break;
      }
    }
  }
  
  if (!options.dataFile) {
    throw new Error('Missing data file argument');
  }
  
  if (!options.format) {
    throw new Error('Missing --format argument');
  }
  
  return options as CliOptions;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root is not an object');
  }
  
  const report = data as Record<string, unknown>;
  
  // Check required fields
  if (!report.title || typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }
  
  if (!report.summary || typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }
  
  if (!report.entries || !Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }
  
  // Validate entries
  const entries = report.entries as unknown[];
  const validatedEntries = entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${index + 1} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${index + 1} missing or invalid "label" field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${index + 1} missing or invalid "amount" field`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });
  
  return {
    title: report.title,
    summary: report.summary,
    entries: validatedEntries
  };
}

function renderReport(data: ReportData, options: CliOptions): string {
  const renderOptions = { includeTotals: options.includeTotals };
  
  switch (options.format) {
    case 'markdown':
      return formatMarkdown(data, renderOptions);
    case 'text':
      return formatText(data, renderOptions);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content);
  } else {
    console.log(content);
  }
}

async function main(): Promise<void> {
  try {
    const args = process.argv;
    const options = parseArgs(args);
    
    // Read and parse JSON file
    const jsonContent = readFileSync(options.dataFile!, 'utf8');
    const parsedData = JSON.parse(jsonContent);
    
    // Validate data structure
    const validatedData = validateReportData(parsedData);
    
    // Render report
    const rendered = renderReport(validatedData, options);
    
    // Output result
    writeOutput(rendered, options.output);
    
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    
    if (message.includes('Unsupported format')) {
      console.error(`Error: ${message}`);
      process.exit(1);
    } else if (message.includes('ENOENT')) {
      console.error(`Error: Unable to read file - file not found`);
      process.exit(1);
    } else {
      console.error(`Error: ${message}`);
      process.exit(1);
    }
  }
}

// Only run main if this file is being executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { parseArgs, validateReportData, renderReport, writeOutput };
