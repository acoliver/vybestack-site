import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('timesTwo computing, input =', input())
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('timesThirty computing, input =', input())
  return input() * 30
})
const sum = createComputed(() => {
  console.log('sum computing, timesTwo =', timesTwo(), ', timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum())
console.log('Setting input to 3...')
setInput(3)
console.log('Final sum:', sum())
