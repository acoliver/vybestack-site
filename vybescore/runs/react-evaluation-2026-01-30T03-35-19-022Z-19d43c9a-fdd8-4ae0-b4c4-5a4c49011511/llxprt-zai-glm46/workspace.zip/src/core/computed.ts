/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  updateObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track observers that depend on this computed value
  const observers = new Set<Observer<unknown>>()
  
  // Set up post-update hook to notify dependent observers
  o.onUpdate = () => {
    // Notify all observers that depend on this computed value
    // This runs after the value is updated and activeObserver is restored
    observers.forEach(observer => {
      updateObserver(observer as Observer<unknown>)
    })
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register the active observer as depending on this computed value
      observers.add(activeObserver as Observer<unknown>)
    }
    return o.value!
  }
  
  return getter
}
