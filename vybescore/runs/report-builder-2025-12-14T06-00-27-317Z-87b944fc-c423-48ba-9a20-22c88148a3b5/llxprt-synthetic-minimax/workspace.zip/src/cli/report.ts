#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Parse arguments manually using Node's standard library
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= argv.length) {
          throw new Error('--format requires a value');
        }
        args.format = argv[i + 1];
        i++; // Skip next argument since it's the value
        break;
        
      case '--output':
        if (i + 1 >= argv.length) {
          throw new Error('--output requires a value');
        }
        args.output = argv[i + 1];
        i++; // Skip next argument since it's the value
        break;
        
      case '--includeTotals':
        args.includeTotals = true;
        break;
        
      default:
        // First non-flag argument is the data file
        if (!args.dataFile && !arg.startsWith('--')) {
          args.dataFile = arg;
        }
        break;
    }
  }

  // Validate required arguments
  if (!args.dataFile) {
    throw new Error('Data file path is required');
  }
  
  if (!args.format) {
    throw new Error('--format is required');
  }

  // Validate format
  if (args.format !== 'markdown' && args.format !== 'text') {
    throw new Error(`Unsupported format: ${args.format}`);
  }

  return args;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Data must be a JSON object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (must be array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry ${i + 1}: must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry ${i + 1}: missing or invalid "label" field (must be string)`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Entry ${i + 1}: missing or invalid "amount" field (must be number)`);
    }
  }

  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        throw new Error(`File not found: ${filePath}`);
      }
      if (error.message.includes('JSON.parse')) {
        throw new Error('Invalid JSON format');
      }
      throw error;
    }
    throw new Error('Unknown error reading file');
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options.includeTotals);
    case 'text':
      return renderText(data, options.includeTotals);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

async function main(): Promise<void> {
  try {
    const args = parseArguments(process.argv.slice(2));
    
    const reportData = loadReportData(args.dataFile);
    
    const options: CLIOptions = {
      format: args.format as 'markdown' | 'text',
      output: args.output,
      includeTotals: args.includeTotals,
    };

    const rendered = renderReport(reportData, options);
    
    if (args.output) {
      // Write to file
      try {
        const { writeFileSync } = await import('node:fs');
        writeFileSync(args.output, rendered, 'utf8');
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Failed to write output file: ${error.message}`);
        }
        throw error;
      }
    } else {
      // Write to stdout
      console.log(rendered);
    }

  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

main();