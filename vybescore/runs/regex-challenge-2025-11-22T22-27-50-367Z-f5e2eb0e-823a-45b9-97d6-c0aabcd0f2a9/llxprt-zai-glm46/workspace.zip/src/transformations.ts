/**
 * Capitalizes the first character of each sentence.
 * After .!? punctuation, adds exactly one space and capitalizes the next character.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Normalize spacing around sentence endings
  // Replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence-ending punctuation
  normalized = normalized.replace(/([.!?])\s*/g, '$1 ');
  
  // Step 2: Split into sentences and capitalize each one
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return '';
    
    // Handle common abbreviations to avoid over-capitalization
    const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'Ave.', 'Blvd.', 'Rd.', 'etc.', 'e.g.', 'i.e.'];
    const isAbbreviation = abbreviations.some(abbr => sentence.toLowerCase().startsWith(abbr.toLowerCase()));
    
    if (isAbbreviation && sentence.length > 4) {
      return sentence;
    }
    
    // Capitalize the first character of the sentence
    return sentence.charAt(0).toUpperCase() + sentence.slice(1).toLowerCase();
  });
  
  // Step 3: Join sentences back together with single spaces
  let result = capitalizedSentences.join(' ');
  
  // Clean up any trailing/leading spaces
  result = result.trim();
  
  return result;
}

/**
 * Extracts all URLs from the given text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches http(s), www, and domain-only URLs
  const urlRegex = /\b((?:https?:\/\/|www\.|ftp:\/\/)[^\s/$.?#].[^\s]*)(?=[\s)\]\}\.,;:!?"]|$)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    return url.replace(/[\)\]\}\.,;:!?'"`]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  // Use negative lookahead to avoid matching https://
  const httpsRegex = /\bhttp:\/\/(?!https:\/\/)/gi;
  
  return text.replace(httpsRegex, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * 1. Always upgrade http:// to https://
 * 2. When path begins with /docs/, rewrite host to docs.example.com
 * 3. Skip host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions
 * 4. Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match URLs with http scheme
  const urlRegex = /\bhttp:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, hostname, path) => {
    // Always upgrade to https
    let newUrl = `https://${hostname}${path}`;
    
    // Check if path starts with /docs/
    const docsPathRegex = /^\/docs\//;
    
    if (docsPathRegex.test(path)) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = [
        /\/cgi-bin\//,
        /[?&=]/,           // Query parameters
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i  // Legacy extensions
      ];
      
      const shouldSkipHostRewrite = dynamicHints.some(hint => hint.test(path));
      
      if (!shouldSkipHostRewrite) {
        // Rewrite host to docs.example.com
        newUrl = `https://docs.${hostname}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns the four-digit year or 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (including leap year for February)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  
  if (isLeapYear) {
    daysInMonth[1] = 29; // February has 29 days in leap year
  }
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}