export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with common rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid formats.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const [, domain] = value.split('@');
  
  // Domain shouldn't contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain shouldn't end with a dot
  if (domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleanPhone = value.replace(/[^\d+]/g, '');
  
  // Use options parameter if needed for future extension logic
  if (options?.allowExtensions) {
    // Future extension handling logic could go here
  }
  
  // Check minimum length (10 digits for US numbers)
  if (cleanPhone.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumber = cleanPhone;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.slice(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Check if we have exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits) and validate it
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the overall format matches one of the supported patterns
  const usPhoneRegex = /^(?:\+1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) but keep other characters for validation
  const cleanPhone = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex that handles all specified formats
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanPhone.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleanPhone.startsWith('+54') && !cleanPhone.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name regex that allows unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any unicode letter, \p{M} marks (accents)
  const nameRegex = /^[\p{L}\p{M}'][\p{L}\p{M}'\-\s]*[\p{L}\p{M}']$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check that the name contains at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names that look like X Æ A-12 style (contain numbers mixed with letters)
  const hasNumberAndLetter = /\d/.test(value) && /[\p{L}\p{M}]/u.test(value);
  if (hasNumberAndLetter) {
    return false;
  }
  
  // Reject names with consecutive special characters
  const hasConsecutiveSpecials = /''|--/.test(value);
  if (hasConsecutiveSpecials) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanCard = value.replace(/\D/g, '');
  
  // Check length based on card type
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Check Visa (starts with 4, length 13 or 16)
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  if (visaRegex.test(cleanCard)) {
    return runLuhnCheck(cleanCard);
  }
  
  // Check Mastercard (starts with 51-55 or 2221-2720, length 16)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  if (mastercardRegex.test(cleanCard)) {
    return runLuhnCheck(cleanCard);
  }
  
  // Check American Express (starts with 34 or 37, length 15)
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleanCard)) {
    return runLuhnCheck(cleanCard);
  }
  
  return false;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
