/**
 * Finds words beginning with the specified prefix but excludes words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // \b ensures we match whole words, \w* matches the rest of the word
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Convert to lowercase for comparison but preserve original case
  const uniqueMatches = Array.from(new Set(matches));
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = uniqueMatches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
  
  return filteredMatches;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds to ensure proper positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex that matches the digit + token pattern
  // This captures the entire occurrence including the preceding digit
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  // Return unique matches
  return Array.from(new Set(matches));
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, testtest, etc.)
  // This regex looks for any sequence of 2-4 characters that repeats immediately
  const repeatedSequenceRegex = /(.{2,4})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while ensuring IPv4 addresses don't trigger positive results.
 * Supports full IPv6 notation, shorthand with ::, and embedded IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles various formats:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8:85a3::8a2e:370:7334
  // - Compressed: ::1, ::ffff:192.168.1.1
  // - Embedded IPv4: ::ffff:192.168.1.1
  
  // Simplified IPv6 detection pattern
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits separated by colons
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/g,
    // Compressed with :: (double colon)
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/g,
    /:(?:[0-9a-fA-F]{1,4}:){1,7}/g,
    // Mixed with embedded IPv4
    /::ffff:(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)/g,
    // Link-local
    /fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}/g
  ];
  
  // IPv4 regex for exclusion
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
  
  // Check if any IPv6 pattern matches
  for (const pattern of ipv6Patterns) {
    const matches = value.match(pattern);
    if (matches) {
      // Verify these matches aren't just IPv4 addresses
      for (const match of matches) {
        // If the match contains colons and is not a pure IPv4, it's IPv6
        if (match.includes(':') && !ipv4Regex.test(match)) {
          return true;
        }
      }
    }
  }
  
  // Additional check for common IPv6 patterns
  // Look for double colon which is specific to IPv6
  if (/::/.test(value) && !ipv4Regex.test(value)) {
    return true;
  }
  
  // Look for hexadecimal groups separated by colons (at least 2 groups)
  if (/(?:[0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4}/.test(value)) {
    return true;
  }
  
  return false;
}