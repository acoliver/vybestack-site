module.exports = {
  parser: '@typescript-eslint/parser',
  extends: ['eslint:recommended'],
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: 'module',
  },
  rules: {
    'no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    'no-undef': 'off',  // TypeScript handles this
  },
  ignorePatterns: ['vitest.config.public.ts', 'node_modules/', 'dist/'],
};
