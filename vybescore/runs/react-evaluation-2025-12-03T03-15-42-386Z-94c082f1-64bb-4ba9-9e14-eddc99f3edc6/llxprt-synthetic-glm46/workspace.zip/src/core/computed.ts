/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      o.observer = observer
    }
    
    // Always recompute to ensure values are up-to-date
    o.value = updateFn(o.value)
    return o.value!
  }
  
  return read
}