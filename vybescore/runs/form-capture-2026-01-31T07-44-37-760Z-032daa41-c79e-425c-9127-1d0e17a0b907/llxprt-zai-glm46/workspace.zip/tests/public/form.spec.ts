import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let app: express.Application;
let close: () => void;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { createServer } = await import('../../src/server.js');
  const serverInstance = await createServer();
  app = serverInstance.app;
  close = serverInstance.close;
});

afterAll(() => {
  if (close) {
    close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    
    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="lastName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'invalid-email',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'john@example.com',
        phone: 'invalid-phone!',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number must contain only digits');
  });

  it('accepts international phone formats', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Maria',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria@example.com',
        phone: '+54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('accepts UK postal codes', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'James',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'james@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Alice',
        lastName: 'Johnson',
        streetAddress: '123 Test Street',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'alice@example.com',
        phone: '+1 234-567-8900',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank you page with redirect', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('stranger on the internet');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Testland',
        email: 'invalid-email-format',
        phone: '+1 555-1234',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('Test');
    expect($('input[name="email"]').val()).toBe('invalid-email-format');
  });

  it('accepts alphanumeric postal codes', async () => {
    const testCases = [
      { postal: 'SW1A 1AA', country: 'UK' },
      { postal: 'C1000', country: 'Argentina' },
      { postal: 'B1675', country: 'Argentina' },
      { postal: '12345', country: 'USA' },
      { postal: 'A1A 1A1', country: 'Canada' },
    ];

    for (const tc of testCases) {
      if (fs.existsSync(dbPath)) {
        fs.unlinkSync(dbPath);
      }

      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: tc.postal,
          country: tc.country,
          email: 'test@example.com',
          phone: '+1 555-1234',
        });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });
});
