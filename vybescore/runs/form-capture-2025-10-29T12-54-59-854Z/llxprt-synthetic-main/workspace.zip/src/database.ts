import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';
import type { Database } from './sqljs.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, '../../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../../db/schema.sql');

let db: Database;
let dbNeedsSave = false;

export default async function initDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    let dbData: Uint8Array | null = null;
    
    if (fs.existsSync(DB_PATH)) {
      console.log('Loading existing database from:', DB_PATH);
      dbData = fs.readFileSync(DB_PATH);
    } else {
      console.log('Creating new database');
    }

    db = new SQL.Database(dbData || undefined);

    if (!dbData) {
      console.log('Initializing database schema');
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.run(schema);
      dbNeedsSave = true;
    }

    const saveDatabase = () => {
      if (dbNeedsSave) {
        try {
          const data = db.export();
          
          const dataDir = path.dirname(DB_PATH);
          if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
          }
          
          fs.writeFileSync(DB_PATH, new Uint8Array(data));
          console.log('Database saved to:', DB_PATH);
          dbNeedsSave = false;
        } catch (error) {
          console.error('Error saving database:', error);
        }
      }
    };

    // We're wrapping the original method with a custom implementation
    const originalRun = db.run.bind(db);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    db.run = function(sql: string, ...params: unknown[]) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const result = originalRun(sql, ...params as any[]);
      if (sql && 
          (sql.trim().toLowerCase().startsWith('insert') || 
           sql.trim().toLowerCase().startsWith('update') || 
           sql.trim().toLowerCase().startsWith('delete'))) {
        dbNeedsSave = true;
        saveDatabase();
      }
      return result;
    };

    // We're wrapping the original method with a custom implementation
    const originalExec = db.exec.bind(db);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    db.exec = function(sql: string, ...params: unknown[]) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const result = originalExec(sql, ...params as any[]);
      if (sql &&
          (sql.trim().toLowerCase().includes('insert') ||
           sql.trim().toLowerCase().includes('update') ||
           sql.trim().toLowerCase().includes('delete'))) {
        dbNeedsSave = true;
        saveDatabase();
      }
      return result;
    };

    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}