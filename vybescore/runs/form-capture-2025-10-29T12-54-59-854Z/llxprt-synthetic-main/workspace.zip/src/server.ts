import express, { type Request, type Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
// sql.js doesn't have proper TypeScript definitions
import initDatabase from './database.js';
import { validateForm, FormSubmission } from './validators.js';
import type { Database } from './sqljs.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

let db: Database;

try {
  db = await initDatabase();
  console.log('Database initialized successfully');
} catch (error) {
  console.error('Failed to initialize database:', error);
  if (process.env.NODE_ENV !== 'test') {
    process.exit(1);
  } else {
    throw error;
  }
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const submission: FormSubmission = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validationErrors = validateForm(submission);
  
  if (validationErrors.length > 0) {
    return res.render('form', {
      errors: validationErrors,
      values: submission
    });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);
    stmt.free();
    
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(submission.firstName)}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: submission
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

const server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

const gracefulShutdown = async () => {
  console.log('Closing server and database...');
  await new Promise<void>((resolve) => {
    server.close(() => {
      if (db) {
        db.close();
      }
      resolve();
    });
  });
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

export { app, server };