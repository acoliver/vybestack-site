export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(data: FormSubmission): string[] {
  const errors: string[] = [];

  // Required fields validation
  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!data.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!data.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  
  if (!data.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  }
  
  if (!data.country?.trim()) {
    errors.push('Country is required');
  }
  
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!isValidEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!isValidPhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Accept international formats: digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings, spaces, dashes (UK: SW1A 1AA, Argentina: C1000, B1675)
  const postalRegex = /^[\w\s-]{3,10}$/;
  return postalRegex.test(postalCode);
}

export function sanitizeInput(input: string): string {
  return input.trim();
}