import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Set NODE_ENV to test to prevent server from exiting on errors
  process.env.NODE_ENV = 'test';
  const { app: expressApp, server: svr } = await import('../../dist/server.js');
  app = expressApp;
  server = svr;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const response = await request(app as any).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check all required form fields are present
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'TestState',
      postalCode: '12345',
      country: 'TestCountry',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit the form
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const response = await request(app as any)
      .post('/submit')
      .send(formData);
    
    // Check for redirect
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    
    // Follow the redirect
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const thankYouResponse = await request(app as any).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    
    // Check the thank you page contains the first name
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain(formData.firstName);
    
    // Check database contains the submission
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
