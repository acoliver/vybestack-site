/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes proper padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both standard and URL-safe Base64, with or without padding.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: must be a non-empty string');
  }

  // Normalize URL-safe characters to standard Base64
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  // Check for invalid characters
  if (/[^A-Za-z0-9+/=]/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-alphabet characters');
  }

  try {
    const result = Buffer.from(normalized, 'base64').toString('utf8');
    // If the result is empty but input wasn't, it might be invalid
    if (!result && normalized) {
      throw new Error('Invalid Base64 input: decoding resulted in empty string');
    }
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
