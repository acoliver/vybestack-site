/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function isValidBase64(input: string): boolean {
  // Base64 valid characters: A-Z, a-z, 0-9, +, /, and = for padding
  const base64Regex = /^[A-Za-z0-9+/=]*$/;
  
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check padding validity: padding '=' can only appear at the end
  // and there can be 0, 1, or 2 padding characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, it must be at the end
    const paddingSection = input.substring(paddingIndex);
    if (!/={1,2}$/.test(paddingSection)) {
      return false;
    }
    
    // The total length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
    
    // If there are padded characters, check if they're valid
    if (paddingSection.length === 2 && input.charAt(input.length - 3) === '=') {
      return false; // Too much padding
    }
  } else {
    // No padding: length must be a multiple of 4 
    // or if not, it should be padded later by the decoder
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate the input first
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
