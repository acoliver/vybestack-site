import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize database path
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

let db: Database;
let server: any;

// Function to initialize database
async function initDatabase() {
  const SQL = await initSqlJs({ locateFile: (file) => `node_modules/sql.js/dist/${file}` });
  
  // Load existing database or create a new one
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    db.run(schema);
    saveDatabase();
  }
}

// Function to save database to file
function saveDatabase() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes with spaces and hyphens
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateRequiredFields(data: any): string[] {
  const errors: string[] = [];
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 
    'city', 'stateProvince', 'postalCode', 
    'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
    }
  });
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const data = req.body;
  let errors: string[] = [];
  
  // Validate required fields
  errors = validateRequiredFields(data);
  
  // Validate email
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please provide a valid email address');
  }
  
  // Validate phone
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please provide a valid phone number');
  }
  
  // Validate postal code
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please provide a valid postal code');
  }
  
  // If validation fails, re-render form with errors
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: data });
  }
  
  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (err) {
    console.error('Database insert error:', err);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req, res) => {
  // We don't have access to the first name here, but let's render with a placeholder
  // In a real-world scenario, we could get this from the database or session
  res.render('thank-you', { firstName: 'Valued User' });
});

// Graceful shutdown
function shutdown() {
  console.log('Shutting down server...');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
}

// Handle shutdown signals
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  await initDatabase();
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});