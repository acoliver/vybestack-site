/**
 * Interface for a report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the complete report data
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Common interface for all report formatters
 */
export interface ReportRenderer {
  render(data: ReportData, options: ReportOptions): string;
}

/**
 * Common options for all formatters
 */
export interface ReportOptions {
  includeTotals: boolean;
}