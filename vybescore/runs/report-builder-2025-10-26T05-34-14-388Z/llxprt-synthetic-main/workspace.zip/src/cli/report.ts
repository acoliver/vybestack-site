#!/usr/bin/env node

import { promises as fs } from 'fs';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIOptions extends ReportOptions {
  output?: string;
  format: string;
}

/**
 * Validates and loads the report data from a JSON file
 */
async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    const data = JSON.parse(content) as unknown;
    
    // Basic validation
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid title');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid summary');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: entries must be an array');
    }
    
    const entries = reportData.entries.map((entry, index) => {
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${index}: expected an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid label`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid amount`);
      }
      
      return {
        label: entryObj.label,
        amount: entryObj.amount
      };
    });
    
    return {
      title: reportData.title,
      summary: reportData.summary,
      entries
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Parse command line arguments
 */
function parseArgs(args: string[]): { filePath: string; options: CLIOptions } {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const filePath = args[2];
  const options: CLIOptions = {
    format: '',
    includeTotals: false
  };
  
  let i = 3;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      options.format = args[i + 1];
      i += 2;
    } else if (arg === '--output' && i + 1 < args.length) {
      options.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
      i += 1;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }
  
  if (!options.format) {
    throw new Error('Missing required option: --format');
  }
  
  if (options.format !== 'markdown' && options.format !== 'text') {
    throw new Error('Unsupported format');
  }
  
  return { filePath, options };
}

/**
 * Main function
 */
async function main(): Promise<void> {
  try {
    const { filePath, options } = parseArgs(process.argv);
    
    // Load report data
    const data = await loadReportData(filePath);
    
    // Render report based on format
    let result: string;
    switch (options.format) {
      case 'markdown':
        result = renderMarkdown.render(data, options);
        break;
      case 'text':
        result = renderText.render(data, options);
        break;
      default:
        throw new Error('Unsupported format');
    }
    
    // Output result
    if (options.output) {
      await fs.writeFile(options.output, result, 'utf8');
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

// Run the CLI
main();
