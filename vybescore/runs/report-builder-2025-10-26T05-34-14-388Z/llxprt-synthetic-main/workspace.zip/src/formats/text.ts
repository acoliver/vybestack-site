import { ReportData, ReportOptions } from '../types.js';

/**
 * Formats a number as a currency with two decimal places
 */
function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total of all entry amounts
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Renders a report in text format
 */
export const renderText = {
  render: (data: ReportData, options: ReportOptions): string => {
  let result = '';
  
  // Title
  result += `${data.title}\n\n`;
  
  // Summary
  result += `${data.summary}\n\n`;
  
  // Entries heading
  result += `Entries:\n`;
  
  // Entry list
  for (const entry of data.entries) {
    result += `- ${entry.label}: ${formatCurrency(entry.amount)}\n`;
  }
  
  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data);
    result += `\nTotal: ${formatCurrency(total)}\n`;
  }
  
  return result;
  }
};