import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type DatabaseState = any;

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');
let db: DatabaseState = null;
let SQL: typeof initSqlJs | null = null;

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    SQL = await initSqlJs({
      locateFile: () => 'node_modules/sql.js/dist/sql-wasm.wasm'
    });

    let data: Uint8Array = new Uint8Array(0);
    if (fs.existsSync(DB_PATH)) {
      data = fs.readFileSync(DB_PATH);
    }

    db = new SQL.Database(data);

    // Initialize schema
    const schema = fs.readFileSync(path.join('db', 'schema.sql'), 'utf8');
    db.run(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  try {
    if (!db) throw new Error('Database not initialized');
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s()\-+]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(data: Partial<FormData>): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join('src', 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    res.render('form', {
      errors: Object.values(validation.errors),
      values: formData
    });
    return;
  }

  try {
    if (!db) throw new Error('Database not initialized');
    
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();

    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the last submitted first name
  let firstName = 'friend';
  try {
    if (!db) throw new Error('Database not initialized');
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    const result = stmt.get();
    stmt.free();
    if (result && result.first_name) {
      firstName = result.first_name;
    }
  } catch (error) {
    console.error('Error fetching last submission:', error);
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(callback: () => void): void {
  console.log('Shutting down server...');
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }

  callback();
}

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Handle signals for graceful shutdown
    process.on('SIGTERM', () => {
      server.close(() => {
        gracefulShutdown(() => {
          process.exit(0);
        });
      });
    });

    process.on('SIGINT', () => {
      server.close(() => {
        gracefulShutdown(() => {
          process.exit(0);
        });
      });
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, initializeDatabase, validateForm, db, saveDatabase };

// Export DatabaseState type
export type { DatabaseState };

// Start server if this file is run directly
startServer();