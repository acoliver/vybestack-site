#!/usr/bin/env node

import { readFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Main entry point for report CLI
 */
function main(): void {
  try {
    const options = parseArguments();
    const reportData = loadAndValidateReportData(options.dataPath);
    const output = renderReport(reportData, options);
    writeOutput(output, options.outputPath);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error(message);
    process.exit(1);
  }
}

/**
 * Parse command line arguments using Node standard library
 */
function parseArguments(): CLIOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataPath = args[0];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1] as 'markdown' | 'text';
      i += 2;
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!format) {
    throw new Error('Missing required flag: --format');
  }
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

/**
 * Load and validate report data from JSON file
 */
function loadAndValidateReportData(dataPath: string): ReportData {
  try {
    const rawData = readFileSync(dataPath, 'utf8');
    const parsedData = JSON.parse(rawData);
    
    // Validate required fields
    if (!parsedData.title || typeof parsedData.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!parsedData.summary || typeof parsedData.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!parsedData.entries || !Array.isArray(parsedData.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < parsedData.entries.length; i++) {
      const entry = parsedData.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${i + 1} missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry ${i + 1} missing or invalid "amount" field`);
      }
    }
    
    return parsedData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${dataPath}": ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${dataPath}`);
    }
    throw error;
  }
}

/**
 * Render report using appropriate formatter
 */
function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options.includeTotals);
    case 'text':
      return renderText(data, options.includeTotals);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

/**
 * Write output to stdout or file
 */
function writeOutput(output: string, outputPath?: string): void {
  if (outputPath) {
    // Write to file (implementation would require fs module)
    // For now, we'll just write to stdout as specified output is optional
    console.error('Note: output to file not implemented in this version');
    console.log(output);
  } else {
    console.log(output);
  }
}

// Run main function if this script is being executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { parseArguments, loadAndValidateReportData, renderReport, writeOutput };
