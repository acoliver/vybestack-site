import { ReportData } from '../types/report.js';

/**
 * Format report data as plain text
 */
export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Entry bullet list
  for (const entry of data.entries) {
    const amount = formatAmount(entry.amount);
    lines.push(`- ${entry.label}: $${amount}`);
  }
  
  // Total if requested
  if (includeTotals) {
    lines.push('');
    const total = calculateTotal(data);
    lines.push(`Total: $${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}

/**
 * Calculate total amount from entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format amount with exactly two decimal places, no thousands separators
 */
function formatAmount(amount: number): string {
  return amount.toFixed(2);
}