# Report Formats

This directory contains the formatters for different output formats:

- `markdown.ts` - renders reports in markdown format
- `text.ts` - renders reports in plain text format

Each formatter exports a consistent interface following the `Formatter` type defined in `../types/report.ts`.
