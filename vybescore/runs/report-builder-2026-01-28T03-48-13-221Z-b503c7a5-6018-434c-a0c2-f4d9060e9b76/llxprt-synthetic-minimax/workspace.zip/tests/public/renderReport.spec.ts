import { describe, expect, it } from 'vitest';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

describe('report CLI (public smoke)', () => {
  const cliPath = 'dist/cli/report.js';
  
  it('should render markdown report with totals', async () => {
    const { stdout } = await execAsync(
      `node ${cliPath} fixtures/data.json --format markdown --includeTotals`
    );
    
    expect(stdout).toContain('# Quarterly Financial Summary');
    expect(stdout).toContain('Highlights include record revenue');
    expect(stdout).toContain('## Entries');
    expect(stdout).toContain('- **North Region** — $12345.67');
    expect(stdout).toContain('**Total:** $70370.34');
  });

  it('should render text report with totals', async () => {
    const { stdout } = await execAsync(
      `node ${cliPath} fixtures/data.json --format text --includeTotals`
    );
    
    expect(stdout).toContain('Quarterly Financial Summary');
    expect(stdout).toContain('Highlights include record revenue');
    expect(stdout).toContain('Entries:');
    expect(stdout).toContain('- North Region: $12345.67');
    expect(stdout).toContain('Total: $70370.34');
  });

  it('should render markdown report without totals', async () => {
    const { stdout } = await execAsync(
      `node ${cliPath} fixtures/data.json --format markdown`
    );
    
    expect(stdout).toContain('# Quarterly Financial Summary');
    expect(stdout).toContain('## Entries');
    expect(stdout).toContain('- **North Region** — $12345.67');
    expect(stdout).not.toContain('**Total:**');
  });

  it('should render text report without totals', async () => {
    const { stdout } = await execAsync(
      `node ${cliPath} fixtures/data.json --format text`
    );
    
    expect(stdout).toContain('Quarterly Financial Summary');
    expect(stdout).toContain('Entries:');
    expect(stdout).toContain('- North Region: $12345.67');
    expect(stdout).not.toContain('Total:');
  });

  it('should reject unknown format', async () => {
    try {
      await execAsync(
        `node ${cliPath} fixtures/data.json --format invalid`
      );
      throw new Error('Expected command to fail');
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      expect(message).toMatch(/Unsupported format/);
    }
  });

  it('should handle malformed JSON file', async () => {
    try {
      await execAsync(
        `node ${cliPath} fixtures/bad-data.json --format markdown`
      );
      throw new Error('Expected command to fail');
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      expect(message).toMatch(/invalid|unable|missing|error|Invalid JSON/);
    }
  });
});
