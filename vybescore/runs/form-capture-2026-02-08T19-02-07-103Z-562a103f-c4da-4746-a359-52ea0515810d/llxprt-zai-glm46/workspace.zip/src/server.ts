import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+]?\d[\d\s()-]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces (e.g., "SW1A 1AA", "C1000", "B1675", "12345")
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!validateRequired(data.firstName || '')) {
    errors.push('First name is required');
  }

  if (!validateRequired(data.lastName || '')) {
    errors.push('Last name is required');
  }

  if (!validateRequired(data.streetAddress || '')) {
    errors.push('Street address is required');
  }

  if (!validateRequired(data.city || '')) {
    errors.push('City is required');
  }

  if (!validateRequired(data.stateProvince || '')) {
    errors.push('State / Province / Region is required');
  }

  if (!validateRequired(data.postalCode || '')) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode || '')) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens');
  }

  if (!validateRequired(data.country || '')) {
    errors.push('Country is required');
  }

  if (!validateRequired(data.email || '')) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email || '')) {
    errors.push('Please enter a valid email address');
  }

  if (!validateRequired(data.phone || '')) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone || '')) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form.ejs', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]);

      stmt.free();

      // Save database to disk
      const data = db.export();
      const dir = path.dirname(DB_PATH);

      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(DB_PATH, data);
    } catch (error) {
      console.error('Database error:', error);
      return res.status(500).render('form.ejs', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData,
      });
    }
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you.ejs', {
    firstName: 'Friend',
  });
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    // Initialize SQL.js
    const SQL = await initSqlJs();

    // Load or create database
    let dbData: Uint8Array | null = null;

    if (fs.existsSync(DB_PATH)) {
      dbData = fs.readFileSync(DB_PATH);
    }

    db = new SQL.Database(dbData);

    // Initialize schema
    if (fs.existsSync(SCHEMA_PATH)) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
    }

    // Set up EJS
    app.set('view engine', 'ejs');
    // Templates are always in src/templates, even when running from dist/
    const srcDir = path.resolve(process.cwd(), 'src');
    app.set('views', path.join(srcDir, 'templates'));

    // Start server
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Graceful shutdown
    const shutdown = () => {
      console.log('Shutting down server...');
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        console.log('Server shut down gracefully');
        process.exit(0);
      });

      // Force shutdown after 10 seconds
      setTimeout(() => {
        console.error('Forced shutdown after timeout');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, startServer };

// Start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
