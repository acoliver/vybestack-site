import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { request } from 'http';
import { URL } from 'url';
import { startServer } from '../../src/server.js';

const PORT = 3535;
const BASE_URL = `http://localhost:${PORT}`;
const dbPath = path.resolve('data', 'submissions.sqlite');

function makeRequest(path: string, method = 'GET', headers?: Record<string, string>, body?: string): Promise<{ statusCode: number; headers: Record<string, string>; body: string }> {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const options = {
      hostname: url.hostname,
      port: url.port || PORT,
      path: url.pathname + url.search,
      method,
      headers: headers || {},
    };

    const req = request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode || 0,
          headers: res.headers as Record<string, string>,
          body: data,
        });
      });
    });

    req.on('error', reject);

    if (body) {
      req.write(body);
    }
    req.end();
  });
}

beforeAll(async () => {
  // Start the server
  await startServer();
  // Wait for server to be ready
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(() => {
  // Server will be shut down by SIGTERM from test harness
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await makeRequest('/');
    expect(response.statusCode).toBe(200);
    expect(response.body).toContain('Tell us who you are');
    expect(response.body).toContain('firstName');
    expect(response.body).toContain('lastName');
    expect(response.body).toContain('streetAddress');
    expect(response.body).toContain('city');
    expect(response.body).toContain('stateProvince');
    expect(response.body).toContain('postalCode');
    expect(response.body).toContain('country');
    expect(response.body).toContain('email');
    expect(response.body).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = new URLSearchParams({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567',
    }).toString();

    const response = await makeRequest(
      '/submit',
      'POST',
      {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      formData
    );

    expect(response.statusCode).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Verify thank-you page is accessible
    const thankYouResponse = await makeRequest('/thank-you');
    expect(thankYouResponse.statusCode).toBe(200);
    expect(thankYouResponse.body).toContain('Thank you');
  });

  it('validates required fields', async () => {
    const formData = new URLSearchParams({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    }).toString();

    const response = await makeRequest(
      '/submit',
      'POST',
      {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      formData
    );

    expect(response.statusCode).toBe(400);
    expect(response.body).toContain('First name is required');
    expect(response.body).toContain('Last name is required');
  });

  it('validates email format', async () => {
    const formData = new URLSearchParams({
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Miami',
      stateProvince: 'FL',
      postalCode: '33101',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1 555-987-6543',
    }).toString();

    const response = await makeRequest(
      '/submit',
      'POST',
      {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      formData
    );

    expect(response.statusCode).toBe(400);
    expect(response.body).toContain('valid email');
  });

  it('accepts international phone formats', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = new URLSearchParams({
      firstName: 'Pierre',
      lastName: 'Martin',
      streetAddress: '78 Rue de Rivoli',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75001',
      country: 'France',
      email: 'pierre.martin@example.com',
      phone: '+33 1 42 86 83 46',
    }).toString();

    const response = await makeRequest(
      '/submit',
      'POST',
      {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      formData
    );

    expect(response.statusCode).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
