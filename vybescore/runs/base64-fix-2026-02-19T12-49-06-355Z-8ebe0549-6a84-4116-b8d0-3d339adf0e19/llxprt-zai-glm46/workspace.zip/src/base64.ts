/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with proper padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input format and structure.
 */
function validateBase64Input(input: string): void {
  if (!input) {
    throw new Error('Failed to decode Base64 input: empty input');
  }

  // Valid Base64 characters: A-Z, a-z, 0-9, +, /, and padding =
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Pattern.test(input)) {
    throw new Error('Failed to decode Base64 input: invalid characters');
  }

  // Validate padding is correct (max 2 padding chars)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Failed to decode Base64 input: invalid padding');
    }
  }

  // Total length must be a multiple of 4
  if (input.length % 4 !== 0) {
    throw new Error('Failed to decode Base64 input: invalid length (must be multiple of 4)');
  }
}

/**
 * Verify that the decoded buffer is valid by re-encoding and comparing.
 */
function verifyDecoded(input: string, buffer: Buffer): void {
  const reEncoded = buffer.toString('base64');
  const normalizedInput = input.replace(/=+$/, '');
  const normalizedReEncoded = reEncoded.replace(/=+$/, '');
  
  if (normalizedInput !== normalizedReEncoded) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  validateBase64Input(input);

  try {
    const buffer = Buffer.from(input, 'base64');
    verifyDecoded(input, buffer);
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('Failed to decode')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input: decoding failed');
  }
}
