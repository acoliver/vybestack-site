/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, addCallbackObserver } from '../types/reactive.js'

const callbacks: Observer<unknown>[] = []

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<unknown> = {
    value,
    updateFn: updateFn as UpdateFn<unknown>,
  }
  
  updateObserver(observer)
  callbacks.push(observer)
  addCallbackObserver(observer)
  
  return () => {
    const index = callbacks.indexOf(observer)
    if (index > -1) {
      callbacks.splice(index, 1)
    }
    observer.updateFn = () => value as unknown
  }
}
