/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  SubjectR,
  getActiveObserver,
  addObserver,
  notifyObservers,
  updateCallbacks,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let currentValue = value
  const equalFn = typeof equal === 'function' ? equal : undefined
  const s: SubjectR = {
    name: options?.name,
    observer: undefined,
  }

  // Store the value and equal function in the observer map for this subject
  const valueMap = new Map<SubjectR, { value: T; equalFn?: EqualFn<T> }>()
  valueMap.set(s, { value: currentValue, equalFn })

const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer)
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    const currentValueData = valueMap.get(s)!
    if (currentValueData.equalFn && currentValueData.equalFn(currentValueData.value, nextValue)) {
      return currentValueData.value
    }
    currentValueData.value = nextValue
    currentValue = nextValue
    notifyObservers(s)
    updateCallbacks()
    return currentValueData.value
  }

  return [read, write]
}
