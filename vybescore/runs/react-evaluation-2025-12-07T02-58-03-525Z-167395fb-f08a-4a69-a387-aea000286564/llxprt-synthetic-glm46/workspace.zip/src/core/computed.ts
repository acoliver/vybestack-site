/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  clearActiveObserver,
  Options,
  Observer
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    observers: [],
    value,
    updateFn: (prev?: T) => {
      // Set this observer as active to track dependencies
      setActiveObserver(o)
      try {
        // Clear previous dependencies before creating new ones
        const currentObservers = [...o.observers]
        o.observers = []
        
        const newValue = updateFn(prev)
        
        // If value has changed, notify observers
        if (value === undefined || !equalFn || !equalFn(value, newValue)) {
          value = newValue
          
          // Notify all dependent observers
          currentObservers.forEach(obs => {
            updateObserver(obs as Observer<unknown>)
          })
        }
        
        o.value = value
        return value
        
      } finally {
        clearActiveObserver()
      }
    }
  }
  
  // Perform initial computation to establish dependencies
  o.updateFn(value)
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer && !o.observers?.includes(observer)) {
      o.observers.push(observer)
    }
    
    return o.value as T
  }
}