/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after .?!
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces, but preserve sentence boundaries
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure space after sentence endings if missing
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Capitalize first letter of the text
  result = result.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Capitalize after sentence endings, being careful about abbreviations
  // Common abbreviations to avoid capitalizing after
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'vs', 'eg', 'ie', 'approx', 'est', 'Dept', 'Univ', 'Assn', 'Ave', 'Capt', 'Cmdr', 'Col', 'Gen', 'Hon', 'Lt', 'Maj', 'Pres', 'Rep', 'Sen', 'Sgt'];
  
  // Build regex pattern for abbreviations
  const abbrevPattern = abbreviations.join('|');
  const abbrevRegex = new RegExp(`\\b(${abbrevPattern})\\.$`, 'i');
  
  // Split into sentences and capitalize
  const sentences = result.split(/(?<=[.!?])\s+/);
  
  let inAbbreviation = false;
  const capitalized = sentences.map((sentence, index) => {
    if (index === 0) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    // Check if previous sentence ended with an abbreviation
    const prevSentence = sentences[index - 1];
    if (abbrevRegex.test(prevSentence.trim())) {
      inAbbreviation = true;
    } else {
      inAbbreviation = false;
    }
    
    if (inAbbreviation && /^[a-z]/.test(sentence)) {
      // Don't capitalize after abbreviation
      return sentence;
    }
    
    // Capitalize first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join sentences back with single spaces
  return capitalized.join(' ').trim();
}

/**
 * Extract all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  const urlRegex = /(https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation: .,!?;:
    return url.replace(/[,.;:!?]+$/, '');
  });
}

/**
 * Replace http:// with https:// while leaving existing https:// URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite example.com URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic URLs (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?:\/\/example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, protocol, path = '') => {
    // Always upgrade to https
    let newHost = 'example.com';
    
    // Check if path should be rewritten to docs.example.com
    // Skip if contains dynamic hints
    const dynamicHints = /\?.*|=|&|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/;
    
    if (path && path.startsWith('/docs/') && !dynamicHints.test(path)) {
      newHost = 'docs.example.com';
      // Keep the /docs/ path intact
      return `https://${newHost}${path}`;
    } else {
      // Just upgrade the scheme
      return `https://${newHost}${path}`;
    }
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
