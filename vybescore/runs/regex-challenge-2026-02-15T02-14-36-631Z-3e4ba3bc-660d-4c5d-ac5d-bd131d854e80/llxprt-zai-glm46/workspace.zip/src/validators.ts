export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive regex.
 * Accepts: name+tag@example.co.uk style addresses
 * Rejects: double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation with some practical restrictions
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks for specific rejection criteria
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (/\.\./.test(value)) {
    return false;
  }
  
  // Reject trailing dot
  if (/\.$/.test(value)) {
    return false;
  }
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart && /_/.test(domainPart)) {
    return false;
  }
  
  // Reject leading/trailing dots in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Handle optional +1 country code
  let areaCodeStart = 0;
  if (digitsOnly.length === 11) {
    if (digitsOnly[0] !== '1') {
      return false;
    }
    areaCodeStart = 1;
  }
  
  // Extract area code (first 3 digits after optional +1)
  const areaCode = digitsOnly.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex for common patterns
  const phoneRegex = /^(?:\+1[\s\-.]?)?\(?([2-9]\d{2})\)?[\s\-.]?([2-9]\d{2})[\s\-.]?(\d{4})(?:\s*(?:ext|ex|x|ext.)\s*\d+)?$/i;
  
  if (!phoneRegex.test(value.trim())) {
    return false;
  }
  
  // Handle extensions if allowed
  if (options?.allowExtensions) {
    const extensionRegex = /(ext|ex|x|ext.)\s*\d+$/i;
    if (extensionRegex.test(value.trim())) {
      return true;
    }
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers for both mobile and landline.
 * Supports formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation, but keep structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code is omitted)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Check that when country code is omitted, trunk prefix 0 is present
  if (!value.includes('+54') && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, and names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and mixed alphanumeric names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if contains any digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject if contains symbols (except allowed apostrophes, hyphens, spaces)
  const allowedSpecial = /[\s'-]/g;
  const withoutAllowed = value.replace(allowedSpecial, '');
  // Check if remaining characters are all letters
  if (!/^[\p{L}\p{M}]+$/u.test(withoutAllowed)) {
    return false;
  }
  
  // Reject empty or whitespace-only names
  if (!value.trim()) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and AmEx.
 * Includes prefix validation, length validation, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-2]\d)\d{12}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || 
                        mastercardRegex.test(cleaned) || 
                        amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
