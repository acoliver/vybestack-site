/**
 * Find words beginning with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}\\w*)\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, ensure not at start of string
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = pattern.exec(text)) !== null) {
    const matched = match[0];
    const index = match.index;
    // Ensure not at start of string
    if (index > 0) {
      matches.push(matched);
    }
  }
  
  return matches;
}

/**
 * Validate password strength:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+=\-[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // Look for any 2-4 character pattern that repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + len * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (including :: shorthand)
  // This pattern matches various IPv6 formats while excluding IPv4
  
  // Full IPv6 regex that handles shorthand
  const ipv6Pattern = 
    /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|::(?:ffff(?::0{1,4})?:)?(?:(?:25[0-5]|(?:2[0-4]|1?[0-9])?[0-9])\.){3}(?:25[0-5]|(?:2[0-4]|1?[0-9])?[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(2[0-4]|1?[0-9])?[0-9])\.){3}(?:25[0-5]|(2[0-4]|1?[0-9])?[0-9]))(?:$|(?=\s))/;
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Check if the entire value is an IPv4 address
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check for IPv6 pattern
  return ipv6Pattern.test(value);
}
