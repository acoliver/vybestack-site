import { findPrefixedWords } from './dist/src/puzzles.js';

console.log(findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));