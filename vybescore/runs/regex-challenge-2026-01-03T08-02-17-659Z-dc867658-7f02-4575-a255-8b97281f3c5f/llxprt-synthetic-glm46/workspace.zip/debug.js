const text = 'preview prevent prefix';
const prefix = 'pre';
const exceptions = ['prevent'];

const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
console.log('escapedPrefix:', escapedPrefix);

const wordRegex = new RegExp('\\b' + escapedPrefix + '\\w*\\b', 'g');
console.log('regex:', wordRegex);

let match;
while ((match = wordRegex.exec(text)) !== null) {
  console.log('match:', match[0]);
}