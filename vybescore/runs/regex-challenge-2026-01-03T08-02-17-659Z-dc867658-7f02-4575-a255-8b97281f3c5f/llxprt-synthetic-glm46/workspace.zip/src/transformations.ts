/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence boundaries (period, exclamation mark, question mark)
  // followed by whitespace or end of string
  const sentences = text.split(/([.!?])(?:\s+|$)/);
  
  // Process even indices (sentences) and preserve punctuation (odd indices) as separators
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    if (sentence && sentence.trim()) {
      // Capitalize first character, leave rest as is
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.substring(1);
      
      // Collapse multiple spaces to single space within the sentence
      sentences[i] = sentences[i].replace(/\s+/g, ' ');
    }
  }
  
  // Re-join and ensure exactly one space after punctuation if followed by another sentence
  return sentences.join('').replace(/([.!?])(\S)/g, '$1 $2');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http(s), www, and domain patterns
  // Captures the full URL but excludes trailing punctuation
  const urlRegex = /((?:https?:\/|www\.)[^\s<>]+)(?=[^\w-]|$)/g;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation like .,!?:;)]}
    url = url.replace(/[.,!?;:'\])}]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, case insensitive
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to capture example.com URLs and their paths
  // Group 1: protocol, Group 2: domain, Group 3: path
  const exampleDomainRegex = /()(http:\/\/(?:www\.)?example\.com)((?:\/[^?\s]*)?)/g;
  
  return text.replace(exampleDomainRegex, (match, protocol, domain, path) => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Determine if we should rewrite the host to docs.example.com
    const rewriteHost = path && 
                        path.startsWith('/docs/') && 
                        !/(cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path) &&
                        !/[?&]/.test(path);
    
    // Set the host
    newUrl += rewriteHost ? 'docs.example.com' : 'example.com';
    
    // Add the path (preserve it exactly)
    newUrl += path || '';
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (1-12) and day (1-31, basic validation)
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}
