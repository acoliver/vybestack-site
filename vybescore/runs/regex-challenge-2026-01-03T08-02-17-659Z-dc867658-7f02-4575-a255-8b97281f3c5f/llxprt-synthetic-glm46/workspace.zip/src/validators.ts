export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common format rules.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject emails with consecutive dots
  if (value.includes('..')) return false;
  
  // Reject emails with trailing dot in local or domain part
  if (value.endsWith('.@') || value.endsWith('.com') || value.endsWith('.org') || 
      value.endsWith('.net') || value.endsWith('.co.uk') || value.includes('@.') || 
      value.includes('. .') || value.includes('.@') || value.includes('@.')) {
    // More specific check for trailing dots
    const parts = value.split('@');
    if (parts.length !== 2) return false;
    if (parts[0].endsWith('.') || parts[1].endsWith('.')) return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have 10 digits (standard) or 11 digits (with country code)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Remove the country code for validation
    return isValidUSPhoneCore(digitsOnly.substring(1));
  } else if (digitsOnly.length === 10) {
    return isValidUSPhoneCore(digitsOnly);
  }
  
  return false;
}

/**
 * Core validation for 10-digit US phone numbers.
 */
function isValidUSPhoneCore(digits: string): boolean {
  if (digits.length !== 10) return false;
  
  // Area code shouldn't start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') return false;
  
  // For validation with digits only, we only need to check the digit pattern
  return true;
}

/**
 * Validates Argentine phone numbers covering landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2-4 digits (leading digit 1-9).
 * - Subscriber number (after the area code) must contain 6-8 digits in total.
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Regex for Argentine phone numbers
  // ^(\+54)?(0|9)?([1-9]\d{1,3})\d{6,8}$
  // Explanation:
  // ^(\+54)? - Optional country code
  // (0|9)? - Optional trunk prefix (0) or mobile indicator (9)
  // ([1-9]\d{1,3}) - Area code (2-4 digits, cannot start with 0)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  
  const argentinePhoneRegex = /^(\+54)?0?9?([1-9]\d{1,3})\d{6,8}$/;
  
  // Special case: if no country code, must have trunk prefix
  const withoutCountryCodeRegex = /^0([1-9]\d{1,3})\d{6,8}$/;
  
  // If it starts with +54, the rest can have optional 0 trunk prefix and/or 9 mobile indicator
  if (cleanValue.startsWith('+54')) {
    const afterCountryCode = cleanValue.substring(3); // Remove +54
    return argentinePhoneRegex.test(cleanValue) || 
           (afterCountryCode.startsWith('9') && argentinePhoneRegex.test(cleanValue)) ||
           (afterCountryCode.startsWith('0') && argentinePhoneRegex.test(cleanValue));
  }
  
  // If no country code, it must start with trunk prefix 0
  return withoutCountryCodeRegex.test(cleanValue);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, spaces, apostrophes, hyphens
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check against regex
  if (!nameRegex.test(value)) return false;
  
  // Check for invalid sequences like multiple consecutive spaces or punctuation
  if (/\s{2,}/.test(value)) return false;
  if (/'{2,}|-{2,}/.test(value)) return false;
  
  // Ensure at least one letter
  if (!/[\p{L}]/u.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check digits only
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check length (13-19 digits for major cards)
  if (cleanValue.length < 13 || cleanValue.length > 19) return false;
  
// Check prefixes for major card types
  const visaRegex = /^4\d{12,18}$/;
  const mastercardRegex = /^5[1-5]\d{14,17}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanValue) && 
      !mastercardRegex.test(cleanValue) && 
      !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Perform Luhn checksum algorithm on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  const isEven = cardNumber.length % 2 === 0;
  
  for (let i = 0; i < cardNumber.length; i++) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (i % 2 === (isEven ? 0 : 1)) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}
