/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex and create a pattern to match words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp('\\b' + escapedPrefix + '\\w*\\b', 'g');
  
  const foundWords: string[] = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[0];
    
    // Check if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      foundWords.push(word);
    }
  }
  
  return foundWords;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of digit+token
  const regex = new RegExp('\\d' + escapedToken, 'g');
  const matches: string[] = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
// Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, testtest, etc.)
  // This checks for patterns that repeat a sequence of 2+ characters
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that covers:
  // - Full IPv6 notation (e.g., ::1)
  // - Compressed notation with :: (e.g., 2001:db8::1)
  // - IPv6 with embedded IPv4 (e.g., ::ffff:192.168.0.1)
  // - Interface identifiers (e.g., fe80::1%lo0)
  
  const ipv6Regex = /((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  
  return ipv6Regex.test(value);
}
