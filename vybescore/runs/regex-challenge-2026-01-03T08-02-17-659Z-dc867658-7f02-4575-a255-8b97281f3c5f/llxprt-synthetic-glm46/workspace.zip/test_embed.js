function findEmbeddedToken(text, token) {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token after a digit, using positive lookbehind
  const tokenRegex = new RegExp('(?<=\\d)' + escapedToken, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

console.log(findEmbeddedToken('xfoo 1foo foo', 'foo'));