import('./dist/src/puzzles.js').then(puzzles => {
  console.log('findPrefixedWords result:', puzzles.findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));
  console.log('findEmbeddedToken result:', puzzles.findEmbeddedToken('xfoo 1foo foo', 'foo'));
});