function findEmbeddedToken(text, token) {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of digit+token
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = [];
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

console.log(findEmbeddedToken('xfoo 1foo foo', 'foo'));