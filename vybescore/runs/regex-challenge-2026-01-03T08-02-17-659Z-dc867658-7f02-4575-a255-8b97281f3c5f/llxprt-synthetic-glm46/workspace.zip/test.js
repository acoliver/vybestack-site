function findPrefixedWords(text, prefix, exceptions) {
  // Escape the prefix for regex and create a pattern to match words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp('\\b' + escapedPrefix + '\\w*\\b', 'g');
  
  const foundWords = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[0];
    
    // Check if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      foundWords.push(word);
    }
  }
  
  return foundWords;
}

console.log(findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));