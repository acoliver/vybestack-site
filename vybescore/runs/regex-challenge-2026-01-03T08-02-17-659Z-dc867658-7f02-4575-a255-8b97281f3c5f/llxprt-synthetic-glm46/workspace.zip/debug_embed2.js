const text = 'xfoo 1foo foo';
const token = 'foo';

// Test the regex
const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const tokenRegex = new RegExp(`(\d${escapedToken})`, 'g');
console.log('regex:', tokenRegex);
console.log('text:', text);

let match;
while ((match = tokenRegex.exec(text)) !== null) {
  console.log('match found:', match[0]);
}