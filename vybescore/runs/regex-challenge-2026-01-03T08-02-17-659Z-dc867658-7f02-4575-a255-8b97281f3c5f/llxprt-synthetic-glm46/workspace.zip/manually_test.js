// Test escape pattern directly
const prefix = 'pre';
const escaped = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
console.log('escaped:', escaped);
console.log('literal in code:', '[.*+?^${}()|[\\]\\]');