// Try to debug the issue with findPrefixedWords

function findPrefixedWords(text, prefix, exceptions) {
  // Escape the prefix for regex and create a pattern to match words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  console.log('escapedPrefix:', escapedPrefix);
  
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'g');
  console.log('wordRegex:', wordRegex);
  console.log('text:', text);
  
  const foundWords = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[0];
    console.log('found match:', word);
    
    // Check if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      console.log('adding to results');
      foundWords.push(word);
    }
  }
  
  return foundWords;
}

console.log(findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));