function findEmbeddedToken(text, token) {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Alternative approach: match digit+token and extract just the token
  const tokenRegex = new RegExp(`(\d${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Get just the token part (after the digit)
    console.log('matched:', match[0], 'substring:', match[0].substring(1));
    matches.push(match[0].substring(1));
  }
  
  return matches;
}

console.log(findEmbeddedToken('xfoo 1foo foo', 'foo'));