export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows typical formats like name+tag@example.co.uk
  // - Rejects double dots (..), trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // If there's a leading +, only allow +1
  if (cleaned.startsWith('+')) {
    if (!cleaned.startsWith('+1')) return false;
    cleaned = cleaned.substring(2); // Remove +1
  }
  
  // Must be 10 digits exactly
  if (cleaned.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other punctuation
  const cleaned = value.replace(/[\s().-]/g, '');
  
  // Check for valid format patterns
  // Pattern: (optional +54) + (optional 9) + area code (2-4 digits) + subscriber (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) return false;
  
  const [, , , areaCode, subscriber] = match;
  
  // If no country code, must have trunk prefix (original '0' at start)
  if (!cleaned.startsWith('+54')) {
    if (!value.trim().startsWith('0')) return false;
  }
  
  // Area code must be 2-4 digits and not start with 0
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber number must be 6-8 digits total
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name regex that:
  // - Allows unicode letters, accents, apostrophes, hyphens, spaces
  // - Rejects digits, symbols, and special patterns like "X Æ A-12"
  const nameRegex = /^(?:[\p{L}][\p{L}'\- ]*[\p{L}]|[\p{L}])[\p{L}'\- ]*$/u;
  return nameRegex.test(value);
}

/**
 * Validate credit cards using Luhn algorithm and card type detection.
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check card type by prefix and length
  // Visa: 4xxx xxxx xxxx xxxx (13, 16, or 19 digits)
  // Mastercard: 5[1-5]xx xxxx xxxx xxxx (16 digits) or 2[2-7]xx xxxx xxxx xxxx (16 digits)
  // AmEx: 3[47]xx xxxx xxxxxx (15 digits)
  
  if (/^4\d{12}(\d{3})?(\d{3})?$/.test(cleaned)) {
    // Visa
  } else if (/^5[1-5]\d{14}$/.test(cleaned)) {
    // Mastercard
  } else if (/^2[2-7]\d{14}$/.test(cleaned)) {
    // Mastercard
  } else if (/^3[47]\d{13}$/.test(cleaned)) {
    // AmEx
  } else {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}