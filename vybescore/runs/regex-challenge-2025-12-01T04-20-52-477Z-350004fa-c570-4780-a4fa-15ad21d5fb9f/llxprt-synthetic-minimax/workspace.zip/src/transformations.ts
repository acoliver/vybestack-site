export function capitalizeSentences(text: string): string {
  return text.replace(/([.!?])\s*([A-Z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter;
  }).replace(/(^|[.!?]\s+)([a-z])/g, (match, start, letter) => {
    return start + letter.toUpperCase();
  });
}

export function extractUrls(text: string): string[] {
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+/gi;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    return url.replace(/[.,!?;]+$/, '');
  });
}

export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  const regex = /https?:\/\/([^/\s]+)(\/[^\s]*)/gi;
  return text.replace(regex, (match, host, path) => {
    let newUrl = `https://${host}`;
    
    if (path.startsWith('/docs/')) {
      const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasDynamicHints = dynamicHints.some(hint => path.includes(hint));
      
      if (!hasDynamicHints) {
        const docsHost = `docs.${host}`;
        newUrl = `https://${docsHost}${path}`;
      }
    }
    
    return newUrl;
  });
}

export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}