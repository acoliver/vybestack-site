/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex to match words starting with the prefix
  // Use word boundaries and escape special characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find digit followed by token, not at the start of string
  const fullMatchRegex = new RegExp(`(?<!^)(\\d)(${token})`, 'gi');
  const matches: string[] = [];
  let match;
  
  while ((match = fullMatchRegex.exec(text)) !== null) {
    matches.push(match[1] + match[2]); // digit + token
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // One uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // One lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // One digit
  if (!/\d/.test(value)) return false;
  
  // One symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab)
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles various formats including shorthand ::
  // This matches IPv6 addresses while excluding IPv4 addresses
  const ipv6Regex = /\b(?:[A-Fa-f0-9]{1,4}:){1,7}[A-Fa-f0-9]{1,4}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,6}:[A-Fa-f0-9]{1,4}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,5}(?::[A-Fa-f0-9]{1,4}){1,2}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,4}(?::[A-Fa-f0-9]{1,4}){1,3}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,3}(?::[A-Fa-f0-9]{1,4}){1,4}\b|\b(?:[A-Fa-f0-9]{1,4}:){1,2}(?::[A-Fa-f0-9]{1,4}){1,5}\b|\b[A-Fa-f0-9]{1,4}:(?:(?::[A-Fa-f0-9]{1,4}){1,6})\b|\b:(?:(?::[A-Fa-f0-9]{1,4}){1,7}|:)\b/;
  
  return ipv6Regex.test(value);
}
