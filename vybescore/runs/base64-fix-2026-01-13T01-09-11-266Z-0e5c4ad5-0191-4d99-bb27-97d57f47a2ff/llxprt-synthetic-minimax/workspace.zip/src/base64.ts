/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input contains only valid Base64 characters.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains unauthorized characters');
  }
  
  // Validate proper padding if present
  if (input.length > 0 && input.includes('=')) {
    const withoutPadding = input.replace(/=/g, '');
    const mod4 = withoutPadding.length % 4;
    // Valid remainders: 0 (no padding), 2 (== padding), 3 (= padding)
    if (mod4 !== 0 && mod4 !== 2 && mod4 !== 3) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
