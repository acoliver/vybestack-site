/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  const prefixedWordRegex = new RegExp('\\b' + escapedPrefix + '[\\w\']*', 'gi');
  
  const matches = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions and duplicates
  const uniqueWords = new Set<string>();
  const lowerCaseExceptions = new Set(exceptions.map(e => e.toLowerCase()));
  
  for (const match of matches) {
    const lowerMatch = match.toLowerCase();
    if (!lowerCaseExceptions.has(lowerMatch)) {
      uniqueWords.add(match);
    }
  }
  
  return Array.from(uniqueWords);
}

/**
 * Find occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  
  // Use matchAll to get all occurrences and get the full match with the digit
  const fullMatches = [...text.matchAll(new RegExp('(\\d' + escapedToken + ')', 'g'))];
  
  return fullMatches.map(match => match[1]);
}

/**
 * Validate password strength according to specified criteria.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This regex checks for patterns of 2-4 characters that repeat immediately
  const repeatedPatternRegex = /(.{2,4})\1+/;
  if (repeatedPatternRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that includes shorthand notation
  // This pattern matches standard IPv6 formats including compressed forms with ::
  const ipv6Regex = /^(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?::(?:[0-9a-fA-F]{1,4}:){1,4}|(?:[0-9a-fA-F]{1,4}:){0,5}:[0-9a-fA-F]{1,4}))$/;
  
  // First, check if the string is a valid IPv4 address and exclude it
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // Check if the string contains a valid IPv6 pattern
  // We need to find IPv6 patterns within the text, not just exact matches
  const ipv6InTextRegex = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/g;
  
  const matches = value.match(ipv6InTextRegex);
  if (!matches) return false;
  
  // Verify that each match is a valid IPv6 address
  for (const match of matches) {
    if (ipv6Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}