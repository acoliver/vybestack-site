export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive checks.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure check - not empty, no double dots, no leading/trailing dots
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Email regex - captures local part and domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // No underscores in domain part
  const domainHasUnderscore = /@.*_/.test(value);
  
  // Domain should not end with a dot
  const domainEndsInDot = /@.*\.$/.test(value);
  
  // Valid TLD check (simplified)
  const validTLD = /\.(com|org|net|edu|gov|mil|int|aero|asia|biz|cat|coop|info|jobs|mobi|museum|name|pro|tel|travel|ac|ad|ae|af|ag|ai|al|am|an|ao|aq|ar|as|at|au|aw|ax|az|ba|bb|bd|be|bf|bg|bh|bi|bj|bm|bn|bo|br|bs|bt|bv|bw|by|bz|ca|cc|cd|cf|cg|ch|ci|ck|cl|cm|cn|co|cr|cs|cu|cv|cx|cy|cz|de|dj|dk|dm|do|dz|ec|ee|eg|eh|er|es|et|eu|fi|fj|fk|fm|fo|fr|ga|gb|gd|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gs|gt|gu|gw|gy|hk|hm|hn|hr|ht|hu|id|ie|il|im|in|io|iq|ir|is|it|je|jm|jo|jp|ke|kg|kh|ki|km|kn|kp|kr|kw|ky|kz|la|lb|lc|li|lk|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mh|mk|ml|mm|mn|mo|mp|mq|mr|ms|mt|mu|mv|mw|mx|my|mz|na|nc|ne|nf|ng|ni|nl|no|np|nr|nu|nz|om|pa|pe|pf|pg|ph|pk|pl|pm|pn|pr|ps|pt|pw|py|qa|re|ro|ru|rw|sa|sb|sc|sd|se|sg|sh|si|sj|sk|sl|sm|sn|so|sr|st|su|sv|sy|sz|tc|td|tf|tg|th|tj|tk|tl|tm|tn|to|tp|tr|tt|tv|tw|tz|ua|ug|uk|um|us|uy|uz|va|vc|ve|vg|vi|vn|vu|wf|ws|ye|yt|yu|za|zm|zw)$/i.test(value);
  
  if (!emailRegex.test(value) || domainHasUnderscore || domainEndsInDot || !validTLD) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for area code + number)
  if (digitsOnly.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.slice(1);
  } else if (digitsOnly.length > 10) {
    // If longer than 11 digits, invalid unless extensions are allowed
    if (options?.allowExtensions) {
      // Check if there's an extension pattern
      const extMatch = value.match(/ext\.?\s*(\d+)|x\s*(\d+)/i);
      if (extMatch) {
        phoneNumber = digitsOnly.slice(0, 10);
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  
  // Must be exactly 10 digits after country code removal
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Argentine phone validation regex
  // Optional +54 country code, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:54)?(?:0?)?(?:9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(digitsOnly)) {
    return false;
  }
  
  const match = digitsOnly.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code validation (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!digitsOnly.startsWith('54') && !digitsOnly.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphenation.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Name regex - allows unicode letters, accents, apostrophes, hyphens, spaces
  // Minimum 2 characters, maximum reasonable length
  const nameRegex = /^[\p{L}\p{M}'\-\s]{2,50}$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that look like serial numbers or codes (have consecutive numbers)
  if (/\d{2,}/.test(value)) {
    return false;
  }
  
  // Reject single character names surrounded by symbols (like "X Æ A-12")
  if (/[A-Za-z]\s*[Ææ]\s*[A-Za-z]\s*-\s*\d+/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper function for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for major providers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if value contains only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Credit card validation with prefix and length checks
  const creditCardRegex = /^(?:(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(3[47][0-9]{13})|(6(?:011|5[0-9]{2})[0-9]{12}))$/;
  
  const isValidFormat = creditCardRegex.test(cleanValue);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}