/**
 * Capitalize the first character of each sentence.
 * After sentence terminators (.?!), capitalize the first letter and ensure proper spacing.
 * Collapses extra spaces and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Step 1: Ensure proper spacing after sentence terminators
  // Add space after .?! if not already there, but don't break abbreviations
  let normalized = text.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Step 2: Collapse multiple spaces into single spaces
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Step 3: Trim leading/trailing whitespace
  normalized = normalized.trim();
  
  // Step 4: Capitalize first letter of the text
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Step 5: Capitalize after sentence terminators while being careful about abbreviations
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (match, terminator, letter) => {
    return terminator + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extract all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern that matches common URL formats
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    return url.replace(/[.,!?;:)]+$/, '');
  });
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs according to specific rules:
 * - Always upgrade to https
 * - Rewrite example.com/docs/* to docs.example.com/*
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, upgrade all http to https
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  // Pattern to match example.com URLs and capture the path
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/g;
  
  result = result.replace(urlPattern, (match, protocol, host, path = '') => {
    // Skip if host is not example.com (to avoid affecting other domains)
    if (!host.includes('example.com')) {
      return match;
    }
    
    // Default result with upgraded protocol
    let newUrl = 'https://' + host;
    
    // Check if we should rewrite the host and if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exclusion patterns that indicate dynamic content
      const hasExclusionPattern = [
        /\/cgi-bin\//i,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i,
        /\?/i,  // Any query string
      ].some(pattern => pattern.test(path));
      
      if (!hasExclusionPattern) {
        // Rewrite the host to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      } else {
        // Keep original host but ensure https
        newUrl = 'https://' + host + path;
      }
    } else {
      // Path doesn't start with /docs/, keep original structure but ensure https
      newUrl += path;
    }
    
    return newUrl;
  });
  
  return result;
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Return "N/A" if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check - for simplicity, we don't check month-specific days)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return yearStr;
}