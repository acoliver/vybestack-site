import { createApp } from './src/server/app.js';

async function testPagination() {
  console.log('Testing API pagination...');
  const app = await createApp();
  
  // Mock a request to /inventory
  const mockReq = {
    query: {}
  };
  
  let resData;
  let resStatus;
  
  const mockRes = {
    status: function(code) {
      resStatus = code;
      return this;
    },
    json: function(data) {
      resData = data;
      console.log('Response:', JSON.stringify(data, null, 2));
      return this;
    }
  };
  
  // Test default parameters (should use page=1, limit=5)
  app._router.handle({ ...mockReq, method: 'GET', url: '/inventory', app }, mockRes);
  
  // Test with page and limit parameters
  mockReq.query = { page: '1', limit: '5' };
  app._router.handle({ ...mockReq, method: 'GET', url: '/inventory', app }, mockRes);
  
  // Test pagination to second page
  mockReq.query = { page: '2', limit: '5' };
  app._router.handle({ ...mockReq, method: 'GET', url: '/inventory', app }, mockRes);
  
  // Test invalid page parameter
  mockReq.query = { page: 'invalid' };
  app._router.handle({ ...mockReq, method: 'GET', url: '/inventory', app }, mockRes);
  console.log('Status for invalid page:', resStatus);
  
  // Test invalid limit parameter
  mockReq.query = { page: '1', limit: 'invalid' };
  app._router.handle({ ...mockReq, method: 'GET', url: '/inventory', app }, mockRes);
  console.log('Status for invalid limit:', resStatus);
  
  console.log('API tests completed');
}

testPagination().catch(console.error);