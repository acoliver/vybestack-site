import { createDatabase } from './src/server/db.ts';
import { listInventory } from './src/server/inventoryRepository.ts';

async function testPaginationImplementation(): Promise<void> {
  console.log('Testing pagination implementation...');
  
  // Create a fresh database
  const db = await createDatabase();
  
  // Test default pagination (page 1, default limit)
  console.log('\n--- Test 1: Default pagination (page 1, default limit) ---');
  let result = listInventory(db, {});
  console.log('Response:', JSON.stringify(result, null, 2));
  
  // Test specific pagination (page 1, limit 5)
  console.log('\n--- Test 2: Specific pagination (page 1, limit 5) ---');
  result = listInventory(db, { page: 1, limit: 5 });
  console.log('Response:', JSON.stringify(result, null, 2));
  
  // Test second page (page 2, limit 5)
  console.log('\n--- Test 3: Second page (page 2, limit 5) ---');
  result = listInventory(db, { page: 2, limit: 5 });
  console.log('Response:', JSON.stringify(result, null, 2));
  
  // Test with limit larger than available items
  console.log('\n--- Test 4: Limit larger than available items (page 1, limit 20) ---');
  result = listInventory(db, { page: 1, limit: 20 });
  console.log('Response:', JSON.stringify(result, null, 2));
  
  // Test page beyond available (should return empty)
  console.log('\n--- Test 5: Page beyond available (page 10, limit 5) ---');
  result = listInventory(db, { page: 10, limit: 5 });
  console.log('Response:', JSON.stringify(result, null, 2));
  
  // Verify total count
  console.log('\n--- Test 6: Total count verification ---');
  result = listInventory(db, { page: 1, limit: 100 });
  console.log('All items count:', result.items.length, 'Expected total:', result.total);
  
  console.log('\nAll pagination tests completed');
  process.exit(0);
}

testPaginationImplementation().catch(console.error);