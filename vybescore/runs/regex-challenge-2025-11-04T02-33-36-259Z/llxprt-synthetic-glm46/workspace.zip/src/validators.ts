export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Accept typical addresses such as name+tag@example.co.uk. 
 * Reject double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that:
  // - Allows letters, digits, and special characters in local part
  // - Supports + tags in local part
  // - Rejects consecutive dots
  // - Rejects dots at start or end
  // - Rejects underscores in domain
  // - Requires proper domain format with at least one dot
  const emailRegex = /^(?![.])[^@\s]+@[^-_\s][^@\s_-]*\.[^@\s_-][^@\s._-]+$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for specific issues
  if (value.includes('..')) return false; // Consecutive dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // Leading/trailing dots
  
  const [localPart, domain] = value.split('@');
  
  // Local part should not start or end with special characters
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain should not contain underscores
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 * Support formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallow impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if starts with country code +1
  const hasCountryCode = value.startsWith('+1');
  const digitsWithoutCountry = hasCountryCode ? digits.substring(1) : digits;
  
  // US phone numbers should have exactly 10 digits after removing country code
  if (digitsWithoutCountry.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digitsWithoutCountry.substring(0, 3);
  
  // Area code should not start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate the overall format
  const phoneRegex = /^(\+1[\s-]?)?(\([0-9]{3}\)|[0-9]{3})[\s-]?[0-9]{3}[\s-]?[0-9]{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2-4 digits (leading digit 1-9).
 * - Subscriber number (after the area code) must contain 6-8 digits in total.
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens to get clean digits
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if starts with country code
  const hasCountryCode = value.startsWith('+54');
  
  // If has country code, verify format
  if (hasCountryCode) {
    const withoutCountry = cleaned.substring(2); // Remove +54
    const hasMobileIndicator = withoutCountry.startsWith('9');
    const afterMobile = hasMobileIndicator ? withoutCountry.substring(1) : withoutCountry;
    
    // Extract area code (2-4 digits starting with 1-9)
    const areaCodeMatch = afterMobile.match(/^([1-9]\d{1,3})/);
    if (!areaCodeMatch) return false;
    
    const areaCode = areaCodeMatch[1];
    const subscriberDigits = afterMobile.substring(areaCode.length);
    
    // Validate lengths
    if (subscriberDigits.length < 6 || subscriberDigits.length > 8) return false;
    
    return true;
  } else {
    // Without country code, must start with trunk prefix 0
    if (!cleaned.startsWith('0')) return false;
    
    // Extract area code after trunk prefix
    const afterTrunk = cleaned.substring(1);
    const areaCodeMatch = afterTrunk.match(/^([1-9]\d{1,3})/);
    if (!areaCodeMatch) return false;
    
    const areaCode = areaCodeMatch[1];
    const subscriberDigits = afterTrunk.substring(areaCode.length);
    
    // Validate lengths
    if (subscriberDigits.length < 6 || subscriberDigits.length > 8) return false;
    
    return true;
  }
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permit unicode letters, accents, apostrophes, hyphens, spaces. 
 * Reject digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Include specific unicode ranges for international characters
  // Reject digits, special symbols, and emoji
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional checks for obvious invalid patterns
  // Reject names with consecutive symbols
  if (value.includes("--") || value.includes("''") || 
      value.includes("-'") || value.includes("'--")) return false;
  
  // Reject names with leading or trailing symbols or spaces
  if (value.startsWith("-") || value.endsWith("-") || 
      value.startsWith("'") || value.endsWith("'")) return false;
      
  // Ensure name has at least one letter (not just symbols/spaces)
  const hasLetter = /\p{L}/u.test(value);
  if (!hasLetter) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Quick length check
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check if all digits
  if (!/^\d+$/.test(digits)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55, 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d|20)\d{12}))$/;
  
  // Amex: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if card matches any supported brand
  const isValidBrand = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
  
  if (!isValidBrand) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
