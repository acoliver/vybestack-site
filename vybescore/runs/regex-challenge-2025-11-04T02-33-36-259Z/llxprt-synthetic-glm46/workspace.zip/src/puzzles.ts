/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to match words starting with the prefix
  // \b - word boundary
  // prefix - the actual prefix
  // [a-zA-Z]* - rest of the word (letters only)
  // \b - word boundary at the end
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  const results: string[] = [];
  for (const word of matches) {
    // Skip if word is in exceptions or matches exactly an exception
    if (exceptions.includes(word)) {
      continue;
    }
    results.push(word);
  }
  
  // Return unique words
  return [...new Set(results)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to find token occurrences after a digit
  // (?<!^) - negative lookbehind to ensure we're not at start of string
  // (\d) - capture a digit
  // (escapedToken) - followed by our token
  const tokenPattern = new RegExp(`(?<!^)(\\d)(${escapedToken})`, 'g');
  
  // Find all matches and capture the full match (digit + token)
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    matches.push(match[0]); // Return the full match (digit + token)
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, 
 * no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^\w]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, 123123)
  // Pattern to detect repeated sequences of 2 or more characters
  // (.+?) - capture any sequence of one or more characters (non-greedy)
  // \1 - repeat the captured sequence
  // Note: This approach catches immediate repetitions
  const repeatedSequenceRegex = /(.+?)\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 pattern that includes shorthand notation and excludes IPv4 addresses
  // Standard IPv6 sections:
  // - Full IPv6 with all 8 groups of 1-4 hex digits separated by colons
  // - IPv6 with :: shorthand for zeros
  // - IPv6 with embedded IPv4 (should be excluded from this detection)
  
  // Check for IPv4 addresses first to exclude them
  const ipv4Regex = /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Regex.test(value)) {
    // If only IPv4 is present, return false
    return !ipv4Regex.test(value);
  }
  
  // IPv6 regex pattern:
  // Matches standard formats and shorthand
  // Excludes IPv4 embedded addresses
  const ipv6Regex = /\b(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])[0-9]))\b/;
  
  // Simplified IPv6 pattern without embedded IPv4 detection
  const simplifiedIPv6Regex = /\b([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|::1?|::\b/;
  
  // Check for IPv6 pattern
  if (ipv6Regex.test(value)) {
    return true;
  }
  
  // Check for shorthand IPv6
  if (simplifiedIPv6Regex.test(value)) {
    return true;
  }
  
  return false;
}