/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalize the first character of each sentence (after .?!), insert exactly one space between 
 * sentences even if the input omitted it, and collapse extra spaces sensibly while leaving 
 * abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, normalize whitespace - replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Regex to match sentence boundaries:
  // ([.?!]) - match punctuation ending a sentence
  // \s* - match any amount of whitespace
  // ([a-z]) - match lowercase letter that starts next sentence
  const sentenceRegex = /([.?!])\s*([a-z])/g;
  
  // Replace with punctuation, single space, and capitalized letter
  result = result.replace(sentenceRegex, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Capitalize first character if it's lowercase
  if (result.length > 0 && result[0] === result[0].toLowerCase() && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex pattern to match URLs with http/https protocol
  // Match http:// or https://
  // Followed by domain names with subdomains
  // Followed by optional path, query string, and fragment
  // Captures the entire URL
  const urlRegex = /(https?:\/\/(?:www\.)?[^\s/$.?#].[^\s]*)/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation (. , ; : ! ?)
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Use regex to find http:// and replace with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/....
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://.
 * - Preserve nested paths (e.g., /docs/api/v1).
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, upgrade all http URLs to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match example.com URLs
  // Capture the entire URL to rewrite it
  const urlPattern = /(https:\/\/(?:www\.)?example\.com(\/[^\s]*))/gi;
  
  result = result.replace(urlPattern, (match, url, path) => {
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should prevent host rewrite
      const hasDynamicHints = /\/cgi-bin|[?&=]|[.](jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite URL to docs.example.com
        return match.replace(/https:\/\/(?:www\.)?example\.com/, 'https://docs.example.com');
      }
    }
    
    // For other cases, just keep the upgraded scheme
    return match;
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Additional validation for day based on month
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Days per month (excluding February which needs special handling)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const yearNum = parseInt(year, 10);
  let isLeapYear = false;
  if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
    isLeapYear = true;
  }
  
  // Validate day based on month
  if (monthNum === 2) {
    if (isLeapYear && dayNum > 29) return 'N/A';
    if (!isLeapYear && dayNum > 28) return 'N/A';
  } else if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
