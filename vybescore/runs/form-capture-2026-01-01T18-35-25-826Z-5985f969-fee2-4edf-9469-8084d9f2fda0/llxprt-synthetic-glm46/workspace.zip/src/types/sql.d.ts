declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): ResultSet[];
    export(): ArrayBuffer;
    close(): void;
  }

  export interface ResultSet {
    columns: string[];
    values: unknown[][];
  }

  interface SqlJsStatic {
    Database: new (data?: ArrayBuffer) => Database;
  }

  interface SqlJsConfigLocateFile {
    (file: string): string;
  }

  interface SqlJsConfig {
    locateFile?: SqlJsConfigLocateFile;
  }

  export default function createSqlJs(config?: SqlJsConfig): Promise<SqlJsStatic>;
}