import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import createSqlJs, { Database } from 'sql.js';
import type { SqlJsStatic } from 'sql.js';
import { Server } from 'http';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '../data/submissions.sqlite');

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface FormErrors {
  [key: string]: string | undefined;
}

// Import the SqlJsStatic type from our custom declaration

class FormCaptureServer {
  private appInstance: express.Application;
  private server: Server | null;
  private db: Database | null;
  private SQL: SqlJsStatic | null;

  constructor() {
    this.appInstance = express();
    this.server = null;
    this.db = null;
    this.SQL = null;
    this.setupMiddleware();
    this.setupRoutes();
    this.setupErrorHandling();
  }

  private setupMiddleware(): void {
    // Parse JSON and URL-encoded bodies
    this.appInstance.use(express.json());
    this.appInstance.use(express.urlencoded({ extended: true }));
    
    // Serve static files from the public directory
    this.appInstance.use('/public', express.static(path.resolve(__dirname, '../public')));
    
    // Set EJS as the view engine
    this.appInstance.set('view engine', 'ejs');
    this.appInstance.set('views', path.resolve(__dirname, '../src/templates'));
  }

  private async initDatabase(): Promise<void> {
    try {
      this.SQL = await createSqlJs({
        locateFile: (file: string) => path.resolve(__dirname, '../node_modules/sql.js/dist/', file)
      });

      let dbBuffer: ArrayBuffer | null = null;
      
      // Check if database file exists
      if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        // Convert Uint8Array to ArrayBuffer by creating a new ArrayBuffer with the same data
        const uint8Array = new Uint8Array(fileBuffer);
        dbBuffer = uint8Array.buffer.slice(uint8Array.byteOffset, uint8Array.byteOffset + uint8Array.byteLength);
      }
      
      this.db = new this.SQL.Database(dbBuffer || undefined);

      // Initialize schema if needed
      const schemaPath = path.resolve(__dirname, '../db/schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      this.db!.run(schemaSql);
      
      // Save the database with schema immediately after initialization
      this.saveDatabaseToDisk();
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabaseToDisk(): void {
    if (!this.db) return;
    
    try {
      // Create the data directory if it doesn't exist
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Save the database to disk
      const dbData = this.db.export();
      const buffer = Buffer.from(dbData);
      fs.writeFileSync(dbPath, buffer);
      
      console.log('Database saved to disk');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private closeDatabase(): void {
    // First save to disk before closing
    this.saveDatabaseToDisk();
    
    if (!this.db) return;
    
    try {
      this.db.close();
      this.db = null;
      console.log('Database closed');
    } catch (error) {
      console.error('Failed to close database:', error);
    }
  }

  private validateForm(data: FormData): FormErrors {
    const errors: FormErrors = {};

    // Required fields validation
    if (!data.firstName || data.firstName.trim() === '') {
      errors.firstName = 'First name is required';
    }
    
    if (!data.lastName || data.lastName.trim() === '') {
      errors.lastName = 'Last name is required';
    }
    
    if (!data.streetAddress || data.streetAddress.trim() === '') {
      errors.streetAddress = 'Street address is required';
    }
    
    if (!data.city || data.city.trim() === '') {
      errors.city = 'City is required';
    }
    
    if (!data.stateProvince || data.stateProvince.trim() === '') {
      errors.stateProvince = 'State / Province / Region is required';
    }
    
    if (!data.postalCode || data.postalCode.trim() === '') {
      errors.postalCode = 'Postal / Zip code is required';
    }
    
    if (!data.country || data.country.trim() === '') {
      errors.country = 'Country is required';
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!data.email || !emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
    
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s-()]+$/;
    if (!data.phone || !phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation - allow alphanumeric with spaces
    if (data.postalCode && !/^[a-zA-Z0-9\s]+$/.test(data.postalCode)) {
      errors.postalCode = 'Postal code can only contain letters, numbers, and spaces';
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - render the form
    this.appInstance.get('/', (req, res) => {
      res.render('form', { 
        errors: [], 
        values: {} 
      });
    });

    // POST /submit - handle form submission
    this.appInstance.post('/submit', async (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      // Validate form data
      const errors = this.validateForm(formData);
      
      // If validation fails, re-render the form with errors
      if (Object.keys(errors).length > 0) {
        res.status(400).render('form', { 
          errors: Object.values(errors), 
          values: formData 
        });
        return;
      }

      // Insert data into database
      try {
        const sql = `
          INSERT INTO submissions 
          (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;
        
        this.db!.run(sql, [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);
        
        // Save database to disk after insert
        this.saveDatabaseToDisk();
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', { 
          errors: ['An error occurred while saving your data. Please try again.'], 
          values: formData 
        });
        return;
      }

      // Redirect to thank you page with first name as parameter
      res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    });

    // GET /thank-you - render thank you page
    this.appInstance.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName || 'friend';
      res.render('thank-you', { firstName });
    });
  }

  private setupErrorHandling(): void {
    // 404 handler
    this.appInstance.use((req, res) => {
      res.status(404).send('Page not found');
    });

    // General error handler
    this.appInstance.use((err: Error, req: express.Request, res: express.Response) => {
      console.error(err);
      res.status(500).send('Internal Server Error');
    });
  }

  public async start(): Promise<void> {
    await this.initDatabase();
    
    const port = process.env.PORT || 3535;
    this.server = this.appInstance.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle SIGTERM for graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      this.close();
    });

    // Handle SIGINT for graceful shutdown
    process.on('SIGINT', () => {
      console.log('SIGINT received, shutting down gracefully');
      this.close();
    });
  }

  public close(callback?: () => void): void {
    if (this.server) {
      this.server.close(() => {
        console.log('HTTP server closed');
        this.closeDatabase();
        if (callback) {
          callback();
        }
      });
    } else {
      this.closeDatabase();
      if (callback) {
        callback();
      }
    }
  }

  // Add a getter for the app instance to access in tests
  public get app() {
    return this.appInstance;
  }
}

// Start the server if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormCaptureServer();
  server.start();
}

export default FormCaptureServer;