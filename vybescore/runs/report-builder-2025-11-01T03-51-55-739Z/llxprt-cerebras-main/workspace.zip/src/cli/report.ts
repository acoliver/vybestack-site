#!/usr/bin/env node

import { readFileSync } from 'fs';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function printUsage() {
  console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('Supported formats: markdown, text');
}

function validateData(data: any): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: root must be an object');
  }

  if (!data.title || typeof data.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }

  if (!data.summary || typeof data.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }

  if (!Array.isArray(data.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }

  for (const entry of data.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: each entry must be an object');
    }

    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error('Invalid data: each entry must have a string label');
    }

    if (typeof entry.amount !== 'number') {
      throw new Error('Invalid data: each entry must have a numeric amount');
    }
  }
}

function parseArguments(args: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const result: any = {
    includeTotals: false
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Missing value for --format');
      }
      result.format = args[i + 1];
      i += 2;
      continue;
    }
    
    if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Missing value for --output');
      }
      result.outputPath = args[i + 1];
      i += 2;
      continue;
    }
    
    if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
      continue;
    }
    
    if (!result.dataPath) {
      result.dataPath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
    
    i += 1;
  }

  if (!result.dataPath) {
    throw new Error('Missing data file path');
  }

  if (!result.format) {
    throw new Error('Missing --format argument');
  }

  return result;
}

function main() {
  try {
    const args = parseArguments(process.argv.slice(2));
    
    // Read and parse data
    const rawData = readFileSync(args.dataPath, 'utf8');
    const data = JSON.parse(rawData);
    validateData(data);
    
    // Render report
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(data, { includeTotals: args.includeTotals });
        break;
      case 'text':
        output = renderText(data, { includeTotals: args.includeTotals });
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }
    
    // Output
    if (args.outputPath) {
      // For simplicity, we're not implementing file output as it's not required in the problem description
      console.error('File output is not implemented in this version');
      process.exit(1);
    } else {
      console.log(output);
    }
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      console.error(`File not found: ${error.path}`);
    } else if (error instanceof SyntaxError) {
      console.error('Invalid JSON in data file');
    } else {
      console.error(error.message);
    }
    printUsage();
    process.exit(1);
  }
}

main();