/**
 * Finds words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Convert to lowercase for case-insensitive comparison with exceptions
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and return original case
  return matches.filter(match => {
    const matchLower = match.toLowerCase();
    return !exceptionsLower.some(exception => 
      matchLower === exception || matchLower.startsWith(exception + ' ')
    );
  });
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit+token combination (simpler approach that works across environments)
  const combinedPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(combinedPattern) || [];
  
  return matches;
}

/**
 * Validates passwords according to strong password policy.
 * Requirements: at least 10 chars, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (like 'abab').
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like 'abab', '123123', etc.)
  // Look for patterns of 2+ characters that repeat immediately
  const repeatedPatternRegex = /(.{2,})\1+/;
  if (repeatedPatternRegex.test(value)) return false;
  
  // Additional check for alternating patterns like 'ababab'
  const alternatingPatternRegex = /(.)(.)\1\2/;
  if (alternatingPatternRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation like ::.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Full IPv6 with 8 groups of 1-4 hex digits
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: compression (replacing consecutive groups of zeros)
  const compressedIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: at start or end
  const edgeCompressedIPv6 = /^::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$|^(?:[0-9a-fA-F]{1,4}:)*::[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with embedded IPv4 (like ::ffff:192.168.1.1)
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:)*:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Simple IPv6 pattern for basic detection
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|::/;
  
  // Check if we have any IPv6 patterns
  if (!ipv6Pattern.test(value)) return false;
  
  // Now exclude pure IPv4 addresses
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If the text contains only IPv4 and no IPv6, return false
  const ipv4Matches = value.match(ipv4Pattern) || [];
  
  // Check for any IPv6 patterns more aggressively
  return (fullIPv6.test(value) || compressedIPv6.test(value) || 
          edgeCompressedIPv6.test(value) || ipv6WithIPv4.test(value)) &&
         !(ipv4Matches.length > 0 && value.trim() === ipv4Matches[0]);
}
