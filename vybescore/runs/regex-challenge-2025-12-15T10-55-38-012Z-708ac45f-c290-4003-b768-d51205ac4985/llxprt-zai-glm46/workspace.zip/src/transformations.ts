/**
 * Capitalizes the first character of each sentence.
 * Handles sentence boundaries after punctuation marks.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  return text
    // Split by sentence endings, preserving the punctuation
    .split(/([.?!]+)/)
    .map((part, index) => {
      if (index % 2 === 1) {
        // This is punctuation
        return part + (index === text.split(/([.?!]+)/).length - 1 ? '' : ' ');
      } else {
        // This is a sentence part
        const trimmed = part.trim();
        if (trimmed.length === 0) return '';
        // Capitalize first letter and normalize spacing
        return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
      }
    })
    .join('')
    // Clean up extra spaces
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 * Matches http, https, www, and domain-only URLs.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/, ''));
}

/**
 * Upgrades http:// schemes to https:// while preserving existing https URLs.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrades to HTTPS
 * - Rewrites /docs/ paths to docs.example.com
 * - Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\/]+)(\/[^ \n]*)?/g, (match, host, path = '') => {
    // Check if we should skip host rewrite
    const skipHostRewrite = /\/cgi-bin\/|\?|&|=|\/.*\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (!skipHostRewrite && path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return `https://docs.${host}${path}`;
    }
    
    // Just upgrade to HTTPS
    return `https://${host}${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if the string doesn't match the format or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate days per month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Basic leap year check for February
  const isLeapYear = (yr: string) => {
    const yearNum = parseInt(yr, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  if (monthNum === 2 && isLeapYear(year) && dayNum > 29) return 'N/A';
  if (monthNum === 2 && !isLeapYear(year) && dayNum > 28) return 'N/A';
  if (dayNum > daysInMonth[monthNum - 1]) return 'N/A';
  
  return year;
}