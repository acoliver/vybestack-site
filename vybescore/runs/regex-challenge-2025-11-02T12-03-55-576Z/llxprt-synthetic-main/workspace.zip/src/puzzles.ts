/**
 * Find words beginning with the prefix but excluding the listed exceptions:
 * - Find words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape any special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  // Find all words starting with the prefix
  const matches = text.match(wordPattern) || [];
  
  // Filter out the exceptions
  return [...new Set(matches)] // Remove duplicates
    .filter(word => !exceptions.includes(word))
    .sort(); // Sort for consistent results
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string:
 * - Return occurrences where the token appears after a digit and not at the start of the string (use lookaheads/lookbehinds)
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token only when preceded by a digit and not at string start
  // Use lookbehind to check for digit preceding the token, and capture the digit+token together
  const tokenPattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  // Return unique results
  return [...new Set(matches)];
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc, etc.)
  // This pattern looks for any substring of 2-4 characters that repeats immediately
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses:
 * - Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 address pattern (simplified and more readable)
  // Standard IPv6: 8 groups of 1-4 hex digits separated by colons
  const standardIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: (consecutive colons replacing one or more groups of zeros)
  const shorthandIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}/;
  
  // IPv6 starting with :: (missing leading groups)
  const leadingShorthandPattern = /^::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}/;
  
  // IPv6 ending with :: (missing trailing groups)
  const trailingShorthandPattern = /(?:[0-9a-fA-F]{1,4}:){1,7}::$/;
  
  // IPv6 with embedded IPv4 address
  const embeddedIPv4Pattern = /(?:[0-9a-fA-F]{1,4}:){6}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // First check if there's an IPv4 address
  const isIPv4 = ipv4Pattern.test(value);
  
  // Check if there's an IPv6 address
  const isIPv6 = standardIPv6Pattern.test(value) || 
                shorthandIPv6Pattern.test(value) || 
                leadingShorthandPattern.test(value) || 
                trailingShorthandPattern.test(value) || 
                embeddedIPv4Pattern.test(value);
  
  // Return true only if IPv6 is found and IPv4 is not found
  // This ensures IPv4 addresses don't trigger a positive result
  return isIPv6 && !isIPv4;
}