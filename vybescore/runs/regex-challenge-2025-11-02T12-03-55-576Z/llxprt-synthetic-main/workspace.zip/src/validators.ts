export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  
  // Convert to array of digits and reverse
  const reversedDigits = cardNumber.split('').reverse().map(Number);
  
  for (let i = 0; i < reversedDigits.length; i++) {
    let digit = reversedDigits[i];
    
    // Double every second digit (from right)
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9; // Equivalent to summing the digits of the result
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with constraints:
 * - Accept typical addresses such as name+tag@example.co.uk
 * - Reject double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // - Local part: letters, digits, +, -, . but no consecutive dots or leading/trailing dots
  // - Domain: letters, digits, hyphens, and dots but no underscores and valid TLD
  const emailRegex = /^[a-zA-Z0-9]+(?:[._%+-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:[-][a-zA-Z0-9]+)*(?:\.[a-zA-Z0-9]+(?:[-][a-zA-Z0-9]+)*)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // - No double dots in local part
  if (value.includes('..')) return false;
  
  // - No leading/ trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // - No underscore in domain
  const domain = value.substring(value.indexOf('@') + 1);
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validate US phone numbers:
 * - Support formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallow impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Clean the input by removing spaces, hyphens, parentheses, and dots
  const cleanPhone = value.replace(/[\s\-\(\)\.]/g, '');
  
  // Handle optional +1 country code
  let effectivePhone = cleanPhone;
  if (cleanPhone.startsWith('+1')) {
    effectivePhone = cleanPhone.substring(2);
  } else if (cleanPhone.startsWith('1') && cleanPhone.length > 10) {
    effectivePhone = cleanPhone.substring(1);
  }
  
  // US phone numbers should have exactly 10 digits after removing country code
  if (effectivePhone.length !== 10 || !/^\d+$/.test(effectivePhone)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = effectivePhone.substring(0, 3);
  
  // Area code should not start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers:
 * - Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2–4 digits (leading digit 1–9)
 * - Subscriber number (after the area code) must contain 6–8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and parentheses for validation
  const cleanPhone = value.replace(/[\s\-\(\)]/g, '');
  
  // Argentine phone regex capturing all required components
  const phoneRegex = /^(\+54)?(0?)(9?)?(\d{2,4})(\d{6,8})$/;
  const match = cleanPhone.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // When country code is omitted, number must begin with trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits and first digit must be 1-9 (not 0)
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number must contain 6-8 digits
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Mobile prefix (9) is only valid for mobile numbers, but we don't need to check that specifically
  // It can appear between country/trunk and area code
  
  return true;
}

/**
 * Validate personal names:
 * - Permit unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Unicode letters with accents, apostrophes, hyphens, and spaces
  // Excludes digits and most symbols except allowed ones
  const nameRegex = /^[ \p{L}\p{M}'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional checks for extreme cases like X Æ A-12
  // This would contain digits which the regex would catch, but let's double-check for other invalid patterns
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers:
 * - Accept Visa/Mastercard/AmEx prefixes and lengths
 * - Run a Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanCard)) {
    return false;
  }
  
  // Visa: 13 or 16 digits starting with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // MasterCard: 16 digits starting with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;
  
  // AmEx: 15 digits starting with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the card patterns
  if (!visaRegex.test(cleanCard) && !mastercardRegex.test(cleanCard) && !amexRegex.test(cleanCard)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanCard);
}