/**
 * Capitalize the first character of each sentence:
 * - Capitalize the first character of each sentence (after .?!)
 * - Insert exactly one space between sentences even if the input omitted it
 * - Collapse extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing around sentence delimiters
  // This ensures exactly one space after periods, question marks, and exclamation marks
  let normalizedText = text.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Collapse multiple spaces to a single space (except newlines)
  normalizedText = normalizedText.replace(/[ \t]+/g, ' ');
  
  // Capitalize the first letter of the entire text
  let result = normalizedText.charAt(0).toUpperCase() + normalizedText.slice(1);
  
  // Capitalize the first letter after each sentence delimiter
  // The negative lookbehind ensures we don't match at the beginning again
  result = result.replace(/(?<!^)([.!?]\s+)([a-z])/g, (_, delimiter, letter) => {
    return delimiter + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text:
 * - Return URLs detected in the text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern that matches http/https and www URLs
  const urlPattern = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?|www\.(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]\}]+$/, ''));
}

/**
 * Force all http URLs to https:
 * - Replace http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints such as 
 *   cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, 
 *   .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http URLs
  const httpUrlPattern = /(https?):\/\/([^\/]+)(\/[^\s]*)?/g;
  
  return text.replace(httpUrlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https';
    
    // If path starts with /docs/, we need to potentially rewrite the host
    if (path.startsWith('/docs/')) {
      // Check if path contains any of the excluded patterns
      const excludedPatterns = [
        /\/cgi-bin\//,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#]|$)/i
      ];
      
      // If any excluded pattern is found, don't change the host
      const shouldSkipHostRewrite = excludedPatterns.some(pattern => pattern.test(path));
      
      if (shouldSkipHostRewrite) {
        return `${newScheme}://${host}${path}`;
      }
      
      // Rewrite host to docs.example.com
      // Always use docs.example.com regardless of original host
      return `${newScheme}://docs.example.com${path}`;
    }
    
    // Default case: just upgrade the scheme
    return `${newScheme}://${host}${path}`;
  });
}

/**
 * Extract the year from a date string:
 * - Return the four-digit year for mm/dd/yyyy
 * - If the string doesn't match that format or month/day are invalid, return N/A
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format where mm and dd are valid dates
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Additional validation for specific month/day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for invalid days in certain months
  // February has 28 days (ignoring leap years for simplicity)
  // April, June, September, November have 30 days
  // The rest have 31 days
  const daysInMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (dayNum > daysInMonths[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
