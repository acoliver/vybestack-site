/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<unknown>> // Track which subjects this observer depends on
  dirty?: boolean
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let isUpdating = false

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Call updateFn with no arguments to allow default parameters
    const newValue = observer.updateFn()
    observer.value = newValue
    return newValue
  } finally {
    activeObserver = previous
  }
}

/**
 * Notifies all observers of a subject about a value change and handles cascading updates.
 */
export function notifyObservers<T>(subject: Subject<T>): void {
  console.log(`DEBUG: notifyObservers called with subject: ${subject.name}, observers: ${subject.observers.size}`)
  if (subject.observers && !isUpdating) {
    isUpdating = true
    try {
      const observers = new Set(subject.observers) // Create a copy to avoid modification during iteration
      console.log(`DEBUG: Notifying ${observers.size} observers`)
      observers.forEach((observer, index) => {
        console.log(`DEBUG: Notifying observer ${index}: ${observer.name || 'unnamed'}`)
        if (observer && typeof observer === 'object') {
          // Re-evaluate this observer
          updateObserver(observer as Observer<unknown>)
        }
      })
    } finally {
      isUpdating = false
    }
  } else {
    console.log(`DEBUG: notifyObservers skipped - observers: ${subject.observers?.size}, isUpdating: ${isUpdating}`)
  }
}

/**
 * Tracks a dependency between the current active observer and a subject.
 * When the subject's value changes, it should trigger updates to all observers.
 */
export function trackDependency<T>(subject: Subject<T>, observer: ObserverR | undefined): void {
  if (observer && !isUpdating) {
    if (!subject.observers) {
      subject.observers = new Set()
    }
    subject.observers.add(observer)
    
    // Also track this dependency in the observer
    const typedObserver = observer as Observer<unknown>
    if (!typedObserver.dependencies) {
      typedObserver.dependencies = new Set()
    }
    typedObserver.dependencies.add(subject as Subject<unknown>)
  }
}
