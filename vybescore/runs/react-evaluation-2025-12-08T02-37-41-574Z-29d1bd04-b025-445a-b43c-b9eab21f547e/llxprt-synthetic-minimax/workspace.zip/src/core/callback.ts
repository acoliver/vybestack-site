/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
    name: 'callback-observer'
  }
  
  // Execute the update function to establish initial dependencies
  updateObserver(callbackObserver)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up dependencies
    if (callbackObserver.dependencies) {
      callbackObserver.dependencies.forEach(subject => {
        if (subject.observers) {
          subject.observers.delete(callbackObserver)
        }
      })
      callbackObserver.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    callbackObserver.value = undefined
    callbackObserver.updateFn = () => value as T
  }
}
