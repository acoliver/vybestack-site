/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  EqualFn,
  trackDependency,
  getActiveObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Create a getter function that re-evaluates the computed value
  const getter: GetterFn<T> = () => {
    // Track dependency on the active observer
    const activeObs = getActiveObserver()
    if (activeObs) {
      trackDependency(subject, activeObs)
    }
    
    // Re-evaluate the computed value and track dependencies
    const result = updateObserver(observer)
    const previousValue = subject.value
    subject.value = result
    
    // Notify observers if the value changed
    if (result !== previousValue && subject.observers.size > 0) {
      notifyObservers(subject)
    }
    
    return result
  }
  
  return getter
}
