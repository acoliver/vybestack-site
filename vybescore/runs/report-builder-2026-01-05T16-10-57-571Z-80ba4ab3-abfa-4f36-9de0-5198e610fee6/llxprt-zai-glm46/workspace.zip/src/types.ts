/**
 * Shared type definitions for the report builder CLI.
 */

/**
 * Represents a single entry in the report.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * The structure of the input JSON data.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering a report.
 */
export interface RenderOptions {
  includeTotals?: boolean;
}

/**
 * Format function signature.
 */
export type FormatRenderer = (data: ReportData, options: RenderOptions) => string;
