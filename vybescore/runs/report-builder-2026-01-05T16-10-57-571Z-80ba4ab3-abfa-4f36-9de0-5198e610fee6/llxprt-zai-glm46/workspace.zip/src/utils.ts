/**
 * Utility functions for report rendering.
 */

import type { ReportEntry } from './types.js';

/**
 * Formats a number as a currency string with exactly two decimal places.
 * No thousands separators are used.
 */
export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}

/**
 * Calculates the total amount from an array of entries.
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}
