#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Renders reports from JSON input in various formats.
 *
 * Usage:
 *   node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';

import type { ReportData, RenderOptions } from '../types.js';
import { FORMAT_RENDERERS, SUPPORTED_FORMATS } from '../formats/index.js';

/**
 * Parsed CLI arguments.
 */
interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments using Node's standard library.
 * Supports positional args and flags in any order.
 */
function parseArgs(processArgs: string[]): CliArgs {
  const args = processArgs.slice(2); // Skip ['node', 'script.js']
  
  let dataFile: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        stderr('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        stderr('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Positional argument - treat as data file
      dataFile = arg;
    } else {
      stderr(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!dataFile) {
    stderr('Error: Missing required argument <data.json>');
    stderr('');
    stderr('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!format) {
    stderr('Error: Missing required flag --format');
    stderr('');
    stderr('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

/**
 * Writes to stderr.
 */
function stderr(message: string): void {
  process.stderr.write(message + '\n');
}

/**
 * Reads and parses JSON input data.
 */
function loadData(dataFile: string): ReportData {
  let content: string;
  try {
    content = fs.readFileSync(dataFile, 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${dataFile}`);
    }
    throw new Error(`Failed to read file: ${dataFile}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON in file: ${dataFile}`);
  }

  // Validate data structure
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: entry at index ${i} is not an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: entry at index ${i} missing or invalid "label" field (must be a string)`);
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI entry point.
 */
function main(): void {
  const args = parseArgs(process.argv);

  // Validate format
  if (!SUPPORTED_FORMATS.includes(args.format)) {
    stderr(`Error: Unsupported format '${args.format}'`);
    stderr(`Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
    process.exit(1);
  }

  // Load and validate data
  let data: ReportData;
  try {
    data = loadData(args.dataFile);
  } catch (error) {
    stderr(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }

  // Get renderer and generate output
  const renderer = FORMAT_RENDERERS[args.format];
  const options: RenderOptions = {
    includeTotals: args.includeTotals
  };

  const output = renderer(data, options);

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      stderr(`Report written to ${args.outputPath}`);
    } catch (error) {
      stderr(`Error: Failed to write output file: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output + '\n');
  }
}

// Run the CLI
main();
