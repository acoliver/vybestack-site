/**
 * Plain text format renderer for reports.
 */

import type { ReportData, RenderOptions, FormatRenderer } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

/**
 * Renders a report in plain text format.
 */
export const renderText: FormatRenderer = (
  data: ReportData,
  options: RenderOptions = {}
): string => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  lines.push('');

  // Entry list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    lines.push('');
    lines.push(`Total: $${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};
