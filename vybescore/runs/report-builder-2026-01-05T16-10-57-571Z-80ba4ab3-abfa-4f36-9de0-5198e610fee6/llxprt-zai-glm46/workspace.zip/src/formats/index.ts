/**
 * Central registry of available format renderers.
 */

import type { FormatRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Map of supported format names to their renderer functions.
 */
export const FORMAT_RENDERERS: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText
};

/**
 * List of supported format names.
 */
export const SUPPORTED_FORMATS = Object.keys(FORMAT_RENDERERS);
