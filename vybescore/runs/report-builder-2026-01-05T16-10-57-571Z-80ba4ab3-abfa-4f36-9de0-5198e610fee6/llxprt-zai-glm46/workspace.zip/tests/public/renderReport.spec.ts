import { describe, expect, it } from 'vitest';
import { spawnSync } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';

const CLI_PATH = path.join(process.cwd(), 'dist', 'cli', 'report.js');
const FIXTURE_PATH = path.join(process.cwd(), 'fixtures', 'data.json');

describe('report CLI (public smoke)', () => {
  it('should render markdown format without totals', () => {
    const result = spawnSync('node', [CLI_PATH, FIXTURE_PATH, '--format', 'markdown'], {
      encoding: 'utf-8'
    });

    expect(result.status).toBe(0);
    expect(result.stdout).toContain('# Quarterly Financial Summary');
    expect(result.stdout).toContain('## Entries');
    expect(result.stdout).toContain('**North Region** — $12345.67');
    expect(result.stdout).toContain('**South Region** — $23456.78');
    expect(result.stdout).toContain('**West Region** — $34567.89');
    expect(result.stdout).not.toContain('Total:');
  });

  it('should render markdown format with totals', () => {
    const result = spawnSync('node', [CLI_PATH, FIXTURE_PATH, '--format', 'markdown', '--includeTotals'], {
      encoding: 'utf-8'
    });

    expect(result.status).toBe(0);
    expect(result.stdout).toContain('**Total:** $70370.34');
  });

  it('should render text format without totals', () => {
    const result = spawnSync('node', [CLI_PATH, FIXTURE_PATH, '--format', 'text'], {
      encoding: 'utf-8'
    });

    expect(result.status).toBe(0);
    expect(result.stdout).toContain('Quarterly Financial Summary');
    expect(result.stdout).toContain('Entries:');
    expect(result.stdout).toContain('- North Region: $12345.67');
    expect(result.stdout).toContain('- South Region: $23456.78');
    expect(result.stdout).toContain('- West Region: $34567.89');
    expect(result.stdout).not.toContain('Total:');
  });

  it('should render text format with totals', () => {
    const result = spawnSync('node', [CLI_PATH, FIXTURE_PATH, '--format', 'text', '--includeTotals'], {
      encoding: 'utf-8'
    });

    expect(result.status).toBe(0);
    expect(result.stdout).toContain('Total: $70370.34');
  });

  it('should reject unsupported format', () => {
    const result = spawnSync('node', [CLI_PATH, FIXTURE_PATH, '--format', 'xml'], {
      encoding: 'utf-8'
    });

    expect(result.status).not.toBe(0);
    expect(result.stderr).toContain('Unsupported format');
  });

  it('should handle missing file', () => {
    const result = spawnSync('node', [CLI_PATH, 'nonexistent.json', '--format', 'markdown'], {
      encoding: 'utf-8'
    });

    expect(result.status).not.toBe(0);
    expect(result.stderr).toContain('File not found');
  });

  it('should handle invalid JSON', () => {
    const invalidPath = path.join(process.cwd(), 'fixtures', 'invalid.json');
    fs.writeFileSync(invalidPath, '{ invalid json }');
    
    const result = spawnSync('node', [CLI_PATH, invalidPath, '--format', 'markdown'], {
      encoding: 'utf-8'
    });

    expect(result.status).not.toBe(0);
    expect(result.stderr).toContain('Invalid JSON');
    
    fs.unlinkSync(invalidPath);
  });

  it('should write output to file when --output is provided', () => {
    const outputPath = path.join(process.cwd(), 'test-output.md');
    
    const result = spawnSync('node', [CLI_PATH, FIXTURE_PATH, '--format', 'markdown', '--output', outputPath], {
      encoding: 'utf-8'
    });

    expect(result.status).toBe(0);
    expect(fs.existsSync(outputPath)).toBe(true);
    
    const content = fs.readFileSync(outputPath, 'utf-8');
    expect(content).toContain('# Quarterly Financial Summary');
    
    fs.unlinkSync(outputPath);
  });
});
