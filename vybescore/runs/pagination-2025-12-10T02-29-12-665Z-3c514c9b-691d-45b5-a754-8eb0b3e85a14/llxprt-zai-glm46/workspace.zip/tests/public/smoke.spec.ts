import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns default pagination with page 1 and limit 5', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBeLessThanOrEqual(5);
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('respects page and limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test page 1 with limit 3
    const page1Response = await request(app).get('/inventory?page=1&limit=3');
    expect(page1Response.status).toBe(200);
    expect(page1Response.body.page).toBe(1);
    expect(page1Response.body.limit).toBe(3);
    expect(page1Response.body.items.length).toBe(3);

    // Test page 2 with limit 3
    const page2Response = await request(app).get('/inventory?page=2&limit=3');
    expect(page2Response.status).toBe(200);
    expect(page2Response.body.page).toBe(2);
    expect(page2Response.body.limit).toBe(3);
    expect(page2Response.body.items.length).toBe(3);
    
    // Ensure items are different between pages
    const page1Ids = page1Response.body.items.map((item: { id: number }) => item.id);
    const page2Ids = page2Response.body.items.map((item: { id: number }) => item.id);
    expect(page1Ids).not.toEqual(page2Ids);
  });

  it('validates page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test invalid page values
    const invalidPageTests = [
      { page: '0', expectedError: 'page must be a positive integer' },
      { page: '-1', expectedError: 'page must be a positive integer' },
      { page: 'abc', expectedError: 'page must be a positive integer' },
      { page: '1.5', expectedError: 'page must be a positive integer' },
      { page: '1001', expectedError: 'page must be less than or equal to 1000' }
    ];

    for (const test of invalidPageTests) {
      const response = await request(app).get(`/inventory?page=${test.page}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe(test.expectedError);
    }
  });

  it('validates limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test invalid limit values
    const invalidLimitTests = [
      { limit: '0', expectedError: 'limit must be a positive integer' },
      { limit: '-1', expectedError: 'limit must be a positive integer' },
      { limit: 'abc', expectedError: 'limit must be a positive integer' },
      { limit: '1.5', expectedError: 'limit must be a positive integer' },
      { limit: '101', expectedError: 'limit must be less than or equal to 100' }
    ];

    for (const test of invalidLimitTests) {
      const response = await request(app).get(`/inventory?limit=${test.limit}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe(test.expectedError);
    }
  });

  it('handles pagination boundaries correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test with a large limit to get all items
    const allItemsResponse = await request(app).get('/inventory?limit=100');
    const totalItems = allItemsResponse.body.total;
    
    // Test the last page
    const itemsPerPage = 5;
    const lastPageNumber = Math.ceil(totalItems / itemsPerPage);
    const lastPageResponse = await request(app).get(`/inventory?page=${lastPageNumber}&limit=${itemsPerPage}`);
    expect(lastPageResponse.status).toBe(200);
    expect(lastPageResponse.body.hasNext).toBe(false);
    
    // Test a page beyond the last page
    const beyondLastPageResponse = await request(app).get(`/inventory?page=${lastPageNumber + 1}&limit=${itemsPerPage}`);
    expect(beyondLastPageResponse.status).toBe(200);
    expect(beyondLastPageResponse.body.items).toHaveLength(0);
    expect(beyondLastPageResponse.body.hasNext).toBe(false);
  });
});
