/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifySubject,
  addDependent,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    dependents: new Set()
  }

  // Handle equality function
  if (typeof equal === 'function') {
    s.equalFn = equal as EqualFn<T>
  } else if (equal === true && typeof value === 'object' && value !== null) {
    s.equalFn = (lhs, rhs) => {
      if (lhs === rhs) return true
      if (!lhs || !rhs) return false
      return JSON.stringify(lhs) === JSON.stringify(rhs)
    }
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as a dependent of this subject
      addDependent<T>(s, observer as Observer<T>)
    }
    return s.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      // Notify all dependents that this subject has changed
      notifySubject<T>(s)
    }
    return s.value as T
  }

  return [read, write]
}
