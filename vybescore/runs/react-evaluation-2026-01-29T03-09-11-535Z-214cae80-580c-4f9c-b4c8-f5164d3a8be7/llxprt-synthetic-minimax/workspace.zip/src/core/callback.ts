/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      if (disposed) return prevValue as T
      
      try {
        // Execute the callback side effect
        updateFn(prevValue)
        return (prevValue ?? value) as T
      } catch (error) {
        console.warn('Callback execution failed:', error)
        return (prevValue ?? value) as T
      }
    }
  }
  
  // Trigger immediate execution to establish dependency tracking
  // This will register the callback with any reactive values it accesses
  const previousActive = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute once to establish dependencies and run initial callback
    observer.updateFn(value)
  } finally {
    setActiveObserver(previousActive)
  }
  
  const unsubscribe: UnsubscribeFn = () => {
    disposed = true
  }
  
  return unsubscribe
}
