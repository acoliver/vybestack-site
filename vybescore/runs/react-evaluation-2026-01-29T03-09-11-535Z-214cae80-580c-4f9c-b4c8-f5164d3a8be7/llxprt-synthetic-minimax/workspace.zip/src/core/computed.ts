/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const disposed = false
  let currentValue = _value

  const observer: Observer<T> = {
    value: _value,
    disposed,
    updateFn: (prevValue) => {
      if (disposed) return (prevValue ?? currentValue) as T
      
      try {
        // Execute the update function to get new value
        const newValue = updateFn((prevValue ?? currentValue) as T)
        return newValue ?? (prevValue ?? currentValue) as T
      } catch (error) {
        console.warn('Computed value update failed:', error)
        return (prevValue ?? currentValue) as T
      }
    }
  }

  // Initial calculation only if no initial value provided
  if (currentValue === undefined) {
    // Set this observer as active to allow dependency tracking
    const previousActive = getActiveObserver()
    setActiveObserver<T>(observer)
    
    try {
      // Calculate initial value for dependency tracking
      currentValue = updateFn(currentValue as T) as T
    } finally {
      // Restore the previous active observer
      setActiveObserver(previousActive)
    }
  }
  
  const getter: GetterFn<T> = () => {
    if (disposed) return currentValue as T
    
    // Set this observer as active for dependency tracking
    const previousActive = getActiveObserver()
    setActiveObserver<T>(observer)
    
    try {
      // Always recalculate fresh to ensure proper dependency tracking
      currentValue = updateFn(currentValue as T)
      return currentValue as T
    } finally {
      // Restore the previous active observer
      setActiveObserver(previousActive)
    }
  }

  return getter
}
