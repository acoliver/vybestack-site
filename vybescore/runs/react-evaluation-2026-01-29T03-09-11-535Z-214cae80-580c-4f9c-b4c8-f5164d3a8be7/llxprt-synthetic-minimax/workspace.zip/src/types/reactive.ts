/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T = unknown> {
  disposed?: boolean
  value?: T
  updateFn: UpdateFn<T>
  notify?: (observer: Observer) => void
}

export interface Subject<T = unknown> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  dependents: Set<Observer<T>>
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer as Observer<unknown> | undefined
}

export function updateObserver<T>(observer: Observer<T>): T {
  if (observer.disposed) {
    return observer.value!
  }
  
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    return newValue
  } finally {
    activeObserver = previous
  }
}

export function notifySubject<T>(subject: Subject<T>): void {
  if (!subject.dependents || subject.dependents.size === 0) return
  
  const dependents = Array.from(subject.dependents)
  for (const dependent of dependents) {
    try {
      if (!dependent.disposed) {
        updateObserver<T>(dependent)
      }
    } catch (error) {
      console.warn('Observer notification failed:', error)
    }
  }
}

export function addDependent<T>(subject: Subject<T>, observer: Observer<T>): void {
  subject.dependents.add(observer)
}

export function removeDependent<T>(subject: Subject<T>, observer: Observer<T>): void {
  subject.dependents.delete(observer)
}
