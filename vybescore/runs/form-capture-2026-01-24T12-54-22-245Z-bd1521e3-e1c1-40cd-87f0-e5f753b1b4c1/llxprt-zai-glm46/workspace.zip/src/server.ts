import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;

async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  let database: Database;

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    saveDatabase(database);
  }

  return database;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  const dataDir = path.dirname(DB_PATH);
  
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

function validateFormData(data: Partial<FormData>): string[] {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!/^[A-Za-z0-9\s]+$/.test(data.postalCode.trim())) {
    errors.push('Postal code must contain only letters, digits, and spaces');
  }

  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push('Email must be valid');
    }
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else {
    const phoneRegex = /^@?[0-9\s()\\-]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading @');
    }
  }

  return errors;
}

function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

async function startServer(): Promise<express.Express> {
  if (!db) {
    db = await initDatabase();
  }

  const app = express();

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  app.use('/public', express.static(path.join(__dirname, '../public')));

  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  app.get('/', (req, res) => {
    res.render('form', { errors: [], values: {} });
  });

  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const errors = validateFormData(formData);

    if (errors.length > 0) {
      res.status(400);
      return res.render('form', { errors, values: formData });
    }

    if (!db) {
      const dbErrors = ['Database not available'];
      res.status(500);
      return res.render('form', { errors: dbErrors, values: formData });
    }

    try {
      db.run(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim(),
      ]);

      saveDatabase(db);
    } catch (error) {
      console.error('Database error:', error);
      const dbErrors = ['Failed to save submission'];
      res.status(500);
      return res.render('form', { errors: dbErrors, values: formData });
    }

    const firstNameParam = formData.firstName.trim();
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(firstNameParam)}`);
  });

  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });

  return app;
}

const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

async function main() {
  const app = await startServer();
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  const gracefulShutdown = (signal: string) => {
    console.log(`\n${signal} received, closing server gracefully...`);
    server.close(() => {
      console.log('Server closed');
      closeDatabase();
      console.log('Database closed');
      process.exit(0);
    });

    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      closeDatabase();
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { startServer, closeDatabase };
