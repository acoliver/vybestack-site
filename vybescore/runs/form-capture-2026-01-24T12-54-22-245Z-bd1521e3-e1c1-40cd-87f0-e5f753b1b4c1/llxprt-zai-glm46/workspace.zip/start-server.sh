#!/bin/bash
cd /home/runner/work/vybestack-site/vybestack-site/evals/outputs/form-capture-2026-01-24T12-54-22-245Z-bd1521e3-e1c1-40cd-87f0-e5f753b1b4c1
PORT=3535 node dist/server.js
