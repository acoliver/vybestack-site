import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, closeDatabase } from '../../src/server.js';

import type { Express } from 'express';

let server: { close: (cb?: () => void) => void };
let app: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await startServer();
  server = app.listen(0); // Use random available port
});

afterAll(() => {
  if (server) {
    server.close();
  }
  closeDatabase();
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields with proper labels and associations
    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('#firstName').attr('name')).toBe('firstName');
    
    expect($('label[for="lastName"]').text()).toBe('Last name');
    expect($('#lastName').attr('name')).toBe('lastName');
    
    expect($('label[for="streetAddress"]').text()).toBe('Street address');
    expect($('#streetAddress').attr('name')).toBe('streetAddress');
    
    expect($('label[for="city"]').text()).toBe('City');
    expect($('#city').attr('name')).toBe('city');
    
    expect($('label[for="stateProvince"]').text()).toBe('State / Province / Region');
    expect($('#stateProvince').attr('name')).toBe('stateProvince');
    
    expect($('label[for="postalCode"]').text()).toBe('Postal / Zip code');
    expect($('#postalCode').attr('name')).toBe('postalCode');
    
    expect($('label[for="country"]').text()).toBe('Country');
    expect($('#country').attr('name')).toBe('country');
    
    expect($('label[for="email"]').text()).toBe('Email');
    expect($('#email').attr('name')).toBe('email');
    
    expect($('label[for="phone"]').text()).toBe('Phone number');
    expect($('#phone').attr('name')).toBe('phone');
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check for external stylesheet
    expect($('link[rel="stylesheet"]').attr('href')).toBe('/public/styles.css');
  });

  it('persists submission and redirects to thank-you page', async () => {
    // Remove existing database if present
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: ' @1 555-123-4567',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/^\/thank-you(\?firstName=.+)?$/);
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid data', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: 'invalid-email',
        phone: 'invalid-phone!@#',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email must be valid');
    expect(response.text).toContain('Phone number must contain only');
  });

  it('accepts international phone and postal formats', async () => {
    const formData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Calle Mayor 123',
      city: 'Madrid',
      stateProvince: 'Madrid',
      postalCode: '28013',
      country: 'Spain',
      email: 'maria.garcia@example.com',
      phone: ' @34 911 123 456',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/^\/thank-you(\?firstName=.+)?$/);
  });

  it('renders thank-you page with humorous copy', async () => {
    const response = await request(app).get('/thank-you?firstName=John');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you, John!');
    expect(response.text).toContain('stranger on the internet');
    expect(response.text).toContain('/public/styles.css');
    expect(response.text).toContain('Return to the form');
  });

  it('accepts UK postal codes', async () => {
    const formData = {
      firstName: 'James',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'james.smith@example.com',
      phone: ' @44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
  });

  it('accepts Argentine postal codes', async () => {
    const formData = {
      firstName: 'Carlos',
      lastName: 'López',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos.lopez@example.com',
      phone: ' @54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: '',
        streetAddress: '456 Oak Ave',
        city: 'Seattle',
        stateProvince: 'WA',
        postalCode: '98101',
        country: 'USA',
        email: 'jane@example.com',
        phone: ' @1 234-567-8900',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Jane');
    expect(response.text).toContain('456 Oak Ave');
    expect(response.text).toContain('Last name is required');
  });
});
