// Shared TypeScript interfaces for the report builder CLI

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CLIOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

export interface Formatter {
  format(data: ReportData, options: CLIOptions): string;
}