#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  options: CLIOptions;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: CLIOptions['format'] | undefined;
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1] as CLIOptions['format'];
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = args[i + 1];
      i++; // Skip next argument as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return {
    dataFile,
    options: { format, output, includeTotals }
  };
}

function loadAndValidateData(dataFile: string): ReportData {
  try {
    const content = readFileSync(dataFile, 'utf-8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }

    // Validate entries
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid data: entry label must be a string');
      }
      if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
        throw new Error('Invalid data: entry amount must be a number');
      }
    }

    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        console.error(`Error: Cannot read file '${dataFile}': No such file or directory`);
      } else if (error.message.startsWith('Unexpected token')) {
        console.error(`Error: Invalid JSON in '${dataFile}'`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load data file');
    }
    process.exit(1);
  }
}

function render(data: ReportData, options: CLIOptions): string {
  if (options.format === 'markdown') {
    return renderMarkdown.format(data, options);
  } else if (options.format === 'text') {
    return renderText.format(data, options);
  } else {
    throw new Error(`Unsupported format: ${options.format}`);
  }
}

function main(): void {
  const { dataFile, options } = parseArgs(process.argv);
  const data = loadAndValidateData(dataFile);
  const output = render(data, options);

  if (options.output) {
    try {
      writeFileSync(options.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${options.output}'`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
