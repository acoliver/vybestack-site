import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import initSqlJs, { Database } from "sql.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, "../data/submissions.sqlite");
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, "../public")));
    this.app.set("view engine", "ejs");
    this.app.set("views", path.join(__dirname, "../src/templates"));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file) => `node_modules/sql.js/dist/${file}`,
      });

      let dbBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(fileBuffer);
      }

      this.db = new SQL.Database(dbBuffer);

      // Create schema if needed
      const schema = fs.readFileSync(
        path.join(__dirname, "../db/schema.sql"),
        "utf8"
      );
      this.db.run(schema);
    } catch (error) {
      console.error("Failed to initialize database:", error);
      process.exit(1);
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error("Failed to save database:", error);
    }
  }

  private validateForm(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    const requiredFields: (keyof FormData)[] = [
      "first_name",
      "last_name",
      "street_address",
      "city",
      "state_province",
      "postal_code",
      "country",
      "email",
      "phone",
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field]!.trim() === "") {
        errors.push({
          field,
          message: `${field.replace("_", " ")} is required`,
        });
      }
    }

    // Email validation
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({
          field: "email",
          message: "Please enter a valid email address",
        });
      }
    }

    // Phone validation
    if (data.phone) {
      const phoneRegex = /^\+?[0-9\s\-(]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({
          field: "phone",
          message: "Phone number can only contain digits, spaces, parentheses, dashes, and a leading +",
        });
      }
    }

    // Postal code validation
    if (data.postal_code) {
      const postalRegex = /^[a-zA-Z0-9\s-]+$/;
      if (!postalRegex.test(data.postal_code)) {
        errors.push({
          field: "postal_code",
          message: "Postal code can only contain letters, digits, spaces, and dashes",
        });
      }
    }

    return errors;
  }

  private insertSubmission(data: FormData): void {
    if (!this.db) return;

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        data.first_name,
        data.last_name,
        data.street_address,
        data.city,
        data.state_province,
        data.postal_code,
        data.country,
        data.email,
        data.phone,
      ]);
    } finally {
      stmt.free();
    }
  }

  private setupRoutes(): void {
    this.app.get("/", (req, res) => {
      res.render("form", {
        errors: [],
        formData: {},
      });
    });

    this.app.post("/submit", (req, res) => {
      const formData = req.body as Partial<FormData>;
      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        return res.status(400).render("form", {
          errors,
          formData,
        });
      }

      // Cast to FormData since validation passed
      this.insertSubmission(formData as FormData);
      this.saveDatabase();

      res.redirect(302, "/thank-you");
    });

    this.app.get("/thank-you", (req, res) => {
      res.render("thank-you", {});
    });

    // 404 handler
    this.app.use((req, res) => {
      res.status(404).render("form", {
        errors: [{ field: "general", message: "Page not found" }],
        formData: {},
      });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    this.setupRoutes();

    const port = process.env.PORT || 3535;
    const server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const shutdown = () => {
      console.log("Shutting down gracefully...");
      server.close(() => {
        if (this.db) {
          this.db.close();
        }
        process.exit(0);
      });
    };

    process.on("SIGTERM", shutdown);
    process.on("SIGINT", shutdown);
  }
}

// Start the application
const app = new FormCaptureApp();
app.start().catch((error) => {
  console.error("Failed to start application:", error);
  process.exit(1);
});