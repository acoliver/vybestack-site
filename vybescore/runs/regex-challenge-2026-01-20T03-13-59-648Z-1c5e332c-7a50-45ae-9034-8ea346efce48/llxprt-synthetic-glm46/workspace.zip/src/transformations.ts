/**
 * Capitalize the first character of each sentence after .?!
 * - Inserts exactly one space between sentences if input omitted it
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, normalize spacing: replace multiple spaces with single space,
  // but keep intentional spaces after sentence delimiters
  let result = text;
  
  // Step 1: Ensure proper spacing after sentence delimiters (.?!)
  // Pattern: punctuation followed by non-space and not a newline
  const punctuationSpaceRegex = /([.!?])([^ \n])/g;
  result = result.replace(punctuationSpaceRegex, '$1 $2');
  
  // Step 2: Collapse multiple spaces into single space
  const multipleSpacesRegex = / +/g;
  result = result.replace(multipleSpacesRegex, ' ');
  
  // Step 3: Ensure there's exactly one space after punctuation if followed by text
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Step 4: Remove space before punctuation
  result = result.replace(/\s+([.!?])/g, '$1');
  
  // Step 3: Capitalize the first character of each sentence
  // Find indexes of all sentence delimiters (.?!)
  const startPositions = [-1]; // Start before the beginning
  const regex = /[.!?]/g;
  let match;
  
  while ((match = regex.exec(result)) !== null) {
    startPositions.push(match.index);
  }
  
  // Add the end position
  startPositions.push(result.length);
  
  // Process each sentence
  for (let i = 0; i < startPositions.length - 1; i++) {
    const startPos = startPositions[i] + 1; // After the delimiter
    const endPos = startPositions[i + 1];
    
    // Skip empty sequences
    if (startPos >= result.length) break;
    if (startPos >= endPos) continue;
    
    // Find first non-whitespace character in this segment
    let capitalPos = startPos;
    while (capitalPos < endPos && result[capitalPos] === ' ') {
      capitalPos++;
    }
    
    // Skip if we're at the end or the segment is empty
    if (capitalPos >= endPos || capitalPos >= result.length) continue;
    
    // Capitalize the first character
    const char = result[capitalPos];
    if (char && char !== char.toUpperCase()) {
      result = result.substring(0, capitalPos) + char.toUpperCase() + result.substring(capitalPos + 1);
    }
  }
  
  // Handle leading/trailing whitespace
  return result.trim();
}

/**
 * Find URLs in the text and return an array of matched URL strings.
 * Removes trailing punctuation (.,?!;:) from URLs.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL pattern: starts with http:// or https://
  // Includes domain name, optional port, path, query string, fragment
  const urlRegex = /(https?:\/\/[^\s<]+)/gi;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,?!;:)]+$/g, ''));
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace all http:// with https:// using regex
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * 
 * Rules:
 * - Always upgrade the scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, or legacy extensions)
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match https://example.com/... URLs
  const urlRegex = /(https:\/\/example\.com\/[^\s]+)/gi;
  
  // List of patterns that should prevent host rewrite
  const skipHostRewritePatterns = [
    /\/cgi-bin\//i,
    /[?&=]/,  // Query parameters
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[\s]|$)/i  // Legacy extensions
  ];
  
  result = result.replace(urlRegex, (match) => {
    // Check if we should skip host rewrite
    const shouldSkipRewrite = skipHostRewritePatterns.some(pattern => pattern.test(match));
    
    if (shouldSkipRewrite) {
      return match; // Already upgraded to https://, just return as is
    }
    
    // Check if path begins with /docs/
    if (/https:\/\/example\.com\/docs\//i.test(match)) {
      return match.replace(/https:\/\/example\.com\/docs\//i, 'https://docs.example.com/docs/');
    }
    
    return match; // Already upgraded to https://, just return as is
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format where mm, dd are two digits and yyyy is four digits
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combinations
  const maxDays = {
    1: 31, // January
    2: isLeapYear(parseInt(year, 10)) ? 29 : 28, // February
    3: 31, // March
    4: 30, // April
    5: 31, // May
    6: 30, // June
    7: 31, // July
    8: 31, // August
    9: 30, // September
    10: 31, // October
    11: 30, // November
    12: 31 // December
  };
  
  if (day > maxDays[month as keyof typeof maxDays]) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to check if a year is a leap year
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
