export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with reasonable RFC compliance.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that covers typical valid cases while rejecting obvious invalid ones
  // Supports Unicode characters in local and domain parts
  const emailRegex = /^[\p{L}\p{N}!#$%&'*+/=?^_`{|}~-]+@[\p{L}\p{N}-]+(?:\.[\p{L}\p{N}-]+)*\.[\p{L}]{2,}$/u;
  
  // Reject domains with underscores
  if (value.includes('_@')) return false;
  
  // Reject double dots anywhere in the email
  if (value.includes('..')) return false;
  
  // Reject emails starting or ending with dots
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Reject emails with dots immediately before or after @
  if (value.includes('.@') || value.includes('@.')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Strip all non-digit characters except +
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Check if it has optional +1 prefix
  const hasPrefix = digitsOnly.startsWith('+1');
  const phoneNumber = hasPrefix ? digitsOnly.substring(2) : digitsOnly;
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code and validate it doesn't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check if the overall format matches one of the accepted patterns
  const phonePatterns = [
    /^\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/, // (212) 555-7890, (212)5557890
    /^\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // 212-555-7890, 212 555 7890
    /^\d{10}$/, // 2125557890
    /^\+1[\s-]*\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/, // +1 (212) 555-7890
    /^\+1[\s-]*\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // +1 212-555-7890
    /^\+1\d{10}$/ // +12125557890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers with these formats:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (when no country code)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Separators: single spaces or hyphens (ignored in validation)
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Normalize: remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check for +54 country code
  const hasCountryCode = normalized.startsWith('+54');
  
  // If there's no country code, must start with trunk prefix 0 otherwise it's invalid
  if (!hasCountryCode && !normalized.startsWith('0')) {
    return false;
  }
  
  // Extract digits after country code or trunk prefix
  const afterPrefix = hasCountryCode ? normalized.substring(3) : normalized.substring(1);
  
  // Try all possible area code lengths (2-4 digits)
  for (let areaCodeLen = 2; areaCodeLen <= 4; areaCodeLen++) {
    if (afterPrefix.length < areaCodeLen + 6) continue; // Not enough digits for this area code length
    
    const testAreaCode = afterPrefix.substring(0, areaCodeLen);
    const testSubscriber = afterPrefix.substring(areaCodeLen);
    
    // Area code must not start with 0
    if (testAreaCode.startsWith('0')) continue;
    
    // Only consider subscriber numbers with valid length (6-8 digits)
    if (testSubscriber.length < 6 || testSubscriber.length > 8) continue;
    
    // If we consumed all digits and found a valid combination, this is valid
    if (testSubscriber.length === afterPrefix.length - areaCodeLen) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validate personal names with unicode support.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace from both ends
  const trimmed = value.trim();
  
  // Check if name is empty after trimming
  if (!trimmed) return false;
  
  // Regex to match valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens (but not at start/end or consecutive)
  // - Spaces (but not consecutive or at start/end)
  // - At least 2 characters
  const nameRegex = /^[\p{L}]+(?:[-'\s][\p{L}]+)*$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Check for consecutive spaces, hyphens, or apostrophes
  if (trimmed.includes('  ') || trimmed.includes('--') || trimmed.includes("''")) return false;
  
  // Check for name starting or ending with hyphen or apostrophe
  if (trimmed.startsWith('-') || trimmed.startsWith("'")) return false;
  if (trimmed.endsWith('-') || trimmed.endsWith("'")) return false;
  
  // Check for digits
  if (/\d/.test(trimmed)) return false;
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx.
 * Checks prefix and length, then runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens commonly found in credit card numbers
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Credit card patterns:
  // - Visa: 13 or 16 digits, starting with 4
  // - Mastercard: 16 digits, starting with 2221-2720 or 51-55
  // - AmEx: 15 digits, starting with 34 or 37
  const visaPattern = /^4\d{12}(\d{3})?$/;
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]|[3-6]\d|[7][01])\d{12}$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if the number matches any of the supported card patterns
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        doubledDigit -= 9;
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
