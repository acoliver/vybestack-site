/**
 * Find words beginning with the given prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Create regex pattern to match words with the given prefix
  // \b ensures we're matching whole words, \w* matches remaining characters
  const prefixRegex = new RegExp(`\\b${prefix}[\\w-]*`, 'gi');
  
  // Find all matches in the text
  const matches = text.match(prefixRegex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowercasedExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out the exceptions, case-insensitively
  const results = matches
    .map(match => match.toLowerCase())
    .filter(match => !lowercasedExceptions.includes(match))
    // Remove duplicates while preserving order
    .filter((value, index, arr) => arr.indexOf(value) === index);
  
  return results;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookahead/lookbehind to identify valid positions.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  try {
    // Fallback approach: split text into words and find matches
  const words = text.split(/\s+/);
  const matches = [];
  
  for (const word of words) {
    // Pattern to match word starting with one or more digits followed by token
    const pattern = new RegExp(`^\\d+${escapedToken}$`);
    if (pattern.test(word)) {
      matches.push(word);
    }
  }
  
  return matches;
  } catch (e) {
    // Continue to fallback implementation
  }
  
  // Fallback for environments that don't support lookbehind
  // Simple approach: use string manipulation to find patterns
  const matches = [];
  
  // Look for occurrences of the token that are preceded by a digit
  const tokenPattern = new RegExp(`\\d+${escapedToken}`, 'g');
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    const matchedText = match[0];
    // Make sure this isn't at the start of the string
    if (match.index > 0) {
      matches.push(matchedText);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric, non-whitespace)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/\d/.test(value)) return false;
  
  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab"
  // Pattern to detect repeated 2-character sequences
  const repeatedSequenceRegex = /(.{2})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // Additional check for repeated 3-character sequences like "abcabc"
  const repeatedThreeCharsRegex = /(.{3})\1/;
  if (repeatedThreeCharsRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv4 regex pattern for exclusion
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // IPv6 regex patterns
  // Standard notation (8 groups of 4 hex digits)
  const ipv6FullRegex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand notation with :: for zeros
  const ipv6ShorthandRegex = /\b(?:[0-9a-fA-F]{1,4}:){0,6}::{1,2}(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/;
  
  // IPv4-mapped IPv6 addresses
  const ipv4MappedRegex = /\b(?:[0-9a-fA-F]{1,4}:){5}:(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // Check for IPv4 first and exclude those
  if (ipv4Regex.test(value)) {
    // Need to check if this is actually an IPv4-mapped IPv6 address
    if (!ipv4MappedRegex.test(value)) {
      return false;
    }
  }
  
  // Check for IPv6 patterns
  return [
    ipv6FullRegex,
    ipv6ShorthandRegex,
    ipv4MappedRegex
  ].some(regex => regex.test(value));
}
