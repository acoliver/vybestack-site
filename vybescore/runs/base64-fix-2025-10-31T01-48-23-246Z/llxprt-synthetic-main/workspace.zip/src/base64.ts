/**
 * Standard RFC 4648 Base64 alphabet
 */
const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/**
 * Encode a string to standard RFC 4648 Base64 with proper padding
 */
export function encode(input: string): string {
  // Convert string to bytes using UTF-8 encoding
  const bytes = Buffer.from(input, 'utf8');
  
  // Use Buffer's base64 encoding which produces RFC 4648 compliant Base64
  return bytes.toString('base64');
}

/**
 * Validate Base64 input according to RFC 4648 specification
 */
function isValidBase64(input: string): boolean {
  // Empty string is considered valid
  if (input === '') return true;
  
  // Remove padding for validation
  const withoutPadding = input.replace(/=+$/, '');
  
  // Check that all characters are valid Base64 characters
  for (const char of withoutPadding) {
    if (!BASE64_ALPHABET.includes(char)) return false;
  }
  
  // Check padding rules
  const paddingCount = input.length - withoutPadding.length;
  if (paddingCount > 0) {
    // Padding can only appear at the end and must be 1 or 2 '=' characters
    if (paddingCount > 2) return false;
    
    // The non-padded part must be a multiple of 4 characters
    if ((withoutPadding.length + paddingCount) % 4 !== 0) return false;
  } else {
    // Without padding, length must be a multiple of 4
    if (input.length % 4 !== 0) return false;
  }
  
  return true;
}

/**
 * Decode RFC 4648 Base64 string back to UTF-8 text
 * Throws error for invalid Base64 input
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
