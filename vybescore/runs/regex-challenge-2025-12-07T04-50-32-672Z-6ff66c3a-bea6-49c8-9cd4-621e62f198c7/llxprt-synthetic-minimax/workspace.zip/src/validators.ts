export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  if (value.includes('..') || value.includes('@.') || value.includes('.@') || value.includes('._') || value.includes('_.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.trim();
  
  // Check for optional +1 prefix
  let digits = cleanValue.replace(/[^\d]/g, '');
  
  // If starts with +1, remove it for validation
  if (cleanValue.startsWith('+1')) {
    digits = digits.replace(/^1/, '');
  }
  
  // Must have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the format matches one of the expected patterns
  const phoneRegex = /^(?:\+1[\s.-]?)?\(?([2-9][0-9]{2})\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  return phoneRegex.test(cleanValue);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other formatting for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional +54, optional 9 (mobile), optional 0 (trunk), area code (2-4 digits, first 1-9), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, areaCode, subscriberNumber] = match;
  
  // When country code is omitted, must have trunk prefix 0
  if (!countryCode && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and unusual patterns
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if contains any digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject unusual patterns like "X Æ A-12"
  if (value.includes('Æ') || /[A-Z]{2,}\s[A-Z]+/.test(value)) {
    return false;
  }
  
  return true;
}

// Helper function for Luhn algorithm
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid card prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // MasterCard: starts with 51-55, or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const firstDigit = digitsOnly[0];
  const firstTwoDigits = parseInt(digitsOnly.substring(0, 2));
  const firstFourDigits = parseInt(digitsOnly.substring(0, 4));
  
  let isValidPrefix = false;
  
  // Visa
  if (firstDigit === '4' && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19)) {
    isValidPrefix = true;
  }
  // MasterCard
  else if ((firstTwoDigits >= 51 && firstTwoDigits <= 55) || 
           (firstFourDigits >= 2221 && firstFourDigits <= 2720)) {
    if (digitsOnly.length === 16) {
      isValidPrefix = true;
    }
  }
  // American Express
  else if ((firstTwoDigits === 34 || firstTwoDigits === 37) && digitsOnly.length === 15) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
