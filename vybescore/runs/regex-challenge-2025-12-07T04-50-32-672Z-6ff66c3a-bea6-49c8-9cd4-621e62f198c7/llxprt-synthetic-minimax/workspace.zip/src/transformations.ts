/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, capitalize the first letter of the entire text
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Find sentence boundaries (.?!), capitalize following letter, ensure single space
  result = result.replace(/([.!?])\s*([a-z])/g, (match, punct, nextChar) => {
    return punct + ' ' + nextChar.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Find URLs in the text
  const urlRegex = /(?:https?:\/\/|www\.)[^\s!,!?)]*/gi;
  const urls = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  const cleanUrls = urls.map(url => {
    // Remove trailing punctuation that shouldn't be part of the URL
    return url.replace(/[.,!?]+$/g, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Find http:// URLs and process them
  return text.replace(/http:\/\/([^/]+)(\/[^\s]*)/gi, (match, host, path) => {
    // Always upgrade to https
    let result = 'https://';
    
    // Check if path begins with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !/[?&].*\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(path)) {
      // Rewrite host to docs.example.com
      const newHost = `docs.${host}`;
      result += newHost;
    } else {
      // Keep original host
      result += host;
    }
    
    result += path;
    return result;
  });
}

export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month);
  const dayNum = parseInt(day);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  // Validate year (between 1900 and 2100, basic check)
  const yearNum = parseInt(year);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}
