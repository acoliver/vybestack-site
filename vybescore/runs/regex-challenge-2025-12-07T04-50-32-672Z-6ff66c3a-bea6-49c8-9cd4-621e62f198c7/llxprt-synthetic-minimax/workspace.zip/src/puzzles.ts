/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  const regex = new RegExp(`\\b${prefix}\\w*`, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token after a digit and not at the start of string
  // Look for digit followed by the token
  const regex = new RegExp(`\\d${token}`, 'g');
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase, one lowercase, one digit, one symbol
  if (!/[A-Z]/.test(value) || !/[a-z]/.test(value) || !/\d/.test(value) || !/[^\w\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., "abab", "abcabc", etc.)
  // Check for any pattern that repeats immediately
  const pattern = /(..+)\1/;
  if (pattern.test(value)) {
    return false;
  }
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // IPv6 regex that includes shorthand :: notation
  // IPv6 has 8 groups of hex digits (0-9, a-f, A-F), separated by colons
  // Can use :: as shorthand for consecutive zero groups
  // Must exclude IPv4 patterns (4 groups of decimal digits)
  const ipv6Regex = /\b(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:((?::[0-9a-fA-F]{1,4}){1,7}|:))(?![.\d])/i;
  
  return ipv6Regex.test(value);
}
