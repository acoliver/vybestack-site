export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@example.co.uk.
 * Rejects double dots, trailing dots, underscores in domains, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) return false;
  
  // Check for invalid patterns
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@.')) return false;
  if (value.includes('.@')) return false;
  
  const [, domain] = value.split('@');
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Optional +1 prefix allowed.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must be at least 10 digits
  const digitsOnly = cleaned.replace(/\+/g, '');
  if (digitsOnly.length < 10) return false;
  
  // Check for optional +1 prefix
  let coreNumber = digitsOnly;
  if (coreNumber.startsWith('1') && coreNumber.length > 10) {
    coreNumber = coreNumber.substring(1);
  }
  
  // Must be exactly 10 digits for US number
  if (coreNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = coreNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code must be 2-4 digits (leading digit 1-9).
 * Subscriber number must contain 6-8 digits.
 * When country code is omitted, number must begin with trunk prefix 0.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces and hyphens)
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match pattern: optional +54, optional 0, optional 9, area code (2-4 digits starting with 1-9), subscriber (6-8 digits)
  // When +54 is present: +54911... or +54011... or +5411...
  // When +54 is absent: must start with 0
  const withCountryCode = /^\+54(\d)?[9]?(\d{2,4})\d{6,8}$/.test(cleaned);
  const withoutCountryCode = /^0[9]?(\d{2,4})\d{6,8}$/.test(cleaned);
  
  if (!withCountryCode && !withoutCountryCode) return false;
  
  // Extract the area code and subscriber number for validation
  let digits = cleaned.replace(/\+/g, '');
  
  if (digits.startsWith('54')) {
    digits = digits.substring(2);
  }
  
  // Check for trunk prefix
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Check for mobile indicator
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Now we have area code + subscriber
  // Area code is 2-4 digits, subscriber is 6-8 digits
  if (digits.length < 8 || digits.length > 12) return false;
  
  // Extract area code (must start with 1-9)
  const areaCode = digits.substring(0, Math.min(4, digits.length - 6));
  
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject if contains digits
  if (/\d/.test(value)) return false;
  
  // Reject specific invalid names like X Æ A-12 (contains digit)
  // This is already covered by the digit check above
  
  return true;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * Accepts valid prefixes and lengths, performs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length and prefix for different card types
  const length = cleaned.length;
  
  // Visa: 13, 16 or 19 digits, starts with 4
  const isVisa = (length === 13 || length === 16 || length === 19) && cleaned.startsWith('4');
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const isMastercard = length === 16 && (
    (/^5[1-5]/.test(cleaned)) ||
    (/^2[2-7][0-9]{2}/.test(cleaned))
  );
  
  // AmEx: 15 digits, starts with 34 or 37
  const isAmEx = length === 15 && (cleaned.startsWith('34') || cleaned.startsWith('37'));
  
  if (!isVisa && !isMastercard && !isAmEx) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  const isEven = cardNumber.length % 2 === 0;
  
  for (let i = 0; i < cardNumber.length; i++) {
    let digit = parseInt(cardNumber[i], 10);
    
    // Double every other digit
    if (i % 2 === (isEven ? 0 : 1)) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}
