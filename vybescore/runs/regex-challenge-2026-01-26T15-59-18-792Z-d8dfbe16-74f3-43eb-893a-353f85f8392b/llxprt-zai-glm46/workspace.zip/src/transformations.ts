/**
 * Capitalize the first character of each sentence.
 * Preserves abbreviations, ensures exactly one space between sentences.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into one
  let result = text.replace(/[  ]+/g, ' ').trim();
  
  // Ensure exactly one space after sentence endings
  result = result.replace(/([.!?])\s*/g, '$1 ');
  
  // Capitalize first letter of each sentence
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result.trim();
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: protocol://domain/path?query
  // Match http/https/ftp/etc URLs
  const urlPattern = /\b(?:https?|ftp):\/\/[^\s<>]+(?:\/[^\s<>]*)?\b/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://...
 * When path begins with /docs/, rewrite host to docs.example.com
 * Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, protocolAndHost, path = '') => {
    // Always upgrade to https
    let newUrl = 'https://example.com';
    
    if (path) {
      // Check if path starts with /docs/
      const startsWithDocs = /^\/docs\//i.test(path);
      
      // Check for dynamic hints that should prevent host rewrite
      const hasDynamicHints = /[?&=]|\/cgi-bin\/|\/(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i.test(path);
      
      if (startsWithDocs && !hasDynamicHints) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      } else {
        // Just upgrade scheme, keep example.com host
        newUrl = 'https://example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
