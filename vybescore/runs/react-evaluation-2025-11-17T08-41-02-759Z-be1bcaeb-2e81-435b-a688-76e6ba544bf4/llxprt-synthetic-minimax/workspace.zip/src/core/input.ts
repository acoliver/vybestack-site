/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : (equal === false ? undefined : undefined),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Use equal function if provided, otherwise use reference equality
    const shouldUpdate = s.equalFn 
      ? !s.equalFn(s.value, nextValue)
      : s.value !== nextValue
    
    if (shouldUpdate) {
      s.value = nextValue
      if (s.observer) updateObserver(s.observer as Observer<unknown>)
    }
    return s.value
  }

  return [read, write]
}
