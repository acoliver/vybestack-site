/**
 * Capitalizes the first character of each sentence after .!? punctuation.
 * Inserts exactly one space between sentences and collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing - collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Add space after sentence endings if missing (but not after abbreviations)
  result = result.replace(/([.!?])(?=[A-Za-z])(?!(?: [a-z]{1,3}\.?|\s*(?:'t|'s|'re|'ve|'ll|'d|'m)))/g, '$1 ');
  
  // Capitalize first letter of sentences
  result = result.replace(/(^[a-z])|([.!?]\s+[a-z])/g, match => match.toUpperCase());
  
  // Handle start of text
  result = result.replace(/^[a-z]/, char => char.toUpperCase());
  
  // Clean up extra spaces around punctuation
  result = result.replace(/\s+([.!?])/g, '$1');
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  // Trim leading/trailing spaces
  result = result.trim();
  
  return result;
}

/**
 * Finds and extracts URLs from the given text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern
  // Matches http/https protocols, www domains, and common domain patterns
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"'(){}[\]]+(?=[\s<>"'(){}[\]]|$)/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,;:!?)]} but keep valid URL characters
    return url.replace(/[.,;:!?)\]]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// protocols with https:// in the given text.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // First upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match https://example.com URLs with potential docs paths
  const urlPattern = /(https:\/\/example\.com)(\/[^\s?]*)(\?[^\s]*)?/g;
  
  result = result.replace(urlPattern, (match, protocolHost, path, query) => {
    // Check if this should be rewritten to docs.example.com
    // Rewrite only if:
    // 1. Path starts with /docs/
    // 2. Path doesn't contain dynamic hints (cgi-bin, query strings, legacy extensions)
    
    // Check for dynamic hints in the path and query that should prevent host rewrite
    // These include: cgi-bin, query strings (?&=), and legacy extensions
    const hasQueryChars = /[?&=]/.test(query);
    const hasLegacyExtensions = /(?:cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasQueryChars && !hasLegacyExtensions) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}${query || ''}`;
    }
    
    // Keep original host but ensure https
    return match;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy date strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  const maxDays = month === 2 ? (isLeapYear ? 29 : 28) : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  // Return the year as a string
  return yearStr;
}
