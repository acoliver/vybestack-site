/**
 * Finds words starting with the given prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex pattern to match words starting with prefix
  // \b ensures we match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and unique results
  const filteredMatches = matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptions.includes(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // unique
  
  return filteredMatches;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to find the token in the right context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Since negative lookbehind with start anchor isn't well supported, 
  // let's implement this with a different approach
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all tokens that follow a digit
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Make sure this isn't at the very beginning of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^\w]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Look for patterns like abab, 1212, !@!@ where a sequence of 2+ characters repeats immediately
  const repeatedSequencePattern = /(..+?)\1+/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Returns true if the text contains a valid IPv6 address, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 address patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressed zeros)
  const compressedIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}?\b/;
  
  // IPv6 with leading/trailing ::
  const edgeCompressedPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}?\b|[0-9a-fA-F]{1,4}(?:::[0-9a-fA-F]{1,4}){0,7}::\b/;
  
  // IPv4-mapped IPv6: ::ffff:192.168.1.1
  const ipv4MappedPattern = /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 with embedded IPv4
  const embeddedIPv4Pattern = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Make sure we don't match pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:\d{1,3}\.){3}\d{1,3})$/;
  
  // If the entire string is just an IPv4 address, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Test for IPv6 patterns
  if (fullIPv6Pattern.test(value) || 
      compressedIPv6Pattern.test(value) || 
      edgeCompressedPattern.test(value) || 
      ipv4MappedPattern.test(value) || 
      embeddedIPv4Pattern.test(value)) {
    return true;
  }
  
  return false;
}
