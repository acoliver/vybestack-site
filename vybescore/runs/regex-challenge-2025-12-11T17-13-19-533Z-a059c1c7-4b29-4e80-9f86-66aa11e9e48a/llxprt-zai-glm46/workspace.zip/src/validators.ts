export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with robust rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Must match basic structure first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Split local and domain parts
  const [localPart, domainPart] = value.split('@');
  
  // Local part validation
  // Cannot start or end with dot, cannot have consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // Domain part validation  
  // Cannot start or end with dot or hyphen
  if (domainPart.startsWith('.') || domainPart.endsWith('.') || 
      domainPart.startsWith('-') || domainPart.endsWith('-')) {
    return false;
  }
  
  // Cannot have consecutive dots
  if (domainPart.includes('..')) {
    return false;
  }
  
  // No underscores in domain (not allowed in hostnames)
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Must have at least one dot in domain
  if (!domainPart.includes('.')) {
    return false;
  }
  
  // Top-level domain validation
  const tld = domainPart.split('.').pop();
  if (!tld || tld.length < 2 || tld.startsWith('-') || tld.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');
  
  // Minimum 10 digits for US phone number
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1);
  } else if (digits.length > 10) {
    // Too many digits
    return false;
  }
  
  // Must be exactly 10 digits now
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if format matches common US phone patterns
  const usPhoneRegex = /^(?:\+?1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code is omitted, must begin with trunk prefix 0 before area code
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but preserve structure
  const normalized = value.replace(/[ -]/g, '');
  
  // Argentine phone regex
  const argentinePhoneRegex = /^(?:\+?54)?(?:9)?0?[2-9]\d{1,3}\d{6,8}$/;
  
  // Basic format check
  if (!argentinePhoneRegex.test(normalized)) {
    return false;
  }
  
  // Extract components for detailed validation
  let remaining = normalized;
  
  // Remove optional country code
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  }
  
  // Check for mobile indicator (9)
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Check for trunk prefix (0)
  let hasTrunkPrefix = false;
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }
  
  // Extract area code (2-4 digits, cannot start with 0 or 1)
  const areaCodeMatch = remaining.match(/^([2-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = areaCodeMatch;
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix
  if (!normalized.startsWith('+54') && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphenation, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name should contain at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Regex for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes (allowed within names like O'Connor)
  // - Hyphens (for hyphenated names)
  // - Spaces (for multi-part names)
  // - Cannot contain digits or other symbols
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns like consecutive hyphens/apostrophes
  if (value.includes('--') || value.includes("''")) {
    return false;
  }
  
  // Cannot start or end with hyphen, apostrophe, or space
  if (value.startsWith("-") || value.startsWith("'") || value.startsWith(" ") ||
      value.endsWith("-") || value.endsWith("'") || value.endsWith(" ")) {
    return false;
  }
  
  // Reject obvious problematic patterns (like X Æ A-12 which contains digits)
  if (/\d/.test(value)) {
    return false;
  }
  
// Reject names with too many special characters relative to letters
  const letters = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  const specialChars = (value.match(/['-]/g) || []).length;
  
  if (letters === 0 || specialChars > letters / 2) {
    return false;
  }
  
  return true;
}

/**
 * Helper function for Luhn algorithm checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum for basic validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Check card patterns and lengths
  const cardPatterns = [
    // Visa: starts with 4, 13 or 16 digits
    { prefix: /^4\d{12}(\d{3})?$/, length: [13, 16] },
    // Mastercard: starts with 51-55 or 2221-2720, 16 digits
    { prefix: /^5[1-5]\d{14}$/, length: [16] },
    { prefix: /^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/, length: [16] },
    // American Express: starts with 34 or 37, 15 digits
    { prefix: /^3[47]\d{13}$/, length: [15] },
  ];
  
  // Check if card matches any known pattern
  const isMatchingPattern = cardPatterns.some(pattern => 
    pattern.prefix.test(cardNumber)
  );
  
  if (!isMatchingPattern) {
    return false;
  }
  
  // Validate length
  const cardLength = cardNumber.length;
  const validLengths = cardPatterns
    .filter(pattern => pattern.prefix.test(cardNumber))
    .flatMap(pattern => pattern.length);
    
  if (!validLengths.includes(cardLength)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}