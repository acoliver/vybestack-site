/**
 * Encode plain text to Base64 using the standard alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  // Validate that input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Validate proper Base64 padding (length should be multiple of 4, or have proper padding)
  if (input.length % 4 !== 0) {
    const paddingMatches = input.match(/=+$/);
    const paddingLength = paddingMatches ? paddingMatches[0].length : 0;
    if (paddingLength > 2 || (input.length - paddingLength) % 4 === 0) {
      // Pad input to proper length
      const paddedInput = input + '='.repeat((4 - input.length % 4) % 4);
      
      try {
        return Buffer.from(paddedInput, 'base64').toString('utf8');
      } catch (error) {
        throw new Error('Failed to decode Base64 input');
      }
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
