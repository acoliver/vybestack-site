/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
const ERROR_MESSAGE = 'Invalid Base64 input';
const DECODE_ERROR_MESSAGE = 'Failed to decode Base64 input';
const PADDING_REGEX = /=+$/;

export function decode(input: string): string {
  // Basic validation: check for valid Base64 characters
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, and optional padding =
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;

  if (!validBase64Pattern.test(input) || input.length === 0) {
    throw new Error(ERROR_MESSAGE);
  }

  // Check that padding, if present, is only at the end and there are at most 2 chars
  // Also check that padding length is valid (1 or 2 = chars, and they come in groups)
  const paddingMatch = input.match(PADDING_REGEX);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error(ERROR_MESSAGE);
    }
    // Check if there are any = characters not at the end
    if (input.slice(0, -paddingLength).includes('=')) {
      throw new Error(ERROR_MESSAGE);
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // If the buffer is empty but input was not just padding, it's likely invalid
    if (buffer.length === 0 && input.replace(/=+/g, '').length > 0) {
      throw new Error(ERROR_MESSAGE);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(DECODE_ERROR_MESSAGE);
  }
}
