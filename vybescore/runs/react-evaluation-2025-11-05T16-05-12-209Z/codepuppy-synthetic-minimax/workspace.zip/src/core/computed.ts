/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const userUpdateFn = updateFn
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      // Get the old value before recomputing
      const oldValue = observer.value
      
      // Call the user function to compute the new value
      // This will track dependencies because we're called within updateObserver
      observer.value = userUpdateFn(currentValue)
      
      // If value changed and we have an observer, notify it
      const computedWithObserver = observer as ObserverR & { observer?: ObserverR }
      if (oldValue !== observer.value && computedWithObserver.observer) {
        updateObserver(computedWithObserver.observer as Observer<unknown>)
      }
      
      return observer.value
    },
  }

  // Initialize the value
  updateObserver(observer)

  return (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Store the computed as a subject that has the active observer
      (observer as ObserverR & { observer?: ObserverR }).observer = activeObserver
      // Recompute immediately to ensure dependencies are tracked with current observer
      updateObserver(observer)
    }
    return observer.value!
  }
}