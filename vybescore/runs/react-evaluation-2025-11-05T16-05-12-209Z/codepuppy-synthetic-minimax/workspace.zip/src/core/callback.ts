/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Store the user's function
  const userFunction = updateFn
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      // When the callback is triggered, execute the user function
      return userFunction(currentValue)
    },
  }
  
  let disposed = false
  
  // Execute the user function to track dependencies
  updateObserver(observer)
  
  return (): void => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.updateFn = () => value!
  }
}