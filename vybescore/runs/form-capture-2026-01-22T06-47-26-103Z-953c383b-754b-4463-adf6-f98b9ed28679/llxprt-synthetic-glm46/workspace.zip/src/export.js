// This file exports the Express app for testing
export { default } from './server.js';