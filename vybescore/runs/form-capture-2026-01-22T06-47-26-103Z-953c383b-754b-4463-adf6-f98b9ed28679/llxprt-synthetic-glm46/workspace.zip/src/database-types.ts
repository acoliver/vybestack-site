export interface SqlJsDatabase {
  export(): Uint8Array;
  close(): void;
  run(sql: string, ...params: unknown[]): void;
  prepare(query: string): {
    run(...params: unknown[]): void;
    free(): void;
  };
}



export interface SqlJsModule {
  Database: {
    new (data?: ArrayBuffer | Uint8Array): SqlJsDatabase;
  };
}