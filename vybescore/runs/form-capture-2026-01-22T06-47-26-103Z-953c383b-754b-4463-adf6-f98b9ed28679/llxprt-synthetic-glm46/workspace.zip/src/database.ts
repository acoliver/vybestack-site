import fs from 'node:fs';
import path from 'node:path';

/// <reference path="./sql-types.d.ts"/>
import initSqlJs from 'sql.js';
import type { SqlJsDatabase } from './database-types.js';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

export class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private isLoaded = false;

  async initialize(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const SQL = await initSqlJs();
      const DatabaseClass = SQL.Database;

      if (fs.existsSync(DB_PATH)) {
        // Load existing database
        const fileBuffer = fs.readFileSync(DB_PATH);
        this.db = new DatabaseClass(fileBuffer);
      } else {
        // Create new database with schema
        this.db = new DatabaseClass();
        const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
        if (this.db) {
          this.db.run(schema);
          await this.save();
        }
      }

      this.isLoaded = true;
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async save(): Promise<void> {
    if (!this.db) return;

    try {
      const data = this.db.export();
      fs.writeFileSync(DB_PATH, data);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  insertSubmission(formData: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
  }): void {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    this.isLoaded = false;
  }

  get isInitialized(): boolean {
    return this.isLoaded && this.db !== null;
  }
}

export const dbManager = new DatabaseManager();