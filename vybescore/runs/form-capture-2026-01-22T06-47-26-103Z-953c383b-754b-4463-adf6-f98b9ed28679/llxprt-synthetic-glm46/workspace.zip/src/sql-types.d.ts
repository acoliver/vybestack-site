declare module 'sql.js' {
  export default function initSqlJs(): Promise<SqlJs>;
  
  export interface SqlJs {
    Database: {
      new (data?: ArrayBuffer | Uint8Array): Database;
    };
  }
  
  export class Database {
    constructor(data?: ArrayBuffer | Uint8Array);
    export(): Uint8Array;
    close(): void;
    run(sql: string, ...params: unknown[]): void;
    prepare(query: string): Statement;
  }
  
  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }
}