import express, { Express, Request, Response } from 'express';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { dbManager } from './database.js';
import {
  FormData,
  validateForm,
  hasFormErrors,
  getSanitizedFormValues,
  createFormField,
} from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const expressApp: Express = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
expressApp.use(express.urlencoded({ extended: true }));
expressApp.use(express.static('public'));

// Set EJS as the view engine
expressApp.set('view engine', 'ejs');
expressApp.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Helper function to initialize form data
function createEmptyFormData(): FormData {
  return {
    firstName: createFormField(''),
    lastName: createFormField(''),
    streetAddress: createFormField(''),
    city: createFormField(''),
    stateProvince: createFormField(''),
    postalCode: createFormField(''),
    country: createFormField(''),
    email: createFormField(''),
    phone: createFormField(''),
  };
}

// Routes
expressApp.get('/', (req: Request, res: Response) => {
  const formData = createEmptyFormData();
  res.render('form', { formData, hasErrors: false, serverError: null });
});

expressApp.post('/submit', async (req: Request, res: Response) => {
  try {
    // Create form data object from request body
    const formData = validateForm({
      firstName: createFormField(req.body.firstName || ''),
      lastName: createFormField(req.body.lastName || ''),
      streetAddress: createFormField(req.body.streetAddress || ''),
      city: createFormField(req.body.city || ''),
      stateProvince: createFormField(req.body.stateProvince || ''),
      postalCode: createFormField(req.body.postalCode || ''),
      country: createFormField(req.body.country || ''),
      email: createFormField(req.body.email || ''),
      phone: createFormField(req.body.phone || ''),
    });

    // Check if there are validation errors
    if (hasFormErrors(formData)) {
      return res.render('form', { formData, hasErrors: true, serverError: null });
    }

    // Save to database
    await dbManager.initialize();
    const sanitizedValues = getSanitizedFormValues(formData);
    dbManager.insertSubmission({
      firstName: sanitizedValues.firstName,
      lastName: sanitizedValues.lastName,
      streetAddress: sanitizedValues.streetAddress,
      city: sanitizedValues.city,
      stateProvince: sanitizedValues.stateProvince,
      postalCode: sanitizedValues.postalCode,
      country: sanitizedValues.country,
      email: sanitizedValues.email,
      phone: sanitizedValues.phone,
    });
    await dbManager.save();

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    const formData = createEmptyFormData();
    res.render('form', { 
      formData, 
      hasErrors: false, 
      serverError: 'An error occurred while processing your submission. Please try again.' 
    });
  }
});

expressApp.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown handler
function setupGracefulShutdown(server: ReturnType<typeof expressApp.listen>) {
  const gracefulShutdown = async () => {
    console.log('Shutting down gracefully...');
    
    if (server) {
      server.close();
    }
    
    dbManager.close();
    process.exit(0);
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start server
async function startServer() {
  try {
    // Initialize database
    await dbManager.initialize();
    
    const server = expressApp.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    setupGracefulShutdown(server);
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// For testing purposes, export the app without starting the server
export const appPromise = Promise.resolve(expressApp);
export const app = appPromise;

// Only start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default expressApp;
