export interface FormField {
  value: string;
  error?: string;
}

export interface FormData {
  firstName: FormField;
  lastName: FormField;
  streetAddress: FormField;
  city: FormField;
  stateProvince: FormField;
  postalCode: FormField;
  country: FormField;
  email: FormField;
  phone: FormField;
}

export function validateRequired(value: string, fieldName: string): string | undefined {
  if (!value || value.trim().length === 0) {
    return `${fieldName} is required`;
  }
  return undefined;
}

export function validateEmail(value: string): string | undefined {
  const requiredError = validateRequired(value, 'Email');
  if (requiredError) return requiredError;

  // Basic email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) {
    return 'Please enter a valid email address';
  }
  return undefined;
}

export function validatePhone(value: string): string | undefined {
  const requiredError = validateRequired(value, 'Phone');
  if (requiredError) return requiredError;

  // Phone validation: allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+(\d|\s|\(|\)|-)+$/;
  if (!phoneRegex.test(value)) {
    return 'Phone number must start with + and contain only digits, spaces, parentheses, and dashes';
  }
  return undefined;
}

export function validatePostalCode(value: string): string | undefined {
  const requiredError = validateRequired(value, 'Postal code');
  if (requiredError) return requiredError;

  // Postal codes: accept alphanumeric characters, spaces, and dashes
  // Supports formats like SW1A 1AA, C1000, B1675, etc.
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (!postalCodeRegex.test(value)) {
    return 'Postal code must contain only letters, numbers, spaces, and dashes';
  }
  return undefined;
}

export function validateField(field: FormField, validator: (value: string) => string | undefined): FormField {
  const error = validator(field.value);
  return { ...field, error };
}

export function createFormField(value: string): FormField {
  return { value };
}

export function validateForm(formData: FormData): FormData {
  const validated: FormData = {
    firstName: validateField(formData.firstName, (value) => validateRequired(value, 'First name')),
    lastName: validateField(formData.lastName, (value) => validateRequired(value, 'Last name')),
    streetAddress: validateField(formData.streetAddress, (value) => validateRequired(value, 'Street address')),
    city: validateField(formData.city, (value) => validateRequired(value, 'City')),
    stateProvince: validateField(formData.stateProvince, (value) => validateRequired(value, 'State/Province/Region')),
    postalCode: validateField(formData.postalCode, validatePostalCode),
    country: validateField(formData.country, (value) => validateRequired(value, 'Country')),
    email: validateField(formData.email, validateEmail),
    phone: validateField(formData.phone, validatePhone),
  };

  return validated;
}

export function hasFormErrors(formData: FormData): boolean {
  return Object.values(formData).some(field => field.error !== undefined);
}

export function getSanitizedFormValues(formData: FormData): Record<string, string> {
  return {
    firstName: formData.firstName.value,
    lastName: formData.lastName.value,
    streetAddress: formData.streetAddress.value,
    city: formData.city.value,
    stateProvince: formData.stateProvince.value,
    postalCode: formData.postalCode.value,
    country: formData.country.value,
    email: formData.email.value,
    phone: formData.phone.value,
  };
}