/**
 * Helper function to run Luhn checksum validation for credit card numbers
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  // Remove spaces and dashes from the card number
  const cardDigits = digits.split('');
  
  // Double every second digit from the right
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cardDigits.length - 1; i >= 0; i--) {
    let digit = parseInt(cardDigits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
// Basic patterns for email validation
  // Local part: alphanumeric characters and some special characters, optional +tag
  // Domain: no underscores, proper TLD
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\+[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)?@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Must pass basic regex
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for rejected patterns
  // No consecutive dots
  if (value.includes('..')) return false;
  
  // Local part shouldn't start or end with dot
  const [local, domain] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Domain must not start or end with dot
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // No underscore in domain part
  if (domain.includes('_')) return false;
  
  // Domain should not contain consecutive dots
  if (domain.includes('..')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
// Remove common separators and spaces, but keep digits and + for validation
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must contain only digits and possibly an initial + sign
  if (!/^\+?\d+$/.test(cleaned)) return false;
  
  // Check for optional +1 country code
  const hasCountryCode = cleaned.startsWith('+1');
  const digits = hasCountryCode ? cleaned.substring(2) : cleaned;
  
  // Must have exactly 10 digits
  if (!/^\d{10}$/.test(digits)) return false;
  
  // Area code can't start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') return false;
  
  // Reject obviously invalid numbers (too short even after cleaning)
  if (digits.length < 10) return false;
  
  // Additional validation: check for valid exchange codes
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except the initial + for easier validation
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Overall length check should be reasonable (8-15 digits)
  if (cleaned.length < 8 || cleaned.length > 15) return false;
  
  // Must start with +54 (country code) or 0 (trunk prefix)
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) return false;
  
  // Must contain only digits and possibly an initial + sign
  if (!/^\+?\d+$/.test(cleaned)) return false;
  
  // With country code +54
  if (cleaned.startsWith('+54')) {
    const afterCountryCode = cleaned.substring(2);
    
    // Optional mobile indicator 9
    let remaining = afterCountryCode;
    if (afterCountryCode.startsWith('9')) {
      remaining = afterCountryCode.substring(1);
    }
    
    // If country code is specified, there shouldn't be a trunk prefix (0)
    if (remaining.startsWith('0')) return false;
    
    // Extract area code (2-4 digits, cannot start with 0)
    const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
    if (!areaCodeMatch) return false;
    
    const areaCode = areaCodeMatch[1];
    const subscriberNumber = remaining.substring(areaCode.length);
    
    // Area code must be 2-4 digits and cannot start with 0
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
    
    // Subscriber number must be 6-8 digits
    if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
    
    return true;
  }
  
  // With trunk prefix 0 (must be present when country code is omitted)
  if (cleaned.startsWith('0')) {
    const afterTrunkPrefix = cleaned.substring(1);
    
    // Extract area code (2-4 digits, cannot start with 0)
    const areaCodeMatch = afterTrunkPrefix.match(/^([1-9]\d{1,3})/);
    if (!areaCodeMatch) return false;
    
    const areaCode = areaCodeMatch[1];
    const subscriberNumber = afterTrunkPrefix.substring(areaCode.length);
    
    // Area code must be 2-4 digits and cannot start with 0
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
    
    // Subscriber number must be 6-8 digits
    if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
    
    return true;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols like X Æ A-12
const nameRegex = /^[\p{L}'\s\p{M}-]+$/u;
  
  // Must pass basic regex
  if (!nameRegex.test(value)) return false;
  
// Must have at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject names with only punctuation/spaces
  if (!/[\p{L}]/u.test(value.replace(/['-\s]/g, ''))) return false;

  // Reject excessive consecutive punctuation
  if (/'[-]|-{2}/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes from the card number
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digits)) return false;
  
  // Check card length (13-19 digits for major cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check card prefixes and lengths for different card types
  const cardTypes = [
    { prefixes: /^4/, lengths: /^(13|16)$/, name: 'Visa' },  // Visa: starts with 4, length 13 or 16
    { prefixes: /^5[1-5]/, lengths: /^16$/, name: 'Mastercard' },  // Mastercard: starts with 51-55, length 16
    { prefixes: /^3[47]/, lengths: /^15$/, name: 'AmEx' },  // AmEx: starts with 34 or 37, length 15
  ];
  
  // Check if card matches any known type
  const isValidType = cardTypes.some(type => {
    return type.prefixes.test(digits) && type.lengths.test(digits.length.toString());
  });
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
