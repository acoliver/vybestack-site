/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize after sentence terminators (. ! ?), handling abbreviations where possible
  return text.replace(/(^|[.!?]+[\s]*)([a-z])/g, (match: string, prefix: string, letter: string) => {
    // Ensure proper single space after sentence terminators
    const normalizedPrefix = prefix.replace(/[.!?]+[\s]*/, (terminator: string) => 
      terminator.replace(/[.!?]+/g, (t: string) => t + ' ').replace(/\s+/g, ' ')
    );
    return normalizedPrefix + letter.toUpperCase();
  }).replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern matching http/https protocols
  const urlRegex = /https?:\/\/[^\s<>"']+/g;
  
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like .,)!?
  return urls.map(url => url.replace(/[.,?!;:)]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs from example.com
  const urlPattern = /(https?):\/\/(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match: string, protocol: string, domain: string, path: string = '') => {
    // Always upgrade to https
    const secureProtocol = 'https';
    
    // Dynamic hints that prevent host rewrite
    const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    
    // Skip host rewrite if path contains dynamic hints
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      return `${secureProtocol}://docs.${domain}${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return `${secureProtocol}://${domain}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month/day
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Check for leap year
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  
  // Validate day based on month
  const daysInMonth = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) return 'N/A';
  
  return year;
}
