/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix to handle special regex characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words with the given prefix
  // Using \b for word boundary, then the prefix, then word characters
  const prefixRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions and return unique matches
  const filtered = matches.filter(word => !exceptions.includes(word));
  
  // Return unique matches in the order they appear
  return [...new Set(filtered)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token to handle special regex characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit + token (e.g., "1foo")
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenPattern) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab)
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns based on RFC 4291:
  // Full form: eight groups of four hex digits (e.g., 2001:0db8:85a3:0000:0000:8a2e:0370:7334)
  // Shortened form: allowing :: for consecutive groups of zeros (e.g., 2001:db8::1)
  // Compressed form: reduced number of groups
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  return ipv6Pattern.test(value);
}
