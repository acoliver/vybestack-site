#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formatters/markdown.js';
import { renderText } from '../formatters/text.js';

interface CliArgs {
  dataPath: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const parsed: Partial<CliArgs> = {};
  
  if (args.length < 3) {
    throw new Error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  parsed.dataPath = args[2];
  
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const format = args[i];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error('Unsupported format');
      }
      parsed.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      parsed.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!parsed.format) {
    throw new Error('--format is required');
  }
  
  return {
    dataPath: parsed.dataPath!,
    format: parsed.format!,
    outputPath: parsed.outputPath,
    includeTotals: parsed.includeTotals || false,
  };
}

function loadReportData(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid title');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid summary');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Invalid report data: missing or invalid entries array');
    }
    
    const entries = obj.entries.map((entry, index) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid entry at index ${index}: expected object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid label`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid amount`);
      }
      
      return {
        label: entryObj.label,
        amount: entryObj.amount,
      };
    });
    
    return {
      title: obj.title,
      summary: obj.summary,
      entries,
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${path}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, options: ReportOptions, format: 'markdown' | 'text'): string {
  if (format === 'markdown') {
    return renderMarkdown(data, options);
  } else {
    return renderText(data, options);
  }
}

async function main(): Promise<void> {
  try {
    const args = parseArguments(process.argv);
    const data = loadReportData(args.dataPath);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const output = renderReport(data, options, args.format);
    
    if (args.outputPath) {
      await writeFile(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
