import type { ReportData, ReportOptions } from '../types.js';

export type ReportFormatter = (data: ReportData, options: ReportOptions) => string;

export interface Formatter {
  render: ReportFormatter;
}