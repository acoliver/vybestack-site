/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: ObserverR
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(): void {
  // This function should trigger updates to dependent computed values
  // When a subject changes, we need to trigger updateObserver on all observers
  // For now, this is a placeholder that should be implemented based on the observable pattern
}

// Track subjects to notify when their observers update
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const subjectObservers = new Map<ObserverR, Set<Observer<any>>>()

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function registerObserver(subject: ObserverR, observer: Observer<any>): void {
  if (!subjectObservers.has(subject)) {
    subjectObservers.set(subject, new Set())
  }
  subjectObservers.get(subject)!.add(observer)
}

export function notifySubjectObservers(subject: ObserverR): void {
  const observers = subjectObservers.get(subject)
  if (observers) {
    observers.forEach(observer => {
      if (observer.updateFn && typeof observer.updateFn === 'function') {
        updateObserver(observer as Observer<unknown>)
      }
    })
  }
}
