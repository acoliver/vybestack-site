/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver, registerObserver, getActiveObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }
  
  // Set up the callback to track dependencies
  const setActiveObserver = (globalThis as { __setActiveObserver?: (observer: Observer<T>) => void }).__setActiveObserver
  const previousObserver = setActiveObserver ? getActiveObserver() : undefined
  
  if (setActiveObserver) setActiveObserver(observer)
  
  try {
    // Execute callback to establish dependencies
    updateObserver(observer)
    
    // Register with current active observer
    const active = getActiveObserver()
    if (active) {
      registerObserver(active, observer)
      observer.observer = active
    }
  } finally {
    const restoreObserver = (globalThis as { __restoreObserver?: (observer?: ObserverR) => void }).__restoreObserver
    if (restoreObserver) restoreObserver(previousObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer
    observer.value = undefined
    observer.updateFn = () => value!
  }
}