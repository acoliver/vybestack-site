/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  EqualFn,
  getActiveObserver,
  registerObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  let initialized = false

  const getter: GetterFn<T> = () => {
    // Initialize on first call
    if (!initialized) {
      initialized = true
      if (o.value === undefined) {
        o.value = updateFn(o.value)
      }
      return o.value!
    }
    
    const observer = getActiveObserver()
    if (observer) {
      // Link this computed to the active observer
      o.observer = observer
      registerObserver(observer, o)
    }
    
    // Always compute the value to ensure we track dependencies
    const setActiveObserver = (globalThis as { __setActiveObserver?: (observer: Observer<T>) => void }).__setActiveObserver
    const previousObserver = setActiveObserver ? getActiveObserver() : undefined
    
    if (setActiveObserver) setActiveObserver(o)
    
    try {
      const newValue = updateFn(o.value)
      // Skip update if values are equal according to equalFn
      if (equalFn && o.value !== undefined && equalFn(o.value, newValue)) {
        return o.value!
      }
      o.value = newValue
    } finally {
      const restoreObserver = (globalThis as { __restoreObserver?: (observer?: ObserverR) => void }).__restoreObserver
      if (restoreObserver) restoreObserver(previousObserver)
    }
    
    return o.value!
  }
  
  return getter
}