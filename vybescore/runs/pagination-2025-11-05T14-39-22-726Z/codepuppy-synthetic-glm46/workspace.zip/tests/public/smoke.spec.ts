import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  describe('validation', () => {
    it('rejects non-numeric page parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=abc');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page must be a positive integer');
    });

    it('rejects non-numeric limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=xyz');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit must be a positive integer (max 100)');
    });

    it('rejects negative page parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=-1');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page must be a positive integer');
    });

    it('rejects zero page parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page must be a positive integer');
    });

    it('rejects negative limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=-5');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit must be a positive integer (max 100)');
    });

    it('rejects zero limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit must be a positive integer (max 100)');
    });

    it('rejects excessive limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=101');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit must be a positive integer (max 100)');
    });
  });

  describe('pagination behavior', () => {
    it('uses default pagination parameters', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(5);
      expect(response.body.items.length).toBe(5);
      expect(response.body.total).toBe(15); // Based on seed data
      expect(response.body.hasNext).toBe(true);
    });

    it('uses custom pagination parameters', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=2&limit=3');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(2);
      expect(response.body.limit).toBe(3);
      expect(response.body.items.length).toBe(3);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
    });

    it('returns correct items for first page', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=1&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(5);
      expect(response.body.items[0].id).toBe(1);
      expect(response.body.items[4].id).toBe(5);
    });

    it('returns correct items for second page', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=2&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(5);
      expect(response.body.items[0].id).toBe(6);
      expect(response.body.items[4].id).toBe(10);
    });

    it('returns correct items for last page', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=3&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(5);
      expect(response.body.items[0].id).toBe(11);
      expect(response.body.items[4].id).toBe(15);
      expect(response.body.hasNext).toBe(false);
    });

    it('returns empty results for page beyond data', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=4&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(0);
      expect(response.body.hasNext).toBe(false);
    });

    it('calculates hasNext correctly', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      
      const page1Response = await request(app).get('/inventory?page=1&limit=5');
      expect(page1Response.body.hasNext).toBe(true);
      
      const page2Response = await request(app).get('/inventory?page=2&limit=5');
      expect(page2Response.body.hasNext).toBe(true);
      
      const page3Response = await request(app).get('/inventory?page=3&limit=5');
      expect(page3Response.body.hasNext).toBe(false);
      
      const page4Response = await request(app).get('/inventory?page=4&limit=5');
      expect(page4Response.body.hasNext).toBe(false);
    });

    it('handles single item per page correctly', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      
      const firstResponse = await request(app).get('/inventory?page=10&limit=1');
      expect(firstResponse.status).toBe(200);
      expect(firstResponse.body.items.length).toBe(1);
      expect(firstResponse.body.items[0].id).toBe(10);
      expect(firstResponse.body.hasNext).toBe(true);
      
      const lastResponse = await request(app).get('/inventory?page=15&limit=1');
      expect(lastResponse.status).toBe(200);
      expect(lastResponse.body.items.length).toBe(1);
      expect(lastResponse.body.items[0].id).toBe(15);
      expect(lastResponse.body.hasNext).toBe(false);
    });
  });
});
