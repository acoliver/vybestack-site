import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'child_process';

let server: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the actual server implementation
  try {
    // The server is started by running the built dist/server.js
    // For testing, we'll start it on a test port
    process.env.PORT = '3536';
    spawn('npm', ['run', 'build'], { cwd: process.cwd() });
    
    // Wait a bit for compilation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Start the server
    server = spawn('node', ['dist/server.js'], { cwd: process.cwd() });
    
    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 2000));
  } catch (error) {
    console.log('Note: Server not available for testing');
  }
});

afterAll(() => {
  if (server && typeof server.kill === 'function') {
    server.kill();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // Basic test structure for now
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
