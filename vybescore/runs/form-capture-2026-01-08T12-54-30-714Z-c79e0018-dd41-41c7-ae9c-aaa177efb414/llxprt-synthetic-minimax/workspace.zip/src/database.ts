import fs from 'fs';
import path from 'path';

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: unknown | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Initialize sql.js using ES module compatible approach
      const sqlModule = await (await import('sql.js')).default();
      
      const dbExists = fs.existsSync(this.dbPath);
      
      if (dbExists) {
        // Load existing database
        const dbBuffer = fs.readFileSync(this.dbPath);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.db = new (sqlModule as any).Database(new Uint8Array(dbBuffer));
      } else {
        // Create new database
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        this.db = new (sqlModule as any).Database();
        
        // Read and execute schema
        const schema = fs.readFileSync(this.schemaPath, 'utf8');
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (this.db as any).run(schema);
        
        // Write initial database file
        this.save();
      }
    } catch (error) {
      throw new Error(`Database initialization failed: ${error}`);
    }
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const stmt = (this.db as any).prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      ]);

      // Get the last inserted ID
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const result = (this.db as any).exec("SELECT last_insert_rowid() as id");
      if (result.length > 0 && result[0].values.length > 0) {
        return result[0].values[0][0] as number;
      }
      throw new Error('Failed to get inserted ID');
    } finally {
      stmt.free();
    }
  }

  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Export database to file
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const dbData = (this.db as any).export();
    const buffer = Buffer.from(dbData);
    fs.writeFileSync(this.dbPath, buffer);
  }

  close(): void {
    if (this.db) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (this.db as any).close();
      this.db = null;
    }
  }
}