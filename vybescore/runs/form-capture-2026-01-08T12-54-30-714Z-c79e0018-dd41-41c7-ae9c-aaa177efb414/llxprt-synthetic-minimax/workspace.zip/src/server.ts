import express from 'express';
import path from 'path';
import { DatabaseManager } from './database.js';
import { Validator, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
const dbManager = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Routes

// GET / - Display contact form
app.get('/', (req, res) => {
  res.status(200).render('form', {
    title: 'Contact Us',
    errors: {},
    formData: {} as FormData
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req, res) => {
  const formData: FormData = {
    first_name: req.body.first_name?.trim() || '',
    last_name: req.body.last_name?.trim() || '',
    street_address: req.body.street_address?.trim() || '',
    city: req.body.city?.trim() || '',
    state_province: req.body.state_province?.trim() || '',
    postal_code: req.body.postal_code?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const validation = Validator.validateForm(formData);

  if (!validation.isValid) {
    // Validation failed, re-render form with errors
    return res.status(200).render('form', {
      title: 'Contact Us',
      errors: validation.errors,
      formData
    });
  }

  try {
    // Insert submission into database
    dbManager.insertSubmission(formData).then(() => {
      // Save database to disk
      dbManager.save();
      
      // Redirect to thank you page
      res.redirect(302, '/thank-you');
    }).catch(error => {
      console.error('Database error:', error);
      return res.status(500).render('form', {
        title: 'Contact Us',
        errors: { _general: 'An error occurred while processing your submission. Please try again.' },
        formData
      });
    });
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      title: 'Contact Us',
      errors: { _general: 'An error occurred while processing your submission. Please try again.' },
      formData
    });
  }
});

// GET /thank-you - Display thank you page
app.get('/thank-you', (req, res) => {
  res.status(200).render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('Shutting down gracefully...');
  dbManager.close();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(error => {
  console.error('Server startup failed:', error);
  process.exit(1);
});
