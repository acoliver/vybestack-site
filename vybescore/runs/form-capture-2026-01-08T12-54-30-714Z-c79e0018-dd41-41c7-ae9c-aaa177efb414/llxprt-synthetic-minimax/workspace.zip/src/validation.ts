export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationErrors {
  [key: string]: string;
}

export class Validator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10;
  }

  static validatePostalCode(postalCode: string): boolean {
    // Accept alphanumeric strings, handle formats like "SW1A 1AA", "C1000", "B1675"
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.length >= 3;
  }

  static validateRequired(value: string): boolean {
    return value.trim().length > 0;
  }

  static validateForm(data: FormData): { isValid: boolean; errors: ValidationErrors } {
    const errors: ValidationErrors = {};

    // Required field validation
    if (!this.validateRequired(data.first_name)) {
      errors.first_name = 'First name is required';
    }

    if (!this.validateRequired(data.last_name)) {
      errors.last_name = 'Last name is required';
    }

    if (!this.validateRequired(data.street_address)) {
      errors.street_address = 'Street address is required';
    }

    if (!this.validateRequired(data.city)) {
      errors.city = 'City is required';
    }

    if (!this.validateRequired(data.state_province)) {
      errors.state_province = 'State/Province/Region is required';
    }

    if (!this.validateRequired(data.postal_code)) {
      errors.postal_code = 'Postal/Zip code is required';
    }

    if (!this.validateRequired(data.country)) {
      errors.country = 'Country is required';
    }

    if (!this.validateRequired(data.email)) {
      errors.email = 'Email is required';
    } else if (!this.validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!this.validateRequired(data.phone)) {
      errors.phone = 'Phone number is required';
    } else if (!this.validatePhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code format validation
    if (data.postal_code && !this.validatePostalCode(data.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }
}