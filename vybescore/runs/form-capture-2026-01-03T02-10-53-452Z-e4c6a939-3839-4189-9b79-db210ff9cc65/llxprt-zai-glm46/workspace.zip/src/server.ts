import express, { Request, Response, Express } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';
import { existsSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: Express;
  private db: Database | null = null;
  private SQL!: Awaited<ReturnType<typeof initSqlJs>>;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3535', 10);
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'views'));
  }

  private async initDatabase(): Promise<void> {
    try {
      this.SQL = await initSqlJs();

      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!existsSync(dataDir)) {
        await fs.mkdir(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (existsSync(DB_PATH)) {
        const dbBuffer = await fs.readFile(DB_PATH);
        this.db = new this.SQL.Database(dbBuffer);
      } else {
        this.db = new this.SQL.Database();
        const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
        this.db!.run(schema);
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (this.db) {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      await fs.writeFile(DB_PATH, buffer);
    }
  }

  private validateForm(formData: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    if (!formData.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!formData.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!formData.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!formData.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!formData.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!formData.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    } else if (!/^[A-Za-z0-9\s-]+$/.test(formData.postalCode.trim())) {
      errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
    }

    if (!formData.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    // Email validation
    if (!formData.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email.trim())) {
        errors.push({ field: 'email', message: 'Please enter a valid email address' });
      }
    }

    // Phone validation - international formats allowed
    if (!formData.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else {
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      if (!phoneRegex.test(formData.phone.trim())) {
        errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    // Form page
    this.app.get('/', (req: Request, res: Response): void => {
      res.render('index', {
        errors: [],
        formData: {},
      });
    });

    // Form submission
    this.app.post('/submit', async (req: Request, res: Response): Promise<void> => {
      const formData: Partial<FormData> = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone,
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        res.status(400).render('index', {
          errors,
          formData,
        });
        return;
      }

      // Insert into database
      try {
        if (this.db) {
          this.db.run(
            `INSERT INTO submissions 
            (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              formData.firstName!.trim(),
              formData.lastName!.trim(),
              formData.streetAddress!.trim(),
              formData.city!.trim(),
              formData.stateProvince!.trim(),
              formData.postalCode!.trim(),
              formData.country!.trim(),
              formData.email!.trim(),
              formData.phone!.trim(),
            ]
          );
          await this.saveDatabase();
        }

        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        errors.push({ field: 'general', message: 'An error occurred while saving your submission. Please try again.' });
        res.status(500).render('index', { errors, formData });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response): void => {
      res.render('thank-you');
    });
  }

  private server: ReturnType<Express['listen']> | null = null;

  public async start(): Promise<void> {
    await this.initDatabase();
    
    this.server = this.app.listen(this.port, () => {
      console.log(`Form capture server running on port ${this.port}`);
    }) as ReturnType<Express['listen']>;

    // Handle graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  public shutdown(): void {
    console.log('Shutting down server...');
    if (this.server) {
      this.server.close(() => {
        if (this.db) {
          this.db.close();
        }
        console.log('Server closed');
        process.exit(0);
      });
    }
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
