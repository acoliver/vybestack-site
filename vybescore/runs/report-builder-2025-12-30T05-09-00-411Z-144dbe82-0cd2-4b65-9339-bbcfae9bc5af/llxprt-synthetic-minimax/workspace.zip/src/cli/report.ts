#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Formatter registry
const formatters = {
  markdown: renderMarkdown,
  text: renderText
} as const;

type Format = keyof typeof formatters;

function parseArgs(args: string[]): { dataPath: string; options: CLIOptions } {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[2]; // argv[0] is node, argv[1] is script path
  
  let format: Format | null = null;
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments starting from argv[3]
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const formatValue = args[++i];
      if (!formatValue) {
        console.error('--format requires a value');
        process.exit(1);
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      const outputValue = args[++i];
      if (!outputValue) {
        console.error('--output requires a value');
        process.exit(1);
      }
      output = outputValue;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('--format is required');
    process.exit(1);
  }

  if (!formatters[format]) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return {
    dataPath,
    options: { format, output, includeTotals }
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    console.error('Invalid JSON: root must be an object');
    return false;
  }

  const dataObj = data as Record<string, unknown>;

  if (!dataObj.title || typeof dataObj.title !== 'string') {
    console.error('Invalid JSON: "title" field is required and must be a string');
    return false;
  }

  if (!dataObj.summary || typeof dataObj.summary !== 'string') {
    console.error('Invalid JSON: "summary" field is required and must be a string');
    return false;
  }

  if (!dataObj.entries || !Array.isArray(dataObj.entries)) {
    console.error('Invalid JSON: "entries" field is required and must be an array');
    return false;
  }

  const entries = dataObj.entries as unknown[];
  // Validate entries
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i] as Record<string, unknown>;
    if (!entry || typeof entry !== 'object') {
      console.error(`Invalid JSON: entries[${i}] must be an object`);
      return false;
    }

    if (!entry.label || typeof entry.label !== 'string') {
      console.error(`Invalid JSON: entries[${i}] must have a "label" field that is a string`);
      return false;
    }

    if (typeof entry.amount !== 'number') {
      console.error(`Invalid JSON: entries[${i}] must have an "amount" field that is a number`);
      return false;
    }
  }

  return true;
}

function loadReportData(dataPath: string): ReportData {
  try {
    const content = readFileSync(join(process.cwd(), dataPath), 'utf-8');
    const data = JSON.parse(content);
    
    if (!validateReportData(data)) {
      process.exit(1);
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if ('code' in error && error.code === 'ENOENT') {
        console.error(`File not found: ${dataPath}`);
      } else if (error.name === 'SyntaxError') {
        console.error('Invalid JSON: malformed JSON');
      } else {
        console.error(`Error reading file: ${error.message}`);
      }
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const { dataPath, options } = parseArgs(args);
  
  const data = loadReportData(dataPath);
  const formatter = formatters[options.format];
  
  const output = formatter.format(data, options);
  
  if (options.output) {
    try {
      writeFileSync(join(process.cwd(), options.output!), output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing output file: ${error.message}`);
      } else {
        console.error('Unknown error occurred while writing output');
      }
      process.exit(1);
    }
  } else {
    process.stdout.write(output + '\n');
  }
}

main();
