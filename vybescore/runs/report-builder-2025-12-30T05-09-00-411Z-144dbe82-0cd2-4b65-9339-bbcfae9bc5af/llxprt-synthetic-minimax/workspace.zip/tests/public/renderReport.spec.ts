import { describe, expect, it } from 'vitest';
import { execSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

function normalize(str: string): string {
  return str
    .trim()
    .replace(/\n\s*\n/g, '\n')
    .replace(/\s+/g, ' ');
}

describe('report CLI (public smoke)', () => {
  const dataPath = 'fixtures/data.json';
  const malformedPath = 'test_malformed.json';
  const missingEntriesPath = 'test_missing_entries.json';

  it('render markdown without totals', () => {
    const result = execSync(`node dist/cli/report.js ${dataPath} --format markdown`, {
      encoding: 'utf-8',
      cwd: process.cwd()
    });

    const expectedText = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('render markdown with totals', () => {
    const result = execSync(`node dist/cli/report.js ${dataPath} --format markdown --includeTotals`, {
      encoding: 'utf-8',
      cwd: process.cwd()
    });

    const expectedText = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('render text without totals', () => {
    const result = execSync(`node dist/cli/report.js ${dataPath} --format text`, {
      encoding: 'utf-8',
      cwd: process.cwd()
    });

    const expectedText = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('render text with totals', () => {
    const result = execSync(`node dist/cli/report.js ${dataPath} --format text --includeTotals`, {
      encoding: 'utf-8',
      cwd: process.cwd()
    });

    const expectedText = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('handle missing arguments', () => {
    try {
      execSync(`node dist/cli/report.js`, {
        encoding: 'utf-8',
        cwd: process.cwd()
      });
      expect(true).toBe(false); // Should not reach here
    } catch (error: any) {
      expect(error.status).toBe(1);
      expect(error.stdout + error.stderr).toContain('Usage:');
    }
  });

  it('handle missing format', () => {
    try {
      execSync(`node dist/cli/report.js ${dataPath}`, {
        encoding: 'utf-8',
        cwd: process.cwd()
      });
      expect(true).toBe(false); // Should not reach here
    } catch (error: any) {
      expect(error.status).toBe(1);
      expect(error.stdout + error.stderr).toContain('--format is required');
    }
  });

  it('handle unsupported format', () => {
    try {
      execSync(`node dist/cli/report.js ${dataPath} --format csv`, {
        encoding: 'utf-8',
        cwd: process.cwd()
      });
      expect(true).toBe(false); // Should not reach here
    } catch (error: any) {
      expect(error.status).toBe(1);
      expect(error.stdout + error.stderr).toContain('Unsupported format');
    }
  });

  it('handle malformed JSON', () => {
    try {
      execSync(`node dist/cli/report.js ${malformedPath} --format markdown`, {
        encoding: 'utf-8',
        cwd: process.cwd()
      });
      expect(true).toBe(false); // Should not reach here
    } catch (error: any) {
      expect(error.status).toBe(1);
      expect(error.stdout + error.stderr).toContain('Invalid JSON');
    }
  });

  it('handle missing entries', () => {
    try {
      execSync(`node dist/cli/report.js ${missingEntriesPath} --format markdown`, {
        encoding: 'utf-8',
        cwd: process.cwd()
      });
      expect(true).toBe(false); // Should not reach here
    } catch (error: any) {
      expect(error.status).toBe(1);
      expect(error.stdout + error.stderr).toContain('Invalid JSON');
    }
  });
});
