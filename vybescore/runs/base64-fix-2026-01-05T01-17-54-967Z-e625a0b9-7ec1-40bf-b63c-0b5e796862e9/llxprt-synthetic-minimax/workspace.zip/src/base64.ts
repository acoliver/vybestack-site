/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with proper padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input contains only valid Base64 characters and proper padding.
 */
export function decode(input: string): string {
  // Remove whitespace and validate input
  const cleanInput = input.trim();
  
  // Handle URL-safe Base64 by converting to standard
  const normalizedInput = cleanInput.replace(/-/g, '+').replace(/_/g, '/');
  
  // Check if input contains only valid Base64 characters
  const base64CharRegex = /^[A-Za-z0-9+/=]*$/;
  const base64UrlCharRegex = /^[A-Za-z0-9+/_=-]*$/;
  
  // Validate character set - allow both standard and URL-safe
  const validCharSet = base64CharRegex.test(normalizedInput) || base64UrlCharRegex.test(normalizedInput);
  if (!validCharSet) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Validate padding count - should be 0, 1, or 2, and only at the end
  const paddingMatch = normalizedInput.match(/=+$/);
  const paddingCount = paddingMatch ? paddingMatch[0].length : 0;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // Check that any padding appears only at the end
  if (paddingCount > 0 && normalizedInput.slice(0, -paddingCount).includes('=')) {
    throw new Error('Invalid Base64 input: padding characters must be at the end');
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding or padding');
  }
}
