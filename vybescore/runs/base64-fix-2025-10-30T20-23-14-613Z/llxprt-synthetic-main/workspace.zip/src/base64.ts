/**
 * Encode plain text to Base64 using canonical RFC 4648 encoding
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string is a valid Base64 string according to RFC 4648
 * Uses a more rigorous validation that checks if the string can be properly decoded
 */
function isValidBase64(input: string): boolean {
  // Try to decode the string to verify it's valid Base64
  try {
    const decoded = Buffer.from(input, 'base64');
    // Check if this was properly round-trippable Base64
    const roundTrip = decoded.toString('base64');
    
    // Extract the actual content without padding (original length of input without '=')
    const originalWithoutPadding = input.replace(/=+$/, '');
    const roundTripWithoutPadding = roundTrip.replace(/=+$/, '');
    
    // If they match, the input is valid Base64
    return originalWithoutPadding === roundTripWithoutPadding;
  } catch {
    return false;
  }
}

/**
 * Decode Base64 text back to plain UTF-8 using canonical RFC 4648
 * This function validates the input and throws errors for invalid Base64
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
