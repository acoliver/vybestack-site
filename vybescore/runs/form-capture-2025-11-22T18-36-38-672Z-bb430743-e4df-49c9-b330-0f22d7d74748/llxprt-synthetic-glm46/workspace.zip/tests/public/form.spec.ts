import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);
let serverProcess: import('child_process').ChildProcess;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Remove any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Build the server first
  await execAsync('npm run build');
  
  // Start the server in the background with the same port
  serverProcess = exec('PORT=3535 node dist/server.js', (error) => {
    if (error) {
      console.error('Server error:', error);
    }
  });
  
  // Give the server time to start
  await new Promise(resolve => setTimeout(resolve, 3000));
});

afterAll(async () => {
  if (serverProcess) {
    serverProcess.kill();
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for form elements
    expect($('form[method="post"][action="/submit"]').length).toBe(1);
    
    // Check for form fields
    const fields = ['first_name', 'last_name', 'street_address', 'city', 
                   'state_province', 'postal_code', 'country', 'email', 'phone'];
    
    for (const field of fields) {
      expect($(`input[name="${field}"]`).length).toBe(1);
      expect($(`label[for="${field}"]`).length).toBe(1);
    }
    
    // Check for submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Test with some invalid data to see validation
    const invalidFormData = {
      first_name: '',
      last_name: '',
      email: 'invalid-email'
    };
    
    const invalidResponse = await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send(invalidFormData);
    
    // Should return 400 with validation errors
    expect(invalidResponse.status).toBe(400);
    
    const $ = cheerio.load(invalidResponse.text);
    expect($('.error-list').length).toBe(1);
    
    // Now test with valid data
    const validFormData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form
    const response = await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send(validFormData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check thank-you page
    const thankYouResponse = await request('http://localhost:3535')
      .get('/thank-you')
      .expect(200);
    
    const $thankYou = cheerio.load(thankYouResponse.text);
    expect($thankYou('.thank-you-content').length).toBe(1);
    expect($thankYou('h1').text()).toContain('Thank you');
  });
});
