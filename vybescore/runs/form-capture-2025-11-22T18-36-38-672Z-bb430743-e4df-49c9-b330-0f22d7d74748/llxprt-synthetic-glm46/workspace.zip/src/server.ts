import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

let db: Database | null = null;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Middleware
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields check
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push({ field, message: 'This field is required' });
    }
  }

  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation
  if (formData.postal_code && !validatePostalCode(formData.postal_code)) {
    errors.push({ field: 'postal_code', message: 'Please enter a valid postal code' });
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    console.log('Initializing SQLite database...');
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Check if database file exists
    if (fs.existsSync(DB_PATH)) {
      console.log('Loading existing database from', DB_PATH);
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } else {
      console.log('Creating new database');
      db = new SQL.Database();
      
      // Create the submissions table
      const schema = fs.readFileSync(
        path.join(__dirname, '..', 'db', 'schema.sql'), 
        'utf8'
      );
      db.run(schema);
      
      // Save the new database
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) {
    console.error('Database not initialized');
    return;
  }

  try {
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
    console.log('Database saved to', DB_PATH);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Save form submission to database
function saveSubmission(formData: FormData): void {
  if (!db) {
    console.error('Database not initialized');
    return;
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();
    console.log('Form submission saved');
  } catch (error) {
    console.error('Failed to save submission:', error);
  }
}

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', { 
    errors: [],
    formData: {} as Partial<FormData>
  });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', { errors, formData });
  }

  saveSubmission(formData);
  return res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you');
});

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('Shutting down server...');
  
  if (db) {
    try {
      // Export database to file before closing
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
      console.log('Database saved successfully');
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

// Handle SIGTERM signal for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown); // Also handle Ctrl+C

// Start server
let server;
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle server errors
    server.on('error', (error) => {
      console.error('Server error:', error);
      process.exit(1);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch((error) => {
  console.error('Server startup failed:', error);
  process.exit(1);
});
