/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  SubjectR,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
function getDefaultEqual<T>(): EqualFn<T> {
  return (lhs: T, rhs: T) => lhs === rhs
}

function toEqualFn<T>(equal: boolean | EqualFn<T> | undefined): EqualFn<T> {
  if (equal === undefined) return getDefaultEqual<T>()
  if (typeof equal === 'boolean') return equal ? getDefaultEqual<T>() : getDefaultEqual<T>()
  return equal
}

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: toEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Track this subject in the observer's subject list for cleanup
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      observer.subjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Separate computed values (observers without subjects) from callbacks (observers with subjects)
    const computed: Observer<T>[] = []
    const callbacks: Observer<T>[] = []
    const toRemove: ObserverR[] = []
    
    for (const observer of s.observers) {
      const obs = observer as Observer<T> & { disposed?: boolean; subjects?: Set<SubjectR> }
      if (obs.disposed) {
        toRemove.push(observer)
      } else if (obs.subjects && obs.subjects.size > 0) {
        // This is a callback (it tracks other subjects)
        callbacks.push(obs as Observer<T>)
      } else {
        // This is a computed value
        computed.push(obs as Observer<T>)
      }
    }
    
    // Remove disposed observers
    for (const observer of toRemove) {
      s.observers.delete(observer)
    }
    
    // Notify computed values first, then callbacks
    for (const obs of computed) {
      updateObserver(obs)
    }
    for (const obs of callbacks) {
      updateObserver(obs)
    }
    
    return s.value
  }

  return [read, write]
}
