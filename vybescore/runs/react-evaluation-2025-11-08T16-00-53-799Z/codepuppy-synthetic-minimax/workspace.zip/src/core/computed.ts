/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  updateObserver,
  EqualFn,
  ObserverWithCleanup,
  SubjectR,
  getActiveObserver,
  notifyObservers
} from '../types/reactive'

function getDefaultEqual<T>(): EqualFn<T> {
  return (lhs: T, rhs: T) => lhs === rhs
}

function _toEqualFn<T>(equal: boolean | EqualFn<T> | undefined): EqualFn<T> {
  if (equal === undefined) return getDefaultEqual<T>()
  if (typeof equal === 'boolean') return equal ? getDefaultEqual<T>() : getDefaultEqual<T>()
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create the observer part (tracks dependencies)
  const observer: ObserverWithCleanup<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      const oldValue = observer.value
      const newValue = updateFn(prevValue)
      // Only notify if the value actually changed from the previous value
      if (oldValue !== undefined && (!equalFn || !equalFn(oldValue, newValue))) {
        observer.value = newValue
        // Notify observers of this computed value when it changes
        notifyObservers(subject, newValue)
      } else {
        observer.value = newValue
      }
      return newValue
    },
    disposed: false,
    subjects: new Set(),
  }
  
  // Create the subject part (notifies its own observers)
  const equalFn = _toEqualFn(equal)
  const subject: SubjectR = {
    name: options?.name,
    observers: new Set(),
  }
  
  // Combine them so the computed acts as both observer and subject
  const computed = observer as ObserverWithCleanup<T> & SubjectR
  computed.observers = subject.observers
  
  return (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // If there's an active observer, add this computed to its subjects
      subject.observers.add(currentObserver)
      if (!currentObserver.subjects) {
        currentObserver.subjects = new Set()
      }
      currentObserver.subjects.add(computed as SubjectR)
    }
    
    // Track dependencies and recompute
    updateObserver(observer)
    return observer.value!
  }
}