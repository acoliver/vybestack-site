/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Extend Observer to track which subjects it's observing for cleanup
export type ObserverWithCleanup<T> = Observer<T> & {
  disposed?: boolean
  subjects: Set<SubjectR>
}

let activeObserver: (ObserverR & { subjects?: Set<SubjectR> }) | undefined

export function getActiveObserver(): (ObserverR & { subjects?: Set<SubjectR> }) | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const obsWithDisposed = observer as Observer<T> & { disposed?: boolean }
    if (!obsWithDisposed.disposed) {
      observer.value = observer.updateFn(observer.value)
    }
  } finally {
    activeObserver = previous
  }
}

// Helper function to notify observers of a subject
export function notifyObservers<T>(subject: { name?: string; observers: Set<ObserverR> }, _value?: T): void {
  const toRemove: ObserverR[] = []
  
  for (const observer of subject.observers) {
    const obs = observer as Observer<T> & { disposed?: boolean }
    if (obs.disposed) {
      toRemove.push(observer)
    } else {
      updateObserver(obs)
    }
  }
  
  // Remove disposed observers
  for (const observer of toRemove) {
    subject.observers.delete(observer)
  }
}
