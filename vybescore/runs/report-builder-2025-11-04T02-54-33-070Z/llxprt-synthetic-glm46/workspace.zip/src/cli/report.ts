#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, ReportOptions } from '../types.js';
import { getRenderer } from '../formats/index.js';

function parseArguments(): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[i + 1];
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument: ${args[i]}`);
        process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }

  const entries = obj.entries.map((entry, index) => {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      Array.isArray(entry)
    ) {
      throw new Error(
        `Invalid data: entry at index ${index} must be an object`,
      );
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid data: entry at index ${index} must have a string label`,
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid data: entry at index ${index} must have a number amount`,
      );
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

async function main() {
  try {
    // Parse command line arguments
    const { dataFile, format, outputPath, includeTotals } = parseArguments();

    // Load and validate report data
    const data = loadReportData(dataFile);

    // Get the renderer for the specified format
    const renderer = getRenderer(format);

    // Render the report
    const options: ReportOptions = { includeTotals };
    const output = renderer(data, options);

    // Write output to file or stdout
    if (outputPath) {
      await writeFile(outputPath, output, 'utf-8');
      console.log(`Report generated at ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Execute main function if this script is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}