import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

export const renderText: ReportRenderer = (
  data: ReportData,
  options: ReportOptions,
): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  const lines: string[] = [];

  // Title
  lines.push(title);
  lines.push('');

  // Summary
  lines.push(summary);
  lines.push('');

  // Entries
  lines.push('Entries:');
  for (const entry of entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- ${entry.label}: ${formattedAmount}`);
  }

  // Totals
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    lines.push(`\nTotal: ${formattedTotal}`);
  }

  return lines.join('\n');
};