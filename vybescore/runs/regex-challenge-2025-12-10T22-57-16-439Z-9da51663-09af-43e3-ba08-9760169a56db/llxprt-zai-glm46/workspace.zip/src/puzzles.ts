export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index);
}

export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const embeddedRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = embeddedRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

export function isStrongPassword(value: string): boolean {
  if (value.length < 10) {
    return false;
  }
  
  if (/\s/.test(value)) {
    return false;
  }
  
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>]/.test(value)) {
    return false;
  }
  
  if (/(.)\1\1/.test(value)) {
    return false;
  }
  
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.substr(i, 2);
    if (value.substr(i + 2, 2) === pattern) {
      return false;
    }
  }
  
  return true;
}

export function containsIPv6(value: string): boolean {
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  const ipv6BasicPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  const ipv6CompressedPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*/;
  const ipv6MixedPattern = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  return ipv6BasicPattern.test(value) || ipv6CompressedPattern.test(value) || ipv6MixedPattern.test(value);
}
