export function capitalizeSentences(text: string): string {
  const commonAbbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Mt|Capt|Lt|Col|Gen|Rep|Sen|Gov|Pres|Atty|Pvt|Sgt|Maj|Ave|Blvd|Rd|St|Dept|Univ|Assn|Inc|Ltd|Corp|etc|e\.g|i\.e|vs|al|et|ca|cf|ibid|op|cit|vol|no|pp|p|ed|trans|rev|ed|repr|ser|pt|ch|fig|pl|no|art|para|sec|cl|pseud|cit|op|ed|transl|anno|repr|commentary|crit|intro|pref|ack|bibl|index|app|gloss|abrid|rev|2nd|3rd|4th|5th|6th|7th|8th|9th|10th|1st|11th|12th|13th|14th|15th|16th|17th|18th|19th|20th)\.?\.?\b/gi;
  
  return text
    .split(/([.?!]+)/)
    .map((part, index) => {
      if (index % 2 === 1) {
        return part;
      }
      
      const trimmed = part.trim();
      if (!trimmed) return part;
      
      if (commonAbbreviations.test(trimmed)) {
        return part;
      }
      
      if (trimmed.length > 0) {
        return part.replace(/^(\s*)(\w)/, (match, spaces, letter) => 
          spaces + letter.toUpperCase()
        );
      }
      
      return part;
    })
    .join('')
    .replace(/\s*([.?!]+)\s*/g, '$1 ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&=/]*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => url.replace(/[.,;:!?)\]}]+$/, ''));
}

export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  const dynamicPatterns = /\.(?:jsp|php|asp|aspx|do|cgi|pl|py)|[?#]/;
  
  return text.replace(/http:\/\/([^/]+)(\/[^ \n\r]*)/gi, (match, host, path) => {
    const cleanPath = path.split(/[?#]/)[0];
    
    if (dynamicPatterns.test(cleanPath)) {
      return `https://${host}${path}`;
    }
    
    if (cleanPath.startsWith('/docs/')) {
      return `https://docs.${host}${path}`;
    }
    
    return `https://${host}${path}`;
  });
}

export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(year)) {
    if (day > 29) return 'N/A';
  } else if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}