export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  if (!localPart || !domain) {
    return false;
  }
  
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  if (localPart.includes('..')) {
    return false;
  }
  
  if (domain.includes('_')) {
    return false;
  }
  
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  if (domain.includes('..')) {
    return false;
  }
  
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }
  
  return true;
}

export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  if (options?.allowExtensions) {
    // Handle extension case if needed in future
  }
  
  const cleanPhone = value.trim();
  
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[\s-]?([2-9]\d{2})[\s-]?(\d{4})(?:\s*(?:ext\.?|extension|x)\s*\d+)?$/;
  
  if (!phoneRegex.test(cleanPhone)) {
    return false;
  }
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  const cleanPhone = value.trim().replace(/[\s-]/g, '');
  
  if (cleanPhone.startsWith('+')) {
    const withCountryRegex = /^\+54(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
    if (!withCountryRegex.test(cleanPhone)) {
      return false;
    }
  } else {
    if (!cleanPhone.startsWith('0')) {
      return false;
    }
    const withoutCountryRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
    if (!withoutCountryRegex.test(cleanPhone)) {
      return false;
    }
  }
  
  const match = cleanPhone.match(/^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/);
  if (!match) return false;
  
  const areaCode = match[1].replace(/^0/, '');
  const subscriber = match[2];
  
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (!/^[1-9]\d*$/.test(areaCode)) {
    return false;
  }
  
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  if (/\d/.test(value)) {
    return false;
  }
  
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  if (value.includes('--') || value.includes("''") || value.includes('  ')) {
    return false;
  }
  
  return true;
}

export function isValidCreditCard(value: string): boolean {
  const cleanCard = value.replace(/\D/g, '');
  
  if (!/^\d{13,19}$/.test(cleanCard)) {
    return false;
  }
  
  const visaRegex = /^4\d{12}(\d{3})?(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanCard) && !mastercardRegex.test(cleanCard) && !amexRegex.test(cleanCard)) {
    return false;
  }
  

  return runLuhnCheck(cleanCard);
}