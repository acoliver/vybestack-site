import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasPrevious = page > 1;
  const hasNext = data.hasNext;

  const handlePrevious = () => {
    if (hasPrevious) {
      setPage(page - 1);
    }
  };

  const handleNext = () => {
    if (hasNext) {
      setPage(page + 1);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      {data.items.length === 0 ? (
        <p>No inventory items found.</p>
      ) : (
        <>
          <InventoryList items={data.items} />
          <div>
            <button disabled={!hasPrevious} onClick={handlePrevious}>
              Previous
            </button>
            <span> Page {page} </span>
            <button disabled={!hasNext} onClick={handleNext}>
              Next
            </button>
          </div>
        </>
      )}
    </section>
  );
}
