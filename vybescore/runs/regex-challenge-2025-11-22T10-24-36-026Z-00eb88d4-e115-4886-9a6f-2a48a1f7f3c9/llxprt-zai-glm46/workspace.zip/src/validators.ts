export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(emailValue: string): boolean {
  // Basic email regex that handles typical cases like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional validation to prevent common invalid patterns
  if (!emailRegex.test(emailValue)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (emailValue.includes('..')) {
    return false;
  }
  
  // Reject dots at beginning or end of local part
  const [localPart, domain] = emailValue.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(phoneValue: string): boolean {
  // Remove all non-digit characters first
  const cleaned = phoneValue.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number without country code)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1);
  } else if (digits.length > 10) {
    return false; // Too many digits
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with optional separators
  const phoneRegex = /^(?:\+1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  
  return phoneRegex.test(phoneValue);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(phoneValue: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = phoneValue.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54, optional 0, optional 9 (mobile), area code (2-4 digits, starts 1-9), subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0?)(?:9)?([1-9]\d{0,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(nameValue: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s\u00A0][\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(nameValue)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(nameValue)) {
    return false;
  }
  
  // Reject X Æ A-12 style names with too many unusual characters
  const specialCharCount = (nameValue.match(/[^\p{L}\p{M}'\-\s\u00A0]/gu) || []).length;
  if (specialCharCount > 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate major credit card numbers with Luhn checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(cardValue: string): boolean {
  // Remove all non-digit characters
  const cleaned = cardValue.replace(/\D/g, '');
  
  // Check typical credit card lengths (13-19 digits)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // Amex: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}