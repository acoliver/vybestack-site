/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence-ending punctuation
  // Replace multiple spaces with a single space, and ensure exactly one space after punctuation
  let normalized = text.replace(/\s+/g, ' ') // Collapse multiple spaces
                      .replace(/([.!?])\s*/g, '$1 '); // Ensure exactly one space after sentence punctuation
  
  // Remove any trailing space
  normalized = normalized.trim();
  
  // Capitalize the first character of the string
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize first character after sentence-ending punctuation
  return normalized.replace(/([.!?])\s+([a-z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https protocols and common URL patterns
  // Excludes trailing punctuation like .,!? etc.
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s)]*[^\s.,!?;:)]/gi;
  const matches = text.match(urlRegex) || [];
  return matches.map(url => url.trim());
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\/(?![s])/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then handle the docs rewrite rule
  // Match example.com URLs with /docs/ path, but exclude certain patterns
  result = result.replace(
    /https:\/\/example\.com(\/docs\/[^\s?,]*)(?![^\s]*?(?:cgi-bin|[?.]|\.(jsp|php|asp|aspx|do|cgi|pl|py)))/gi,
    'https://docs.example.com$1'
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format where month (01-12) and day (01-31) are valid
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    return match[3]; // Return the year (4th capture group)
  }
  
  return 'N/A';
}
