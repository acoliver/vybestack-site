/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9_-]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return matches.filter(match => 
    !exceptions.some(exception => 
      match.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to match token only when preceded by a digit
  // and negative lookbehind to ensure it's not at the start
  // Also include the preceding digit in the match
  const tokenRegex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  // Find all occurrences
  const matches: string[] = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Get the preceding digit and add it to the result
    const index = match.index;
    const precedingChar = text[index - 1];
    if (precedingChar && /\d/.test(precedingChar)) {
      matches.push(precedingChar + match[0]);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 123123, etc.)
  const repeatedSequenceRegex = /(..).*\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles shorthand notation and excludes IPv4
  // Use a simpler pattern that captures the core IPv6 formats
  const ipv6Regex = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/g;
  
  // Check for IPv4 pattern and exclude if found
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Find potential IPv6 matches
  const matches = value.match(ipv6Regex);
  
  if (!matches) {
    return false;
  }
  
  // Filter out matches that contain IPv4 patterns
  return matches.some(match => !ipv4Regex.test(match));
}