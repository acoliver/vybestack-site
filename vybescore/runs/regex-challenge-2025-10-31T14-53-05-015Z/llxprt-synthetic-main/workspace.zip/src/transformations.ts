/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing: collapse multiple spaces into one
  let normalizedText = text.replace(/\s+/g, ' ');
  
  // Insert a space after punctuation marks if there isn't one already (and it's not an abbreviation)
  normalizedText = normalizedText.replace(/([.?!])(?!\s|$)/g, '$1 ');
  
  // Split into sentences using punctuation marks
  const sentences = normalizedText.split(/(?<=[.?!])(?=\s)/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim leading whitespace and capitalize first character
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return trimmed;
    return trimmed[0].toUpperCase() + trimmed.slice(1);
  });
  
  // Join with a single space and collapse again just in case
  return processedSentences.join(' ').replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regex for URLs with common protocols
  // Match http://, https://, ftp:// and protocol-relative URLs
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|\/\/)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Strip trailing punctuation (.,!?;:) that is not part of the URL
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// in all URLs that start with http://
  // The negative lookahead ensures we don't match URLs that are already https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // First upgrade all http to https
  const rewritten = text.replace(/http:\/\//g, 'https://');
  
  // Now handle example.com URLs with /docs/ path
  const docsUrlRegex = /https:\/\/(example\.com)\/docs\/([^\s?]*)(?=\?|$)/gi;
  
  return rewritten.replace(docsUrlRegex, (match, hostname, path) => {
    // Check if the URL contains dynamic hints (cgi-bin, query strings, legacy extensions)
    // Since we're using a negative lookahead for query strings in the main regex,
    // we need to check the path for cgi-bin and file extensions
    if (path.includes('cgi-bin') || 
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)($|\?)/i.test(path)) {
      // Keep the original host but with https
      return match;
    }
    // Otherwise, rewrite to docs.example.com
    return `https://docs.${hostname}/docs/${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month/day combinations
  const daysInMonth = (month: number): number => {
    switch (month) {
      case 2: return 28; // Simplified - don't account for leap years
      case 4:
      case 6:
      case 9:
      case 11: return 30;
      default: return 31;
    }
  };
  
  if (day > daysInMonth(month)) {
    return 'N/A';
  }
  
  return year;
}
