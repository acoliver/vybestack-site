export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 simplified email regex with additional constraints
  // Local part: letters, digits, +, -, . and other special chars but no consecutive dots or trailing dots
  // Domain: letters, digits, hyphens, but no underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+$/;
  
  // First basic check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific requirements
  // No double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot in local part or domain
  if (value.endsWith('.@') || value.endsWith('.com.') || value.endsWith('.org.') || 
      value.includes('@.') || value.includes('. @') || value.includes('@.com')) {
    return false;
  }
  
  // Check that domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Check that local part doesn't start or end with dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-numeric characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Minimum length check: 10 digits for US number, optionally 11 with +1 country code
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digits.length === 11 && digits[0] !== '1') {
    return false;
  }
  
  // Extract the 10-digit phone number (without country code if present)
  const phoneDigits = digits.length === 11 ? digits.substring(1) : digits;
  
  // Check area code (first 3 digits) - should not start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Format check - accept common US phone formats
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[-]?)\d{3}[-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Regex for Argentine phone numbers
  // Optional country code (+54)
  // Optional trunk prefix (0) immediately before area code
  // Optional mobile indicator (9) between country/trunk and area code
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0?9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // If no country code, must start with 0 (trunk prefix)
  if (!cleanNumber.startsWith('+54') && !cleanNumber.startsWith('0')) {
    return false;
  }
  
  // Test the format
  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Check area code constraints (2-4 digits, not starting with 0)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Check subscriber number constraints (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Empty check
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Regex for names allowing unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any unicode letter
  // \p{M} matches combining marks (accents)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Basic format check
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with consecutive special characters (like "Jean--Claude")
  if (value.includes("--") || value.includes("  ") || value.includes("''")) {
    return false;
  }
  
  // Reject names that start or end with special characters
  if (/^['\-\s]|['\-\s]$/.test(value)) {
    return false;
  }
  
  // Reject names with numbers or symbols like in "X Æ A-12"
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for unusual symbol patterns
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper function for credit card validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check card type
  if (!visaRegex.test(cleanNumber) && 
      !mastercardRegex.test(cleanNumber) && 
      !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(cleanNumber);
}
