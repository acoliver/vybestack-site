/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a Set for faster exception lookup
  const exceptionSet = new Set(exceptions);
  
  // Regex to match words starting with the prefix
  // \b ensures we match whole words
  // \w* matches the rest of the word characters
  const prefixedWordsRegex = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions and deduplicate
  return Array.from(new Set(matches.filter(word => 
    !exceptionSet.has(word.toLowerCase())
  )));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find digit followed by the token (returning the digit+token combination)
  const embeddedTokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(embeddedTokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This looks for any pattern that's immediately repeated (like "abab")
  // The pattern captures any 2-4 characters and checks if they're repeated
  if (/(..|...|....)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 regex for negative matching
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Check for IPv4 first, if we find an IPv4 address, we should not return true
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 regex covering full format, shorthand with ::, and embedded IPv4
  // Full IPv6 format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand format: one :: can replace consecutive groups of zeros
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  return ipv6Regex.test(value);
}