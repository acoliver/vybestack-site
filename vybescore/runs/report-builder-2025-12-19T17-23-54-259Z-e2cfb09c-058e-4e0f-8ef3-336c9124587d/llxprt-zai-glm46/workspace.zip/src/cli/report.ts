#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format': {
        i++;
        const formatValue = args[i];
        if (formatValue !== 'markdown' && formatValue !== 'text') {
          console.error(`Unsupported format: ${formatValue}`);
          process.exit(1);
        }
        format = formatValue as Format;
        break;
      }
      case '--output': {
        i++;
        outputPath = args[i];
        break;
      }
      case '--includeTotals': {
        includeTotals = true;
        break;
      }
      default: {
        console.error(`Unknown argument: ${args[i]}`);
        process.exit(1);
      }
    }
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Report data must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Report data must have a "title" string field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Report data must have a "summary" string field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Report data must have an "entries" array field');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Each entry must have a "label" string field');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Each entry must have an "amount" number field');
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();
    
    let fileContent: string;
    try {
      fileContent = readFileSync(args.inputFile, 'utf8');
    } catch (error) {
      console.error(`Error reading file ${args.inputFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error parsing JSON in ${args.inputFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    const reportData = validateReportData(jsonData);
    
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    let output: string;
    switch (args.format) {
      case 'markdown': {
        output = renderMarkdown.render(reportData, options);
        break;
      }
      case 'text': {
        output = renderText.render(reportData, options);
        break;
      }
      default: {
        console.error(`Unsupported format: ${args.format}`);
        process.exit(1);
      }
    }
    
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file ${args.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();