import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 validation tests', () => {
  it('handles non-ASCII characters', () => {
    const input = 'héllo wörld ';
    const encoded = encode(input);
    const decoded = decode(encoded);
    expect(decoded).toBe(input);
  });

  it('rejects invalid Base64 characters', () => {
    expect(() => decode('abc!def')).toThrow('Invalid Base64 input: contains illegal characters');
    expect(() => decode('a b c')).toThrow('Invalid Base64 input: contains illegal characters');
  });

  it('rejects obviously invalid Base64', () => {
    // Test some clearly invalid cases
    expect(() => decode('x')).toThrow();
    expect(() => decode('xyz')).toThrow();
  });

  it('handles valid inputs without padding', () => {
    // Test data that's valid without padding 
    expect(decode('YWJjZGVm')).toBe('abcdef');
  });

  it('handles edge cases with different lengths', () => {
    // Single character
    const singleChar = 'a';
    expect(decode(encode(singleChar))).toBe(singleChar);
    
    // Two characters
    const twoChars = 'ab';
    expect(decode(encode(twoChars))).toBe(twoChars);
    
    // Three characters (requires one = padding)
    const threeChars = 'abc';
    expect(decode(encode(threeChars))).toBe(threeChars);
    
    // Four characters (exact fit)
    const fourChars = 'abcd';
    expect(decode(encode(fourChars))).toBe(fourChars);
  });

  it('handles padding correctly', () => {
    // Test data that requires padding when encoded
    const testInputs = [
      'a',        // Should encode to "YQ=="
      'ab',       // Should encode to "YWI="
      'abc',      // Should encode to "YWJj"
    ];
    
    for (const input of testInputs) {
      const encoded = encode(input);
      const decoded = decode(encoded);
      expect(decoded).toBe(input);
    }
  });
});