const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const ERROR_MESSAGES = {
  ILLEGAL_CHARS: 'Invalid Base64 input: contains illegal characters',
  INCORRECT_LENGTH: 'Invalid Base64 input: incorrect length',
  PADDING_NOT_AT_END: 'Invalid Base64 input: padding not at end',
  INCORRECT_PADDING: 'Invalid Base64 input: incorrect padding',
  DECODE_FAILED: 'Failed to decode Base64 input'
} as const;

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate input contains only valid Base64 characters
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error(ERROR_MESSAGES.ILLEGAL_CHARS);
  }

  // Check for minimum length (except for empty string)
  if (trimmed.length > 0 && trimmed.length < 2) {
    throw new Error(ERROR_MESSAGES.INCORRECT_LENGTH);
  }

  // Validate padding position and format
  const paddingIndex = trimmed.indexOf('=');
  
  if (paddingIndex !== -1) {
    const hasValidPadding = isValidPadding(trimmed, paddingIndex);
    if (!hasValidPadding) {
      throw new Error(ERROR_MESSAGES.PADDING_NOT_AT_END);
    }
  } else if (trimmed.length % 4 !== 0 && trimmed.length < 4) {
    // No padding, length should be multiple of 4 for strings shorter than 4 characters
    throw new Error(ERROR_MESSAGES.INCORRECT_LENGTH);
  }

  // Try to decode and catch any errors
  try {
    return Buffer.from(trimmed, 'base64').toString('utf8');
  } catch (error) {
    throw new Error(ERROR_MESSAGES.DECODE_FAILED);
  }
}

/**
 * Validates padding position and format
 */
function isValidPadding(str: string, paddingIndex: number): boolean {
  const paddingPart = str.substring(paddingIndex);
  const paddingCount = paddingPart.length;
  
  // Padding must be at the end
  if (paddingIndex + paddingCount !== str.length) {
    return false;
  }
  
  // Padding can be at most 2 characters and must be all '='
  if (paddingCount > 2) {
    return false;
  }
  
  // Padding characters must all be '='
  for (let i = 0; i < paddingCount; i++) {
    if (paddingPart[i] !== '=') {
      return false;
    }
  }
  
  return true;
}