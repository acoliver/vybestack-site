import type { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};
