import type { ReportData } from './types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const record = data as Record<string, unknown>;

  if (
    typeof record.title !== 'string' ||
    typeof record.summary !== 'string' ||
    !Array.isArray(record.entries)
  ) {
    return false;
  }

  for (const entry of record.entries) {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      typeof (entry as { label: unknown }).label !== 'string' ||
      typeof (entry as { amount: unknown }).amount !== 'number'
    ) {
      return false;
    }
  }

  return true;
}
