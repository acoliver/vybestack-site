#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';

import type { RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { formatters } from '../formats/index.js';

function parseArgs(args: string[]): {
  inputPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  let inputPath = '';
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!inputPath) {
      inputPath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!inputPath) {
    throw new Error('Input file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { inputPath, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const inputFile = path.resolve(args.inputPath);
    if (!fs.existsSync(inputFile)) {
      console.error(`Error: File not found: ${args.inputPath}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      const content = fs.readFileSync(inputFile, 'utf-8');
      jsonData = JSON.parse(content);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`Error: Failed to parse JSON: ${message}`);
      process.exit(1);
    }

    if (!validateReportData(jsonData)) {
      console.error(
        'Error: Invalid report data. Expected object with title (string), summary (string), and entries (array of {label: string, amount: number})'
      );
      process.exit(1);
    }

    const renderer = formatters[args.format];
    if (!renderer) {
      console.error(`Error: Unsupported format: ${args.format}`);
      process.exit(1);
    }

    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = renderer(jsonData, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
