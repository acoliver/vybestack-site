import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Determine if we're running in production (from dist) or development (from src)
const isProd = __dirname.endsWith('dist');
const basePath = isProd ? path.join(__dirname) : path.join(__dirname, '..');

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(basePath, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(basePath, 'templates'));

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
};

const validatePostalCode = (postal: string): boolean => {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postal);
};

// Database interface
let db: Database | null = null;
let saveDatabase: (() => void) | null = null;

// Initialize database
const initializeDatabase = async () => {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(basePath, 'data/submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    // Ensure data directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    let databaseBuffer: Uint8Array | undefined;
    
    // Load existing database if it exists
    if (fs.existsSync(dbPath)) {
      try {
        const fileContent = fs.readFileSync(dbPath);
        databaseBuffer = new Uint8Array(fileContent);
        console.log('Loaded existing database from file');
      } catch (error) {
        console.warn('Failed to read existing database file, creating new one:', error);
      }
    }
    
    // Create or open database
    db = new SQL.Database(databaseBuffer);
    
    // Run schema to ensure table exists
    const schemaPath = path.join(basePath, 'db/schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      const schemaStmt = db.prepare(schema);
      schemaStmt.run();
      schemaStmt.free();
      console.log('Database schema initialized');
    } else {
      // Fallback schema if file doesn't exist
      const fallbackSchema = `
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
      `;
      const fallbackStmt = db.prepare(fallbackSchema);
      fallbackStmt.run();
      fallbackStmt.free();
      console.log('Database schema initialized with fallback');
    }
    
    console.log('Database initialized successfully');
    
    // Save database function
    const saveDatabaseInternal = () => {
      try {
        const data = db!.export();
        fs.writeFileSync(dbPath, Buffer.from(data));
        console.log('Database saved to file');
      } catch (error) {
        console.error('Failed to save database:', error);
      }
    };
    
    saveDatabase = saveDatabaseInternal;
    
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
};

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: {},
    formData: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req, res) => {
  const { 
    firstName, 
    lastName, 
    streetAddress, 
    city, 
    stateProvince, 
    postalCode, 
    country, 
    email, 
    phone 
  } = req.body;

  const errors: Record<string, string> = {};

  // Validation
  if (!firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  if (!country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // If there are errors, re-render the form
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData: req.body,
      title: 'Friendly Contact Form - Please Fix Errors'
    });
  }

  // Save to database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        firstName?.trim(),
        lastName?.trim(),
        streetAddress?.trim(),
        city?.trim(),
        stateProvince?.trim(),
        postalCode?.trim(),
        country?.trim(),
        email?.trim(),
        phone?.trim()
      ]);
      
      stmt.free();
      saveDatabase!();
      console.log('Form submission saved to database');
    } catch (error) {
      console.error('Failed to save form submission:', error);
      // Continue anyway to user experience
    }
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('Received shutdown signal, closing server...');
  if (db) {
    db.close();
    console.log('Database closed');
  }
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const startServer = async () => {
  try {
    await initializeDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
