/**
 * Match words starting with the prefix but excluding banned words.
 * Returns an array of words that begin with the given prefix but are not in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match word boundaries and the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  const wordRegex = new RegExp('\\b' + escapedPrefix + '\\w+\\b', 'gi');

  const matches = text.match(wordRegex) || [];
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());

  // Filter out exceptions (case-insensitive)
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds to find tokens that are preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');

  // Find all occurrences where token is preceded by a digit and capture the full match
  const pattern = new RegExp('\\d' + escapedToken, 'g');
  const matches = Array.from(text.matchAll(pattern));

  // Return the full matches (digit + token)
  return matches.map(match => match[0]);
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
// Check for immediate repeated sequences (e.g., abab, abcabc, 1212)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatedPattern = new RegExp('(.{' + len + '})\\1', 'g');
    if (repeatedPattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 * Returns true if the string contains a valid IPv6 address, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude IPv4 addresses to avoid false positives
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIpv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressed form)
  const compressedIpv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with leading/trailing ::
  const edgeCompressedPattern = /\b::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b|[0-9a-fA-F]{1,4}::\b/;
  
  // IPv6 embedded IPv4 (like ::ffff:192.168.1.1)
  const ipv4EmbeddedPattern = /\b(?:[0-9a-fA-F]{1,4}:)*:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  return fullIpv6Pattern.test(value) || 
         compressedIpv6Pattern.test(value) || 
         edgeCompressedPattern.test(value) || 
         ipv4EmbeddedPattern.test(value);
}
