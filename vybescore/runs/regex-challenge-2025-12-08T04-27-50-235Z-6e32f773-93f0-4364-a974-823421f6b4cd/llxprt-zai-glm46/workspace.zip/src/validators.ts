export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Robust email validation supporting typical addresses.
 * Accepts name+tag@example.co.uk format, rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const [local, domain] = value.split('@');
  
  // Local part shouldn't start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Domain shouldn't contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain shouldn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation supporting common formats and optional +1 prefix.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's at least 10 digits (without country code)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Remove country code if present
  const withoutCountryCode = digitsOnly.startsWith('1') && digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Should be exactly 10 digits for US numbers
  if (withoutCountryCode.length !== 10) {
    return false;
  }
  
  // Area code shouldn't start with 0 or 1
  const areaCode = withoutCountryCode.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Argentine phone number validation covering mobile and landline formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other punctuation for validation
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Argentine phone number regex
// Optional +54 country code, optional 0 trunk prefix (no mobile indicator needed for validation)
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0?)([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, countryCode, trunkPrefix, areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}'\-\s]*[\p{L}\p{M}]$/u;
  
  // Check if it contains only allowed characters and doesn't start/end with space/hyphen/apostrophe
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Should not contain digits or symbols other than allowed ones
  if (/\d/.test(value) || /[!"#$%&()*+,.:;<=>?@[\\^_`{|}~]/.test(value)) {
    return false;
  }
  
  // Minimum length of 2 characters
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Credit card validation for Visa/Mastercard/AmEx with Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card format
  const isValidFormat = visaRegex.test(cleanNumber) || 
                        mastercardRegex.test(cleanNumber) || 
                        amexRegex.test(cleanNumber);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */