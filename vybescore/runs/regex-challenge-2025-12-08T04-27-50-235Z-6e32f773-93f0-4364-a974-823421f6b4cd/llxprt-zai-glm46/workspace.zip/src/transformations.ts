/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Sentences are separated by .?! punctuation and the function inserts exactly one space 
 * between sentences even if the input omitted it. Collapses extra spaces while 
 * preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Add space after sentence endings if missing
  normalized = normalized.replace(/([.!?])(?=\S)/g, '$1 ');

  // Split by sentence boundaries while preserving the punctuation
  const sentences = normalized.split(/([.!?]\s*)/);

  let result = '';
  let capitalizeNext = true;

  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];

    // If this is sentence-ending punctuation, add it as-is
    if (/[.!?]/.test(segment)) {
      result += segment;
      capitalizeNext = true;
    }
    // If this is whitespace, preserve it
    else if (/^\s+$/.test(segment)) {
      result += segment;
    }
    // If this is text content, capitalize if needed
    else if (segment && capitalizeNext) {
      result += segment.charAt(0).toUpperCase() + segment.slice(1);
      capitalizeNext = false;
    } else {
      result += segment;
    }
  }

  return result;
}

/**
 * Extract all URLs from the given text.
 * Returns an array of URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+/g;
  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades the scheme to https://. When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/([^\/]+)(\/[^\s]*)?/g, (match, host, path = '') => {
    // Always upgrade to https
    let newUrl = 'https://' + host + path;

    // Check if we should rewrite the host for docs
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints that should skip host rewrite
      const hasDynamicHints = /\/cgi-bin\/|[?&=]|(\/.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);

      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com format
        newUrl = 'https://docs.' + host + path;
      }
    }

    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns the four-digit year or 'N/A' if the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);

  // Validate month and day ranges
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }

  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = monthNum === 2 && isLeapYear(parseInt(year, 10)) 
    ? 29 
    : daysInMonth[monthNum - 1];

  if (dayNum < 1 || dayNum > maxDays) {
    return 'N/A';
  }

  return year;
}

/**
 * Helper function to check if a year is a leap year
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}