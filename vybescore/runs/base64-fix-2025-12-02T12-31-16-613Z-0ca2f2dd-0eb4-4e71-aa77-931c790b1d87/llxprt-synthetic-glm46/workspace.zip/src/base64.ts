

/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Basic validation: check for non-Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Remove whitespace that might be present
  const sanitized = input.replace(/\s/g, '');
  
  // Additional validation: check length modulo 4 (with allowance for missing padding)
  const adjustedLength = sanitized.length;
  const remainder = adjustedLength % 4;
  
  // Add missing padding if needed (at most 2 padding chars)
  const paddedInput = remainder !== 0 ? sanitized + '='.repeat(4 - remainder) : sanitized;
  
  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
