/**
 * Validate that the input contains only valid Base64 characters
 */
function validateBase64Characters(input: string): void {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
}

/**
 * Validate that padding characters are in the correct position
 */
function validateBase64Padding(input: string): void {
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    const afterPadding = input.slice(paddingIndex + 1);
    // After the first '=', everything should be '=' characters
    if (afterPadding.match(/[^=]/)) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
  }
}

/**
 * Validate that the decoded result represents valid Base64 by round-trip testing
 */
function validateBase64RoundTrip(decoded: string, originalInput: string): void {
  const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
  
  // Compare the re-encoded result with our padded input (without padding differences)
  const originalWithoutPadding = originalInput.replace(/=+$/, '');
  const reEncodedWithoutPadding = reEncoded.replace(/=+$/, '');
  
  if (originalWithoutPadding !== reEncodedWithoutPadding) {
    throw new Error('Invalid Base64 input: round-trip validation failed');
  }
}

/**
 * Encode plain text to Base64 using standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  validateBase64Characters(input);
  validateBase64Padding(input);

  // For Base64 without padding, we need to add padding to make it work with Buffer.from
  let paddedInput = input;
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  if (paddingNeeded > 0) {
    paddedInput = input + '='.repeat(paddingNeeded);
  }

  try {
    const decoded = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Validate that the Base64 input actually produces valid UTF-8
    if (!decoded || decoded.length === 0) {
      throw new Error('Invalid Base64 input: decoded to empty or invalid UTF-8');
    }
    
    validateBase64RoundTrip(decoded, paddedInput);
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}