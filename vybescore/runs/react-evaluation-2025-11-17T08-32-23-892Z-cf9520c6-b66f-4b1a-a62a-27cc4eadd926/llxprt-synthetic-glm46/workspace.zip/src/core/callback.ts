/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerCallback } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let active = true
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Execute the initial callback
  updateObserver(observer)
  
  // Register in the global callback registry
  const unregister = registerCallback(observer)
  
  const unsubscribe = () => {
    if (!active) return
    active = false
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value as T
    
    // Unregister from the global registry
    unregister()
  }
  
  return unsubscribe
}