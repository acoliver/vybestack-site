/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set()
  }

  const computedFn: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    
    // If we're being called by another observer, register dependency
    if (observer && o.observers && observer !== o) {
      o.observers.add(observer)
    }
    
    // Update our value on access
    if (getActiveObserver() !== o) {
      updateObserver(o)
    }
    
    return o.value!
  }
  
  return computedFn
}