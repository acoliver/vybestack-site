/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyCallbacks,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? ((a, b) => a === b) as EqualFn<T>
    : equal === false || equal === undefined
    ? undefined
    : equal as EqualFn<T>

  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observers) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.equalFn ? !s.equalFn(s.value, nextValue) : true
    if (shouldUpdate) {
      s.value = nextValue
      
      // Notify all observers that depend on this input
      if (s.observers) {
        for (const observer of s.observers) {
          // Update the observer (computed or callback)
          observer.value = observer.updateFn(observer.value)
        }
      }
      
      // Also notify all callbacks
      notifyCallbacks()
    }
    return s.value
  }

  return [read, write]
}