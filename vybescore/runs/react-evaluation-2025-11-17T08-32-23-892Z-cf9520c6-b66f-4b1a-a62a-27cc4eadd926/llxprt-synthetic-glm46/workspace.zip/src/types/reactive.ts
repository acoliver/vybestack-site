/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

interface ObserverR {
  name?: string
}

interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface Observer<T> extends ObserverR, ObserverV<T> {
  callback?: () => void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  observers?: Set<Observer<any>>
}

interface SubjectR {
  name?: string
}

interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  observers?: Set<Observer<any>>
}

export interface Subject<T> extends SubjectR, SubjectV<T> {}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let activeObserver: Observer<any> | undefined

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  activeObserver = observer as any
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry for all callbacks so we can notify them when anything changes
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const callbackRegistry = new Set<Observer<any>>()

export function registerCallback<T>(observer: Observer<T>) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  callbackRegistry.add(observer as any)
  return () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    callbackRegistry.delete(observer as any)
  }
}

export function notifyCallbacks(): void {
  // Notify all callback observers
  for (const observer of callbackRegistry) {
    if (activeObserver !== observer) {
      updateObserver(observer)
    }
  }
}