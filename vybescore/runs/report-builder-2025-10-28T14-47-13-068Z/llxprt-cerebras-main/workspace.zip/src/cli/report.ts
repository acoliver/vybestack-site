import { readFile } from 'fs/promises';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map of supported formats to their render functions
const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText
};

async function main() {
  const args = process.argv.slice(2);
  
  // Parse arguments
  let dataFile: string | undefined;
  let format: string | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[++i];
    } else if (arg === '--output') {
      outputFile = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!dataFile) {
      dataFile = arg;
    }
  }
  
  // Validate required arguments
  if (!dataFile) {
    console.error('Error: Data file is required');
    process.exit(1);
  }
  
  if (!format) {
    console.error('Error: Format is required');
    process.exit(1);
  }
  
  if (!formatRenderers[format as keyof typeof formatRenderers]) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }
  
  try {
    // Read and parse data file
    const dataContent = await readFile(dataFile, 'utf-8');
    const data: ReportData = JSON.parse(dataContent);
    
    // Validate data structure
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      console.error('Error: Invalid data structure in JSON file');
      process.exit(1);
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        console.error('Error: Invalid entry structure in JSON file');
        process.exit(1);
      }
    }
    
    // Render report
    const renderer = formatRenderers[format as keyof typeof formatRenderers];
    const output = renderer(data, { includeTotals });
    
    // Output result
    if (outputFile) {
      await writeFile(outputFile, output);
      console.log(`Report written to ${outputFile}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Failed to parse JSON file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: ${error}`);
    }
    process.exit(1);
  }
}

// Import writeFile from fs/promises inside the function to avoid top-level await
async function writeFile(path: string, content: string) {
  const { writeFile } = await import('fs/promises');
  await writeFile(path, content);
}

main();