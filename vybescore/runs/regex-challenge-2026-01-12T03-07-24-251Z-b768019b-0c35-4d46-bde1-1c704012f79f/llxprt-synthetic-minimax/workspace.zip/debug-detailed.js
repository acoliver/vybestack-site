// Detailed debug of isStrongPassword function
const testPassword = 'Abcdef!234';

console.log('=== DEBUGGING isStrongPassword ===');
console.log('Test password:', testPassword);
console.log('Length check:');
console.log('  !value:', !testPassword);
console.log('  length < 10:', testPassword.length < 10);
console.log('  length:', testPassword.length);

console.log('\nWhitespace check:');
console.log('  Has whitespace:', /\s/.test(testPassword));

console.log('\nUppercase check:');
console.log('  Has uppercase:', /[A-Z]/.test(testPassword));

console.log('\nLowercase check:');
console.log('  Has lowercase:', /[a-z]/.test(testPassword));

console.log('\nDigit check:');
console.log('  Has digit:', /\d/.test(testPassword));

console.log('\nSymbol check:');
const symbolPattern = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\?]/.test(testPassword);
console.log('  Symbol pattern matches:', symbolPattern);

console.log('\nAlternating pattern check:');
const lowerValue = testPassword.toLowerCase();
console.log('  Lowercase value:', lowerValue);

let hasAlternating = false;
for (let i = 0; i < lowerValue.length - 3; i++) {
  const pattern = lowerValue.slice(i, i + 2);
  const following = lowerValue.slice(i + 2, i + 4);
  console.log(`  Position ${i}: '${pattern}' vs '${following}'`);
  if (pattern === following) {
    hasAlternating = true;
    console.log('    FOUND ALTERNATING PATTERN!');
    break;
  }
}

console.log('\n=== RESULTS ===');
console.log('All conditions:');
console.log('  Length >= 10:', testPassword.length >= 10);
console.log('  No whitespace:', !/\s/.test(testPassword));
console.log('  Has uppercase:', /[A-Z]/.test(testPassword));
console.log('  Has lowercase:', /[a-z]/.test(testPassword));
console.log('  Has digit:', /\d/.test(testPassword));
console.log('  Has symbol:', symbolPattern);
console.log('  No alternating pattern:', !hasAlternating);

const finalResult = testPassword.length >= 10 && 
                   !/\s/.test(testPassword) && 
                   /[A-Z]/.test(testPassword) && 
                   /[a-z]/.test(testPassword) && 
                   /\d/.test(testPassword) && 
                   symbolPattern && 
                   !hasAlternating;

console.log('Final result:', finalResult);

// Test individual character class elements
console.log('\n=== INDIVIDUAL SYMBOL TESTS ===');
const symbols = ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '-', '=', '[', ']', '{', '}', ';', ':', "'", '"', '\\', '|', ',', '.', '<', '>', '?', '/'];
symbols.forEach(sym => {
  const matches = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\?]/.test(sym);
  if (matches) {
    console.log(`  Symbol '${sym}' matches: ${matches}`);
  }
});

// Most importantly, test exclamation directly
console.log('\n=== DIRECT EXCLAMATION TESTS ===');
console.log('! in character class:', /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\?]/.test('!'));
console.log('Direct ! test:', /!/.test(testPassword));