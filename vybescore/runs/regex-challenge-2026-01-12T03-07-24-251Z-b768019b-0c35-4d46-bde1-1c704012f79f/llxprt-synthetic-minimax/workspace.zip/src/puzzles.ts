/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Pattern to match words starting with prefix
  // Using word boundaries to match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Find all occurrences where token appears after a digit and not at string start
  const results: string[] = [];
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a more specific pattern to match digit followed by token
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Return the full match (digit + token)
    results.push(match[0]);
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab)
  // Check for alternating patterns
  const lowerValue = value.toLowerCase();
  for (let i = 0; i < lowerValue.length - 3; i++) {
    const pattern = lowerValue.slice(i, i + 2);
    const following = lowerValue.slice(i + 2, i + 4);
    if (pattern === following) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // Pattern to match IPv6 addresses including shorthand notation
  // Look for patterns like 2001:db8::1
  const ipv6Pattern = /(?:^|[^0-9a-fA-F:])((?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})(?::[0-9a-fA-F]{1,4})*(?::[0-9a-fA-F]{0,4})?(?=$|[^0-9a-fA-F:])/;
  
  return ipv6Pattern.test(value);
}
