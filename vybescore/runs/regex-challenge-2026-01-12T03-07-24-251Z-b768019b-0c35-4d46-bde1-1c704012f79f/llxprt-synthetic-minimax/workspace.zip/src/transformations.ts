/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, let's ensure proper spacing by collapsing multiple spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to match sentence endings followed by spaces and next sentence
  // Look for .?! followed by (optional spaces) and a lowercase letter
  const sentenceEndPattern = /([.!?])(?:\s*)([a-z])/g;
  
  result = result.replace(sentenceEndPattern, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  // Also handle the case where first character is lowercase
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Pattern to match URLs, capture them without trailing punctuation
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlPattern);
  if (!matches) return [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation while preserving valid URL characters
    return url.replace(/[.,!?;:\s]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// while preserving existing https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match URLs starting with http:// and capture everything after the host
  const urlPattern = /http:\/\/([^/\s]+)(.*)/gi;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    // Always upgrade the scheme to https://
    let newUrl = `https://${host}`;
    
    // Check if path begins with /docs/ and doesn't have dynamic hints
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints in the path
      const hasDynamicHints = /(\?|=|&)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (!hasDynamicHints) {
        // Extract domain from host and prefix with docs.
        const domain = host.includes('.') ? host.split('.').slice(-2).join('.') : host;
        newUrl = `https://docs.${domain}${path}`;
      } else {
        newUrl = `https://${host}${path}`;
      }
    } else {
      newUrl = `https://${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, accounting for month length would be more complex but let's keep it simple)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year as string
  return year.toString();
}
