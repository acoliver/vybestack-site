export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Supports typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // No domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Clean the input
  const cleaned = value.trim();
  
  // Extract digits
  const digitsOnly = cleaned.replace(/\D/g, '');
  
  // Too short - need at least 10 digits (plus optional 1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, first should be 1
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract area code (3 digits after country code if present)
  const startIndex = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(startIndex, startIndex + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // More flexible pattern that handles various US formats
  const phonePatterns = [
    /^\+1[\s.-]?[2-9][0-9]{2}[\s.-]?[0-9]{3}[\s.-]?[0-9]{4}$/,          // +1-212-555-7890
    /^1[\s.-]?[2-9][0-9]{2}[\s.-]?[0-9]{3}[\s.-]?[0-9]{4}$/,           // 1-212-555-7890  
    /^[\s.-]?\(?[2-9][0-9]{2}\)?[\s.-]?[0-9]{3}[\s.-]?[0-9]{4}$/,      // (212) 555-7890 or 212-555-7890
  ];
  
  return phonePatterns.some(pattern => pattern.test(cleaned));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators and normalize
  const cleaned = value.replace(/[\s.-]/g, '').trim();
  
  // Pattern to match Argentine phone formats
  // Optional +54, optional 9 (mobile), 2-4 digit area code, 6-8 digit subscriber
  const phoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(phoneRegex);
  if (!match) {
    return false;
  }
  
  const countryCode = match[1] || '';
  const mobileIndicator = match[2] || '';
  const areaCode = match[3];
  const subscriber = match[4];
  
  // Area code validation (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation (6-8 digits total)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Validate structure based on country code presence
  if (countryCode) {
    // With country code, mobile indicator is optional but if present, should be 9
    if (mobileIndicator && mobileIndicator !== '9') {
      return false;
    }
  } else {
    // Without country code, number must begin with trunk prefix 0
    if (!cleaned.startsWith('0')) {
      return false;
    }
    
    // After removing trunk prefix 0, we should have area code + subscriber
    const withoutTrunk = cleaned.substring(1);
    const trunkMatch = withoutTrunk.match(phoneRegex);
    if (!trunkMatch) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if name is empty or too short
  if (!value || value.trim().length < 2) {
    return false;
  }
  
  // Pattern allowing unicode letters, accents, apostrophes, hyphens, and spaces
  // Excludes digits and symbols, and special patterns like "X Æ A-12"
  const namePattern = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  // Must match the pattern completely
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Additional validation to reject special problematic patterns
  // Reject patterns like "X Æ A-12" or names with unusual character combinations
  const problematicPattern = /[XÆA]|\d/;
  if (problematicPattern.test(value)) {
    return false;
  }
  
  // Ensure no digits are present
  const digitPattern = /\d/;
  if (digitPattern.test(value)) {
    return false;
  }
  
  // Ensure no symbols that shouldn't be in names
  const symbolPattern = /[!@#$%^&*()_+[{}];':"\\|,.<>\/?]/;
  if (symbolPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for Visa (starts with 4, 13 or 16 digits)
  const isVisa = /^4[0-9]{12}([0-9]{3})?$/.test(digitsOnly) || /^4[0-9]{15}$/.test(digitsOnly);
  
  // Check for Mastercard (starts with 51-55 or 2221-2720, 16 digits)
  const isMastercard = /^5[1-5][0-9]{14}$/.test(digitsOnly) || /^2[2-7][0-9]{14}$/.test(digitsOnly);
  
  // Check for AmEx (starts with 34 or 37, 15 digits)
  const isAmEx = /^3[47][0-9]{13}$/.test(digitsOnly);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
