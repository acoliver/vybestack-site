// Debug the isStrongPassword function
const testPassword = 'Abcdef!234';

console.log('Testing password:', testPassword);
console.log('Length:', testPassword.length);
console.log('Has uppercase:', /[A-Z]/.test(testPassword));
console.log('Has lowercase:', /[a-z]/.test(testPassword));
console.log('Has digit:', /\d/.test(testPassword));

// Test the current symbol pattern
const symbolPattern = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\?]/.test(testPassword);
console.log('Current symbol pattern matches:', symbolPattern);

// Test a simpler exclamation pattern
console.log('Has exclamation:', testPassword.includes('!'));
console.log('Exclamation matches:', /[!]/.test(testPassword));

// Test the complete symbol character class step by step
const testChar = '!';
console.log('Testing character:', testChar);
console.log('In character class:', /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\?]/.test(testChar));

// Check if the character class is correctly escaped
console.log('Direct exclamation test:', /!/.test(testPassword));