// Test edge cases for all implemented functions
import * as functions from './dist/src/index.js';

console.log('=== TESTING EDGE CASES ===\n');

// Test Validators
console.log('=== VALIDATORS ===');

console.log('1. isValidEmail:');
const emailTests = [
  'user@example.com',           // Standard
  'name+tag@example.co.uk',     // Plus and UK domain
  'user@@example..com',         // Should fail
  'user@example..com',          // Should fail (double dot)
  'user@',                      // Should fail (incomplete)
  'user@domain_with_underscore.com' // Should fail (underscore)
];
emailTests.forEach(email => {
  console.log(`  "${email}" -> ${functions.validators.isValidEmail(email)}`);
});

console.log('\n2. isValidUSPhone:');
const phoneTests = [
  '212-555-7890',              // Standard
  '(212) 555-7890',           // With parentheses
  '212-555-7890',             // Dash separator
  '2125557890',               // No separators
  '+1 212-555-7890',          // With country code
  '02-555-7890',              // Should fail (area code starts with 0)
  '123-456-7890',             // Should fail (area code starts with 1)
  '555'                       // Should fail (too short)
];
phoneTests.forEach(phone => {
  console.log(`  "${phone}" -> ${functions.validators.isValidUSPhone(phone)}`);
});

console.log('\n3. isValidArgentinePhone:');
const argPhoneTests = [
  '+54 9 11 1234 5678',       // Mobile format
  '011 1234 5678',            // Landline format
  '+54 341 123 4567',         // Regional mobile
  '0341 4234567',             // Regional landline
  '+54 341 123 456',          // Should fail (too short subscriber)
  '341 123 45678'             // Should fail (missing trunk prefix)
];
argPhoneTests.forEach(phone => {
  console.log(`  "${phone}" -> ${functions.validators.isValidArgentinePhone(phone)}`);
});

console.log('\n4. isValidName:');
const nameTests = [
  'Jane Doe',                 // Standard
  'José María García',        // With accents
  'O\'Connor-Smith',          // Apostrophe and hyphen
  'X Æ A-12',                 // Should fail (problematic)
  'User123',                  // Should fail (digits)
  'Dr. Smith',                // Should pass (dots allowed)
  'Name with 123 numbers',    // Should fail (contains numbers)
  ''                          // Should fail (empty)
];
nameTests.forEach(name => {
  console.log(`  "${name}" -> ${functions.validators.isValidName(name)}`);
});

console.log('\n5. isValidCreditCard:');
const ccTests = [
  '4111111111111111',         // Visa
  '5555555555554444',         // Mastercard  
  '378282246310005',          // AmEx
  '1234567890123456',         // Should fail (invalid prefix/Luhn)
  '4111'                      // Should fail (too short)
];
ccTests.forEach(cc => {
  console.log(`  "${cc}" -> ${functions.validators.isValidCreditCard(cc)}`);
});

// Test Transformations
console.log('\n\n=== TRANSFORMATIONS ===');

console.log('6. capitalizeSentences:');
const sentenceTests = [
  'hello world. this is a test.',
  'no spaces.before punctuation',
  'multiple  spaces  between  words',
  'UPPERCASE.ALREADY.FORMATTED',
  ''
];
sentenceTests.forEach(text => {
  const result = functions.transformations.capitalizeSentences(text);
  console.log(`  "${text}" -> "${result}"`);
});

console.log('\n7. extractUrls:');
const urlTests = [
  'Visit https://example.com for more info.',
  'Check out www.example.com or http://old-site.com/path',
  'No URLs here.',
  'Multiple: https://site1.com http://site2.com, also www.site3.org.',
  'URL with punctuation: https://example.com/path?query=true.'
];
urlTests.forEach(text => {
  const result = functions.transformations.extractUrls(text);
  console.log(`  "${text}" -> [${result.map(u => `"${u}"`).join(', ')}]`);
});

console.log('\n8. enforceHttps:');
const httpsTests = [
  'Visit http://example.com and https://secure-site.com',
  'http://site1.com and http://site2.org both',
  'All https://already.secure.org',
  'No URLs here'
];
httpsTests.forEach(text => {
  const result = functions.transformations.enforceHttps(text);
  console.log(`  "${text}" -> "${result}"`);
});

console.log('\n9. rewriteDocsUrls:');
const docsTests = [
  'Visit http://example.com/docs/api/v1 for docs',
  'Docs at http://site.org/docs/guide and regular at http://site.org/home',
  'Query docs: http://example.com/docs/page?dynamic=true should not rewrite host',
  'Legacy docs: http://example.com/docs/page.jsp should not rewrite host'
];
docsTests.forEach(text => {
  const result = functions.transformations.rewriteDocsUrls(text);
  console.log(`  "${text}" -> "${result}"`);
});

console.log('\n10. extractYear:');
const yearTests = [
  '12/25/2023',
  '01/01/2020',
  '13/45/2021',  // Invalid month/day
  'not a date',
  '2023-12-25', // Wrong format
  '1/1/99'      // 2-digit year
];
yearTests.forEach(text => {
  const result = functions.transformations.extractYear(text);
  console.log(`  "${text}" -> "${result}"`);
});

// Test Puzzles
console.log('\n\n=== PUZZLES ===');

console.log('11. findPrefixedWords:');
const prefixTests = [
  ['preview prevent prefix exceptional', 'pre', ['prevent']],
  ['disallowed disconnect', 'dis', ['disallowed']]
];
prefixTests.forEach(([text, prefix, exceptions]) => {
  const result = functions.puzzles.findPrefixedWords(text, prefix, exceptions);
  console.log(`  "${text}" with prefix "${prefix}" except [${exceptions.join(', ')}] -> [${result.join(', ')}]`);
});

console.log('\n12. findEmbeddedToken:');
const tokenTests = [
  ['xfoo 1foo foo2bar token', 'foo'],
  ['123abc abcdef token', 'abc'],
  ['starttoken notembedded', 'token']
];
tokenTests.forEach(([text, token]) => {
  const result = functions.puzzles.findEmbeddedToken(text, token);
  console.log(`  "${text}" looking for "${token}" -> [${result.join(', ')}]`);
});

console.log('\n13. isStrongPassword:');
const passwordTests = [
  'Abcdef!234',               // Should pass (public test case)
  'short',                    // Should fail (too short)
  'NoNumbersOrSymbols!',      // Should fail (no digits/symbols)
  'nouppercase123!',          // Should fail (no uppercase)
  'NOSYMBOLS123',             // Should fail (no symbols)
  'ValidPass123!',            // Should pass
  'Patternpattern123!'        // Should fail (alternating pattern)
];
passwordTests.forEach(pwd => {
  const result = functions.puzzles.isStrongPassword(pwd);
  console.log(`  "${pwd}" -> ${result}`);
});

console.log('\n14. containsIPv6:');
const ipv6Tests = [
  'Address: 2001:db8::1',     // Should pass
  'IPv4: 192.168.1.1',        // Should fail (IPv4)
  'Normal text only',         // Should fail
  'IPv6 with shorthand: ::1',   // Should pass
  'Multiple addresses: ::1 192.168.1.1' // Mixed
];
ipv6Tests.forEach(text => {
  const result = functions.puzzles.containsIPv6(text);
  console.log(`  "${text}" -> ${result}`);
});

console.log('\n=== ALL TESTS COMPLETED ===');