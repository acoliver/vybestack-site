// Fix password validation
const fs = require('fs');

let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Fix the character class and repeated sequence regex on lines 104-106
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('Check for at least one symbol')) {
    // Replace the next line (i+1) with corrected regex using RegExp
    lines[i+1] = "  if (!/[!@#$%^&*()_+\\-=\\[\\]{}\';\":|,.<>\\/]/.test(value)) return false;";
  }
  
  if (lines[i].includes('repeatedSequenceRegex =')) {
    // Fix the backreference in the regex
    lines[i] = "  const repeatedSequenceRegex = /(.{2,4})\\1/;";
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed password validation');