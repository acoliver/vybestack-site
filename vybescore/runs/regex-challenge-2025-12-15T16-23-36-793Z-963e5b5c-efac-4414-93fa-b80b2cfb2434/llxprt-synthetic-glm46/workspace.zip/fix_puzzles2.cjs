// This is a script to fix line 104 in puzzles.ts
const fs = require('fs');
const filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';

// Read the file
let content = fs.readFileSync(filePath, 'utf8');

// Get all lines
let lines = content.split('\n');

// Replace line 104 specifically (index 103)
lines[103] = '  if (!/[!@#$%^&*()_+\\-=\\[\\]{}\';":\\|,.<>\\/]/.test(value)) return false;';

// Join back together
content = lines.join('\n');

// Write back to file
fs.writeFileSync(filePath, content);
console.log('Fixed line 104 in puzzles.ts (attempt 2)');