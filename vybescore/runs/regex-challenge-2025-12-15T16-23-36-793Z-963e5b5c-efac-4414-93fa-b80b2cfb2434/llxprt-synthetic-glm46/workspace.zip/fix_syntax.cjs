// Fix remaining syntax errors
const fs = require('fs');

// Fix transformations.ts syntax issue around line 75
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
let content = fs.readFileSync(filePath, 'utf8');

// Find and fix the issue around line 75
content = content.replace(/\n}\n    return url\.replace.*\n  \}\);\n  \n/, '\n  });\n\n');

fs.writeFileSync(filePath, content);

// Fix validators.ts missing closing brace
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');

// Add missing closing brace at the end
if (!content.trim().endsWith('}')) {
  content += '\n}';
}

fs.writeFileSync(filePath, content);

console.log('Fixed syntax errors');