// Test if 'Abcdef!234' matches our symbol regex
const regex = /[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/]/;
console.log('Matches symbol:', regex.test('Abcdef!234'));

// Test the repeated sequence regex  
const repeatedSequenceRegex = /(.{2,4})\1/;
console.log('Test repeated pattern:', repeatedSequenceRegex.test('Abcdef!234'));

// Test keyboard patterns
const keyboardPatterns = ['qwerty', 'asdf', 'zxcv', '1234', 'abcd'];
const containsKeyboard = keyboardPatterns.some(pattern => 'Abcdef!234'.toLowerCase().includes(pattern));
console.log('Contains keyboard pattern:', containsKeyboard);

console.log('Length:', 'Abcdef!234'.length);
console.log('Has uppercase:', /[A-Z]/.test('Abcdef!234'));
console.log('Has lowercase:', /[a-z]/.test('Abcdef!234'));
console.log('Has digit:', /\d/.test('Abcdef!234'));