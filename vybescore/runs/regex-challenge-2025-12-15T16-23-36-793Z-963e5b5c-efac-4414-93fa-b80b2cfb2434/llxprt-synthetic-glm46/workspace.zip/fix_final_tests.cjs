// Fix the final two failing tests
const fs = require('fs');

// Fix the IPv6 detection in puzzles.ts
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');

// Replace the entire containsIPv6 function with a simpler, more robust implementation
const newContainsIPv6 = `
/**
 * Detects IPv6 addresses (including shorthand ::)
 * Ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Clean up whitespace for validation
  const cleanValue = value.trim();
  
  // IPv4 detection regex - make sure we don't match these
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If it's a clean IPv4 address, return false
  if (ipv4Regex.test(cleanValue)) return false;
  
  // IPv6 patterns
  
  // Full IPv6 pattern: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Shorthand IPv6 with :: compression
  const shorthandRegex = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;
  
  // Edge case: just :: (all zeros)
  const doubleColonOnlyRegex = /^::$/;
  
  // Edge case: IPv6 with :: at end or beginning
  const endWithShorthand = /^[0-9a-fA-F:]*::$/;
  const startWithShorthand = /^::[0-9a-fA-F:]*$/;
  
  // Test all patterns
  if (fullIpv6Regex.test(cleanValue)) return true;
  if (doubleColonOnlyRegex.test(cleanValue)) return true;
  if (shorthandRegex.test(cleanValue)) return true;
  if (endWithShorthand.test(cleanValue)) return true;
  if (startWithShorthand.test(cleanValue)) return true;
  
  // One more pattern for IPv6 with fewer than 8 groups
  const partialIpv6Regex = /^[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4}){1,7}$/;
  if (partialIpv6Regex.test(cleanValue)) return true;
  
  // No IPv6 detected
  return false;
}`;

// Replace the containsIPv6 function
const lines = content.split('\n');
let startIndex = -1;
let endIndex = -1;

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('export function containsIPv6')) {
    startIndex = i;
  }
  if (startIndex >= 0 && lines[i].trim() === '}' && lines[i+1]?.includes('export')) {
    endIndex = i;
    break;
  }
}

if (startIndex >= 0 && endIndex >= 0) {
  lines.splice(startIndex, endIndex - startIndex + 1, ...newContainsIPv6.trim().split('\n'));
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix the sentence capitalization in transformations.ts
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
content = fs.readFileSync(filePath, 'utf8');

// Fix the capitalizeSentences function
const newCapitalizeSentences = `
/**
 * Capitalizes the first character of each sentence
 * After punctuation marks (., ?, !), capitalizes the next letter
 * Collapses multiple spaces while preserving proper sentence structure
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Split by sentence boundaries while keeping the punctuation
  const sentences = text.split(/([.!?])/);
  
  // Process sentence pairs (text and punctuation)
  const result = [];
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (!part) continue;
    
    if (/[.!?]/.test(part)) {
      // This is punctuation, add it and ensure single space after
      result.push(part);
      capitalizeNext = true;
    } else {
      // This is text, capitalize first letter if needed
      let processedPart = part.trim();
      if (processedPart && capitalizeNext) {
        processedPart = processedPart.charAt(0).toUpperCase() + processedPart.slice(1);
        capitalizeNext = false;
      }
      result.push(processedPart);
    }
  }
  
  return result.join(' ').replace(/\\s+/g, ' ').trim();
}`;

// Replace the capitalizeSentences function
lines = content.split('\n');
startIndex = -1;
endIndex = -1;

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('export function capitalizeSentences')) {
    startIndex = i;
  }
  if (startIndex >= 0 && lines[i].trim() === '}' && lines[i+1]?.includes('export')) {
    endIndex = i;
    break;
  }
}

if (startIndex >= 0 && endIndex >= 0) {
  lines.splice(startIndex, endIndex - startIndex + 1, ...newCapitalizeSentences.trim().split('\n'));
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed final test issues');