// Fix remaining lint issues with proper string handling
const fs = require('fs');

// Fix puzzles.ts escape characters
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Find and replace the problematic line directly
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('Check for at least one symbol')) {
    // Replace the next line with a fixed version using string concatenation
    lines[i+1] = '  if (!/[!@#$%^&*()_+=\\-\\[\\]{};\\\'":|,.<>\\/]/.test(value)) return false;';
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix validators.ts escape characters
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');

// Find and fix the phoneRegex line
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('phoneRegex = /^(?:\\+?1)')) {
    // Fix the regex by removing unnecessary escapes
    lines[i] = "  const phoneRegex = /^(?:\\+?1)?(?:\\s*|\\-)?\\(?([2-9]\\d{2})\\)?(?:\\s*|\\-)?([2-9]\\d{2})(?:\\s*|\\-)?(\\d{4})$/;";
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed final lint issues (attempt 2)');