// Final fix for escape characters
const fs = require('fs');

// Fix puzzles.ts line 104
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Fix line 104 - In character class, \ doesn't need escaping unless it's at end
lines[103] = '  if (!/[!@#$%^&*()_+\\-=[\\]{}\';":|,.<>\\/]/.test(value)) return false;';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix transformations.ts line 101
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');
lines[100] = '  const urlRegex = /(https?:\\/\\/)([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})(\\/[a-zA-Z0-9._\\/~?%\\-#&=+;@]*)?/g;';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed final escape characters');