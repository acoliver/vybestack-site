// Fix IPv6 pattern by using RegExp constructor with escaped strings
const fs = require('fs');

let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Fix the IPv6 patterns by replacing the problematic line
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('embeddedMixedPattern')) {
    // Replace with a proper regex using RegExp constructor
    lines[i] = "  const embeddedMixedPattern = new RegExp('(?:^|[^0-9a-fA-F:])((?:[0-9a-fA-F]{1,4}:){1,6}:[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})(?![0-9a-fA-F.:])');";
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed IPv6 pattern');