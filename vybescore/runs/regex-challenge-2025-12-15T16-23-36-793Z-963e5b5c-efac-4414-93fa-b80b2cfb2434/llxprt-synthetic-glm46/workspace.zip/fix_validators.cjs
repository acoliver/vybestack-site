// Fix phoneRegex not defined error in validators.ts
const fs = require('fs');
const filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';

// Read the file
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Find line 88 and replace the broken comment with phoneRegex definition
// Lines 88-90 currently are:
// // +1(212)555-7890
// // Enhanced domain validation: no double dots, no trailing dots, no underscores
// return phoneRegex.test(value.trim());

// Replace them with proper phoneRegex definition and return statement
lines[87] = '  // +1(212)555-7890';
lines[88] = '  const phoneRegex = /^(?:\\+?1)?(?:\\s*|\\-)?\\(?([2-9]\\d{2})\\)?(?:\\s*|\\-)?([2-9]\\d{2})(?:\\s*|\\-)?(\\d{4})$/;';
lines[89] = '  return phoneRegex.test(value.trim());';

// Remove the extra line that was added
lines.splice(90, 1);

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed phoneRegex not defined error');