// Fix remaining escape character issues
const fs = require('fs');

// Fix puzzles.ts
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Fix line 104 - properly escape regex character class
lines[103] = '  if (!/[!@#$%^&*()_+\\-=\\[\\]{}\';":|,.<>\\/]/.test(value)) return false;';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix transformations.ts
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');

// Fix line 101
lines[100] = '  const urlRegex = /(https?:\\/\\/)([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})(\\/[a-zA-Z0-9._\\/~?%\\-#&=+;@]*)?/g;';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix validators.ts
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');

// Fix lines 89 and 179
lines[88] = '    // Enhanced domain validation: no double dots, no trailing dots, no underscores';
lines[178] = '  // Validate check digit using the Luhn algorithm';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed all remaining escape character issues');