// Fix remaining test errors
const fs = require('fs');

// Fix the regex range error in transformations.ts
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
let content = fs.readFileSync(filePath, 'utf8');

// Look for the problematic line with "Range out of order in character class"
// This happens when there's a pattern like [z-a] instead of [a-z]
const badPattern = '\\[a-zA-Z0-9\\._\\\\/~?%\\-#&=+;@\\]';
const goodPattern = '[a-zA-Z0-9._/~?#&=+;@]';
content = content.replace(new RegExp(badPattern, 'g'), goodPattern);

fs.writeFileSync(filePath, content);

// Fix the password immediate repeats in puzzles.ts
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
content = fs.readFileSync(filePath, 'utf8');

// Check for immediate repeated sequences (e.g., abab, abcabc)
// This should look for any sequence of 2-4 characters that repeats immediately
// Let's add the correct regex pattern after line 104
let lines = content.split('\n');
let insertIndex = -1;

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('Check for immediate repeated sequences')) {
    insertIndex = i + 1;
    break;
  }
}

if (insertIndex > 0) {
  // Insert the proper repeated sequence check
  lines.splice(insertIndex, 0, '  // This regex looks for any sequence of 2-4 characters that repeats immediately');
  lines.splice(insertIndex + 1, 0, '  if (/(.{2,4})\\1/.test(value)) return false;');
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Also fix the isStrongPassword function issues - we had an OR condition that was invalid
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('value.indexOf(\'/\') === -1)')) {
    lines[i] = lines[i].replace('|| value.indexOf(\'/\') === -1', '|| value.indexOf(\'/\') >= 0');
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix the email validation in validators.ts - we're missing emailRegex
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');

// Find and fix email validation
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('return emailRegex.test')) {
    // Need to define emailRegex before this line
    lines.splice(i, 0, '  const emailRegex = /^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;');
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed remaining test errors');