// Fix urlRegex not defined error in transformations.ts
const fs = require('fs');
const filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';

// Read the file
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Find where urlRegex is used without being defined, around line 65
// We need to add the urlRegex definition before it's used
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('text.match(urlRegex)')) {
    // Insert urlRegex definition before this line
    lines.insert = [
      '  const urlRegex = /(?:https?:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\']+|(?:https?:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\']+[\\w\\/-]/gi;'
    ];
    break;
  }
}

// Actually, let's replace the content in the function for extractUrls
let newExtractUrls = `export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex to match URLs
  const urlRegex = /(?:https?:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\']+|(?:https?:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\']+[\\w\\/-]/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches - remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like . , ; : ? ! ) ] } " '
    return url.replace(/[.,;:?!)"}]+$/gi, '').trim();
  });
  
  // Filter out empty strings and duplicates
  return [...new Set(cleanedUrls.filter(url => url))];
}`;

// Find the extractUrls function and replace it
let extractUrlsStart = -1;
let extractUrlsEnd = -1;
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('export function extractUrls')) {
    extractUrlsStart = i;
  }
  if (extractUrlsStart >= 0 && lines[i].includes('}') && !lines[i + 1]?.includes('//')) {
    extractUrlsEnd = i;
    break;
  }
}

if (extractUrlsStart >= 0 && extractUrlsEnd >= 0) {
  lines.splice(extractUrlsStart, extractUrlsEnd - extractUrlsStart + 1, ...newExtractUrls.split('\n'));
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed urlRegex not defined error');