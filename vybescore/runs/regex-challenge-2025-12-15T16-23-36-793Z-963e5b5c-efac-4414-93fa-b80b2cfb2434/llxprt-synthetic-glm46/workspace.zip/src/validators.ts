export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with proper RFC compliance
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure check - must have exactly one @
  const atParts = value.split('@');
  if (atParts.length !== 2) return false;
  
  const [localPart, domainPart] = atParts;
  
  // Local part validation
  if (!localPart || localPart.length > 64) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Local part regex: allows letters, digits, and special chars like +, -, _, .
  // but must not start or end with . and no consecutive dots
  const localRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
  if (!localRegex.test(localPart)) return false;
  
  // Domain part validation
  if (!domainPart || domainPart.length > 255) return false;
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) return false;
  if (domainPart.includes('..')) return false;
  
  // Domain cannot contain underscores
  if (domainPart.includes('_')) return false;
  
  // Domain regex: allows subdomains and tlds
  // Must have at least one dot separating domain and TLD
  const domainRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  const labels = domainPart.split('.');
  
  // Must have at least 2 labels for a valid domain (e.g., example.com)
  if (labels.length < 2) return false;
  
  // TLD must be at least 2 characters for ccTLDs or standard TLDs
  const tld = labels[labels.length - 1];
  if (tld.length < 2) return false;
  
  // Check each label
  for (const label of labels) {
    if (!domainRegex.test(label)) return false;
    if (label.startsWith('-') || label.endsWith('-')) return false;
  }
  
  // Enhanced domain validation: no double dots, no trailing dots, no underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(value.trim());
}

/**
 * Validates US phone numbers in various formats
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum and maximum length
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    // If 11 digits, must start with +1 country code
    if (!digitsOnly.startsWith('1')) return false;
    phoneNumber = digitsOnly.slice(1); // Remove country code
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate format with regex for common US phone patterns
  const phoneRegex = /^(?:\+?1)?(?:\s*|\-)?\(?([2-9]\d{2})\)?(?:\s*|\-)?([2-9]\d{2})(?:\s*|\-)?(\d{4})$/;
  
  // +1(212)555-7890
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Clean the input: remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix (if country code omitted, 0 is required)
  // Optional 9 mobile indicator
  // 2-4 digit area code (must not start with 0)
  // 6-8 digit subscriber number
  const phoneRegex = /^(?:\+54)?(?:0?)(?:9?)([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(phoneRegex);
  if (!match) return false;
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits and start with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  // If country code is omitted, must begin with 0 before area code
  if (!cleanValue.startsWith('+54') && !value.startsWith('0')) return false;
  
  return true;
}

/**
 * Validates names using Unicode letter patterns
 * Allows letters with diacritics/accents, apostrophes, hyphens, and spaces
 * Rejects digits, symbols, and unconventional names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Name regex pattern explanation:
  // \p{L} matches any Unicode letter (including accented characters)
  // \p{M} matches combining marks (like accents)
  // The pattern allows for letters, accents, apostrophes, hyphens, and spaces
  // Name must start with a letter, can contain letters, accents, apostrophes, hyphens, and spaces
  // Must end with a letter or apostrophe
  const nameRegex = /^\p{L}[\p{L}\p{M}'’\- ]*\p{L}[\p{L}\p{M}'’\- ]*$/u;
  
  // Reject if contains digits or common unwanted symbols
  if (/[0-9]/.test(value)) return false;
  
  // Reject if contains multiple special characters in sequence (common in nonsensical names)
  if (/[—–]/.test(value)) return false; // Dash variants
  
  // Reject common fake/celebrity "names" like X Æ A-12
  if (/[×æØ]/.test(value)) return false;
  
  // Minimum length check (at least 2 characters)
  if (value.trim().length < 2) return false;
  
  // Maximum reasonable length for a name
  if (value.trim().length > 100) return false;
  
  return nameRegex.test(value.trim());
}

/**
 * Validates credit card numbers using Luhn algorithm
 * Accepts Visa/Mastercard/AmEx prefixes and lengths
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Clean input: remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Length validation
  if (cleanValue.length < 13 || cleanValue.length > 19) return false;
  
  // Card prefix and length validation
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$/; // 16 digits
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits, starts with 34 or 37
  
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Validate check digit using the Luhn algorithm
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to run the Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Start from the rightmost digit (check digit) and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = digit.toString().split('').reduce((acc, curr) => acc + parseInt(curr, 10), 0);
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}