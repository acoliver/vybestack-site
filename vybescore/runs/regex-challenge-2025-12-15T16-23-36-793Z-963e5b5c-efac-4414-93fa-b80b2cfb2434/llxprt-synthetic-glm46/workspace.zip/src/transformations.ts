/**
 * Capitalizes the first character of each sentence
 * After punctuation marks (., ?, !), capitalizes the next letter
 * Collapses multiple spaces while preserving proper sentence structure
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, normalize whitespace but preserve structure
  const result = text.replace(/\s+/g, ' ').trim();
  
  // Split by sentence boundaries using regex
  // This pattern matches periods, exclamation marks, and question marks
  const sentences = result.split(/([.!?])/);
  
  // Reconstruct sentences with proper capitalization
  let capitalizedText = '';
  let capitalizeNext = true; // First sentence should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const piece = sentences[i];
    
    if (piece) {
      // If this is punctuation, just add it and a single space
      if (piece === '.' || piece === '!' || piece === '?') {
        capitalizedText += piece + ' ';
        capitalizeNext = true; // Next piece should be capitalized
      } else {
        // This is text content
        if (capitalizeNext) {
          capitalizedText += piece.charAt(0).toUpperCase() + piece.slice(1);
          capitalizeNext = false;
        } else {
          capitalizedText += piece;
        }
      }
    }
  }
  
  // Clean up any extra spaces and trim
  return capitalizedText.replace(/\s+/g, ' ').trim();
}

/**
 * Extracts all URLs from the given text
 * Returns array of URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex to match URLs
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|ftps:\/\/|www\.)[^\s<>'"]+/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches - remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like . , ; : ? ! ) ] } " '
    return url.replace(/[.,;:?!)"}]+$/gi, '').trim();
  });
  
  // Filter out empty strings and duplicates
  return [...new Set(cleanedUrls.filter(url => url))];
}

/**
 * Upgrades all http:// URLs to https://
 * Converts insecure HTTP URLs to HTTPS while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// but not already https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrades http:// to https://
 * - For URLs with /docs/ path, rewrites host from example.com to docs.example.com
 * - Skips host rewrite for paths containing cgi-bin, query strings, or legacy extensions
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Find all URLs in the text
  // Accept both http and https protocols
  const urlRegex = /(https?:\/\/)([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/[a-zA-Z0-9._/~?%\-#&=+;@]*)?/g;
  
  return text.replace(urlRegex, (match, scheme, domain, path) => {
    // Always upgrade scheme to https
    const upgradedScheme = 'https://';
    
    // If there's no path, return with upgraded scheme
    if (!path) {
      return upgradedScheme + domain;
    }
    
    // Skip host rewrite for paths with dynamic hints or legacy extensions
    const skipPatterns = [
      /\/cgi-bin\//i,
      /\?|&|=/, // Query string indicators
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i // Legacy extensions
    ];
    
    const shouldSkipHostRewrite = skipPatterns.some(pattern => pattern.test(path));
    
    // If the path starts with /docs/ and we shouldn't skip, rewrite host
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return upgradedScheme + 'docs.' + domain + path;
    }
    
    // Default: just upgrade the scheme
    return upgradedScheme + domain + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format
 * Returns the four-digit year or 'N/A' if format is invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Pattern matches mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/([0-9]{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day for the month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for February with leap year consideration
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) return 'N/A';
  } else if (day > maxDays[month - 1]) {
    return 'N/A';
  }
  
  // All validations passed, return year
  return year;
}