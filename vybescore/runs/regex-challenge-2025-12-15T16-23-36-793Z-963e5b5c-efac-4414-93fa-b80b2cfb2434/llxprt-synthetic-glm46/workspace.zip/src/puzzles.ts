/**
 * Finds words beginning with the prefix but excluding the listed exceptions
 * Uses regex with word boundaries and negative lookaheads
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  if (!Array.isArray(exceptions)) return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words starting with prefix
  // Word boundaries ensure we match whole words only
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  // Find all matches
  const allMatches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  const filteredWords = allMatches.filter(word => {
    // Convert to lowercase for case-insensitive comparison with exceptions
    const lowerWord = word.toLowerCase();
    // Check if the word matches any exception (case-insensitive)
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerWord || 
      lowerWord.startsWith(exception.toLowerCase())
    );
  });
  
  // Remove duplicates and return
  return [...new Set(filteredWords)];
}

/**
 * Finds occurrences where the token appears after a digit but not at the start
 * Uses lookbehind and lookahead assertions
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find token that appears after a digit but not at start
  // Using positive lookbehind to find the digit before the token
  // Using word boundary to ensure we're not at the start
  const embeddedTokenRegex = new RegExp(`\\b(\\d${escapedToken})\\b`, 'g');
  
  // Find all matches
  const matches = [];
  let match;
  while ((match = embeddedTokenRegex.exec(text)) !== null) {
    matches.push(match[1]);
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Validates password strength
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol
 * No whitespace, no immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (special character)
  if (!/[!@#$%^&*()_+=\-\[\]{};\'":|,.<>\/]/.test(value)) return false;
  
  // This regex looks for any sequence of 2-4 characters that repeats immediately
  const repeatedSequenceRegex = /(.{2,4})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // Passes all checks
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::)
 * Ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Clean up whitespace for validation
  const cleanValue = value.trim();
  
  // IPv4 detection regex - make sure we don't match these
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If it's a clean IPv4 address, return false
  if (ipv4Regex.test(cleanValue)) return false;
  
  // IPv6 patterns
  
  // Full IPv6 pattern: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Shorthand IPv6 with :: compression
  const shorthandRegex = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;
  
  // Edge case: just :: (all zeros)
  const doubleColonOnlyRegex = /^::$/;
  
  // Test all patterns
  if (fullIpv6Regex.test(cleanValue)) return true;
  if (doubleColonOnlyRegex.test(cleanValue)) return true;
  if (shorthandRegex.test(cleanValue)) return true;
  
  // No IPv6 detected
  return false;
}