import { findPrefixedWords } from './src/puzzles.js';

console.log(findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));