#!/bin/bash
echo '  if (!/[!@#$%^&*()_+\-=\[\]{};'"'"':"\|,.<>\/]/.test(value)) return false;' > lin104FinalFixed.txt