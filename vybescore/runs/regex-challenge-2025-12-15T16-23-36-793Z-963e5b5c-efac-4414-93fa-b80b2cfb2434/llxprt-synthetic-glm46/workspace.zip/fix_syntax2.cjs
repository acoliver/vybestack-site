// Fix remaining syntax errors by replacing entire functions
const fs = require('fs');

// Fix transformations.ts by replacing extractUrls function entirely
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
let content = fs.readFileSync(filePath, 'utf8');

// Fix extractUrls function properly
const extractUrls = `export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex to match URLs
  const urlRegex = /(?:https?:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\']+|(?:https?:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\']+[\\w\\/-]/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches - remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like . , ; : ? ! ) ] } " '
    return url.replace(/[.,;:?!)"}]+$/gi, '').trim();
  });
  
  // Filter out empty strings and duplicates
  return [...new Set(cleanedUrls.filter(url => url))];
}`;

// Find and replace the extractUrls function
let lines = content.split('\n');
let startIndex = -1;
let endIndex = -1;

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('export function extractUrls')) {
    startIndex = i;
  }
  if (startIndex >= 0 && lines[i].includes('}') && (lines[i+1]?.includes('export') || lines[i+1]?.includes('//') || i === lines.length - 1)) {
    endIndex = i;
    break;
  }
}

if (startIndex >= 0 && endIndex >= 0) {
  lines.splice(startIndex, endIndex - startIndex + 1, ...extractUrls.split('\n'));
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix validators.ts by ensuring it ends properly
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');

// Remove any extra content at the very end that might be malformed
lines = content.split('\n');

// Ensure the last line is a proper closing brace
if (lines[lines.length - 1].trim() !== '}') {
  // Find the last non-empty line
  let lastNonEmpty = lines.length - 1;
  while (lastNonEmpty >= 0 && !lines[lastNonEmpty].trim()) {
    lastNonEmpty--;
  }
  
  // If the last non-empty line doesn't end with }, add it
  if (lastNonEmpty >= 0 && !lines[lastNonEmpty].trim().endsWith('}')) {
    lines.push('}');
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed syntax errors again');