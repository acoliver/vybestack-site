// Final attempt to fix syntax errors by completely rewriting problematic file sections
const fs = require('fs');

// Completely rewrite transformations.ts for the problematic parts
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';

// Read original file
let content = fs.readFileSync(filePath, 'utf8');

// Split and reassemble in a clean way
let transformationsParts = content.split('export function');

let firstPart = transformationsParts[0];
let remainingParts = transformationsParts.slice(1);

// Rebuild with clean export functions
let result = firstPart;

// Keep everything before extractUrls
for (let part of remainingParts) {
  if (part.includes('extractUrls(')) {
    // Add a clean extractUrls function
    result += 'export function extractUrls(text: string): string[] {\n';
    result += '  if (!text || typeof text !== \'string\') return [];\n';
    result += '  \n';
    result += '  // Regex to match URLs\n';
    result += '  const urlRegex = /(?:https?\\:\\/\\/|ftp:\\/\\/|ftps:\\/\\/|www\\.)[^\\s<>"\\\']+/gi;\n';
    result += '  \n';
    result += '  // Find all matches\n';
    result += '  const matches = text.match(urlRegex) || [];\n';
    result += '  \n';
    result += '  // Clean up matches - remove trailing punctuation\n';
    result += '  const cleanedUrls = matches.map(url => {\n';
    result += '    // Remove trailing punctuation like . , ; : ? ! ) ] } " \'\n';
    result += '    return url.replace(/[.,;:?!)"}]+$/gi, \'\').trim();\n';
    result += '  });\n';
    result += '  \n';
    result += '  // Filter out empty strings and duplicates\n';
    result += '  return [...new Set(cleanedUrls.filter(url => url))];\n';
    result += '}\n\n';
  } else {
    result += 'export function' + part;
  }
}

// Add missing closing braces at the very end
if (result.trim().endsWith('}') !== true) {
  result += '\n}';
}

fs.writeFileSync(filePath, result);

// Fix validators.ts
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');

// Clean up the file structure - make sure it ends properly
if (content.trim().endsWith('}') !== true) {
  if (content.trim().endsWith('}}')) {
    // Already has extra closing braces
  } else {
    content += '\n}';
  }
}

fs.writeFileSync(filePath, content);

console.log('Applied final syntax fixes');