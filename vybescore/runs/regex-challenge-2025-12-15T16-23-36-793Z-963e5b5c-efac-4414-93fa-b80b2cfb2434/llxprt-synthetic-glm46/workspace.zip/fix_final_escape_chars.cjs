// Final fix for remaining escape character issues
const fs = require('fs');

// Fix puzzles.ts line 104
let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/puzzles.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// For regex character class, only these need escaping: ^ - ] \
// Let's fix line 104 with correct escaping
lines[103] = '  if (!/[!@#$%^&*()_+\\-=\\[\\]{}\';":|,.<>\\x2F]/.test(value)) return false;';
// Using \x2F for / to avoid needing to escape it in the character class
content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix transformations.ts line 101
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');
lines[100] = '  const urlRegex = /(https?:\\/\\/)([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})(\\/[a-zA-Z0-9._\\/~?%\\-#&=+;@]*)?/g;';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

// Fix validators.ts line 178
filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/validators.ts';
content = fs.readFileSync(filePath, 'utf8');
lines = content.split('\n');
lines[177] = '  // Validate check digit using the Luhn algorithm';
content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed all final escape character issues');