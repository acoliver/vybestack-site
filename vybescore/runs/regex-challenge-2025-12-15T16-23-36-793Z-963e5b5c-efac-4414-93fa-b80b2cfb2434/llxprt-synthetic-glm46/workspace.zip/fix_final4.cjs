// Fix transformations.ts line 101 escape character - create the regex differently
const fs = require('fs');

let filePath = '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2025-12-15T16-23-36-793Z-963e5b5c-efac-4414-93fa-b80b2cfb2434/src/transformations.ts';
let content = fs.readFileSync(filePath, 'utf8');
let lines = content.split('\n');

// Replace line 101 with explicit regex string
let oldLine = "  const urlRegex = /(https?:\\/\\/)([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})(\\/[a-zA-Z0-9._\\/~?%\\-#&=+;@]*)?/g;";
let newLine = "  const urlRegex = new RegExp('(https?://' + ')([a-zA-Z0-9.-]+\\\\.[a-zA-Z]{2,})(/[a-zA-Z0-9._/~?%\\-#&=+;@]*)?', 'g');";

for (let i = 0; i < lines.length; i++) {
  if (lines[i] === oldLine) {
    lines[i] = newLine;
    break;
  }
}

content = lines.join('\n');
fs.writeFileSync(filePath, content);

console.log('Fixed transformations.ts escape character');