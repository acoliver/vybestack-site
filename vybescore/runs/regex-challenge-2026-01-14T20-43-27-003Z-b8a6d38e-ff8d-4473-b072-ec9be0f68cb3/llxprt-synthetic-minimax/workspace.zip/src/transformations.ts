/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into single spaces (but preserve sentence boundaries)
  const processed = text.replace(/\s+/g, ' ');
  
  // Split by sentence endings (.?!), capture the punctuation
  const sentences = processed.split(/([.!?])(\s+|$)/);
  
  let result = '';
  let expectNewSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part === undefined || part === '') {
      continue;
    }
    
    // If this is punctuation, add it
    if (part === '.' || part === '!' || part === '?') {
      result += part;
      // Add exactly one space after sentence-ending punctuation if not end of string
      if (i + 2 < sentences.length) {
        result += ' ';
      }
      expectNewSentence = true;
      continue;
    }
    
    // If we expect a new sentence and this part has content
    if (expectNewSentence && part.trim()) {
      // Capitalize first letter
      const trimmed = part.trim();
      const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      result += capitalized;
      expectNewSentence = false;
    } else if (part.trim()) {
      // Not expecting new sentence, just add as is
      result += part;
    }
  }
  
  // Handle first sentence capitalization
  const trimmedResult = result.trim();
  if (trimmedResult && /^[a-z]/.test(trimmedResult)) {
    return trimmedResult.charAt(0).toUpperCase() + trimmedResult.slice(1);
  }
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Enhanced URL regex that captures most common URL patterns
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[.,;!?)]*/gi;
  
  const urls = [];
  const matches = text.match(urlPattern);
  
  if (matches) {
    for (const url of matches) {
      // Remove trailing punctuation that isn't part of URL
      let cleanUrl = url.replace(/[.,;:!?]+$/g, '');
      
      // If it starts with www., add protocol for consistency
      if (cleanUrl.startsWith('www.')) {
        cleanUrl = 'http://' + cleanUrl;
      }
      
      urls.push(cleanUrl);
    }
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs (not https://)
  const httpPattern = /\bhttp:\/\/[^\s<>"{}|\\^`[]+/gi;
  
  return text.replace(httpPattern, (match) => {
    // Replace http:// with https://
    return match.replace(/^http:\/\//i, 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with path components
  const httpUrlPattern = /\bhttp:\/\/([^/\s]+)([^\s<>"{}|\\^`[]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    let newUrl = 'https://';
    
    // Check if path starts with /docs/
    const hasDocsPath = path.startsWith('/docs/');
    
    // Check for dynamic hints or legacy extensions
    const hasDynamicHints = /[?&]=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (hasDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.' + host;
    } else {
      // Keep original host
      newUrl += host;
    }
    
    // Always add the path
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (01-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31, basic validation)
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  // Return the year part
  return year;
}
