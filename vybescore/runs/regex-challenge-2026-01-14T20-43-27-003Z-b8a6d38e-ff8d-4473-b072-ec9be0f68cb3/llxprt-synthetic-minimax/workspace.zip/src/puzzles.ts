/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern to match words starting with prefix
  // Use word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(match => {
    const cleanMatch = match.toLowerCase();
    return !exceptions.some(exc => exc.toLowerCase() === cleanMatch);
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  // Find pattern where token appears after a digit
  const pattern = new RegExp(`(\\d${token})`, 'g');
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Return the full match (digit + token)
    results.push(match[1]);
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.\\<>]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences like 'abab'
  // Look for any 2-character pattern that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const twoCharPattern = value.slice(i, i + 2);
    const nextTwoChars = value.slice(i + 2, i + 4);
    if (twoCharPattern === nextTwoChars && twoCharPattern.length === 2) {
      return false;
    }
  }
  
  // Check for 3-character repeated sequences
  for (let i = 0; i < value.length - 5; i++) {
    const threeCharPattern = value.slice(i, i + 3);
    const nextThreeChars = value.slice(i + 3, i + 6);
    if (threeCharPattern === nextThreeChars && threeCharPattern.length === 3) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it looks like IPv4 (dots with digits)
  // If it's pure IPv4 pattern, reject it immediately
  if (/^\d+\.\d+\.\d+\.\d+$/.test(value.trim())) {
    return false;
  }
  
  // Check for pure IPv4 patterns anywhere in the string
  if (/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match:
  // 1. Standard IPv6 with full groups
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b/;
  
  // 2. IPv6 with shorthand :: notation
  const shorthandIPv6Pattern = /\b(?:[0-9a-fA-F]{0,4}:){0,7}::(?:[0-9a-fA-F]{0,4}:){0,7}[0-9a-fA-F]{0,4}\b/;
  
  // 3. IPv6-mapped IPv4 (::ffff:192.168.1.1)
  const ipv4MappedPattern = /\b::(?:ffff|Ffff):\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // 4. Leading/trailing IPv6 with shorthand
  const leadingShorthandPattern = /\b::[0-9a-fA-F:]+\b/;
  const trailingShorthandPattern = /\b[0-9a-fA-F:]+\\::\b/;
  
  // 5. IPv6 in brackets (commonly used in URLs)
  const bracketedIPv6Pattern = /\[[0-9a-fA-F:]+\]/;
  
  // Check various IPv6 patterns
  if (fullIPv6Pattern.test(value) || 
      shorthandIPv6Pattern.test(value) || 
      ipv4MappedPattern.test(value) ||
      leadingShorthandPattern.test(value) ||
      trailingShorthandPattern.test(value) ||
      bracketedIPv6Pattern.test(value)) {
    
    // Additional validation: ensure it's not just colons or malformed
    const cleanedValue = value.replace(/[:[\]]/g, '');
    
    // Must contain at least some hex digits and valid IPv6 structure
    if (/[0-9a-fA-F]{1,}/.test(cleanedValue)) {
      // Make sure it's not just looking like IPv4 in disguise
      const ipv4Digits = cleanedValue.match(/\d+/g) || [];
      if (ipv4Digits.some(digits => parseInt(digits, 10) > 255)) {
        return true; // Has digits > 255, likely IPv6
      }
      
      // If all digits are <= 255 and it's a dotted pattern, it's probably IPv4
      const hasDots = value.includes('.');
      if (hasDots) {
        const allNumbers = value.match(/\d+/g) || [];
        const allValidIPv4 = allNumbers.every(num => parseInt(num, 10) <= 255);
        if (allValidIPv4 && allNumbers.length >= 4) {
          return false; // Pure IPv4 format
        }
      }
      
      return true;
    }
  }
  
  return false;
}
