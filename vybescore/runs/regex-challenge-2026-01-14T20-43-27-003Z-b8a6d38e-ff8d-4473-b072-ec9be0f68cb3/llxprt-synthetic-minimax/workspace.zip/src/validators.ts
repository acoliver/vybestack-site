export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\s+/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obvious invalid patterns first
  if (value.includes('..') || value.endsWith('.') || value.includes('_.') || value.includes('_@')) {
    return false;
  }

  // Basic email pattern with constraints
  const emailPattern = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }

  // Additional validation: reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  const hasCountryCode = cleaned.startsWith('+1');
  const numberPart = hasCountryCode ? cleaned.slice(2) : cleaned;
  
  // Must be 10 digits after country code removal
  if (numberPart.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = numberPart.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // If no country code, verify basic format patterns
  if (!hasCountryCode) {
    const basicPatterns = [
      /^\d{10}$/, // 1234567890
      /^\d{3}-\d{3}-\d{4}$/, // 123-456-7890
      /^\(\d{3}\)\s*\d{3}-\d{4}$/, // (123) 456-7890
      /^\d{3}\s*\d{3}\s*\d{4}$/, // 123 456 7890
    ];
    
    const formatValid = basicPatterns.some(pattern => pattern.test(value));
    if (!formatValid) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it starts with country code +54
  let remaining = cleaned;
  let hasCountryCode = false;
  let hasMobileIndicator = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check for optional mobile indicator 9
  if (remaining.startsWith('9')) {
    hasMobileIndicator = true;
    remaining = remaining.slice(1);
  }
  
  // Must have trunk prefix 0 (either before country code or now)
  if (!remaining.startsWith('0')) {
    // If no country code, must start with 0
    if (!hasCountryCode) {
      return false;
    }
    // If country code present but no 0, add it for validation
    remaining = '0' + remaining;
  }
  
  // Now remaining should start with 0, remove it for area code extraction
  if (!remaining.startsWith('0')) {
    return false;
  }
  remaining = remaining.slice(1); // Remove the 0
  
  // Extract area code (2-4 digits) - first digit must be 1-9
  if (remaining.length < 2) {
    return false;
  }
  
  // First digit of area code must be 1-9
  const firstDigit = parseInt(remaining[0], 10);
  if (firstDigit < 1 || firstDigit > 9) {
    return false;
  }
  
  // Extract area code: try different lengths
  let areaCodeEnd = 0;
  let foundAreaCode = false;
  let validSubscriber = false;
  
  // Try area code lengths 4, 3, 2
  for (let areaLen = 4; areaLen >= 2; areaLen--) {
    if (remaining.length >= areaLen) {
      const areaCode = remaining.slice(0, areaLen);
      const subscriberNumber = remaining.slice(areaLen);
      
      // Area code must be all digits, first digit 1-9, no leading zeros
      if (/^\d+$/.test(areaCode) && areaCode[0] !== '0') {
        // Subscriber number must be digits
        if (/^\d+$/.test(subscriberNumber)) {
          // Total digits after area code should be 6-8 (subscriber number)
          if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
            areaCodeEnd = areaLen;
            validSubscriber = true;
            foundAreaCode = true;
            break;
          }
        }
      }
    }
  }
  
  if (!foundAreaCode || !validSubscriber) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for obvious invalid patterns
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject special character patterns like "X Æ A-12"
  if (/[^\p{L}\s'-]/u.test(value)) {
    return false;
  }
  
  // Pattern for valid names: letters, spaces, apostrophes, hyphens
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must have at least some content
  if (value.trim().length === 0) {
    return false;
  }
  
  // Cannot start or end with special characters
  const trimmed = value.trim();
  if (/^[\s'-]|[\s'-]$/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\s+/g, '').replace(/-/g, '');
  
  // Must be 13-19 digits for valid credit cards
  if (!/^\d{13,19}$/.test(cardNumber)) {
    return false;
  }
  
  // Check card type based on prefix and length
  let isValidType = false;
  
  // Visa: starts with 4, 13, 16, 19 digits
  if (/^4/.test(cardNumber)) {
    isValidType = cardNumber.length === 13 || cardNumber.length === 16 || cardNumber.length === 19;
  }
  // Mastercard: starts with 51-55, 16 digits
  else if (/^5[1-5]/.test(cardNumber)) {
    isValidType = cardNumber.length === 16;
  }
  // American Express: starts with 34 or 37, 15 digits
  else if (/^3[47]/.test(cardNumber)) {
    isValidType = cardNumber.length === 15;
  }
  // Discover: starts with 6011 or 65, 16 digits
  else if (/^6011/.test(cardNumber) || /^65/.test(cardNumber)) {
    isValidType = cardNumber.length === 16;
  }
  // Other valid patterns
  else {
    // Default validation for other card types (13-19 digits)
    isValidType = cardNumber.length >= 13 && cardNumber.length <= 19;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
