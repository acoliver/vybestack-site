/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /).
 * Includes padding (=) when required for proper decoding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding, and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace that might be present
  const cleaned = input.replace(/\s/g, '');
  
  // Validate the input: must contain only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Check that input has valid padding if present
  if (cleaned.includes('=') && (/[^A-Za-z0-9+/=]/.test(cleaned) || !/^[A-Za-z0-9+/]*={0,2}$/.test(cleaned))) {
    throw new Error('Invalid Base64 input: malformed padding');
  }
  
  try {
    return Buffer.from(cleaned, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: ' + (error as Error).message);
  }
}
