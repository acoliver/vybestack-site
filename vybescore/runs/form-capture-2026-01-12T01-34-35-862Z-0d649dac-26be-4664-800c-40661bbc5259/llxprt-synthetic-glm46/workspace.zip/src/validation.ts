import type { FormData, ValidationError } from './types.js';

export function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // First name validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push({
      field: 'firstName',
      message: 'First name is required',
    });
  }

  // Last name validation
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push({
      field: 'lastName',
      message: 'Last name is required',
    });
  }

  // Street address validation
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push({
      field: 'streetAddress',
      message: 'Street address is required',
    });
  }

  // City validation
  if (!formData.city || formData.city.trim() === '') {
    errors.push({
      field: 'city',
      message: 'City is required',
    });
  }

  // State/Province validation
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push({
      field: 'stateProvince',
      message: 'State/Province/Region is required',
    });
  }

  // Postal code validation (accept alphanumeric)
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push({
      field: 'postalCode',
      message: 'Postal/Zip code is required',
    });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode.trim())) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code contains invalid characters',
    });
  }

  // Country validation
  if (!formData.country || formData.country.trim() === '') {
    errors.push({
      field: 'country',
      message: 'Country is required',
    });
  }

  // Email validation
  if (!formData.email || formData.email.trim() === '') {
    errors.push({
      field: 'email',
      message: 'Email is required',
    });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address',
    });
  }

  // Phone validation (accept international formats)
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push({
      field: 'phone',
      message: 'Phone number is required',
    });
  } else if (!/^\+?[0-9\s-()]+$/.test(formData.phone.trim())) {
    errors.push({
      field: 'phone',
      message: 'Phone number contains invalid characters',
    });
  }

  return errors;
}