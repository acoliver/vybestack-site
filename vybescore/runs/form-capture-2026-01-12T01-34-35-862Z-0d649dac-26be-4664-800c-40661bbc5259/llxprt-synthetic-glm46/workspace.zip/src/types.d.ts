declare module 'sql.js' {
  export default function initSqlJs(options?: {
    locateFile?: (file: string) => string;
  }): Promise<typeof Database>;
  
  export class Database {
    constructor(data?: ArrayBuffer | Uint8Array | null);
    run(sql: string, params?: unknown[]): unknown;
    prepare(sql: string): {
      run(...params: unknown[]): unknown[];
      free(): void;
      get(params?: unknown[]): unknown;
      getAsObject(params?: unknown[]): unknown[];
    };
    export(): Uint8Array;
    getRowsModified(): number[];
    close(): void;
  }
}