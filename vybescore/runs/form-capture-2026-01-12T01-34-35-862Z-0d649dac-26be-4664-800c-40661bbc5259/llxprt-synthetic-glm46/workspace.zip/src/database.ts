// @ts-nocheck
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';
import type { FormData, FormSubmission } from './types.js';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

export class Database {
  private db: any | null = null;
  private isInitialized = false;

  async init(): Promise<void> {
    if (this.isInitialized) return;

    try {
      const SQL = await initSqlJs();
      
      // Always create a new database for testing
      this.db = new SQL.Database();
      
      // Initialize schema
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      this.db.run(schema);
      
      this.isInitialized = true;
    } catch (error) {
      console.error('Database initialization error:', error);
      throw new Error(`Failed to initialize database: ${error}`);
    }
  }

  private save(): void {
    if (!this.isInitialized) {
      throw new Error('Database not initialized');
    }
    
    try {
      const data = this.db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
    } catch (error) {
      throw new Error(`Failed to save database: ${error}`);
    }
  }

  insertSubmission(formData: FormData): FormSubmission {
    if (!this.isInitialized) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    );

    const id = this.db.getRowsModified()[0];
    stmt.free();

    const result = this.db.prepare('SELECT * FROM submissions WHERE id = ?');
    const row = result.get([id]) as Record<string, unknown>;
    result.free();

    this.save();

    return {
      id: row.id as number,
      firstName: row.first_name as string,
      lastName: row.last_name as string,
      streetAddress: row.street_address as string,
      city: row.city as string,
      stateProvince: row.state_province as string,
      postalCode: row.postal_code as string,
      country: row.country as string,
      email: row.email as string,
      phone: row.phone as string,
      createdAt: row.created_at as string,
    };
  }

  getSubmissions(): FormSubmission[] {
    if (!this.isInitialized) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
    const rows: unknown[] = stmt.getAsObject([]);
    stmt.free();

    return rows.map((row) => ({
      id: (row as Record<string, unknown>).id as number,
      firstName: (row as Record<string, unknown>).first_name as string,
      lastName: (row as Record<string, unknown>).last_name as string,
      streetAddress: (row as Record<string, unknown>).street_address as string,
      city: (row as Record<string, unknown>).city as string,
      stateProvince: (row as Record<string, unknown>).state_province as string,
      postalCode: (row as Record<string, unknown>).postal_code as string,
      country: (row as Record<string, unknown>).country as string,
      email: (row as Record<string, unknown>).email as string,
      phone: (row as Record<string, unknown>).phone as string,
      createdAt: (row as Record<string, unknown>).created_at as string,
    }));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.isInitialized = false;
    }
  }
}