import express from 'express';
import path from 'node:path';
import { Database } from './database.js';
import { validateForm } from './validation.js';
import type { FormData } from './types.js';

const app = express();
const db = new Database();
const port = Number(process.env.PORT) || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static files
app.use('/public', express.static(path.resolve('public')));

// EJS setup
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Routes
app.get('/', (req, res) => {
  const errors: string[] = [];
  const values = {} as Record<string, string>;
  
  res.render('form', { errors, values });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };
    
    const validationErrors = validateForm(formData);
    
    if (validationErrors.length > 0) {
      const errorMessages = validationErrors.map(err => err.message);
      res.status(400).render('form', { errors: errorMessages, values: formData });
      return;
    }
    
    // Insert into database
    db.insertSubmission(formData);
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', { 
      errors: ['An unexpected error occurred. Please try again.'],
      values: req.body 
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || '';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, closing database connection...');
  db.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, closing database connection...');
  db.close();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await db.init();
    console.log('Database initialized');
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
