/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet
 * with proper padding characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the canonical RFC 4648 alphabet.
 * Accepts inputs with or without padding characters and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Empty or invalid input');
  }

  // Remove all whitespace characters
  const normalizedInput = input.replace(/\s+/g, '');

  // Validate that the string contains only Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalizedInput)) {
    throw new Error('Invalid Base64 format: contains characters outside the Base64 alphabet');
  }

  // Validate padding is only at the end
  const paddingIndex = normalizedInput.indexOf('=');
  if (paddingIndex !== -1) {
    // Check that all characters after first '=' are also '='
    const paddingSection = normalizedInput.substring(paddingIndex);
    if (![...paddingSection].every(char => char === '=')) {
      throw new Error('Invalid Base64 format: padding characters not at the end');
    }
  }

  // Add padding if needed for proper decoding
  // Node.js Buffer.from with 'base64' encoding handles missing padding correctly,
  // but we validate it to ensure strict compliance
  let processedInput = normalizedInput;
  const paddingNeeded = processedInput.length % 4;
  if (paddingNeeded !== 0) {
    // Only add padding if there's no existing padding
    if (paddingIndex === -1) {
      processedInput += '='.repeat(4 - paddingNeeded);
    }
  }

  try {
    const buffer = Buffer.from(processedInput, 'base64');
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
