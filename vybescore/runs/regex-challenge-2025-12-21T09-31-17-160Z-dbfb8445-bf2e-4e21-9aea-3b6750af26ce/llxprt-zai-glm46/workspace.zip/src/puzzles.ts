/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create a Set for faster exception lookup (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  // Word boundary regex to find words starting with the prefix
  const wordRegex = new RegExp('\\b' + prefix + '[a-zA-Z]*\\b', 'g');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and return unique words
  return [...new Set(matches.filter(word => !exceptionSet.has(word.toLowerCase())))];
}

export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to match token only when preceded by a digit
  const tokenRegex = new RegExp('\\d' + escapedToken, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab, abcabc)
  // Check for repeated patterns of length 2-4
  for (let patternLength = 2; patternLength <= 4; patternLength++) {
    for (let i = 0; i <= value.length - patternLength * 2; i++) {
      const pattern = value.slice(i, i + patternLength);
      const nextPattern = value.slice(i + patternLength, i + patternLength * 2);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv4 regex to exclude IPv4 addresses
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it contains an IPv4 address, return false
  if (ipv4Regex.test(value)) return false;
  
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const ipv6FullRegex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed IPv6 with :: (can appear at most once)
  const ipv6CompressedRegex = /\b(?:[0-9a-fA-F]{1,4}:)*::?(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with embedded IPv4
  const ipv6WithIPv4Regex = /\b(?:[0-9a-fA-F]{1,4}:){6}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Test for any IPv6 pattern
  return ipv6FullRegex.test(value) || ipv6CompressedRegex.test(value) || ipv6WithIPv4Regex.test(value);
}
