export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure: local@domain.tld
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) return false;
  
  // More specific validation
  // Local part: allow letters, digits, ., _, +, -, but no consecutive dots or starting/ending dots
  const localPartRegex = /^[a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*$/;
  // Domain part: allow letters, digits, hyphens, but no underscores or starting/ending hyphens
  const domainPartRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  const [localPart, ...domainParts] = value.split('@');
  const domain = domainParts.join('@');
  
  if (!localPart || !domain) return false;
  
  // Check local part
  if (!localPartRegex.test(localPart)) return false;
  
  // Check domain part
  if (!domainPartRegex.test(domain)) return false;
  
  // Reject double dots anywhere
  if (value.includes('..')) return false;
  
  // Reject domain with underscores
  if (domain.includes('_')) return false;
  
  // Reject trailing dots
  if (value.endsWith('.')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Validate format patterns first
  const patterns = [
    /^\+1\s*\(\s*\d{3}\s*\)\s*\d{3}[-\s]?\d{4}$/,     // +1 (212) 555-7890
    /^\+1\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/,              // +1 212-555-7890
    /^\+1\s*\d{10}$/,                                   // +1 2125557890
    /^\(\s*\d{3}\s*\)\s*\d{3}[-\s]?\d{4}$/,            // (212) 555-7890
    /^\d{3}[-\s]?\d{3}[-\s]?\d{4}$/,                    // 212-555-7890, 212 555 7890
    /^\d{10}$/,                                         // 2125557890
  ];
  
  if (!patterns.some(pattern => pattern.test(value))) return false;
  
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  } else if (digits.length === 10) {
    // No country code
  } else {
    return false;
  }
  
  // US phone numbers should have exactly 10 digits after removing country code
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1 for North American Numbering Plan
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Validate format patterns with separators first
  const patterns = [
    /^\+54\s*9\s*\d{2,4}\s*\d{6,8}$/,           // +54 9 11 1234 5678
    /^\+54\s*\d{2,4}\s*\d{6,8}$/,               // +54 341 123 4567
    /^0\d{2,4}\s*\d{6,8}$/,                     // 011 1234 5678
    /^0\d{2,4}\s*\d{3,4}\s*\d{4}$/,             // 0341 423 4567
    /^\d{10,12}$/,                              // Cleaned format without spaces
  ];
  
  // If the original format matches any pattern, accept it
  if (patterns.some(pattern => pattern.test(value))) {
    return true;
  }
  
  // Argentine phone regex pattern for cleaned format
  // Optional +54 country code, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits (leading 1-9)
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, areaCodeWithTrunk, subscriberNumber] = match;
  
  // Area code should be 2-4 digits after removing optional trunk prefix
  const areaCode = areaCodeWithTrunk.startsWith('0') ? areaCodeWithTrunk.substring(1) : areaCodeWithTrunk;
  
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Area code should not start with 0
  if (areaCode.startsWith('0')) return false;
  
  // Subscriber number should be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // When country code is omitted, must have trunk prefix 0 before area code
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and special characters like X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}]+(?:['’-][\p{L}\p{M}]+)*(?:\s[\p{L}\p{M}]+(?:['’-][\p{L}\p{M}]+)*)*$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Reject names that look like codes or contain excessive symbols
  if (trimmed.includes('Æ') || trimmed.includes('X') || /\d/.test(trimmed)) return false;
  
  // Should contain at least one letter
  if (!/[\p{L}]/u.test(trimmed)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Should contain only digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length: Visa (13, 16, 19), Mastercard (16), AmEx (15)
  const length = cleaned.length;
  if (![13, 15, 16, 19].includes(length)) return false;
  
  // Check prefixes based on card type
  // Visa: starts with 4
  const visaRegex = /^4/;
  // Mastercard: starts with 51-55, 2221-2720
  const mastercardRegex = /^(5[1-5]|2[2-7][0-9]|2[2-7]00)/;
  // AmEx: starts with 34 or 37
  const amexRegex = /^3[47]/;
  
  const isVisa = visaRegex.test(cleaned) && [13, 16, 19].includes(length);
  const isMastercard = mastercardRegex.test(cleaned) && length === 16;
  const isAmex = amexRegex.test(cleaned) && length === 15;
  
  if (!isVisa && !isMastercard && !isAmex) return false;
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit.toString().split('').map(d => parseInt(d, 10)).reduce((a, b) => a + b, 0);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
