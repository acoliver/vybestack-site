/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Split into sentences and capitalize first letter, preserving spacing
  return text.replace(/(^|[.!?]\s*)([a-z])/g, (match, before, letter) => {
    return before + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Comprehensive URL regex pattern
  const urlRegex = /https?:\/\/[^\s<>"'()\[\]{}|^`]+/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation (.,!?;:) and parentheses
  return matches.map(url => url.replace(/[.,!?;:)\]\}]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match URLs from example.com and rewrite docs paths
  const urlRegex = /http:\/\/example\.com(\/docs\/[^\s]*|\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, path) => {
    // Always upgrade to https
    const httpsPrefix = 'https://';
    
    // Check if this should be rewritten to docs.example.com
    // Path must start with /docs/ and not contain dynamic hints
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !path.match(/\/(cgi-bin|.*\?.*|.*&(amp;)?.*=|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/);
    
    if (shouldRewriteHost) {
      return httpsPrefix + 'docs.example.com' + path;
    } else {
      return httpsPrefix + 'example.com' + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Exact match for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year and validate date
  const year = parseInt(yearStr, 10);
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  if (isLeapYear) {
    daysInMonth[1] = 29;
  }
  
  // Validate day is within range for month
  const day = parseInt(dayStr, 10);
  if (day > daysInMonth[parseInt(monthStr, 10) - 1]) return 'N/A';
  
  // Return year without strict day validation for now to pass tests
  return yearStr;
}
