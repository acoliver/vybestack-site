import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server.js';

let server: ReturnType<import('express').Express['listen']> | null = null;
let app: import('express').Express | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await startServer();
  app = result.app;
  server = result.server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone!@#'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('Phone number');
  });

  it('accepts international phone formats', async () => {
    const response1 = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 High Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958'
      });
    
    expect(response1.status).toBe(302);
    expect(response1.headers.location).toBe('/thank-you');
    
    const response2 = await request(app)
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678'
      });
    
    expect(response2.status).toBe(302);
    expect(response2.headers.location).toBe('/thank-you');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test Blvd',
        city: 'Testville',
        stateProvince: 'TX',
        postalCode: '75001',
        country: 'USA',
        email: 'test@example.com',
        phone: '+1 555-999-8888'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    expect(fs.existsSync(dbPath)).toBe(true);
    
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain('identity');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Incomplete',
        lastName: 'Submission',
        streetAddress: '123 Street',
        city: 'Cityville',
        stateProvince: 'ST',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email-format',
        phone: '+1 555-123-4567'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('Incomplete');
    expect($('input[name="lastName"]').val()).toBe('Submission');
  });

  it('handles alphanumeric postal codes', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Emma',
        lastName: 'Wilson',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'emma@example.uk',
        phone: '+44 20 7000 0000'
      });
    
    expect(response.status).toBe(302);
  });
});
