import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: import('sql.js').Database | null = null;
let SQL: import('sql.js').SqlJsStatic | null = null;

async function initializeDatabase(): Promise<void> {
  SQL = await initSqlJs();

  const fs = await import('node:fs');

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL!.Database(buffer);
  } else {
    db = new SQL!.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    await saveDatabase();
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const fs = await import('node:fs');
  const data = db.export();
  const buffer = Buffer.from(data);
  
  const dataDir = path.resolve(__dirname, '..', 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[@+]?[\d\s()\\-]+$/;
  const trimmed = phone.trim();
  return phoneRegex.test(trimmed) && trimmed.replace(/[^0-9]/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const trimmed = postalCode.trim();
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return trimmed.length > 0 && postalRegex.test(trimmed);
}

function validateForm(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain digits, spaces, parentheses, dashes, and may start with @' });
  }

  return errors;
}

function createApp(): express.Express {
  const app = express();

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

  app.get('/', (req, res) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });

  app.post('/submit', async (req, res) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validationErrors = validateForm(formData);

    if (validationErrors.length > 0) {
      const errorMessages = validationErrors.map(e => e.message);
      res.status(400);
      return res.render('form', {
        errors: errorMessages,
        values: formData
      });
    }

    if (!db) {
      throw new Error('Database not initialized');
    }

    try {
      const values = [
        formData.firstName!,
        formData.lastName!,
        formData.streetAddress!,
        formData.city!,
        formData.stateProvince!,
        formData.postalCode!,
        formData.country!,
        formData.email!,
        formData.phone!
      ];

      db.run(
        `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        values
      );

      await saveDatabase();

      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  });

  app.get('/thank-you', (req, res) => {
    const firstName = 'Friend';
    res.render('thank-you', { firstName });
  });

  return app;
}

async function startServer(): Promise<{ app: express.Express; server: ReturnType<express.Express['listen']> }> {
  await initializeDatabase();
  
  const app = createApp();
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  return { app, server };
}

function gracefulShutdown(server: ReturnType<express.Express['listen']>): void {
  console.log('Shutting down gracefully...');
  
  server.close(() => {
    console.log('Express server closed');
    
    if (db) {
      db.close();
      db = null;
      console.log('Database connection closed');
    }
    
    process.exit(0);
  });

  setTimeout(() => {
    console.error('Forced shutdown after timeout');
    process.exit(1);
  }, 10000);
}

// Store server reference for signal handlers
let runningServer: ReturnType<express.Express['listen']> | null = null;

process.on('SIGTERM', () => {
  if (runningServer) {
    gracefulShutdown(runningServer);
  } else {
    process.exit(0);
  }
});

process.on('SIGINT', () => {
  if (runningServer) {
    gracefulShutdown(runningServer);
  } else {
    process.exit(0);
  }
});

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().then((result) => {
    runningServer = result.server;
  }).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { startServer, createApp, FormData, ValidationError, initializeDatabase };
