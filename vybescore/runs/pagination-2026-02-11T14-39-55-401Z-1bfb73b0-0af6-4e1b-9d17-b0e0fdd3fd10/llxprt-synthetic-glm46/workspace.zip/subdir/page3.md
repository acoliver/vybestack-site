# Test Pagination - Page 3

This is the third page for testing read_many_files with offset.

## Content

- Subdirectory file #3
- Testing offset parameter
- Pagination functionality check

This page ensures that the offset parameter skips files correctly and that we can get the next batch of files with confidence.

## Testing Parameters

- Expected to be shown when offset=2
- Should NOT appear when offset=0
- Confirms pagination is working

---
Page 3 of test data set
---