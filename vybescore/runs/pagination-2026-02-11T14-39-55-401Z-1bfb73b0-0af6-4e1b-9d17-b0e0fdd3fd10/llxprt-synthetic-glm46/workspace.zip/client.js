// Client-side pagination demonstration
const http = require('http');

// API configuration
const API_URL = 'http://localhost:3000/api/users';

// Fetches a single page of data
async function fetchPage(page, pageSize) {
  return new Promise((resolve, reject) => {
    const url = `${API_URL}?page=${page}&pageSize=${pageSize}`;
    
    http.get(url, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const jsonData = JSON.parse(data);
          resolve(jsonData);
        } catch (error) {
          reject(new Error(`Failed to parse JSON: ${error.message}`));
        }
      });
    }).on('error', (error) => {
      reject(new Error(`Request failed: ${error.message}`));
    });
  });
}

// Creates an array with a specific number of dummy users
function createTestUsers(count) {
  const users = [];
  for (let i = 1; i <= count; i++) {
    users.push({
      id: i,
      name: `User ${i}`,
      email: `user${i}@example.com`,
      role: i % 2 === 0 ? 'admin' : 'user'
    });
  }
  return users;
}

// Demonstrates pagination with different page sizes
async function demonstratePagination() {
  console.log('Starting pagination demonstration...\n');
  
  const pageSize = 10; // Show 10 users at a time
  
  try {
    // Fetch first page
    let pageData = await fetchPage(1, pageSize);
    console.log(`Page ${pageData.currentPage}: Showing ${pageData.users.length} users`);
    console.log('First user:', pageData.users[0]);
    console.log('Total users:', pageData.totalItems);
    console.log('Total pages:', pageData.totalPages);
    console.log('---');
    
    // Navigate through pages
    while (pageData.currentPage < pageData.totalPages && pageData.currentPage < 3) {
      const nextPage = pageData.currentPage + 1;
      pageData = await fetchPage(nextPage, pageSize);
      
      console.log(`Page ${pageData.currentPage}: Showing ${pageData.users.length} users`);
      console.log('First user of page:', pageData.users[0]?.name || 'None');
      console.log('---');
    }
    
    // Demonstrate changing page size
    console.log('\nChanging page size to 5:');
    const smallPageData = await fetchPage(1, 5);
    console.log(`Page 1 with size 5: Showing ${smallPageData.users.length} users`);
    
  } catch (error) {
    console.error('Error during pagination demonstration:', error.message);
  }
}

// Demonstrates server-sent events with pagination
function demonstrateLivePagination() {
  console.log('\nStarting live pagination demonstration...');
  console.log('Listening for real-time updates...');
  
  const eventSourceUrl = `${API_URL.replace('/api/users', '/api/users/events')}?pageSize=5`;
  
  // Note: In a real scenario, you would use EventSource API
  // This is a placeholder to show how the client would connect
  console.log(`Would connect to: ${eventSourceUrl}`);
  console.log('In a browser, you would use the EventSource API to listen for updates');
  
  // Simulate receiving some updates
  setTimeout(() => {
    console.log('(Simulated) New users added, refreshing page...');
  }, 2000);
}

// Run the demonstrations
demonstratePagination()
  .then(() => demonstrateLivePagination())
  .catch(error => console.error('Client error:', error.message));