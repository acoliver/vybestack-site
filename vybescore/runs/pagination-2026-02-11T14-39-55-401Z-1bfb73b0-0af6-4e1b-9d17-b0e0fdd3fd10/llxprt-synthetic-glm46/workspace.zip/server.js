/**
 * Fixed Pagination API Server
 * Demonstrates proper page-based pagination with correct math
 */

const express = require('express');
const cors = require('cors');
const path = require('path');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Log requests for debugging
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path}`, {
    query: req.query,
    body: req.body,
    page: req.query.page,
    per_page: req.query.per_page
  });
  next();
});

// Generate sample data
function generateItems(count = 100) {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    name: `Item ${i + 1}`,
    description: `This is the description for item ${i + 1}`,
    category: `Category ${(i % 5) + 1}`,
    created: new Date(Date.now() - (count - i) * 86400000).toISOString()
  }));
}

const ALL_ITEMS = generateItems(100);
const TOTAL_COUNT = ALL_ITEMS.length;

// Helper function for page-based pagination math
function calculatePagination(totalItems, page, perPage) {
  const currentPage = Math.max(1, parseInt(page) || 1);
  const itemsPerPage = Math.max(1, Math.min(100, parseInt(perPage) || 10));
  
  const offset = (currentPage - 1) * itemsPerPage;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const hasNextPage = currentPage < totalPages;
  const hasPrevPage = currentPage > 1;
  
  return {
    currentPage,
    itemsPerPage,
    offset,
    totalPages,
    hasNextPage,
    hasPrevPage,
    totalItems,
    nextPage: hasNextPage ? currentPage + 1 : null,
    prevPage: hasPrevPage ? currentPage - 1 : null,
  };
}

// FIXED: Page-based pagination endpoint
app.get('/api/items', (req, res) => {
  // Extract pagination parameters
  const { page = "1", per_page = "10", search } = req.query;
  const pagination = calculatePagination(TOTAL_COUNT, page, per_page);
  
  // Get items for the current page
  let filteredItems = ALL_ITEMS;
  
  if (search) {
    filteredItems = ALL_ITEMS.filter(item => 
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.description.toLowerCase().includes(search.toLowerCase())
    );
    // Update pagination with filtered count
    const updatedPagination = calculatePagination(filteredItems.length, page, per_page);
    pagination.totalItems = updatedPagination.totalItems;
    pagination.totalPages = updatedPagination.totalPages;
    pagination.hasNextPage = updatedPagination.hasNextPage;
    pagination.hasPrevPage = updatedPagination.hasPrevPage;
    pagination.nextPage = updatedPagination.nextPage;
    pagination.prevPage = updatedPagination.prevPage;
  }
  
  // Get the slice of items for the current page
  const items = filteredItems.slice(pagination.offset, pagination.offset + pagination.itemsPerPage);
  
  const response = {
    items,
    pagination: {
      currentPage: pagination.currentPage,
      totalPages: pagination.totalPages,
      totalItems: pagination.totalItems,
      itemsPerPage: pagination.itemsPerPage,
      hasNextPage: pagination.hasNextPage,
      hasPrevPage: pagination.hasPrevPage,
      nextPage: pagination.nextPage,
      prevPage: pagination.prevPage,
    }
  };
  
  console.log('API Response:', {
    requestedPage: page,
    returnedPage: pagination.currentPage,
    totalItems: pagination.totalItems,
    totalPages: pagination.totalPages,
    itemsReturned: items.length,
    hasMore: pagination.hasNextPage
  });
  
  res.json(response);
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    pagination: 'page-based',
    message: 'Server is running correctly',
    itemCount: TOTAL_COUNT
  });
});

// Default route serves the frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(` Server running at http://localhost:${PORT}`);
  console.log(` API endpoints:`);
  console.log(`   GET /api/items - Paginated items`);
  console.log(`   GET /api/health - Health check`);
  console.log(` Pagination: Fixed page-based with correct math`);
});