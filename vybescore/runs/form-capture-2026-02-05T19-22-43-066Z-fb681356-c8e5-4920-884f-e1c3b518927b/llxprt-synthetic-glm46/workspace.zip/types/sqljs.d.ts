declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }
  
  export default function sqliteInitFactory(): Promise<typeof sqlite>;
  export const sqlite: {
    Database: {
      new(data?: ArrayBuffer): Database;
    };
  };
}