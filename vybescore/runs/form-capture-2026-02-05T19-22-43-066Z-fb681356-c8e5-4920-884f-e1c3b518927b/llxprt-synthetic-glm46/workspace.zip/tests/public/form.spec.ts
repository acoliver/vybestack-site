import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase, shutdown } from '../../src/server';

let server: ReturnType<typeof import('http').createServer>.listen;

beforeAll(async () => {
  await initializeDatabase();
  server = (app as any).listen();
});

afterAll(async () => {
  if (server) {
    server.close();
  }
  await shutdown();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app as any).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app as any)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'United States',
        email: 'john@example.com',
        phone: '+1 555 123 4567'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify data was saved
    const thankYouResponse = await request(app as any).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    // Submit invalid data to test validation
    const invalidResponse = await request(app as any)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: 'invalid-email',
        phone: ''
      });
    
    expect(invalidResponse.status).toBe(200);
    const $ = cheerio.load(invalidResponse.text);
    expect($('.error-list').length).toBe(1);
    
    // Test international formats
    const internationalResponse = await request(app as any)
      .post('/submit')
      .send({
        firstName: 'Pierre',
        lastName: 'Dupont',
        streetAddress: '123 Rue de la Paix',
        city: 'Paris',
        stateProvince: 'Île-de-France',
        postalCode: '75001',
        country: 'France',
        email: 'pierre@example.com',
        phone: '+33 1 42 86 83 26'
      });
    
    expect(internationalResponse.status).toBe(302);
    expect(internationalResponse.headers.location).toBe('/thank-you');
  });
});
