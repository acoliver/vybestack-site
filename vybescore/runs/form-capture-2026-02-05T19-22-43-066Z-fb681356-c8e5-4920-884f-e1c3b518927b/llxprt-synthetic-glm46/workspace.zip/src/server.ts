import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import sqliteInitFactory, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const dbSchemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');

const port = process.env.PORT || 3535;
const app = express();

// Configure Express
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Database management
let db: Database | null = null;
let dbInitialized = false;

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await sqliteInitFactory();
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer.buffer.slice(dbBuffer.byteOffset, dbBuffer.byteOffset + dbBuffer.byteLength));
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(dbSchemaPath, 'utf8');
      db.exec(schema);
    }
    
    dbInitialized = true;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (db && dbInitialized) {
    try {
      const dbData = db.export();
      fs.writeFileSync(dbPath, Buffer.from(dbData));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Validation utilities
function validateField(name: string, value: string): string[] {
  const errors: string[] = [];
  
  switch (name) {
    case 'firstName':
    case 'lastName':
      if (!value.trim()) {
        errors.push(`${name} is required`);
      }
      break;
      
    case 'email':
      if (!value.trim()) {
        errors.push('Email is required');
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        errors.push('Please enter a valid email address');
      }
      break;
      
    case 'phone':
      if (!value.trim()) {
        errors.push('Phone number is required');
      } else if (!/^[+]?[\d\s()\-]+$/.test(value)) {
        errors.push('Please enter a valid phone number');
      }
      break;
      
    case 'postalCode':
      if (!value.trim()) {
        errors.push('Postal code is required');
      } else if (!/^[a-zA-Z0-9\s-]+$/.test(value)) {
        errors.push('Postal code can only contain letters, numbers, spaces, and dashes');
      }
      break;
      
    default:
      if (!value.trim()) {
        errors.push(`${name} is required`);
      }
  }
  
  return errors;
}

function validateForm(formData: Record<string, string>): Record<string, string[]> {
  const errors: Record<string, string[]> = {};
  
  for (const [name, value] of Object.entries(formData)) {
    const fieldErrors = validateField(name, value);
    if (fieldErrors.length > 0) {
      errors[name] = fieldErrors;
    }
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: null, values: {} });
});

app.post('/submit', (req, res) => {
  if (!db || !dbInitialized) {
    return res.status(500).render('form', {
      errors: { general: ['Database not available'] },
      values: req.body
    });
  }
  
  const formData = req.body;
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    // Flatten errors for display
    const errorMessages = Object.values(errors).flat();
    return res.render('form', { errors: errorMessages, values: formData });
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: { general: ['Failed to save your submission. Please try again.'] },
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  // For simplicity, we'll just use a generic name since we don't track session
  res.render('thank-you', { firstName: 'friend' });
});

// Server lifecycle management
let server: ReturnType<typeof app.listen>;

async function startServer(): Promise<void> {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close();
  }
  if (db && dbInitialized) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

// Handle graceful shutdown
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export { app, initializeDatabase, shutdown };
