/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses the standard Base64 alphabet and validates input.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters and proper structure
  const base64Pattern = /^[A-Za-z0-9+/]+(={0,2})?$/;
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for correct padding
  const paddingLength = input.match(/=+$/)?.[0].length || 0;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 input: excessive padding');
  }
  
  // Check that padding only occurs at the end if present
  if (paddingLength > 0 && input.indexOf('=') !== input.length - paddingLength) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }
  
  // For padded inputs, check that total length is consistent with padding rules
  if (paddingLength > 0 && input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: padding length mismatch');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: malformed data');
  }
}
