#!/usr/bin/env node

import { promises as fs } from 'node:fs';
import { type ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  let format: 'markdown' | 'text' = 'markdown';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--format') {
      const nextArg = args[i + 1];
      if (nextArg === 'markdown' || nextArg === 'text') {
        format = nextArg;
        i++;
      } else {
        console.error(`Unsupported format: ${nextArg}`);
        process.exit(1);
      }
    } else if (args[i] === '--output') {
      output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  return { dataFile, format, output, includeTotals };
}

async function readDataFile(filePath: string): Promise<ReportData> {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      throw new Error('Invalid report data structure');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry in report data');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON file: ${filePath}`);
      console.error('Please ensure the file contains valid JSON');
    } else {
      console.error(`Error reading file: ${filePath}`);
      console.error((error as Error).message);
    }
    process.exit(1);
  }
}

async function main() {
  const args = process.argv;
  const { dataFile, format, output, includeTotals } = parseArgs(args);
  
  const data = await readDataFile(dataFile);
  
  let result: string;
  if (format === 'markdown') {
    result = renderMarkdown(data, includeTotals);
  } else {
    result = renderText(data, includeTotals);
  }
  
  if (output) {
    await fs.writeFile(output, result, 'utf-8');
    console.log(`Report written to ${output}`);
  } else {
    console.log(result);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});