import type { ReportData } from '../types.js';

export function renderText(data: ReportData, includeTotals = false): string {
  let output = '';
  
  output += `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `Total: $${total.toFixed(2)}\n`;
  }
  
  return output;
}