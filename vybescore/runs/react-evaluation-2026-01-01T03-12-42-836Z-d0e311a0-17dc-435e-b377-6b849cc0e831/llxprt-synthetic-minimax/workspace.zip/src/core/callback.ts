import { 
  UnsubscribeFn, 
  Observer, 
  Subject,
  UpdateFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const subject: Subject = {
    name: 'callback',
    value,
    dependents: new Set(),
  }
  
  const observer: Observer = {
    name: 'callback',
    updateFn,
    value: value,
    isCallback: true,
  }
  
  function executeCallback(): void {
    // Execute the callback function to establish dependencies
    const previous = getActiveObserver()
    try {
      // Set this observer as active to track dependencies
      setActiveObserver(observer)
      const newValue = updateFn(observer.value)
      subject.value = newValue
      observer.value = newValue
    } finally {
      // Restore previous observer context
      setActiveObserver(previous)
    }
  }
  
  // Execute to establish initial dependencies
  executeCallback()
  
  const unsubscribe = () => {
    // Remove this callback from all subjects that track it
    if (subject.dependents) {
      subject.dependents.clear()
    }
  }
  
  return unsubscribe
}
