import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver,
  setActiveObserver,
  recordDependency,
  EqualFn,
  updating
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const subject: Subject = {
    name: options?.name,
    value,
    dependents: new Set(),
  }
  
  const observer: Observer = {
    name: options?.name,
    updateFn,
    value,
    isCallback: false,
  }
  
  // Cache for memoization
  let cachedValue: T | undefined = value
  
  const getter: GetterFn<T> = () => {
    // Record this computed as a dependency when accessed
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      recordDependency(subject, activeObserver)
    }
    
    // Check if we're already being updated to prevent infinite recursion
    if (updating.has(observer)) {
      return cachedValue as T
    }
    
    // Always recalculate to get fresh dependencies
    const previous = getActiveObserver()
    setActiveObserver(observer as Observer)
    try {
      const newValue = updateFn(observer.value)
      cachedValue = newValue
      subject.value = newValue
      observer.value = newValue
      return newValue
    } finally {
      setActiveObserver(previous)
    }
  }
  
  return getter
}
