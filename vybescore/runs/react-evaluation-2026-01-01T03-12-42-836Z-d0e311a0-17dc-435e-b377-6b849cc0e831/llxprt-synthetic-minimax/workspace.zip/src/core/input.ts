import {
  InputPair,
  Subject,
  recordDependency,
  notifyDependents,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject = {
    name: options?.name,
    value,
    dependents: new Set(),
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Record this subject as a dependency of the current observer
      recordDependency(subject, observer)
    }
    return subject.value as T
  }

  const setter: SetterFn<T> = (nextValue) => {
    if (nextValue === subject.value) {
      return subject.value as T
    }
    subject.value = nextValue
    // Notify all observers that depend on this input
    notifyDependents(subject)
    return subject.value as T
  }

  return [getter, setter]
}
