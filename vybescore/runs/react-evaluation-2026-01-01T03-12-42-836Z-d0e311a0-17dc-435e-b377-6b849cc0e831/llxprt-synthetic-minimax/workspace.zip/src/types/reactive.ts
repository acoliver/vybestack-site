/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  updateFn: (value?: unknown) => unknown
  value?: unknown
  isCallback?: boolean
  unsubscribe?: UnsubscribeFn
}

export interface Subject {
  name?: string
  value?: unknown
  dependents: Set<Observer>
}

// Global reactive system state
export let currentObserver: Observer | undefined = undefined
export const updating = new WeakSet<Observer>()

export function getActiveObserver(): Observer | undefined {
  return currentObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  currentObserver = observer
}

export function recordDependency(subject: Subject, observer: Observer): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function notifyDependents(subject: Subject): void {
  if (!subject.dependents) return
  
  // Update all dependents - both computed values and callbacks
  const dependents = Array.from(subject.dependents)
  for (const dependent of dependents) {
    if (dependent.isCallback) {
      // Execute callback to establish dependencies
      const previous = currentObserver
      try {
        setActiveObserver(dependent)
        const newValue = dependent.updateFn(dependent.value)
        dependent.value = newValue
      } finally {
        setActiveObserver(previous)
      }
    } else {
      // Update computed values normally
      updateObserver(dependent)
    }
  }
}

export function updateObserver(observer: Observer): unknown {
  if (updating.has(observer)) {
    // Already being updated, prevent infinite recursion
    return observer.value
  }
  
  const previous = currentObserver
  updating.add(observer)
  try {
    currentObserver = observer
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    return newValue
  } finally {
    currentObserver = previous
    updating.delete(observer)
  }
}

export function unregisterObserver(subject: Subject, observer: Observer): void {
  if (subject.dependents) {
    subject.dependents.delete(observer)
  }
}
