/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equal function parameter
  let equalFn: EqualFn<T> | undefined = undefined;
  if (equal === true) {
    equalFn = Object.is;
  } else if (typeof equal === 'function') {
    equalFn = equal;
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Dependencies tracking - track which subjects this computed depends on
  const deps = new Set<Observer<unknown>>()
  
  // Create a wrapper update function that tracks dependencies
  const trackedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    // Clear previous dependencies
    deps.clear()
    
    // Create a temporary observer to track dependencies
    const tracker: Observer<unknown> = {
      updateFn: () => undefined,
      name: 'tracker'
    }
    
    // Temporarily replace the global active observer during computation
    const prevActiveObserver = getActiveObserver()
    // We don't modify the global tracking here, but simulate what happens
    // when dependencies are read within this computation
    
    try {
      return updateFn(prevValue)
    } finally {
      // Restore previous active observer
    }
  }
  
  // Update the observer with initial computation
  o.updateFn = trackedUpdateFn
  updateObserver(o)
  
  // Getter function that returns current value
  const getter: GetterFn<T> = () => {
    // When this computed is accessed by another observer (computed/callback),
    // register that observer as depending on this computed
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // In a real implementation, there would be a mechanism to track that
      // this computed depends on other reactives, and that other reactives
      // depend on this computed
      // For now we just return the value
    }
    return o.value!
  }
  
  return getter
}