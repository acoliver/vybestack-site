/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyCallbacks,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined

  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value,
    equalFn: equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subject.observer = observer
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(subject.value, nextValue)
    if (shouldUpdate) {
      subject.value = nextValue
      if (subject.observer) {
        updateObserver(subject.observer as Observer<unknown>)
      }
      // Also notify callbacks when input changes
      notifyCallbacks()
    }
    return subject.value
  }

  return [read, write]
}
