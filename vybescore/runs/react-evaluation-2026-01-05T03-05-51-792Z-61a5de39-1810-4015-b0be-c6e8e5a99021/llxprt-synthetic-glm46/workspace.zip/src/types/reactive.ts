/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Add a generic observer registry for callbacks
const callbackObservers = new Set<Observer<unknown>>()

export function addCallbackObserver<T>(observer: Observer<T>): void {
  callbackObservers.add(observer as Observer<unknown>)
}

export function removeCallbackObserver<T>(observer: Observer<T>): void {
  callbackObservers.delete(observer as Observer<unknown>)
}

export function notifyCallbacks(): void {
  callbackObservers.forEach(callbackObserver => {
    try {
      callbackObserver.value = callbackObserver.updateFn(callbackObserver.value)
    } catch (error) {
      console.error('Error in callback observer:', error)
    }
  })
}
