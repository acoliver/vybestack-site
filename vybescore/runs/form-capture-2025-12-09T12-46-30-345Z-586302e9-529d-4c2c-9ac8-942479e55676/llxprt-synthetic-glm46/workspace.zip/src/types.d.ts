declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    exec(sql: string): unknown[];
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array | number[]) => Database;
  }

  export const initSqlJs: (options?: { locateFile?: (file: string) => string }) => Promise<SqlJsStatic>;
}