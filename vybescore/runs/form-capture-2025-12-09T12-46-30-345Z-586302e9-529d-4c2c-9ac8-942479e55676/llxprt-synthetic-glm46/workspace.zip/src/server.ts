import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';

// Import sql.js types
import { initSqlJs, Database as SqlJsDatabase } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3535;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

class FormCaptureServer {
  private app: express.Application;
  private db: SqlJsDatabase | null = null;

  constructor() {
    this.app = express();
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', 
      process.env.NODE_ENV === 'development' 
        ? path.join(__dirname, 'templates')
        : path.join(__dirname, '..', 'templates')
    );
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Initialize sql.js
      const SQL = await initSqlJs({
        locateFile: (file: string) => {
          return path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file);
        },
      });

      // Try to load existing database
      try {
        const dbFile = await fs.readFile(DB_PATH);
        this.db = new SQL.Database(dbFile);
        console.log('Loaded existing database');
      } catch (error) {
        // Database doesn't exist, create a new one
        this.db = new SQL.Database();
        console.log('Created new database');
        const schema = await fs.readFile(SCHEMA_PATH, 'utf8');
        this.db?.run(schema);
        console.log('Applied schema to new database');
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) return;

    try {
      const data = this.db.export();
      await fs.writeFile(DB_PATH, Buffer.from(data));
      console.log('Database saved successfully');
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateForm(formData: FormData): ValidationErrors {
    const errors: ValidationErrors = {};

    if (!formData.firstName.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!formData.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!formData.streetAddress.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!formData.city.trim()) {
      errors.city = 'City is required';
    }

    if (!formData.stateProvince.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }

    if (!formData.postalCode.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    }

    if (!formData.country.trim()) {
      errors.country = 'Country is required';
    }

    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else {
      // Basic email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        errors.email = 'Email appears to be invalid';
      }
    }

    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else {
// Phone validation - allow digits, spaces, parentheses, dashes, and leading +
      const phoneRegex = /^\+?[0-9\s()\-.]+$/;
      if (!phoneRegex.test(formData.phone)) {
        errors.phone = 'Phone number contains invalid characters';
      }
    }

    // Postal code validation - allow alphanumeric characters and spaces
    if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
      errors.postalCode = 'Postal code contains invalid characters';
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - Display the contact form
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req, res) => {
      if (!this.db) {
        res.status(500).send('Database not initialized');
        return;
      }

      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);

      if (Object.keys(errors).length > 0) {
        // Validation failed, redisplay form with errors
        const errorMessages = Object.values(errors);
        res.status(400).render('form', {
          errors: errorMessages,
          values: formData
        });
        return;
      }

      try {
        // Insert into database
        this.db.run(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `, [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);

        // Save database
        await this.saveDatabase();

        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while processing your submission. Please try again.'],
          values: formData
        });
      }
    });

    // GET /thank-you - Display thank you page
    this.app.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName as string || 'friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    try {
      console.log('Initializing database...');
      await this.initializeDatabase();
      
      console.log('Setting up routes...');
      this.setupRoutes();
      
      const server = this.app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
      });

      // Handle graceful shutdown
      const gracefulShutdown = async () => {
        console.log('Shutting down gracefully...');
        
        server.close(() => {
          console.log('HTTP server closed');
        });

        if (this.db) {
          try {
            await this.saveDatabase();
            this.db.close();
            this.db = null;
            console.log('Database closed');
          } catch (error) {
            console.error('Error closing database:', error);
          }
        }

        process.exit(0);
      };

      process.on('SIGTERM', gracefulShutdown);
      process.on('SIGINT', gracefulShutdown);

    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }
}

// Start the server
const server = new FormCaptureServer();
server.start().catch(error => {
  console.error('Failed to start application:', error);
  process.exit(1);
});