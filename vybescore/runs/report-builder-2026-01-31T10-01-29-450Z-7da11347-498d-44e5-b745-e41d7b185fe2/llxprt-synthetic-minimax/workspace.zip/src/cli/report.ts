import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, RenderOptions, ReportFormat } from '../types.js';
import { renderMarkdown, renderText } from '../formats/index.js';

function parseArguments(args: string[]): {
  inputPath: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputPath = args[2];
  
  // Parse arguments manually
  let format: ReportFormat | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[i + 1] as ReportFormat;
      i++; // Skip next argument as it's the value
    } else if (arg === '--output') {
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    throw new Error('--format is required');
  }
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  return {
    inputPath,
    format,
    outputPath,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label is required and must be a string`);
      }
      
      if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}].amount is required and must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON: unable to parse file');
    }
    
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    
    throw error;
  }
}

function renderReport(data: ReportData, format: ReportFormat, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown.format(data, options);
    case 'text':
      return renderText.format(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const { inputPath, format, outputPath, includeTotals } = parseArguments(args);
    
    const data = loadReportData(inputPath);
    const output = renderReport(data, format, { includeTotals });
    
    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
      process.stdout.write('\n');
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
