/**
 * Finds words starting with the given prefix, excluding listed exceptions.
 * Uses regex to match word boundaries and prefix.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words with the prefix
  // \b ensures we match whole words
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when:
 * - It appears after a digit
 * - It's not at the start of the string
 * Returns the full match (digit + token).
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, not at string start
  // Use word boundary to ensure we don't match partial words
  const pattern = new RegExp(`\\d${escapedToken}\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Validates password strength:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab, abcabc)
  // Look for patterns where a substring of length 2-4 repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const substr = value.slice(i, i + len);
      const next = value.slice(i + len, i + len * 2);
      if (substr === next) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (simplified but comprehensive)
  // Supports full notation and :: shorthand
  // Excludes IPv4 addresses
  
  // First, check for IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 patterns
  // Full format: 8 groups of 1-4 hex digits separated by colons
  const ipv6Full = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed format with :: (replaces one or more groups)
  const ipv6Compressed = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with IPv4 embedded (e.g., ::ffff:192.168.1.1)
  const ipv6EmbeddedIPv4 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check for embedded IPv4 (this is still valid IPv6)
  if (ipv6EmbeddedIPv4.test(value)) {
    return true;
  }
  
  // Check for pure IPv6 (excluding pure IPv4)
  if ((ipv6Full.test(value) || ipv6Compressed.test(value)) && !ipv4Pattern.test(value)) {
    // Additional check: ensure it looks like IPv6 (contains colons)
    if (value.includes(':')) {
      return true;
    }
  }
  
  return false;
}
