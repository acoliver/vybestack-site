export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Main email pattern:
  // - Local part: allowed chars (letters, digits, ._%+-), but no consecutive dots, no leading/trailing dot
  // - @ symbol
  // - Domain: letters, digits, hyphens, dots (but no underscores)
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks:
  // - No double dots in local part or domain
  // - No trailing dot before @
  // - No underscore in domain
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for underscore in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Check for consecutive special chars in local part
  const localPart = value.split('@')[0];
  if (localPart && /[._%+-]{2,}/.test(localPart)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let numberDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    numberDigits = digitsOnly.slice(1);
  } else if (digitsOnly.length > 11) {
    // Too long even with country code
    return false;
  }
  
  // Must be exactly 10 digits now
  if (numberDigits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = numberDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = numberDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Match the format more strictly to ensure proper separators
  // Allow: (XXX) XXX-XXXX, XXX-XXX-XXXX, XXXXXXXXX, +1-XXX-XXX-XXXX, etc.
  const formatRegex = /^\+?1?[\s\-.]?\(?\d{3}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}$/;
  
  return formatRegex.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles like:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Also need to handle the case where country code is omitted
  // In that case, trunk prefix 0 is required before area code
  const withoutCountryRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  const withCountryRegex = /^\+54(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Try matching with country code first
  const withCountryMatch = cleaned.match(withCountryRegex);
  if (withCountryMatch) {
    const areaCode = withCountryMatch[1];
    const subscriber = withCountryMatch[2];
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    // Subscriber must be 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    return true;
  }
  
  // Try matching without country code (must have trunk prefix 0)
  const withoutCountryMatch = cleaned.match(withoutCountryRegex);
  if (withoutCountryMatch) {
    const areaCode = withoutCountryMatch[1];
    const subscriber = withoutCountryMatch[2];
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    // Subscriber must be 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Pattern: unicode letters, apostrophes, hyphens, spaces
  // Must have at least one letter
  // No digits or special symbols
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // No digits (should be caught by regex but double check)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 4, 13-19 digits
  const visaRegex = /^4\d{12}(?:\d{3,6})?$/;
  
  // Mastercard: 51-55 or 2221-2720, 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;
  
  // AmEx: 34 or 37, 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  let isValid = false;
  
  if (visaRegex.test(cleaned)) {
    if (cleaned.length >= 13 && cleaned.length <= 19) {
      isValid = true;
    }
  } else if (mastercardRegex.test(cleaned) && cleaned.length === 16) {
    isValid = true;
  } else if (amexRegex.test(cleaned) && cleaned.length === 15) {
    isValid = true;
  }
  
  if (!isValid) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
