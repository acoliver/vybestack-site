/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences if omitted
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/[ \t]+/g, ' ').trim();
  
  // Insert space after sentence endings if missing (before next letter)
  normalized = normalized.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Common abbreviations to preserve (lowercase after them)
  const abbreviations = [
    'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Rev', 'Gen', 'Sen', 'Rep',
    'St', 'Ave', 'Blvd', 'Rd', 'Ln', 'etc', 'eg', 'ie', 'vs', 'approx',
    'dept', 'univ', 'assn', 'bros', 'co', 'corp', 'inc', 'ltd', 'no',
    'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec',
    'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'
  ];
  
  // Build a regex pattern for abbreviations
  const abbrPattern = abbreviations.join('|');
  
  // Capitalize first character of string
  const result = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence endings, but not after abbreviations
  // Split by sentence boundaries and process
  const sentences = result.split(/([.!?]\s+)/);
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    // If this is a sentence ending followed by space
    if (/[.!?]\s+/.test(sentence)) {
      continue;
    }
    
    // If this sentence starts with an abbreviation, skip capitalization
    if (i > 0 && new RegExp(`^(${abbrPattern})\\.`, 'i').test(sentence)) {
      continue;
    }
    
    // If this is the start of a new sentence (after punctuation), capitalize
    if (i > 0 && sentences[i - 1] && /[.!?]/.test(sentences[i - 1])) {
      // Check if previous was an abbreviation
      const prevSentence = sentences[i - 1];
      const abbrMatch = prevSentence.match(new RegExp(`(${abbrPattern})\\.?$`, 'i'));
      
      if (!abbrMatch) {
        // Capitalize first letter
        sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
    }
  }
  
  return sentences.join('');
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, www
  // Exclude trailing punctuation
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"'(){}[\]]+?(?=(?:[.,!?;:)]?(?:\s|$))|[^\s.,!?;:<>"'(){}[\]]*$)/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:)+]+$/, ''));
}

/**
 * Forces all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch existing https://
  return text.replace(/http(?!s):\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for http://example.com URLs
  const pattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(pattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if this is example.com domain
    if (host === 'example.com' || host.startsWith('example.com:')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = [
        'cgi-bin',
        '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
      ];
      
      const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
      const hasDynamicHint = dynamicHints.some(hint => path.toLowerCase().includes(hint));
      
      if (path.startsWith('/docs/') && !hasQueryString && !hasDynamicHint) {
        // Rewrite host to docs.example.com
        const newHost = host.replace(/^example\.com/, 'docs.example.com');
        return newProtocol + newHost + path;
      }
    }
    
    // Just upgrade the protocol
    return newProtocol + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
