import express from 'express';
import path from 'path';
import * as fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define types for form submission
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
// Determine the correct path for templates based on execution context
const isCompiledInDist = __dirname.includes('/dist/');
const templatesPath = isCompiledInDist ? 
  path.join(__dirname, 'templates') : 
  path.join(__dirname, 'templates');
app.set('views', templatesPath);

// Database instance
let db: Database | null = null;

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    if (fs.existsSync(dbPath)) {
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
    } else {
      db = new SQL.Database();
    }
    
    // Run schema to ensure tables exist
    const schema = fs.readFileSync(
      path.join(__dirname, '..', 'db', 'schema.sql'),
      'utf8'
    );
    if (!db) throw new Error('Database not initialized');
    db.run(schema);
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateForm(formData: Pick<FormData, Exclude<keyof FormData, 'created_at'>>): ValidationResult {
  const errors: Record<string, string> = {};

  // Required fields validation
  if (!formData.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!formData.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!formData.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!formData.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!formData.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  } else {
    // Allow alphanumeric characters, spaces, and dashes
    if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postal_code)) {
      errors.postal_code = 'Invalid postal code format';
    }
  }
  
  if (!formData.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Invalid email format';
    }
  }
  
  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Allow digits, spaces, parentheses, dashes, and a leading +
    if (!/^\+?[0-9\s()-]+$/.test(formData.phone)) {
      errors.phone = 'Invalid phone number format';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
// Home page with form
app.get('/', (req, res) => {
  res.render('form', {
    formData: {},
    errors: {}
  });
});

// Form submission handler
app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      formData,
      errors: validation.errors
    });
  }
  
  try {
    if (!db) throw new Error('Database not initialized');
    
    // Insert submission into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      formData,
      errors: { 
        general: 'An error occurred while submitting the form. Please try again.' 
      }
    });
  }
});

// Thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

// Handle process signals for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start the application
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
