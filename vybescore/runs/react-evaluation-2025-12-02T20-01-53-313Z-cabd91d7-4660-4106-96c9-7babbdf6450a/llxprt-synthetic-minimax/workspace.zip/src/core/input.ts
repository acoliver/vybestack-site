/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Registry for tracking disposed observers for cleanup
import { disposedObservers } from './disposed.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const dependents = new Set<ObserverR>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !disposedObservers.has(observer)) {
      dependents.add(observer)
      s.observer = observer  // Store just the ObserverR part
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Only notify dependents if the value actually changed
    if (_equal && typeof _equal === 'function' ? !_equal(oldValue, nextValue) : oldValue !== nextValue) {
      // Create a copy of dependents to avoid issues while iterating
      const dependentsToNotify = Array.from(dependents)
      // Filter out disposed observers
      const activeDependents = dependentsToNotify.filter(observer => !disposedObservers.has(observer))
      
      activeDependents.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
      })
      
      // Always clean up disposed observers from the dependents set
      const allDependents = Array.from(dependents)
      allDependents.forEach(observer => {
        if (disposedObservers.has(observer)) {
          dependents.delete(observer)
        }
      })
    }
    
    return s.value
  }

  return [read, write]
}
