/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

// Import disposed observers registry from disposed module
import { disposedObservers } from './disposed.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let cachedValue = value
  
  const dependents = new Set<Observer<unknown>>()

  const o: Observer<T> = {
    name: options?.name,
    updateFn: () => {
      const oldValue = cachedValue
      const computedValue = updateFn()
      cachedValue = computedValue
      
      // Notify dependents only if value actually changed
      if (_equal && typeof _equal === 'function' ? !_equal(oldValue as T, computedValue) : oldValue !== computedValue) {
        const dependentsArray = Array.from(dependents)
        // Filter out disposed observers
        const activeDependents = dependentsArray.filter(dependent => !disposedObservers.has(dependent))
        
        activeDependents.forEach(dependent => {
          updateObserver(dependent as Observer<T>)
        })
        
        // Clean up disposed observers from dependents set
        const disposedDependents = dependentsArray.filter(dependent => disposedObservers.has(dependent))
        disposedDependents.forEach(dependent => {
          dependents.delete(dependent)
        })
      }
      
      return computedValue
    },
  }

  const getValue: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      dependents.add(activeObserver as Observer<unknown>)
    }
    
    // Recalculate the computed value
    updateObserver(o)
    return cachedValue!
  }
  
  return getValue
}
