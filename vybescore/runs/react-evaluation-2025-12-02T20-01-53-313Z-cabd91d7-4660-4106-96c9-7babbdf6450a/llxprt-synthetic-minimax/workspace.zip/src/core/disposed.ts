/**
 * Registry for tracking disposed observers for cleanup.
 * This module is shared to avoid circular dependencies.
 */

export const disposedObservers = new WeakSet<object>()