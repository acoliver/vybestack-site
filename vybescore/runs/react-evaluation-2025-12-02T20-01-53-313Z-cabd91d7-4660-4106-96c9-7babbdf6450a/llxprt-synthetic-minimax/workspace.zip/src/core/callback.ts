/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Registry for tracking disposed observers for cleanup
import { disposedObservers } from './disposed.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    updateFn: () => {
      if (disposed) return value as T
      return updateFn()
    },
    value,
  }
  
  // Execute the callback immediately to establish dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Add to disposed observers to prevent future updates
    disposedObservers.add(observer)
  }
}
