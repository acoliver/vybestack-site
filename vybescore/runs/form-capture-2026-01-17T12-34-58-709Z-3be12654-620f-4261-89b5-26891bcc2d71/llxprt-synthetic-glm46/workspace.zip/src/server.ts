import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Import types
import type { Database } from 'sql.js';



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

let db: Database | null = null;

// Database initialization
const initializeDatabase = async (): Promise<void> => {
  try {
    // Load sql.js wasm module
    const initSqlJs = await import('sql.js');
    const SQL = initSqlJs.default;
    
    // Initialize sql.js with WASM
    const sql = await SQL();
    
    // Read existing database file or create new one
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }
    
    db = new sql.Database(dbData);
    
    // Initialize schema
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    if (fs.existsSync(schemaPath) && db) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

// Save database to disk
const saveDatabase = (): void => {
  if (!db) return;
  
  try {
    // Ensure data directory exists
    const dataDir = path.join(__dirname, '../data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Write database to file
    const dbData = db.export();
    fs.writeFileSync(dbPath, Buffer.from(dbData));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
};

// Validation functions
const validateRequired = (value: string, fieldName: string): ValidationError | null => {
  if (!value || value.trim() === '') {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
};

const validateEmail = (email: string): ValidationError | null => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
};

const validatePhone = (phone: string): ValidationError | null => {
  const phoneRegex = /^[+]?[0-9\s()-]+$/;
  if (!phoneRegex.test(phone.trim())) {
    return { field: 'phone', message: 'Please enter a valid phone number' };
  }
  return null;
};

const validatePostalCode = (postalCode: string): ValidationError | null => {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  if (!postalRegex.test(postalCode.trim())) {
    return { field: 'postalCode', message: 'Please enter a valid postal code' };
  }
  return null;
};

const validateFormData = (data: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];
  
  const requiredError = validateRequired(data.firstName, 'First Name');
  if (requiredError) errors.push(requiredError);
  
  const requiredError2 = validateRequired(data.lastName, 'Last Name');
  if (requiredError2) errors.push(requiredError2);
  
  const requiredError3 = validateRequired(data.streetAddress, 'Street Address');
  if (requiredError3) errors.push(requiredError3);
  
  const requiredError4 = validateRequired(data.city, 'City');
  if (requiredError4) errors.push(requiredError4);
  
  const requiredError5 = validateRequired(data.stateProvince, 'State/Province/Region');
  if (requiredError5) errors.push(requiredError5);
  
  const requiredError6 = validateRequired(data.postalCode, 'Postal/Zip Code');
  if (requiredError6) errors.push(requiredError6);
  
  const requiredError7 = validateRequired(data.country, 'Country');
  if (requiredError7) errors.push(requiredError7);
  
  const emailError = validateEmail(data.email);
  if (emailError) errors.push(emailError);
  
  const phoneError = validatePhone(data.phone);
  if (phoneError) errors.push(phoneError);
  
  const postalError = validatePostalCode(data.postalCode);
  if (postalError) errors.push(postalError);
  
  return errors;
};

// Save submission to database
const saveSubmission = (formData: FormData): void => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    console.log('Submission saved successfully');
  } catch (error) {
    console.error('Failed to save submission:', error);
    throw error;
  }
};

// Routes
app.get('/', (request: Request, response: Response) => {
  response.render('form', {
    title: 'International Contact Form',
    errors: [],
    formData: {}
  });
});

app.post('/submit', (request: Request, response: Response) => {
  const formData: FormData = {
    firstName: request.body.firstName || '',
    lastName: request.body.lastName || '',
    streetAddress: request.body.streetAddress || '',
    city: request.body.city || '',
    stateProvince: request.body.stateProvince || '',
    postalCode: request.body.postalCode || '',
    country: request.body.country || '',
    email: request.body.email || '',
    phone: request.body.phone || ''
  };

  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    response.status(400).render('form', {
      title: 'International Contact Form',
      errors,
      formData
    });
    return;
  }

  // Save to database
  try {
    saveSubmission(formData);
  } catch (error) {
    console.error('Failed to save submission:', error);
    response.status(500).render('form', {
      title: 'International Contact Form',
      errors: [{ field: 'general', message: 'An error occurred while saving your submission. Please try again.' }],
      formData
    });
    return;
  }

  response.redirect('/thank-you');
});

app.get('/thank-you', (request: Request, response: Response) => {
  response.render('thank-you', {
    title: 'Thank You!'
  });
});

// Start server
const startServer = async (): Promise<void> => {
  try {
    await initializeDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Graceful shutdown
const gracefulShutdown = (): void => {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
