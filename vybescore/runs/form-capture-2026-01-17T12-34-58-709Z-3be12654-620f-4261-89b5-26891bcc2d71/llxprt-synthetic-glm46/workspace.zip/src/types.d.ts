// Import types from @types/sql.js
export type { Database, Statement } from 'sql.js';