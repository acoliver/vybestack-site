#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, SupportedFormat } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: SupportedFormat;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: 'markdown',
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      const formatValue = argv[i + 1];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      
      args.format = formatValue as SupportedFormat;
      i++; // Skip next argument since we consumed it
    } else if (arg === '--output') {
      const outputValue = argv[i + 1];
      if (!outputValue) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      
      args.output = outputValue;
      i++; // Skip next argument since we consumed it
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // This is the data file
      args.dataFile = arg;
    }
  }

  if (!args.dataFile) {
    console.error('Error: data file argument is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return args;
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i}: missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i}: missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
      process.exit(1);
    }
    
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    
    throw error;
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = loadAndValidateData(args.dataFile);
  
  let output: string;
  
  if (args.format === 'markdown') {
    output = renderMarkdown(data, { includeTotals: args.includeTotals });
  } else if (args.format === 'text') {
    output = renderText(data, { includeTotals: args.includeTotals });
  } else {
    console.error(`Error: Unsupported format: ${args.format}`);
    process.exit(1);
  }
  
  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write to file "${args.output}": ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    // Write to stdout
    console.log(output);
  }
}

main();
