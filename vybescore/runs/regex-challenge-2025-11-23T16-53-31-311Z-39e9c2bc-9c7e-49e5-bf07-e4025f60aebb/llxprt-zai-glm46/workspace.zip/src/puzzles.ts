/**
 * Match words starting with the prefix but excluding banned words.
 * Returns array of matched words that start with the prefix but are not in exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  // \b ensures we match whole words only
  const prefixedWordsRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    const hasException = exceptions.some(exception => 
      exception.toLowerCase() === lowerWord
    );
    return !hasException;
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to position the token correctly.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Lookbehind for digit, include the digit in the match
  // Use negative lookahead to ensure we don't match at the very beginning
  const embeddedTokenRegex = new RegExp(`(?<!^)(\\d${escapedToken})`, 'g');
  
  const matches = text.match(embeddedTokenRegex) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=\\[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (pattern like 'abab', '1212', etc.)
  // This catches sequences where a pattern of 2+ characters repeats immediately
  const repeatedSequenceRegex = /(..+)\1+/;
  
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  // Additional check for sequences like 'aaa', 'bbb' (3+ repeated characters)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true if the string contains a valid IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  const ipv6Patterns = [
    // Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
    /(?:^|[^a-f0-9:])((?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4})(?![a-f0-9:])/i,
    
    // Shortened with :: (multiple groups)
    /(?:^|[^a-f0-6:])((?:[0-9a-f]{1,4}:){0,6}::(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})(?![a-f0-6:])/i,
    
    // IPv4-mapped IPv6: ::ffff:192.168.1.1
    /(?:^|[^a-f0-6:])::ffff:(?:\d{1,3}\.){3}\d{1,3}/i,
    
    // IPv4-embedded: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:192.168.1.1
    /(?:^|[^a-f0-6:])((?:[0-9a-f]{1,4}:){5,6}(?:\d{1,3}\.){3}\d{1,3})(?![a-f0-6:])/i,
  ];
  
  // Check if any IPv6 pattern matches
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Make sure it's not just IPv4
      const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
      const match = value.match(pattern);
      if (match && !ipv4Pattern.test(match[0])) {
        return true;
      }
    }
  }
  
  // Special case: just :: (which is a valid IPv6 address)
  if (/::/.test(value)) {
    // Make sure we're not matching something like "http://"
    if (!/https?:\/\//.test(value)) {
      return true;
    }
  }
  
  return false;
}