/**
 * Capitalize the first character of each sentence.
 * Preserves spacing rules and handles abbreviations when possible.
 * Inserts exactly one space between sentences even if input omitted it.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }

  // Split on sentence endings (.?!)
  return text
    .split(/([.!?])/)
    .map((part, index) => {
      if (index === 0) {
        // First part - just capitalize first letter
        return part.charAt(0).toUpperCase() + part.slice(1);
      } else if (index % 2 === 0 && part.trim()) {
        // Text part after punctuation - capitalize first non-space character
        return part.replace(/^(\s*)(.)/, (match, spaces, firstChar) => {
          return spaces + firstChar.toUpperCase();
        });
      }
      return part;
    })
    .join('')
    // Fix spacing: ensure single space after sentence punctuation if there's text
    .replace(/([.!?])(?=\S)/g, '$1 ')
    // Collapse multiple spaces
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches common URL formats including query strings
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs (but keep query strings)
  return matches.map(url => {
    return url.replace(/[.,;:!?)]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://... with special handling for docs paths.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /http:\/\/([^/]+)(\/[^?]*)/g,
    (match, host, path) => {
      // Always upgrade to https
      let newUrl = `https://${host}${path}`;
      
      // Check if we should rewrite the host for docs
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints that should prevent host rewrite
        const dynamicPatterns = [
          /\/cgi-bin\//i,
          /[?&=]/,           // query parameters
          /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i  // legacy extensions
        ];
        
        const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
        
        if (!shouldSkipHostRewrite) {
          // Rewrite host to docs.example.com
          newUrl = `https://docs.${host}${path}`;
        }
      }
      
      return newUrl;
    }
  );
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for specific month/day combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for February leap year handling
  const isLeapYear = (year: number) => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(parseInt(year, 10))) {
    if (day > 29) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}