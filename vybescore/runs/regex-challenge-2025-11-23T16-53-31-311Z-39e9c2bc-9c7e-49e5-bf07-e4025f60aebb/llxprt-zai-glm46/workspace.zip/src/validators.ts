export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, ');
  
  // Check minimum length (10 digits for US number, 11 for with country code)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }
  
  // Extract the actual 10-digit phone number
  const phoneNumber = digits.length === 11 ? digits.slice(1) : digits;
  
  // Check area code (can't start with 0 or 1)
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex
  const phoneRegex = /^\+?1?[\s-]?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep track of original format
  const cleanValue = value.replace(/[\s-]/g, ');
  
  // Argentine phone regex with optional country code, trunk prefix, and mobile indicator
  // When country code is omitted, must start with trunk prefix 0
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix (0)
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
// Regex that allows unicode letters, accents, apostrophes, hyphens, and spaces
  // Excludes digits, special symbols, and unusual character combinations
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  // Additional checks for obviously invalid patterns
  const invalidPatterns = [
    /\d/,                    // digits
    /[^\p{L}\p{M}'’\-\s]/u,  // symbols other than allowed ones
    /^(?:['’\-\s]+)$/,       // only separators
    /['’-]{2,}/,           // multiple consecutive separators
  ];
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Check for invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, ');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for major brands.
 * Accepts Visa, Mastercard, and American Express with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, ');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check length (13-19 digits for major cards)
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check prefixes for major card types
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidPrefix = visaRegex.test(cleanValue) || 
                        mastercardRegex.test(cleanValue) || 
                        amexRegex.test(cleanValue);
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}