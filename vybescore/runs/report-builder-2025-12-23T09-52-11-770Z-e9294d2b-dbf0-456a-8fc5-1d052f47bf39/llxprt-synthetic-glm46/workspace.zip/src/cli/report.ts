#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportFormat } from '../types.js';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';

function parseArguments(argv: string[]): {
  inputFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = argv.slice(2); // Skip node and script path
  
  if (args.length < 2) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  // Parse input file
  const inputFile = args[0];
  if (!inputFile) {
    console.error('Error: Input file is required');
    process.exit(1);
  }
  
  // Find --format argument
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required and must have a value');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as ReportFormat;
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  // Find optional --output argument
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 
    ? args[outputIndex + 1] 
    : undefined;
  
  // Check for --includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Input must be a JSON object');
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    console.error('Error: "title" field is required and must be a string');
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    console.error('Error: "summary" field is required and must be a string');
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    console.error('Error: "entries" field is required and must be an array');
    return false;
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${index} must be an object`);
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${index} must have a "label" string`);
      return false;
    }
    
    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${index} must have an "amount" number`);
      return false;
    }
  }
  
  return true;
}

function main() {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArguments(process.argv);
    
    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = readFileSync(inputFile, { encoding: 'utf-8' });
    } catch (error) {
      console.error(`Error: Could not read file "${inputFile}": ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${inputFile}": ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    // Validate data structure
    if (!validateReportData(data)) {
      console.error('Error: Invalid report data structure');
      process.exit(1);
    }
    
    // Create appropriate renderer
    let renderer;
    if (format === 'markdown') {
      renderer = new MarkdownRenderer();
    } else {
      renderer = new TextRenderer();
    }
    
    // Generate report
    const report = renderer.render(data, { includeTotals });
    
    // Output report
    if (outputPath) {
      try {
        writeFileSync(outputPath, report, { encoding: 'utf-8' });
        console.log(`Report written to ${outputPath}`);
      } catch (error) {
        console.error(`Error: Could not write to file "${outputPath}": ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(report);
    }
    
  } catch (error) {
    console.error(`Unexpected error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
