const value = '+54 341 123 4567';
const withSeparatorsRegex = /^(?:\+54[\s-]?)?0?[1-9]\d{1,3}(?:[\s-]\d{2,4}){0,2}\d{4,6}$/;
console.log('regex:', withSeparatorsRegex);
console.log('test result:', withSeparatorsRegex.test(value));