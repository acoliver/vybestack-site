/**
 * Capitalizes the first character of each sentence.
 * After .?! separators, inserts exactly one space and capitalizes.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing around sentence terminators
  const result = text
    // Replace multiple spaces with single space
    .replace(/\s+/g, ' ')
    // Ensure space after sentence terminators (but not after common abbreviations)
    .replace(/([.?!])(?!\s|$)(?![a-z])/g, '$1 ')
    // Remove space before sentence terminators
    .replace(/\s+([.?!])/g, '$1')
    // Trim leading/trailing spaces
    .trim();
  
  // Split into sentences using sentence terminators
  const sentences = result.split(/([.?!]\s*)/);
  
  // Process each sentence
  const processedSentences = sentences.map((sentence, _index) => {
    // Skip terminators and empty strings
    if (sentence.match(/^[.?!\s]+$/) || !sentence.trim()) {
      return sentence;
    }
    
    // Capitalize first letter of sentence
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  return processedSentences.join('');
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https protocols, domains, optional ports, paths, query params
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation but keep valid URL characters
    return url.replace(/[.,;:!?()\[\]{}"']+$/g, '');
  });
}

/**
 * Replaces all http:// URLs with https:// while preserving existing https URLs.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using a regex that doesn't match https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade http:// to https://
 * - For example.com URLs with /docs/ paths, move to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    // Match http://example.com URLs with optional paths
    /http:\/\/example\.com(\/[^\s]*)?/gi,
    (match, path = '') => {
      // Always upgrade to https
      let newUrl = 'https://example.com' + path;
      
      // Check if we should move to docs.example.com
      if (path.startsWith('/docs/')) {
        // Check for dynamic content that should prevent host rewrite
        const hasDynamicContent = 
          /cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
        
        if (!hasDynamicContent) {
          // Safe to move to docs.example.com
          newUrl = 'https://docs.example.com' + path;
        } else {
          // Keep as https://example.com but upgrade scheme
          newUrl = 'https://example.com' + path;
        }
      }
      
      return newUrl;
    }
  );
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Additional validation for day based on month
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for valid day ranges
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > daysInMonth[monthNum]) {
    return 'N/A';
  }
  
  return year;
}
