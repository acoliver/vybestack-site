/**
 * Finds words starting with the given prefix, excluding specified exceptions.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match words starting with prefix
  // \b ensures word boundary, [a-zA-Z]+ matches the rest of the word
  let escapedPrefix = prefix;
  escapedPrefix = escapedPrefix.replace(/[*+?^${}()|[\]]/g, '\$&');
  const regex = new RegExp(`\b${escapedPrefix}\w*`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  // Return unique matches
  const uniqueSet = new Set(filteredMatches);
  return Array.from(uniqueSet);
}





/**
 * Finds occurrences of token that appear after a digit and not at string start.
 * Uses lookbehind to ensure token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use a simpler approach without lookbehind for broader compatibility
  // Match digit + token sequences and return the full match
  const regex = new RegExp(`\d${token.replace(/[*+?^${}()|[\]]/g, '\$&')}`, 'g');
  
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates password strength according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (pattern of 2 chars repeated)
  // This catches things like "abab", "1212", "!!!!", etc.
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  // Check for more complex repeated patterns (3+ chars)
  // Using a negative lookahead for repeated substrings
  for (let i = 1; i <= value.length / 2; i++) {
    for (let j = 0; j <= value.length - 2 * i; j++) {
      const substr = value.substr(j, i);
        let escapedSubstr = substr;
        escapedSubstr = escapedSubstr.replace(/[*+?^${}()|[\]]/g, '\$&');
        const regex = new RegExp(`${escapedSubstr}.*${escapedSubstr}`);
      if (regex.test(value.substr(j + i))) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 * Returns true if IPv6 address is found.
 */
export function containsIPv6(value: string): boolean {
  
  // IPv6 regex patterns
  // Full IPv6 format (8 groups of 4 hex digits)
  const fullIpv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: compression
  const compressedIpv6Regex = /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with IPv4 embedded (not to be confused with pure IPv4)
  const ipv4EmbeddedRegex = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check for IPv6 patterns
  const hasFullIPv6 = fullIpv6Regex.test(value);
  const hasCompressedIPv6 = compressedIpv6Regex.test(value);
  const hasEmbeddedIPv6 = ipv4EmbeddedRegex.test(value);
  
  // If we found IPv6, return true
  if (hasFullIPv6 || hasCompressedIPv6 || hasEmbeddedIPv6) {
    return true;
  }
  
  return false;
}