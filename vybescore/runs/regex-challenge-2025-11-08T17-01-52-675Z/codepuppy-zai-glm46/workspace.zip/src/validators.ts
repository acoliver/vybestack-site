export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with proper RFC-compliant rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles most cases
  const emailRegex = /^[\w!#$%&'*+/=?`{|}~^-]+(?:\.[\w!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validations
  
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing or leading dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // No dots immediately before or after @
  if (value.includes('.@') || value.includes('@.')) {
    return false;
  }
  
  // Domain should not contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Domain should not start or end with hyphen
  if (domain && (domain.startsWith('-') || domain.endsWith('-'))) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length: 10 digits (standard) or 11 digits (with country code)
  if (digits.length !== 10 && digits.length !== 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (US country code)
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }
  
  // Extract the actual 10-digit number
  const phoneNumber = digits.length === 11 ? digits.slice(1) : digits;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate overall format with regex
  const usPhoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers (mobile and landline).
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Extract digits for validation
  const digits = cleanNumber.replace(/\D/g, '');
  
  // Check if we have reasonable number of digits
  if (digits.length < 10 || digits.length > 14) {
    return false;
  }
  
  // Multiple regex patterns to match different valid formats
  const patterns = [
    // +54 9 XXXX XXXXXX (mobile with country code)
    /^\+549[1-9]\d{1,3}\d{6,8}$/,
    // +54 XXXX XXXXXX (landline with country code)
    /^\+54[1-9]\d{1,3}\d{6,8}$/,
    // 0 XXXX XXXXXX (landline without country code)
    /^0[1-9]\d{1,3}\d{6,8}$/,
    // 0 9 XXXX XXXXXX (mobile without country code)
    /^09[1-9]\d{1,3}\d{6,8}$/
  ];
  
  // Check if clean number matches any pattern
  const isValidPattern = patterns.some(pattern => pattern.test(cleanNumber));
  
  if (!isValidPattern) {
    return false;
  }
  
  // Additional validation with spaces/hyphens allowed
  // Allow spaces between area code and subscriber number
  const withSeparatorsRegex = /^(?:\+54[\s-]?)?0?[1-9]\d{1,3}(?:[\s-]\d{2,4}){0,2}\d{4,6}$/;
  if (!withSeparatorsRegex.test(value)) {
    return false;
  }
  
  // Extract components for detailed validation
  let areaCode: string | undefined;
  let subscriber: string | undefined;
  
  if (cleanNumber.startsWith('+54')) {
    // With country code
    const afterCountry = cleanNumber.slice(3);
    if (afterCountry.startsWith('9')) {
      // Mobile: +54 9 (area) (subscriber)
      const afterMobile = afterCountry.slice(1);
      // Find the split point between area code and subscriber
      // Area code is 2-4 digits, subscriber is 6-8 digits
      for (let i = 2; i <= 4; i++) {
        if (afterMobile.length - i >= 6 && afterMobile.length - i <= 8) {
          areaCode = afterMobile.slice(0, i);
          subscriber = afterMobile.slice(i);
          break;
        }
      }
    } else {
      // Landline: +54 (area) (subscriber)
      // Find the split point
      for (let i = 2; i <= 4; i++) {
        if (afterCountry.length - i >= 6 && afterCountry.length - i <= 8) {
          areaCode = afterCountry.slice(0, i);
          subscriber = afterCountry.slice(i);
          break;
        }
      }
    }
  } else {
    // Without country code, must start with 0
    const afterTrunk = cleanNumber.slice(1);
    if (afterTrunk.startsWith('9')) {
      // Mobile: 0 9 (area) (subscriber)
      const afterMobile = afterTrunk.slice(1);
      for (let i = 2; i <= 4; i++) {
        if (afterMobile.length - i >= 6 && afterMobile.length - i <= 8) {
          areaCode = afterMobile.slice(0, i);
          subscriber = afterMobile.slice(i);
          break;
        }
      }
    } else {
      // Landline: 0 (area) (subscriber)
      for (let i = 2; i <= 4; i++) {
        if (afterTrunk.length - i >= 6 && afterTrunk.length - i <= 8) {
          areaCode = afterTrunk.slice(0, i);
          subscriber = afterTrunk.slice(i);
          break;
        }
      }
    }
  }
  
  // Validate area code and subscriber if we found them
  if (areaCode && subscriber) {
    // Area code must start with 1-9 and be 2-4 digits
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
      return false;
    }
    // Subscriber must be 6-8 digits
    if (!/^\d{6,8}$/.test(subscriber)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Regex for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens (but not consecutive)
  // - Spaces (but not consecutive or leading/trailing)
  // - At least 2 characters
  // Use a simpler pattern that covers most unicode letters without Unicode property escapes
  const nameRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ]+(?:[''`´-][A-Za-zÀ-ÖØ-öø-ÿ]+| [A-Za-zÀ-ÖØ-öø-ÿ]+)*$/;
  
  if (!nameRegex.test(value) || value.length < 2) {
    return false;
  }
  
  // Additional checks
  
  // Should not contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Should not start or end with apostrophe, hyphen, or space
  if (/^[‘'''s-\s]|[''s-\s]$/.test(value)) {
    return false;
  }
  
  // Should not have consecutive spaces, apostrophes, or hyphens
  if (/[\s'''s-]{2,}/.test(value)) {
    return false;
  }
  
  // Should not contain symbols other than allowed ones
  if (/[^A-Za-zÀ-ÖØ-öø-ÿ\s'''`´-]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks length, prefix, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Check length and prefix for different card types
  let isValid = false;
  
  // Visa: 13, 16, or 19 digits, starts with 4
  if (/^4\d{12}(\d{3})?(\d{3})?$/.test(cleanNumber)) {
    isValid = true;
  }
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  else if (/^(5[1-5]\d{14}|2[2-7]\d{14})$/.test(cleanNumber)) {
    isValid = true;
  }
  // American Express: 15 digits, starts with 34 or 37
  else if (/^3[47]\d{13}$/.test(cleanNumber)) {
    isValid = true;
  }
  
  if (!isValid) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
