declare module 'sql.js' {
  interface Database {
    run(sql: string, params?: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(): Promise<SqlJsStatic>;

  export default initSqlJs;
  export { Database };
}