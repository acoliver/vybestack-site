import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { readFile, writeFile } from 'fs/promises';
import initSqlJs, { Database } from 'sql.js';



interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string | undefined;
}

const app = express();
const port = process.env.PORT || 3535;
const dataDir = path.join(process.cwd(), 'data');
const dbPath = path.join(dataDir, 'submissions.sqlite');

let serverInstance: ReturnType<typeof app.listen> | null = null;

// Ensure data directory exists
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Initialize database
async function initializeDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs();
    let dbInstance: Database;
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      const dbFileBuffer = await readFile(dbPath);
      dbInstance = new SQL.Database(dbFileBuffer);
    } else {
      dbInstance = new SQL.Database();
      const schema = await readFile(
        path.join(process.cwd(), 'db', 'schema.sql'),
        'utf8'
      );
      dbInstance.run(schema);
      await saveDatabase(dbInstance);
    }
    
    return dbInstance;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
async function saveDatabase(dbInstance: Database): Promise<void> {
  try {
    const data = dbInstance.export();
    await writeFile(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(formData: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  // Required fields
  if (!formData.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!formData.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!formData.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!formData.postalCode.trim()) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    formData: {}, 
    errors: {} 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  const formData: FormData = {
    firstName: req.body.first_name || '',
    lastName: req.body.last_name || '',
    streetAddress: req.body.street_address || '',
    city: req.body.city || '',
    stateProvince: req.body.state_province || '',
    postalCode: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.render('form', {
      formData,
      errors: validation.errors
    });
  }
  
  try {
    db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    await saveDatabase(db);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database insertion error:', error);
    res.status(500).send('Error saving form submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Start server and initialize database
async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    console.log('Database initialized successfully');
    
    serverInstance = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Graceful shutdown function
    const gracefulShutdown = async () => {
      console.log('Shutting down gracefully...');
      if (serverInstance) {
        serverInstance.close(async () => {
          if (db) {
            db.close();
            console.log('Database connection closed');
          }
          process.exit(0);
        });
      }
    };
    
    // Handle SIGTERM for graceful shutdown
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
