/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and check each one
  const words = text.split(/\s+/);
  const matches: string[] = [];
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  for (const word of words) {
    // Remove any punctuation around the word
    const cleanWord = word.replace(/^[^a-zA-Z]+|[^a-zA-Z]+$/g, '');
    
    // Check if word starts with prefix and isn't in exceptions
    if (cleanWord.toLowerCase().startsWith(prefix.toLowerCase()) &&
        !exceptionSet.has(cleanWord.toLowerCase())) {
      matches.push(cleanWord);
    }
  }
  
  // Remove duplicates while preserving order
  return [...new Set(matches)];
}

/**
 * Returns occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for precise positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token that have a digit before them
  const matches: string[] = [];
  let searchIndex = 0;
  
  while (searchIndex < text.length) {
    // Find next occurrence of token
    const tokenIndex = text.indexOf(token, searchIndex);
    if (tokenIndex === -1) break;
    
    // Check if it's not at the start and has a digit before it
    if (tokenIndex > 0) {
      const charBefore = text[tokenIndex - 1];
      if (/\d/.test(charBefore)) {
        // Include the digit in the result
        matches.push(text.substring(tokenIndex - 1, tokenIndex + token.length));
      }
    }
    
    searchIndex = tokenIndex + 1;
  }
  
  return matches;
}

/**
 * Validates passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern using string constructor to avoid regex literal issues
  // Simplified pattern that matches common IPv6 formats
  const ipv6Pattern = '([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::';
  const ipv6Regex = new RegExp(ipv6Pattern);
  
  return ipv6Regex.test(value);
}