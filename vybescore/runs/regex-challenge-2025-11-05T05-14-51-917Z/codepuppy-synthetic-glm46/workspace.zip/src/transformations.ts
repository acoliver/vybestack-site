/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces to single space
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence endings if missing
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Split into sentence boundaries while preserving delimiters
  const sentences = result.split(/([.!?]\s+)/);
  
  // Process each sentence fragment
  for (let i = 0; i < sentences.length; i++) {
    const fragment = sentences[i];
    
    // Skip empty fragments and punctuation-only fragments
    if (!fragment || /^[.!?,\s]+$/.test(fragment)) continue;
    
    // Capitalize first character of the sentence (if it's a letter)
    sentences[i] = fragment.replace(/^([a-z])/, (match, char) => char.toUpperCase());
  }
  
  // Rejoin and clean up final spacing
  return sentences.join('').replace(/\s+$/, '');
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  const urlRegex = /(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:[^\s<>"']*)/gi;
  
  const matches: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation that's not part of the URL
    url = url.replace(/[.,;:!?\)\]\}"']+$/g, '');
    
    // Ensure we have a protocol
    if (!url.match(/^https?:\/\//)) {
      url = 'http://' + url;
    }
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't affect existing https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite when path contains dynamic hints or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with example.com domain
  const urlRegex = /(http:\/\/example\.com)(\/[^\s]*?)(?=\s|$)/gi;
  
  return text.replace(urlRegex, (match, protocolAndDomain, path) => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(cgi\-bin|[?&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=\?|$))/i.test(path);
    
    // If it's a docs path and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Check for dynamic hints in the remaining path after /docs/
      const docsPath = path.substring(6); // Remove '/docs/'
      const docsHasDynamicHints = /(cgi\-bin|[?&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=\?|$))/i.test(docsPath);
      
      if (!docsHasDynamicHints) {
        // Rewrite to docs.example.com
        return secureProtocol + 'docs.example.com' + path;
      }
    }
    
    // Just upgrade the scheme
    return secureProtocol + 'example.com' + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let maxDays = daysInMonth[month - 1];
  
  // Handle leap year for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeap) maxDays = 29;
  }
  
  if (day < 1 || day > maxDays) return 'N/A';
  
  return year;
}
