export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid formats.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic structure: local@domain
  const emailRegex = /^[^\s@]+@[^\s@]+$/;
  if (!emailRegex.test(email)) return false;
  
  const [local, domain] = email.split('@');
  
  // Local part validation
  // Cannot start or end with dot, no consecutive dots
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (local.includes('..')) return false;
  
  // Domain part validation
  // Cannot start or end with dot, no consecutive dots, no underscores
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..') || domain.includes('_')) return false;
  
  // Domain labels: alphanumeric and hyphens only, no leading/trailing hyphens
  const domainLabels = domain.split('.');
  if (domainLabels.length < 2) return false; // Need at least second-level domain
  
  for (const label of domainLabels) {
    if (label.length === 0) return false;
    if (/[^a-zA-Z0-9-]/.test(label)) return false;
    if (label.startsWith('-') || label.endsWith('-')) return false;
  }
  
  // TLD validation: should be at least 2 characters
  const tld = domainLabels[domainLabels.length - 1];
  if (tld.length < 2) return false;
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;
  
  // Local part: allowed chars are more permissive
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localRegex.test(local)) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check length: should be 10 digits (US number) or 11 digits (with country code)
  if (digits.length === 11) {
    // If 11 digits, must start with 1 (US country code)
    if (!digits.startsWith('1')) return false;
  } else if (digits.length !== 10) {
    // Only 10 or 11 digits allowed
    return false;
  }
  
  // Extract just the 10-digit phone number (without country code)
  const phoneNumber = digits.length === 11 ? digits.slice(1) : digits;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format using regex for common US phone patterns
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers covering both mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Comprehensive regex for Argentine phone numbers
  const argentinePhoneRegex = /^(\+54)?(?:0|9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanNumber.match(argentinePhoneRegex);
  
  if (!match) return false;
  
  const [, countryCode, areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix (0)
  if (!countryCode && !cleanNumber.startsWith('0')) return false;
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (!/^[1-9]/.test(areaCode)) return false;
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unconventional names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  const trimmedName = value.trim();
  
  // Cannot be empty or just whitespace
  if (trimmedName.length === 0) return false;
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!nameRegex.test(trimmedName)) return false;
  
  // Cannot contain multiple consecutive separators (except allowed single spaces between words)
  if (trimmedName.includes("''") || trimmedName.includes('--')) return false;
  
  // Cannot start or end with apostrophe or hyphen
  if (trimmedName.startsWith("'") || trimmedName.endsWith("'")) return false;
  if (trimmedName.startsWith('-') || trimmedName.endsWith('-')) return false;
  
  // Reject names with unusual symbol combinations like in "X Æ A-12"
  const unusualSymbolRegex = /[Æ]/;
  if (unusualSymbolRegex.test(trimmedName)) return false;
  
  // Must contain at least one letter
  const letterRegex = /[\p{L}\p{M}]/u;
  if (!letterRegex.test(trimmedName)) return false;
  
  return true;
}

/**
 * Validates credit card numbers checking prefixes, lengths, and Luhn checksum.
 * Supports Visa, Mastercard, and American Express.
 */
export function isValidCreditCard(value: string): boolean {
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must consist of only digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Check card type-specific prefixes and lengths
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12})$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}
