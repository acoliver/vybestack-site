import { ReportData, RenderOptions, Formatter } from '../types.js';

export const textFormatter: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    let output = `${data.title}

${data.summary}

Entries:

`;

    // Add each entry as a bullet point
    for (const entry of data.entries) {
      const amount = entry.amount.toFixed(2);
      output += `- ${entry.label}: $${amount}
`;
    }

    // Add total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      const totalFormatted = total.toFixed(2);
      output += `
Total: $${totalFormatted}`;
    }

    return output;
  }
};