import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { markdownFormatter, textFormatter } from '../formats/index.js';

function parseArgs(args: string[]): CliOptions {
  // Skip first two args (node and script path)
  const cliArgs = args.slice(2);
  
  if (cliArgs.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < cliArgs.length; i++) {
    const arg = cliArgs[i];
    
    if (arg === '--format') {
      i++;
      if (i >= cliArgs.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = cliArgs[i] as 'markdown' | 'text';
      
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
        process.exit(1);
      }
    } else if (arg === '--output') {
      i++;
      if (i >= cliArgs.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = cliArgs[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    format,
    output,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (must be an array)');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Missing or invalid required field: label`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: Missing or invalid required field: amount (must be a number)`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${filePath}': ${error.message}`);
      process.exit(1);
    }
    
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    
    console.error(`Error: Unexpected error reading file '${filePath}'`);
    process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const options = parseArgs(args);
  
  // Load and validate report data
  const data = loadReportData(args[2]);
  
  // Select format renderer
  const renderer = options.format === 'markdown' ? markdownFormatter : textFormatter;
  
  // Render report
  const report = renderer.render(data, { includeTotals: options.includeTotals });
  
  // Output report
  if (options.output) {
    writeFileSync(options.output, report, 'utf-8');
  } else {
    console.log(report);
  }
}

main();