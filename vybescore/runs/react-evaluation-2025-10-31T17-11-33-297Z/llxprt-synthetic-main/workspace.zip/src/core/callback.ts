/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create a wrapper observer that will be invoked when dependencies change
  const observer: Observer<T> = {
    value,
    updateFn: () => {
      if (!disposed) {
        // Execute the side-effect function with current observer value
        observer.value = updateFn(observer.value)
        return observer.value
      }
      return value!
    },
  }
  
  // Initial execution to establish dependencies and run the callback
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}