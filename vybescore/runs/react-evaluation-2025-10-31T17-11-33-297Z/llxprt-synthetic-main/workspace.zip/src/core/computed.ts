/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  normalizeEqual,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const _equalFn = normalizeEqual(equal)
  
  // Create the observer 
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store initial computed value
  let computedValue: T | undefined = value
  
  // Return getter that recomputes dependencies when accessed
  const getter: GetterFn<T> = () => {
    updateObserver(observer)
    // Get latest computed value
    computedValue = observer.value
    return computedValue!
  }
  
  return getter
}