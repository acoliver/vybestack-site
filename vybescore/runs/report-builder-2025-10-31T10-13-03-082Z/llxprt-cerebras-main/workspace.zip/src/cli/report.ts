import { readFile } from 'fs/promises';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../formats/types.js';

async function main() {
  const args = process.argv.slice(2);
  
  // Parse arguments
  let dataPath: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        format = args[++i];
        break;
      case '--output':
        outputPath = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (!dataPath) {
          dataPath = args[i];
        }
        break;
    }
  }
  
  // Validate arguments
  if (!dataPath) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }
  
  if (!format) {
    console.error('Error: Format is required');
    process.exit(1);
  }
  
  // Load and parse data
  let data: ReportData;
  try {
    const fileContent = await readFile(dataPath, 'utf-8');
    data = JSON.parse(fileContent);
  } catch (error) {
    console.error(`Error: Failed to read or parse data file: ${error}`);
    process.exit(1);
  }
  
  // Validate data structure
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    console.error('Error: Invalid data structure. Missing required fields.');
    process.exit(1);
  }
  
  // Render based on format
  let output: string;
  switch (format) {
    case 'markdown':
      output = renderMarkdown(data, { includeTotals });
      break;
    case 'text':
      output = renderText(data, { includeTotals });
      break;
    default:
      console.error(`Error: Unsupported format "${format}"`);
      process.exit(1);
  }
  
  // Write to file or stdout
  if (outputPath) {
    try {
      await writeFile(outputPath, output);
      console.log(`Report written to ${outputPath}`);
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Import writeFile from fs/promises
import { writeFile } from 'fs/promises';

main().catch(error => {
  console.error(`Unexpected error: ${error}`);
  process.exit(1);
});