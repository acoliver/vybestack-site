import { ReportData, FormatOptions } from './types.js';

export function renderMarkdown(data: ReportData, options: FormatOptions = {}): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let output = `# ${title}\n\n${summary}\n\n## Entries\n`;
  
  entries.forEach(entry => {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  });

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** $${total.toFixed(2)}\n`;
  }

  return output;
}