import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Import sql.js
import initSqlJs from 'sql.js';
 
// Database type definition (based on sql.js documentation)
interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  run(sql: string, ...params: any[]): any;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(params: any[]): any;
  step(): any;
  free(): void;
}

// Database instance
let db: Database | null = null;

async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    const { Database: DbClass } = SQL;
    
    const dbPath = path.resolve('data', 'submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    // Ensure data directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    let dbData = new Uint8Array();
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }
    
    db = new DbClass(dbData) as unknown as Database;
    
    // Initialize schema
    const schemaPath = path.resolve('db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db!.exec(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase() {
  try {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    const data = db!.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateFormData(formData: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field validation
  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else {
    // Phone validation: allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }
  }
  
  // Postal code validation: allow alphanumeric characters and spaces
  if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, digits, and spaces' });
  }
  
  return errors;
}

function saveToDatabase(formData: FormData) {
  try {
    const stmt = db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    console.log('Form submission saved to database');
  } catch (error) {
    console.error('Failed to save to database:', error);
    throw error;
  }
}

// Initialize Express app
const app = express();
const port = process.env.PORT || '3535';

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };
  
  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    const errorMessages = errors.map(e => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
  } else {
    // Save to database
    saveToDatabase(formData as FormData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  }
});

app.get('/thank-you', (req, res) => {
  // For simplicity, we'll use a generic greeting since we don't have 
  // session storage or query parameters in this implementation
  res.render('thank-you', {
    firstName: 'friend'
  });
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('Received shutdown signal, closing server...');
    
    server.close(() => {
      console.log('Server closed');
      
      if (db && typeof db.close === 'function') {
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
    
    // Force close after 5 seconds
    setTimeout(() => {
      console.error('Forcing server shutdown...');
      process.exit(1);
    }, 5000);
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the application
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
