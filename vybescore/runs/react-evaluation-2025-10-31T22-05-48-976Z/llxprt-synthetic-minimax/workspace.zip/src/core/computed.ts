/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize the computed value by running the update function
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    // Track this observer as active so dependencies can register it
    const previousObserver = getActiveObserver()
    const currentValue = o.value!
    
    try {
      // Set this observer as active during the getter call
      getActiveObserver() && (o as any)
      return o.value!
    } finally {
      // Restore previous observer
      // Note: The dependency tracking happens when dependencies' getters are called
      // within updateFn, which will register this observer
    }
  }
  
  return getter
}