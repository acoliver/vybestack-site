/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 padding format.
 */
function validatePadding(input: string): void {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) return;
  
  // Padding must appear only at the end and be 1 or 2 characters
  const padding = input.substring(paddingIndex);
  if (!/^(={1,2})$/.test(padding)) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }
  
  // Calculate expected padding based on string length
  const totalLength = input.length;
  const lengthWithoutPadding = totalLength - padding.length;
  const expectedPadding = lengthWithoutPadding % 4;
  
  if ((expectedPadding === 0 && padding.length !== 0) ||
      (expectedPadding === 1) ||  // This shouldn't happen in valid base64
      (expectedPadding === 2 && padding.length !== 2) ||
      (expectedPadding === 3 && padding.length !== 1)) {
    throw new Error('Invalid Base64 input: incorrect padding length');
  }
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard Base64 format.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate the input is proper base64 format
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }
  
  // Validate padding if present
  validatePadding(input);

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // If the decoded result is empty and the input wasn't just padding, that's an error
    if (result === '' && input.replace(/=/g, '').length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
