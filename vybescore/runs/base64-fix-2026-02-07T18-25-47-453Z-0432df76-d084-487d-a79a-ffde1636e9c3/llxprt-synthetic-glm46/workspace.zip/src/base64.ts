/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 data.
 */
export function decode(input: string): string {
  // Remove whitespace characters if any
  const normalized = input.replace(/\s/g, '');

  // Validate Base64 format: must contain only A-Z, a-z, 0-9, +, /, =
  // and length must be multiple of 4 (ignoring padding)
  if (!/^[A-Za-z0-9+/=]*$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    const result = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Check if the result contains invalid UTF-8 sequences
    if (!Buffer.from(result, 'utf8').equals(Buffer.from(result, 'utf8'))) {
      throw new Error('Failed to decode Base64 input: invalid UTF-8 sequence');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
