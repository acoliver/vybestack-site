export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compatible email validation with restrictions
  // Local part: letters, digits, and allowed special chars, no consecutive dots, no leading/trailing dots
  // Domain: subdomains and TLD, no underscores, no consecutive dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  // No consecutive dots in local part
  if (value.split('@')[0].includes('..')) return false;
  
  // No dots at start or end of local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // No double dots in domain
  const domain = value.split('@')[1];
  if (domain.includes('..')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // Valid TLD check (2+ characters after last dot, letters only)
  const tldMatch = domain.match(/\.([a-zA-Z]{2,})$/);
  if (!tldMatch) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Clean the input to only contain digits and basic separators
  // Remove all non-digit, non-separator characters
  /* eslint-disable no-useless-escape */
  const cleanedValue = value.replace(/[^0-9\-\(\)\s.]/g, '');
  /* eslint-enable no-useless-escape */
  
  // US phone number regex that supports:
  // - Optional country code +1
  // - Area codes not starting with 0 or 1
  // - Various separators: spaces, hyphens, dots, parentheses
  // - 10 digits (excluding country code) minimum
  /* eslint-disable no-useless-escape */
  const phoneRegex = /^(?:\+?1[\s-]?)?\(?([2-9][0-9]{2})\)?[\s.-]?([0-9]{3})[\s.-]?([0-9]{4})$/;
  /* eslint-enable no-useless-escape */
  
  if (!phoneRegex.test(cleanedValue)) return false;
  
  // Ensure we have enough digits (at least 10 digits excluding country code)
  const digits = cleanedValue.replace(/\D/g, '');
  if (digits.length < 10) return false;
  
  // If we have country code, it must be "1"
  if (digits.length === 11) {
    if (digits[0] !== '1') return false;
  }
  
  // Reject if more than 11 digits
  if (digits.length > 11) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces, hyphens) for validation
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone format regex:
  // - Optional country code +54
  // - Optional trunk prefix 0
  // - Optional mobile indicator 9
  // - Area code 2-4 digits (leading digit 1-9)
  // - Subscriber number 6-8 digits
  const argPhoneRegex = /^(?:\+?54)?(?:0)?(?:9)?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  if (!argPhoneRegex.test(cleanedValue)) return false;
  
  // Extract area code and subscriber number
  const match = cleanedValue.match(argPhoneRegex);
  if (!match) return false;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  const areaCode = match[1];
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number validation: 6-8 digits
  const subscriberNum = match[2];
  if (subscriberNum.length < 6 || subscriberNum.length > 8) return false;
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!cleanedValue.startsWith('+54') && !cleanedValue.startsWith('54')) {
    // Number without country code must have trunk prefix 0
    if (!value.startsWith('0')) return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name should only contain:
  // - Unicode letters (including accented letters)
  // - Spaces
  // - Apostrophes
  // - Hyphens
  // At least one letter is required
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter (not just spaces, hyphens, or apostrophes)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject names with too many consecutive special chars
  if (/''/.test(value) || /--/.test(value) || /'/.test(value)) return false;
  
  // Reject very specific pattern "X Æ A-12" style (containing numbers or specific symbols)
  if (/[0-9]/.test(value)) return false;
  
  // Minimum length (at least 2 characters)
  if (value.trim().length < 2) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Clean up input - remove spaces and hyphens
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Credit card validation using regex for major card types and Luhn checksum
  // Visa: 4, 13 or 16 digits
  // Mastercard: 51-55, 2221-2720, 16 digits
  // AmEx: 34,37, 15 digits
  const ccRegex = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|2(?:22(?:2[6-9]|[3-9][0-9])|[3-6][0-9]{2}|7(?:[01][0-9]|20))[0-9]{12}|3[47][0-9]{13})$/;
  
  if (!ccRegex.test(cleanedValue)) return false;
  
  // Luhn checksum algorithm
  return runLuhnCheck(cleanedValue);
}

/**
 * Helper function: Run Luhn checksum algorithm on a numeric string
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      // If 2*digit is 2-digit number, add the digits together
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  // If sum is divisible by 10, the number is valid
  return sum % 10 === 0;
}
