/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // List of common abbreviations to avoid splitting sentences incorrectly
  const abbreviations = /\b(?:mr|mrs|ms|dr|prof|sr|jr|st|vs|etc|e\.g|i\.e|no|vol|art|p|pp|ed|rep|dept|univ|assn|bros|inc|ltd|co|corp|llc|plc)\b/gi;
  
  // Split text into sentences, considering sentence endings (? . !)
  // First, temporarily replace abbreviations to avoid splitting at them
  const textWithPlaceholders = text.replace(abbreviations, (match) => match.replace(/\./g, '§§§'));
  
  // Split by sentence endings (., ?, !) followed by whitespace or end of string
  const sentences = textWithPlaceholders.split(/([.?!])(?:\s+|$)/);
  
  // Process each sentence: capitalize first letter and fix spacing
  let result = '';
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i];
    
    // Restore abbreviations
    sentence = sentence.replace(/§§§/g, '.');
    
    // Capitalize if this is the beginning of a sentence (starting position or after punctuation)
    if (i === 0 || (i > 0 && sentences[i-1] && /^[.?!]$/.test(sentences[i-1]))) {
      sentence = sentence.replace(/^(\s*)([a-z])/, (_, spaces, letter) => {
        return spaces + letter.toUpperCase();
      });
    }
    
    result += sentence;
    
    // Add exactly one space after punctuation if needed
    if (i > 0 && i % 2 === 1 && /^[.?!]$/.test(sentences[i]) && i < sentences.length - 1) {
      // Ensure exactly one space after punctuation if there isn't already space in next piece
      if (sentences[i+1] && !sentences[i+1].startsWith(' ')) {
        result += ' ';
      } else if (sentences[i+1] && sentences[i+1].startsWith(' ')) {
        // Replace any amount of whitespace with just one space
        result += ' ';
      }
    }
  }
  
  // Collapse multiple spaces to single spaces, but preserve single spaces
  result = result.replace(/\s{2,}/g, ' ');
  
  // Remove trailing space
  result = result.replace(/\s+$/, '');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches:
  // - Protocol (http://, https://, ftp://, etc.)
  // - Domain names with subdomains
  // - IP addresses
  // - Paths, query strings, fragments
  // This pattern doesn't capture trailing punctuation
  const urlPattern = /\b((?:https?|ftp):\/\/(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?:\/[^\s<>"'()`]+)?)/g;
  
  const matches = [];
  let match;
  while ((match = urlPattern.exec(text)) !== null) {
    // Extract the URL and trim trailing punctuation if present
    let url = match[1];
    
    // Remove trailing punctuation that's not part of the URL
    url = url.replace(/[.,;!?:)\]}"'*>]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's at the beginning of a URL
  // Avoid replacing in text like "http://example.com is cool" where http:// is just a mention
  return text.replace(/\b(http:\/\/)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // We use a capture group for the domain and the rest of the URL
  const exampleUrlPattern = /(http:\/\/example\.com)(\/[^\t <>"']*)?/gi;
  
  return text.replace(exampleUrlPattern, (match, domain, path = '') => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check if we should rewrite the host
    // If the path begins with /docs/ and doesn't contain dynamic hints
    // Note: The domain part of match includes the protocol
    const shouldRewriteHost = path && path.startsWith('/docs/') && 
                            !path.match(/\/(cgi-bin|[?&])/) && 
                            !path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py|html|htm)/i);
    
    // Set domain based on whether we're rewriting docs
    if (shouldRewriteHost) {
      newUrl += 'docs.example.com';
    } else {
      newUrl += 'example.com';
    }
    
    // Add the path (which might be empty)
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  // Extract month, day, and year
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combinations
  // Check for impossible dates like February 31, April 31, etc.
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (February 29) if needed
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  // Special handling for February
  if (month === 2) {
    if (isLeapYear(year) && day > 29) return 'N/A';
    if (!isLeapYear(year) && day > 28) return 'N/A';
  } else {
    // All other months
    if (day > daysInMonth[month - 1]) return 'N/A';
  }
  
  return year;
}
