/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match word boundaries after the prefix
  // eslint-disable-next-line no-useless-escape
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]+)\\b`, 'g');
  
  const matches = [];
  let match;
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    
    // Check if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find tokens preceded by digits using manual scanning
  const matches = [];
  let index = text.length;
  
  // Search for the token from the end of the string
  while ((index = text.lastIndexOf(token, index - 1)) !== -1) {
    // Check if there's a character before the token and if it's a digit
    if (index > 0 && /\d/.test(text.charAt(index - 1))) {
      // Include the digit in the result
      matches.push(text.charAt(index - 1) + token);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password requirements:
  // - At least 10 characters
  // - One uppercase
  // - One lowercase
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., abab)
  
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/\d/.test(value)) return false;
  
  // Check for symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  // This catches patterns where two characters are repeated consecutively
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern includes:
  // - Full format with colons (xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx)
  // - Shorthand with :: (2001:db8::1)
  // - Embedded IPv4 addresses (::ffff:192.168.1.1)
  // - Other valid IPv6 formats
  
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/i;
  
  // Check if the value contains an IPv6 address
  return ipv6Pattern.test(value);
}
