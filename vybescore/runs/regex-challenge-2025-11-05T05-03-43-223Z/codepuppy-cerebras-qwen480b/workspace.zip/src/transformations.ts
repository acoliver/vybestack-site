export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) return text;
  
  // First, normalize spacing around punctuation
  let processed = text
    .replace(/\s*([.!?]+)\s*/g, '$1 ') // Ensure one space after punctuation
    .replace(/\s+/g, ' ') // Collapse multiple spaces to one
    .trim();
  
  // Capitalize first letter of each sentence
  processed = processed.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
  
  return processed;
}

export function extractUrls(text: string): string[] {
  if (!text || text.trim().length === 0) return [];
  
  // URL regex that matches http/https and www URLs
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>,;:"'`{}|\[\]()]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

export function enforceHttps(text: string): string {
  if (!text || text.trim().length === 0) return text;
  
  // Replace http:// with https:// but don't touch https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  if (!text || text.trim().length === 0) return text;
  
  return text.replace(/\bhttps?:\/\/example\.com(\/[^\s]*)?/gi, (match, path = '') => {
    // Always upgrade to https
    const secureUrl = match.replace(/^http:/, 'https:');
    
    // Check if we should rewrite the host
    // Skip when path contains dynamic hints or legacy extensions
    const skipPatterns = [/(?:cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/i];
    const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
    
    if (path.startsWith('/docs/') && !shouldSkip) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
    
    return secureUrl;
  });
}

export function extractYear(value: string): string {
  if (!value || value.trim().length === 0) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month/day combinations
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > daysInMonth[month]) return 'N/A';
  
  return year;
}
