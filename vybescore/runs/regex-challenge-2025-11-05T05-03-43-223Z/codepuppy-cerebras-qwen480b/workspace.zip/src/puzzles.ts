export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
}

export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token that appears after a digit and not at start, but include the digit in the result
  const tokenRegex = new RegExp(`(?<!^)(\\d${escapedToken})`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return matches;
}

export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // At least one uppercase
  if (!/[a-z]/.test(value)) return false; // At least one lowercase
  if (!/\d/.test(value)) return false; // At least one digit
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false; // At least one symbol
  
  // Check for immediate repeated sequences (like abab, abcabc)
  if (/(..).*\1/.test(value)) return false; // Repeated 2-char sequences
  if (/(...).*\1/.test(value)) return false; // Repeated 3-char sequences
  
  return true;
}

export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, ensure we're not matching IPv4 addresses
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 regex patterns (including shorthand ::)
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // Shortened IPv6: can use :: to compress zeros
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b:(?::[0-9a-fA-F]{1,4}){1,7}\b|\b[0-9a-fA-F]{1,4}:(?:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::\b|\b::(?:(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4})?\b/;
  
  // Check for IPv6 patterns but make sure they're not part of IPv4
  const ipv6Matches = value.match(ipv6Regex);
  if (!ipv6Matches) return false;
  
  // Verify that matches are not actually IPv4 addresses
  for (const match of ipv6Matches) {
    if (!ipv4Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}