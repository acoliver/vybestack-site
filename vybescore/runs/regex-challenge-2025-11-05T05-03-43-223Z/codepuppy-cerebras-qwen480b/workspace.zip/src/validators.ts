export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

export function isValidEmail(value: string): boolean {
  // Email regex that accepts typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores, and other invalid forms
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!value.trim()) return false;
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@.') || value.includes('.@')) return false;
  if (value.includes('_@') || value.includes('@_')) return false;
  if (value.includes('._') || value.includes('_.') || value.includes('_.')) return false;
  
  return emailRegex.test(value);
}

export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || value.trim().length < 10) return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if it has optional +1 prefix
  let phoneNumber = digits;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate overall format
  const phoneRegex = /^\+?1?[\s\-\(\)]*\d{3}[\s\-\)]*\d{3}[\s\-\)]*\d{4}$/;
  
  return phoneRegex.test(value.replace(/\s+/g, ' '));
}

export function isValidArgentinePhone(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Argentine phone regex patterns
  // Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
  // Area code: 2-4 digits (leading 1-9), subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{0,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) return false;
  
  // Extract parts for detailed validation
  let remaining = cleaned;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    remaining = remaining.substring(3);
  }
  
  // Remove trunk prefix if present
  if (remaining.startsWith('0')) {
    remaining = remaining.substring(1);
  }
  
  // Remove mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Now remaining should be: area code + subscriber number
  // Area code is 2-4 digits, subscriber is 6-8 digits
  if (remaining.length < 8 || remaining.length > 12) return false;
  
  // Extract area code (first 2-4 digits)
  const areaCodeLength = Math.min(4, Math.max(2, remaining.length - 8));
  const areaCode = remaining.substring(0, areaCodeLength);
  const subscriber = remaining.substring(areaCodeLength);
  
  // Area code must start with 1-9 and be 2-4 digits
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) return false;
  
  return true;
}

export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and weird names like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}'’-]+(?:[\s][\p{L}\p{M}'’-]+)*$/u;
  
  // Additional checks for obviously invalid patterns
  if (/\d/.test(value)) return false; // No digits
  if (/[™®©©]/.test(value)) return false; // No trademark symbols
  if (/[Æ]/.test(value) && /\d/.test(value)) return false; // Reject X Æ A-12 style
  
  return nameRegex.test(value);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Validate based on card type
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d|20)\d{12}))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
