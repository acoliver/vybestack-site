/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  EqualFn,
  Subject,
  invalidateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set<Subject<unknown>>(),
    stale: true, // Start as stale to force initial calculation
  }
  
  const getter: GetterFn<T> = () => {
    // Check if we need to recompute
    if (o.stale || o.value === undefined) {
      // Set this observer as active so dependencies can register with it
      setActiveObserver(o)
      
      try {
        // Compute the new value
        const newValue = o.updateFn(o.value)
        
        // Update stored value
        const oldValue = o.value
        o.value = newValue
        
        // Mark as fresh
        o.stale = false
        
        // If value changed, invalidate observers
        if (oldValue !== newValue && o.subjects) {
          for (const dependent of o.subjects) {
            invalidateObserver(dependent as unknown as Observer<unknown>)
          }
        }
        
        return newValue
      } finally {
        // Restore previous active observer
        setActiveObserver(undefined)
      }
    }
    
    return o.value!
  }
  
  return getter
}