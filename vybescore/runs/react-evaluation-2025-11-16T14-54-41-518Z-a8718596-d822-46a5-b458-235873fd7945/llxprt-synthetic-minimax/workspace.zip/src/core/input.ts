/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifySubjects,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer as Observer<unknown>)
      // Track the reverse relationship
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      observer.subjects.add(s as Subject<unknown>)
    }
    
    // Clear stale flag on this subject
    // (Subjects don't have stale flags, so this is a no-op)
    return s.value
  }

  const write: SetterFn<T> = (newValue: T) => {
    s.value = newValue
    
    // Notify all observers that depend on this subject
    notifySubjects(s)
    
    return newValue
  }

  return [read, write]
}