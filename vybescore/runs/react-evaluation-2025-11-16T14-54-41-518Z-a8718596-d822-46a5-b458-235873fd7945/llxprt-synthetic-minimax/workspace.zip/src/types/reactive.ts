/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: Set<Subject<unknown>>
  stale?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<unknown>>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined = undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    observer.value = result
    return result
  } finally {
    activeObserver = previous
  }
}

export function notifySubjects<T>(subject: Subject<T>): void {
  const observers = Array.from(subject.observers)
  // Invalidate and then immediately trigger recomputation for all observers
  for (const observer of observers) {
    if (observer.updateFn) {
      // For computed values, mark as stale and trigger immediate recomputation
      observer.stale = true
    }
  }
  
  // Now trigger recomputation
  for (const observer of observers) {
    if (observer.updateFn && observer.stale) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}

export function invalidateObserver<T>(observer: Observer<T>): void {
  observer.stale = true
}