import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load as loadCheerio } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type { Server } from 'http';

let server: Server;
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and start the app - this will handle database initialization
  const imported = await import('../../dist/server.js');
  app = imported.app;
  
  // Start server on test port
  server = app.listen(3545);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = loadCheerio(response.text);
    
    // Check for form
    expect($('form').length).toBe(1);
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('POST');
    
    // Check for all required fields
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city',
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];
    
    requiredFields.forEach(field => {
      expect($(`input[name="${field}"]`).length).toBe(1);
    });
    
    // Check for field labels
    expect($('label[for="firstName"]').text()).toContain('First Name');
    expect($('label[for="email"]').text()).toContain('Email Address');
    
    // Check for submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        // Missing other required fields
      })
      .expect(400);

    const $ = loadCheerio(response.text);
    
    // Should show validation errors
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('input.error').length).toBeGreaterThan(0);
  });

  it('shows validation error for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1234567890'
      })
      .expect(400);

    const $ = loadCheerio(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
  });

  it('redirects to thank you page on successful submission', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1234567890'
      })
      .expect(302);

    // Should redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');
  });

  it('has thank you page with humorous content', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);

    const $ = loadCheerio(response.text);
    expect($('h1').text()).toContain('Thank You');
    expect($('.warning-box').length).toBe(1);
    expect($('body').text()).toMatch(/spam|scam|warning/i);
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = loadCheerio(response.text);
    
    // Check for form
    expect($('form').length).toBe(1);
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('POST');
    
    // Check for all required fields
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city',
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];
    
    requiredFields.forEach(field => {
      expect($(`input[name="${field}"]`).length).toBe(1);
    });
    
    // Check for field labels
    expect($('label[for="firstName"]').text()).toContain('First Name');
    expect($('label[for="email"]').text()).toContain('Email Address');
    
    // Check for submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        // Missing other required fields
      })
      .expect(400);

    const $ = loadCheerio(response.text);
    
    // Should show validation errors
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('input.error').length).toBeGreaterThan(0);
  });

  it('shows validation error for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1234567890'
      })
      .expect(400);

    const $ = loadCheerio(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
  });

  it('persists submission and redirects to thank you page', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1234567890'
      })
      .expect(302);

    // Should redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow redirect
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);

    const $ = loadCheerio(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank You');
    expect($('.warning-box').length).toBe(1);
  });

  it('stores submission data in database', async () => {
    // Database should be created after first submission
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('supports international phone numbers and postal codes', async () => {
    await request(app)
      .post('/submit')
      .send({
        firstName: 'Marie',
        lastName: 'Dupont',
        streetAddress: '15 Rue de la Paix',
        city: 'Paris',
        stateProvince: 'Île-de-France',
        postalCode: '75001',
        country: 'France',
        email: 'marie.dupont@example.fr',
        phone: '+33 1 42 86 83 53'
      })
      .expect(302);

    await request(app)
      .post('/submit')
      .send({
        firstName: 'José',
        lastName: 'García',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1043AAZ',
        country: 'Argentina',
        email: 'jose.garcia@example.ar',
        phone: '+54 9 11 1234-5678'
      })
      .expect(302);
  });
});
