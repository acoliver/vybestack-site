import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../db/schema.sql');
const WASM_PATH = path.join(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm');

let db: Database | null = null;
let sql: SqlJsStatic | null = null;

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Initialize database on module load
initDB().catch(error => {
  console.error('Failed to initialize database on startup:', error);
});

export async function initDB(): Promise<void> {
  if (sql === null) {
    try {
      // Try to use the WASM file locally
      sql = await initSqlJs({
        locateFile: (file: string) => {
          if (file.endsWith('.wasm')) {
            return WASM_PATH;
          }
          return `https://sql.js.org/dist/${file}`;
        }
      });
    } catch (error) {
      console.error('Failed to initialize SQL.js:', error);
      throw error;
    }
  }

  // Check if database file exists
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new sql.Database(fileBuffer);
  } else {
    // Create new database
    db = new sql.Database();
    
    // Load and execute schema
    if (db) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      
      // Save initial database
      saveDB();
    }
  }
}

export function saveDB(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

export async function saveSubmission(submission: SubmissionData): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone
  ]);
  
  stmt.free();
  saveDB();
}

export function closeDB(): void {
  if (db) {
    db.close();
    db = null;
  }
}