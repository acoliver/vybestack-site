import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDB, saveSubmission } from './db.js';
import type { Server } from 'http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
const PORT = process.env.PORT || 3535;

let server: Server | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s()+-]+$/;
  const nonDigits = phone.replace(/[\d]/g, '');
  return phoneRegex.test(phone) && nonDigits.length >= 1 && phone.length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function isValidFormData(data: Record<string, unknown>): ValidationResult {
  const errors: Record<string, string> = {};
  
  // Check if data has required properties
  const fields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  // Required fields
  for (const field of fields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      errors[field] = 'This field is required';
    }
  }
  
  // Email validation
  const email = data.email as string;
  if (email && !validateEmail(email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation
  const phone = data.phone as string;
  if (phone && !validatePhone(phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation
  const postalCode = data.postalCode as string;
  if (postalCode && !validatePostalCode(postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    data: {},
    title: 'Contact Us'
  });
});

app.post('/submit', async (req, res) => {
  const validation = isValidFormData(req.body);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      data: req.body,
      title: 'Contact Us'
    });
  }
  
  try {
    // Save to database
    await saveSubmission({
      first_name: req.body.firstName.trim(),
      last_name: req.body.lastName.trim(),
      street_address: req.body.streetAddress.trim(),
      city: req.body.city.trim(),
      state_province: req.body.stateProvince.trim(),
      postal_code: req.body.postalCode.trim(),
      country: req.body.country.trim(),
      email: req.body.email.trim(),
      phone: req.body.phone.trim()
    });
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred. Please try again.' },
      data: req.body,
      title: 'Contact Us'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer() {
  try {
    await initDB();
    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Only start server if this file is run directly (not imported)
if (process.argv[1] === new URL(import.meta.url).pathname) {
  startServer();
}