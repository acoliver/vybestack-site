declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    bind(params: unknown[]): void;
    run(params?: unknown[]): void;
    step(): boolean;
    get(params?: unknown[]): unknown[];
    free(): void;
    getColumnNames(): string[];
  }

  export interface SqlJsStatic {
    Database: {
      new (buffer?: Uint8Array): Database;
    };
  }

  const initSqlJs: (config?: { locateFile?: (file: string) => string }) => Promise<SqlJsStatic>;
  
  export default initSqlJs;
}