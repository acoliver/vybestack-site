/**
 * Encode plain text to Base64 using the canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input contains only valid Base64 characters.
 */
export function decode(input: string): string {
  // Trim whitespace
  input = input.trim();
  
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Check for invalid characters (only A-Z, a-z, 0-9, +, /, and = allowed)
  const paddingIndex = input.indexOf('=');

  // If padding is present, check that it's only at the end
  if (paddingIndex !== -1) {
    const padding = input.substring(paddingIndex);
    // Padding can only be '=' or '==' and must be at the end
    if (!/^(==?)$/.test(padding) || paddingIndex < input.length - padding.length) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    
    // Check the non-padded part has only valid chars
    if (!/^[A-Za-z0-9+/]+$/.test(input.substring(0, paddingIndex))) {
      throw new Error('Invalid Base64 input: contains illegal characters');
    }
  } else {
    // No padding - check for invalid characters
    if (!/^[A-Za-z0-9+/]+$/.test(input)) {
      throw new Error('Invalid Base64 input: contains illegal characters');
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    // Check if decoding failed (Buffer.from returns empty buffer for invalid base64)
    if (buffer.length === 0 && input.length > 0) {
      throw new Error('Invalid Base64 input: decoding failed');
    }
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
