import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Validate that parameters are numeric if provided
      let page: number | undefined;
      let limit: number | undefined;

      if (pageParam !== undefined) {
        if (isNaN(Number(pageParam))) {
          return res.status(400).json({ error: 'Page parameter must be numeric' });
        }
        page = Number(pageParam);
        if (page <= 0) {
          return res.status(400).json({ error: 'Page parameter must be positive' });
        }
      }

      if (limitParam !== undefined) {
        if (isNaN(Number(limitParam))) {
          return res.status(400).json({ error: 'Limit parameter must be numeric' });
        }
        limit = Number(limitParam);
        if (limit <= 0) {
          return res.status(400).json({ error: 'Limit parameter must be positive' });
        }
      }

      // Validate pagination parameters using the repository function
      const validation = validatePaginationParams(page, limit);
      if (!validation) {
        return res.status(400).json({ error: 'Limit parameter must be <= 100' });
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof Error && error.message.includes('Invalid pagination parameters')) {
        return res.status(400).json({ error: error.message });
      }
      return res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
