/**
 * Regular expression to validate Base64 strings.
 * Matches valid Base64 characters (A-Z, a-z, 0-9, +, /) with optional padding.
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Error message thrown when Base64 decoding fails.
 */
const DECODE_ERROR = 'Failed to decode Base64 input';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!trimmed) {
    throw new Error(DECODE_ERROR);
  }

  // Validate that input contains only valid Base64 characters
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error(DECODE_ERROR);
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Verify that the decoded result is valid UTF-8
    // If the input was invalid base64, Buffer.from may produce garbage
    // We verify by re-encoding and comparing (this catches malformed padding)
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Normalize padding for comparison
    const normalizedInput = trimmed.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error(DECODE_ERROR);
    }

    return result;
  } catch (error) {
    throw new Error(DECODE_ERROR);
  }
}
