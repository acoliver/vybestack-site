// Debug script to understand why callback unsubscribe isn't working
import { createInput, createComputed, createCallback } from './dist/index.js';

console.log('Starting callback unsubscribe debug...');

// Test case: callbacks can be added and removed
const [input, setInput] = createInput(11);
const output = createComputed(() => input() + 1);

const values1 = [];
console.log('Creating first callback and subscribing...');
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 called with value:', output());
  values1.push(output());
});

const values2 = [];
console.log('Creating second callback and subscribing...');
const unsubscribe2 = createCallback(() => {
  console.log('Callback 2 called with value:', output());
  values2.push(output());
});

console.log('Setting input to 31 (should trigger both callbacks)...');
setInput(31);

console.log('After first input change:');
console.log('values1 length:', values1.length, 'values1:', values1);
console.log('values2 length:', values2.length, 'values2:', values2);

console.log('Unsubscribing first callback...');
unsubscribe1();

console.log('Setting input to 41 (should trigger only second callback)...');
setInput(41);

console.log('After second input change:');
console.log('values1 length:', values1.length, 'values1:', values1);
console.log('values2 length:', values2.length, 'values2:', values2);

console.log('Expected: values2.length should be greater than values1.length');
console.log('Actual: values2.length =', values2.length, ', values1.length =', values1.length);
console.log('Test condition:', values2.length > values1.length);