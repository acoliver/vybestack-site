/**
 * Callback test to debug the unsubscribe behavior.
 */

import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing callback unsubscribe functionality...')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log(`Callback 1 fired: ${output()}`)
  values1.push(output())
})
const values2 = []
createCallback(() => {
  console.log(`Callback 2 fired: ${output()}`)
  values2.push(output())
})

setInput(31)
console.log(`After setInput(31): values1=${values1.length}, values2=${values2.length}`)

unsubscribe1()
console.log('Called unsubscribe1()')

setInput(41)
console.log(`After setInput(41): values1=${values1.length}, values2=${values2.length}`)

console.log(`Final values1: [${values1.join(', ')}], length: ${values1.length}`)
console.log(`Final values2: [${values2.join(', ')}], length: ${values2.length}`)