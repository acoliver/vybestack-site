/**
 * Simple debug test for reactive system.
 */

import { createInput, createComputed, createCallback } from './src/index.js'

// Test for computed dependencies
console.log('Testing computed dependencies...')

// Create input
const [input, setInput] = createInput(1)
console.log(`Initial input value: ${input()}`)

// Create computed that depends on input
const double = createComputed(() => {
  const val = input()
  console.log(`Computing double: ${val} * 2`)
  return val * 2
})
console.log(`Initial double value: ${double()}`)

// Change input
setInput(3)
console.log(`After setInput to 3, input value: ${input()}`)
console.log(`After setInput to 3, double value: ${double()}`)

// Test comprehensive scenario
console.log('\nTesting comprehensive scenario...')

const [input2, setInput2] = createInput(1)
const timesTwo = createComputed(() => {
  console.log(`Computing timesTwo: ${input2()} * 2`)
  return input2() * 2
})
const timesThirty = createComputed(() => {
  console.log(`Computing timesThirty: ${input2()} * 30`)
  return input2() * 30
})
const sum = createComputed(() => {
  console.log(`Computing sum: ${timesTwo()} + ${timesThirty()}`)
  return timesTwo() + timesThirty()
})

console.log(`Initial sum: ${sum()}`)
console.log('Setting input2 to 3...')
setInput2(3)
console.log(`After setInput2 to 3, sum: ${sum()}`)
console.log('Direct sum call again (should be cached):')
console.log(`Sum again: ${sum()}`)

// Test callback
console.log('\nTesting callbacks...')

const [input3, setInput3] = createInput(1)
const output = createComputed(() => {
  console.log(`Computing output: ${input3()} + 1`)
  return input3() + 1
})
let value = 0
createCallback(() => {
  console.log(`Callback fired: output is ${output()}`)
  value = output()
})
console.log(`Setting input3 to 3...`)
setInput3(3)
console.log(`Callback result value: ${value}`)

// Test multiple callbacks
console.log('\nTesting multiple callbacks...')

const [input4, setInput4] = createInput(11)
const output2 = createComputed(() => {
  console.log(`Computing output2: ${input4()} + 1`)
  return input4() + 1
})

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log(`Callback 1: ${output2()}`)
  values1.push(output2())
})

const values2 = []
createCallback(() => {
  console.log(`Callback 2: ${output2()}`)
  values2.push(output2())
})

console.log(`Setting input4 to 31...`)
setInput4(31)
console.log(`Unsubscribing callback 1...`)
unsubscribe1()
console.log(`Setting input4 to 41...`)
setInput4(41)

console.log(`Values1: [${values1.join(', ')}] (length: ${values1.length})`)
console.log(`Values2: [${values2.join(', ')}] (length: ${values2.length})`)