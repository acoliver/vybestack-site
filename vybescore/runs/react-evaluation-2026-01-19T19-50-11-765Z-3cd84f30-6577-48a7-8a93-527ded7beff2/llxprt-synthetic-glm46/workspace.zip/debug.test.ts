/**
 * Debug test for reactive system.
 */

import { describe, it, expect } from 'vitest'
import { createInput, createComputed } from './src/index.js'

describe('Reactive Debug', () => {
  it('debug step by step', () => {
    // Create input
    const [input, setInput] = createInput(1)
    console.log(`Initial input value: ${input()}`)
    
    // Create computed that depends on input
    const double = createComputed(() => {
      const val = input()
      console.log(`Computing double: ${val} * 2`)
      return val * 2
    })
    console.log(`Initial double value: ${double()}`)
    
    // Change input
    setInput(3)
    console.log(`After setInput, input value: ${input()}`)
    console.log(`After setInput, double value: ${double()}`)
    
    expect(double()).toBe(6)
  })
})