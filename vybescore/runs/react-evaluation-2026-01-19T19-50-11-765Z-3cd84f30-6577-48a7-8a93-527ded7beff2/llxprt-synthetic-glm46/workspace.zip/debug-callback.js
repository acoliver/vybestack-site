/**
 * Simple debug script to test callback behavior.
 */

import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing callback unsubscribe...')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = () => {
  console.log('Unsubscribing callback 1')
  // This callback should stop receiving updates after unsubscribing
}
const actualUnsubscribe1 = createCallback(() => {
  console.log(`Callback 1: ${output()}`)
  values1.push(output())
})

// Replace the returned unsubscribe function with our debug version
const realUnsubscribe = actualUnsubscribe1
 unsubscribe1 = realUnsubscribe

const values2 = []
createCallback(() => {
  console.log(`Callback 2: ${output()}`)
  values2.push(output())
})

console.log('Setting input to 31...')
setInput(31)

console.log('Calling unsubscribe1...')
realUnsubscribe()

console.log('Setting input to 41...')
setInput(41)

console.log(`Values1: [${values1.join(', ')}] (length: ${values1.length})`)
console.log(`Values2: [${values2.join(', ')}] (length: ${values2.length})`)