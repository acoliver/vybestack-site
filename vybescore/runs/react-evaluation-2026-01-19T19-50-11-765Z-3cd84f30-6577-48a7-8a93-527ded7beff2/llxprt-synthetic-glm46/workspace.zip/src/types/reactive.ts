/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean
  subjects?: Set<Subject<unknown>>  // Move subjects to base type
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    // Add a safety check to prevent excessive observer growth
    if (observer.subjects && observer.subjects.size > 100) {
      console.warn('Observer has too many dependencies, stopping further updates')
      return
    }
    
    // Only run the update function if we're not already in deep recursion
    // This prevents infinite callback loops
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
  } finally {
    activeObserver = previous
  }
}

// Add an isUpdating flag to prevent infinite computation chains
let isComputing = false

export function setIsComputing(value: boolean): void {
  isComputing = value
}

export function getIsComputing(): boolean {
  return isComputing
}

// Track notification depth to prevent infinite loops
let notificationDepth = 0
const maxNotificationDepth = 50

export function notifyObservers<T>(subject: Subject<T>): void {
  if (notificationDepth >= maxNotificationDepth) {
    return
  }
  
  const observers = Array.from(subject.observers)
  if (observers.length === 0) return
  
  notificationDepth++
  
  try {
    // Create a snapshot of current observers to avoid issues with observers being removed during iteration
    const activeObservers = observers.filter(observer => !observer.disposed)
    
    // Limit the number of updates to prevent runaway loops
    if (activeObservers.length > 100) {
      console.warn('Too many observers, limiting updates to prevent memory issues')
      return
    }
    
    // Update all observers
    for (const observer of activeObservers) {
      if (!observer.disposed) {
        // Trigger update by calling updateObserver
        updateObserver(observer as Observer<unknown>)
      }
    }
  } finally {
    notificationDepth--
  }
}

export function addObserverToSubject<T>(observer: ObserverR, subject: Subject<T>): void {
  if (observer.disposed) return
  
  subject.observers.add(observer)
  
  if (!observer.subjects) {
    observer.subjects = new Set()
  }
  observer.subjects.add(subject as Subject<unknown>)
}

export function removeObserverFromSubject<T>(observer: ObserverR, subject: Subject<T>): void {
  subject.observers.delete(observer)
  
  if (observer.subjects) {
    observer.subjects.delete(subject as Subject<unknown>)
  }
}

export function disposeObserver(observer: ObserverR): void {
  observer.disposed = true
  
  if (observer.subjects) {
    for (const subject of observer.subjects) {
      subject.observers.delete(observer)
    }
    observer.subjects.clear()
  }
}
