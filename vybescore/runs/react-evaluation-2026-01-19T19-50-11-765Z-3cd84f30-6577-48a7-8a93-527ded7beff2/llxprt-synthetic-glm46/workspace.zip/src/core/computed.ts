/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  updateObserver,
  addObserverToSubject,
  removeObserverFromSubject,
  EqualFn,
  Subject,
  notifyObservers,
  setIsComputing
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject for this computed value to be able to be observed
  const computedSubject: Subject<T> = {
    name: `computed-${options?.name || ''}`,
    observers: new Set(),
    value: undefined as T,  // Temporary initial value
  }
  
  // Track whether computed has dependencies
  let hasDependencies = false
  
  let cachedValue: T = value as T
  let dirty = true
  
  // The computed observer will be notified when dependencies change
  const computedObserver: Observer<T> = {
    value: cachedValue,
    updateFn: (prevValue) => {
      dirty = true
      
      // If we have dependencies, clear them to re-establish
      if (hasDependencies && computedObserver.subjects) {
        for (const subject of computedObserver.subjects) {
          removeObserverFromSubject(computedObserver, subject)
        }
        computedObserver.subjects.clear()
      }
      
      // Mark as computing to prevent cycles
      setIsComputing(true)
      
      try {
        // Recompute the value
        const newValue = updateFn(prevValue)
        cachedValue = newValue
        computedSubject.value = cachedValue
      } finally {
        setIsComputing(false)
      }
      
      // Notify all our observers that we have changed
      notifyObservers(computedSubject)
      
      return cachedValue
    },
    subjects: new Set(),
  }
  
  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Establish dependency between current observer and this computed value's subject
      addObserverToSubject(currentObserver, computedSubject)
    }
    
    // If value is dirty, recompute
    if (dirty) {
      dirty = false
      
      // Execute update function as the active observer to track dependencies
      // This ensures any inputs/computed values accessed during computation are tracked
      updateObserver(computedObserver)
      
      // Store computed value in subject
      computedSubject.value = cachedValue
    }
    
    return cachedValue
  }
  
  // Note: We don't do an initial read here to avoid issues with default parameters
  
  // Register this computed observer with its subject
  computedSubject.observers.add(computedObserver)
  
  return read
}
