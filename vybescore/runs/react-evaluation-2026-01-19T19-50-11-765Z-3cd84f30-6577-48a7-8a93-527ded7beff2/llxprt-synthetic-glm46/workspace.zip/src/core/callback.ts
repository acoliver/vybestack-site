/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, disposeObserver, getActiveObserver, addObserverToSubject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set(),
  }
  
  // Create observer that will track dependencies when its update function runs
  // We don't immediately call updateObserver here - let it happen naturally when dependencies change
  
  let disposed = false
  
  // Establish initial dependencies by executing the function in observer context
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Dispose the observer to clean up all subject relationships
    disposeObserver(observer)
  }
}
