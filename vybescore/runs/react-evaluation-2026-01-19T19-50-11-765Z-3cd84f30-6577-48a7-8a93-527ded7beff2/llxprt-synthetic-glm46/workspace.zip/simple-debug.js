// Simple debug script to analyze the failing test
import { createInput, createComputed, createCallback } from './dist/index.js';

console.log('Testing callback unsubscribe...');

// Simplified test case based on the failing 
const [input, setInput] = createInput(11);
const output = createComputed(() => input() + 1);

const values1 = [];
const unsubscribe1 = createCallback(() => values1.push(output()));
const values2 = [];
createCallback(() => values2.push(output()));

console.log('Initial state:');
console.log('Initial output value:', output());

// First change - should trigger both callbacks
console.log('\nSetting input to 31...');
setInput(31);

console.log('After first change:');
console.log('values1 length:', values1.length, 'values1 content:', values1);
console.log('values2 length:', values2.length, 'values2 content:', values2);

// Unsubscribe first callback
console.log('\nUnsubscribing first callback...');
unsubscribe1();

// Second change - should trigger only second callback
console.log('\nSetting input to 41...');
setInput(41);

console.log('After second change:');
console.log('values1 length:', values1.length, 'values1 content:', values1);
console.log('values2 length:', values2.length, 'values2 content:', values2);

console.log('\nFinal state:');
console.log('Expected: values2.length > values1.length');
console.log('Actual: values2.length =', values2.length, ', values1.length =', values1.length);
console.log('Test result:', values2.length > values1.length);