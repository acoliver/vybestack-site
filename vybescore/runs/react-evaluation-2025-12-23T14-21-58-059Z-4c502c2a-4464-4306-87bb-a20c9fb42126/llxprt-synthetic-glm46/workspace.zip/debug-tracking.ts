#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== STEP 1: Create input ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

console.log('=== STEP 2: Create computed ===')
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

console.log('=== STEP 3: Create callback ===')
let value = 0
const unsubscribe = createCallback(() => {
  console.log('=== CALLBACK TRIGGERED ===')
  console.log('Output() is now:', output())
  value = output()
  console.log('Value set to:', value)
  console.log('=== END CALLBACK ===')
})

console.log('Initial value:', value)

console.log('=== STEP 4: Check callback dependencies ===')
const depSystem = (globalThis as any).__dependencySystem
const callbackObserver = Array.from(depSystem.subjects.keys())[2] // The callback observer
console.log('Callback observer subjects:', depSystem.subjects.get(callbackObserver))
console.log('Subjects callback depends on:', [...depSystem.subjects.get(callbackObserver)])

const computedObserver = Array.from(depSystem.subjects.keys())[1] // The computed observer
console.log('Computed observer subjects:', depSystem.subjects.get(computedObserver))
console.log('Subjects computed depends on:', [...depSystem.subjects.get(computedObserver)])

console.log('=== STEP 5: Change input ===')
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - value:', value, '(expected: 4)')
console.log('Current input:', input(), 'output:', output())

console.log('=== STEP 6: Check what notify sees ===')
let foundCallback = false
for (const [observer, subjects] of depSystem.subjects.entries()) {
  if (subjects.has(input)) {
    console.log('Found observer that depends on input!')
    if (observer === callbackObserver) {
      console.log('This is the callback observer!')
      foundCallback = true
    }
  }
}
console.log('Callback found in input subjects?', foundCallback)

console.log('=== STEP 7: Manual call to callback update function ===')
const callbackFn = depSystem.callbacks.get(callbackObserver)
if (callbackFn) {
  console.log('Calling callback manually...')
  callbackFn()
  console.log('Value after manual callback:', value)
}

console.log('=== STEP 8: Final states ===')
console.log('Final input:', input())
console.log('Final output:', output())
console.log('Final value:', value)