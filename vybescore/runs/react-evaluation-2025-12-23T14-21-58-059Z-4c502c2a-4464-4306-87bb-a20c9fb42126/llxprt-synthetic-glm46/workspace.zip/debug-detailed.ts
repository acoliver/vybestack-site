#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== STEP 1: Create input ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

console.log('=== STEP 2: Create computed ===')
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

console.log('=== STEP 3: Create callback ===')
let value = 0

// Manually examine dependency tracking
const depSystem = (globalThis as any).__dependencySystem
console.log('Pre-creation dependency system callbacks:', depSystem.callbacks.size)

const unsubscribe = createCallback(() => {
  console.log('=== CALLBACK TRIGGERED ===')
  console.log('Output() is now:', output())
  value = output()
  console.log('Value set to:', value)
  console.log('=== END CALLBACK ===')
})

console.log('Post-creation dependency system callbacks:', depSystem.callbacks.size)
console.log('Dependency system callbacks Map entries:', [...depSystem.callbacks.entries()])

console.log('Initial value:', value)

console.log('=== STEP 4: Check subjects ===')
console.log('Dependency system subjects:', [...depSystem.subjects.entries()])

console.log('=== STEP 5: Change input ===')
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - value:', value, '(expected: 4)')
console.log('Current input:', input(), 'output:', output())

console.log('=== STEP 6: Manual notify check ===')
console.log('Will now manually trigger notify to see if it works:')
depSystem.notify(input)
console.log('After manual notify - value:', value)

console.log('=== STEP 7: Final states ===')
console.log('Final input:', input())
console.log('Final output:', output())
console.log('Final value:', value)