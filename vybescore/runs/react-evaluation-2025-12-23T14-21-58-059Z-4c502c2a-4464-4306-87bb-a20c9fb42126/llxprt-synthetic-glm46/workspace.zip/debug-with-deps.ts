#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== STEP 1: Create input ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

console.log('=== STEP 2: Access input from callback to set up dependency ===')
let dependenciesEstablished = false
const testCallback = createCallback(() => {
  console.log('Test callback fired, input() is:', input())
  dependenciesEstablished = true
})

console.log('Dependencies established?', dependenciesEstablished)

console.log('=== STEP 3: Create computed ===')
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

console.log('=== STEP 4: Create callback that uses computed ===')
let value = 0
const unsubscribe = createCallback(() => {
  console.log('=== CALLBACK TRIGGERED ===')
  console.log('Output() is now:', output())
  value = output()
  console.log('Value set to:', value)
  console.log('=== END CALLBACK ===')
})

console.log('Initial value:', value)

console.log('=== STEP 5: Check dependency system ===')
const depSystem = (globalThis as any).__dependencySystem
console.log('Dependency system subjects entries:', [...depSystem.subjects.entries()])

console.log('=== STEP 6: Change input ===')
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - value:', value, '(expected: 4)')
console.log('Current input:', input(), 'output:', output())

console.log('=== STEP 7: Final states ===')
console.log('Final input:', input())
console.log('Final output:', output())
console.log('Final value:', value)

console.log('=== STEP 8: Check subjects again ===')
console.log('Dependency system subjects entries:', [...depSystem.subjects.entries()])