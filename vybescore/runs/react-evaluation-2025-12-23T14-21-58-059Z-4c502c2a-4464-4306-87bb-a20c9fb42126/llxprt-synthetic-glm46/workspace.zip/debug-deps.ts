#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Testing working solution ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

// When accessed, computed reads from current input
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

let value = 0
const unsubscribe = createCallback(() => {
  console.log('=== CALLBACK TRIGGERED ===')
  console.log('Output() is now:', output())
  value = output()
  console.log('Value set to:', value)
  console.log('=== END CALLBACK ===')
})

console.log('Initial value:', value)
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - value:', value, '(expected: 4)')
console.log('Current input:', input(), 'output:', output())

// Add debug to show the dependency system
const depSystem = (globalThis as any).__dependencySystem
console.log('=== DEPENDENCY DEBUG ===')
console.log('Total observers:', depSystem.observers.size)
console.log('Total subjects in registry:', depSystem.subjects.size)
for (const [observer, subjects] of depSystem.subjects.entries()) {
  console.log('Observer depends on subjects:', subjects.size)
  for (const subject of subjects) {
    console.log('  Subject value:', subject.value)
  }
}