#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Testing simplified direct pattern ===')

console.log('=== STEP 1: Create input ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

console.log('=== STEP 2: Create computed ===')
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

console.log('=== STEP 3: Create callback ===')
let value = 0
const unsubscribe = createCallback(() => {
  console.log('=== CALLBACK TRIGGERED ===')
  console.log('Output() is now:', output())
  value = output()
  console.log('Value set to:', value)
  console.log('=== END CALLBACK ===')
})

console.log('Initial value:', value)

console.log('=== STEP 4: Change input ===')
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - value:', value, '(expected: 4)')
console.log('Current input:', input(), 'output:', output())