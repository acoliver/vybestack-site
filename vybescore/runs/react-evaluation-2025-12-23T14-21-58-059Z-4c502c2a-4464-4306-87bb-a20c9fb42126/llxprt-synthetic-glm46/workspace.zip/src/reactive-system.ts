/**
 * Reactive coordination system for managing dependencies and updates
 */

import { Observer, Subject } from './types/reactive.js'

// Global tracking of dependencies
const systemState = {
  activeSubject: null as Subject<unknown> | null,
  activeObserver: null as Observer<unknown> | null,
  
  // Maps observers to the subjects they depend on
  observerToSubjects: new WeakMap<Observer<unknown>, Set<Subject<unknown>>>(),
  
  // Maps subjects to the observers that depend on them
  subjectToObservers: new WeakMap<Subject<unknown>, Set<Observer<unknown>>>()
}

// Export a global instance for use across modules
export const reactiveSystem = systemState