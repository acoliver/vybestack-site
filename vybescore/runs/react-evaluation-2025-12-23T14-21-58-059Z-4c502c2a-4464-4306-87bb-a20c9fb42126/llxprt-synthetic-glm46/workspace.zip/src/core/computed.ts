import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

export function createComputed<T>(updateFn: UpdateFn<T>, value?: T, _equal?: boolean | EqualFn<T>, options?: { name?: string }): GetterFn<T> {
  const o: Observer<T> = { name: options?.name, value, updateFn }
  const getter: GetterFn<T> = () => { updateObserver(o); return o.value! }
  return getter
}
