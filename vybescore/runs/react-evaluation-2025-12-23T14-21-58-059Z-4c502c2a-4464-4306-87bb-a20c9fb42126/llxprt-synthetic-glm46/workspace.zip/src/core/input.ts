/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getSubjectObservers,
  addSubjectObserver
} from '../types/reactive.js'

// Force creation of the global dependency system if it doesn't exist
const globalInterface = globalThis as { __dependencySystem?: unknown }
if (!globalInterface.__dependencySystem) {
  const dependencySystem = {
    observers: new Set(),
    subjects: new Map(),
    callbacks: new Map(),
    register() {},
    notify() {},
    onNotify() {},
    cleanup() {}
  }
  globalInterface.__dependencySystem = dependencySystem
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Add this observer to global registry
      addSubjectObserver(s, observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    const equalFn = typeof _equal === 'function' ? _equal : undefined
    const shouldSkip = equalFn ? equalFn(prevValue, nextValue) : prevValue === nextValue
    
    if (!shouldSkip) {
      s.value = nextValue
      
      // Get all observers that depend on this subject
      const observers = getSubjectObservers(s)
      if (observers) {
        for (const observer of observers) {
          updateObserver(observer)
        }
      }
      
      // Also notify dependency system
      const globalInterface = globalThis as {
        __dependencySystem?: {
          notify?: (subject: Subject<T>) => void
        }
      }
      if (globalInterface.__dependencySystem?.notify) {
        globalInterface.__dependencySystem.notify(s)
      }
      
      // Manually trigger observer updates for any computed values that depend on this input
      const subjectObservers = getSubjectObservers(s)
      if (subjectObservers) {
        for (const observer of subjectObservers) {
          // Update the observer, which should trigger recomputation
          updateObserver(observer)
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
