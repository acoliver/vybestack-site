/**
 * Callback closure implementation for reactive side effects.
 */

/**
 * Global system for tracking reactive dependencies and updates
 */
const dependencySystem = {
  observers: new Set<Observer<unknown>>(),
  subjects: new Map<Observer<unknown>, Set<unknown>>(),
  callbacks: new Map<Observer<unknown>, (() => void)>(),
  
  // Register an observer for a subject
  register(subject: unknown, observer: Observer<unknown>) {
    this.observers.add(observer)
    let subjects = this.subjects.get(observer)
    if (!subjects) {
      subjects = new Set()
      this.subjects.set(observer, subjects)
    }
    subjects.add(subject)
    console.log('Register: subject registered to observer')
  },
  
  // Notify all observers that depend on a subject
  notify(subject: unknown) {
    const observersToNotify = []
    for (const [observer, subjects] of this.subjects.entries()) {
      if (subjects.has(subject)) {
        const callback = this.callbacks.get(observer)
        if (callback) {
          observersToNotify.push(callback)
        }
      }
    }
    // Execute notifications in a separate loop to avoid mutation during iteration
    for (const notifyCallback of observersToNotify) {
      notifyCallback()
    }
  },
  
  // Add a callback for when observer dependencies change
  onNotify(observer: Observer<unknown>, callback: () => void) {
    this.callbacks.set(observer, callback)
  },
  
  // Cleanup
  cleanup(observer: Observer<unknown>) {
    this.observers.delete(observer)
    this.subjects.delete(observer)
    this.callbacks.delete(observer)
  }
}

// Make dependency system globally accessible
;(globalThis as { __dependencySystem?: typeof dependencySystem }).__dependencySystem = dependencySystem

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create observer that tracks dependencies
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue as T
      // Execute the callback function
      const result = updateFn(prevValue)
      return result
    },
  }
  
  // Execute the callback initially to establish dependencies
  updateObserver(observer)
  
  // Register callback for when dependencies change
  dependencySystem.onNotify(observer as Observer<unknown>, () => {
    if (disposed) return
    // Re-execute the callback when dependencies change
    updateObserver(observer)
  })
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Cleanup from dependency system
    dependencySystem.cleanup(observer as Observer<unknown>)
  }
}
