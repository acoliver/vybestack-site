/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry for tracking reactive dependencies using regular Maps for better tracking
const globalSubjectToObservers = new Map<unknown, Set<Observer<unknown>>>()
const globalObserverToSubjects = new Map<Observer<unknown>, Set<unknown>>()

export function getSubjectObservers<T>(subject: Subject<T>): Set<Observer<unknown>> | undefined {
  return globalSubjectToObservers.get(subject)
}

export function addSubjectObserver<T>(subject: Subject<T>, observer: Observer<unknown> | ObserverR): void {
  let observers = globalSubjectToObservers.get(subject)
  if (!observers) {
    observers = new Set()
    globalSubjectToObservers.set(subject, observers)
  }
  // Force to Observer<unknown> for the Set storage
  observers.add(observer as Observer<unknown>)
  
  // Also track reverse relationship for cleanup
  let subjects = globalObserverToSubjects.get(observer as Observer<unknown>)
  if (!subjects) {
    subjects = new Set()
    globalObserverToSubjects.set(observer as Observer<unknown>, subjects)
  }
  subjects.add(subject)
  
  // Also notify the callback system
  const globalInterface = globalThis as {
    __dependencySystem?: {
      register?: (subject: unknown, observer: Observer<unknown>) => void
    }
  }
  if (globalInterface.__dependencySystem?.register) {
    globalInterface.__dependencySystem.register(subject, observer as Observer<unknown>)
  }
}

export function removeSubjectObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  const observers = globalSubjectToObservers.get(subject)
  if (observers) {
    observers.delete(observer)
  }
  
  const subjects = globalObserverToSubjects.get(observer)
  if (subjects) {
    subjects.delete(subject)
  }
}
