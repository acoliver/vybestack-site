#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== STEP 1: Create input ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

console.log('=== STEP 2: Create computed ===')
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

console.log('=== STEP 3: Create callback ===')
let value = 0
const unsubscribe = createCallback(() => {
  console.log('Callback triggered! Setting value:', output())
  value = output()
})
console.log('Initial value:', value)

console.log('=== STEP 4: Change input ===')
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - value:', value, '(expected: 4)')
console.log('Current input:', input(), 'output:', output())

console.log('=== STEP 5: Final states ===')
console.log('Final input:', input())
console.log('Final output:', output())
console.log('Final value:', value)