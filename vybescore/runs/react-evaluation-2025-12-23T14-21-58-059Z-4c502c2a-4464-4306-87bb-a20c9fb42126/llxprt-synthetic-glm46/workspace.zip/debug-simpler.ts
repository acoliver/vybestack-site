#!/usr/bin/env tsx
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== STEP 1: Create callback without dependencies ===')
let directInputValue = 0
const directCallback = createCallback(() => {
  console.log('Direct callback triggered')
})

console.log('=== STEP 2: Create input ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

console.log('=== STEP 3: Create callback that directly depends on input ===')
let indirectValue = 0
createCallback(() => {
  console.log('=== INDIRECT CALLBACK TRIGGERED ===')
  console.log('Input() is now:', input())
  indirectValue = input()
  console.log('Indirect value set to:', indirectValue)
  console.log('=== END INDIRECT CALLBACK ===')
})

console.log('Initial indirectValue:', indirectValue)

console.log('=== STEP 4: Change input and test direct dependency ===')
console.log('Setting input to 3')
setInput(3)
console.log('After setInput - indirectValue:', indirectValue, '(expected: 3)')

console.log('=== STEP 5: Test computed indirection ===')
const output = createComputed(() => input() + 1)
console.log('Computed output is:', output())

console.log('=== STEP 6: Create callback that depends on computed ===')
let computedValue = 0
createCallback(() => {
  console.log('=== COMPUTED CALLBACK TRIGGERED ===')
  console.log('Output() is now:', output())
  computedValue = output()
  console.log('Computed value set to:', computedValue)
  console.log('=== END COMPUTED CALLBACK ===')
})

console.log('Initial computedValue:', computedValue)
console.log('Setting input to 5')
setInput(5)
console.log('After setInput - computedValue:', computedValue, '(expected: 6)')