import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validateParams(page?: number, limit?: number): { error?: string } {
  if (page !== undefined && (!Number.isInteger(page) || page < 1)) {
    return { error: 'page must be a positive integer' };
  }
  if (limit !== undefined && (!Number.isInteger(limit) || limit < 1 || limit > 100)) {
    return { error: 'limit must be a positive integer (1-100)' };
  }
  return {};
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const validation = validateParams(page, limit);
    if (validation.error) {
      return res.status(400).json({ error: validation.error });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
