/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Dependency tracking: map from observable -> set of observers that depend on it
export const dependencies = new Map<ObserverR, Set<ObserverR>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Record that the current active observer depends on a reactive subject
export function trackDependency(subject: ObserverR): void {
  if (activeObserver && activeObserver !== subject) {
    if (!dependencies.has(subject)) {
      dependencies.set(subject, new Set())
    }
    dependencies.get(subject)!.add(activeObserver)
  }
}

// Update an observer without triggering notification (used for notifyDependents)
export function updateObserverDirect<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Update an observer and trigger notification of dependents
export function updateObserver<T>(observer: Observer<T>): void {
  updateObserverDirect(observer)
  notifyDependents(observer)
}

// Notify all observers that depend on this one
export function notifyDependents(observer: ObserverR): void {
  const dependents = dependencies.get(observer)
  if (dependents) {
    // Create a copy to avoid issues with concurrent modifications
    const deps = Array.from(dependents)
    deps.forEach(dep => {
      if (dep !== activeObserver) {
        updateObserverDirect(dep as Observer<unknown>)
        // After updating direct dependents, also notify their dependents
        const savedActive = activeObserver
        try {
          notifyDependents(dep)
        } finally {
          activeObserver = savedActive
        }
      }
    })
  }
}
