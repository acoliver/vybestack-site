/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  trackDependency,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equality to function for internal consistency
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue)
      
      // Check equality if function is provided  
      if (equalFn && prevValue !== undefined && equalFn(prevValue, newValue)) {
        return prevValue // No change needed
      }
      
      return newValue
    },
  }
  
  // Register dependencies during initial computation
  updateObserver(o)
  
  // Return a getter that accesses the computed value
  const computedGetter = (): T => {
    // When accessed within an observer context, track this dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      trackDependency(o)
    }
    return o.value!
  }
  
  return computedGetter
}
