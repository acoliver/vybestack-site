/**
 * Capitalizes the first character of each sentence.
 * Handles punctuation (.?!) and ensures proper spacing.
 * Preserves abbreviations when possible and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces to a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Add space after punctuation if missing
  result = result.replace(/([.?!])([a-z])/gi, '$1 $2');
  
  // Split into sentences using punctuation marks as delimiters
  const sentences = result.split(/(?<=[.?!])/);
  
  // Capitalize the first letter of each sentence
  const capitalized = sentences.map(sentence => {
    // Find the first letter after possible leading whitespace
    const match = sentence.match(/^\s*([a-z])/i);
    if (match) {
      const firstCharIndex = sentence.indexOf(match[0]) + match[0].indexOf(match[1]);
      return sentence.substring(0, firstCharIndex) + 
             sentence.charAt(firstCharIndex).toUpperCase() + 
             sentence.substring(firstCharIndex + 1);
    }
    return sentence;
  });
  
  // Join back together
  return capitalized.join('');
}

/**
 * Extracts URLs from text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches most common URL formats
  // Includes protocol, domain, optional port, path, query, and fragment
  const urlPattern = /(https?:\/\/[^\s/$.?#].[^\s]*|[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/gi;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Trim trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation (. , ; : ! ? ' ) ] } " etc)
    return url.replace(/[.,;:!?'"')\]}]+$/, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https:// (using negative lookahead)
  return text.replace(/http:\/\/(?!https:)/g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, or legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Process URLs with specific patterns
  return text.replace(/https?:\/\/(example\.com)\/docs\/(.+?)(?=\s|$)/gi, (match, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if we should rewrite the host
    // Skip if path contains dynamic hints or legacy extensions
    const skipRewrite = /\/(cgi-bin)|[?&=]|(\/.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test('/docs/' + path);
    
    if (skipRewrite) {
      // Only upgrade the scheme
      return newProtocol + domain + '/docs/' + path;
    } else {
      // Rewrite host to docs.example.com
      return newProtocol + 'docs.' + domain + '/docs/' + path;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format and capture components
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
