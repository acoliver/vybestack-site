/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a pattern to match words with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9]+\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Convert exceptions to a Set for efficient look-up
  const exceptionsSet = new Set(exceptions);
  
  // Filter out exceptions
  return matches.filter(word => !exceptionsSet.has(word));
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds as required.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit followed by token
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  return text.match(tokenPattern) || [];
}

/**
 * Validates password strength.
 * Requirements: at least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Length check (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Character type checks
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!#$%&'*+,.:;<>?@^_`{}~-]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }
  
  // Check for repeated characters (e.g., aaa, bbb) - only if 3 or more in a row
  if (/(.)\1\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  const ipv6Patterns = [
    // Full IPv6 pattern (8 groups of 1-4 hex digits separated by colons)
    /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})$/,
    // With :: compression (at most one instance)
    /^((([0-9a-fA-F]{1,4}:){1,7}:|::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|^([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})$/,
    // IPv4-mapped IPv6 address
    /^(::ffff:(\d{1,3}\.){3}\d{1,3})$/,
    // IPv4-compatible IPv6 address
    /^:(\d{1,3}\.){3}\d{1,3}$/,
    // IPv6 with port suffix
    /^(\[[0-9a-fA-F:]+\])((:|\/)\d*)?$/
  ];

  // Check if the value matches any IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value.trim())) {
      return true;
    }
  }

  // A more comprehensive IPv6 pattern that covers all cases
  // From RFC 4291 standard
  const ipv6Regex = /^(?:(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})|(([0-9a-fA-F]{1,4}:){1,6}:([0-9a-fA-F]{1,4}:){0,1}[0-9a-fA-F]{1,4})|(([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2})|(([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3})|(([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4})|(([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5})|(([0-9a-fA-F]{1}:){1,6}(:[0-9a-fA-F]{1,4}){1,6})|(:((:[0-9a-fA-F]{1,4}){1,7}|:))|(([0-9a-fA-F]{1,4}:){6}:(\d{1,3}\.){3}\d{1,3})|((([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4})|((([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::)(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?)$/;
  
  // Extract potential addresses from the text
  const potentialIPs = value.match(/\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/g) || [];
  
  for (const ip of potentialIPs) {
    // Check if it's an IPv4 address first - if so, skip it
    const ipv4Pattern = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (ipv4Pattern.test(ip)) {
      continue; // Skip IPv4 addresses
    }
    
    // Check if it matches the IPv6 pattern
    if (ipv6Regex.test(ip)) {
      return true;
    }
  }
  
  return false;
}
