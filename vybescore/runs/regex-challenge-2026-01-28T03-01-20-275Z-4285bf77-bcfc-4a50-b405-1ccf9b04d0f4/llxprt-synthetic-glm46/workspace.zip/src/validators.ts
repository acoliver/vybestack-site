export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, ''); // Remove non-digits
  
  let sum = 0;
  let shouldDouble = false;
  
  // Loop from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows unicode letters in the local part
  // - Rejects leading/trailing dots and consecutive dots
  // - Rejects underscores in domain
  // - Allows common TLDs
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  const invalidPatterns = [
    /\.\./, // consecutive dots
    /^\./, // leading dot
    /\.$/, // trailing dot
    /_.*@/, // underscore in domain part
    /@.*_/, // underscore in domain part
    /@.*\._/, // underscore after dot in domain
  ];
  
  // Basic pattern check
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional invalid pattern checks
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // For future extension handling - currently not used in validation
  // but might be useful if extensions are added later
  // (keeping for API compatibility)
  void options; // Explicitly mark as intentionally unused
  
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');
  
  // Minimum length check (10 digits without country code, 11 with)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Extract number without country code if present
  let phoneNumber = cleaned;
  if (phoneNumber.length === 11 && phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.substring(1);
  } else if (phoneNumber.length > 10) {
    // If it's longer than 10 but doesn't start with 1, it's invalid
    return false;
  }
  
  // Area code can't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Format validation - check if the original matches one of the accepted formats
  const validFormats = [
    /^\+?1?\s*\(?([2-9]\d{2})\)?\s*[-.\s]?([2-9]\d{2})\s*[-.\s]?(\d{4})$/, // (212) 555-7890, +1 (212) 555-7890
    /^\+?1?\s*([2-9]\d{2})\s*[-.\s]?([2-9]\d{2})\s*[-.\s]?(\d{4})$/, // 212-555-7890, +1 212-555-7890
    /^\+?1?([2-9]\d{9})$/, // 2125557890, +12125557890
  ];
  
  return validFormats.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits in total
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize input: replace spaces with hyphens for regex, then validate
  const normalized = value.replace(/\s/g, '-');
  
  // Remove all non-digit and non-hyphen characters for easier validation
  const cleanDigits = normalized.replace(/[^\d-]/g, '');
  
  // Debug info for troubleshooting
  if (process.env.DEBUG_PHONE === 'true') {
    console.log('Original:', value);
    console.log('Normalized:', normalized);
    console.log('Clean digits:', cleanDigits);
  }
  
  // Argentine phone patterns:
  // 1. Country code + followed by area code and subscriber
  // 2. Trunk prefix 0 followed by area code and subscriber
  
  // Split by hyphen to get parts
  const parts = cleanDigits.split('-');
  
  // Check if we have the right number of parts
  if (parts.length < 2) {
    return false;
  }
  
  // Check if the first part is a country code
  if (parts[0] === '+54' || parts[0] === '54') {
    // Country code format - next part should be area code, then subscriber
    if (parts.length < 3) {
      return false;
    }
    
    const areaCode = parts[1];
    const subscriber = parts.length === 4 ? parts[2] + parts[3] : parts[2];
    
    // Check area code (2-4 digits, leading digit 1-9)
    if (!/^([1-9]\d{1,3})$/.test(areaCode)) {
      return false;
    }
    
    // Check subscriber (6-8 digits)
    if (!/^(\d{6,8})$/.test(subscriber)) {
      return false;
    }
  } else if (parts[0] === '0') {
    // Trunk prefix format - next part should be area code, then subscriber
    if (parts.length < 3) {
      return false;
    }
    
    const areaCode = parts[1];
    const subscriber = parts.length === 4 ? parts[2] + parts[3] : parts[2];
    
    // Check area code (2-4 digits, leading digit 1-9)
    if (!/^([1-9]\d{1,3})$/.test(areaCode)) {
      return false;
    }
    
    // Check subscriber (6-8 digits)
    if (!/^(\d{6,8})$/.test(subscriber)) {
      return false;
    }
  } else {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name validation pattern:
  // - Allows unicode letters (including accented characters)
  // - Allows apostrophes and hyphens
  // - Allows spaces between name parts
  // - Rejects digits, symbols (except apostrophes and hyphens)
  // - Disallows names that are just symbols
  const namePattern = /^[\p{L}\p{M}'-]+(?:[\s]+[\p{L}\p{M}'-]+)*$/u;
  
  // Additional validation to reject problematic names
  const invalidPatterns = [
    /\d/, // Any digits
    /[^\p{L}\p{M}'\s-]/u, // Any symbols except allowed ones
    /^[^'\p{L}\p{M}]+$/u, // Can't start with non-letter
  ];
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  // Check minimum length (at least some actual letters, not just symbols)
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letterCount < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Check Visa: starts with 4, length 13 or 16
  const visaPattern = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-4]\d|[4-9]\d|10[0-2]|210[1-9]|22\d)\d{11})$/;
  
  // Check Amex: starts with 34 or 37, length 15
  const amexPattern = /^(34|37)\d{13}$/;
  
  // Validate against card type patterns
  const isValidCardType = visaPattern.test(normalized) || mastercardPattern.test(normalized) || amexPattern.test(normalized);
  
  if (!isValidCardType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(normalized);
}
