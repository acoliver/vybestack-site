/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple whitespace characters with a single space
  text = text.replace(/\s+/g, ' ');
  
  // Pattern to match sentence endings followed by optional whitespace and a character
  const sentenceEndings = /\.|\!|\?/;
  
  // Capitalize the first character of the text
  if (text.length > 0) {
    text = text.charAt(0).toUpperCase() + text.slice(1);
  }
  
  // Capitalize the first character after sentence endings
  return text.replace(
    new RegExp(`(${sentenceEndings.source})\\s+(\\w)`, 'g'),
    (match, ending, char) => `${ending} ${char.toUpperCase()}`
  );
}

/**
 * Extracts all URLs from the text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs (http/https)
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.!?]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't modify already https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * unless the path contains dynamic hints.
 */
export function rewriteDocsUrls(text: string): string {
  // Dynamic hints that prevent host rewrite
  const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
  
  // Replace URLs with docs paths, but only if they don't contain dynamic hints
  return text.replace(
    /http:\/\/([\w\-\.]+)(\/[\w\/\.\-_]*)/g,
    (match, host, path) => {
      // Check if path contains dynamic hints
      const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
      
      // If path starts with /docs/ and has no dynamic hints, rewrite host
      if (path.startsWith('/docs/') && !hasDynamicHint) {
        return `https://docs.${host}${path}`;
      }
      
      // Otherwise just upgrade to https
      return `https://${host}${path}`;
    }
  );
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format with a valid year (4 digits)
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  // Test if the string matches the pattern
  const match = value.match(dateRegex);
  
  // If it matches, return the year (3rd capturing group)
  if (match) {
    const month = parseInt(match[1], 10);
    const day = parseInt(match[2], 10);
    const year = match[3];
    
    // Basic validation of month and day ranges
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return year;
    }
  }
  
  // Return 'N/A' if format is invalid
  return 'N/A';
}