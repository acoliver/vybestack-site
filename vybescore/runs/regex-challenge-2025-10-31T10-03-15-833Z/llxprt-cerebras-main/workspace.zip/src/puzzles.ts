/**
 * Finds words that start with the given prefix but excludes those in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out the exceptions (case insensitive comparison)
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern with lookbehind to ensure it follows a digit
  // and lookahead to ensure it's not at the start of the string
  const regex = new RegExp(`(?<=\\d)${token}`, 'g');
  
  // Find all matches
  return text.match(regex) || [];
}

/**
 * Validates passwords according to strict security requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab)
  // This pattern looks for any sequence of 2 or more characters that repeats
  if (/(.+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positives.
 */
export function containsIPv6(value: string): boolean {
  // Pattern for IPv6 addresses including shorthand notation
  // This is a simplified pattern that covers most common IPv6 formats
  const ipv6Regex = /(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)/;
  
  // Check if value contains an IPv6 address
  return ipv6Regex.test(value);
}