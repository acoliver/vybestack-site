export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical formats like name+tag@example.co.uk
 * Rejects invalid formats like double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Remove whitespace
  value = value.trim();
  
  // Basic email validation pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if it matches the basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain part
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except extension marker 'x'
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if too short
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check if it's now exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Check if area code starts with 0 or 1 (impossible area codes)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove whitespace and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex patterns for Argentine phone numbers
  // Pattern 1: +54 9 11 1234 5678 (mobile with country code)
  // Pattern 2: 011 1234 5678 (landline with trunk prefix)
  // Pattern 3: +54 341 123 4567 (landline with country code)
  // Pattern 4: 0341 4234567 (landline with trunk prefix)
  
  // Check for patterns starting with +54
  if (cleanValue.startsWith('+54')) {
    // Mobile format: +549[area code 2-4 digits][subscriber 6-8 digits]
    // Landline format: +54[area code 2-4 digits][subscriber 6-8 digits]
    const mobileRegex = /^\+549[1-9]\d{1,3}\d{6,8}$/;
    const landlineRegex = /^\+54[1-9]\d{1,3}\d{6,8}$/;
    
    return mobileRegex.test(cleanValue) || landlineRegex.test(cleanValue);
  }
  
  // Check for patterns starting with 0 (trunk prefix)
  if (cleanValue.startsWith('0')) {
    // Format: 0[area code 2-4 digits][subscriber 6-8 digits]
    const regex = /^0[1-9]\d{1,3}\d{6,8}$/;
    return regex.test(cleanValue);
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Remove whitespace from both ends
  value = value.trim();
  
  // Check if empty
  if (!value) {
    return false;
  }
  
  // Pattern for valid names: unicode letters, accents, apostrophes, hyphens, and spaces
  // but no digits or other symbols
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u1E00-\u1EFF''\- ]+$/;
  
  // Check if matches the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check if there are digits in the name
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run the Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) using prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // If not all digits, return false
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check for valid card types based on prefix and length
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/; // 16 digits, starts with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check card type and length
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn algorithm
  return runLuhnCheck(cleanValue);
}