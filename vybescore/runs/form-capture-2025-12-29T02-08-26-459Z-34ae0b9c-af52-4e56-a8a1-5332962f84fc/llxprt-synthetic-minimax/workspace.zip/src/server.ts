import express, { Request, Response } from 'express';
import path from 'path';
import { dbManager, FormSubmission } from './database';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
  data: Partial<FormData>;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/views'));

// Validation functions
function validateFormData(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
  ];

  // Check required fields
  requiredFields.forEach(field => {
    const value = data[field]?.trim();
    if (!value) {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`;
    }
  });

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (international formats)
  if (data.phone && !/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    data
  };
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvinceRegion: req.body.stateProvinceRegion?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData: validation.data,
      title: 'Friendly Contact Form - Please Fix Errors'
    });
  }

  try {
    // Convert FormData to FormSubmission format
    const submission: Omit<FormSubmission, 'submitted_at'> = {
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province_region: formData.stateProvinceRegion,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    await dbManager.insertSubmission(submission);
    console.log('Form submission stored:', submission);

  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your request. Please try again.' },
      formData,
      title: 'Friendly Contact Form - Error'
    });
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', { 
    title: 'Thank You (We\'ll Be In Touch... Constantly)'
  });
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).render('error', { 
    title: 'Error',
    message: 'Something went wrong. Please try again later.' 
  });
});

// Graceful shutdown
async function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  try {
    await dbManager.close();
    console.log('Database connection closed.');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(` Friendly Form Capture server is running on port ${PORT}`);
      console.log(` Form available at: http://localhost:${PORT}/`);
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
