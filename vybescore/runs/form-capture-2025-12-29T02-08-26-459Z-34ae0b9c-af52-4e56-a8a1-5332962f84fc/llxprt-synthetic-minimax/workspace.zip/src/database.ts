import * as fs from 'fs';
import * as path from 'path';
import initSqlJs, { SqlJsStatic, Database, Statement } from 'sql.js';

export interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  submitted_at?: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = process.env.DB_PATH || path.join(process.cwd(), 'data/submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db/schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js with default locateFile to let it find WASM automatically
      const SQL: SqlJsStatic = await initSqlJs();

      const dir = path.dirname(this.dbPath);
      
      // Ensure data directory exists
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      // Check if database file exists
      const dbExists = fs.existsSync(this.dbPath);
      
      if (dbExists) {
        // Load existing database
        const dbFile = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbFile);
      } else {
        // Create new database
        this.db = new SQL.Database();
        
        // Load and execute schema
        if (fs.existsSync(this.schemaPath)) {
          const schema = fs.readFileSync(this.schemaPath, 'utf8');
          this.db.exec(schema);
        }
        
        // Save initial database
        this.saveDatabase();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async insertSubmission(submission: Omit<FormSubmission, 'submitted_at'>): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt: Statement = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province_region, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province_region,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      ]);

      stmt.free();
      this.saveDatabase();
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data: Uint8Array = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  isInitialized(): boolean {
    return this.db !== null;
  }
}

export const dbManager = new DatabaseManager();