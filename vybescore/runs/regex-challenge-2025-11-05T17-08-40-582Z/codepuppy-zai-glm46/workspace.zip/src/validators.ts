export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses with proper RFC compliance.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that rejects common invalid patterns
  const emailRegex = /^(?!.*\.\.)(?!.*\.$)[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional check: no underscores in domain
  const domainRegex = /@[a-zA-Z0-9.-]+$/;
  const domain = value.match(domainRegex)?.[0];
  
  if (!emailRegex.test(value)) return false;
  if (domain && domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters to validate structure
  const digits = value.replace(/\D/g, '');
  
  // Handle optional +1 prefix
  let actualDigits = digits;
  if (digits.startsWith('1') && digits.length === 11) {
    actualDigits = digits.substring(1);
  } else if (digits.startsWith('54') && digits.length === 12) {
    // This is not a US number
    return false;
  }
  
  // Must be exactly 10 digits for US number
  if (actualDigits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = actualDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format with common separators
  const phoneRegex = /^\+?1?[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value.replace(/\s+/g, ' ').trim());
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, keep track of structure
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  // Optional +54, optional 0, optional 9, area code 2-4 digits, subscriber 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
  
  // Alternative regex for numbers starting with 0 (without country code)
  const withTrunkRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  let match;
  
  if (cleanValue.startsWith('+54')) {
    // With country code
    match = cleanValue.match(argentinePhoneRegex);
    if (!match) return false;
    
    const areaCode = match[3]; // Area code after optional +54 and 9
    const subscriber = match[4];
    
    // Area code must be 2-4 digits, leading digit 1-9
    if (/^[1-9]\d{1,3}$/.test(areaCode) && /^\d{6,8}$/.test(subscriber)) {
      return true;
    }
  } else if (cleanValue.startsWith('0')) {
    // With trunk prefix but no country code
    match = cleanValue.match(withTrunkRegex);
    if (!match) return false;
    
    const areaCode = match[1];
    const subscriber = match[2];
    
    // Area code must be 2-4 digits, leading digit 1-9
    if (/^[1-9]\d{1,3}$/.test(areaCode) && /^\d{6,8}$/.test(subscriber)) {
      return true;
    }
  } else if (!cleanValue.startsWith('0') && !cleanValue.startsWith('+54')) {
    // Try without country code and without trunk prefix (this should be rejected)
    return false;
  }
  
  // Test with original format (allowing spaces and hyphens)
  const formatRegex = /^(\+54[\s-]?)?(9[\s-]?)?\d{2,4}[\s-]?\d{6,8}$/;
  const formatWithTrunk = /^0\d{2,4}[\s-]?\d{6,8}$/;
  
  return formatRegex.test(value.replace(/\s+/g, ' ').trim()) || 
         formatWithTrunk.test(value.replace(/\s+/g, ' ').trim());
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M} '\-]+$/u;
  
  // Must contain at least one letter
  const hasLetter = /\p{L}/u.test(value);
  
  // Reject if contains digits or other symbols
  const hasInvalidChars = /[^\p{L}\p{M} '\-]/u.test(value);
  
  return nameRegex.test(value) && hasLetter && !hasInvalidChars;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check card patterns and lengths
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  const isValidLength = visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue);
  
  if (!isValidLength) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}