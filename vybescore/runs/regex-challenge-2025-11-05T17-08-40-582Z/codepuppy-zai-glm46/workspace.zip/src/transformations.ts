/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalizes the first character of each sentence (after .?!), insert exactly one space between sentences 
 * even if the input omitted it, and collapse extra spaces sensibly while leaving abbreviations intact.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Ensure proper spacing after sentence enders
  normalized = normalized.replace(/([.!?])(?!\s|$)/g, '$1 ');
  
  // Split into sentences, capitalize each one
  const sentences = normalized.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i] && sentences[i].trim()) {
      // Capitalize first letter of the sentence
      sentences[i] = sentences[i].charAt(0).toUpperCase() + sentences[i].slice(1).toLowerCase();
    }
  }
  
  return sentences.join('');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Returns all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex that matches common URL patterns
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:)]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace only http:// with https:// (not https://)
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Still upgrade the scheme to https:// in those cases
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // URL regex for example.com domain
  const urlRegex = /(https?):\/\/(example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = /\/cgi-bin\/[?&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py)($|[?&])/;
      
      if (dynamicHints.test(path)) {
        // Just upgrade protocol, keep original host
        return `${newProtocol}://${domain}${path}`;
      } else {
        // Rewrite to docs.example.com
        return `${newProtocol}://docs.example.com${path}`;
      }
    } else {
      // Just upgrade protocol, keep original host
      return `${newProtocol}://${domain}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 * Returns the four-digit year for mm/dd/yyyy. If the string doesn't match that format 
 * or month/day are invalid, return 'N/A'.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Extract mm/dd/yyyy pattern
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Basic leap year check for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}