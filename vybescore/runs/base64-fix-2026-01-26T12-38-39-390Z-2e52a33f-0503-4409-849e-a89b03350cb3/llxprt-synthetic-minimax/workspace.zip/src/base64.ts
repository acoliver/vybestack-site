/**
 * Encode plain text to Base64 using standard Base64 encoding with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding, and URL-safe Base64.
 */
export function decode(input: string): string {
  // Normalize URL-safe Base64 to standard Base64
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  // Add padding if missing (Base64 strings should be multiple of 4)
  const padding = normalized.length % 4;
  const withPadding = padding === 0 ? normalized : normalized + '='.repeat(4 - padding);

  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(withPadding)) {
    throw new Error('Invalid Base64 input: contains non-base64 characters');
  }

  try {
    return Buffer.from(withPadding, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
