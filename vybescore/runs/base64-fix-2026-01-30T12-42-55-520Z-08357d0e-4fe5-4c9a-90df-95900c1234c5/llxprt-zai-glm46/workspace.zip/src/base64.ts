/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input is not valid Base64.
 */
export function decode(input: string): string {
  // Validate Base64 format before attempting decode
  const trimmed = input.trim();
  
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, =)
  // Must be a multiple of 4 characters (after padding)
  // Padding (=) can only appear at the end
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Add padding if missing (standard Base64 requires padding to multiple of 4)
  const normalized = trimmed.padEnd(Math.ceil(trimmed.length / 4) * 4, '=');

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // If the buffer is empty and we had input, it means decoding failed
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
