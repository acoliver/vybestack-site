/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 * Returns standard Base64 with padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check for invalid Base64 characters (anything outside A-Z, a-z, 0-9, +, /, =)
  const invalidChars = input.match(/[^A-Za-z0-9+/=]/g);
  if (invalidChars) {
    throw new Error(`Invalid Base64 characters found: ${invalidChars.join(', ')}`);
  }
  
  // Check for incorrect padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingSection = input.substring(paddingIndex);
    // Padding must be at the end and can only be 1 or 2 '=' characters
    // and should only appear as the last characters
    if (!/^={1,2}$/.test(paddingSection)) {
      throw new Error('Invalid Base64 padding');
    }
  }
  
  // Node.js handles base64 padding automatically, but we want to catch the most obvious errors
  try {
    // Create a new Buffer and try to decode
    const buffer = Buffer.from(input, 'base64');
    
    // Check for decoding corruption (e.g., input was not valid base64)
    // When corrupted input is provided, Buffer.from may produce garbled output
    // We're not checking that here since Node.js is forgiving, but we're at least
    // blocking invalid characters and malformed padding
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
