export interface ValidationErrors {
  [key: string]: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Email validation regex - simple but effective
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Phone validation regex - allows digits, spaces, parentheses, dashes, and leading +
const phoneRegex = /^[+]?[\d\s\-()]{7,}$/;

// Postal code validation - alphanumeric, allows letters and digits
const postalCodeRegex = /^[A-Za-z0-9\s-]{3,10}$/;

export function validateFormData(formData: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Validate required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'state',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = formData[field].trim();
    if (!value) {
      errors[field] = `${getFieldLabel(field)} is required`;
    }
  });

  // Email validation (only if email is not empty)
  if (formData.email.trim() && !emailRegex.test(formData.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (only if phone is not empty)
  if (formData.phone.trim() && !phoneRegex.test(formData.phone.trim())) {
    errors.phone = 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and + are allowed)';
  }

  // Postal code validation (only if postal code is not empty)
  if (formData.postalCode.trim() && !postalCodeRegex.test(formData.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code (letters and numbers only, 3-10 characters)';
  }

  return errors;
}

function getFieldLabel(field: keyof FormData): string {
  const labels: Record<keyof FormData, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    state: 'State / Province / Region',
    postalCode: 'Postal / Zip code',
    country: 'Country',
    email: 'Email address',
    phone: 'Phone number'
  };

  return labels[field] || field;
}