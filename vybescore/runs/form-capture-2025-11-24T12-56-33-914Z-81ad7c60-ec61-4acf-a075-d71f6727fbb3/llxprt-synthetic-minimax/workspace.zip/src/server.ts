import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initDB, saveSubmission, closeDB } from './database.js';
import { validateFormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Interface for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// GET / - Render the contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {} as FormData,
    pageTitle: 'Contact Us - Friendly Form Capture'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      state: req.body.state || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const errors = validateFormData(formData);

    if (Object.keys(errors).length > 0) {
      return res.status(400).render('form', {
        errors,
        formData,
        pageTitle: 'Contact Us - Please Fix Errors'
      });
    }

    await saveSubmission(formData);
    
    // Redirect to thank you page after successful submission
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your submission. Please try again.' },
      formData: req.body,
      pageTitle: 'Contact Us - Error'
    });
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    pageTitle: 'Thank You - Form Submitted Successfully'
  });
});

// Initialize database and start server
async function startServer() {
  try {
    await initDB();
    
    const server = app.listen(PORT, () => {
      console.log(` Server running on http://localhost:${PORT}`);
      console.log(' Contact form available at /');
      console.log(' Database initialized successfully');
    });

    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('\n Received SIGTERM, shutting down gracefully...');
      server.close(async () => {
        console.log(' HTTP server closed');
        await closeDB();
        console.log(' Database connection closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('[ERROR] Failed to start server:', error);
    process.exit(1);
  }
}

startServer();