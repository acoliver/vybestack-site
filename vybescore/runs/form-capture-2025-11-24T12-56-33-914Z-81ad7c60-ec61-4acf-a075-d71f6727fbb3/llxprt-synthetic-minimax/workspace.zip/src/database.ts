import initSqlJs, { Database } from 'sql.js';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let db: Database | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Initialize database
export async function initDB(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    let dbData: Uint8Array | null = null;
    
    // Load existing database file if it exists
    if (fs.existsSync(dbPath)) {
      const buffer = fs.readFileSync(dbPath);
      dbData = new Uint8Array(buffer);
    }

    // Create or load database
    db = new SQL.Database(dbData);

    // Create table if it doesn't exist
    db.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    console.log(' Database initialized successfully');
  } catch (error) {
    console.error('[ERROR] Failed to initialize database:', error);
    throw error;
  }
}

// Save submission to database
export async function saveSubmission(formData: FormData): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.state,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();

    // Write database to file
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const binaryArray = db.export();
    fs.writeFileSync(dbPath, binaryArray);

    console.log(' Submission saved successfully');
  } catch (error) {
    console.error('[ERROR] Failed to save submission:', error);
    throw error;
  }
}

// Close database connection
export async function closeDB(): Promise<void> {
  if (db) {
    db.close();
    db = null;
    console.log(' Database connection closed');
  }
}