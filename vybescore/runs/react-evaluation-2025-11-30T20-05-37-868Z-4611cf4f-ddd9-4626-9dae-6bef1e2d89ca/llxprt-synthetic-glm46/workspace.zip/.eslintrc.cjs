module.exports = {
  root: true,
  env: {
    node: true,
    es2022: true,
  },
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: 'module',
    project: ['./tsconfig.json', './vitest.config.public.ts'],
    tsconfigRootDir: __dirname,
  },
  plugins: ['@typescript-eslint'],
rules: {
    '@typescript-eslint/no-unused-vars': 'error',
  },
  ignorePatterns: [
    'dist/',
    'node_modules/',
    'vitest.config.public.ts',
  ],
  overrides: [
    {
      files: ['src/types/reactive.ts', 'src/core/input.ts'],
      rules: {
        '@typescript-eslint/no-explicit-any': 'off'
      }
    }
  ]
};