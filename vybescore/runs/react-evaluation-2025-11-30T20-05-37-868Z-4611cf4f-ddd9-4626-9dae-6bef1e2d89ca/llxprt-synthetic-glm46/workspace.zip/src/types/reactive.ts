/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

// Base dispose function signature
const DISPOSED_UPDATE_FN = (() => undefined) as any

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observer?: ObserverR | Subject<T> | undefined
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR<T> = {
  name?: string
  observer?: ObserverR | Subject<T> | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR<T> & SubjectV<T>

let activeObserver: ObserverR | undefined
const observers = new Set<Observer<any>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  // Skip if this observer is disposed
  if (observer.updateFn === DISPOSED_UPDATE_FN) {
    return
  }
  
  // Register observer to track it for updates
  observers.add(observer)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(): void {
  // Create a copy of observers to avoid issues during iteration
  const currentObservers = Array.from(observers)
  
  currentObservers.forEach(observer => {
    if (observer.updateFn !== DISPOSED_UPDATE_FN) {
      updateObserver(observer)
    }
  })
}

export function disposeObserver<T>(observer: Observer<T>): void {
  observers.delete(observer)
  observer.observer = undefined
  observer.updateFn = DISPOSED_UPDATE_FN
}
