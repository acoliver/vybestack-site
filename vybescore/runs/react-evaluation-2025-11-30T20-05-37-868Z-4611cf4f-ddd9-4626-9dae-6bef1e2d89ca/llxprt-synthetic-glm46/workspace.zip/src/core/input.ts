/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize equal function
  let equalFn: EqualFn<T> | undefined
  if (equal === false) {
    equalFn = undefined // No equality checking, always update
  } else if (equal === true || equal === undefined) {
    equalFn = (a: T, b: T): boolean => a === b // Default strict equality
  } else if (typeof equal === 'function') {
    equalFn = equal // Use provided function
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Set up relationship: input to observer
      s.observer = currentObserver
      // The observer now tracks this input as a dependency
      const typedObserver = currentObserver as Observer<T>
      typedObserver.observer = s
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Skip update if values are equal and equality checking is enabled
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Update the observer if one is registered, otherwise notify all observers
    if (s.observer) {
      updateObserver(s.observer as any)
    }
    
    // Notify all other registered observers about the change
    notifyObservers()
    
    return s.value
  }

  return [read, write]
}
