/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Note: equal parameter is handled for consistency with the API
  // but computed values always recompute when dependencies change
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track dependencies by registering this computed as an observer
  // The first execution establishes all dependencies
  updateObserver(o)
  
  return (): T => {
    // Always return the current value
    // The value is already computed when updateObserver was called
    // Dependencies are tracked by the reactive system
    return o.value!
  }
}
