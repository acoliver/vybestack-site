// Define form data interface
export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define validation error interface
export interface ValidationError {
  field: string;
  message: string;
}
