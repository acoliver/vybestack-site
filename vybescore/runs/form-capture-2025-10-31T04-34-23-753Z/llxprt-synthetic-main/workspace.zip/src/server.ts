import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  initializeDatabase,
  insertSubmission,
  saveDatabase,
  closeDatabase,
} from './dataService.js';
import { validateFormData } from './validationService.js';
import { FormData } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Graceful shutdown
const gracefulShutdown = (): void => {
  console.log('Shutting down gracefully...');
  server.close(() => {
    closeDatabase();
    process.exit(0);
  });

  // Force close after 10 seconds
  setTimeout(() => {
    console.error('Could not close connections in time, forcefully shutting down');
    closeDatabase();
    process.exit(1);
  }, 10000);
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  // Validate form data
  const errors = validateFormData(formData);

  if (errors.length > 0) {
    // Return form with errors
    const errorMessages = errors.map((error) => error.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  try {
    // Insert form data into database
    insertSubmission(formData);

    // Save database immediately after insertion
    saveDatabase();

    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error: unknown) {
    console.error('Database error:', error);
    const errorMessage = 'An error occurred while submitting the form. Please try again.';
    res.status(500).render('form', {
      errors: [errorMessage],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, async () => {
  try {
    await initializeDatabase();
    console.log(`Server running on port ${PORT}`);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
});

// Handle signals for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

export { app };
