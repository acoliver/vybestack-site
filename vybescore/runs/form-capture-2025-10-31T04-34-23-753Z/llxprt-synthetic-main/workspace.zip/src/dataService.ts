import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import { FormData } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbFilePath = path.join(__dirname, '../data/submissions.sqlite');
let isDbClosed = false; // Add flag to track database state
let db: Database | null = null;
let isDatabaseDirty = false;

/**
 * Initialize the SQLite database with schema
 */
export const initializeDatabase = async (): Promise<void> => {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbFilePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();

    // Check if database file exists
    if (fs.existsSync(dbFilePath)) {
      const fileBuffer = fs.readFileSync(dbFilePath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } else {
      // Create new database
      db = new SQL.Database();
      console.log('Created new database');
    }

    // Read and execute schema only if creating a new database
    if (!fs.existsSync(dbFilePath)) {
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
      try {
        db.run(schema);
        console.log('Schema loaded successfully');
      } catch (error) {
        console.error('Error loading schema:', error);
        throw error;
      }
    } else {
      console.log('Database already exists and contains data');
    }
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

/**
 * Save database to disk
 */
export const saveDatabase = (): void => {
  if (isDatabaseDirty && db) {
    try {
      const data = db.export();
      fs.writeFileSync(dbFilePath, Buffer.from(data));
      isDatabaseDirty = false;
      console.log('Database saved to disk');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
};

/**
 * Write form data to database
 */
export const insertSubmission = (formData: FormData): void => {
  try {
    // Check database connection
    if (!db || isDbClosed) {
      throw new Error('Database is not initialized or is closed');
    }

    // Insert form data into database
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]);
    } finally {
      stmt.free(); // Ensure statement is freed even if run fails
    }

    isDatabaseDirty = true;
  } catch (error) {
    console.error('Failed to insert submission:', error);
    throw error;
  }
};

/**
 * Close database connection
 */
export const closeDatabase = (): void => {
  if (db && !isDbClosed) {
    saveDatabase();
    try {
      db.close();
      isDbClosed = true;
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
};
