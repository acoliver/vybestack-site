import { FormData, ValidationError } from './types.js';

/**
 * Validate email format
 */
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate phone number (international formats)
 */
export const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
};

/**
 * Validate postal code (alphanumeric)
 */
export const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric characters, spaces, and dashes
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
};

/**
 * Validate form data and return any errors
 */
export const validateFormData = (data: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];

  // Check required fields
  Object.entries(data).forEach(([key, value]) => {
    if (!value || (typeof value === 'string' && value.trim() === '')) {
      // Convert camelCase to readable field names
      const fieldName = key.replace(/([A-Z])/g, ' $1').toLowerCase();
      errors.push({
        field: key,
        message: `${fieldName} is required`,
      });
    }
  });

  // Validate email format
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address',
    });
  }

  // Validate phone number
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number',
    });
  }

  // Validate postal code
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code',
    });
  }

  return errors;
};
