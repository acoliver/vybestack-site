/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  GetterFn,
  SetterFn,
  EqualFn,
  Options,
  createSignal
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' 
    ? equal 
    : typeof equal === 'boolean' && equal === false
      ? undefined
      : (lhs: T, rhs: T) => lhs === rhs

  const signal = createSignal(value)

  const read: GetterFn<T> = () => {
    return signal.get()
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && !equalFn(signal.value, nextValue)) {
      signal.set(nextValue)
    }
    return nextValue
  }

  return [read, write]
}
