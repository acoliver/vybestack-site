/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  createSignal,
  getCurrentObserver,
  setCurrentObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  _options?: { name?: string }
): GetterFn<T> {
  const signal = createSignal(value as T)

  const read: GetterFn<T> = () => {
    // Set as current observer for dependency tracking
    const currentObserver = getCurrentObserver()
    setCurrentObserver(currentObserver)
    
    // Track dependencies by reading signal value
    signal.get()
    
    // Execute update function to get new value
    const computedValue = updateFn(signal.value)
    
    // Set the computed value if it changed
    signal.set(computedValue)
    
    // Clear current observer
    setCurrentObserver(undefined)
    
    return computedValue
  }

  return read
}
