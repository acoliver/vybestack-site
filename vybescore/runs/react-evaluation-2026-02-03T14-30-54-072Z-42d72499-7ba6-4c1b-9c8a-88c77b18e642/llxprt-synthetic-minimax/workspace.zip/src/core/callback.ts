/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  createSignal,
  createEffect
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const disposed = createSignal(false)

  // Create effect that re-executes when dependencies change
  const effectObserver = createEffect(() => {
    if (!disposed.value) {
      updateFn(value)
    }
  })

  const unsubscribe = () => {
    disposed.set(true)
    // Mark disposed to prevent future executions
    if (effectObserver) {
      effectObserver.disposed = true
    }
  }

  return unsubscribe
}
