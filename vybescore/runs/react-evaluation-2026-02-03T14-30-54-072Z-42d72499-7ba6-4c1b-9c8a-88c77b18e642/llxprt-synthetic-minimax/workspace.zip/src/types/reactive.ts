/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Observer patterns for reactive programming
export interface Observer {
  fn: () => void
  disposed: boolean
  dependencies: Set<Signal<unknown>>
}

export interface ObserverR {
  fn: () => void
  disposed: boolean
  dependencies: Set<Signal<unknown>>
}

export interface ObserverV {
  fn: () => void
  disposed: boolean
  dependencies: Set<Signal<unknown>>
}

// Subject patterns for reactive programming
export interface Subject<T> {
  value: T
  observers: Set<ReactiveObserver>
  get: () => T
  set: (value: T) => T
}

export interface SubjectR {
  value: unknown
  observers: Set<ReactiveObserver>
  get: () => unknown
  set: (value: unknown) => unknown
}

export interface SubjectV {
  value: unknown
  observers: Set<ReactiveObserver>
  get: () => unknown
  set: (value: unknown) => unknown
}

// Signal system for reactive programming
export interface Signal<T> {
  value: T
  observers: Set<ReactiveObserver>
  get: () => T
  set: (value: T) => T
}

interface ReactiveObserver {
  fn: () => void
  disposed: boolean
  dependencies: Set<Signal<unknown>>
}

const globalState = {
  currentObserver: undefined as ReactiveObserver | undefined
}

export function getCurrentObserver(): ReactiveObserver | undefined {
  return globalState.currentObserver
}

export function setCurrentObserver(observer: ReactiveObserver | undefined): void {
  globalState.currentObserver = observer
}

export function createSignal<T>(initialValue: T): Signal<T> {
  let currentValue = initialValue
  const observers = new Set<ReactiveObserver>()

  const signal: Signal<T> = {
    value: currentValue,
    observers,
    get: function() {
      const observer = getCurrentObserver()
      if (observer) {
        // Register this signal as a dependency of the observer
        observers.add(observer)
        observer.dependencies.add(this as Signal<unknown>)
      }
      return currentValue
    },
    set: function(newValue: T) {
      if (currentValue === newValue) return currentValue
      currentValue = newValue
      
      // Trigger all observers that depend on this signal
      const observersCopy = Array.from(observers)
      observersCopy.forEach(observer => {
        if (!observer.disposed) {
          // Clear dependencies to force re-tracking on next access
          observer.dependencies.clear()
          
          // Execute observer with proper context
          setCurrentObserver(observer)
          try {
            observer.fn()
          } finally {
            setCurrentObserver(undefined)
          }
        }
      })
      return currentValue
    }
  }
  return signal
}

export function createEffect(fn: () => void): ReactiveObserver {
  const observer: ReactiveObserver = {
    fn,
    disposed: false,
    dependencies: new Set()
  }
  
  // Execute effect immediately to establish initial dependencies
  setCurrentObserver(observer)
  try {
    fn()
  } finally {
    setCurrentObserver(undefined)
  }
  
  return observer
}
