/**
 * Capitalize the first character of each sentence after .?!, 
 * insert exactly one space between sentences, and collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences using punctuation as delimiters
  const sentences = text.split(/([.!?])/);
  
  // Rebuild with proper capitalization
  let result = '';
  let newSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (segment === '.' || segment === '!' || segment === '?') {
      // Punctuation marks - append and ensure next part starts new sentence
      result += segment;
      newSentence = true;
    } else {
      // Text segment - capitalize first character if it's a new sentence
      let processedSegment = segment;
      
      if (newSentence && segment.trim()) {
        processedSegment = segment.replace(/^(\s*)([a-zA-Z])/, (match, spaces, letter) => {
          return spaces + letter.toUpperCase();
        });
      }
      
      result += processedSegment;
      newSentence = false;
    }
  }
  
  // Clean up spacing
  return result.replace(/\s+/g, ' ').replace(/\s+([.!?])/g, '$1').trim();
}

/**
 * Find URLs in the text and return them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match URLs starting with http:// or https://
  // Include domain, path, query, and fragment
  // Exclude trailing punctuation like .,!?:;
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[a-zA-Z0-9/](?=[^a-zA-Z0-9/]|$)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean trailing punctuation
  return matches.map(url => url.replace(/[.,!?;):)]+$/, ''));
}

/**
 * Replace http:// with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:/g, 'https:');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * Skip URLs with dynamic paths (cgi-bin, query strings, etc.)
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  const httpsText = text.replace(/http:/g, 'https:');
  
  // Pattern to match URLs that should have their host rewritten to docs.example.com
  // Criteria: https://example.com/docs/... without dynamic elements
  const docsUrlRegex = /(https:\/\/example\.com\/docs\/([^\s?.]*(?:\?[^\s]*)?))/g;
  
  // Check for dynamic elements that would disqualify the URL from host rewriting
  const hasDynamicElements = (url: string): boolean => {
    return /cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(url);
  };
  
  return httpsText.replace(docsUrlRegex, (match, fullUrl) => {
    // Check if URL contains dynamic elements that would disqualify it from host rewriting
    if (hasDynamicElements(fullUrl)) {
      return fullUrl; // Keep original host if dynamic elements found
    }
    
    // Extract just the path portion after /docs/
    const docsPath = fullUrl.replace('https://example.com/docs/', '');
    
    // Rebuild as docs.example.com while preserving the rest of the path
    return `https://docs.example.com/docs/${docsPath}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy format. Returns N/A for invalid formats.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, month, day, year] = dateMatch;
  
  // Validate month and day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Check for valid days in each month (simple validation)
  const maxDays = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified leap year handling
  
  if (dayNum > maxDays[monthNum]) {
    return 'N/A';
  }
  
  // February 29 validation for leap years
  if (monthNum === 2 && dayNum === 29) {
    // Simple leap year check
    if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
