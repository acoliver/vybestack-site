/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words with the prefix
  // \b word boundary, \w+ letters/digits, but we'll refine to allow word characters
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[\\w'-]*)`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Check if this word is in the exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of the token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to ensure token follows a digit
  // and is not at the start of the string
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate password strength: at least 10 chars, upper/lower/digit/symbol, no whitespace, no repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab, abcabc)
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    
    if (seq1 === seq2) {
      return false; // Found repeated 2-char sequence
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) while ensuring IPv4 addresses do not match.
 */
export function containsIPv6(value: string): boolean {
  // First, filter out obvious IPv4 addresses to avoid false positives
  // IPv4 pattern: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false; // This looks like an IPv4 address
  }
  
  // IPv6 patterns (including various shorthand forms)
  
  // Full 8 groups of 1-4 hex digits
  const ipv6Full = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?![\d.:])/;
  
  // Compressed form with :: (replaces one or more groups of zeros)
  const ipv6Compressed = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4})?(?![\d.:])/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4 = /\b(?:[0-9a-fA-F]{1,4}:)*:(?:\d{1,3}\.){3}\d{1,3}(?![\d.:])/;
  
  // Check for any IPv6 pattern but ensure it's not IPv4
  return ipv6Full.test(value) || ipv6Compressed.test(value) || ipv6WithIPv4.test(value);
}
