/**
 * Encode plain text to Base64 using canonical RFC 4648 alphabet.
 * Includes required padding with '=' characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input format and throws error for invalid Base64.
 */
export function decode(input: string): string {
  // Validate input is non-empty
  if (!input || input.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Accept both padded and unpadded Base64
  let normalizedInput = input;
  
  // If no padding, add appropriate padding to make length a multiple of 4
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  if (paddingNeeded > 0 && !input.includes('=')) {
    normalizedInput = input + '='.repeat(paddingNeeded);
  }

  // Validate characters are from the Base64 alphabet
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Regex.test(normalizedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Validate padding
  const paddingCount = (normalizedInput.match(/=/g) || []).length;
  
  // Padding must be 0, 1, or 2 characters
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Total length must be a multiple of 4
  if (normalizedInput.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
