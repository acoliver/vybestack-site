import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, type FormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Set up view engine and static files
app.set('view engine', 'ejs');

// Try to find views in both src (dev) and dist (prod) directories
const devViewsPath = path.join(__dirname, 'views');
const prodViewsPath = path.join(__dirname, '..', 'views');
app.set('views', [devViewsPath, prodViewsPath]);

app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Initialize database on startup
async function startServer() {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

// Routes

// GET / - Serve the contact form
app.get('/', (req, res) => {
  res.render('index', {
    formData: {},
    errors: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req, res) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  // Validate form data
  const validation = validateForm(formData);

  if (!validation.isValid) {
    // Re-render form with errors and previous values
    return res.status(400).render('index', {
      formData,
      errors: validation.errors
    });
  }

  try {
    // Insert submission into database
    insertSubmission(formData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('index', {
      formData,
      errors: { general: 'An error occurred while saving your submission. Please try again.' }
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});