/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to match words starting with the prefix
  // \b ensures we match word boundaries
  const regex = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find the token when it appears after a digit and not at the start
  // We need to capture the full word/sequence containing the token
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Return full matches (digit + token)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // This regex looks for any 2+ character sequence that repeats immediately
  if (/(.+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with shorthand (::) for consecutive zero groups
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 starting with :: (handles edge cases)
  const startShorthand = /\b::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 ending with ::
  const endShorthand = /\b(?:[0-9a-fA-F]{1,4}:)+::\b/;
  
  // IPv6 with only ::
  const onlyShorthand = /\b::\b/;
  
  // IPv6 patterns with different separators
  const mixedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  return fullIPv6.test(value) || shorthandIPv6.test(value) || startShorthand.test(value) || 
         endShorthand.test(value) || onlyShorthand.test(value) || mixedIPv6.test(value);
}