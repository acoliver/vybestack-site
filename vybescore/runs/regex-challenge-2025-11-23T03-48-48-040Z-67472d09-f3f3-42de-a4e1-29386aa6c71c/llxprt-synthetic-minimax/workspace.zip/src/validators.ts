export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Basic email format regex
  // Pattern breaks down:
  // - Local part: [a-zA-Z0-9._%+-]+ (allows letters, numbers, dots, underscores, percent, plus, hyphen)
  // - @ symbol
  // - Domain: [a-zA-Z0-9.-]+\.[a-zA-Z]{2,} (domain with TLD of 2+ chars)
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  // Check for double dots in local part
  if (trimmed.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in domain
  const domainPart = trimmed.split('@')[1];
  if (domainPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (US standard)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Optional +1 prefix check
  let numberToCheck = digitsOnly;
  if (digitsOnly.startsWith('1')) {
    if (digitsOnly.length === 11) {
      numberToCheck = digitsOnly.substring(1); // Remove leading 1
    } else if (digitsOnly.length > 11) {
      return false; // Invalid if more than 11 digits with leading 1
    }
  }
  
  // Must have exactly 10 digits now
  if (numberToCheck.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = parseInt(numberToCheck.substring(0, 3));
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  // Verify the original format matches expected patterns
  const phoneRegex = /^(\+1[\s.-]?)?(\([0-9]{3}\)|[0-9]{3})[\s.-]?[0-9]{3}[\s.-]?[0-9]{4}$/;
  return phoneRegex.test(value.trim());
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Extract digits only for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 8 digits (2-4 area code + 6-8 subscriber)
  // and at most 13 digits (country code + mobile indicator + area code + subscriber)
  if (digitsOnly.length < 8 || digitsOnly.length > 13) {
    return false;
  }
  
  // Parse the number structure, starting with the original string
  let remaining = value.trim();
  
  // Check for country code +54
  let hasCountryCode = false;
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3).trim();
  }
  
  // Check for mobile indicator 9 (after country code or at start if no country code)
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1).trim();
  }
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !remaining.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  if (remaining.startsWith('0')) {
    remaining = remaining.substring(1).trim();
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const areaCodeLength = areaCode.length;
  if (areaCodeLength < 2 || areaCodeLength > 4) {
    return false;
  }
  
  // Extract subscriber number
  const afterAreaCode = remaining.substring(areaCode.length).replace(/[\s-]/g, '');
  const subscriberLength = afterAreaCode.length;
  
  // Subscriber number must be 6-8 digits
  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }
  
  // Verify it's all digits
  if (!/^\d+$/.test(afterAreaCode)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  if (trimmed.length === 0) {
    return false;
  }
  
  // Pattern breakdown:
  // - ^[\p{L}\p{M}\s'’-]+$ - Start with one or more letters (unicode), marks, spaces, apostrophes, hyphens
  // - \p{L} matches any unicode letter
  // - \p{M} matches unicode marks (accents, etc.)
  // - ' and ’ (regular and smart apostrophes)
  // - - (hyphen)
  // - \s (whitespace)
  const nameRegex = /^[\p{L}\p{M}\s'\u2018\u2019-]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Check for obviously invalid patterns
  // Reject names that contain digits
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Reject names that contain symbols other than apostrophes and hyphens
  if (/[^\p{L}\p{M}\s'\u2018\u2019-]/u.test(trimmed)) {
    return false;
  }
  
  // Reject very short or very long names
  if (trimmed.length < 2 || trimmed.length > 100) {
    return false;
  }
  
  // Reject names that are just spaces, apostrophes, or hyphens
  if (/^[\s'\u2018\u2019-]+$/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check card types and lengths
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digitsOnly.startsWith('4') && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19)) {
    isValidType = true;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if ((digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || digitsOnly.startsWith('53') || 
       digitsOnly.startsWith('54') || digitsOnly.startsWith('55') ||
       (digitsOnly.startsWith('222') || digitsOnly.startsWith('223') || digitsOnly.startsWith('224') || 
        digitsOnly.startsWith('225') || digitsOnly.startsWith('226') || digitsOnly.startsWith('227') || 
        digitsOnly.startsWith('228') || digitsOnly.startsWith('229') || digitsOnly.startsWith('230') || 
        digitsOnly.startsWith('231') || digitsOnly.startsWith('232') || digitsOnly.startsWith('233') || 
        digitsOnly.startsWith('234') || digitsOnly.startsWith('235') || digitsOnly.startsWith('236') || 
        digitsOnly.startsWith('237') || digitsOnly.startsWith('238') || digitsOnly.startsWith('239') || 
        digitsOnly.startsWith('240') || digitsOnly.startsWith('241') || digitsOnly.startsWith('242') || 
        digitsOnly.startsWith('243') || digitsOnly.startsWith('244') || digitsOnly.startsWith('245') || 
        digitsOnly.startsWith('246') || digitsOnly.startsWith('247') || digitsOnly.startsWith('248') || 
        digitsOnly.startsWith('249') || digitsOnly.startsWith('250') || digitsOnly.startsWith('251') || 
        digitsOnly.startsWith('252') || digitsOnly.startsWith('253') || digitsOnly.startsWith('254') || 
        digitsOnly.startsWith('255') || digitsOnly.startsWith('256') || digitsOnly.startsWith('257') || 
        digitsOnly.startsWith('258') || digitsOnly.startsWith('259') || digitsOnly.startsWith('260') || 
        digitsOnly.startsWith('261') || digitsOnly.startsWith('262') || digitsOnly.startsWith('263') || 
        digitsOnly.startsWith('264') || digitsOnly.startsWith('265') || digitsOnly.startsWith('266') || 
        digitsOnly.startsWith('267') || digitsOnly.startsWith('268') || digitsOnly.startsWith('269') || 
        digitsOnly.startsWith('270') || digitsOnly.startsWith('271') || digitsOnly.startsWith('272'))) && 
      digitsOnly.length === 16) {
    isValidType = true;
  }
  
  // American Express: starts with 34 or 37, length 15
  if ((digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) && digitsOnly.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Luhn checksum algorithm
  return runLuhnCheck(digitsOnly);
}

// Luhn checksum helper function
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
