/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, clean up multiple spaces
  const result = text.replace(/\s+/g, ' ');
  
  // Split by sentence endings, but preserve the delimiters
  const sentences = result.split(/([.!?]+\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i].trim().length > 0) {
      // Capitalize first letter of sentence
      sentences[i] = sentences[i].replace(/^\s*([a-záéíóúñü])/, (match, p1) => {
        return match.replace(p1, p1.toUpperCase());
      });
    }
  }
  
  return sentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"'()]+[^\s<>"'(),.!?]/gi;
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/[^?\s]*)?/gi, (match, domain, path) => {
    // If no path or path doesn't start with /docs/, just upgrade scheme
    if (!path || !path.startsWith('/docs/')) {
      return `https://${domain}${path || ''}`;
    }
    
    // Check for dynamic hints that should skip host rewrite
    const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasDynamicHint = dynamicHints.some(hint => 
      path.includes(hint) || match.includes('?') || match.includes('&') || match.includes('=')
    );
    
    if (hasDynamicHint) {
      return `https://${domain}${path}`;
    }
    
    // Rewrite host to docs.domain.com
    const newDomain = `docs.${domain}`;
    return `https://${newDomain}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, but also check month-specific limits)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check for invalid date combinations (like February 30)
  const daysInMonth = new Date(year, month, 0).getDate();
  if (day > daysInMonth) {
    return 'N/A';
  }
  
  return match[3]; // Return the year part
}
