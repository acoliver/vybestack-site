const express = require('express');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

// Replace these with your actual credentials
const SHOPIFY_API_KEY = process.env.SHOPIFY_API_KEY || 'your_api_key';
const SHOPIFY_API_SECRET = process.env.SHOPIFY_API_SECRET || 'your_api_secret';
const SHOP_DOMAIN = process.env.SHOP_DOMAIN || 'your-shop.myshopify.com';
const SCOPES = 'read_orders,read_products';

app.use(express.static(path.join(__dirname, 'public')));

app.get('/auth', (req, res) => {
  const redirectUri = `${req.protocol}://${req.get('host')}/callback`;
  const installUrl = `https://${SHOP_DOMAIN}/admin/oauth/authorize?client_id=${SHOPIFY_API_KEY}&scope=${SCOPES}&redirect_uri=${redirectUri}`;
  res.redirect(installUrl);
});

app.get('/callback', async (req, res) => {
  const { code, hmac, shop } = req.query;
  
  // Validate the request
  if (!shop || !code || !hmac) {
    return res.status(400).send('Required parameters missing');
  }

  // Exchange temporary code for permanent access token
  try {
    const tokenResponse = await fetch(`https://${shop}/admin/oauth/access_token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        client_id: SHOPIFY_API_KEY,
        client_secret: SHOPIFY_API_SECRET,
        code,
      }),
    });

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;
    
    // Store token securely (session, database, etc.)
    req.session = { accessToken, shop };
    
    res.redirect('/dashboard.html');
  } catch (error) {
    console.error('Error exchanging code for token:', error);
    res.status(500).send('Authentication failed');
  }
});

// Middleware to check if authenticated
function requireAuth(req, res, next) {
  if (!req.session || !req.session.accessToken) {
    return res.redirect('/');
  }
  next();
}

app.get('/api/orders', requireAuth, async (req, res) => {
  try {
    const ordersResponse = await fetch(`https://${req.session.shop}/admin/api/2023-10/orders.json`, {
      headers: {
        'X-Shopify-Access-Token': req.session.accessToken,
        'Content-Type': 'application/json',
      },
    });
    
    const ordersData = await ordersResponse.json();
    res.json(ordersData);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});