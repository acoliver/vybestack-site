import React, { useState, useCallback, useMemo } from 'react';

// 优化的子组件 - 使用 React.memo 避免不必要的重渲染
const UserProfile = React.memo(({ user, onUpdate }) => {
  console.log('UserProfile rendered');
  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px', borderRadius: '5px' }}>
      <h3>{user.name}</h3>
      <p>Email: {user.email}</p>
      <p>Age: {user.age}</p>
      <button onClick={() => onUpdate(user.id)}>Update</button>
    </div>
  );
});

// 优化的子组件 - 使用 React.memo 和 useCallback 防止不必要的重渲染
const TodoItem = React.memo(({ todo, onToggle, onDelete }) => {
  console.log(`TodoItem ${todo.id} rendered`);
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '5px' }}>
      <span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
        {todo.text}
      </span>
      <div>
        <button onClick={() => onToggle(todo.id)}>
          {todo.completed ? '未完成' : '完成'}
        </button>
        <button onClick={() => onDelete(todo.id)}>删除</button>
      </div>
    </div>
  );
});

// 优化的父组件
const OptimizedParentComponent = () => {
  // 使用 useState 管理状态
  const [count, setCount] = useState(0);
  const [users, setUsers] = useState([
    { id: 1, name: '张三', email: 'zhangsan@example.com', age: 28 },
    { id: 2, name: '李四', email: 'lisi@example.com', age: 35 },
    { id: 3, name: '王五', email: 'wangwu@example.com', age: 42 }
  ]);
  const [todos, setTodos] = useState([
    { id: 1, text: '学习React优化', completed: false },
    { id: 2, text: '编写组件示例', completed: true },
    { id: 3, text: '性能测试', completed: false }
  ]);
  const [filter, setFilter] = useState('');
  
  // 使用 useCallback 优化事件处理函数，避免每次渲染都创建新函数
  const handleUserUpdate = useCallback((userId) => {
    alert(`更新用户 ID: ${userId}`);
  }, []);
  
  const handleTodoToggle = useCallback((todoId) => {
    setTodos(prevTodos => 
      prevTodos.map(todo => 
        todo.id === todoId ? { ...todo, completed: !todo.completed } : todo
      )
    );
  }, []);
  
  const handleTodoDelete = useCallback((todoId) => {
    setTodos(prevTodos => 
      prevTodos.filter(todo => todo.id !== todoId)
    );
  }, []);
  
  // 使用 useMemo 优化计算密集型操作
  const filteredTodos = useMemo(() => {
    console.log('重新计算过滤后的todos');
    return todos.filter(todo => 
      todo.text.toLowerCase().includes(filter.toLowerCase())
    );
  }, [todos, filter]);
  
  // 计算统计信息
  const stats = useMemo(() => {
    return {
      totalUsers: users.length,
      totalTodos: todos.length,
      completedTodos: todos.filter(todo => todo.completed).length,
      pendingTodos: todos.filter(todo => !todo.completed).length
    };
  }, [users, todos]);
  
  return (
    <div className="optimized-app" style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h1>React 优化示例应用</h1>
      
      {/* 性能测试区域 */}
      <div style={{ marginBottom: '20px', backgroundColor: '#f0f8ff', padding: '10px', borderRadius: '5px' }}>
        <h3>性能测试区域</h3>
        <p>计数器: {count}</p>
        <button onClick={() => setCount(count + 1)}>增加计数</button>
        <p>注意：点击这个按钮不会导致用户列表和任务列表重新渲染</p>
      </div>
      
      {/* 统计信息 */}
      <div style={{ marginBottom: '20px', backgroundColor: '#f9f9f9', padding: '10px', borderRadius: '5px' }}>
        <h3>统计信息</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px' }}>
          <div>
            <strong>用户总数:</strong> {stats.totalUsers}
          </div>
          <div>
            <strong>任务总数:</strong> {stats.totalTodos}
          </div>
          <div>
            <strong>已完成:</strong> {stats.completedTodos}
          </div>
          <div>
            <strong>待处理:</strong> {stats.pendingTodos}
          </div>
        </div>
      </div>
      
      {/* 用户列表 */}
      <div style={{ marginBottom: '20px' }}>
        <h3>用户列表 (使用 React.memo 优化)</h3>
        {users.map(user => (
          <UserProfile key={user.id} user={user} onUpdate={handleUserUpdate} />
        ))}
        
        <button 
          onClick={() => setUsers(prevUsers => [
            ...prevUsers, 
            { 
              id: prevUsers.length + 1, 
              name: `用户${prevUsers.length + 1}`, 
              email: `user${prevUsers.length + 1}@example.com`, 
              age: 20 + Math.floor(Math.random() * 30)
            }
          ])}
        >
          添加用户
        </button>
      </div>
      
      {/* 任务列表 */}
      <div style={{ marginBottom: '20px' }}>
        <h3>任务列表 (使用 React.memo + useCallback 优化)</h3>
        
        <input 
          type="text" 
          placeholder="过滤任务..." 
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
        />
        
        <div style={{ marginBottom: '10px', color: '#666' }}>
          过滤结果: {filteredTodos.length} / {todos.length} 个任务
        </div>
        
        {filteredTodos.map(todo => (
          <TodoItem 
            key={todo.id} 
            todo={todo} 
            onToggle={handleTodoToggle} 
            onDelete={handleTodoDelete} 
          />
        ))}
        
        <button 
          onClick={() => setTodos(prevTodos => [
            ...prevTodos, 
            { 
              id: prevTodos.length + 1, 
              text: `新任务${prevTodos.length + 1}`, 
              completed: false 
            }
          ])}
        >
          添加任务
        </button>
      </div>
      
      {/* 优化说明 */}
      <div style={{ backgroundColor: '#f5f5f5', padding: '10px', borderRadius: '5px', fontSize: '14px' }}>
        <h3>优化说明</h3>
        <ul>
          <li><strong>React.memo</strong>: 防止父组件状态变化时子组件不必要的重渲染</li>
          <li><strong>useCallback</strong>: 保持事件处理函数的引用稳定，防止子组件重渲染</li>
          <li><strong>useMemo</strong>: 缓存计算结果，避免每次渲染时重复计算</li>
          <li>打开浏览器控制台查看渲染日志，观察优化效果</li>
        </ul>
      </div>
    </div>
  );
};

// 性能测试组件
const PerformanceTest = () => {
  const [testData, setTestData] = useState(Array.from({ length: 1000 }, (_, i) => ({
    id: i,
    value: Math.random()
  })));
  
  // 使用 useMemo 优化大量数据的处理
  const processedData = useMemo(() => {
    console.log('重新处理大量数据');
    return testData.map(item => ({
      ...item,
      processed: item.value * 100
    }));
  }, [testData]);
  
  const handleRefresh = useCallback(() => {
    setTestData(Array.from({ length: 1000 }, (_, i) => ({
      id: i,
      value: Math.random()
    })));
  }, []);
  
  return (
    <div style={{ marginTop: '20px', backgroundColor: '#fffbf0', padding: '10px', borderRadius: '5px' }}>
      <h3>性能测试 (useMemo 优化)</h3>
      <button onClick={handleRefresh}>测试数据处理性能</button>
      <div style={{ marginTop: '10px', fontSize: '12px' }}>
        已处理 {processedData.length} 条数据，请查看控制台日志
      </div>
    </div>
  );
};

export default function OptimizedReactApp() {
  return (
    <div>
      <OptimizedParentComponent />
      <PerformanceTest />
    </div>
  );
}