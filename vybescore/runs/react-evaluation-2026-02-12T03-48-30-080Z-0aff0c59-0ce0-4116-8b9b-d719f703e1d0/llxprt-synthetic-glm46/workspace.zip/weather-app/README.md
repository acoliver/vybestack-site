# Weather Dashboard

A simple weather dashboard built with HTML, CSS, and JavaScript that displays weather information for multiple cities.

## Features

- View weather information for multiple preconfigured cities
- Displays temperature, weather description, and weather icons
- Clean, responsive design
- Add or remove cities from the dashboard

## Usage

Open `index.html` in a web browser to start using the weather dashboard.

## Configuration

Cities can be added or modified in the `script.js` file in the `cities` array. You can also change the API endpoint and key in the `main.js` file if needed.

## Dependencies

- Uses an external weather API to fetch weather data
- Requires an API key to function properly