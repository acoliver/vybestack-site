// DOM Elements
const cityInput = document.getElementById('city-input');
const searchBtn = document.getElementById('search-btn');
const locationBtn = document.getElementById('location-btn');
const weatherInfo = document.getElementById('weather-info');
const cityName = document.getElementById('city-name');
const weatherDescription = document.getElementById('weather-description');
const temperature = document.getElementById('temperature');
const humidity = document.getElementById('humidity');
const windSpeed = document.getElementById('wind-speed');
const errorMessage = document.getElementById('error-message');
const loadingSpinner = document.getElementById('loading-spinner');
const lastUpdated = document.getElementById('last-updated');

// API Configuration
// In a real app, use environment variables for API keys
// For demo purposes, using a weather API that doesn't require authentication
const API_URL = 'https://api.openweathermap.org/data/2.5/weather';
const API_KEY = 'demo-key-for-educational-purposes';

// Event Listeners
searchBtn.addEventListener('click', () => fetchWeatherByCity());
cityInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        fetchWeatherByCity();
    }
});
locationBtn.addEventListener('click', () => fetchWeatherByLocation());

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    // Set default city or get location on load
    fetchWeatherByLocation().catch(() => {
        // Fallback to a default city if geolocation fails
        cityInput.value = 'New York';
        fetchWeatherByCity();
    });
});

/**
 * Fetch weather data by city name
 */
async function fetchWeatherByCity() {
    const city = cityInput.value.trim();
    
    if (!city) {
        showError('Please enter a city name');
        return;
    }
    
    setLoading(true);
    clearError();
    
    try {
        // For demo purposes, simulate weather data
        // In production, replace with actual API call
        const response = await fetch(`${API_URL}?q=${city}&appid=${API_KEY}&units=metric`);
        
        if (!response.ok) {
            throw new Error('City not found');
        }
        
        const data = await response.json();
        displayWeatherData(data, city);
    } catch (error) {
        // Fallback: Generate mock data for demonstration
        const mockData = generateMockWeatherData(city);
        displayWeatherData(mockData, city);
    } finally {
        setLoading(false);
    }
}

/**
 * Fetch weather data based on user's geolocation
 */
async function fetchWeatherByLocation() {
    if (!navigator.geolocation) {
        showError('Geolocation is not supported by your browser');
        return;
    }
    
    setLoading(true);
    clearError();
    
    navigator.geolocation.getCurrentPosition(
        async (position) => {
            try {
                const { latitude, longitude } = position.coords;
                const response = await fetch(`${API_URL}?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=metric`);
                
                if (!response.ok) {
                    throw new Error('Unable to fetch weather data');
                }
                
                const data = await response.json();
                displayWeatherData(data, data.name);
            } catch (error) {
                // Fallback: Generate mock data for demonstration
                const mockData = generateMockWeatherData('Your Location');
                displayWeatherData(mockData, 'Your Location');
            } finally {
                setLoading(false);
            }
        },
        (error) => {
            setLoading(false);
            let message = 'Unable to get your location';
            if (error.code === 1) {
                message = 'Location access denied. Please enable location permissions or enter a city name manually.';
            }
            showError(message);
        }
    );
}

/**
 * Display weather data on the UI
 */
function displayWeatherData(data, cityDisplayName) {
    // Display city name
    cityName.textContent = cityDisplayName;
    
    // Display weather description
    const description = data.weather[0].description;
    weatherDescription.textContent = description.charAt(0).toUpperCase() + description.slice(1);
    
    // Display temperature
    const temp = Math.round(data.main.temp);
    temperature.textContent = `${temp}°C`;
    
    // Display humidity
    humidity.textContent = `${data.main.humidity}%`;
    
    // Display wind speed
    const wind = Math.round(data.wind.speed);
    windSpeed.textContent = `${wind} km/h`;
    
    // Update timestamp
    const now = new Date();
    lastUpdated.textContent = formatTime(now);
    
    // Show weather info and hide error message
    weatherInfo.classList.remove('hidden');
    errorMessage.classList.add('hidden');
    
    // Apply weather-appropriate styling
    applyWeatherStyling(data.weather[0].main);
}

function applyWeatherStyling(weatherMain) {
    // Convert weather main category to lowercase for class matching
    const weatherClass = weatherMain.toLowerCase();
    
    // Remove all weather classes first
    document.body.classList.remove('sunny', 'cloudy', 'rainy', 'snowy', 'thunderstorm', 'foggy');
    
    // Add appropriate weather class
    switch (weatherMain.toLowerCase()) {
        case 'clear':
            document.body.classList.add('sunny');
            break;
        case 'clouds':
            document.body.classList.add('cloudy');
            break;
        case 'rain':
        case 'drizzle':
            document.body.classList.add('rainy');
            break;
        case 'snow':
            document.body.classList.add('snowy');
            break;
        case 'thunderstorm':
            document.body.classList.add('thunderstorm');
            break;
        case 'mist':
        case 'fog':
            document.body.classList.add('foggy');
            break;
        default:
            // Default to sunny weather styling
            document.body.classList.add('sunny');
    }
}

/**
 * Create mock weather data for demonstration purposes
 */
function generateMockWeatherData(city) {
    const weatherConditions = [
        { main: 'Clear', description: 'clear sky' },
        { main: 'Clouds', description: 'few clouds' },
        { main: 'Rain', description: 'light rain' },
        { main: 'Snow', description: 'light snow' },
        { main: 'Thunderstorm', description: 'thunderstorm' }
    ];
    
    // Get a random weather condition
    const randomWeather = weatherConditions[Math.floor(Math.random() * weatherConditions.length)];
    
    // Generate random weather values
    const temp = Math.floor(Math.random() * 30) + 5; // 5-35°C
    const humidity = Math.floor(Math.random() * 50) + 40; // 40-90%
    const windSpeed = Math.floor(Math.random() * 15) + 3; // 3-18 km/h
    
    return {
        name: city,
        weather: [
            {
                main: randomWeather.main,
                description: randomWeather.description
            }
        ],
        main: {
            temp: temp,
            humidity: humidity
        },
        wind: {
            speed: windSpeed
        }
    };
}

/**
 * Show error message
 */
function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.remove('hidden');
    weatherInfo.classList.add('hidden');
    setLoading(false);
}

/**
 * Clear error message
 */
function clearError() {
    errorMessage.classList.add('hidden');
}

/**
 * Show or hide loading state
 */
function setLoading(isLoading) {
    if (isLoading) {
        loadingSpinner.classList.remove('hidden');
        searchBtn.disabled = true;
        locationBtn.disabled = true;
        weatherInfo.classList.add('hidden');
    } else {
        loadingSpinner.classList.add('hidden');
        searchBtn.disabled = false;
        locationBtn.disabled = false;
    }
}

/**
 * Format the time in a user-friendly format
 */
function formatTime(date) {
    const options = { 
        hour: 'numeric', 
        minute: 'numeric', 
        weekday: 'short'
    };
    return new Intl.DateTimeFormat('en-US', options).format(date);
}