# Weather Dashboard

This is the default weather dashboard with comprehensive features including:
- Current weather display with rich metrics
- Detailed 7-day forecast with advanced data
- Location management with geolocation and search
- Beautiful UI with weather backgrounds and animations
- Settings management with many customizations
- Map view for weather visualization
- Air quality and UV index data
- Weather alerts and notifications
- Full TypeScript typing and robust error handling