import mongoose from 'mongoose';

const profileSchema = new mongoose.Schema({
  name: {
    first: { type: String, required: true },
    last: { type: String, required: true },
  },
  title: String,
  bio: String,
  avatar: String,
});

const locationSchema = new mongoose.Schema({
  postalCode: String,
  address: String,
});

const socialLinkSchema = new mongoose.Schema({
  twitter: String,
  github: String,
  website: String,
});

const userSchema = new mongoose.Schema({
  displayName: { type: String, required: true },
  profile: profileSchema,
  location: locationSchema,
  socialLinks: socialLinkSchema,
});

userSchema.options.toJSON = {
  transform: function (doc, ret, options) {
    ret.id = ret._id;
    delete ret._id;
    delete ret.__v;
    return ret;
  },
};

export default mongoose.model('User', userSchema);