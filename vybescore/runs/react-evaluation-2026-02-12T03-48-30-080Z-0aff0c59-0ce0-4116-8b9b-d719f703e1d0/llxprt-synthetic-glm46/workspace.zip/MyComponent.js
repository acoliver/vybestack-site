import React, { useState, useCallback } from 'react';

/**
 * ErrorBoundary Component for catching errors in child components
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
    console.error('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <div className="error-fallback">
          <h2>Something went wrong.</h2>
          <details>
            {this.state.error && this.state.error.toString()}
            <br />
            {this.state.errorInfo.componentStack}
          </details>
        </div>
      );
    }

    return this.props.children;
  }
}

/**
 * Form Component demonstrating error pattern usage
 * Note: React recommends using functional components with hooks for new code
 */
class FormComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formData: {
        username: '',
        email: ''
      },
      errors: {
        username: null,
        email: null
      },
      isSubmitting: false
    };
  }

  // Validation logic
  validateField = (name, value) => {
    switch (name) {
      case 'username':
        if (!value.trim()) {
          return 'Username is required';
        }
        if (value.length < 3) {
          return 'Username must be at least 3 characters';
        }
        return null;
      case 'email':
        if (!value.trim()) {
          return 'Email is required';
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          return 'Please enter a valid email address';
        }
        return null;
      default:
        return null;
    }
  };

  // Handle field changes
  handleFieldChange = (fieldName, value) => {
    this.setState(prevState => ({
      formData: {
        ...prevState.formData,
        [fieldName]: value
      }
    }));

    // Validate field and update errors
    const error = this.validateField(fieldName, value);
    this.setState(prevState => ({
      errors: {
        ...prevState.errors,
        [fieldName]: error
      }
    }));
  };

  // Handle form submission
  handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate all fields
    const { formData } = this.state;
    const newErrors = {};
    
    newErrors.username = this.validateField('username', formData.username);
    newErrors.email = this.validateField('email', formData.email);
    
    this.setState({ errors: newErrors });

    // Only submit if there are no errors
    const hasErrors = Object.values(newErrors).some(error => error !== null);
    
    if (!hasErrors) {
      this.setState({ isSubmitting: true });
      this.props.onSubmit(formData);
    }
  };

  render() {
    const { formData, errors, isSubmitting } = this.state;
    const { submitButtonText, extraClasses } = this.props;

    return (
      <form 
        className={`formComponent ${extraClasses.join(' ')}`}
        onSubmit={this.handleSubmit}
      >
        <div className="formField">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={formData.username}
            onChange={(e) => this.handleFieldChange('username', e.target.value)}
            placeholder="Enter your username"
          />
          {errors.username && (
            <span className="errorMessage">{errors.username}</span>
          )}
        </div>

        <div className="formField">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={formData.email}
            onChange={(e) => this.handleFieldChange('email', e.target.value)}
            placeholder="Enter your email"
          />
          {errors.email && (
            <span className="errorMessage">{errors.email}</span>
          )}
        </div>

        <div className="formActions">
          <button 
            type="submit" 
            className="submitButton"
            disabled={isSubmitting}
          >
            {submitButtonText}
          </button>
        </div>
      </form>
    );
  }
}

FormComponent.defaultProps = {
  submitButtonText: 'Submit',
  extraClasses: []
};

export default FormComponent;
export { ErrorBoundary };