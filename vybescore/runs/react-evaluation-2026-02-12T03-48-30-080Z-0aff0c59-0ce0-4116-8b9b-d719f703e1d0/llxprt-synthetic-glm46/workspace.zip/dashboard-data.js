// Dashboard data for visualization
const ReactEvaluationDashboardData = {
  overall: {
    totalModels: 4,
    metrics: {
      overallScore: 0.75,
      qualityScore: 0.69,
      functionalityScore: 0.84,
      architectureScore: 0.83
    }
  },
  detailedScores: [
    { name: "Claude 3.5 Sonnet", overallScore: 0.87, qualityScore: 0.80, functionalityScore: 0.94, architectureScore: 0.87 },
    { name: "GPT-4o", overallScore: 0.83, qualityScore: 0.75, functionalityScore: 0.94, architectureScore: 0.81 },
    { name: "Gemini 2.0 Flash", overallScore: 0.68, qualityScore: 0.62, functionalityScore: 0.77, architectureScore: 0.83 },
    { name: "LLaMA 3.1 70B", overallScore: 0.63, qualityScore: 0.58, functionalityScore: 0.68, architectureScore: 0.80 }
  ],
  radar: {
    labels: ["Functional Accuracy", "Error Handling", "Performance", "State Management", "Code Quality", "Testability"],
    datasets: [
      {
        label: "Claude 3.5 Sonnet",
        data: [100, 0.71, 0.71, 0.82, 0.90, 0.83],
        backgroundColor: "rgba(255, 99, 132, 0.2)",
        borderColor: "rgba(255, 99, 132, 1)",
        borderWidth: 1
      },
      {
        label: "GPT-4o",
        data: [1.00, 0.81, 0.81, 0.63, 0.81, 0.75],
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1
      },
      {
        label: "Gemini 2.0 Flash",
        data: [0.86, 0.43, 0.43, 0.89, 0.66, 0.80],
        backgroundColor: "rgba(255, 206, 86, 0.2)",
        borderColor: "rgba(255, 206, 86, 1)",
        borderWidth: 1
      },
      {
        label: "LLaMA 3.1 70B",
        data: [0.71, 0.31, 0.31, 0.82, 0.53, 0.80],
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1
      }
    ]
  },
  heatmap: {
    labels: {
      y: ["Claude 3.5 Sonnet", "GPT-4o", "Gemini 2.0 Flash", "LLaMA 3.1 70B"],
      x: [
        "Basic Components",
        "Custom Event",
        "Local Storage",
        "External API Integration",
        "Form Validation",
        "Context API",
        "React Query",
        "Performance Optimization",
        "Error Boundaries",
        "Custom Hooks"
      ]
    },
    data: [
      [87, 81, 88, 87, 94, 94, 94, 87, 75, 94],   // Claude 3.5 Sonnet
      [87, 87, 88, 88, 94, 93, 94, 87, 88, 87],   // GPT-4o
      [69, 62, 88, 94, 88, 56, 88, 81, 69, 81],   // Gemini 2.0 Flash
      [62, 56, 63, 94, 88, 87, 50, 75, 56, 75]    // LLaMA 3.1 70B
    ]
  }
};

// Export data for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ReactEvaluationDashboardData;
}

// For browser use
if (typeof window !== 'undefined') {
  window.ReactEvaluationDashboardData = ReactEvaluationDashboardData;
}