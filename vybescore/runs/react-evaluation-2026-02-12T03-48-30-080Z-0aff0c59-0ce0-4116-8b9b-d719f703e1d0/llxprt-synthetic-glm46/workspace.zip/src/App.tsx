import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import './styles/globals.css';

/**
 * Main App Component
 * 
 * This is the root component of the React application that sets up routing
 * and renders the appropriate page components based on the current URL.
 */
const App: React.FC = () => {
  return (
    <Router>
      <div className="app">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/health" element={<HomePage />} />
          <Route path="/api/tasks" element={<HomePage />} />
          <Route path="/api/user" element={<HomePage />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;