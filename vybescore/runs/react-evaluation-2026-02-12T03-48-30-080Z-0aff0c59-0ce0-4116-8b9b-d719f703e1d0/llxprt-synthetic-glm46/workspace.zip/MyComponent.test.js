import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import MyComponent from './MyComponent';

// Mock the setTimeout function for testing
jest.useFakeTimers();

describe('MyComponent', () => {
  it('renders initial state correctly', () => {
    render(<MyComponent />);
    expect(screen.getByText('Initial Count: 0')).toBeInTheDocument();
    expect(screen.getByText('Initial Message: Hello World')).toBeInTheDocument();
  });

  it('handles button click events correctly', () => {
    render(<MyComponent />);
    const incrementButton = screen.getByText('Increment');
    const countElement = screen.getByText(/Initial Count:/);
    
    // Initial state
    expect(countElement).toHaveTextContent('Initial Count: 0');
    
    // Click increment button
    fireEvent.click(incrementButton);
    expect(countElement).toHaveTextContent('Initial Count: 1');
    
    // Click decrement button
    const decrementButton = screen.getByText('Decrement');
    fireEvent.click(decrementButton);
    expect(countElement).toHaveTextContent('Initial Count: 0');
  });

  it('handles text input for message', () => {
    render(<MyComponent />);
    const messageInput = screen.getByRole('textbox');
    const messageElement = screen.getByText(/Initial Message:/);
    
    // Initial message
    expect(messageElement).toHaveTextContent('Initial Message: Hello World');
    expect(messageInput).toHaveValue('Hello World');
    
    // Change input value
    fireEvent.change(messageInput, { target: { value: 'New Message' } });
    expect(messageElement).toHaveTextContent('Initial Message: New Message');
    expect(messageInput).toHaveValue('New Message');
  });

  it('displays correct status based on count', () => {
    render(<MyComponent />);
    const statusElement = screen.getByText(/Status:/);
    const incrementButton = screen.getByText('Increment');
    
    // Initial status
    expect(statusElement).toHaveTextContent('Status: Low');
    
    // Increment to 3
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    expect(statusElement).toHaveTextContent('Status: Medium');
    
    // Increment to 7
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    expect(statusElement).toHaveTextContent('Status: High');
  });

  it('disables reset button initially', () => {
    render(<MyComponent />);
    const resetButton = screen.getByText('Reset');
    expect(resetButton).toBeDisabled();
  });

  it('enables reset button when count or message changes', () => {
    render(<MyComponent />);
    const resetButton = screen.getByText('Reset');
    const incrementButton = screen.getByText('Increment');
    const messageInput = screen.getByRole('textbox');
    
    // Initially disabled
    expect(resetButton).toBeDisabled();
    
    // After incrementing
    fireEvent.click(incrementButton);
    expect(resetButton).toBeEnabled();
    
    // Reset and test message change
    fireEvent.click(resetButton);
    expect(resetButton).toBeDisabled();
    
    fireEvent.change(messageInput, { target: { value: 'New Message' } });
    expect(resetButton).toBeEnabled();
  });

  it('resets component to initial state when reset button is clicked', () => {
    render(<MyComponent />);
    const resetButton = screen.getByText('Reset');
    const incrementButton = screen.getByText('Increment');
    const messageInput = screen.getByRole('textbox');
    const countElement = screen.getByText(/Initial Count:/);
    const messageElement = screen.getByText(/Initial Message:/);
    
    // Change state
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    fireEvent.change(messageInput, { target: { value: 'Changed Message' } });
    
    // Verify state changed
    expect(countElement).toHaveTextContent('Initial Count: 2');
    expect(messageElement).toHaveTextContent('Initial Message: Changed Message');
    expect(resetButton).toBeEnabled();
    
    // Reset
    fireEvent.click(resetButton);
    
    // Verify state reset
    expect(countElement).toHaveTextContent('Initial Count: 0');
    expect(messageElement).toHaveTextContent('Initial Message: Hello World');
    expect(resetButton).toBeDisabled();
  });

  it('debounces input changes correctly', () => {
    render(<MyComponent />);
    const messageInput = screen.getByRole('textbox');
    const messageElement = screen.getByText(/Initial Message:/);
    
    // Initial message
    expect(messageElement).toHaveTextContent('Initial Message: Hello World');
    
    // Change input value multiple times quickly
    fireEvent.change(messageInput, { target: { value: 'Message 1' } });
    fireEvent.change(messageInput, { target: { value: 'Message 2' } });
    fireEvent.change(messageInput, { target: { value: 'Final Message' } });
    
    // Should not update immediately due to debounce
    expect(messageElement).toHaveTextContent('Initial Message: Hello World');
    
    // Fast-forward past debounce delay
    jest.runAllTimers();
    
    // Should update to the last value
    expect(messageElement).toHaveTextContent('Initial Message: Final Message');
  });

  it('should debounce multiple input changes and only update once', () => {
    render(<MyComponent />);
    const messageInput = screen.getByRole('textbox');
    const messageElement = screen.getByText(/Initial Message:/);
    
    // Change input value multiple times
    fireEvent.change(messageInput, { target: { value: 'Message 1' } });
    jest.advanceTimersByTime(100);
    fireEvent.change(messageInput, { target: { value: 'Message 2' } });
    jest.advanceTimersByTime(100);
    fireEvent.change(messageInput, { target: { value: 'Message 3' } });
    
    // Still should show original message
    expect(messageElement).toHaveTextContent('Initial Message: Hello World');
    
    // After full debounce delay
    jest.advanceTimersByTime(800);
    
    // Should show final message
    expect(messageElement).toHaveTextContent('Initial Message: Message 3');
  });
});