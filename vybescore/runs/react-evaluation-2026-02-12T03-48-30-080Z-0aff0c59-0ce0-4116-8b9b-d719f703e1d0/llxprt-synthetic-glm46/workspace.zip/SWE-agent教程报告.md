# SWE-agent 代理实现教程：基于真实 GitHub 问题解决

## 1. SWE-agent 简介

SWE-agent是一个专门用于解决GitHub问题的AI代理系统，它通过模拟人类开发者的工作流程，能够理解问题、分析代码、编写解决方案并验证修复效果。该系统在SWE-bench基准测试中取得了令人瞩目的成绩，已成为评估AI编程能力的重要标准。

## 2. 系统架构与核心理念

### 2.1 SWE-agent 的核心组件

1. **代理核心 (Agent Core)**：负责决策生成和任务分解
2. **环境接口 (Environment Interface)**：提供与代码库交互的工具集
3. **工具系统 (Tool System)**：包括文件操作、代码执行、搜索等能力
4. **反馈机制 (Feedback Mechanism)**：从执行结果中学习和调整策略

### 2.2 SWE-bench 基准测试

SWE-bench是一个评估AI代理软件工程能力的基准测试，它包含了来自真实开源项目的GitHub问题。该测试主要关注以下能力：

- 理解需求描述
- 定位相关代码
- 实现解决方案
- 验证修复效果

### 2.3 性能评估标准

不同实现在SWE-bench上的表现：
- SWE-agent原始版本：约12%解决率
- Augment SWE-bench代理：65.4%解决率（使用Claude Sonnet 3.7 + OpenAI o1）
- Mini-swe-agent：74%+解决率（仅需100行代码）

## 3. 详细实现教程

### 3.1 项目初始化

首先创建项目结构：

```bash
mkdir swe-agent-tutorial
cd swe-agent-tutorial
python -m venv venv
source venv/bin/activate # Linux/Mac
pip install -r requirements.txt
```

### 3.2 基础工具实现

#### 文件操作工具

```python
import os
import subprocess
from typing import Dict, List, Optional

class FileTool:
 """文件操作工具集"""
 
 @staticmethod
 def read_file(file_path: str) -> str:
 """读取文件内容"""
 try:
 with open(file_path, 'r', encoding='utf-8') as f:
 return f.read()
 except Exception as e:
 return f"Error reading file: {str(e)}"
 
 @staticmethod
 def write_file(file_path: str, content: str) -> bool:
 """写入文件内容"""
 try:
 with open(file_path, 'w', encoding='utf-8') as f:
 f.write(content)
 return True
 except Exception as e:
 print(f"Error writing file: {str(e)}")
 return False
 
 @staticmethod
 def list_directory(dir_path: str) -> List[str]:
 """列出目录内容"""
 try:
 return os.listdir(dir_path)
 except Exception as e:
 print(f"Error listing directory: {str(e)}")
 return []
```

#### 代码执行工具

```python
class ExecutionTool:
 """代码执行工具"""
 
 @staticmethod
 def execute_bash(command: str, timeout: int = 30) -> Dict:
 """执行bash命令"""
 try:
 result = subprocess.run(
 command, 
 shell=True, 
 capture_output=True, 
 text=True, 
 timeout=timeout
 )
 
 return {
 "status": "success" if result.returncode == 0 else "error",
 "stdout": result.stdout,
 "stderr": result.stderr,
 "returncode": result.returncode
 }
 except subprocess.TimeoutExpired:
 return {
 "status": "error",
 "stdout": "",
 "stderr": f"Command timed out after {timeout} seconds",
 "returncode": -1
 }
 except Exception as e:
 return {
 "status": "error",
 "stdout": "",
 "stderr": str(e),
 "returncode": -1
 }
```

### 3.3 核心代理实现

#### 基础代理框架

```python
from abc import ABC, abstractmethod
from typing import List, Dict, Any
import json
import re

class BaseAgent(ABC):
 """基础代理抽象类"""
 
 def __init__(self, llm_client, tool_system):
 self.llm_client = llm_client
 self.tool_system = tool_system
 self.memory = []
 
 @abstractmethod
 def think(self, instruction: str) -> str:
 """生成思考过程"""
 pass
 
 @abstractmethod
 def act(self, action: str) -> Dict:
 """执行具体动作"""
 pass
 
 @abstractmethod
 def reflect(self, result: Dict) -> str:
 """反思执行结果"""
 pass
```

#### Mini-swe-agent 简约实现

```python
class MiniSWEAgent(BaseAgent):
 """简约SWE代理实现 - 约100行代码"""
 
 def __init__(self, llm_client):
 tool_system = {
 "read_file": FileTool.read_file,
 "write_file": FileTool.write_file, 
 "list_directory": FileTool.list_directory,
 "execute_bash": ExecutionTool.execute_bash
 }
 super().__init__(llm_client, tool_system)
 self.max_iterations = 10
 
 def think(self, instruction: str) -> str:
 """生成思考过程和下一步动作"""
 context = "\n".join([f"{m['role']}: {m['content']}" for m in self.memory[-5:]])
 
 prompt = f"""
你是一个解决GitHub问题的AI助手。

问题描述:
{instruction}

历史对话:
{context}

请思考下一步应该做什么，用以下格式回答:
 

<action>
工具调用格式: tool_name(parameters)
</action>

可用工具: {list(self.tool_system.keys())}
"""
 
 response = self.llm_client.chat(prompt)
 return response
 
 def act(self, action: str) -> Dict:
 """解析并执行动作"""
 # 提取工具调用
 tool_match = re.search(r'(\w+)\((.*)\)', action)
 
 if not tool_match:
 return {"status": "error", "message": "Invalid action format"}
 
 tool_name = tool_match.group(1)
 params_str = tool_match.group(2)
 
 if tool_name not in self.tool_system:
 return {"status": "error", "message": f"Unknown tool: {tool_name}"}
 
 # 解析参数
 try:
 # 简单参数解析，实际实现需要更复杂的处理
 params = eval(params_str) if params_str else {}
 result = self.tool_system[tool_name](**params)
 return {"status": "success", "result": result}
 except Exception as e:
 return {"status": "error", "message": str(e)}
 
 def reflect(self, result: Dict) -> str:
 """根据执行结果反思"""
 if result["status"] == "success":
 return "Action completed successfully"
 else:
 return f"Action failed: {result.get('message', 'Unknown error')}"
 
 def run(self, instruction: str) -> Dict:
 """运行代理直到问题解决或达到最大迭代次数"""
 self.memory.append({"role": "system", "content": instruction})
 
 for iteration in range(self.max_iterations):
 # 思考
 thought = self.think(instruction)
 
 # 记录思考过程
 self.memory.append({"role": "assistant", "content": thought})
 
 # 提取动作
 action_match = re.search(r'<action>(.*?)</action>', thought, re.DOTALL)
 if not action_match:
 continue
 
 action = action_match.group(1).strip()
 
 # 执行动作
 result = self.act(action)
 
 # 反思
 reflection = self.reflect(result)
 
 # 记录执行结果
 self.memory.append({"role": "system", "content": f"Result: {result}\nReflection: {reflection}"})
 
 # 检查是否解决问题
 if self._check_solution():
 return {"status": "success", "iterations": iteration + 1}
 
 return {"status": "failed", "iterations": self.max_iterations}
 
 def _check_solution(self) -> bool:
 """检查是否已解决问题（简化版本）"""
 # 在实际实现中，这里应该运行测试或检查其他指标
 return False
```

### 3.4 高级特性实现

#### 上下文管理器

```python
class ContextManager:
 """上下文管理器 - 负责维护代理的长期记忆"""
 
 def __init__(self, max_context_length: int = 10000):
 self.max_context_length = max_context_length
 self.relevant_snippets = []
 self.interaction_history = []
 
 def add_relevant_snippet(self, file_path: str, excerpt: str, reason: str):
 """添加相关代码片段"""
 self.relevant_snippets.append({
 "file_path": file_path,
 "excerpt": excerpt,
 "reason": reason
 })
 
 def add_interaction(self, role: str, content: str):
 """添加交互记录"""
 self.interaction_history.append({
 "role": role,
 "content": content,
 "timestamp": time.time()
 })
 
 def get_context(self) -> str:
 """获取完整上下文"""
 context_parts = []
 
 # 添加相关代码片段
 if self.relevant_snippets:
 context_parts.append("=== Relevant Code Snippets ===")
 for snippet in self.relevant_snippets[-10:]: # 只保留最近的10个片段
 context_parts.append(f"File: {snippet['file_path']}")
 context_parts.append(f"Reason: {snippet['reason']}")
 context_parts.append("```")
 context_parts.append(snippet['excerpt'])
 context_parts.append("```\n")
 
 # 添加交互历史
 relevant_history = self.interaction_history[-20:]
 context_parts.append("=== Interaction History ===")
 for interaction in relevant_history:
 context_parts.append(f"{interaction['role']}: {interaction['content']}")
 
 full_context = "\n".join(context_parts)
 
 # 如果上下文过长则截断
 if len(full_context) > self.max_context_length:
 return full_context[-self.max_context_length:]
 
 return full_context
```

#### 思维链工具

```python
class ThoughtChainTool:
 """思维链工具 - 帮助代理进行结构化思考"""
 
 def __init__(self, llm_client):
 self.llm_client = llm_client
 
 def decompose_problem(self, problem_description: str) -> List[str]:
 """将复杂问题分解为子任务"""
 prompt = f"""
请将以下GitHub问题分解为一系列子任务。每个子任务应该是可以被独立执行的。

问题描述:
{problem_description}

请以JSON格式返回子任务列表:
{{ "subtasks": ["任务1", "任务2", ...] }}
"""
 
 response = self.llm_client.chat(prompt)
 try:
 result = json.loads(response)
 return result.get("subtasks", [])
 except:
 # 如果JSON解析失败，尝试提取清单格式
 subtasks = re.findall(r'[\-\*]\s*(.+)', response)
 return subtasks
 
 def plan_action(self, current_state: str, goal: str) -> str:
 """规划下一步行动"""
 prompt = f"""
基于当前状态和目标，规划下一步应该采取的行动。

当前状态:
{current_state}

目标:
{goal}

请规划具体的下一步行动，描述要具体且可执行。
"""
 
 return self.llm_client.chat(prompt)
 
 def reflect_on_result(self, action: str, result: Dict) -> Dict:
 """反思执行结果并生成见解"""
 prompt = f"""
反思以下行动和结果:

行动: {action}
结果: {json.dumps(result)}

请回答以下问题:
1. 行动是否按预期执行？
2. 结果是否向目标更进一步？
3. 下一步应该做什么？
4. 从中学到了什么？

以JSON格式返回:
{{ "success": true/false, "next_action": "...", "insights": ["..."], "adjustments": ["..."] }}
"""
 
 response = self.llm_client.chat(prompt)
 try:
 return json.loads(response)
 except:
 return {
 "success": "error" in str(result).lower(),
 "next_action": "Re-evaluate approach",
 "insights": ["Reflection failed"],
 "adjustments": ["Simplify plan"]
 }
```

## 4. 示例：解决实际GitHub问题

### 4.1 准备环境

```python
# 示例：设置一个简单的GitHub问题解决环境
import os
import shutil
from tempfile import TemporaryDirectory

class SWEProblemSolver:
 """GitHub问题解决器"""
 
 def __init__(self, repo_url: str, issue_description: str):
 self.repo_url = repo_url
 self.issue_description = issue_description
 self.work_dir = TemporaryDirectory()
 self.agent = None
 
 def setup_repository(self):
 """克隆和设置代码库"""
 try:
 # 提取仓库信息
 repo_name = self.repo_url.split('/')[-1].replace('.git', '')
 repo_path = os.path.join(self.work_dir.name, repo_name)
 
 # 实际实现中应该使用git clone
 # 这里简化处理
 os.makedirs(repo_path, exist_ok=True)
 
 # 创建一些示例文件
 self._create_sample_files(repo_path)
 
 return repo_path
 except Exception as e:
 print(f"Failed to setup repository: {e}")
 return None
 
 def _create_sample_files(self, repo_path: str):
 """创建示例文件用于演示"""
 # 创建主要应用文件
 app_content = '''def calculate_total(items):
 """计算项目总数"""
 total = 0
 for item in items:
 total += item['price'] * item['quantity']
 return total

def format_currency(amount):
 """格式化货币显示"""
 return f"${amount:.2f}"
'''
 
 with open(os.path.join(repo_path, 'app.py'), 'w') as f:
 f.write(app_content)
 
 # 创建测试文件
 test_content = '''import unittest
from app import calculate_total, format_currency

class TestApp(unittest.TestCase):
 def test_calculate_total(self):
 items = [
 {'name': 'Apple', 'price': 1.0, 'quantity': 3},
 {'name': 'Orange', 'price': 1.5, 'quantity': 2}
 ]
 self.assertEqual(calculate_total(items), 6.0)
 
 def test_format_currency(self):
 self.assertEqual(format_currency(12.5), '$12.50')

if __name__ == '__main__':
 unittest.main()
'''
 
 with open(os.path.join(repo_path, 'test_app.py'), 'w') as f:
 f.write(test_content)
 
 def solve_problem(self):
 """解决问题的主要流程"""
 # 设置代码库
 repo_path = self.setup_repository()
 if not repo_path:
 return {"status": "failed", "reason": "Repository setup failed"}
 
 # 创建代理
 self.agent = MiniSWEAgent(llm_client=self._create_mock_llm())
 
 # 运行问题解决流程
 result = self.agent.run(self.issue_description)
 
 return result
 
 def _create_mock_llm(self):
 """创建模拟LLM客户端用于演示"""
 class MockLLM:
 def chat(self, prompt):
 # 在实际实现中，这里会调用真实的LLM API
 # 这里简化返回一些预定义的响应
 if "下一步应该做什么" in prompt or "think" in prompt.lower():
 return ''' 

<action>list_directory({"dir_path": "./"})</action>'''
 
 elif "read_file" in prompt or "open" in prompt.lower():
 return ''' 

<action>read_file({"file_path": "./app.py"})</action>'''
 
 elif "bug" in prompt.lower() or "error" in prompt.lower():
 return ''' 

<action>write_file({"file_path": "./app.py", "content": "def calculate_total(items):\n \"\"\"计算项目总数\"\"\"\n total = 0\n for item in items:\n try:\n total += item['price'] * item['quantity']\n except KeyError:\n # 如果缺少必要字段，跳过该项\n continue\n return total\n\ndef format_currency(amount):\n \"\"\"格式化货币显示\"\"\"\n return f\"\\${amount:.2f}\""})</action>'''
 
 return "I need more information to proceed."
 
 return MockLLM()
```

### 4.2 完整问题解决示例

```python
def run_example():
 """运行完整的GitHub问题解决示例"""
 
 # 创建问题描述
 issue_description = """
 使用calculate_total函数时，如果商品字典中缺少'price'或'quantity'键，程序会抛出KeyError。
 请修复这个问题，使函数更加健壮。
 """
 
 # 创建问题解决器
 solver = SWEProblemSolver(
 repo_url="https://github.com/example/shopping-cart.git",
 issue_description=issue_description
 )
 
 # 尝试解决问题
 result = solver.solve_problem()
 
 print(f"问题解决结果: {result['status']}")
 print(f"迭代次数: {result.get('iterations', 'N/A')}")
 
 return result

# 运行示例
if __name__ == "__main__":
 result = run_example()
```

## 5. 高级应用与优化

### 5.1 模型集成策略

#### 多模型集成

```python
class EnsembleAgent:
 """集成代理 - 结合多个模型的能力"""
 
 def __init__(self, models: Dict[str, Any]):
 self.models = models
 self.voting_weights = {
 'claude': 0.5, # 代码生成能力强
 'gpt': 0.3, # 推理能力强
 'gemini': 0.2 # 综合能力平衡
 }
 
 def ensemble_response(self, prompt: str, task_type: str = "general") -> str:
 """获取集成响应"""
 responses = {}
 
 # 从各个模型获取响应
 for model_name, model in self.models.items():
 try:
 response = model.chat(prompt)
 responses[model_name] = response
 except Exception as e:
 print(f"Error from {model_name}: {e}")
 responses[model_name] = None
 
 # 根据任务类型选择不同的集成策略
 if task_type == "code_generation":
 return self._vote_code(responses)
 elif task_type == "reasoning":
 return self._vote_reasoning(responses)
 else:
 return self._vote_general(responses)
 
 def _vote_code(self, responses: Dict) -> str:
 """代码生成任务的投票策略"""
 # 优先考虑Claude对代码的理解
 if responses.get('claude') and self._validate_code(responses['claude']):
 return responses['claude']
 
 # 备选其他模型
 for model_name, response in responses.items():
 if response and self._validate_code(response):
 return response
 
 # 回退到最后一个有效的响应
 valid_responses = [r for r in responses.values() if r]
 return valid_responses[-1] if valid_responses else ""
 
 def _validate_code(self, code: str) -> bool:
 """简单的代码验证"""
 try:
 compile(code, '<string>', 'exec')
 return True
 except:
 return False
 
 def _vote_reasoning(self, responses: Dict) -> str:
 """推理任务的投票策略"""
 # 优先考虑GPT的推理能力
 if responses.get('gpt'):
 return responses['gpt']
 
 # 备选其他模型
 for response in responses.values():
 if response:
 return response
 
 return ""
 
 def _vote_general(self, responses: Dict) -> str:
 """通用任务的投票策略"""
 # 基于权重的加权选择
 total_score = 0
 weighted_text = ""
 
 for model_name, response in responses.items():
 if response:
 weight = self.voting_weights.get(model_name, 0.1)
 weighted_text += f"[{weight:.1f}]{response}\n"
 total_score += weight
 
 # 在实际实现中，这里应该有更复杂的投票逻辑
 return weighted_text
```

### 5.2 性能优化技巧

#### 高效的文件处理

```python
class EfficientFileManager:
 """高效的文件管理器"""
 
 def __init__(self, working_dir: str):
 self.working_dir = working_dir
 self.file_cache = {}
 self.recent_files = []
 self.max_recent = 10
 
 def read_file_cached(self, file_path: str) -> str:
 """带缓存的文件读取"""
 full_path = os.path.join(self.working_dir, file_path)
 
 # 检查缓存
 if file_path in self.file_cache:
 return self.file_cache[file_path]
 
 # 检查文件是否被修改
 try:
 current_mtime = os.path.getmtime(full_path)
 cache_entry = self.file_cache.get(file_path)
 
 if cache_entry and cache_entry.get('mtime') == current_mtime:
 return cache_entry['content']
 
 # 读取文件内容
 with open(full_path, 'r', encoding='utf-8') as f:
 content = f.read()
 
 # 更新缓存
 self.file_cache[file_path] = {
 'content': content,
 'mtime': current_mtime
 }
 
 # 更新最近文件列表
 if file_path in self.recent_files:
 self.recent_files.remove(file_path)
 self.recent_files.append(file_path)
 
 # 保持最近文件列表大小
 if len(self.recent_files) > self.max_recent:
 oldest = self.recent_files.pop(0)
 self.file_cache.pop(oldest, None)
 
 return content
 
 except Exception as e:
 return f"Error reading file: {str(e)}"
```

### 5.3 测试与验证

#### 自动化测试流程

```python
class TestRunner:
 """自动化测试运行器"""
 
 def __init__(self, working_dir: str):
 self.working_dir = working_dir
 self.test_results = {}
 
 def run_tests(self, test_pattern: str = None) -> Dict:
 """运行测试"""
 if not test_pattern:
 test_pattern = "test_*.py"
 
 test_files = glob.glob(os.path.join(self.working_dir, test_pattern))
 
 results = {
 "total": len(test_files),
 "passed": 0,
 "failed": 0,
 "errors": 0,
 "details": []
 }
 
 for test_file in test_files:
 try:
 # 运行测试文件
 test_result = self._run_single_test(test_file)
 
 if test_result["exit_code"] == 0:
 results["passed"] += 1
 status = "PASSED"
 else:
 results["failed"] += 1
 status = "FAILED"
 
 results["details"].append({
 "file": os.path.basename(test_file),
 "status": status,
 "output": test_result["output"],
 "errors": test_result["errors"]
 })
 
 except Exception as e:
 results["errors"] += 1
 results["details"].append({
 "file": os.path.basename(test_file),
 "status": "ERROR",
 "errors": str(e)
 })
 
 return results
 
 def _run_single_test(self, test_file: str) -> Dict:
 """运行单个测试文件"""
 try:
 # 在实际实现中，这里应该使用subprocess执行Python测试
 # 这里简化处理
 result = subprocess.run(
 ["python", test_file],
 capture_output=True,
 text=True,
 timeout=30
 )
 
 return {
 "exit_code": result.returncode,
 "output": result.stdout,
 "errors": result.stderr
 }
 except subprocess.TimeoutExpired:
 return {
 "exit_code": -1,
 "output": "",
 "errors": "Test timed out"
 }
 except Exception as e:
 return {
 "exit_code": -2,
 "output": "",
 "errors": str(e)
 }
```

## 6. 总结与最佳实践

### 6.1 关键成功因素

1. **清晰的系统提示**：精心设计的系统提示是代理成功的关键
2. **工具设计**：简单而强大的工具集能显著提高代理能力
3. **反馈循环**：及时、准确的反馈机制帮助代理学习改进
4. **上下文管理**：高效的上下文管理使代理能够处理大型项目

### 6.2 常见挑战与解决方案

1. **理解能力限制**：
 - 问题提供充分的问题描述
 - 实现多轮对话澄清机制

2. **工具滥用**：
 - 限制工具调用频率
 - 实现工具使用成本模型

3. **上下文溢出**：
 - 实现动态上下文裁剪
 - 优先保留最相关的信息

4. **错误恢复**：
 - 设计错误恢复机制
 - 实现回滚和重试策略

### 6.3 未来发展方向

1. **多模态支持**：集成图像和UI理解能力
2. **持续学习**：从成功/失败案例中学习改进
3. **协作增强**：支持多代理协作解决复杂问题
4. **领域特化**：针对特定编程语言和领域的优化

通过本教程，您应该了解了如何构建一个基本的SWE-agent系统，并学习了核心组件的实现方法。虽然简化版本可能无法直接达到74%的解决率，但它提供了坚实的基础，您可以根据实际需求和资源水平逐步扩展和完善系统。

## 附录：完整工具集参考

```python
class CompleteSWEToolKit:
 """完整的SWE-agent工具集参考实现"""
 
 def __init__(self):
 self.file_tool = FileTool()
 self.execution_tool = ExecutionTool()
 self.context_manager = ContextManager()
 self.thought_chain = ThoughtChainTool(None) # 需要传入LLM客户端
 
 # 其他可能需要的工具
 self.search_tool = self._init_search_tool()
 self.test_runner = TestRunner(".")
 
 def _init_search_tool(self):
 """初始化代码搜索工具"""
 # 实现代码搜索功能，可以基于grep或rg
 return None
 
 def git_tool(self, command: str) -> Dict:
 """Git操作工具"""
 try:
 result = subprocess.run(
 f"git {command}",
 shell=True,
 capture_output=True,
 text=True
 )
 
 return {
 "status": "success" if result.returncode == 0 else "error",
 "stdout": result.stdout,
 "stderr": result.stderr,
 "returncode": result.returncode
 }
 except Exception as e:
 return {
 "status": "error",
 "stdout": "",
 "stderr": str(e),
 "returncode": -1
 }
```

以上提供了一个完整的SWE-agent实现框架，您可以根据具体需求进一步扩展和完善功能。