export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  const noDoubleDots = !value.includes('..');
  const noTrailingDot = !value.endsWith('.');
  const noUnderscoresInDomain = !(/@.*_/.test(value));
  const noLeadingTrailingDotsInLocal = !/^[.+]|[.+]$/.test(value.split('@')[0]);
  
  return emailRegex.test(value) && noDoubleDots && noTrailingDot && noUnderscoresInDomain && noLeadingTrailingDotsInLocal;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length
  if (cleaned.length < 10) return false;
  
  // Optional +1 prefix
  const hasPlusOne = cleaned.startsWith('+1');
  const phoneNumber = hasPlusOne ? cleaned.substring(2) : cleaned;
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Validate area code (first digit can't be 0 or 1)
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') return false;
  
  // Check for valid US phone format with separators
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-plus characters for validation
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Optional country code +54
  const hasCountryCode = cleaned.startsWith('+54');
  let phoneNumber = hasCountryCode ? cleaned.substring(3) : cleaned;
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !phoneNumber.startsWith('0')) return false;
  
  // Remove trunk prefix if present
  if (phoneNumber.startsWith('0')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Extract mobile indicator if present (comes after country code/trunk prefix)
  const isMobile = phoneNumber.startsWith('9');
  if (isMobile) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Now phoneNumber should be: area code + subscriber number
  if (phoneNumber.length < 8 || phoneNumber.length > 12) return false;
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeLength = Math.min(4, phoneNumber.length - 6); // Leave at least 6 digits for subscriber
  if (areaCodeLength < 2) return false;
  
  const areaCode = phoneNumber.substring(0, areaCodeLength);
  const subscriberNumber = phoneNumber.substring(areaCodeLength);
  
  // Validate area code (leading digit can't be 0)
  if (areaCode[0] === '0') return false;
  
// Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;

  // Create specific patterns for each case
  const withCountryCodeAndMobile = /^\+54[\s-]?9[\s-]?[1-9]\d{1,3}[\s-]?\d{3,4}[\s-]?\d{4}$/;
  const withCountryCodeNoMobile = /^\+54[\s-]?[1-9]\d{1,3}[\s-]?\d{3,4}[\s-]?\d{4}$/;
  const withTrunkAndMobile = /^0[\s-]?9[\s-]?[1-9]\d{1,3}[\s-]?\d{3,4}[\s-]?\d{4}$/;
  const withTrunkNoMobile = /^0[\s-]?[1-9]\d{1,3}[\s-]?\d{3,4}[\s-]?\d{4}$/;

  // Check if format matches any pattern
  const formatValid = withCountryCodeAndMobile.test(value) ||
                     withCountryCodeNoMobile.test(value) ||
                     withTrunkAndMobile.test(value) ||
                     withTrunkNoMobile.test(value);

  return formatValid;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  // Additional check to reject digits and obvious symbols
  const hasDigits = /\d/.test(value);
  const hasBadSymbols = /[^\p{L}\p{M}'’\-\s]/u.test(value);
  
  // Must be at least 2 characters and not start/end with space or hyphen
  const trimmed = value.trim();
  if (trimmed.length < 2) return false;
  if (/^[ -]/.test(trimmed) || /[ -]$/.test(trimmed)) return false;
  
  return nameRegex.test(value) && !hasDigits && !hasBadSymbols;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let alternate = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = parseInt(digits[i], 10);
    if (alternate) {
      n *= 2;
      if (n > 9) {
        n = Math.floor(n / 10) + (n % 10);
      }
    }
    sum += n;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length (13-19 digits)
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check Visa (starts with 4, length 13 or 16)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard (starts with 51-55 or 2221-2720, length 16)
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|1\d{3})\d{12})$/;
  
  // Check American Express (starts with 34 or 37, length 15)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if any card type matches
  const validPrefix = visaRegex.test(cleaned) || 
                     mastercardRegex.test(cleaned) || 
                     amexRegex.test(cleaned);
  
  if (!validPrefix) return false;
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}
