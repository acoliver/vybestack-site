/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  // \b for word boundary, then prefix, then one or more word characters
  const pattern = new RegExp(`\\b${escapeRegExp(prefix)}\\w+`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      exception.toLowerCase() === word.toLowerCase()
    )
  );
}

// Helper function to escape regex special characters
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a simpler regex pattern that matches digit followed by token
  const pattern = new RegExp(`\\d${escapeRegExp(token)}`, 'g');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase, one lowercase, one digit, one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':,.<>\/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // This checks for patterns where a character sequence of 2+ chars is repeated consecutively
  const repeatedPattern = /(.{2,})(?=\1)/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Full form: 8 groups of 1-4 hex digits separated by colons
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed form with :: replacing consecutive zero groups
  const ipv6Compressed = /(?:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?::(?:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?/;
  
  // IPv4 embedded in IPv6
  const ipv6EmbeddedIPv4 = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check if text contains IPv6 pattern but exclude pure IPv4
  const hasIPv6 = ipv6Full.test(value) || 
                  ipv6Compressed.test(value) || 
                  ipv6EmbeddedIPv4.test(value);
  
  const hasIPv4Only = ipv4Pattern.test(value) && 
                     !(ipv6Full.test(value) || ipv6Compressed.test(value));
  
  return hasIPv6 && !hasIPv4Only;
}
