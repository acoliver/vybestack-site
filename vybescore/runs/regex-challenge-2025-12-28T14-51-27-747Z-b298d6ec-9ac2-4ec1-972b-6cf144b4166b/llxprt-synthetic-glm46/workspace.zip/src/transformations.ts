/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence boundaries (., ?, !) but handle abbreviations
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let i = 0;
  
  while (i < sentences.length) {
    const content = sentences[i];
    const punctuation = sentences[i + 1] || '';
    
    if (content.trim()) {
      // Trim content and capitalize first letter
      const trimmed = content.trim();
      const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      
      // Add the capitalized sentence with appropriate spacing
      result += capitalized;
      result += (punctuation ? punctuation : '');
      
      // Add space after punctuation if followed by more content
      if (punctuation && i + 2 < sentences.length && sentences[i + 2].trim()) {
        result += ' ';
      }
    } else {
      // Add empty parts as-is
      result += content + punctuation;
    }
    
    i += 2;
  }
  
  // Collapse multiple spaces while preserving single spaces
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to find URLs without trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s)<\]]+[a-zA-Z0-9]/g;
  const urls: string[] = [];
  
  const matches = text.match(urlRegex);
  if (!matches) return urls;
  
  for (const match of matches) {
    // Remove trailing punctuation that's not part of URL
    const cleanUrl = match.replace(/[.,;:!?)]+$/, '');
    urls.push(cleanUrl);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't affect existing https://
  return text.replace(/https?:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Patterns to check for dynamic content that should skip host rewrite
  const skipPatterns = ['cgi-bin', '\\?', '&', '=', '\\.jsp$', '\\.php$', '\\.asp$', '\\.aspx$', '\\.do$', '\\.cgi$', '\\.pl$', '\\.py$'];
  
  return text.replace(/https?:\/\/(?:example\.com)(\/[^\s]*?)(?=\s|$)/g, (match, path) => {
    // Always upgrade to https first
    const upgraded = match.replace('http://', 'https://');
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check if we should skip host rewrite based on dynamic patterns
      const shouldSkip = skipPatterns.some(pattern => new RegExp(pattern).test(path));
      
      if (!shouldSkip) {
        // Rewrite host to docs.example.com but preserve the path
        return 'https://docs.example.com' + path;
      }
    }
    
    return upgraded;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^([0][1-9]|[1][0-2])\/([0][1-9]|[12][0-9]|[3][01])\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Basic validation: check if day is valid for the month
  // (This is simplified - doesn't account for leap years or all month lengths)
  const maxDays = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > maxDays[monthNum as keyof typeof maxDays]) return 'N/A';
  
  return year;
}
