#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatRenderers, supportedFormats } from '../formats/index.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const dataPath = args[0];
  if (!dataPath) {
    console.error('Error: Missing data file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format') {
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = nextArg;
      i++;
    } else if (arg === '--output') {
      if (!nextArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = nextArg;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      console.error(`Error: Unknown option: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Invalid JSON - root must be an object');
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Invalid or missing "title" field (must be a string)');
    return false;
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Invalid or missing "summary" field (must be a string)');
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Invalid or missing "entries" field (must be an array)');
    return false;
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} must be an object`);
      return false;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${i} missing or invalid "label" (must be a string)`);
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${i} missing or invalid "amount" (must be a number)`);
      return false;
    }
  }

  return true;
}

function main(): void {
  const args = process.argv.slice(2);
  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

  if (!supportedFormats.includes(format)) {
    console.error(`Error: Unsupported format "${format}"`);
    console.error(`Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }

  let jsonData: unknown;
  try {
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    jsonData = JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in ${dataPath}`);
      console.error(error.message);
    } else if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: ${dataPath}`);
    } else {
      console.error(`Error: Unable to read file ${dataPath}`);
      console.error((error as Error).message);
    }
    process.exit(1);
  }

  if (!validateReportData(jsonData)) {
    process.exit(1);
  }

  const reportData = jsonData as ReportData;
  const renderer = formatRenderers[format];
  const options: RenderOptions = { includeTotals };
  const output = renderer(reportData, options);

  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to write to file ${outputPath}`);
      console.error((error as Error).message);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
