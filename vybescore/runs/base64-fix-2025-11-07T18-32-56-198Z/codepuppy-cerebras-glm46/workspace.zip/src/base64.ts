/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('Input must be a string');
  }
  
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('Input must be a string');
  }
  
  if (input.trim() === '') {
    throw new Error('Input cannot be empty');
  }
  
  // Remove whitespace for validation (Base64 can contain whitespace in some contexts)
  const trimmedInput = input.trim();
  
  // Check for valid Base64 characters and padding placement
  const firstEqualsIndex = trimmedInput.indexOf('=');
  if (firstEqualsIndex !== -1) {
    // If there's padding (=), it must only be at the end
    const base64WithoutPadding = trimmedInput.substring(0, firstEqualsIndex);
    const paddingPart = trimmedInput.substring(firstEqualsIndex);
    
    // Validate the non-padded part contains only Base64 characters
    const base64Regex = /^[A-Za-z0-9+/]+$/;
    if (!base64Regex.test(base64WithoutPadding)) {
      throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
    }
    
    // Validate padding is only '=' characters
    if (!/^=+$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: padding must be at the end');
    }
    
    // Validate padding length (max 2) and total length is multiple of 4
    const paddingLength = paddingPart.length;
    const totalLength = trimmedInput.length;
    
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
    
    if (totalLength % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  } else {
    // No padding - validate all characters are Base64 alphabet
    const base64Regex = /^[A-Za-z0-9+/]+$/;
    if (!base64Regex.test(trimmedInput)) {
      throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
    }
    
    // For unpadded input, any length is acceptable (RFC 4648)
    // Node.js Buffer can handle unpadded input of any length
  }
  
  try {
    const result = Buffer.from(trimmedInput, 'base64').toString('utf8');
    
    // Additional validation: if the input contains padding, ensure it's not corrupted
    // by checking that the buffer operation didn't silently fail
    if (trimmedInput.includes('=')) {
      // Verify that re-encoding the result would give us the same (or minimally different) input
      const reencoded = Buffer.from(result, 'utf8').toString('base64');
      if (!trimmedInput.startsWith(reencoded.replace(/=+$/, ''))) {
        throw new Error('Invalid Base64 input: corrupted padding');
      }
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input: malformed input');
  }
}