import type { ReportData } from '../types.js';

export interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const result: CliArgs = {
    dataPath: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.dataPath) {
      result.dataPath = arg;
    } else {
      throw new Error(`Unknown or unexpected argument: ${arg}`);
    }
    
    i++;
  }
  
  if (!result.dataPath) {
    throw new Error('Data file path is required');
  }
  
  if (!result.format) {
    throw new Error('--format is required');
  }
  
  return result;
}

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount must be a number`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}