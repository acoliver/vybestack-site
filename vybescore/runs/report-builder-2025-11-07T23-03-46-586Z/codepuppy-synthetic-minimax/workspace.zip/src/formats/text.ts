import type { ReportData, RenderOptions, Formatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: Formatter['render'] = (data: ReportData, options: RenderOptions): string => {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('Entries:');
  
  // Entry list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  // Optional total
  if (options.includeTotals) {
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }
  
  return lines.join('\n');
};