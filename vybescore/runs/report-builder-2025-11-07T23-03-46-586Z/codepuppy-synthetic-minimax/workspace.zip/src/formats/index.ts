import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { Formatter } from '../types.js';

export const formatters: Record<string, Formatter['render']> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats = Object.keys(formatters);