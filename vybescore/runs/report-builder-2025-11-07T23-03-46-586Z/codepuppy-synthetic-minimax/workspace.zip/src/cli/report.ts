#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { parseArgs, validateReportData, type CliArgs } from '../utils/args.js';
import { formatters, supportedFormats } from '../formats/index.js';
import type { ReportData, RenderOptions } from '../types.js';

async function loadJsonFile(path: string): Promise<unknown> {
  try {
    const content = await readFile(path, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${path}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${path}`);
    }
    throw new Error(`Error reading file ${path}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

async function writeOutput(content: string, path?: string): Promise<void> {
  if (path) {
    await writeFile(path, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

async function main(): Promise<void> {
  try {
    const args: CliArgs = parseArgs();
    
    // Validate format
    if (!supportedFormats.includes(args.format)) {
      throw new Error(`Unsupported format: ${args.format}. Supported formats: ${supportedFormats.join(', ')}`);
    }
    
    // Load and validate data
    const rawData = await loadJsonFile(args.dataPath);
    const data: ReportData = validateReportData(rawData);
    
    // Get formatter
    const formatter = formatters[args.format];
    if (!formatter) {
      throw new Error(`No formatter found for format: ${args.format}`);
    }
    
    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    
    const output = formatter(data, options);
    
    // Write output
    await writeOutput(output, args.outputPath);
    
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();