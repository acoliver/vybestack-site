import { markdownFormatter } from './markdown.js';
import { textFormatter } from './text.js';

export const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export type SupportedFormat = keyof typeof formatters;