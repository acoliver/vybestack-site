import { writeFileSync } from 'fs';
import { FormatOptions } from '../types.js';
import { formatters, SupportedFormat } from '../formats/index.js';
import { parseArgs } from './args.js';
import { loadReportData } from '../data.js';

/**
 * Write report content to a file or stdout
 */
function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf8');
  } else {
    process.stdout.write(content);
  }
}

/**
 * Main CLI function
 */
function main(): void {
  try {
    // Parse command line arguments
    const { dataFile, format, outputPath, includeTotals } = parseArgs();

    // Load and validate report data
    const reportData = loadReportData(dataFile);

    // Check if format is supported
    const isSupportedFormat = format in formatters;
    if (!isSupportedFormat) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Get the appropriate formatter
    const formatter = formatters[format as SupportedFormat];

    // Prepare format options
    const options: FormatOptions = {
      includeTotals,
    };

    // Render the report
    const output = formatter.render(reportData, options);

    // Write output
    writeOutput(output, outputPath);
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(`Error: ${error.message}\n`);
    }
    process.exit(1);
  }
}

// Run the CLI
main();