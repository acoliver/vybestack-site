interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    throw new Error('Usage: node <script> <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const result: CliArgs = {
    dataFile: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  // Parse arguments
  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.dataFile) {
      result.dataFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }

    i++;
  }

  if (!result.dataFile) {
    throw new Error('Missing data file argument');
  }

  if (!result.format) {
    throw new Error('Missing required --format argument');
  }

  return result;
}