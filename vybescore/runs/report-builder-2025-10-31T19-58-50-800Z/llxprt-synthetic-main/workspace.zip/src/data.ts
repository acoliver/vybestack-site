import { readFileSync } from 'fs';
import { ReportData } from './types.js';

export function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid report data: title is required and must be a string');
    }

    if (typeof data.summary !== 'string') {
      throw new Error('Invalid report data: summary is required and must be a string');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid report data: entries is required and must be an array');
    }

    // Validate entries
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid report data: each entry must have a string label');
      }

      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error('Invalid report data: each entry must have a valid number amount');
      }
    }

    return data;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to load report data from ${filePath}: ${error.message}`);
    }
    throw new Error(`Failed to load report data from ${filePath}: Unknown error`);
  }
}