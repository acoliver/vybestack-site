#!/usr/bin/env node

import * as fs from 'node:fs';
import type { FormatRenderer } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const FORMATS: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText
};

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    printUsage();
    process.exit(1);
  }

  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      printUsage();
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    printUsage();
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function printUsage(): void {
  console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Arguments:');
  console.error('  data.json       Path to the JSON data file');
  console.error('  --format        Output format (markdown, text)');
  console.error('  --output        Optional output file path (defaults to stdout)');
  console.error('  --includeTotals Include total sum of entry amounts');
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Read and parse JSON file
  let jsonData: unknown;
  try {
    const content = fs.readFileSync(args.dataFile, 'utf-8');
    jsonData = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${args.dataFile}": ${error.message}`);
      process.exit(1);
    }
    const fsError = error as NodeJS.ErrnoException;
    console.error(`Error: Cannot read file "${args.dataFile}": ${fsError.message}`);
    process.exit(1);
  }

  // Validate data structure
  const data = validateReportData(jsonData);

  // Get renderer for format
  const renderer = FORMATS[args.format];
  if (!renderer) {
    console.error(`Error: Unsupported format "${args.format}"`);
    console.error(`Supported formats: ${Object.keys(FORMATS).join(', ')}`);
    process.exit(1);
  }

  // Render report
  const output = renderer(data, { includeTotals: args.includeTotals });

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      const fsError = error as NodeJS.ErrnoException;
      console.error(`Error: Cannot write to file "${args.outputPath}": ${fsError.message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();

