import type { FormatRenderer } from '../types.js';

export const renderMarkdown: FormatRenderer = (data, options) => {
  const lines: string[] = [];

  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push(``);
    lines.push(`**Total:** ${formatAmount(calculateTotal(data))}`);
  }

  return lines.join('\n');
};

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(data: Parameters<FormatRenderer>[0]): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}
