/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR,
  addObserver,
  SubjectR
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observer: undefined,
    observers: new Set<ObserverR>(),
  }
  
  updateObserver(o)
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      o.observer = observer
      addObserver(o as SubjectR, observer)
    }
    return o.value!
  }
}
