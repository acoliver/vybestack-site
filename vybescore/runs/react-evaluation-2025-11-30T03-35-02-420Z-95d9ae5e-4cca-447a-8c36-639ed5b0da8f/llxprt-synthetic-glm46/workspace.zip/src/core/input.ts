/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerObserver,
  notifyAllObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = Object.is
  } else if (_equal === false) {
    equalFn = undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      registerObserver(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed (or no equality function)
    if (!equalFn || !equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all registered observers
      notifyAllObservers()
    }
    return s.value
  }

  return [read, write]
}