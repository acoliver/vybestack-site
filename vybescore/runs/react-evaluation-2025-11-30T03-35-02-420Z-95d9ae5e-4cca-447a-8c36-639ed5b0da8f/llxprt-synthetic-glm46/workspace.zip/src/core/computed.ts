/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver, 
  getActiveObserver,
  registerObserver,
  unregisterObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function (currently not used but kept for API compatibility)
  void _equal

  const currentValue = value

  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn,
  }
  
  // Register this computed observer globally
  registerObserver(o as ObserverR)
  
  // Don't compute initial value - wait for first access
  
  const getter = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Register this observer as a dependency 
      registerObserver(currentObserver)
    }
    // Always recompute when accessed to ensure dependencies are tracked
    updateObserver(o)
    return o.value!
  }
  
  // Set up cleanup if the getter is called in a context where it could be unsubscribed
  const unsubscribe = () => {
    unregisterObserver(o as ObserverR)
  }
  
  // Add unsubscribe method to getter
  Object.defineProperty(getter, 'unsubscribe', {
    value: unsubscribe,
    enumerable: false,
    writable: false,
  })
  
  return getter
}