/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserverWithoutTracking, registerObserver, unregisterObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register this callback globally
  registerObserver(observer)
  
  // Initial execution
  updateObserverWithoutTracking(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Unregister to stop future notifications
    unregisterObserver(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}