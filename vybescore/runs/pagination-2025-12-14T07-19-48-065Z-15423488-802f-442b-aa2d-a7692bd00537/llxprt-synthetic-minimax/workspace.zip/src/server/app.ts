import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_PAGE = 1000;
const MAX_LIMIT = 100;

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse and validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (Number.isNaN(pageNum) || !Number.isFinite(pageNum) || pageNum <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive number.' });
      }
      if (pageNum > MAX_PAGE) {
        return res.status(400).json({ error: `Page parameter too large. Maximum allowed: ${MAX_PAGE}.` });
      }
      page = Math.floor(pageNum);
    }

    // Parse and validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (Number.isNaN(limitNum) || !Number.isFinite(limitNum) || limitNum <= 0) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive number.' });
      }
      if (limitNum > MAX_LIMIT) {
        return res.status(400).json({ error: `Limit parameter too large. Maximum allowed: ${MAX_LIMIT}.` });
      }
      limit = Math.floor(limitNum);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
