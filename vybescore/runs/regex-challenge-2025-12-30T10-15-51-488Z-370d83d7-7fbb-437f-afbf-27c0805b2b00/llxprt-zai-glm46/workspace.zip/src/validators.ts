export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * - Accepts typical addresses like name+tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores
 * - Rejects other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const noUnderscoreInDomain = /^[^@]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const noConsecutiveDots = /^[^@]*@(?!.*\.\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const noTrailingDotLocal = /^[^@]+(?<!\.)@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const noTrailingDotDomain = /^[^@]+@[a-zA-Z0-9.-]+(?<!\.)\.[a-zA-Z]{2,}$/;

  return (
    emailRegex.test(value) &&
    noUnderscoreInDomain.test(value) &&
    noConsecutiveDots.test(value) &&
    noTrailingDotLocal.test(value) &&
    noTrailingDotDomain.test(value) &&
    !value.includes('..')
  );
}

/**
 * Validate US phone numbers.
 * - Supports (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && !cleaned.startsWith('+')) {
    // If there's a leading 1 but no +, it could be the country code or part of area code
    // Only treat as country code if we have exactly 11 digits
    if (digits.length === 11) {
      digits = digits.substring(1);
    }
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (first digit of central office code) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * - Handles landlines and mobiles
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to get raw digits and any +
  const raw = value.replace(/[\s-]/g, '');
  
  // Match the full pattern
  // +54 9 11 1234 5678 - mobile with country code
  // 011 1234 5678 - BA without country code
  // +54 341 123 4567 - landline with country code
  // 0341 4234567 - landline without country code
  const argPhoneRegex = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
  
  const match = raw.match(argPhoneRegex);
  if (!match) {
    return false;
  }

  const [, countryCode, , areaCode, subscriber] = match;

  // When country code is omitted, the number must begin with 0 (trunk prefix)
  if (!countryCode) {
    // The area code should start with 0 when no country code
    if (areaCode[0] !== '0') {
      return false;
    }
  }

  // Area code must be 2-4 digits, leading digit 1-9 (after trunk prefix if present)
  // If we have a trunk prefix (0), the actual area code is the rest
  const actualAreaCode = areaCode[0] === '0' ? areaCode.substring(1) : areaCode;
  if (actualAreaCode.length < 1 || actualAreaCode.length > 4) {
    return false;
  }
  // Leading digit of actual area code (excluding trunk prefix 0) must be 1-9
  if (actualAreaCode[0] < '1' || actualAreaCode[0] > '9') {
    return false;
  }

  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  // Total length check (excluding country code and optional 9)
  // Area code (with trunk prefix if present) + subscriber should be reasonable
  const localLength = areaCode.length + subscriber.length;
  if (localLength < 8 || localLength > 12) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * - Permits unicode letters, accents, apostrophes, hyphens, spaces
 * - Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), apostrophes, hyphens, spaces
  // At least one character required
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }

  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Check for symbols/numbers by verifying that all characters are valid
  // If the regex above passed, we just need to ensure it's not just spaces/hyphens/apostrophes
  const validCharsRegex = /[\p{L}\p{M}]/u;
  if (!validCharsRegex.test(value)) {
    return false;
  }

  // Reject names with numbers (they wouldn't pass the first regex anyway)
  // But let's be explicit about the Æ type characters - they are valid unicode letters
  // X Æ A-12 would fail because of the 12

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.split('').map((d) => parseInt(d, 10));
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * - Accepts Visa/Mastercard/AmEx prefixes and lengths
 * - Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Check length: Visa/MC are 16 digits, AmEx is 15
  if (cleaned.length !== 15 && cleaned.length !== 16) {
    return false;
  }

  // Check prefixes and lengths
  // Visa: starts with 4, length 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4\d{15}$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{13})$/;
  const amexRegex = /^3[47]\d{13}$/;

  const validPrefix =
    (cleaned.length === 16 && visaRegex.test(cleaned)) ||
    (cleaned.length === 16 && mastercardRegex.test(cleaned)) ||
    (cleaned.length === 15 && amexRegex.test(cleaned));

  if (!validPrefix) {
    return false;
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
