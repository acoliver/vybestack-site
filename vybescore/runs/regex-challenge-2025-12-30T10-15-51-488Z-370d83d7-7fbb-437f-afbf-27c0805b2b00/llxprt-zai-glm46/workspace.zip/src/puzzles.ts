/**
 * Match words starting with the prefix but excluding banned words (exceptions).
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match whole words starting with the prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]+)\\b`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    // Only include if not in exceptions
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token preceded by a digit (lookbehind), but not at string start
  // The pattern (?<=\d) uses a positive lookbehind to ensure the token is after a digit
  // We capture the digit + token combination
  const pattern = new RegExp(`(\\d)${escapedToken}(?!\\d)`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Verify we're not at the start of the string
    if (match.index > 0) {
      // Return the digit + token
      matches.push(match[1] + token);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+=[\]{};':"\\|,.<>/?-]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc, 1212)
  // A repeated sequence is a pattern of 2+ characters that repeats immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + 2 * len);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that excludes IPv4
  // Supports shorthand :: and various IPv6 formats
  
  // First, exclude obvious IPv4 patterns
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }

  // IPv6 pattern:
  // - Can have :: for consecutive zero groups
  // - Groups of 1-4 hex digits separated by :
  // - Can end with IPv4-mapped IPv6 (::ffff:192.168.1.1), but we exclude those above
  // - Full form: 8 groups of 4 hex digits
  // - Compressed form: :: replaces one or more consecutive groups of zeros
  
  // Match IPv6 addresses (including compressed :: forms)
  const ipv6Pattern = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::)(?:$|(?=\s))/;
  
  // Also match simpler IPv6 patterns
  const simpleIpv6Pattern = /[0-9a-fA-F]{1,4}:[0-9a-fA-F:]+/;
  
  // Ensure we're not matching IPv4-mapped IPv6 or IPv4-compatible IPv6
  if (ipv6Pattern.test(value) || simpleIpv6Pattern.test(value)) {
    // Double-check it's actually IPv6 format and not just something that looks similar
    // IPv6 must contain colons and hex digits
    if (value.includes(':') && /[0-9a-fA-F]/.test(value)) {
      return true;
    }
  }

  return false;
}
