/**
 * Capitalize the first character of each sentence.
 * - Insert exactly one space between sentences if input omitted it
 * - Collapse extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence terminators
  // Replace cases where there's no space after . ? or ! with space + the next char
  let result = text;

  // Add space after sentence terminators if missing (but not for abbreviations)
  // Common abbreviations to preserve: Mr., Mrs., Ms., Dr., Prof., Sr., Jr., vs., etc., e.g., i.e.
  const abbrPattern = /\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|etc|e\.g|i\.e|No)\.$/;
  
  // Split by sentence terminators, process, and rejoin
  const sentences: string[] = [];
  let current = '';
  
  for (let i = 0; i < result.length; i++) {
    const char = result[i];
    const nextChar = result[i + 1] || '';
    
    current += char;
    
    if (char === '.' || char === '?' || char === '!') {
      // Check if this might be an abbreviation
      const precedingWord = current.trim().split(/\s+/).pop() || '';
      if (abbrPattern.test(precedingWord)) {
        // Likely an abbreviation, don't treat as sentence end
        if (nextChar && nextChar !== ' ') {
          current += ' ';
        }
        continue;
      }
      
      // This is a sentence end
      sentences.push(current);
      current = '';
      
      // Handle spacing between sentences
      if (nextChar && nextChar !== ' ') {
        sentences.push(' ');
      } else if (nextChar === ' ') {
        // Will be handled by collapsing spaces later
        sentences.push(' ');
      }
    }
  }
  
  if (current) {
    sentences.push(current);
  }
  
  // Join and process
  result = sentences.join('');
  
  // Collapse multiple spaces into single spaces
  result = result.replace(/  +/g, ' ');
  
  // Capitalize first character of text
  result = result.replace(/^./, (c) => c.toUpperCase());
  
  // Capitalize after sentence terminators (that are not abbreviations)
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, prefix, char) => {
    return prefix + char.toUpperCase();
  });
  
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, and www
  // Excludes trailing punctuation: .,?!;: etc.
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,?!;:]/g;
  
  // Also match www. URLs without http/https
  const wwwPattern = /www\.[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,?!;:]/g;
  
  const urls: string[] = [];
  
  let match;
  while ((match = urlPattern.exec(text)) !== null) {
    urls.push(match[0]);
  }
  
  while ((match = wwwPattern.exec(text)) !== null) {
    // Only add if not already captured
    if (!urls.includes(match[0])) {
      urls.push(match[0]);
    }
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, ?, &, =, .jsp, .php, etc.)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s<>"{}|\\^`[\]]*)/g;
  
  const result = text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should skip the host rewrite
    // Skip if path contains dynamic hints
    const skipHostRewrite = /[?&=]|\/cgi-bin\/|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/.test(path);
    
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      return newScheme + 'docs.' + host + path;
    }
    
    // Just upgrade the scheme
    return newScheme + host + path;
  });
  
  // Also handle URLs that might end with punctuation
  // Re-run the pattern to catch trailing punctuation cases
  return result.replace(/(https?:\/\/)(example\.com)(\/[^\s<>"{}|\\^`[\]]*[^\s<>"{}|\\^`[\].,?!;:])/g, (match, scheme, host, path) => {
    const newScheme = 'https://';
    const skipHostRewrite = /[?&=]|\/cgi-bin\/|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/.test(path);
    
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      return newScheme + 'docs.' + host + path;
    }
    
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days in each month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Validate day
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
