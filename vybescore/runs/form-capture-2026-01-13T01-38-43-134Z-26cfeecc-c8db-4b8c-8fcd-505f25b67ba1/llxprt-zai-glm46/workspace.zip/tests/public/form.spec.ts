import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

import { app, initializeDatabase } from '../../src/server.js';

let server: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await initializeDatabase();
  server = app.listen(0);
});

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server && typeof server.close === 'function') {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    await initializeDatabase();

    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email',
      phone: '+54 9 11 1234-5678',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Email must be valid');
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: 'Johnson',
      streetAddress: '789 Pine Rd',
      city: 'Sydney',
      stateProvince: 'NSW',
      postalCode: '2000',
      country: 'Australia',
      email: 'test@example.com',
      phone: '+61 2 9876 5432',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
  });
});
