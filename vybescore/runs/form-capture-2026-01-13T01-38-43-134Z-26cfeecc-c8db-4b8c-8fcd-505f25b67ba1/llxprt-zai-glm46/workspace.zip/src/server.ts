import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT || 3535;
const DB_PATH = path.join('data', 'submissions.sqlite');
const SCHEMA_PATH = path.join('db', 'schema.sql');

let db: Database | null = null;

interface FormBody {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join('public')));

function validateForm(body: FormBody): ValidationResult {
  const errors: string[] = [];
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone,
  } = body;

  if (!firstName || firstName.trim() === '') {
    errors.push('First name is required');
  }

  if (!lastName || lastName.trim() === '') {
    errors.push('Last name is required');
  }

  if (!streetAddress || streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  if (!city || city.trim() === '') {
    errors.push('City is required');
  }

  if (!stateProvince || stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }

  if (!postalCode || postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  }

  if (!country || country.trim() === '') {
    errors.push('Country is required');
  }

  if (!email || email.trim() === '') {
    errors.push('Email is required');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      errors.push('Email must be valid');
    }
  }

  if (!phone || phone.trim() === '') {
    errors.push('Phone number is required');
  } else {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(phone.trim())) {
      errors.push('Phone number must be valid (digits, spaces, parentheses, dashes, and optional leading +)');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<void> {
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let dbBuffer: Uint8Array | undefined = undefined;
  if (fs.existsSync(DB_PATH)) {
    const fileData = fs.readFileSync(DB_PATH);
    dbBuffer = new Uint8Array(fileData);
  }

  const SQL = await initSqlJs();
  db = new SQL.Database(dbBuffer);

  if (!fs.existsSync(DB_PATH)) {
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
})

app.post('/submit', (req: Request, res: Response) => {
  const body = req.body as FormBody;
  const validation = validateForm(body);

  if (!validation.valid) {
    res.status(400);
    return res.render('form', {
      errors: validation.errors,
      values: body,
    });
  }

  if (!db) {
    validation.errors.push('Database not initialized');
    res.status(500);
    return res.render('form', {
      errors: validation.errors,
      values: body,
    });
  }

  try {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        body.firstName!.trim(),
        body.lastName!.trim(),
        body.streetAddress!.trim(),
        body.city!.trim(),
        body.stateProvince!.trim(),
        body.postalCode!.trim(),
        body.country!.trim(),
        body.email!.trim(),
        body.phone!.trim(),
      ]
    );
    saveDatabase();
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    validation.errors.push('Failed to save submission');
    res.status(500);
    return res.render('form', {
      errors: validation.errors,
      values: body,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
})

function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

async function startServer(): Promise<void> {
  await initializeDatabase();

  app.set('views', path.join('src', 'templates'));
  app.set('view engine', 'ejs');

  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  return new Promise<void>((resolve) => {
    server.on('close', resolve);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export { app, shutdown, initializeDatabase, saveDatabase };
