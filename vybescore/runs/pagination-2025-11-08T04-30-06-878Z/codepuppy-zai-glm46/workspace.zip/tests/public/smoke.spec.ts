import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination structure', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page', 1);
    expect(response.body).toHaveProperty('limit', 5);
    expect(response.body).toHaveProperty('total', 15);
    expect(response.body).toHaveProperty('hasNext', true);
  });

  it('handles pagination parameters correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test first page
    const page1 = await request(app).get('/inventory?page=1&limit=3');
    expect(page1.status).toBe(200);
    expect(page1.body.items).toHaveLength(3);
    expect(page1.body.page).toBe(1);
    expect(page1.body.limit).toBe(3);
    expect(page1.body.hasNext).toBe(true);
    
    // Test second page
    const page2 = await request(app).get('/inventory?page=2&limit=3');
    expect(page2.status).toBe(200);
    expect(page2.body.items).toHaveLength(3);
    expect(page2.body.page).toBe(2);
    expect(page2.body.hasNext).toBe(true);
    
    // Test last page with fewer items
    const page5 = await request(app).get('/inventory?page=5&limit=3');
    expect(page5.status).toBe(200);
    expect(page5.body.items).toHaveLength(3);
    expect(page5.body.hasNext).toBe(false);
  });

  it('validates invalid page parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const invalidCases = [
      { param: 'page=0', message: 'page parameter must be greater than 0' },
      { param: 'page=-1', message: 'page parameter must be greater than 0' },
      { param: 'page=abc', message: 'page parameter must be a positive integer' },
      { param: 'page=', message: 'page parameter cannot be empty' },
      { param: 'page=1001', message: 'page parameter cannot exceed 1000' },
    ];
    
    for (const { param, message } of invalidCases) {
      const response = await request(app).get(`/inventory?${param}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe(message);
    }
  });

  it('validates invalid limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const invalidCases = [
      { param: 'limit=0', message: 'limit parameter must be greater than 0' },
      { param: 'limit=-1', message: 'limit parameter must be greater than 0' },
      { param: 'limit=xyz', message: 'limit parameter must be a positive integer' },
      { param: 'limit=', message: 'limit parameter cannot be empty' },
      { param: 'limit=101', message: 'limit parameter cannot exceed 100' },
    ];
    
    for (const { param, message } of invalidCases) {
      const response = await request(app).get(`/inventory?${param}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe(message);
    }
  });

  it('returns correct items for each page', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page
    const page1 = await request(app).get('/inventory?page=1&limit=2');
    expect(page1.status).toBe(200);
    expect(page1.body.items).toHaveLength(2);
    expect(page1.body.items[0].id).toBe(1);
    expect(page1.body.items[1].id).toBe(2);
    
    // Get second page
    const page2 = await request(app).get('/inventory?page=2&limit=2');
    expect(page2.status).toBe(200);
    expect(page2.body.items).toHaveLength(2);
    expect(page2.body.items[0].id).toBe(3);
    expect(page2.body.items[1].id).toBe(4);
  });
});
