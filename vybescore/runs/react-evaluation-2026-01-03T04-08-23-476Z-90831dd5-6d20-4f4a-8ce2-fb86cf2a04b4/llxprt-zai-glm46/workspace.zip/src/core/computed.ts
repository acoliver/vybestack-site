/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  addObserverDependent
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
  }
  
  // Track dependencies by running updateFn with this observer as active
  const prevObserver = getActiveObserver()
  setActiveObserver(o)
  try {
    o.value = updateFn(o.value)
  } finally {
    setActiveObserver(prevObserver)
  }
  
  const getter = (): T => {
    // When the getter is called, check if there's an active observer (e.g., another computed or callback)
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // Register the active observer as a dependent of this computed value
      addObserverDependent(o, activeObserver)
    }
    return o.value!
  }
  
  return getter
}
