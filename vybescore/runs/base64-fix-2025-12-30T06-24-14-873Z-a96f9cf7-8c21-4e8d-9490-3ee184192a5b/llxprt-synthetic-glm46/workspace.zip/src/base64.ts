/**
 * Encode plain text to Base64 using the canonical alphabet.
 * Includes padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Failed to decode Base64 input: empty input');
  }

  // Check if the input contains valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Failed to decode Base64 input: invalid characters');
  }

  // Remove padding for validation
  const unpadded = input.replace(/=+$/, '');
  
  // Check for correct padding placement (at most 2 padding chars and at the end)
  const paddingLength = input.length - unpadded.length;
  if (paddingLength > 2) {
    throw new Error('Failed to decode Base64 input: invalid padding');
  }

  // Check if the input can be validly padded (mod 4)
  const neededPadding = (4 - (unpadded.length % 4)) % 4;
  const paddedInput = unpadded + '='.repeat(neededPadding);
  
  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
