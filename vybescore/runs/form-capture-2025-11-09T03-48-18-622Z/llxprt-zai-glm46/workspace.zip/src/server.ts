import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have TypeScript definitions
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: unknown = null;
  private readonly dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    this.app.get('/', this.renderForm.bind(this));
    this.app.post('/submit', this.handleSubmission.bind(this));
    this.app.get('/thank-you', this.renderThankYou.bind(this));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      let dbData: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        dbData = fs.readFileSync(this.dbPath);
      }
      
      this.db = new SQL.Database(dbData);
      
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      (this.db as { run: (sql: string) => void }).run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = (this.db as { export: () => Uint8Array }).export();
      const dataBuffer = Buffer.from(data);
      
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.dbPath, dataBuffer);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!data.firstName.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!data.lastName.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!data.streetAddress.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!data.city.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!data.stateProvince.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!data.postalCode.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }

    if (!data.country.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!data.email.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!this.isValidEmail(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    if (!data.phone.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!this.isValidPhone(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    return errors;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
  }

  private renderForm(req: Request, res: Response): void {
    const errors = req.query.errors ? JSON.parse(req.query.errors as string) : [];
    const formData = req.query.formData ? JSON.parse(req.query.formData as string) : {};
    
    res.render('form', {
      errors,
      formData,
      title: 'Friendly Contact Form'
    });
  }

  private async handleSubmission(req: Request, res: Response): Promise<void> {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = this.validateForm(formData);

    if (errors.length > 0) {
      const queryParams = new URLSearchParams({
        errors: JSON.stringify(errors),
        formData: JSON.stringify(formData)
      });
      res.redirect(`/?${queryParams.toString()}`);
      return;
    }

    if (!this.db) {
      console.error('Database not initialized');
      res.status(500).send('Internal server error');
      return;
    }

    try {
      const stmt = (this.db as { prepare: (sql: string) => unknown }).prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      (stmt as { run: (params: string[]) => void }).run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      (stmt as { free: () => void }).free();
      this.saveDatabase();

      res.redirect('/thank-you');
    } catch (error) {
      console.error('Failed to save submission:', error);
      res.status(500).send('Internal server error');
    }
  }

  private renderThankYou(req: Request, res: Response): void {
    res.render('thank-you', {
      title: 'Thank You!',
      message: 'Why did you give your info to a stranger on the internet? We\'ll definitely use this responsibly... probably.'
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT || 3000;
    const server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    const gracefulShutdown = (signal: string): void => {
      console.log(`Received ${signal}, shutting down gracefully...`);
      
      if (this.db) {
        this.saveDatabase();
        (this.db as { close: () => void }).close();
      }
      
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }
}

const app = new FormCaptureApp();
app.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});