import { readFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';

interface ParsedArgs {
  filePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    filePath: '',
    format: '',
    includeTotals: false,
  };

  // Skip 'node' and 'script.js'
  const flags = argv.slice(2);

  for (let i = 0; i < flags.length; i++) {
    const flag = flags[i];

    if (!flag.startsWith('--')) {
      if (!args.filePath) {
        args.filePath = flag;
      } else {
        console.error('Error: Unexpected positional argument:', flag);
        process.exit(1);
      }
    } else if (flag === '--format') {
      if (i + 1 >= flags.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      args.format = flags[i + 1];
      i++; // Skip the next flag (the value)
    } else if (flag === '--output') {
      if (i + 1 >= flags.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      args.outputPath = flags[i + 1];
      i++; // Skip the next flag (the value)
    } else if (flag === '--includeTotals') {
      args.includeTotals = true;
    } else {
      console.error(`Error: Unknown flag: ${flag}`);
      process.exit(1);
    }
  }

  if (!args.filePath) {
    console.error('Error: Missing required argument: <data.json>');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing required flag: --format');
    process.exit(1);
  }

  return args;
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];

    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid JSON')) {
        console.error(`Error: ${error.message}`);
      } else if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found: ${filePath}`);
      } else {
        console.error(`Error: Failed to read file: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to parse JSON');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return formatMarkdown(data, options);
    case 'text':
      return formatText(data, options);
    default:
      console.error(`Error: Unsupported format: ${format}`);
      console.error('Supported formats: markdown, text');
      process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = loadReportData(args.filePath);
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const report = renderReport(data, args.format, options);

  if (args.outputPath) {
    try {
      import('fs').then(fs => {
        fs.writeFileSync(args.outputPath!, report, 'utf-8');
      });
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(report);
  }
}

main();