/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to match sentence endings followed by any amount of whitespace
  // and captures the next alphabetic character to capitalize
  const sentencePattern = /([.!?])(\s*)([A-Za-z])/g;
  
  // Replace each sentence ending with the punctuation, single space, and capitalized letter
  let result = normalized.replace(sentencePattern, (match, punct, spaces, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  // Also capitalize the very first letter if it exists and is lowercase
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs - basic http/https URLs
  const urlPattern = /\b(?:https?):\/\/[^\s<>"'{}|\\^`[\]]+/gi;
  
  // Find all matches and clean up trailing punctuation
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation from matches
  return matches.map(url => {
    // Remove trailing punctuation (but keep colons for ports)
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs (but not https://)
  const httpPattern = /http:\/\/[^\s<>"'{}|\\^`[\]]+/gi;
  
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(httpPattern, (match) => {
    return match.replace(/^http:\/\//, 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with paths
  const httpDocsPattern = /http:\/\/([^/\s]+)(\/[^\s<>"'{}|\\^`[\]]*)/gi;
  
  return text.replace(httpDocsPattern, (match, host, path) => {
    // Always upgrade scheme to https
    let newUrl = `https://${host}`;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.<host>
        newUrl = `https://docs.${host}`;
      }
    }
    
    // Preserve the path
    return newUrl + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (reasonable range)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return match[3]; // Return the year part
}
