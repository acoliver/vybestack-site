/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words that start with the prefix
  // \b ensures word boundaries, so we match whole words
  // Need to use double backslash to ensure proper escaping in template literals
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    const cleanWord = word.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === cleanWord
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to match digit followed by token
  // This captures the full digit+token combination
  const digitTokenPattern = new RegExp(`(?<!^)\\d${token}`, 'gi');
  
  // Find all matches
  const matches = text.match(digitTokenPattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have symbol
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for repeating patterns like abab, 1212, etc.
  const repeatingPattern = /(..)\1/;  // Any 2-character sequence repeated
  if (repeatingPattern.test(value)) {
    return false;
  }
  
  // Additional check for 4-character patterns
  const fourCharPattern = /(....)\1/;  // Any 4-character sequence repeated
  if (fourCharPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's clearly an IPv4 address (should NOT be detected as IPv6)
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns - multiple variations to catch different formats
  
  // Pattern for IPv6 with possible shorthand notation (::)
  // This captures the basic structure of IPv6 addresses
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand pattern with :: (multiple groups of zeros)
  const shorthandPattern = /\b(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4}:)?::(?:[0-9a-fA-F]{1,4}:?)*\b/;
  
  // Pattern that catches IPv6 with leading zeros omitted
  const leadingZerosPattern = /\b(?:[0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}\b/;
  
  // More comprehensive IPv6 pattern that includes most valid formats
  const comprehensivePattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{0,4}|(?:[0-9a-fA-F]{0,4}:){0,7}[0-9a-fA-F]{0,4}::\b/;
  
  // Check against all patterns
  if (ipv6Pattern.test(value) || 
      shorthandPattern.test(value) || 
      leadingZerosPattern.test(value) || 
      comprehensivePattern.test(value)) {
    return true;
  }
  
  // Additional check for IPv6-like patterns that might be missed
  // Look for hex characters with colons
  const colonHexPattern = /\b[0-9a-fA-F]*(?::[0-9a-fA-F]*){2,}\b/;
  if (colonHexPattern.test(value) && !/\.\d+\.\d+/.test(value)) {
    return true;
  }
  
  return false;
}
