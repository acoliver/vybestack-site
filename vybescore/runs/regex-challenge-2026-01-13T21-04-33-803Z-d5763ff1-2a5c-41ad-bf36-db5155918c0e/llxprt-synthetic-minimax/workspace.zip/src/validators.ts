export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation pattern
  // Allow letters, numbers, dots, underscores, percent, plus, hyphen
  // Must have @ and a domain with at least 2 characters after the dot
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Additional checks for obviously invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for domain with underscores
  const domainMatch = value.match(/@(.+)$/);
  if (domainMatch && domainMatch[1].includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean { // eslint-disable-line @typescript-eslint/no-unused-vars
  // Remove all non-digit characters for processing
  // Remove all non-digit characters for processing
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for minimum length (10 digits for US numbers)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let normalizedDigits = digitsOnly;
  if (digitsOnly.startsWith('1') && digitsOnly.length === 11) {
    normalizedDigits = digitsOnly.substring(1); // Remove country code
  }
  
  // Must be exactly 10 digits after removing country code
  if (normalizedDigits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = normalizedDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the original format is reasonable
  // Allow formats with parentheses, dashes, dots, or just digits
  const validFormats = [
    /^\(\d{3}\)\s?\d{3}-\d{4}$/,           // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,                // 212-555-7890
    /^\d{3}\.\d{3}\.\d{4}$/,               // 212.555.7890
    /^\d{10}$/,                            // 2125557890
    /^\+1\s?\d{3}\s?\d{3}\s?\d{4}$/,      // +1 212 555 7890
    /^\+1\s?\(\d{3}\)\s?\d{3}-\d{4}$/,    // +1 (212) 555-7890
    /^\+1\d{10}$/                          // +12125557890
  ];
  
  // Check if original value matches any valid format or digits
  const matchesFormat = validFormats.some(pattern => pattern.test(value)) || 
                       digitsOnly.length >= 10;
  
  return matchesFormat;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Extract just the digits to validate structure
  const digits = cleanValue.replace(/[^\d]/g, '');
  
  if (digits.length < 8 || digits.length > 13) {
    return false;
  }
  
  // Pattern to match Argentine phone numbers
  const arPhonePattern = /^(?:\+54)?(?:\s*)?(?:9\s*)?(?:0\s*)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(arPhonePattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode[0] === '0' || areaCode[0] === '') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must start with trunk prefix '0'
  if (!value.startsWith('+54') && !value.trim().startsWith('0')) {
    return false;
  }
  
  // If country code is present, mobile indicator '9' is optional but valid
  // If no country code but '9' is present without '0', it's invalid
  if (!value.startsWith('+54') && value.includes('9') && !value.includes('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least some letters and be non-empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check for digits - names should not contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols that are not allowed (excluding apostrophes, hyphens, spaces)
  // This pattern looks for any character that is not a letter, apostrophe, hyphen, space, or accented character
  const invalidSymbolsPattern = /[^a-zA-ZÀ-ÿ'\s-]/u;
  if (invalidSymbolsPattern.test(value)) {
    return false;
  }
  
  // Check for the specific pattern mentioned "X Æ A-12" style names
  if (/Æ/.test(value)) {
    return false;
  }
  
  // Must have at least some alphabetic characters
  const hasLetters = /[a-zA-ZÀ-ÿ]/.test(value);
  if (!hasLetters) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */

// Helper function to implement Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  // Remove all non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check length - valid credit cards are typically 13-19 digits
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check prefixes for different card types
  const visaPattern = /^4/; // Visa starts with 4
  const mastercardPattern = /^(5[1-5]|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)/; // Mastercard starts with 51-55 or 2221-2720
  const amexPattern = /^(34|37)/; // AmEx starts with 34 or 37
  
  // Must match at least one pattern
  if (!visaPattern.test(cleanValue) && 
      !mastercardPattern.test(cleanValue) && 
      !amexPattern.test(cleanValue)) {
    return false;
  }
  
  // Additional length checks for specific card types
  if (amexPattern.test(cleanValue) && cleanValue.length !== 15) {
    return false;
  }
  
  if (visaPattern.test(cleanValue) && cleanValue.length !== 13 && 
      cleanValue.length !== 16 && cleanValue.length !== 19) {
    return false;
  }
  
  if (mastercardPattern.test(cleanValue) && cleanValue.length !== 16) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
