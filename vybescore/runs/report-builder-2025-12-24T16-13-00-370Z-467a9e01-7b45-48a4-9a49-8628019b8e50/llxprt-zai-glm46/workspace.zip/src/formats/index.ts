import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type ReportFormat = 'markdown' | 'text';

export interface Formatter {
  (data: ReportData, options: RenderOptions): string;
}

/**
 * Registry of available formatters keyed by format name.
 */
export const FORMATTERS: Record<ReportFormat, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Get a formatter by format name.
 * @throws Error if format is not supported
 */
export function getFormatter(format: string): Formatter {
  const formatter = FORMATTERS[format as ReportFormat];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
