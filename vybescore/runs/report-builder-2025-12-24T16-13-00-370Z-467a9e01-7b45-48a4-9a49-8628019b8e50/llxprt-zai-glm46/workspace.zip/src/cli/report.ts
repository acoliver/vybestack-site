#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData } from '../types.js';
import { validateReportData } from '../types.js';
import { getFormatter } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2);

  if (args.length < 1) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function readJsonFile(path: string): ReportData {
  try {
    const content = fs.readFileSync(path, 'utf-8');
    const parsed = JSON.parse(content);
    return validateReportData(parsed);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${path}": ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

function writeOutput(content: string, path: string | null): void {
  if (path) {
    fs.writeFileSync(path, content, 'utf-8');
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = parseArgs(process.argv);

  const data = readJsonFile(args.inputFile);
  const formatter = getFormatter(args.format);
  const output = formatter(data, { includeTotals: args.includeTotals });

  writeOutput(output, args.outputPath);
}

main();
