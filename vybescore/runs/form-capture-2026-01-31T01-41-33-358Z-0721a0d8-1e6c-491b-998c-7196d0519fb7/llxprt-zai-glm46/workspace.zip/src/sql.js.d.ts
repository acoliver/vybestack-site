declare module 'sql.js' {
  export interface SqlValue {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [key: string]: any;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    get(params?: unknown[]): SqlValue | undefined;
    all(params?: unknown[]): SqlValue[];
    free(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface RunResult {
    changes: number;
    lastInsertRowid: number;
  }

  export interface SqlJsConfig {
    locateFile?: (filename: string) => string;
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    SqlJs: (config?: SqlJsConfig) => Promise<any>;
  }

  export default function initSqlJs(config?: SqlJsConfig): Promise<SqlJsStatic>;
}
