import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

// Determine templates directory - works in both src and dist
const TEMPLATES_DIR = path.resolve(process.cwd(), 'src', 'templates');
const PUBLIC_DIR = path.resolve(process.cwd(), 'public');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;
let serverInstance: import('http').Server | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use('/public', express.static(PUBLIC_DIR));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', TEMPLATES_DIR);

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading @
  const phoneRegex = /^@?[0-9\s()--]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters and spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode.trim())) {
    errors.push('Postal code must contain only letters, numbers, and spaces');
  }

  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(data.email.trim())) {
    errors.push('Please enter a valid email address');
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone.trim())) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and may start with @');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const dbBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } else {
    db = new SQL.Database();
    // Run schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName!.trim(),
      formData.lastName!.trim(),
      formData.streetAddress!.trim(),
      formData.city!.trim(),
      formData.stateProvince!.trim(),
      formData.postalCode!.trim(),
      formData.country!.trim(),
      formData.email!.trim(),
      formData.phone!.trim(),
    ]);

    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  // Return existing server if already started
  if (serverInstance) {
    return serverInstance;
  }

  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  serverInstance = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down server...');
    if (serverInstance) {
      serverInstance.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        serverInstance = null;
        console.log('Server closed');
        process.exit(0);
      });
    }
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return serverInstance;
}

// Only start server if this file is run directly
// Check if we're in a test environment or being imported
const isTestRun = process.env.VITEST === 'true' || process.env.NODE_ENV === 'test' || process.env.npm_lifecycle_event?.startsWith('test');
const isDirectRun = import.meta.url === `file://${process.argv[1]}`;

if (isDirectRun && !isTestRun) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { app, startServer };
