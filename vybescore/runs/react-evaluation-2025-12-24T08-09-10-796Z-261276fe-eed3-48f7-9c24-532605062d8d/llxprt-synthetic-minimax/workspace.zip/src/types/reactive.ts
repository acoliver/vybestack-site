/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: Set<SubjectR | ComputedR> // Track which subjects this observer is watching
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

let activeObserver: ObserverR | undefined

// Global registry of all active observers for cleanup
const activeObservers = new Set<ObserverR>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObserver(observer: ObserverR): void {
  if ('updateFn' in observer && typeof observer.updateFn === 'function') {
    // Skip if observer is no longer active (has been unsubscribed)
    if (!activeObservers.has(observer)) {
      return
    }
    
    const computedObserver = observer as Computed<unknown>
    
    // If this is a computed value, re-evaluate it first
    if ('observers' in observer && computedObserver.observers) {
      const oldValue = computedObserver.value
      const previousActiveObserver = getActiveObserver()
      
      // Set this computed as the active observer for dependency tracking
      setActiveObserver(computedObserver)
      try {
        computedObserver.value = computedObserver.updateFn(computedObserver.value)
      } finally {
        setActiveObserver(previousActiveObserver)
      }
      
      // If the value changed, notify all observers of this computed value
      if (computedObserver.value !== oldValue) {
        const computedObserversToNotify = Array.from(computedObserver.observers)
        computedObserversToNotify.forEach(computedObserver => {
          if ('updateFn' in computedObserver && activeObservers.has(computedObserver)) {
            notifyObserver(computedObserver)
          }
        })
      }
    } else {
      // Regular observer notification
      updateObserver(observer as Observer<unknown>)
    }
  }
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Computed values also need to act as subjects
export type ComputedR = {
  name?: string
  observers: Set<ObserverR>
}

export type ComputedV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  previousValue?: T
  hasChanged?: boolean // Track if the value has changed since last notification
  observers?: Set<ObserverR> // Add observers property
}

export type Computed<T> = ComputedR & ComputedV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObserver(observer: ObserverR): void {
  if ('updateFn' in observer && typeof observer.updateFn === 'function') {
    const computedObserver = observer as Computed<unknown>
    
    // If this is a computed value, re-evaluate it first
    if ('observers' in observer && computedObserver.observers) {
      const oldValue = computedObserver.value
      const previousActiveObserver = getActiveObserver()
      
      // Set this computed as the active observer for dependency tracking
      setActiveObserver(computedObserver)
      try {
        computedObserver.value = computedObserver.updateFn(computedObserver.value)
      } finally {
        setActiveObserver(previousActiveObserver)
      }
      
      // If the value changed, notify all observers of this computed value
      if (computedObserver.value !== oldValue) {
        const computedObserversToNotify = Array.from(computedObserver.observers)
        computedObserversToNotify.forEach(computedObserver => {
          if ('updateFn' in computedObserver) {
            notifyObserver(computedObserver)
          }
        })
      }
    } else {
      // Regular observer notification
      updateObserver(observer as Observer<unknown>)
    }
  }
}
