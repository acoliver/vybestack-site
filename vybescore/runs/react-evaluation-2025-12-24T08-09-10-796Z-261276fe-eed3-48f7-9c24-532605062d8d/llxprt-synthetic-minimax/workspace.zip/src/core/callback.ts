/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserver, activeObservers } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set()
  }
  
  // Register this observer as active
  activeObservers.add(observer)
  
  // Execute the callback initially to establish dependencies
  const previousActiveObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    updateObserver(observer)
  } finally {
    setActiveObserver(previousActiveObserver)
  }
  
  let isActive = true

  return () => {
    if (!isActive) return
    isActive = false
    
    // Unregister this observer
    activeObservers.delete(observer)
    
    // Remove this observer from all subjects it's observing
    if (observer.subjects) {
      observer.subjects.forEach(subject => {
        if ('observers' in subject) {
          subject.observers.delete(observer)
        }
      })
      observer.subjects.clear()
    }
    
    // Also need to remove this observer from any computed values that might be observing it
    // This is a more complex cleanup that requires iterating through all potential observers
    // For now, we'll set the observer to be inactive
    observer.value = undefined
    observer.updateFn = () => {
      return value as T
    }
  }
}
