/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  Computed,
  notifyObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const computed: Computed<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    updateFn,
    previousValue: value,
  }
  
  // Create a getter that re-evaluates the computed value
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      computed.observers.add(activeObserver)
      
      // Track which subjects this observer is watching
      if ('subjects' in activeObserver && activeObserver.subjects) {
        activeObserver.subjects.add(computed)
      }
    }
    
    // Re-evaluate the computed value every time it's accessed
    const oldValue = computed.value
    const previousActiveObserver = getActiveObserver()
    
    // Set this computed as the active observer so dependencies can track it
    setActiveObserver(computed)
    try {
      const newValue = updateFn(computed.value)
      computed.value = newValue
    } finally {
      setActiveObserver(previousActiveObserver)
    }
    
    // If the value changed, notify all observers
    if (computed.value !== oldValue) {
      // Create a copy to avoid issues during iteration
      const observersToNotify = Array.from(computed.observers)
      observersToNotify.forEach(observer => {
        if ('updateFn' in observer) {
          notifyObserver(observer)
        }
      })
      computed.previousValue = oldValue
    }
    
    return computed.value!
  }
  
  return getter
}
