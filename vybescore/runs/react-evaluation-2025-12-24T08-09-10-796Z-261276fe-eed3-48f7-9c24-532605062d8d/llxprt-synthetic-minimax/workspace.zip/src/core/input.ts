/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      
      // Track which subjects this observer is watching
      if ('subjects' in observer && observer.subjects) {
        observer.subjects.add(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const previousValue = s.value
    s.value = nextValue
    
    // Always notify observers when the input changes
    if (s.observers.size > 0) {
      // Create a copy to avoid issues if observers modify the set during iteration
      const observersToNotify = Array.from(s.observers)
      observersToNotify.forEach(observer => {
        notifyObserver(observer)
      })
    }
    
    return s.value
  }

  return [read, write]
}
