import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Test 1: compute cells fire callbacks ===')
const [input1, setInput1] = createInput(1)
const output1 = createComputed(() => {
  const val = input1()
  console.log(`Computing output: ${val} + 1 = ${val + 1}`)
  return val + 1
})

let value = 0
console.log('Creating callback...')
const unsubscribe = createCallback(() => {
  const output = output1()
  console.log(`Callback firing: value = ${output}`)
  value = output
})

console.log(`After callback creation: value = ${value}`)
console.log('Setting input to 3...')
setInput1(3)
console.log(`After setInput: value = ${value}`)
console.log('Expected: value = 4')

console.log('\n=== Test 2: callbacks can be added and removed ===')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => {
  const val = input2()
  console.log(`Computing output2: ${val} + 1 = ${val + 1}`)
  return val + 1
})

const values1 = []
const values2 = []

console.log('Creating first callback...')
const unsubscribe1 = createCallback(() => {
  const output = output2()
  console.log(`Callback 1 firing: ${output}`)
  values1.push(output)
})

console.log('Creating second callback...')
createCallback(() => {
  const output = output2()
  console.log(`Callback 2 firing: ${output}`)
  values2.push(output)
})

console.log(`Initial values1: ${values1.length}, values2: ${values2.length}`)
console.log('Setting input to 31...')
setInput2(31)
console.log(`After setInput to 31: values1=${values1.length}, values2=${values2.length}`)

console.log('Unsubscribing callback 1...')
unsubscribe1()
console.log('Setting input to 41...')
setInput2(41)
console.log(`Final: values1=${values1.length}, values2=${values2.length}`)
console.log('Expected: values1 > 0, values2 > values1')