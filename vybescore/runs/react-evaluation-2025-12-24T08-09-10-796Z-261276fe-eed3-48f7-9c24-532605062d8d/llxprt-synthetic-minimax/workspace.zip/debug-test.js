
const { createInput, createComputed, createCallback } = require('./src/index.ts');

console.log('=== Manual Test with Logging ===');
const [input, setInput] = createInput(1);
console.log('Input created with value:', input());

const output = createComputed(() => {
  const result = input() + 1;
  console.log('Computed function called: input() =', input(), 'result =', result);
  return result;
});
console.log('Computed created, initial value:', output());

let value = 0;
console.log('Setting up callback...');
const unsubscribe = createCallback(() => {
  console.log('Callback executing, reading output...');
  value = output();
  console.log('Callback set value to:', value);
});

console.log('Initial value after callback setup:', value);
console.log('Setting input to 3...');
setInput(3);
console.log('After setInput, input() =', input());
console.log('After setInput, output() =', output());
console.log('After setInput, value =', value);
console.log('Unsubscribing...');
unsubscribe();
console.log('Setting input to 5...');
setInput(5);
console.log('Final state: input() =', input(), 'output() =', output(), 'value =', value);
