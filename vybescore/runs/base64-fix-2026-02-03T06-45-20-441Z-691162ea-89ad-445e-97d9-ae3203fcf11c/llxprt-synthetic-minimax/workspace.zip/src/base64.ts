/**
 * Encode plain text to Base64 using standard alphabet and padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Remove whitespace that could be part of invalid input
  const cleaned = input.replace(/\s+/g, '');

  // Validate that input contains only valid Base64 characters
  if (cleaned && !/^[A-Za-z0-9+/=]*$/.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains non-base64 characters');
  }

  try {
    const decoded = Buffer.from(cleaned, 'base64').toString('utf8');
    // If we got empty string and input wasn't empty, something went wrong
    if (!decoded && cleaned) {
      throw new Error('Invalid Base64 input');
    }
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
