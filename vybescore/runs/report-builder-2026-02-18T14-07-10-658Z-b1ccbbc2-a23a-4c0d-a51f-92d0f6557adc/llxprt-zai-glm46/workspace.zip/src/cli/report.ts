#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { getFormatter } from '../formatters.js';
import { validateReportData } from '../utils.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  const formatArgIndex = args.indexOf('--format');
  if (formatArgIndex === -1 || formatArgIndex + 1 >= args.length) {
    throw new Error('Missing required argument: --format <format>');
  }

  const format = args[formatArgIndex + 1];
  const outputArgIndex = args.indexOf('--output');
  const outputPath = outputArgIndex !== -1 && outputArgIndex + 1 < args.length ? args[outputArgIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const inputPath = path.resolve(args.inputFile);
    let inputData: string;

    try {
      inputData = fs.readFileSync(inputPath, 'utf-8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        throw new Error(`Input file not found: ${args.inputFile}`);
      }
      throw error;
    }

    let parsedData: unknown;
    try {
      parsedData = JSON.parse(inputData);
    } catch (error) {
      throw new Error(`Invalid JSON in input file: ${(error as Error).message}`);
    }

    const reportData = validateReportData(parsedData);
    const formatter = getFormatter(args.format);
    const options: RenderOptions = { includeTotals: args.includeTotals };

    const output = formatter(reportData, options);

    if (args.outputPath) {
      const outputPath = path.resolve(args.outputPath);
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
