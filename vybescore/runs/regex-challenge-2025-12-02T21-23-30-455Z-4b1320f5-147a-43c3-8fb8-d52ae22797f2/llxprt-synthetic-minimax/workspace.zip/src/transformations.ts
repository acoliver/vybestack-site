/**
 * Capitalizes the first character of each sentence and handles spacing
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences by finding .?! followed by whitespace or end of string
  // Use regex to identify sentence boundaries
  const sentences = text.match(/[^.!?]*[.!?]?(\s+|$)/g) || [text];
  
  return sentences
    .map(sentence => {
      const trimmed = sentence.trim();
      if (!trimmed) return sentence;
      
      // Capitalize first letter and ensure single space after sentence endings
      const firstChar = trimmed.charAt(0).toUpperCase();
      const rest = trimmed.slice(1);
      
      // Preserve original spacing but ensure one space after sentence
      const words = (firstChar + rest).split(/\s+/);
      return words.join(' ') + ' ';
    })
    .join('')
    .trim();
}

/**
 * Extracts all URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Find URLs and remove trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"')]+/gi;
  const matches = text.match(urlPattern) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation that might be part of sentence
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * Replaces http:// with https:// while leaving existing https:// untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites documentation URLs by upgrading scheme and changing host for /docs/ paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/example\.com(\/docs\/[^\s<>"')]*)/gi, (match, path) => {
    // Always upgrade to https
    let result = 'https://docs.example.com' + path;
    
    // Check for dynamic hints in the path
    const dynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    if (dynamicHints) {
      // Skip host rewrite, just upgrade scheme
      result = 'https://example.com' + path;
    }
    
    return result;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern with valid month/day ranges
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}