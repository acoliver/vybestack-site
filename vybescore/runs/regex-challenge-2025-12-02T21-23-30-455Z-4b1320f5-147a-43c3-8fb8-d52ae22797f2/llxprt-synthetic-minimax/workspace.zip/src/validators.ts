/**
 * Validates email addresses using regex patterns
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern that rejects double dots, trailing dots, domains with underscores
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  return emailPattern.test(value);
}

/**
 * Validates US phone numbers with various formats
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Must start with +1 or just the 10 digits
  if (cleanValue.startsWith('+1')) {
    // +1 followed by 10 digits
    const phonePattern = /^\+1[2-9]\d{9}$/;
    return phonePattern.test(cleanValue);
  } else {
    // Just 10 digits, area code can't start with 0 or 1
    const phonePattern = /^[2-9]\d{9}$/;
    return phonePattern.test(cleanValue);
  }
}

/**
 * Validates Argentine phone numbers
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleanDigits = value.replace(/\D/g, '');
  
  // Handle the format step by step
  // Check for +54 prefix
  let remainingDigits = cleanDigits;
  let hasCountryCode = false;
  
  if (remainingDigits.startsWith('54')) {
    remainingDigits = remainingDigits.slice(2);
    hasCountryCode = true;
  }
  
  // Check for optional 9 (mobile indicator)
  if (remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.slice(1);
  }
  
  // At this point, we should have area code + subscriber number
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: remaining digits (6-8 total after area code)
  
  if (remainingDigits.length < 8 || remainingDigits.length > 12) {
    return false;
  }
  
  // Try different area code lengths
  for (let areaCodeLength = 4; areaCodeLength >= 2; areaCodeLength--) {
    if (remainingDigits.length >= areaCodeLength + 6) {
      const areaCode = remainingDigits.slice(0, areaCodeLength);
      const subscriber = remainingDigits.slice(areaCodeLength);
      
      // Area code must start with 1-9
      if (/^[1-9]/.test(areaCode) && subscriber.length >= 6 && subscriber.length <= 8) {
        // Additional validation: when no country code, must have started with 0
        if (!hasCountryCode) {
          // Check if original had trunk prefix 0
          const originalCleaned = cleanDigits;
          return originalCleaned.startsWith('0');
        }
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Validates names allowing unicode letters, accents, apostrophes, hyphens, spaces
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  return namePattern.test(value) && value.trim().length > 0;
}

/**
 * Helper function for Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using Luhn algorithm
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check length and format for major card types
  const cardPatterns = [
    // Visa: 13 or 19 digits starting with 4
    /^4\d{12}(\d{3})?(\d{3})?$/,
    // MasterCard: 16 digits starting with 5[1-5]
    /^5[1-5]\d{14}$/,
    // American Express: 15 digits starting with 3[47]
    /^3[47]\d{13}$/
  ];
  
  // Check if it matches any card pattern
  const isValidFormat = cardPatterns.some(pattern => pattern.test(cleanNumber));
  
  // Run Luhn checksum if format is valid
  return isValidFormat && runLuhnCheck(cleanNumber);
}