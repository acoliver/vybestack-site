/**
 * Finds words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[] = []): string[] {
  // Create a word boundary regex for the prefix
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*`, 'gi');
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => 
    !exceptions.some(exception => 
      match.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use positive lookbehind to ensure the token comes after a digit
  // Use negative lookbehind to ensure it's not at the start of the string
  // Find the digit and token together, then extract both
  const result: string[] = [];
  const pattern = new RegExp(`(?<!^)(?<=\\d)(${token})`, 'gi');
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const index = match.index;
    if (index > 0) {
      const charBefore = text.charAt(index - 1);
      if (/\d/.test(charBefore)) {
        result.push(charBefore + match[0]);
      }
    }
  }
  
  return result;
}

/**
 * Validates strong password requirements
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/\d/.test(value)) return false;
  
  // Check for symbol
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab should fail)
  // This checks for any sequence of 2+ characters that repeats immediately
  const repeatingPattern = /(.{2,})\1/;
  if (repeatingPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation, ensuring IPv4 doesn't match
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (simplified but comprehensive)
  const ipv6Patterns = [
    // Full IPv6 format (8 groups of 4 hex digits)
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with :: shorthand (at least one group of ::
    /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/,
    // IPv6 with leading :: 
    /::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with trailing ::
    /\b[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:){0,5}::\b/,
    // Mixed IPv4-IPv6 (IPv4 at the end)
    /\b(?:[0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}\b/,
    // ::1 (loopback)
    /\b::1\b/,
    // :: (any address)
    /\b::\b/,
    // Compressed format with :: in middle
    /\b[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,3}[0-9a-fA-F]{1,4}\b/
  ];
  
  // First check if it looks like IPv4 - if so, exclude it
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check if any IPv6 pattern matches
  return ipv6Patterns.some(pattern => pattern.test(value));
}