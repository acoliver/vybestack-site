/**
 * Finds words beginning with the specified prefix but excluding the listed exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Word boundary pattern to find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredWords = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  return [...new Set(filteredWords)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds to find embedded tokens.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Look for pattern: digit followed by token (including the digit in result)
  // This finds matches like "1foo" but not "foo" at start
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const allMatches = text.match(pattern) || [];
  // Filter out matches that might be at the start of the string
  const results = allMatches.filter(match => {
    const index = text.indexOf(match);
    return index > 0; // Not at start of string
  });
  
  return [...new Set(results)];
}

/**
 * Validates passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc)
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // Check for immediate repeated characters (like aaa, bbb)
  const repeatedCharRegex = /(.)\1\1+/;
  if (repeatedCharRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 * Returns true if IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches standard IPv6 formats and shorthand
  // This pattern excludes IPv4 addresses
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|::|:(?::[0-9a-fA-F]{1,4}){1,7}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,7}|[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|::ffff:(?::[0-9a-fA-F]{1,4}){1,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}|(?:[0-9a-fA-F]{1,4}:){1,6}:(?::[0-9a-fA-F]{1,4}){1,6}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}|[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}){0,5}|[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}|::ffff:\d{1,3}(?:\.\d{1,3}){3}/;
  
  // First, remove any IPv4-like patterns to avoid false positives
  const withoutIPv4 = value.replace(/\b\d{1,3}(?:\.\d{1,3}){3}\b/g, '');
  
  // Then check for IPv6 patterns
  return ipv6Regex.test(withoutIPv4);
}