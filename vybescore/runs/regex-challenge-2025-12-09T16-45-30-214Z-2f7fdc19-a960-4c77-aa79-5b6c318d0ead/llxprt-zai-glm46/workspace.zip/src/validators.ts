export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots in local part
  if (value.substring(0, value.indexOf('@')).includes('..')) return false;
  
  // Reject domains with underscores
  if (value.includes('@') && value.substring(value.indexOf('@')).includes('_')) return false;
  
  // Reject trailing dot in domain
  if (value.endsWith('.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 country code
  let phoneNumber = cleanValue;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Phone number should be exactly 10 digits after cleaning
  if (phoneNumber.length !== 10) return false;
  
  // Check area code - first digit cannot be 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate the full 10-digit format with common separators
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers supporting mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Regex pattern to validate Argentine phone number structure
  const argentinePhoneRegex = /^(?:\+54)?(?:0|9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits and start with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) return false;
  
  // More comprehensive validation for common formats
  const formatRegex = /^(?:\+54\s?(?:9\s?)?)?(?:0?[1-9]\d{1,3})\s?\d{3,4}\s?\d{4}$/;
  return formatRegex.test(value.trim());
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid name patterns like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Name should not be empty or just whitespace
  if (!value || value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'-]+(?:\s[\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value.trim())) return false;
  
  // Reject names that look like codes (contain multiple consecutive symbols or numbers)
  if (/\d/.test(value)) return false;
  if (/[^ \p{L}\p{M}'-]/u.test(value)) return false;
  
  // Reject names with excessive consecutive symbols
  if (/(?:'{2,}|-{2,}|(?:['-]){3,})/.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using Luhn algorithm.
 * Accepts common prefixes and lengths for major card types.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check if the cleaned value contains only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Validate card format for major card types
  const cardPatterns = {
    visa: /^4\d{12}(?:\d{3})?$/, // 13 or 16 digits
    mastercard: /^5[1-5]\d{14}$/, // 16 digits
    amex: /^3[47]\d{13}$/, // 15 digits
    discover: /^6(?:011|5\d{2})\d{12}$/, // 16 digits
  };
  
  // Check if any card pattern matches
  const isValidFormat = Object.values(cardPatterns).some(pattern => pattern.test(cleanValue));
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}