/**
 * Capitalizes the first character of each sentence in the text.
 * Handles sentence boundaries after . ? ! and ensures proper spacing.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences using regex that looks for . ? ! followed by optional quotes and whitespace
  const sentences = text.split(/([.!?])(?:\s*|$)/);
  
  let result = '';
  let isStartOfSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    let part = sentences[i];
    
    // Check if this is a sentence terminator (., ?, !)
    const isTerminator = part.match(/^[.!?]$/);
    
    if (isTerminator) {
      result += part;
      // Add exactly one space after terminator if not the last part
      if (i < sentences.length - 1 && sentences[i + 1].trim()) {
        result += ' ';
      }
      isStartOfSentence = true;
    } else {
      // Skip empty parts
      if (!part.trim()) {
        continue;
      }
      
      // Capitalize first character if at start of sentence
      if (isStartOfSentence && part.length > 0) {
        part = part.charAt(0).toUpperCase() + part.slice(1);
        isStartOfSentence = false;
      }
      
      result += part;
    }
  }
  
  // Clean up extra spaces
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http/https protocols and common URL structures
  const urlRegex = /\bhttps?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,;:!?)\]]+$/, '');
  });
  
  return cleanUrls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// scheme with https:// in URLs.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but avoid replacing https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... to https://..., with special handling for docs paths.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs and capture components
  const urlRegex = /\bhttp:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, hostname, path) => {
    // Check for dynamic content that should skip host rewrite
    const skipHostRewrite = path.search(/\/cgi-bin\/|[?.=&]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/) !== -1;
    
    // Always upgrade to https
    let newUrl = `https://${hostname}${path}`;
    
    // If path starts with /docs/ and not dynamic content, rewrite hostname
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Simple approach: use the entire hostname as base domain
      newUrl = `https://docs.${hostname}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simple rule)
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  
  if (monthNum === 2 && isLeapYear) {
    if (dayNum > 29) return 'N/A';
  } else if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
