/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmed = input.trim();
  
  // Validate Base64 format
  validateBase64Format(trimmed);
  
  try {
    return decodeAndValidate(trimmed);
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validates the format of a Base64 string.
 */
function validateBase64Format(input: string): void {
  // Valid Base64 contains only A-Z, a-z, 0-9, +, /, and = (only at the end)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check if padding is only at the end and correctly formatted
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingStart = input.indexOf('=');
    if (paddingStart !== -1 && paddingStart < input.length - paddingMatch[0].length) {
      throw new Error('Invalid Base64 input: padding in the middle');
    }
    // Base64 can only have 0, 1, or 2 padding characters
    if (paddingMatch[0].length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }
}

/**
 * Decodes a Base64 string and validates it by re-encoding.
 */
function decodeAndValidate(input: string): string {
  const buffer = Buffer.from(input, 'base64');
  const reencoded = buffer.toString('base64');
  
  // Normalize for comparison (add padding if missing)
  let normalizedInput = input;
  while (normalizedInput.length % 4 !== 0) {
    normalizedInput += '=';
  }
  
  // If re-encoding doesn't match (after normalization), the input was invalid
  if (reencoded !== normalizedInput) {
    throw new Error('Invalid Base64 input: malformed data');
  }
  
  return buffer.toString('utf8');
}
