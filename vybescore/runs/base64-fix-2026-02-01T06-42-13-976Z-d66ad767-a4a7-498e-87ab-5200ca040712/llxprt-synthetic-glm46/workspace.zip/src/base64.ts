

/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input is valid Base64 and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check that padding is correct (at the end and only 0-2 characters)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.substring(paddingIndex);
    if (padding.length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    
    // Verify that padding only appears at the end
    const beforePadding = input.substring(0, paddingIndex);
    if (beforePadding.includes('=')) {
      throw new Error('Invalid Base64 input: padding in middle of string');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
