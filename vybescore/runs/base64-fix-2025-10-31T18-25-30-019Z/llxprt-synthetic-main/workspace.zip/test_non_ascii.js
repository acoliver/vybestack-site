import { encode, decode } from './src/base64.js';

// Test non-ASCII characters (Unicode)
const unicodeText = "Hello, 世界! ";
const encoded = encode(unicodeText);
const decoded = decode(encoded);

console.log("Original:", unicodeText);
console.log("Encoded:", encoded);
console.log("Decoded:", decoded);
console.log("Match:", unicodeText === decoded);