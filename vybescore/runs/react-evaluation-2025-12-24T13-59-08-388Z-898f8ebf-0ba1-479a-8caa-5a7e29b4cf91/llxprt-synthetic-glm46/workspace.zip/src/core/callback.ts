/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Track all active callback observers to enable proper cleanup
const activeCallbackObservers = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Store the original update function
  const originalUpdateFn = updateFn
  
  // Create a wrapper that tracks the callback's disposal state
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      if (disposed) {
        return value as T
      }
      
      // Execute the original function to get new value
      const newValue = originalUpdateFn(currentValue)
      observer.value = newValue
      return newValue
    },
  }
  
  // Create unsubscribe function
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all its dependencies
    if (observer.dependencies) {
      for (const subject of observer.dependencies) {
        if (subject.observers) {
          subject.observers.delete(observer)
        }
      }
    }
    
    // Remove from global tracking set
    activeCallbackObservers.delete(observer)
  }
  
  // Add to global tracking set
  activeCallbackObservers.add(observer)
  
  // Register observer to track dependencies by executing it initially
  updateObserver(observer)
  
  return unsubscribe
}
