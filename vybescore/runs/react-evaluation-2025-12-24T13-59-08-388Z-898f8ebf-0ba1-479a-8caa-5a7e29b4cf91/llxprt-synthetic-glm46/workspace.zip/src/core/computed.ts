/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  Subject,
  EqualFn,
  setGlobalNotificationEnabled
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store initial value for reference
  const initialValue = value
  
  const o: Observer<T> = {
    name: options?.name,
    value: initialValue,
    updateFn,
  }

  // Store as a subject so other observers can depend on it
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value: initialValue!,
    equalFn: undefined
  }

  // Calculate the initial value if not provided
  if (initialValue === undefined) {
    // Register dependencies for this computed value by running updateObserver
    updateObserver(o)
    subject.value = o.value!
  }

  // Override updateFn to update subject value and notify observers
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue) => {
    // Disable global notifications while we recompute
    const wasEnabled = true
    setGlobalNotificationEnabled(false)
    
    try {
      const newValue = originalUpdateFn(prevValue)
      o.value = newValue
      subject.value = newValue
      return newValue
    } finally {
      // Re-enable notifications
      setGlobalNotificationEnabled(wasEnabled)
      
      // Now notify our observers with the new value
      if (subject.observers && subject.observers.size > 0) {
        const observers = Array.from(subject.observers)
        observers.forEach(observer => {
          updateObserver(observer)
        })
      }
    }
  }

  // Connect the observer to the subject for notifications
  // This allows the computed value to notify its observers when it updates
  o.observers = subject.observers

  // Create a getter function that tracks dependencies
  const getter = (): T => {
    const active = getActiveObserver()
    if (active && active !== o) {
      // This computed value is being accessed by another observer,
      // track the dependency
      if (!active.dependencies) {
        active.dependencies = new Set()
      }
      active.dependencies.add(subject)

      // Register that observer as a subscriber to this computed value
      if (!subject.observers) {
        subject.observers = new Set()
      }
      subject.observers.add(active as any)
    }

    return o.value!
  }

  return getter
}
