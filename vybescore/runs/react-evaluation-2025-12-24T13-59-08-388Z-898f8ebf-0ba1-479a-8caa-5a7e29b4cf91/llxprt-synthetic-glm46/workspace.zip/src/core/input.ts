/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track this dependency
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(s)
      
      // Add this observer as a subscriber to the subject
      s.observers.add(observer as any)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check for equality if equalFn is provided
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers that this subject has changed
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}
