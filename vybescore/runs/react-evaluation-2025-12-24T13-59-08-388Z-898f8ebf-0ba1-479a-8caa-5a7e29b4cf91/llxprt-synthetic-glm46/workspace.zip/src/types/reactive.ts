/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<Subject<any>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observers?: Set<Observer<any>>
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & {
  observers?: Set<Observer<any>>
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

let globalNotificationEnabled = true

export function setGlobalNotificationEnabled(enabled: boolean): void {
  globalNotificationEnabled = enabled
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Store current dependencies to clean up later
    const previousDependencies = observer.dependencies || new Set()
    
    // Clear previous dependencies before re-evaluating
    observer.dependencies = new Set()
    
    // Execute the updateFn to get the new value
    observer.value = observer.updateFn(observer.value)
    
    // For each subject newly accessed during evaluation, register this observer
    // to receive notifications when those subjects change
    if (observer.dependencies) {
      for (const subject of observer.dependencies) {
        // This observer depends on this subject
        if (!subject.observers) {
          subject.observers = new Set()
        }
        
        // Don't add if already there to avoid duplicates
        if (!subject.observers.has(observer)) {
          subject.observers.add(observer as Observer<any>)
        }
      }
    }
    
    // Clean up dependencies we no longer have
    for (const subject of previousDependencies) {
      if (!observer.dependencies.has(subject)) {
        if (subject.observers) {
          subject.observers.delete(observer)
        }
      }
    }
    
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!globalNotificationEnabled) {
    return
  }
  
  if (subject.observers) {
    // Create a copy of the observers to avoid issues with modifying the Set during iteration
    const observers = Array.from(subject.observers)
    
    // For each observer, trigger re-evaluation
    observers.forEach(observer => {
      // For callbacks and computed values, trigger their update
      updateObserver(observer)
    })
  }
}
