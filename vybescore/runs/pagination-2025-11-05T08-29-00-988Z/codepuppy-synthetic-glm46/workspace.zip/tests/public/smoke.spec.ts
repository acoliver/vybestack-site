import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('limit');
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
    
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // default limit
    expect(response.body.total).toBe(15); // total items in seed data
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items.length).toBe(5);
  });

  it('paginates correctly with page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page
    const page1 = await request(app).get('/inventory?page=1');
    expect(page1.status).toBe(200);
    expect(page1.body.items.length).toBe(5);
    expect(page1.body.page).toBe(1);
    
    // Get second page
    const page2 = await request(app).get('/inventory?page=2');
    expect(page2.status).toBe(200);
    expect(page2.body.items.length).toBe(5);
    expect(page2.body.page).toBe(2);
    
    // Ensure different items on each page
    const page1Ids = page1.body.items.map((item: { id: number }) => item.id);
    const page2Ids = page2.body.items.map((item: { id: number }) => item.id);
    expect(page1Ids).not.toEqual(page2Ids);
  });

  it('handles custom limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(3);
    expect(response.body.limit).toBe(3);
    expect(response.body.hasNext).toBe(true);
  });

  it('validates page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test non-numeric page
    const res1 = await request(app).get('/inventory?page=abc');
    expect(res1.status).toBe(400);
    expect(res1.body.error).toContain('Page must be a positive integer');
    
    // Test negative page
    const res2 = await request(app).get('/inventory?page=-1');
    expect(res2.status).toBe(400);
    expect(res2.body.error).toContain('Page must be a positive integer');
    
    // Test zero page
    const res3 = await request(app).get('/inventory?page=0');
    expect(res3.status).toBe(400);
    expect(res3.body.error).toContain('Page must be a positive integer');
  });

  it('validates limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test non-numeric limit
    const res1 = await request(app).get('/inventory?limit=abc');
    expect(res1.status).toBe(400);
    expect(res1.body.error).toContain('Limit must be a positive integer <= 100');
    
    // Test negative limit
    const res2 = await request(app).get('/inventory?limit=-1');
    expect(res2.status).toBe(400);
    expect(res2.body.error).toContain('Limit must be a positive integer <= 100');
    
    // Test zero limit
    const res3 = await request(app).get('/inventory?limit=0');
    expect(res3.status).toBe(400);
    expect(res3.body.error).toContain('Limit must be a positive integer <= 100');
    
    // Test excessive limit
    const res4 = await request(app).get('/inventory?limit=101');
    expect(res4.status).toBe(400);
    expect(res4.body.error).toContain('Limit must be a positive integer <= 100');
  });

  it('handles last page correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get last page (3 pages with limit=5, total=15)
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.hasNext).toBe(false);
  });
});
