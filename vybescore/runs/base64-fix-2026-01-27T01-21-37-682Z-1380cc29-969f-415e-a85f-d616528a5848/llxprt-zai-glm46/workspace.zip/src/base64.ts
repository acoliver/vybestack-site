/**
 * Encode plain text to Base64 using the standard Base64 alphabet
 * (A-Z, a-z, 0-9, +, /) with padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with or without padding.
 * Throws an error if the input is not valid Base64.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  if (trimmed.length === 0) {
    throw new Error('Base64 input cannot be empty');
  }

  // Check for invalid Base64 characters (standard alphabet only)
  // Valid: A-Z, a-z, 0-9, +, /, and = for padding
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside standard Base64 alphabet');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // If the resulting buffer is empty and input wasn't just padding, it's likely invalid
    if (buffer.length === 0 && !/^=+$/.test(trimmed)) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
