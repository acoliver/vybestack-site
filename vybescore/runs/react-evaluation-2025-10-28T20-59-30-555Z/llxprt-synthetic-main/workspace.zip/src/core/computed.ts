/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Default equality function
  const defaultEqualFn: EqualFn<T> = (a, b) => {
    if (typeof a === 'object' && a !== null && typeof b === 'object' && b !== null) {
      return JSON.stringify(a) === JSON.stringify(b)
    }
    return a === b
  }

  // Set up the equality function based on the parameter
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = defaultEqualFn
  } else if (equal === false) {
    equalFn = undefined // Always notify
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = defaultEqualFn // Default to strict equality
  }

  let currentValue = value

  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue)
      
      // Check if value has changed based on equality function
      const hasChanged = !equalFn ? true : !equalFn(currentValue as T, newValue)
      
      if (hasChanged) {
        currentValue = newValue
        o.value = currentValue
      }
      
      return currentValue as T
    },
  }
  
  // Execute initial computation
  updateObserver(o)
  
  const getter = (): T => {
    // Always track dependencies when called from an observer
    if (getActiveObserver()) {
      updateObserver(o)
    }
    
    return o.value as T
  }
  
  return getter
}