/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Default equality function
  const defaultEqualFn: EqualFn<T> = (a, b) => {
    if (typeof a === 'object' && a !== null && typeof b === 'object' && b !== null) {
      return JSON.stringify(a) === JSON.stringify(b)
    }
    return a === b
  }

  // Set up the equality function based on the parameter
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = defaultEqualFn
  } else if (equal === false) {
    equalFn = undefined // Always notify
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = defaultEqualFn // Default to strict equality
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer as Observer<T>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has changed based on equality function
    const hasChanged = !equalFn ? true : !equalFn(s.value, nextValue)
    
    if (hasChanged) {
      s.value = nextValue
      // Force update of all observers
      if (s.observers) {
        const observers = Array.from(s.observers)
        observers.forEach(observer => {
          updateObserver(observer as any, true)
        })
      }
    }
    
    return s.value
  }

  return [read, write]
}