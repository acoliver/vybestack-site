/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Subject<unknown>[]
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: Set<any>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let computingObserver: Observer<any> | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>, forceUpdate: boolean = false): void {
  // Don't update if we're already computing this observer (unless forced)
  if (computingObserver === observer && !forceUpdate) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  computingObserver = observer
  
  // Clear previous dependencies
  if (!observer.dependencies) {
    observer.dependencies = []
  } else {
    // Remove this observer from all previous dependencies
    observer.dependencies.forEach(dep => {
      if (dep.observers) {
        dep.observers.delete(observer)
      }
    })
    observer.dependencies = []
  }
  
  try {
    // Always recompute when updateObserver is called
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    computingObserver = undefined
  }
}

export function addObserver<T>(subject: Subject<T>, observer: Observer<T>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer as any)
  
  // Track this dependency on the observer
  if (!observer.dependencies) {
    observer.dependencies = []
  }
  observer.dependencies.push(subject as any)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  // Create a copy of observers to avoid issues with modifications during iteration
  const observers = Array.from(subject.observers)
  observers.forEach(observer => {
    updateObserver(observer as any, true)
  })
}