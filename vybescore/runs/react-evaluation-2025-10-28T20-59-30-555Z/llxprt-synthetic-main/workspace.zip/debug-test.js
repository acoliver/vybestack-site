// Simple debug test to understand the flow
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Debugging Reactive System ===')

// Test 1: Basic compute dependency
console.log('\nTest 1: Basic compute dependency')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('  - timesTwo recomputing, input() =', input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('  - timesThirty recomputing, input() =', input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('  - sum recomputing, timesTwo() =', timesTwo(), ', timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('  Initial sum():', sum())
console.log('  Setting input to 3...')
setInput(3)
console.log('  After setInput(3), sum():', sum())

// Test 2: Callbacks
console.log('\nTest 2: Callbacks')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => {
  console.log('  - output recomputing, input2() =', input2())
  return input2() + 1
})

let value = 0
createCallback(() => {
  console.log('  - callback executing, output() =', output())
  value = output()
})

console.log('  Initial value:', value)
console.log('  Setting input2 to 3...')
setInput2(3)
console.log('  After setInput2(3), value:', value)