#!/usr/bin/env node

import { readFileSync } from 'fs';
import { writeFileSync } from 'fs';
import type { ReportData, RenderOptions } from '../types.js';
import { FORMATTERS } from '../formats/index.js';

function parseArguments(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateAndParseData(dataPath: string): ReportData {
  try {
    const fileContent = readFileSync(dataPath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing "title" field in JSON data');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing "summary" field in JSON data');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing "entries" field in JSON data');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label" field');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid "amount" field');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON file: ${error.message}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const { dataPath, format, outputPath, includeTotals } = parseArguments();
  
  if (!FORMATTERS[format]) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  const data = validateAndParseData(dataPath);
  const options: RenderOptions = { includeTotals };
  
  const formatter = FORMATTERS[format];
  const output = formatter(data, options);
  
  if (outputPath) {
    try {
      writeFileSync(outputPath, output, 'utf8');
    } catch (error) {
      console.error(`Error writing to file: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
