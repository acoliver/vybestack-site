import type { RenderFunction } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const FORMATTERS: Record<string, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};