export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Accept typical addresses such as name+tag @example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@..')) {
    return false;
  }
  
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  if (domain.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* options?: PhoneValidationOptions */ _options?: PhoneValidationOptions): boolean {
  // Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Mark parameter as intentionally unused to avoid lint warnings
  void _options;
  
const cleanValue = value.replace(/[\s\-()+.]/g, '');
  
  // Check for +1 prefix
  const hasCountryCode = cleanValue.startsWith('1') && cleanValue.length === 11;
  const withoutCountryCode = cleanValue.length === 10;
  
  let areaCode: string;
  let remainingDigits: string;
  
  if (hasCountryCode) {
    areaCode = cleanValue.substring(1, 4);
    remainingDigits = cleanValue.substring(4);
  } else if (withoutCountryCode) {
    areaCode = cleanValue.substring(0, 3);
    remainingDigits = cleanValue.substring(3);
  } else {
    return false;
  }
  
  // Check area code (cannot start with 0 or 1)
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Check total digits
  if (remainingDigits.length !== 7) {
    return false;
  }
  
  // Verify format matches allowed patterns
const usPhoneRegex = /^(\+?1[\s-\.?])?\(?[2-9]\d{2}\)?[\s-\.?]?\d{3}[\s-\.?]?\d{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles with various formats:
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  
  // Clean the input - remove all non-digit characters except leading +
const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Pattern to match Argentine phone numbers
const argentinePhoneRegex = /^\+?54?0?[2-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) {
    return false;
  }
  
  // Extract components for validation
  let temp = cleanValue;
  
  // Check country code
  let hasCountryCode = false;
  if (temp.startsWith('+54')) {
    hasCountryCode = true;
    temp = temp.substring(3);
  } else if (temp.startsWith('54')) {
    hasCountryCode = true;
    temp = temp.substring(2);
  }
  
  // Check trunk prefix
  let hasTrunkPrefix = false;
  if (temp.startsWith('0')) {
    hasTrunkPrefix = true;
    temp = temp.substring(1);
  }
  
  // Check mobile indicator
  temp = temp.startsWith('9') ? temp.substring(1) : temp;
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Extract area code (next 2-4 digits, first digit 1-9)
  if (temp.length < 8) return false; // Need at least area code + subscriber minimum
  
  const areaCode = temp.substring(0, Math.min(4, temp.length - 6));
  
  // Area code must be 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode.charAt(0) < '1' || areaCode.charAt(0) > '9') return false;
  
  // Remaining digits are subscriber number
  const subscriberDigits = temp.substring(areaCode.length);
  
  // Total subscriber digits should be 6-8
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  
  // Must start with a letter (unicode supported)
  if (!/^\p{L}/u.test(value)) {
    return false;
  }
  
  // Pattern allows: unicode letters, spaces, apostrophes, hyphens
  // Rejects: digits, symbols (except apostrophe and hyphen)
const validNameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!validNameRegex.test(value)) {
    return false;
  }
  
  // Reject obviously fake names like "X Æ A-12"
  const fakeNamePattern = /[\dÆØÅ]/;
  if (fakeNamePattern.test(value)) {
    return false;
  }
  
  // Additional check: must contain at least one alphabetic character
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  // Reject names that are only punctuation/spaces
  if (!/[\p{L}\p{M}]/u.test(value.replace(/[\s'-]/g, ''))) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Accept Visa/Mastercard/AmEx prefixes and lengths
  // Run a Luhn checksum
  
  const cleanValue = value.replace(/\D/g, '');
  
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check for acceptable prefixes
  const visaPrefix = cleanValue.startsWith('4') && (cleanValue.length === 13 || cleanValue.length === 16 || cleanValue.length === 19);
  const mastercardPrefix = cleanValue.startsWith('5') && cleanValue.length === 16; // 51-55 range
  const amexPrefix = (cleanValue.startsWith('34') || cleanValue.startsWith('37')) && cleanValue.length === 15;
  
  if (!visaPrefix && !mastercardPrefix && !amexPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
