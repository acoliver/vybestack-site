/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!)
  // Insert exactly one space between sentences even if input omitted it
  // Collapse extra spaces sensibly while leaving abbreviations intact when possible
  
  if (!text) return text;
  
  let result = text;
  
  // Find sentence boundaries (.?! followed by lowercase or start)
  // Look for the pattern: sentence ending + lowercase/start
  const sentenceEndRegex = /([.!?]\s*)([a-z])/g;
  
  result = result.replace(sentenceEndRegex, (match, punctuation, nextChar) => {
    return punctuation + nextChar.toUpperCase();
  });
  
  // Fix spacing - ensure exactly one space after sentence endings
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  // Collapse multiple spaces but preserve sentence boundaries
  result = result.replace(/\s+/g, ' ');
  
  // Capitalize the very first character if it's a letter
  result = result.replace(/^([a-z])/, (match, firstChar) => firstChar.toUpperCase());
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Return all URLs detected in the text without trailing punctuation
  
  // URL pattern that captures standard URLs
  const urlRegex = /https?:\/\/[^\s<>"']+|[a-zA-Z0-9-]+\.(?:[a-zA-Z]{2,})+(?:\/[^\s<>"']*)?/g;
  
  const urls = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  const cleanedUrls = urls.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?:;]+$/, '').replace(/["'<>]+$/, '');
  });
  
  // Filter out invalid matches (too short, no domain)
  return cleanedUrls.filter(url => {
    if (url.length < 4) return false;
    
    // Must have at least one dot for domain
    if (!url.includes('.') && !url.startsWith('http')) return false;
    
    // For non-http URLs, must have proper structure
    if (!url.startsWith('http')) {
      const domainPattern = /^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/;
      return domainPattern.test(url);
    }
    
    return true;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  
  // Pattern to match http:// URLs
  const httpRegex = /http:\/\/[^\s<>"']+/g;
  
  return text.replace(httpRegex, (match) => {
    return match.replace('http://', 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://
  // - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/...
  // - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://.
  // - Preserve nested paths (e.g., /docs/api/v1).
  
  // Pattern to match http:// URLs
  const httpRegex = /http:\/\/([^/\s]+)([^<>"']*)/g;
  
  return text.replace(httpRegex, (match, host, path) => {
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|&|=|cgi-bin)/.test(path) || 
                              /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.<original host>
        host = `docs.${host}`;
      }
    }
    
    // Always upgrade scheme to https://
    return `https://${host}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // If the string doesn't match that format or month/day are invalid, return N/A
  
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31, check month-specific limits)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Check for February 29th in non-leap years (simplified check)
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Simple leap year check: divisible by 4, but not by 100 unless by 400
    if (yearNum % 4 !== 0 || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
