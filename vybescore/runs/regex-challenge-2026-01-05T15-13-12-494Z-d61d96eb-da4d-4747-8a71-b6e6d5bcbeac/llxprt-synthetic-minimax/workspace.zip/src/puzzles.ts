/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  // Create word boundary pattern with the prefix
  const wordPattern = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive matching)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerMatch.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string
  // Use lookaheads/lookbehinds
  
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find the complete pattern (digit followed by token)
  // Ensure we're not matching at the very beginning of the string
  const simplePattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(simplePattern) || [];
  
  // Filter out matches that start at position 0 (beginning of string)
  return matches.filter(match => {
    const index = text.indexOf(match);
    return index >= 0; // All matches from regex should be valid positions
  });
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol
  // No whitespace, no immediate repeated sequences (e.g., abab should fail)
  
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()\-_=+[\]{}|;:'",.<>/?\\]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1234)
  // This pattern looks for 4-character patterns that repeat immediately
  const repeatedPattern = /(..)\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Check for any 3+ character sequential patterns that repeat
  // For example: abab, 1234, ABCABC
  const sequentialPattern = /(\w{3,})\1/;
  if (sequentialPattern.test(value)) {
    return false;
  }
  
  // Additional check: no 4-character repeating patterns anywhere
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.substring(i, i + 4);
    const rest = value.substring(i + 4);
    if (rest.includes(pattern)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
  
  // IPv6 address pattern
  // Supports various formats including shorthand ::
  // Examples: 2001:db8::1, 2001:0db8:0000:0000:0000:ff00:0042:7879, ::1
  
  // Pattern to match IPv6 addresses
  // This is a comprehensive pattern that handles:
  // - Full IPv6 addresses with 8 groups of 4 hex digits
  // - Compressed notation with ::
  // - Various edge cases
  
  const ipv6Patterns = [
    // Standard full notation: 2001:0db8:0000:0000:0000:ff00:0042:7879
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // Compressed notation with :: (various positions)
    /\b(?:[0-9a-fA-F]{1,4}:){0,6}(?::[0-9a-fA-F]{1,4}){1,7}\b/,
    
    // Starting with :: (multiple groups)
    /\b::(?::[0-9a-fA-F]{1,4}){1,7}\b/,
    
    // Ending with :: (multiple groups)
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/,
    
    // Single group or mixed
    /\b[0-9a-fA-F]{0,4}::(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{0,4}\b/,
    
    // Very compressed (just ::)
    /\b::\b/
  ];
  
  // Test against all IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
