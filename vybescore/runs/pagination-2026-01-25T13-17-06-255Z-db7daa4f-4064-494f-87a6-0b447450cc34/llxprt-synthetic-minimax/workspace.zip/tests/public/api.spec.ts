import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/server/app';
import type { Database } from 'sql.js';
import { createDatabase } from '../../src/server/db';

describe('Inventory API Pagination', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  describe('GET /inventory', () => {
    it('should return first page with default limit', async () => {
      const response = await request(app).get('/inventory');
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('items');
      expect(response.body).toHaveProperty('page', 1);
      expect(response.body).toHaveProperty('limit', 5);
      expect(response.body).toHaveProperty('total');
      expect(response.body).toHaveProperty('hasNext');
      expect(Array.isArray(response.body.items)).toBe(true);
      expect(response.body.items.length).toBeLessThanOrEqual(5);
    });

    it('should return second page correctly', async () => {
      const page1Response = await request(app).get('/inventory');
      const total = page1Response.body.total;
      
      if (total > 5) {
        const response = await request(app).get('/inventory?page=2&limit=5');
        
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('page', 2);
        expect(response.body).toHaveProperty('limit', 5);
        expect(Array.isArray(response.body.items)).toBe(true);
        
        // Verify no duplicate items between pages
        const page1Items = page1Response.body.items;
        const page2Items = response.body.items;
        const page1Ids = page1Items.map((item: { id: number }) => item.id);
        const page2Ids = page2Items.map((item: { id: number }) => item.id);
        const intersection = page1Ids.filter((id: number) => page2Ids.includes(id));
        expect(intersection.length).toBe(0);
      }
    });

    it('should validate page parameter', async () => {
      const invalidResponses = await Promise.all([
        request(app).get('/inventory?page=0'),
        request(app).get('/inventory?page=-1'),
        request(app).get('/inventory?page=abc'),
        request(app).get('/inventory?page=1001')
      ]);

      for (const response of invalidResponses) {
        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('error');
      }
    });

    it('should validate limit parameter', async () => {
      const invalidResponses = await Promise.all([
        request(app).get('/inventory?limit=0'),
        request(app).get('/inventory?limit=-1'),
        request(app).get('/inventory?limit=abc'),
        request(app).get('/inventory?limit=101')
      ]);

      for (const response of invalidResponses) {
        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('error');
      }
    });

    it('should handle valid page and limit', async () => {
      const response = await request(app).get('/inventory?page=1&limit=10');
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('page', 1);
      expect(response.body).toHaveProperty('limit', 10);
      expect(response.body.items.length).toBeLessThanOrEqual(10);
    });

    it('should calculate hasNext correctly', async () => {
      const page1Response = await request(app).get('/inventory?page=1&limit=5');
      const total = page1Response.body.total;
      
      if (total > 5) {
        const hasNext = total > 5;
        expect(page1Response.body.hasNext).toBe(hasNext);
      }
    });

    it('should return empty items for out of bounds page', async () => {
      const response = await request(app).get('/inventory?page=999&limit=5');
      
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('items', []);
      expect(response.body).toHaveProperty('page', 999);
      expect(response.body).toHaveProperty('hasNext', false);
    });

    it('should include pagination metadata', async () => {
      const response = await request(app).get('/inventory?page=1&limit=5');
      
      expect(response.body).toHaveProperty('total');
      expect(typeof response.body.total).toBe('number');
      expect(response.body.total).toBeGreaterThanOrEqual(0);
      expect(typeof response.body.hasNext).toBe('boolean');
    });

    it('should maintain consistent pagination across pages', async () => {
      if (await hasEnoughData(db)) {
        const page1 = await request(app).get('/inventory?page=1&limit=3');
        const page2 = await request(app).get('/inventory?page=2&limit=3');
        const page3 = await request(app).get('/inventory?page=3&limit=3');
        
        // Verify each page has consistent limit
        expect(page1.body.items.length).toBeLessThanOrEqual(3);
        expect(page2.body.items.length).toBeLessThanOrEqual(3);
        expect(page3.body.items.length).toBeLessThanOrEqual(3);
        
        // Verify no item appears in multiple pages
        const allIds = [...page1.body.items, ...page2.body.items, ...page3.body.items]
          .map((item: { id: number }) => item.id);
        const uniqueIds = new Set(allIds);
        expect(allIds.length).toBe(uniqueIds.size);
      }
    });
  });
});

async function hasEnoughData(db: Database): Promise<boolean> {
  const stmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  stmt.step();
  const count = stmt.getAsObject().count as number;
  stmt.free();
  return count >= 10;
}