import InitSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface Submission extends ContactFormData {
  id: number;
  createdAt: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private readonly dbPath: string;
  private readonly schemaPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite', schemaPath: string = 'db/schema.sql') {
    this.dbPath = path.resolve(process.cwd(), dbPath);
    this.schemaPath = path.resolve(process.cwd(), schemaPath);
  }

  async initialize(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Initialize sql.js
      const SQL = await InitSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });

      // Load existing database or create new one
      let sqlBuffer: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        const existingDb = fs.readFileSync(this.dbPath);
        sqlBuffer = new Uint8Array(existingDb);
      }

      this.db = new SQL.Database(sqlBuffer);
      
      // Run schema initialization
      const schema = fs.readFileSync(this.schemaPath, 'utf-8');
      this.db.exec(schema);
    } catch (error) {
      throw new Error(`Failed to initialize database: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async insertSubmission(data: ContactFormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();

    // Get the last inserted row ID
    const idStmt = this.db.prepare('SELECT last_insert_rowid() as id');
    const idResult = idStmt.getAsObject() as { id: number };
    idStmt.free();

    await this.save();
    return idResult.id;
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      SELECT id, first_name, last_name, street_address, city,
             state_province, postal_code, country, email, phone,
             created_at
      FROM submissions 
      ORDER BY created_at DESC
    `);

    const results: Submission[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject() as Record<string, number | string | Uint8Array | null>;
      results.push({
        id: row.id as number,
        firstName: row.first_name as string,
        lastName: row.last_name as string,
        streetAddress: row.street_address as string,
        city: row.city as string,
        stateProvince: row.state_province as string,
        postalCode: row.postal_code as string,
        country: row.country as string,
        email: row.email as string,
        phone: row.phone as string,
        createdAt: row.created_at as string
      });
    }
    stmt.free();

    return results;
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const binaryData = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(binaryData));
    } catch (error) {
      throw new Error(`Failed to save database: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}