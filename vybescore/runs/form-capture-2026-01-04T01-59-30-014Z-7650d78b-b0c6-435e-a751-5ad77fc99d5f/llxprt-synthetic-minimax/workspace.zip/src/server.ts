import express, { Request, Response } from 'express';
import * as path from 'path';
import * as http from 'http';
import { DatabaseManager } from './db-manager';
import { validateContactForm, sanitizeFormData, ContactFormData } from './validation';

const PORT = process.env['PORT'] || 3535;

// Global variables for the running server
let runningServer: http.Server | null = null;
let dbManager: DatabaseManager | null = null;

// Middleware setup function
function setupMiddleware(app: express.Application): void {
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use(express.static(path.join(__dirname, '../public')));

  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '../views'));
}

// Routes setup function
function setupRoutes(app: express.Application, database: DatabaseManager): void {
  app.get('/', (_req: Request, res: Response) => {
    res.render('contact-form', {
      title: 'Contact Us',
      data: {},
      errors: {}
    });
  });

  app.post('/submit', async (req: Request, res: Response) => {
    try {
      const formData: ContactFormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const sanitizedData = sanitizeFormData(formData);
      const validation = validateContactForm(sanitizedData);

      if (!validation.isValid) {
        // Validation failed, re-render form with errors
        return res.status(400).render('contact-form', {
          title: 'Contact Us - Please Fix Errors',
          data: formData,
          errors: validation.errors
        });
      }

      // Validation passed, insert into database
      await database.insertSubmission(sanitizedData);
      
      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error processing form submission:', error);
      res.status(500).render('contact-form', {
        title: 'Contact Us - Error',
        data: {},
        errors: { general: 'An error occurred while processing your submission. Please try again.' }
      });
    }
  });

  app.get('/thank-you', (_req: Request, res: Response) => {
    res.render('thank-you', {
      title: 'Thank You (Please Don\'t Sue Us)'
    });
  });

  // Health check endpoint
  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });
}

// Factory function to create properly initialized app instance
async function createApp(): Promise<express.Application> {
  // Initialize database
  const database = new DatabaseManager();
  await database.initialize();
  console.log('Database initialized successfully');
  dbManager = database;

  const app = express();
  setupMiddleware(app);
  setupRoutes(app, database);

  return app;
}

// Graceful shutdown function
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  try {
    if (dbManager) {
      await dbManager.close();
      console.log('Database closed successfully');
    }
    if (runningServer) {
      runningServer.close();
    }
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

async function startServer(): Promise<void> {
  try {
    const app = await createApp();
    
    runningServer = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export a factory function for creating test instances
export async function createTestApp(): Promise<express.Application> {
  const app = express();
  setupMiddleware(app);
  
  // For testing, create a fresh database instance
  const testDbManager = new DatabaseManager();
  await testDbManager.initialize();
  setupRoutes(app, testDbManager);
  
  return app;
}

// Start server only if this file is run directly
if (require.main === module) {
  startServer();
}

export { createApp as app };
