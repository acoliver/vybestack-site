export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export type ContactFormData = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

export function validateContactForm(data: ContactFormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  if (!data['firstName']?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data['lastName']?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data['streetAddress']?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data['city']?.trim()) {
    errors.city = 'City is required';
  }

  if (!data['stateProvince']?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data['postalCode']?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!data['country']?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data['email']?.trim()) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data['email'])) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data['phone']?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data['phone'])) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  // Simple but effective email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254; // RFC 5321 limit
}

function isValidPhone(phone: string): boolean {
  // Remove all non-phone characters for validation
  const cleanedPhone = phone.replace(/[^\d+]/g, '');
  
  // Must have at least 7 digits for a basic international number
  const digitCount = (cleanedPhone.match(/\d/g) || []).length;
  return digitCount >= 7 && cleanedPhone.length >= 7;
}

export function sanitizeFormData(data: ContactFormData): ContactFormData {
  return {
    firstName: data.firstName?.trim() || '',
    lastName: data.lastName?.trim() || '',
    streetAddress: data.streetAddress?.trim() || '',
    city: data.city?.trim() || '',
    stateProvince: data.stateProvince?.trim() || '',
    postalCode: data.postalCode?.trim() || '',
    country: data.country?.trim() || '',
    email: data.email?.trim().toLowerCase() || '',
    phone: data.phone?.trim() || ''
  };
}