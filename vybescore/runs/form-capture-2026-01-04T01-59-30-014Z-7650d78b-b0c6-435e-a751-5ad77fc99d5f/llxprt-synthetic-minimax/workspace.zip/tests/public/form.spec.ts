import { describe, expect, it, beforeAll, afterEach } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import * as express from 'express';
import { createTestApp } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

let testApp: express.Express;

beforeAll(async () => {
  // Create a fresh app instance for testing
  testApp = await createTestApp();
});

afterEach(() => {
  // Clean up test database after each test
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(testApp)
      .get('/')
      .expect(200);

    const html = response.text;
    
    // Check for form elements
    expect(html).toContain('Contact Us');
    expect(html).toContain('name="firstName"');
    expect(html).toContain('name="lastName"');
    expect(html).toContain('name="streetAddress"');
    expect(html).toContain('name="city"');
    expect(html).toContain('name="stateProvince"');
    expect(html).toContain('name="postalCode"');
    expect(html).toContain('name="country"');
    expect(html).toContain('name="email"');
    expect(html).toContain('name="phone"');
    expect(html).toContain('action="/submit"');
  });

  it('redirects to thank you page after successful submission', async () => {
    const validSubmission = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    await request(testApp)
      .post('/submit')
      .send(validSubmission)
      .expect(302) // Redirect status
      .expect('Location', '/thank-you');
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(testApp)
      .post('/submit')
      .send({}) // Empty submission
      .expect(400); // Bad Request status

    const html = response.text;
    expect(html).toContain('First name is required');
  });

  it('handles invalid email format', async () => {
    const submissionWithInvalidEmail = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };

    const response = await request(testApp)
      .post('/submit')
      .send(submissionWithInvalidEmail)
      .expect(400);

    const html = response.text;
    expect(html).toContain('Please enter a valid email address');
  });

  it('accepts international phone numbers', async () => {
    const submissionWithInternationalPhone = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.co.uk',
      phone: '+44 20 7946 0958'
    };

    await request(testApp)
      .post('/submit')
      .send(submissionWithInternationalPhone)
      .expect(302)
      .expect('Location', '/thank-you');
  });

  it('shows thank you page after submission', async () => {
    const response = await request(testApp)
      .get('/thank-you')
      .expect(200);

    const html = response.text;
    expect(html).toContain('Thank You');
    expect(html).toContain('Your information has been successfully captured');
  });

  it('has working health check endpoint', async () => {
    const response = await request(testApp)
      .get('/health')
      .expect(200);

    const healthData = JSON.parse(response.text);
    expect(healthData.status).toBe('ok');
    expect(healthData.timestamp).toBeDefined();
  });
});
