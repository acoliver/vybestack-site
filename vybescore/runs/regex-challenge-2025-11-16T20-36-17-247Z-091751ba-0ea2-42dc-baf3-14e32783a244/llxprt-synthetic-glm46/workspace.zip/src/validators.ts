export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with proper formatting rules
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // More comprehensive email validation regex for typical addresses such as name+tag@example.co.uk
  // Local part: letters, numbers, dots, hyphens, plus, apostrophes (but not consecutive dots)
  // Domain: letters, numbers, hyphens, subdomains (but no underscores)
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9.+'-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for consecutive dots
  if (value.includes('..')) return false;
  
  // Check for domain underscores (any underscore in domain part)
  const atPos = value.indexOf('@');
  if (atPos !== -1 && value.substring(atPos).includes('_')) return false;
  
  // Check for leading or trailing dot in local part
  const localPart = value.substring(0, atPos);
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Check for double @
  if (value.split('@').length > 2) return false;
  
  // Check for leading or trailing dots in the entire email
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length: 10 digits for standard US number, 11 if starting with 1
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (US country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Get the actual phone number (remove country code if present)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Area code cannot start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') return false;
  
  // Exchange code (second 3 digits) cannot start with 0 or 1
  if (phoneNumber[3] === '0' || phoneNumber[3] === '1') return false;
  
  // Full regex validation for supported formats
  const usPhoneRegex = /^(\+1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)[2-9]\d{2}[\s-]?\d{4}$/;
  
  return usPhoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats
 * Supports +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all spaces and hyphens for validation
  const cleanValue = value.trim().replace(/[\s-]/g, '');
  
  // Comprehensive regex for Argentine phone numbers:
  // ^\+54   - Optional country code
  // 9?      - Optional mobile indicator
  // 0?      - Optional trunk prefix before area code
  // [1-9]\d{1,3} - Area code (2-4 digits, leading digit 1-9)
  // \d{6,8} - Subscriber number (6-8 digits)
  // OR
  // 0   - Required trunk prefix when country code omitted
  // [1-9]\d{1,3} - Area code (2-4 digits, leading digit 1-9)
  // \d{6,8} - Subscriber number (6-8 digits)
  
  const argentinePhoneWithCountry = /^\+54?9?0?[1-9]\d{1,3}\d{6,8}$/;
  const argentinePhoneWithoutCountry = /^0[1-9]\d{1,3}\d{6,8}$/;
  
  return argentinePhoneWithCountry.test(cleanValue) || argentinePhoneWithoutCountry.test(cleanValue);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace first
  const trimmed = value.trim();
  
  // Empty string is invalid
  if (!trimmed) return false;
  
  // Regex pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens (but not at start/end)
  // - Spaces between name parts
  // - Minimum 2 characters, maximum 50 characters
  const nameRegex = /^[\p{L}]+([ '-][\p{L}]+)*$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Reject names with digits
  if (/[\d]/.test(trimmed)) return false;
  
  // Reject names with certain symbols that shouldn't be in names
  if (/[@#$%^&*()+=\\[{}|:;"<>,.?/~`]/.test(trimmed)) return false;
  
  // Reject names with consecutive symbols
  if (/--|''/.test(trimmed)) return false;
  
  // Ensure the name has at least 2 letters
  const letterCount = (trimmed.match(/[\p{L}]/gu) || []).length;
  if (letterCount < 2) return false;
  
  return true;
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  if (!cardNumber || !/^\d+$/.test(cardNumber)) return false;
  
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx
 * Performs prefix and length validation plus Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleanCard)) return false;
  
  // Check length for different card types
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$|^(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  // Test against card patterns
  const isValidPattern = visaRegex.test(cleanCard) || 
                         mastercardRegex.test(cleanCard) || 
                         amexRegex.test(cleanCard);
  
  if (!isValidPattern) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanCard);
}