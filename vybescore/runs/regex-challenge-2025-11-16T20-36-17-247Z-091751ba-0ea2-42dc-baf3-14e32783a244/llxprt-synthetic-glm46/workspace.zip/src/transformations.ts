/**
 * Capitalizes the first character of each sentence
 * After sentence-ending punctuation (., ?, !), inserts exactly one space
 * Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace multiple spaces with a single space first
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Handle sentence boundaries - split on . ? ! followed by any number of spaces and capitalize the next letter
  const sentences = normalized.split(/([.?!])/);
  
  let result = '';
  let isStartOfSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part && /^[.?!]$/.test(part)) {
      // This is punctuation, add it to result and prepare for next sentence
      result += part;
      isStartOfSentence = true;
    } else if (part && part.trim()) {
      // This is a sentence or part of a sentence
      let sentencePart = part.trim();
      
      if (isStartOfSentence) {
        // Capitalize first letter of the sentence
        sentencePart = sentencePart.charAt(0).toUpperCase() + sentencePart.slice(1).toLowerCase();
        isStartOfSentence = false;
      }
      
      result += sentencePart;
    }
  }
  
  // Ensure proper spacing after punctuation
  result = result.replace(/([.?!])([a-zA-Z])/g, '$1 $2');
  
  return result;
}

/**
 * Extracts URLs from text, removing trailing punctuation
 * Returns an array of matched URL strings
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Enhanced URL regex pattern based on RFC 3986
  const urlRegex = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s/$.?#].[^\s]*\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
// Clean each URL by removing trailing punctuation characters
  return matches.map(url => {
    return url.replace(/[.,;:!?)\]}]+$/g, '');
  });
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * Always upgrades http:// to https://
 * For /docs/ paths, rewrites http://example.com/... to https://docs.example.com/...
 * Skips host rewrite for paths with dynamic hints or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then check for docs paths that need host rewriting
  // Match URLs with /docs/ path, excluding dynamic content and legacy extensions
  const docsUrlRegex = /https:\/\/([a-zA-Z0-9.-]+)(\/docs\/[^?\s]*?)(?=[\s?&]|$)/g;
  
  result = result.replace(docsUrlRegex, (match, host, path) => {
    // Skip if path contains dynamic hints or legacy extensions
    const skipPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i
    ];
    
    const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
    
    if (shouldSkip) {
      return match; // Don't change the host, only the scheme (already done above)
    }
    
    // Rewrite the host to docs.example.com
    return `https://docs.${host}${path}`;
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Simple regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month day combinations
  const maxDaysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  // February validation
  if (month === 2) {
    if (isLeapYear && day > 29) return 'N/A';
    if (!isLeapYear && day > 28) return 'N/A';
  } else {
    if (day > maxDaysInMonth[month]) return 'N/A';
  }
  
  return year;
}
