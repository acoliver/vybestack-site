/**
 * Finds words starting with the specified prefix, excluding listed exceptions
 * Returns an array of matched words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }
  
  // Use simpler word matching with split by spaces
  const words = text.split(/\s+/);
  const matches = words.filter(word => {
    // Remove punctuation from word
    const cleanWord = word.replace(/[.,;:!?()[\]{}"']/g, '');
    return cleanWord.toLowerCase().startsWith(prefix.toLowerCase()) && cleanWord.length > prefix.length;
  });
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches
    .map(match => match.replace(/[.,;:!?()[\]{}"']/g, ''))
    .filter(word => word && !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token that appear after a digit but not at the start of the string
 * Uses lookaheads and lookbehinds for precise matching
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
  
  // Simple approach without lookbehind for better compatibility
  // Split text and look for patterns
  const parts = text.split(/(\d+)/);
  const results: string[] = [];
  
  for (let i = 0; i < parts.length; i += 2) {
    // Check if the next part exists and contains our token after a digit
    if (i + 1 < parts.length && (i + 1) % 2 === 1) {
      const digitPart = parts[i + 1];
      const followingText = parts[i + 2] || '';
      
      // Look for token at the start of the text following a digit
      const tokenRegex = new RegExp(`^${escapedToken}`, 'g');
      if (tokenRegex.test(followingText)) {
        results.push(digitPart + escapedToken);
      }
    }
  }
  
  return results;
}

/**
 * Validates passwords according to the policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol
 * No whitespace, no immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // This pattern checks for any sequence of 2-4 characters that repeats immediately
  const repeatedSequenceRegex = /(..|...|....)\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::)
 * Ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Simple IPv6 detection pattern including shorthand
  // This pattern matches basic IPv6 forms including :: notation
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|::[0-9a-fA-F:]*|\b[0-9a-fA-F:]*::\b/;
  
  // First check for any potential IPv6 match
  const potentialMatches = value.match(ipv6Regex);
  if (!potentialMatches || potentialMatches.length === 0) return false;
  
  // Check if the text contains IPv4 addresses - these would be false positives
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  const hasIPv4 = ipv4Regex.test(value);
  
  // If we have IPv4 addresses, be more careful about IPv6 detection
  if (hasIPv4) {
    // Look for clear IPv6 indicators
    // IPv6 typically has at least two colons, often in sequence (like ::)
    // Also look for hex characters beyond what would be in IPv4
    for (const match of potentialMatches) {
      if (match.includes('::')) return true;
      if ((match.match(/:/g) || []).length >= 2) {
        // Check for hex characters that wouldn't appear in IPv4
        if (/[a-fA-F]/.test(match)) return true;
      }
    }
    return false;
  }
  
  // No IPv4 present, so we can be more confident about IPv6 detection
  return potentialMatches.length > 0;
}