/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Execute the initial side effect by tracking dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value as T
    
    // Remove observer from any dependencies it might be tracking
    // This is crucial for proper cleanup to prevent memory leaks
    const extendedObserver = observer as Observer<T> & { dependents?: Set<Observer<unknown>> }
    if (extendedObserver.dependents) {
      extendedObserver.dependents.clear()
    }
  }
  
  // Add a property to track cleanup for testing
  ;(unsubscribe as unknown as { isDisposed: () => boolean }).isDisposed = () => disposed
  
  // Track how many times the callback has been executed
  let executionCount = 0
  const originalUpdateFn = updateFn
  
  // Override updateFn to count executions, but only after initial execution
  observer.updateFn = (newValue) => {
    if (!disposed && executionCount > 0) {
      executionCount++
    } else if (!disposed && executionCount === 0) {
      // First execution is the initial call during creation
      executionCount = 1
    }
    return originalUpdateFn(newValue)
  }
  
  // Expose execution count for testing
  ;(observer as unknown as { executionCount: number }).executionCount = executionCount
  
  return unsubscribe
}
