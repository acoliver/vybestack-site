/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Store dependents in the observer itself using type extension
  const o: Observer<T> & { dependents?: Set<Observer<unknown>> } = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set()
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  const computed: GetterFn<T> = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver && 'updateFn' in currentObserver) {
      // The current observer depends on this computed value
      if (o.dependents) {
        o.dependents.add(currentObserver as Observer<unknown>)
      }
    }
    return o.value!
  }
  
  return computed
}
