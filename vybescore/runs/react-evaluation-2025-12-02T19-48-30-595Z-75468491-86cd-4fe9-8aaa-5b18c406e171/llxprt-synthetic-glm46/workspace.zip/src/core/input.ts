/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : (equal === false ? (a, b) => a !== b : undefined),
    dependents: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && 'updateFn' in observer) {
      s.observer = observer
      if (s.dependents) {
        s.dependents.add(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    let hasChanged = true
    
    if (s.equalFn) {
      hasChanged = !s.equalFn(s.value, nextValue)
    } else if (equal === false) {
      hasChanged = s.value !== nextValue
    } else {
      hasChanged = s.value !== nextValue || typeof s.value !== typeof nextValue
    }
    
    if (hasChanged) {
      s.value = nextValue
      // When value changes, update all dependent observers
      if (s.observer) {
        updateObserver(s.observer as Observer<T>)
      }
      if (s.dependents) {
        s.dependents.forEach(dependent => {
          updateObserver(dependent as Observer<unknown>)
        })
      }
    }
    return s.value
  }

  return [read, write]
}
