/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  dependents?: Set<Observer<unknown>>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const prevValue = observer.value
    observer.value = observer.updateFn(observer.value)
    
    // If this observer has dependents, update them when value changes
    if (prevValue !== observer.value) {
      const extendedObserver = observer as Observer<T> & { dependents?: Set<Observer<unknown>> }
      if (extendedObserver.dependents) {
        extendedObserver.dependents.forEach(dependent => {
          updateObserver(dependent as Observer<unknown>)
        })
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(observers: Set<Observer<unknown>>): void {
  observers.forEach(observer => {
    updateObserver(observer as Observer<unknown>)
  })
}
