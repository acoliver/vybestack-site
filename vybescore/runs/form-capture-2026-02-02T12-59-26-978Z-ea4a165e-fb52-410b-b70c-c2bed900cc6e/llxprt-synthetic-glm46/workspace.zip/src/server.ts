import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Database variables
let db: Database | null = null;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initializeDatabase() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load or create database
    let dbData: Uint8Array;
    if (fs.existsSync(DB_PATH)) {
      dbData = fs.readFileSync(DB_PATH);
    } else {
      dbData = new Uint8Array(0);
    }

    const SQL = await initSqlJs();
    db = new SQL.Database(dbData);

    // Create schema if not exists
    if (!fs.existsSync(DB_PATH)) {
      const schema = fs.readFileSync(
        path.join(__dirname, '../db/schema.sql'),
        'utf8'
      );
      db.run(schema);
      console.log('Database initialized with schema');
    } else {
      console.log('Database loaded successfully');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase() {
  if (db) {
    try {
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Define form data interface
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Form validation
function validateForm(formData: FormData): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  // Required fields validation
  if (!formData.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }

  if (!formData.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }

  if (!formData.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }

  if (!formData.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!formData.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!formData.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }

  if (!formData.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Allow digits, spaces, parentheses, dashes, and leading +
    if (!/^\+?[0-9\s()-]+$/.test(formData.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Form',
    data: {},
    errors: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation = validateForm(req.body);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      title: 'Contact Form',
      data: req.body,
      errors: validation.errors
    });
  }

  try {
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        req.body.first_name,
        req.body.last_name,
        req.body.street_address,
        req.body.city,
        req.body.state_province,
        req.body.postal_code,
        req.body.country,
        req.body.email,
        req.body.phone
      ]);

      stmt.free();
      saveDatabase();
    }
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      title: 'Contact Form',
      data: req.body,
      errors: { general: 'An error occurred while saving your submission. Please try again.' }
    });
  }

  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
