/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    // Always update if false
    equalFn = () => false
  } else if (equal === true || equal === undefined) {
    // Default equality using strict equality
    equalFn = (a, b) => a === b
  }

  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initially compute the value
  updateObserver(computedObserver)

  // Set of observers that depend on this computed value
  const dependentObservers = new Set<ObserverR>()

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      dependentObservers.add(observer)
    }

    // Return the computed value
    return computedObserver.value!
  }

  // Override the update method to notify dependent observers when value changes
  const originalUpdate = computedObserver.updateFn
  computedObserver.updateFn = (prevValue?: T) => {
    const newValue = originalUpdate(prevValue)
    
    // Only notify if value actually changed
    if (equalFn && prevValue !== undefined && equalFn(prevValue, newValue)) {
      return newValue
    }

    // Update the stored value
    computedObserver.value = newValue

    // Notify all dependent observers
    const observersToNotify = Array.from(dependentObservers)
    observersToNotify.forEach(dependentObserver => {
      // Cast to Observer for compatibility
      updateObserver(dependentObserver as Observer<T>)
    })

    return newValue
  }

  return getter
}