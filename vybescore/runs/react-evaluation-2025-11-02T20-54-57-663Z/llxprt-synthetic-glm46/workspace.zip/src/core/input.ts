/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    // Always update if false
    equalFn = () => false
  } else if (equal === true || equal === undefined) {
    // Default equality using strict equality
    equalFn = (a, b) => a === b
  }

  // Multiple observers to support reactive programming
  const observers = new Set<ObserverR>()

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if values are different according to the equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }

    s.value = nextValue
    
    // Notify all observers
    const observersToNotify = Array.from(observers)
    observersToNotify.forEach(observer => {
      // Cast to Observer for updateObserver compatibility
      updateObserver(observer as Observer<T>)
    })

    return s.value
  }

  return [read, write]
}
