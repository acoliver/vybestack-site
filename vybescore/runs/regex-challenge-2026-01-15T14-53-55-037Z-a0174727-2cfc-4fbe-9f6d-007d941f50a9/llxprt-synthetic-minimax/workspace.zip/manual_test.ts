import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './src/puzzles.js';

// Manual tests for edge cases
console.log('\n=== VALIDATOR TESTS ===');

// Email validation tests
console.log('Email tests:');
console.log('user@example.com:', isValidEmail('user@example.com')); // true
console.log('name+tag@example.co.uk:', isValidEmail('name+tag@example.co.uk')); // true
console.log('user@@example..com:', isValidEmail('user@@example..com')); // false
console.log('user@domain_with_underscore.com:', isValidEmail('user@domain_with_underscore.com')); // false

// Name validation tests
console.log('\nName tests:');
console.log('Jane Doe:', isValidName('Jane Doe')); // true
console.log('José María González:', isValidName('José María González')); // true
console.log('O\'Connor-Smith:', isValidName('O\'Connor-Smith')); // true
console.log('X Æ A-12:', isValidName('X Æ A-12')); // false (problematic pattern)
console.log('John123:', isValidName('John123')); // false (digits not allowed)

// Phone number tests
console.log('\nUS Phone tests:');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890')); // true
console.log('212-555-7890:', isValidUSPhone('212-555-7890')); // true
console.log('2125557890:', isValidUSPhone('2125557890')); // true
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890')); // true
console.log('055-7890:', isValidUSPhone('055-7890')); // false (area code starts with 0)

console.log('\nArgentine Phone tests:');
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567')); // true
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678')); // true
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678')); // true

// Credit card tests
console.log('\nCredit Card tests:');
console.log('4111111111111111 (Visa):', isValidCreditCard('4111111111111111')); // true
console.log('378282246310005 (AmEx):', isValidCreditCard('378282246310005')); // true
console.log('1234567890123456 (Invalid prefix):', isValidCreditCard('1234567890123456')); // false

console.log('\n=== TRANSFORMATION TESTS ===');

// Capitalize sentences tests
console.log('\nCapitalize tests:');
console.log('capitalizeSentences("hello world. this is a test."):', 
  capitalizeSentences('hello world. this is a test.')); // "Hello world. This is a test."
console.log('capitalizeSentences("hello.world.this is another!"):', 
  capitalizeSentences('hello.world.this is another!')); // Handles proper spacing

// URL extraction tests
console.log('\nURL extraction tests:');
const testText = 'Check out https://example.com and http://test.org for more info.';
console.log('extractUrls("' + testText + '"):', 
  extractUrls(testText)); // ["https://example.com", "http://test.org"]

// HTTPS enforcement tests
console.log('\nHTTPS enforcement tests:');
const httpText = 'Visit http://example.com and http://test.org';
console.log('enforceHttps("' + httpText + '"):', 
  enforceHttps(httpText)); // "Visit https://example.com and https://test.org"

// URL rewriting tests
console.log('\nURL rewriting tests:');
const docsText = 'See http://example.com/docs/api for details and http://test.org/docs/v1/overview';
console.log('rewriteDocsUrls("' + docsText + '"):', 
  rewriteDocsUrls(docsText)); // Should rewrite docs URLs properly

// Date extraction tests
console.log('\nDate extraction tests:');
console.log('extractYear("12/25/2023"):', extractYear('12/25/2023')); // "2023"
console.log('extractYear("13/25/2023"):', extractYear('13/25/2023')); // "N/A" (invalid month)
console.log('extractYear("invalid"):', extractYear('invalid')); // "N/A"

console.log('\n=== PUZZLE TESTS ===');

// Prefixed words tests
console.log('\nPrefixed words tests:');
const prefixText = 'We need to debug, debug, and de-stress. But never debug-test exceptions.';
console.log('findPrefixedWords("' + prefixText + '", "de", ["debug"]):', 
  findPrefixedWords(prefixText, 'de', ['debug'])); // Should find "debug" and "de-stress" but exclude exceptions

// Embedded token tests
console.log('\nEmbedded token tests:');
const tokenText = 'abc123def and 456token but not token alone';
console.log('findEmbeddedToken("' + tokenText + '", "token"):', 
  findEmbeddedToken(tokenText, 'token')); // Should find "456token" only

// Password strength tests
console.log('\nPassword tests:');
console.log('isStrongPassword("StrongP@ss1"):', isStrongPassword('StrongP@ss1')); // true
console.log('isStrongPassword("weak"):', isStrongPassword('weak')); // false (too short)
console.log('isStrongPassword("NoSymbols123"):', isStrongPassword('NoSymbols123')); // false (no symbol)

// IPv6 detection tests
console.log('\nIPv6 tests:');
console.log('containsIPv6("2001:0db8:85a3:0000:0000:8a2e:0370:7334"):', 
  containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334')); // true
console.log('containsIPv6("::1"):', containsIPv6('::1')); // true
console.log('containsIPv6("192.168.1.1"):', containsIPv6('192.168.1.1')); // false (IPv4)
console.log('containsIPv6("invalid"):', containsIPv6('invalid')); // false