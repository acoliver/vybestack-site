export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for valid email addresses
  // Allow typical addresses like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
  
  // Basic validation first
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional checks for specific requirements
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number without country code)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle country code - allow optional +1
  let startIndex = 0;
  if (digitsOnly.startsWith('1') && digitsOnly.length === 11) {
    startIndex = 1;
  }
  
  // Area codes cannot start with 0 or 1
  if (startIndex < digitsOnly.length && 
      (digitsOnly.charAt(startIndex) === '0' || digitsOnly.charAt(startIndex) === '1')) {
    return false;
  }
  
  // Pattern matching - check the actual format of the input
  const patterns = [
    // With +1 country code
    /^\+1[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/,
    // With 1 country code (no +)
    /^1[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/,
    // With parentheses and separators
    /^\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/,
    // All digits only (10 or 11 with country code)
    /^\d{10,11}$/
  ];
  
  // Test against all patterns
  return patterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters to work with just digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have between 10-13 digits (country code + area + subscriber)
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }
  
  // Handle full international format with country code +54
  if (value.includes('+54')) {
    // Format: +54 [9] [area code] [subscriber]
    // Remove country code and check remaining
    const withoutCountry = digitsOnly.substring(2); // Remove "54"
    
    // Optional mobile indicator 9
    let currentIndex = 0;
    if (withoutCountry.startsWith('9')) {
      currentIndex = 1;
    }
    
    // Extract area code (2-4 digits, starting with 1-9)
    const remainingDigits = withoutCountry.length - currentIndex;
    if (remainingDigits < 8 || remainingDigits > 11) {
      return false; // Need 2-4 for area code + 6-8 for subscriber
    }
    
    // Area code is 2-4 digits, subscriber is remaining (6-8 total)
    const areaCodeLength = Math.min(4, Math.max(2, remainingDigits - 6));
    const subscriberLength = remainingDigits - areaCodeLength;
    
    if (subscriberLength < 6 || subscriberLength > 8) {
      return false;
    }
    
    const areaCode = withoutCountry.substring(currentIndex, currentIndex + areaCodeLength);
    
    // Check area code validity (first digit 1-9)
    if (areaCode.length < 2 || areaCode.length > 4 || 
        parseInt(areaCode.charAt(0), 10) < 1 || parseInt(areaCode.charAt(0), 10) > 9) {
      return false;
    }
    
    return true;
  }
  
  // Handle local format (must start with trunk prefix 0)
  if (!digitsOnly.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix
  const withoutTrunk = digitsOnly.substring(1);
  
  // Optional mobile indicator 9
  let currentIndex = 0;
  if (withoutTrunk.startsWith('9')) {
    currentIndex = 1;
  }
  
  const remainingDigits = withoutTrunk.length - currentIndex;
  if (remainingDigits < 8 || remainingDigits > 11) {
    return false;
  }
  
  // Area code 2-4 digits, subscriber 6-8 digits
  const areaCodeLength = Math.min(4, Math.max(2, remainingDigits - 6));
  const subscriberLength = remainingDigits - areaCodeLength;
  
  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }
  
  const areaCode = withoutTrunk.substring(currentIndex, currentIndex + areaCodeLength);
  
  // Check area code validity
  if (areaCode.length < 2 || areaCode.length > 4 || 
      parseInt(areaCode.charAt(0), 10) < 1 || parseInt(areaCode.charAt(0), 10) > 9) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must have at least 2 characters
  if (value.length < 2) {
    return false;
  }
  
  // Cannot start or end with spaces
  if (value.startsWith(' ') || value.endsWith(' ')) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional check: no sequences of only symbols
  // and avoid problematic patterns like X Æ A-12
  if (/[\dXA-]/.test(value)) {
    // If contains these characters, ensure they're not creating a weird pattern
    const problematicPattern = /^[XÆA-]|[\dXÆA-]+$/;
    if (problematicPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for major card types)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check card type prefixes
  // Visa: 4 (13, 16, or 19 digits)
  // MasterCard: 51-55 (16 digits) or 2221-2720 (16 digits)
  // American Express: 34 or 37 (15 digits)
  let isValidPrefix = false;
  
  if (digitsOnly.startsWith('4')) {
    // Visa: 13, 16, or 19 digits
    if (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19) {
      isValidPrefix = true;
    }
  } else if (digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) {
    // American Express: 15 digits
    if (digitsOnly.length === 15) {
      isValidPrefix = true;
    }
  } else if (digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || 
             digitsOnly.startsWith('53') || digitsOnly.startsWith('54') || 
             digitsOnly.startsWith('55')) {
    // MasterCard: 16 digits (traditional range)
    if (digitsOnly.length === 16) {
      isValidPrefix = true;
    }
  } else {
    // Check 2221-2720 range for new MasterCard
    const prefix = parseInt(digitsOnly.substring(0, 4), 10);
    if (prefix >= 2221 && prefix <= 2720 && digitsOnly.length === 16) {
      isValidPrefix = true;
    }
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Luhn checksum validation
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    let digit = parseInt(digitsOnly.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
