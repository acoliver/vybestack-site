/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with prefix
  // Word boundary at start, then prefix, then word characters
  const pattern = new RegExp(`\\b${prefix}[\\w-]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !lowerExceptions.includes(lowerMatch);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at start of string
  const results: string[] = [];
  
  // Use regex to find digit followed by token
  const regex = new RegExp(`\\d${token}`, 'gi');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    // Don't include matches at the very beginning of string
    if (match.index > 0) {
      results.push(match[0]);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // Look for patterns that repeat immediately
  for (let i = 0; i < value.length - 2; i++) {
    const pattern = value.substring(i, i + 2);
    const nextPattern = value.substring(i + 2, i + 4);
    if (pattern === nextPattern) {
      return false;
    }
  }
  
  // Check for patterns like ababab (shorter repeats)
  for (let i = 0; i < value.length - 4; i++) {
    const pattern = value.substring(i, i + 2);
    const fullPattern = value.substring(i, i + 4);
    if (pattern === fullPattern.substring(2, 4)) {
      return fullPattern === pattern + pattern ? false : true;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it looks like an IPv4 address (4 groups of digits with dots)
  // If it's IPv4, return false
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Make sure it's actually IPv4 (all groups <= 255)
    const ipv4Groups = value.match(/\b(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\b/);
    if (ipv4Groups) {
      for (let i = 1; i <= 4; i++) {
        const num = parseInt(ipv4Groups[i], 10);
        if (num > 255) {
          // Invalid IPv4, could be IPv6 in disguise
          break;
        }
      }
      return false; // It's a valid IPv4, so not IPv6
    }
  }
  
  // IPv6 patterns to detect:
  // 1. Standard IPv6: 8 groups of 1-4 hex digits separated by colons
  // 2. Compressed notation with ::
  // 3. IPv6 with embedded IPv4 at the end
  
  const ipv6Patterns = [
    // Full IPv6: 8 groups of hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Compressed with :: at various positions
    /(?:^[0-9a-fA-F:]*::[0-9a-fA-F:]*$)|(?:\b::\b)/,
    // IPv6-mapped IPv4: ends with IPv4 format
    /\b(?:[0-9a-fA-F]{1,4}:){5,6}:(?:\d{1,3}\.){3}\d{1,3}\b/,
    // Simple compressed IPv6 formats
    /(::)|([0-9a-fA-F]*::[0-9a-fA-F]*)/,
    // IPv6 loopback and more patterns
    /\b[0-9a-fA-F:]*(::)[0-9a-fA-F:]*\b/
  ];
  
  // Test against all IPv6 patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
