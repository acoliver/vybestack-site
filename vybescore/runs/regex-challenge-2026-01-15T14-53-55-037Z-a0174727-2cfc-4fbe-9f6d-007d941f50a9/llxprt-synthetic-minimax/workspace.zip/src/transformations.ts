/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First normalize spaces - collapse multiple spaces
  const normalizedText = text.replace(/\s+/g, ' ');
  
  // Pattern to match sentence boundaries (after . ? !)
  // We need to capitalize after these punctuation marks
  const pattern = /([.!?])\s*([a-z])/g;
  
  // Replace each match by the punctuation followed by the capitalized letter
  const result = normalizedText.replace(pattern, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Handle the first character of the text
  if (result.length > 0 && /[a-z]/.test(result.charAt(0))) {
    return result.charAt(0).toUpperCase() + result.substring(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs
  // Match http(s):// followed by domain and optional path
  const urlPattern = /https?:\/\/[^\s]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match HTTP URLs (not HTTPS)
  const httpUrlPattern = /http:\/\/[^\s]+/gi;
  
  return text.replace(httpUrlPattern, (url) => {
    // Parse the URL
    try {
      // Replace http with https
      let newUrl = url.replace(/^http:\/\//i, 'https://');
      
      // Extract host and path
      const urlParts = newUrl.match(/^https:\/\/([^/\s]+)(.*)$/i);
      if (!urlParts) {
        return newUrl;
      }
      
      const host = urlParts[1];
      const path = urlParts[2] || '';
      
      // Check if path begins with /docs/ and doesn't have dynamic hints
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints or legacy extensions
        const hasDynamicHints = /[?&]|(cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
        
        if (!hasDynamicHints) {
          // Rewrite host to docs.<original-host>
          newUrl = `https://docs.${host}${path}`;
        }
      }
      
      return newUrl;
    } catch (error) {
      // If parsing fails, just return the upgraded URL
      return url.replace(/^http:\/\//i, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  let maxDay = 31; // Default
  
  if (month === 2) {
    // Check for leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    maxDay = isLeapYear ? 29 : 28;
  } else if (month === 4 || month === 6 || month === 9 || month === 11) {
    // April, June, September, November have 30 days
    maxDay = 30;
  }
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  // Return the year as string
  return match[3];
}
