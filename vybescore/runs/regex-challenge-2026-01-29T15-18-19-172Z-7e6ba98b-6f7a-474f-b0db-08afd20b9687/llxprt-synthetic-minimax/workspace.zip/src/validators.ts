export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects double dots, trailing dots, and domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for obviously invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@@')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // Remove leading 1 if present (for cases like +12125557890)
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1
  if (digits[3] === '0' || digits[3] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Pattern to match Argentine phone numbers
  // Optional +54 country code
  // Optional 9 mobile indicator  
  // Optional 0 trunk prefix
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: remaining 6-8 digits
  
  // Handle different formats more precisely
  const hasCountryCode = cleaned.startsWith('+54');
  let remainder = hasCountryCode ? cleaned.substring(3) : cleaned;
  
  // Handle mobile indicator 9
  const hasMobileIndicator = remainder.startsWith('9');
  if (hasMobileIndicator) {
    remainder = remainder.substring(1);
  }
  
  // Handle trunk prefix 0
  const hasTrunkPrefix = remainder.startsWith('0');
  if (hasTrunkPrefix && !hasCountryCode) {
    remainder = remainder.substring(1);
  }
  
  // Now match area code and subscriber
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: exactly the right number of digits to total 6-8 after area code
  const areaCodeMatch = remainder.match(/^([1-9]\d{1,3})/);
  
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const subscriber = remainder.substring(areaCode.length);
  
  // Validate components
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have had trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix && !hasMobileIndicator) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]/.test(value)) {
    return false;
  }
  
  // Pattern that allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens
  // - Spaces
  // But rejects:
  // - Digits
  // - Symbols (except apostrophe and hyphen)
  // - Names that are primarily symbols or look like codes
  
  const validNamePattern = /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF](?:[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF\s-]*[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF])?$/;
  
  // Must match the pattern
  if (!validNamePattern.test(value)) {
    return false;
  }
  
  // Reject names that are primarily spaces or have too many special characters
  const words = value.trim().split(/\s+/);
  if (words.length === 0) {
    return false;
  }
  
  // Each word should contain at least one letter
  for (const word of words) {
    if (!/[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]/.test(word)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Visa: 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const isVisa = /^4\d{15}$/.test(digits);
  const isMastercard = /^5[1-5]\d{14}$/.test(digits) || /^2(2[2-9]|[3-6]\d|7[01]|720)\d{12}$/.test(digits);
  const isAmEx = /^3[47]\d{13}$/.test(digits);
  
  // Must match one of the card types
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Luhn algorithm checksum
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
