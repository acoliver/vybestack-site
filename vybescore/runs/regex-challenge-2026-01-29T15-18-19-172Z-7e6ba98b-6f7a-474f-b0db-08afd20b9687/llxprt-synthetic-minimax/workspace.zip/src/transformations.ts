/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence endings: . ? !
  // Followed by optional whitespace and the start of a new sentence
  const sentencePattern = /([.!?])(\s*)([a-z])/g;
  
  // Capitalize the first letter after sentence endings
  const result = text.replace(sentencePattern, (match, punctuation, spacing, letter) => {
    return punctuation + spacing + letter.toUpperCase();
  });
  
  // Also capitalize the very first character if it's a letter
  const firstCharPattern = /^([a-z])/;
  const firstCharMatch = result.match(firstCharPattern);
  
  if (firstCharMatch) {
    return result.replace(firstCharPattern, firstCharMatch[1].toUpperCase());
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs - any non-whitespace sequence starting with http:// or https://
  const urlPattern = /https?:\/\/\S+/g;
  
  const matches = text.match(urlPattern) || [];
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, leaving https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const urlPattern = /http:\/\/[^\s]+/g;
  
  return text.replace(urlPattern, (url) => {
    // Check if it's a docs path that should get the host rewritten
    const isHttp = url.startsWith('http://');
    if (!isHttp) {
      return url;
    }
    
    // Remove trailing punctuation from URL
    const cleanUrl = url.replace(/[.,;:!?]$/, '');
    
    // Check for dynamic hints and legacy extensions
    const hasDynamicHints = /(\?|&|=|cgi-bin)/.test(cleanUrl);
    const hasLegacyExtensions = /(\.(jsp|php|asp|aspx|do|cgi|pl|py))(\?|&|$)/.test(cleanUrl);
    
    if (hasDynamicHints || hasLegacyExtensions) {
      // Only upgrade scheme, keep original host
      return cleanUrl.replace('http://', 'https://');
    }
    
    // Parse the URL
    try {
      const parsedUrl = new URL(cleanUrl);
      
      // Check if path begins with /docs/
      if (parsedUrl.pathname.startsWith('/docs/')) {
        // Change host to docs.example.com
        const newUrl = new URL(cleanUrl);
        newUrl.protocol = 'https:';
        newUrl.host = 'docs.example.com';
        return newUrl.toString();
      } else {
        // Just upgrade scheme
        const newUrl = new URL(cleanUrl);
        newUrl.protocol = 'https:';
        return newUrl.toString();
      }
    } catch (e) {
      // If URL parsing fails, just upgrade scheme
      return cleanUrl.replace('http://', 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31, but we'll check more loosely for simplicity)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (must be 4 digits, but we already matched that)
  // Could add additional checks like year range validation
  
  return year;
}
