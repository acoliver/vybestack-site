/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with the prefix
  // Word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(word => {
    return !exceptions.includes(word);
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to match token only when preceded by a digit and not at start
  const embedPattern = new RegExp(`\\d${token}(?=\\s|$)`, 'g');
  const embedMatches = text.match(embedPattern) || [];
  
  // Return the full matches (including the digit) as expected by the test
  return embedMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must not contain immediate repeated sequences (e.g., abab)
  // Check for repeating patterns of 2-4 characters
  for (let i = 0; i < value.length - 3; i++) {
    const substring = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === substring || 
        value.substring(i + 1, i + 3) === substring) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to match IPv6 addresses (including shorthand ::)
  // This pattern is more relaxed to catch various IPv6 formats
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/i;
  
  // First check if it's a pure IPv6 pattern (no colons for IPv4)
  if (value.includes(':') && !value.match(/^\d+\.\d+\.\d+\.\d+$/)) {
    return ipv6Pattern.test(value);
  }
  
  // Explicitly check for pure IPv4 patterns and reject them
  const ipv4Pattern = /^\d+\.\d+\.\d+\.\d+$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check if value contains IPv6 patterns
  return ipv6Pattern.test(value);
}
