import type { RenderFunction, Format } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<Format, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};