#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';

import { formatters } from '../formats/index.js';
import { validateReportData } from '../utils/validation.js';
import { parseCliArgs } from '../utils/args.js';

async function main(): Promise<void> {
  try {
    const { inputFile, format, outputPath, options } = parseCliArgs();

    // Read and parse JSON input file
    const fileContent = await readFile(inputFile, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    
    // Validate the data structure
    const reportData = validateReportData(jsonData);

    // Get the appropriate formatter
    const formatter = formatters[format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Generate the report
    const output = formatter(reportData, options);

    // Write to file or stdout
    if (outputPath) {
      await writeFile(outputPath, output, 'utf-8');
      console.error(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

if (process.argv[1].endsWith('report.js') || process.argv[1].endsWith('report.ts')) {
  main();
}
