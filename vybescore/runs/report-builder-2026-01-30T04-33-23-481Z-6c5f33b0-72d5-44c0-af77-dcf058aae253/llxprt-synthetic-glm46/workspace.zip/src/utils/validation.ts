import type { ReportData } from '../types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: missing or invalid entries array');
  }

  for (const [index, entry] of reportData.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${index} is not an object`);
    }

    const entryRecord = entry as Record<string, unknown>;

    if (typeof entryRecord.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${index} has invalid label`);
    }

    if (typeof entryRecord.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${index} has invalid amount`);
    }
  }

  return reportData as unknown as ReportData;
}