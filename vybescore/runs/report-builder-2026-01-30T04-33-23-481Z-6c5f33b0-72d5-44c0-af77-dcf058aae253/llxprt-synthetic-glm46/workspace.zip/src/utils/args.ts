import type { Format, RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  options: RenderOptions;
}

export function parseCliArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  
  let format: Format = 'markdown';
  let outputPath: string | undefined;
  const options: RenderOptions = {};

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Error: --format requires a value');
      }
      const formatValue = args[++i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}. Supported formats: markdown, text`);
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Error: --output requires a value');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('Error: --format is required');
  }

  return {
    inputFile,
    format,
    outputPath,
    options,
  };
}