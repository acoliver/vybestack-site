export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove any non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    // Double every second digit (starting from the second-to-last digit)
    if (isEven) {
      digit *= 2;
      // If doubling results in a two-digit number, sum the digits
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}

/**
 * Validates email addresses according to common standards.
 * Accepts typical addresses like name@domain.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern:
  // - Local part: letters, digits, and special characters !#$%&'*+/=?^_`{|}~- and dots
  // - No consecutive dots or starting/ending with dot
  // - Domain: letters, digits, hyphens, no underscores or consecutive dots
  // - TLD: at least 2 letters
  // - Optional subdomains separated by dots
  const emailPattern = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Basic regex validation
  if (!emailPattern.test(value)) return false;
  
  // Additional validation: no consecutive dots in the entire email
  if (value.includes('..')) return false;
  
  // Additional validation: no local part starting or ending with dot
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts formats: (212) 555-7890, 212-555-7890, 2125557890
 * Supports optional +1 country code prefix.
 * Disallows impossible area codes (starting with 0 or 1).
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-numeric characters first to get just the digits
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for area code + number)
  if (digits.length < 10 || digits.length > 11) return false;
  
  // Check if there's a country code
  let digitsToValidate = digits;
  if (digits.length === 11) {
    // If it's 11 digits, it must start with 1 (US country code)
    if (!digits.startsWith('1')) return false;
    // Remove the country code and validate the remaining 10 digits
    digitsToValidate = digits.substring(1);
  }
  
  // Now we should have exactly 10 digits to validate
  if (digitsToValidate.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digitsToValidate.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Extract exchange code (next 3 digits)
  const exchangeCode = digitsToValidate.substring(3, 6);
  
  // Exchange code cannot start with 0 or 1
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  // Check if format matches one of the accepted patterns
  const validPatterns = [
    /^\(\d{3}\) \d{3}-\d{4}$/, // (212) 555-7890
    /^\(\d{3}\)\d{3}-\d{4}$/,  // (415)555-0199
    /^\d{3}-\d{3}-\d{4}$/,     // 212-555-7890
    /^\d{10}$/,                // 2125557890
    /^\d{3}\.\d{3}\.\d{4}$/,  // 212.555.7890
    /^\d{3} \d{3} \d{4}$/,    // 212 555 7890
    /^\+1 \d{3}-\d{3}-\d{4}$/, // +1 212-555-7890
    /^\+1 \(\d{3}\) \d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1\d{10}$/,             // +12125557890
    /^\+1 \d{3} \d{3} \d{4}$/, // +1 212 555 7890
    /^1 \(\d{3}\) \d{3}-\d{4}$/, // 1 (212) 555-7890
    /^1-\d{3}-\d{3}-\d{4}$/     // 1-212-555-7890
  ];
  
  return validPatterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Features:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits (leading digit 1-9)
 * - Subscriber number: 6-8 digits total
 * - When country code omitted, number must begin with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // First, normalize by removing separators
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check overall minimum length requirement
  if (normalized.length < 8) return false;
  
  // Additional validation by parsing the components
  let areaCode = '';
  let subscriberNumber = '';
  
  // Parse based on starting characters
  if (normalized.startsWith('+54')) {
    // Has country code with +
    let remaining = normalized.substring(3);
    
    // Check for mobile prefix 9
    if (remaining.startsWith('9')) {
      remaining = remaining.substring(1);
    }
    
    // Now we should have area code + subscriber digits
    // Try to extract area code (2-4 digits)
    let foundValidAreaCode = false;
    for (let len = 2; len <= 4; len++) {
      if (remaining.length >= len + 6) {
        const potentialAreaCode = remaining.substring(0, len);
        const potentialSubscriber = remaining.substring(len);
        
        // Area code must start with 1-9
        if (/^[1-9]\d*$/.test(potentialAreaCode) && 
            potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
          areaCode = potentialAreaCode;
          subscriberNumber = potentialSubscriber;
          foundValidAreaCode = true;
          break;
        }
      }
    }
    
    if (!foundValidAreaCode) return false;
  } else if (normalized.startsWith('0')) {
    // Has trunk prefix but no country code
    const remaining = normalized.substring(1);
    
    // Try to extract area code (2-4 digits)
    let foundValidAreaCode = false;
    for (let len = 2; len <= 4; len++) {
      if (remaining.length >= len + 6) {
        const potentialAreaCode = remaining.substring(0, len);
        const potentialSubscriber = remaining.substring(len);
        
        // Area code must start with 1-9
        if (/^[1-9]\d*$/.test(potentialAreaCode) && 
            potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
          areaCode = potentialAreaCode;
          subscriberNumber = potentialSubscriber;
          foundValidAreaCode = true;
          break;
        }
      }
    }
    
    if (!foundValidAreaCode) return false;
  } else {
    // Invalid - must start with country code or trunk prefix
    return false;
  }
  
  // Final validation checks
  if (!areaCode || !subscriberNumber) return false;
  
  // Area code validation: 2-4 digits, first digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number validation: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  // Additional check: ensure we don't have invalid patterns like
  // area code starting with 0 or having too many digits
  if (areaCode.startsWith('0') || subscriberNumber.length < 6) return false;
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional name formats.
 */
export function isValidName(value: string): boolean {
  // Check if value is empty or contains only whitespace
  if (!value || value.trim() === '') return false;
  
  // Name validation pattern:
  // - Allows Unicode letters (including accented characters)
  // - Allows apostrophes and hyphens (within names)
  // - Allows spaces (between name parts)
  // - Rejects digits, special symbols, and unusual patterns like "X Æ A-12"
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Check overall pattern
  if (!namePattern.test(value)) return false;
  
  // Additional validation steps
  
  // 1. No consecutive spaces, hyphens, or apostrophes
  if (/[ \-']{2,}/.test(value)) return false;
  
  // 2. Not starting or ending with space, hyphen, or apostrophe
  if (/^[ \-']+|[ \-']+$/.test(value)) return false;
  
  // 3. Must contain at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // 4. Reject patterns that look more like codes or placeholders than names
  // Check for patterns like "X Æ A-12" with lots of symbols mixed with letters
  const letterCount = (value.match(/\p{L}/gu) || []).length;
  const nonLetterCount = value.replace(/\s/g, '').length - letterCount;
  
  // If non-letter characters (mostly symbols) make up too much of the name
  if (nonLetterCount > 0 && letterCount / nonLetterCount < 2) return false;
  
  return true;
}

/**
 * Validates credit card numbers using format and Luhn checksum validation.
 * Accepts Visa, Mastercard, and American Express formats.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any non-digit characters (spaces, hyphens)
  const digits = value.replace(/\D/g, '');
  
  // Check basic length constraints
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check against major card patterns
  const patterns = [
    // Visa: 13 or 16 digits, start with 4
    {
      pattern: /^4(\d{12}|\d{15})$/,
      requiredLength: [13, 16]
    },
    // Mastercard: 16 digits, start with 51-55, 2221-2720
    {
      pattern: /^(5[1-5]\d{14}|2[2-7]\d{14})$/,
      requiredLength: [16]
    },
    // American Express: 15 digits, start with 34 or 37
    {
      pattern: /^(34|37)\d{13}$/,
      requiredLength: [15]
    }
  ];
  
  // Check if card number matches any pattern and length
  const validPattern = patterns.some(({ pattern, requiredLength }) => {
    return pattern.test(digits) && requiredLength.includes(digits.length);
  });
  
  if (!validPattern) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digits);
}
