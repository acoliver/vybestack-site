/**
 * Finds words beginning with the prefix but excluding words listed in exceptions.
 * Returns a list of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words with the given prefix
  // \b ensures we're at word boundary
  // \w* matches the rest of the word characters (letters, digits, underscore)
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'g');
  
  // Find all matches in the text
  const matches = text.match(pattern) || [];
  
  // Filter out words that are in the exceptions list
  const filtered = matches.filter(word => !exceptions.includes(word));
  
  // Return unique words to avoid duplicates
  return [...new Set(filtered)];
}

/**
 * Returns occurrences of the token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to find the token in the correct context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit followed by token (e.g., "1foo")
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Return unique matches to avoid duplicates
  return [...new Set(matches)];
}

/**
 * Validates passwords against strength requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One special character/symbol
 * - No whitespace
 * - No immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (any non-alphanumeric character)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated patterns (at least 2 characters repeating)
  // This will detect patterns like "abab", "123123", "xyxy"
  const repeatedPattern = /(...)(?=.*\1)/;
  if (repeatedPattern.test(value) && value.match(/(...)/)?.[0] === value.match(/.*(...).*\1/)?.[1]) {
    // Check if the repeated pattern is at least 2 characters
    const groups = value.match(/(.{2,})(?=.*\1)/);
    if (groups && groups.length > 1) return false;
  }
  
  // More direct approach: detect any 2+ character sequence that repeats consecutively
  const repeatedSequencePattern = /(.{2,})\1/;
  if (repeatedSequencePattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation like ::).
 * Ensures IPv4 addresses don't trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that captures full and shorthand notation
  // Supports patterns like:
  // - 2001:0db8:85a3:0000:0000:8a2e:0370:7334 (full)
  // - 2001:db8:85a3::8a2e:370:7334 (shorthand with ::)
  // - ::1 (loopback)
  // - fe80:: (link-local with trailing ::)
  // - 2001:db8:: (trailing ::)
  // - ::ffff:192.168.1.1 (IPv4-mapped IPv6)
  
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // Check for IPv4 pattern to avoid false positives
  const ipv4Pattern = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if the text contains an IPv6 address
  const hasIPv6 = ipv6Pattern.test(value);
  
  if (!hasIPv6) return false;
  
  // If we found what looks like IPv6, do a second validation to
  // make sure it's not actually an IPv4 address
  // Extract potential IPv6 address from the text
  const potentialIPv6 = value.match(ipv6Pattern);
  if (!potentialIPv6) return false;
  
  // Check each potential IPv6 address to make sure it's not actually an IPv4
  // address that happens to contain similar characters
  return potentialIPv6.some(match => {
    // Double-check that this doesn't look like an IPv4 address
    // IPv4 addresses are decimal numbers separated by dots
    // IPv6 addresses are hexadecimal numbers separated by colons
    return !ipv4Pattern.test(match[0]);
  });
}
