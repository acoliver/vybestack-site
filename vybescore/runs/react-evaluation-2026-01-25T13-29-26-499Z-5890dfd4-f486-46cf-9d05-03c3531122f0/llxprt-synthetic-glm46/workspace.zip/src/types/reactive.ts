/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Keep track of computed values that need to be re-evaluated
const computedRegistry = new WeakMap<() => void, () => void>()

export function registerComputed(getter: () => void, markDirty: () => void): void {
  computedRegistry.set(getter, markDirty)
}

export function getComputedMarkDirty(getter: () => void): (() => void) | undefined {
  return computedRegistry.get(getter)
}

// Track dependency relationships
const dependencyMap = new WeakMap<ObserverR, Set<() => void>>()

export function addDependency(observer: ObserverR, computed: () => void): void {
  let dependencies = dependencyMap.get(observer)
  if (!dependencies) {
    dependencies = new Set()
    dependencyMap.set(observer, dependencies)
  }
  dependencies.add(computed)
}

export function notifyDependents(observer: ObserverR): void {
  const dependencies = dependencyMap.get(observer)
  if (dependencies) {
    for (const computed of dependencies) {
      const markDirty = getComputedMarkDirty(computed)
      if (markDirty) {
        markDirty()
      }
    }
  }
}

export function addObserverToSubject<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.add(observer)
  
  // If observer is a computed value, track dependency
  const globalComputedObserverToGetter = (globalThis as { computedObserverToGetter?: WeakMap<ObserverR, () => void> }).computedObserverToGetter
  
  if ('updateFn' in observer && globalComputedObserverToGetter) {
    const getter = globalComputedObserverToGetter.get(observer)
    if (getter) {
      addDependency(observer, getter)
    }
  }
}

// Make addObserverToSubject available globally for callback tracking
(globalThis as Record<string, unknown>).addObserverToSubject = addObserverToSubject

export function removeObserverFromSubject<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.delete(observer)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  for (const observer of subject.observers) {
    updateObserver(observer as Observer<unknown>)
  }
}

// Global tracking for the current observer being evaluated
let activeObserver: ObserverR | null = null

export function getActiveObserver<T>(): Observer<T> | null {
  return activeObserver as Observer<T> | null
}

export function setActiveObserver<T>(observer: Observer<T> | null): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = getActiveObserver()
  setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
    // Notify any computed values that depend on this observer
    notifyDependents(observer)
  } finally {
    setActiveObserver(previous)
  }
}
