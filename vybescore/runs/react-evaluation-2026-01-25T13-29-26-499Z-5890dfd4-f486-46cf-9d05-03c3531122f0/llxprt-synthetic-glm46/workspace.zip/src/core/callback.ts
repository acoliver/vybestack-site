/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, removeObserverFromSubject, setActiveObserver, getActiveObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: `callback-${Math.random().toString(36).substr(2, 9)}`,
    value,
    updateFn,
  }
  
  // Track which subjects this observer depends on
  const dependentSubjects = new Set<Subject<unknown>>()
  
  let disposed = false
  
  // Store the global addObserverToSubject function temporarily
  const globalObj = globalThis as Record<string, unknown>
  const globalAddObserverToSubject = globalObj.addObserverToSubject as <T>(subject: Subject<T>, observer: ObserverR) => void
  
  // Override to track dependencies
  globalObj.addObserverToSubject = <T>(subject: Subject<T>, observerToAdd: ObserverR) => {
    if (observerToAdd === observer && !disposed) {
      dependentSubjects.add(subject as Subject<unknown>)
    }
    // Always call the original function
    if (globalAddObserverToSubject) {
      return globalAddObserverToSubject(subject, observerToAdd)
    }
  }
  
  // Run the callback function to establish dependencies
  const run = () => {
    if (disposed) return
    
    const previous = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      updateFn()
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Override observer update function to run the callback and manage dependencies
  observer.updateFn = () => {
    run()
    return value as T
  }
  
  // Initial run to establish dependencies
  run()
  
  // Restore original function
  globalObj.addObserverToSubject = globalAddObserverToSubject
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all dependent subjects
    dependentSubjects.forEach(subject => removeObserverFromSubject(subject, observer))
    dependentSubjects.clear()
  }
}
