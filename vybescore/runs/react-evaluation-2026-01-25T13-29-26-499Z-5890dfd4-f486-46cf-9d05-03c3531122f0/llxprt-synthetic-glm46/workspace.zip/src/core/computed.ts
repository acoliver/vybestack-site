/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  registerComputed,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track when dependencies change
  let dirty = true
  
  const compute = () => {
    if (dirty) {
      // Execute the update function while this is the active observer
      const previousActive = getActiveObserver()
      setActiveObserver(o)
      
      try {
        o.value = updateFn(o.value)
        dirty = false
      } finally {
        // Restore previous observer
        setActiveObserver(previousActive)
      }
    }
    return o.value!
  }
  
  const getter: GetterFn<T> = () => {
    const previousActive = getActiveObserver()
    setActiveObserver(o)
    
    try {
      return compute()
    } finally {
      setActiveObserver(previousActive)
    }
  }
  
  // Register this computed value in the global registry for marking dirty
  registerComputed(getter, () => { dirty = true })
  
  // Store mapping from observer to getter for dependency tracking
  const globalThisTyped = globalThis as { computedObserverToGetter?: WeakMap<Observer<T>, GetterFn<T>> }
  if (!globalThisTyped.computedObserverToGetter) {
    globalThisTyped.computedObserverToGetter = new WeakMap()
  }
  globalThisTyped.computedObserverToGetter.set(o, getter)
  
  return getter
}
