/**
 * Input closure implementation for reactive primitives.
 */

import{
  InputPair,
  Subject,
  addObserverToSubject,
  notifyObservers,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    if (observer) {
      // Register the current observer as dependent on this input
      addObserverToSubject(s, observer)
      
      // We don't need to track input-read dependencies here now
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (shouldNotify) {
      s.value = nextValue
      
      // Notify observers and trigger dependent updates
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
