import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Determine if we're running from dist or src for static files
const publicPath = __dirname.endsWith('dist')
  ? path.resolve(__dirname, '../public')
  : path.resolve(__dirname, '../public');
app.use('/public', express.static(publicPath));

// Set up EJS
app.set('view engine', 'ejs');
// Determine if we're running from dist or src
const isDist = __dirname.endsWith('dist');
const viewsPath = isDist 
  ? path.resolve(__dirname, '../src/templates')
  : path.resolve(__dirname, 'templates');
app.set('views', viewsPath);

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(code: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(code) && code.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): string[] {
  const errors: string[] = [];

  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State / Province / Region is required');
  if (!data.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and dashes');
  }
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number may only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();
  
  // Try to load existing database
  try {
    const fs = await import('node:fs');
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
      console.log('Loaded existing database from', DB_PATH);
    } else {
      db = new SQL.Database();
      console.log('Created new in-memory database');
    }
  } catch (error) {
    console.error('Error loading database:', error);
    db = new SQL.Database();
  }

  // Initialize schema
  try {
    const schema = await import('node:fs').then(fs => 
      fs.promises.readFile(SCHEMA_PATH, 'utf-8')
    );
    db.run(schema);
    console.log('Database schema initialized');
  } catch (error) {
    console.error('Error initializing schema:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    // Use dynamic import for fs to avoid require statement
    import('node:fs').then(fs => {
      const dir = path.dirname(DB_PATH);
      
      // Ensure data directory exists
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(DB_PATH, buffer);
      console.log('Database saved to', DB_PATH);
    });
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400).render('form', {
      errors,
      values: formData
    });
    return;
  }

  // Insert into database
  try {
    const stmt = db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    res.status(500).render('form', {
      errors,
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission for the greeting
  let firstName = 'friend';
  
  try {
    const result = db!.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  } catch (error) {
    console.error('Error fetching recent submission:', error);
  }
  
  res.render('thank-you', { firstName });
});

// Error handling
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
    
    // Export server for testing
    (server as { close: (callback?: () => void) => void }).close = (callback?: () => void) => {
      return new Promise<void>((resolve) => {
        server.close(() => {
          shutdown();
          if (callback) callback();
          resolve();
        });
      });
    };
    
    // Export app and server for testing
    (app as unknown as { server: typeof server }).server = server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

export { app, db };
