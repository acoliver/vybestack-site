import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

type ServerInstance = {
  close: () => Promise<void>;
};

type AppInstance = {
  server?: ServerInstance;
};

let server: ServerInstance | undefined;
let app: AppInstance | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the server module
  const module = await import('../../src/server.js');
  app = module.app as AppInstance;
  server = app.server;
  
  // Wait a bit for server to be ready
  await new Promise(resolve => setTimeout(resolve, 100));
});

afterAll(async () => {
  if (server && typeof server.close === 'function') {
    await server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form has proper action
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]')).toHaveLength(1);
    
    // Check labels are associated with inputs
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    
    // Check for submit button
    expect($('.submit, button[type="submit"]')).toHaveLength(1);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errors = $('.error-list li');
    
    // Should have multiple validation errors
    expect(errors.length).toBeGreaterThan(0);
    
    // Check that input values are preserved
    expect($('input[name="firstName"]')).toHaveLength(1);
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'not-an-email',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText.toLowerCase()).toContain('email');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'john@example.com',
        phone: 'invalid-phone@#$'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText.toLowerCase()).toContain('phone');
  });

  it('validates postal code format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'C1000@#',
        country: 'UK',
        email: 'john@example.com',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText.toLowerCase()).toContain('postal');
  });

  it('persists submission and redirects', async () => {
    // Clean up database if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 High Street',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'jane.smith@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page with user name', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Should have thank you message
    expect($('.thankyou-card')).toHaveLength(1);
    expect($('h1').text().toLowerCase()).toContain('thank');
    
    // Should have link back to form
    expect($('a[href="/"]')).toHaveLength(1);
    
    // Should mention data usage (scam warning)
    const pageText = $('.thankyou-card').text().toLowerCase();
    expect(pageText).toMatch(/identity|stranger|spam|messages/);
  });

  it('accepts international phone formats', async () => {
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+33 1 23 45 67 89'
    ];
    
    for (const phone of testCases) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone: phone
        });
      
      // Should not have phone validation error
      if (response.status === 400) {
        const $ = cheerio.load(response.text);
        const errorText = $('.error-list').text().toLowerCase();
        expect(errorText).not.toContain('phone');
      }
    }
  });

  it('accepts international postal formats', async () => {
    const testCases = [
      { postal: 'SW1A 1AA', country: 'UK' },
      { postal: 'C1000', country: 'Argentina' },
      { postal: 'B1675', country: 'Argentina' },
      { postal: '12345', country: 'USA' }
    ];
    
    for (const { postal, country } of testCases) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: postal,
          country: country,
          email: 'test@example.com',
          phone: '+1 555 123 4567'
        });
      
      // Should not have postal code validation error
      if (response.status === 400) {
        const $ = cheerio.load(response.text);
        const errorText = $('.error-list').text().toLowerCase();
        expect(errorText).not.toContain('postal');
      }
    }
  });
});
