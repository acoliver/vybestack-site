#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import type { ReportData, ReportOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

function parseArguments(): ReportOptions & { inputFile: string } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: ReportOptions & { inputFile: string } = {
    inputFile: args[0],
    format: 'markdown',
    includeTotals: false,
  };

  if (!args.includes('--format')) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format requires a value');
    process.exit(1);
  }

  const formatValue = args[formatIndex + 1];
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  result.format = formatValue;

  if (args.includes('--includeTotals')) {
    result.includeTotals = true;
  }

  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1) {
    if (outputIndex === args.length - 1) {
      console.error('Error: --output requires a path');
      process.exit(1);
    }
    result.output = args[outputIndex + 1];
  }

  return result;
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const fullPath = path.resolve(filePath);
    if (!fs.existsSync(fullPath)) {
      console.error(`Error: File not found: ${fullPath}`);
      process.exit(1);
    }

    const fileContent = fs.readFileSync(fullPath, 'utf-8');
    const data = JSON.parse(fileContent);

    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Missing or invalid title');
      process.exit(1);
    }

    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Missing or invalid summary');
      process.exit(1);
    }

    if (!Array.isArray(data.entries)) {
      console.error('Error: Missing or invalid entries array');
      process.exit(1);
    }

    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        console.error('Error: Entry missing or invalid label');
        process.exit(1);
      }

      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        console.error('Error: Entry missing or invalid amount');
        process.exit(1);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const options = parseArguments();
  const data = loadAndValidateData(options.inputFile);

  const renderer = options.format === 'markdown' ? markdownRenderer : textRenderer;
  const output = renderer.render(data, { includeTotals: options.includeTotals });

  if (options.output) {
    try {
      fs.writeFileSync(options.output, output, 'utf-8');
      console.log(`Report written to ${options.output}`);
    } catch (error) {
      console.error(`Error writing to file: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
