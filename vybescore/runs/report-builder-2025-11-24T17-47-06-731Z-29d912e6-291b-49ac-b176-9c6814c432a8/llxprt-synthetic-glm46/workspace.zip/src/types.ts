export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

export interface ReportRenderer {
  render(data: ReportData, options: { includeTotals: boolean }): string;
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}