import type { ReportData, ReportRenderer } from '../types.js';
import { formatAmount, calculateTotal } from '../types.js';

export function renderText(data: ReportData, options: { includeTotals: boolean }): string {
  let output = '';

  output += `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;

  data.entries.forEach(entry => {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  });

  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    output += `Total: ${formatAmount(total)}\n`;
  }

  return output;
}

export const textRenderer: ReportRenderer = {
  render: renderText,
};