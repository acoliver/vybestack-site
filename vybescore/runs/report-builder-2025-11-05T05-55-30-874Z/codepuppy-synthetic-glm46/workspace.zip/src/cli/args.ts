interface CliArgs {
  input: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const result: CliArgs = {
    input: args[0],
    format: '',
    includeTotals: false
  };

  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Missing format argument');
      }
      result.format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Missing output path argument');
      }
      result.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return result;
}

function validateArguments(args: CliArgs): void {
  if (!args.format) {
    throw new Error('--format is required');
  }

  if (!['markdown', 'text'].includes(args.format)) {
    throw new Error(`Unsupported format: ${args.format}`);
  }
}

export { CliArgs, parseArguments, validateArguments };