#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs';
import { Report, createReport } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseArguments, validateArguments } from './args.js';

interface Formatter {
  (report: Report, includeTotals?: boolean): string;
}

function getFormatter(format: string): Formatter {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function formatReport(report: Report, formatter: Formatter, includeTotals: boolean): string {
  return formatter(report, includeTotals);
}

async function main(): Promise<void> {
  try {
    const args = parseArguments();
    validateArguments(args);

    const data = await new Promise<string>((resolve, reject) => {
      readFile(args.input, 'utf8', (err: Error | null, data: string) => {
        if (err) {
          reject(err);
        } else {
          resolve(data);
        }
      });
    });

    let parsedData: unknown;
    try {
      parsedData = JSON.parse(data);
    } catch (error) {
      throw new Error(`Invalid JSON: ${(error as Error).message}`);
    }

    const report = createReport(parsedData);

    const formatter = getFormatter(args.format);
    const output = formatReport(report, formatter, args.includeTotals);

    if (args.output) {
      await new Promise<void>((resolve, reject) => {
        writeFile(args.output!, output, 'utf8', (err: Error | null) => {
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    process.stderr.write(`Error: ${(error as Error).message}\n`);
    process.exit(1);
  }
}

main();