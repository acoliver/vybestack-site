export interface Report {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export function createReport(data: unknown): Report {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: must be an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  const entries = reportData.entries.map((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries
  };
}