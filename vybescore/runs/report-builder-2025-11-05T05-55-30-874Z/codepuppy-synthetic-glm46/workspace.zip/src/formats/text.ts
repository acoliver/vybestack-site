import { Report } from '../types/report.js';

export function renderText(report: Report, includeTotals: boolean = false): string {
  const lines: string[] = [];

  // Title
  lines.push(report.title);
  lines.push('');

  // Summary
  lines.push(report.summary);
  lines.push('');

  // Entries heading
  lines.push('Entries:');

  // Entries list
  for (const entry of report.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }

  // Total if requested
  if (includeTotals) {
    const total = report.entries.reduce((sum: number, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}