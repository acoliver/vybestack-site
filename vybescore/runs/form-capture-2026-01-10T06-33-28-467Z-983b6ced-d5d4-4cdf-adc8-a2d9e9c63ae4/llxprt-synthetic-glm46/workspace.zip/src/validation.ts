export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<keyof FormData, string>;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};
  
  // Required field validation
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.firstName = 'First name is required';
  } else if (data.firstName.trim().length > 100) {
    errors.firstName = 'First name must be less than 100 characters';
  }
  
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.lastName = 'Last name is required';
  } else if (data.lastName.trim().length > 100) {
    errors.lastName = 'Last name must be less than 100 characters';
  }
  
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.streetAddress = 'Street address is required';
  } else if (data.streetAddress.trim().length > 200) {
    errors.streetAddress = 'Street address must be less than 200 characters';
  }
  
  if (!data.city || data.city.trim().length === 0) {
    errors.city = 'City is required';
  } else if (data.city.trim().length > 100) {
    errors.city = 'City must be less than 100 characters';
  }
  
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.stateProvince = 'State/Province/Region is required';
  } else if (data.stateProvince.trim().length > 100) {
    errors.stateProvince = 'State/Province/Region must be less than 100 characters';
  }
  
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Postal/Zip code can only contain letters, numbers, spaces, and hyphens';
  } else if (data.postalCode.trim().length > 20) {
    errors.postalCode = 'Postal/Zip code must be less than 20 characters';
  }
  
  if (!data.country || data.country.trim().length === 0) {
    errors.country = 'Country is required';
  } else if (data.country.trim().length > 100) {
    errors.country = 'Country must be less than 100 characters';
  }
  
  // Email validation
  if (!data.email || data.email.trim().length === 0) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  } else if (data.email.trim().length > 255) {
    errors.email = 'Email must be less than 255 characters';
  }
  
  // Phone validation - should accept international formats
  if (!data.phone || data.phone.trim().length === 0) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+\s()\-\d]+$/.test(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  } else if (data.phone.trim().length > 30) {
    errors.phone = 'Phone number must be less than 30 characters';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}