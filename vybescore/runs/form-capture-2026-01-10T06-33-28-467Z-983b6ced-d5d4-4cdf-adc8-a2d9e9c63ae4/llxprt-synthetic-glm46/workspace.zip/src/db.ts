import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export async function initializeDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs();
    
    // Try to load existing database
    try {
      const fileBuffer = await fs.readFile(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } catch (error) {
      // Database doesn't exist, create new one
      db = new SQL.Database();
      console.log('Created new database');
      
      // Read and execute schema
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf8');
      db.run(schema);
      console.log('Initialized database schema');
      
      // Save the new database
      await saveDatabase();
    }
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export async function saveDatabase(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    await fs.mkdir(dataDir, { recursive: true });
    
    // Save database to file
    const data = db.export();
    await fs.writeFile(dbPath, data);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export async function insertSubmission(submission: Submission): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    await saveDatabase();
    console.log('Submission saved successfully');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    throw error;
  } finally {
    stmt.free();
  }
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }
}