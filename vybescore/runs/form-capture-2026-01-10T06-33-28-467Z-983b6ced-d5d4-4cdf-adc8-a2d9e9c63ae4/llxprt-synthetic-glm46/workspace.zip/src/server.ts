import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeDatabase, insertSubmission, closeDatabase } from './db.js';
import { validateForm } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('index', {
    title: 'International Contact Form',
    formData: {},
    errors: {}
  });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!',
    firstName: req.query.firstName || 'friend'
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData = req.body;
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(200).render('index', {
        title: 'International Contact Form',
        formData,
        errors: validation.errors
      });
    }
    
    // Insert into database
    await insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });
    
    // Redirect to thank you page with first name
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('index', {
      title: 'International Contact Form',
      formData: req.body,
      errors: { general: 'An error occurred while processing your submission. Please try again.' }
    });
  }
});

// Initialize database and start server
async function startServer() {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = async () => {
      console.log('Shutting down gracefully...');
      server.close(async () => {
        await closeDatabase();
        console.log('Server closed');
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();

export default app;
