const INVALID_BASE64_MESSAGE = 'Invalid Base64 input';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if input is valid Base64 using the standard alphabet.
 */
function isValidBase64(input: string): boolean {
  // Check for valid Base64 characters (standard alphabet: A-Z, a-z, 0-9, +, /, and padding =)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Empty string is not valid Base64
  if (!input || input.length === 0) {
    return false;
  }
  
  // Check if the input contains only valid Base64 characters
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check padding: padding can only appear at the end and at most 2 '=' characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be at the end
    const padding = input.substring(paddingIndex);
    // Only '=' characters allowed for padding
    if (!/^[=]{1,2}$/.test(padding)) {
      return false;
    }
    // Total length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, accept strings with or without multiple of 4 length
    // This allows for padding-omitted Base64 strings that are still valid
    // We'll let Buffer handle the validation during decoding
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  // Validate basic format first
  if (!isValidBase64(input)) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }
  
  // Try to decode using Node's Buffer
  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify the result is valid UTF-8
    // If the input contains invalid Base64 sequences, Buffer may convert some of it
    // but we want to reject inputs with invalid characters or padding
    if (input.length % 4 === 1) {
      // Length mod 4 = 1 is never valid Base64
      throw new Error(INVALID_BASE64_MESSAGE);
    }
    
    return result;
  } catch (error) {
    // If Buffer.from fails, it's definitely invalid Base64
    throw new Error(INVALID_BASE64_MESSAGE);
  }
}
