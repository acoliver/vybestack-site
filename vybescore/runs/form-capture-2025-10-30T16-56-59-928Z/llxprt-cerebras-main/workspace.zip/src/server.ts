import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src/templates'));

// Database initialization
let db: Database;
let SQL: initSqlJs.SqlJsStatic;

async function initDatabase(): Promise<void> {
  SQL = await initSqlJs({
    locateFile: (file) => `node_modules/sql.js/dist/${file}`,
  });
  
  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.run(schema);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body;
  const errors: Record<string, string> = {};
  
  // Validation
  if (!formData.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!formData.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!formData.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!formData.postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Invalid postal code format';
  }
  
  if (!formData.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Invalid email format';
  }
  
  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Invalid phone number format';
  }
  
  // If there are errors, re-render the form with errors and previous data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }
  
  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone,
  ]);
  
  stmt.free();
  
  // Write database back to file
  const data = db.export();
  const buffer = Buffer.from(data);
  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  fs.writeFileSync(dbPath, buffer);
  
  // Redirect to thank you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen>;

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server?.close(() => {
    console.log('Express server closed');
    db?.close();
    console.log('Database closed');
    process.exit(0);
  });
});

// Export app for testing
export default app;

// Start server when file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  initDatabase().then(() => {
    server = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  }).catch((err) => {
    console.error('Failed to initialize database:', err);
    process.exit(1);
  });
}