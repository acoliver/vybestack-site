import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ReactiveNode,
  trackDependency,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const node: ReactiveNode = {
    id: Symbol(),
    name: options?.name,
    dependencies: new Set(),
    dependents: new Set(),
    dirty: true,
    update() {
      this.dirty = true
      for (const dependent of this.dependents) {
        dependent.update()
      }
    }
  }

  const observer: Observer<T> = {
    ...node,
    value,
    updateFn,
  }
  
  const getter = (): T => {
    // Track this computed value as a dependency
    trackDependency(node)
    
    // If dirty, recompute
    if (node.dirty) {
      updateObserver(observer)
    }
    
    return observer.value!
  }
  
  return getter
}