/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  ReactiveNode,
  trackDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const node: ReactiveNode = {
    id: Symbol(),
    name: options?.name,
    dependencies: new Set(),
    dependents: new Set(),
    dirty: false,
    update() {
      // Input nodes don't need to update themselves, they just notify dependents
      for (const dependent of this.dependents) {
        dependent.update()
      }
    }
  }

  const equalFn = equal === true ? (a: T, b: T) => a === b : equal as EqualFn<T>

  const read: GetterFn<T> = () => {
    trackDependency(node)
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(value, nextValue)) {
      return value
    }
    value = nextValue
    
    // Notify all dependent nodes
    node.update()
    
    return value
  }

  return [read, write]
}