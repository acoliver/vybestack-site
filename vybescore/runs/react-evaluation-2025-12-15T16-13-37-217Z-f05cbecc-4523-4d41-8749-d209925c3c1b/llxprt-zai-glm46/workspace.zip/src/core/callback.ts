/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ReactiveNode, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: (value?: T) => T, value?: T): UnsubscribeFn {
  const node: ReactiveNode = {
    id: Symbol(),
    dependencies: new Set(),
    dependents: new Set(),
    dirty: true,
    update() {
      this.dirty = true
      // Only re-run the effect if not disposed
      if (!disposed) {
        updateObserver(observer)
      }
    }
  }

  const observer: Observer<T> = {
    ...node,
    value,
    updateFn,
  }
  
  // Initial run to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this node from all its dependencies' dependents
    for (const dependency of node.dependencies) {
      dependency.dependents.delete(node)
    }
    node.dependencies.clear()
  }
  
  return unsubscribe
}