/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ReactiveNode {
  readonly id: symbol
  readonly name?: string
  readonly dependencies: Set<ReactiveNode>
  readonly dependents: Set<ReactiveNode>
  dirty: boolean
  update(): void
}

export type ObserverR = ReactiveNode

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeNode: ReactiveNode | undefined

export function getActiveNode(): ReactiveNode | undefined {
  return activeNode
}

export function setActiveNode(node: ReactiveNode | undefined): void {
  activeNode = node
}

export function createReactiveNode(name?: string): ReactiveNode {
  return {
    id: Symbol(),
    name,
    dependencies: new Set(),
    dependents: new Set(),
    dirty: true,
    update() {
      this.dirty = true
      for (const dependent of this.dependents) {
        dependent.update()
      }
    }
  }
}

export function trackDependency(node: ReactiveNode): void {
  const active = getActiveNode()
  if (active && active !== node) {
    if (!active.dependencies.has(node)) {
      active.dependencies.add(node)
      node.dependents.add(active)
    }
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = getActiveNode()
  setActiveNode(observer)
  try {
    observer.value = observer.updateFn(observer.value)
    observer.dirty = false
  } finally {
    setActiveNode(previous)
  }
}