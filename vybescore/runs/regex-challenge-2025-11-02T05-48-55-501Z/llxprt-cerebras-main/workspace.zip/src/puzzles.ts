/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix) return [];
  
  // Create a regex pattern to match words with the given prefix, excluding exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  
  // Match words starting with the prefix but not in the exceptions list
  const pattern = escapedExceptions 
    ? new RegExp(`\\b(?!${escapedExceptions}\\b)${escapedPrefix}\\w*`, 'gi')
    : new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(pattern);
  return matches || [];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token that appears after a digit and not at the beginning of the string
  const pattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(pattern);
  return matches || [];
}

/**
 * Validates passwords according to the policy.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // One uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // One lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // One digit
  if (!/\d/.test(value)) return false;
  
  // One symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., "abab")
  // This pattern looks for any sequence of 2 or more characters that repeats immediately
  if (/^(.)\1+$/.test(value) || /(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Regex for IPv6 addresses including shorthand notation (::)
  // This pattern checks for valid IPv6 formats but excludes IPv4
  const ipv6Regex = /(?:::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}|(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){7}|(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4})(?![:.\d])/g;
  
  // Check if any matches are found
  const matches = value.match(ipv6Regex);
  if (!matches) return false;
  
  // Make sure we're not matching IPv4 addresses
  // IPv4 addresses have the format xxx.xxx.xxx.xxx
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Return true if we found IPv6 matches and no IPv4 matches
  return !ipv4Regex.test(value);
}