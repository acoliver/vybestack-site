export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure
  if (!value || typeof value !== 'string') return false;
  
  // Regex for email validation
  // - Local part: alphanumeric, dots (not consecutive), plus signs, hyphens, but no trailing dot
  // - Domain part: alphanumeric, dots, hyphens but no underscores or consecutive dots, no trailing dot
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for trailing dot in local or domain part
  const [localPart, domainPart] = value.split('@');
  if (localPart.endsWith('.') || domainPart.endsWith('.')) return false;
  
  // Check for underscores in domain part
  if (domainPart.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1 prefix.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for length check
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's too short
  if (digitsOnly.length < 10) return false;
  
  // Handle optional +1 prefix
  let cleanedValue = value;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    cleanedValue = value.replace(/^\+?1/, '');
  }
  
  // Validate area code (first digit cannot be 0 or 1)
  const areaCodeMatch = cleanedValue.match(/^[\s()-]*(\d)[\s()-]*\d/);
  if (areaCodeMatch && (areaCodeMatch[1] === '0' || areaCodeMatch[1] === '1')) {
    return false;
  }
  
  // General format validation
  const phoneRegex = /^(\+?1[-\s()]?)?\(?([2-9][0-9]{2})\)?[-\s]?([2-9][0-9]{2})[-\s]?([0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for digit counting
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Covers formats like:
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const argentinePhoneRegex = /^(\+54\s?)?(0?[9]?\s?)?([1-9][0-9]{1,3})\s?([0-9]{3,4}\s?[0-9]{4}|[0-9]{6,8})$/;
  
  // Check if matches the general pattern
  if (!argentinePhoneRegex.test(value)) return false;
  
  // Extract area code and subscriber number
  // We need to clean the value to check digit counts properly
  let cleanedValue = value.replace(/[^\d+]/g, '');
  
  // If +54 is present, remove it
  if (cleanedValue.startsWith('+54')) {
    cleanedValue = cleanedValue.substring(3);
  }
  
  // Find the area code (2-4 digits starting with 1-9)
  const areaCodeMatch = cleanedValue.match(/^([1-9][0-9]{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Find subscriber number (remaining digits)
  const subscriberNumber = cleanedValue.substring(areaCodeMatch[0].length);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no +54 prefix, must start with 0
  if (!value.includes('+54') && !value.startsWith('0')) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Names can contain unicode letters, accents, apostrophes, hyphens, and spaces
  // But should not contain digits, symbols (except apostrophes and hyphens), or "X Æ A-12" style names
  const nameRegex = /^[^\d\W][\p{L}\s'-]*[^\d\W]$/u;
  
  // Check if it matches the basic pattern
  if (!nameRegex.test(value)) return false;
  
  // Special check for "X Æ A-12" style names - should reject names with numbers
  if (/\d/.test(value)) return false;
  
  // Names with just one character are valid if that character is a letter
  if (value.length === 1) return /\p{L}/u.test(value);
  
  // Additional check that it doesn't start or end with special characters
  if (value.startsWith("'") || value.startsWith('-') || value.endsWith("'") || value.endsWith('-')) return false;
  
  return true;
}

/**
 * Helper function to run Luhn algorithm on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanedValue)) return false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cleanedValue) && [13, 16, 19].includes(cleanedValue.length)) {
    return runLuhnCheck(cleanedValue);
  }
  
  // Mastercard: starts with 5[1-5] or 2[2-7], length 16
  if ((/^5[1-5]/.test(cleanedValue) || /^2[2-7]/.test(cleanedValue)) && cleanedValue.length === 16) {
    return runLuhnCheck(cleanedValue);
  }
  
  // AmEx: starts with 34 or 37, length 15
  if ((/^34/.test(cleanedValue) || /^37/.test(cleanedValue)) && cleanedValue.length === 15) {
    return runLuhnCheck(cleanedValue);
  }
  
  return false;
}