/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, collapse multiple spaces into single spaces, but preserve sentence breaks
  // Then capitalize first letter after sentence ending punctuation (.?!)
  return text
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => p1 + p2.toUpperCase()) // Capitalize first letter after sentence end
    .trim(); // Remove leading/trailing whitespace
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex to match URLs, excluding trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?(?=[\s\ufffc\ufffd\ufffe\uffff.,;!?)]|$)/g;
  
  const matches = text.match(urlRegex);
  return matches ? matches.map(url => url.replace(/[.,;!?)]+$/, '')) : []; // Remove trailing punctuation
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Replace all http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Regex to match http:// URLs with example.com host and potentially docs paths
  // Skips rewriting if path contains dynamic or legacy indicators
  return text.replace(/http:\/\/(example\.com)(\/[^\s]*)?/gi, (match, host, path = '/') => {
    // Always upgrade to https
    let result = `https://${host}`;
    
    // Check if we should rewrite the host to docs.example.com
    const shouldRewriteHost = (
      path.startsWith('/docs/') && 
      !/[?=&]/.test(path) && // No query strings
      !/\.(jsp|php|asp|aspx|do|cgi|pl|py)/.test(path) // No legacy extensions
    );
    
    if (shouldRewriteHost) {
      result = `https://docs.${host}`;
    }
    
    return result + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format with proper validation for month and day
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}