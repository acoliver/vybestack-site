/**
 * Finds words starting with the given prefix but excludes any words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Build a regex to find words that start with the prefix
  // \b matches word boundary to ensure we're getting whole words
  const wordRegex = new RegExp(`\\b(${prefix}[a-zA-Z]+)\\b`, 'g');
  
  const results: string[] = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Check if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * Finds occurrences of a token when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token to safely use it in regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex to find occurrences of token preceded by a digit
  const tokenRegex = new RegExp(`(\\d${escapedToken})(?!\\w)`, 'g');
  
  const results: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    results.push(match[1]);
  }
  
  return results;
}

/**
 * Validates passwords according to the strength policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, and no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for at least one uppercase, lowercase, digit, and symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+={}[|:";'<>?,./~-]/.test(value);
  
  // Check for whitespace
  const hasWhitespace = /\s/.test(value);
  
  // Basic password strength without complex sequence checks
  return (
    hasUppercase &&
    hasLowercase &&
    hasDigit &&
    hasSymbol &&
    !hasWhitespace
  );
}

/**
 * Detects IPv6 addresses (including shorthand format) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 pattern to exclude
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if it's IPv4 first and return false if so
  if (ipv4Regex.test(value)) return false;
  
  // IPv6 pattern that covers most common formats
  const ipv6Regex = /(?:^|[^0-9a-fA-F:])(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|::1|::)(?![0-9a-fA-F:])|/;
  
  // Check for IPv6 patterns
  return ipv6Regex.test(value);
}
