export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to typical RFC 5322 rules.
 * Accepts typical addresses such as name@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Local part: alphanumerics, dots (not consecutive or at ends), hyphens, plus, apostrophes
  // Domain part: alphanumerics, hyphens, dots (not consecutive or at ends), but no underscores
  // TLD: at least 2 characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for common invalid patterns
  // Reject consecutive dots in local part
  const consecutiveDots = /\.\./.test(value);
  // Reject local part starting or ending with dot
  const localStartEndDot = value.startsWith('.') || value.endsWith('.');
  // Reject underscore in domain
  const underscoreInDomain = /@.*_/.test(value);
  // Reject domain starting or ending with dot
  const domainStartEndDot = value.startsWith('@.') || value.endsWith('.');
  // Reject domain with consecutive dots
  const domainConsecutiveDots = /@.*\.\./.test(value);
  
  if (!value.match(emailRegex) || consecutiveDots || localStartEndDot || 
      underscoreInDomain || domainStartEndDot || domainConsecutiveDots) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Remove common separators and spaces
  let cleanValue = value.replace(/[\s\-()]/g, '');
  
  // Allow optional extensions if configured to do so
  if (options?.allowExtensions && cleanValue.includes(',')) {
    const [mainNumber] = cleanValue.split(',');
    cleanValue = mainNumber;
  }
  
  // Check for optional +1 country code
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  } else if (cleanValue.startsWith('1') && cleanValue.length > 10) {
    cleanValue = cleanValue.substring(1);
  }
  
  // After cleaning, should be exactly 10 digits
  if (!/^\d{10}$/.test(cleanValue)) return false;
  
  const areaCode = cleanValue.substring(0, 3);
  const exchangeCode = cleanValue.substring(3, 6);
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange codes cannot start with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove common separators
  const cleanValue = value.replace(/[\s\-()]/g, '');
  
  // Pattern matches:
  // Optional country code +54
  // Optional trunk prefix 0
  // Optional mobile indicator 9
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(argentinePhoneRegex);
  
  if (!match) return false;
  
  // Using match[1] and match[2] for area code and subscriber validation if needed
  // When country code is omitted, number must begin with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || !value.trim()) return false;
  
  // Check for at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject digits and certain symbols (excludingallowed apostrophes/hyphens/spaces)
  if (/[0-9@#$%^&*()_+=<>{}/\\[\]|~`]/.test(value)) return false;
  
  // Allow unicode letters, spaces, apostrophes, hyphens, and commas
  const nameRegex = /^[\p{L}\s'\-.,]+$/u;
  
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers according to Visa/Mastercard/AmEx prefixes and lengths.
 * Applies Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-5]\d|4[0-9]\d|5[0-7]\d|6[0-8]\d|7[01]\d|720)\d{12}$/;
  
  // Amex: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card number matches any of the supported formats
  if (!cleanValue.match(visaRegex) && !cleanValue.match(mastercardRegex) && !cleanValue.match(amexRegex)) {
    return false;
  }
  
  // Apply Luhn algorithm
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit and work leftwards
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    let doubled = digit;
    if (isEven) {
      doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
    }
    
    sum += doubled;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
