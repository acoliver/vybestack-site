/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 * Inserts exactly one space between sentences even if input omitted it, and collapses extra spaces.
 * Leaves abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Common abbreviations that typically appear within sentences
  const abbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|St|Ave|Blvd|Rd|Ln|etc|e\.g|i\.e|vs|fig|p|pp|vol|no|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b/gi;
  
  // First, temporarily protect abbreviations by replacing them with placeholders
  let workingText = text;
  const abbrMatches = [...workingText.matchAll(abbreviations)];
  
  const placeholderMap = new Map();
  abbrMatches.forEach((match, index) => {
    const placeholder = `__ABBR_${index}__`;
    placeholderMap.set(placeholder, match[0]);
    workingText = workingText.replace(match[0], placeholder);
  });
  
  // Split by sentence boundaries (.?!) followed by any spaces
  const sentenceRegex = /([.?!])(\s*)/g;
  const sentences = workingText.split(sentenceRegex);
  
  let result = '';
  let needsCapitalize = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // If it's a sentence terminator
    if (part && part.match(/[.?!]/)) {
      result += part + ' ';
      needsCapitalize = true;
    } else {
      // Process the actual sentence part
      if (part) {
        // Trim leading whitespace
        const trimmedPart = part.replace(/^\s+/, '');
        
        // Capitalize first letter if needed
        if (needsCapitalize && trimmedPart.length > 0) {
          const firstChar = trimmedPart[0].toUpperCase();
          const rest = trimmedPart.slice(1);
          result += firstChar + rest;
          needsCapitalize = false;
        } else {
          result += trimmedPart;
        }
      }
    }
  }
  
  // Restore abbreviations
  placeholderMap.forEach((originalAbbr, placeholder) => {
    result = result.replace(new RegExp(placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), originalAbbr);
  });
  
  // Clean up extra spaces (preserve abbreviations already restored)
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Finds URLs in the text and returns them without trailing punctuation.
 * Handles HTTP/HTTPS protocols and various domain structures.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern based on RFC 3986 with simplifications
  // Match protocol, domain, and path, query, fragment
  const urlRegex = /(https?:\/\/[^\s/$.?#].[^\s]*)([.!?,:;)]*)?/gi;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    // The main URL part is the first capture group
    const url = match[1];
    matches.push(url);
  }
  
  return matches;
}

/**
 * Forces all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https:// using a regex with word boundaries
  const httpRegex = /\bhttp:\/\//g;
  
  return text.replace(httpRegex, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to specific rules:
 * Always upgrade the scheme to https://.
 * When the path begins with /docs/, rewrite the host to docs.example.com.
 * Skip host rewrite when path contains dynamic hints or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  const result = text.replace(
    /\bhttp:\/\/(example\.com)(\/[^\s]*)/gi,
    (match, domain, path) => {
      // First, always upgrade to https
      let newUrl = 'https://' + domain;
      
      // Check if this is a docs path and should have host rewrite
      const shouldRewriteHost = 
        path.startsWith('/docs/') && 
        // Skip dynamic or legacy paths
        !path.match(/(cgi-bin|\?|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i);
      
      if (shouldRewriteHost) {
        newUrl = 'https://docs.' + domain;
      }
      
      // Append the path
      return newUrl + path;
    }
  );
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format doesn't match or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match the mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12) return 'N/A';
  
  // Simple day validation - check for days 1-31 (we'll skip comprehensive month-specific validation)
  if (day < 1 || day > 31) return 'N/A';
  
  return year;
}
