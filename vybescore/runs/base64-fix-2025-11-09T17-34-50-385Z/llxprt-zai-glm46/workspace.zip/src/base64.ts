/**
 * Encode plain text to Base64 using canonical RFC 4648 Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Trim whitespace first
  const trimmedInput = input.trim();
  
  // Reject empty input after trimming
  if (trimmedInput === '') {
    throw new Error('Invalid Base64 input');
  }
  
  // Basic pattern validation for clearly invalid input
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(trimmedInput)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const result = Buffer.from(trimmedInput, 'base64').toString('utf8');
    
    // Additional validation: if the input contains non-base64 characters, Buffer might not fail
    // So we re-encode the result and compare to ensure round-trip consistency
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Normalize both by removing padding for comparison
    const normalizedInput = trimmedInput.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}