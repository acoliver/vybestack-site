/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else if (equal) {
    equalFn = equal
  } else {
    equalFn = (a, b) => a === b
  }

  // Store all observers that depend on this input
  const subjectObservers = new Set<Observer<T>>()

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: subjectObservers,
  }

  const read: GetterFn<T> = () => {
    // Register the current observer as a dependency
    const observer = getActiveObserver()
    if (observer) {
      // Set this input as a dependency of the observer
      subjectObservers.add(observer)
      
      // Add this subject to the observer's dependencies
      if (observer.dependingSubjects) {
        observer.dependingSubjects.add(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if values are different based on equality function
    if (equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all dependent observers
    // Create a copy to avoid issues with modification during iteration
    const observers = Array.from(subjectObservers)
    observers.forEach(observer => {
      // Check if observer is still valid and not disposed
      if (!observer.disposed && subjectObservers.has(observer)) {
        updateObserver(observer)
      }
    })
    
    return s.value
  }

  return [read, write]
}