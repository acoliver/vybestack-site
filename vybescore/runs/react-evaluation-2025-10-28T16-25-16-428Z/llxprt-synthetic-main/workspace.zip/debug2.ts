import { createInput, createComputed, createCallback } from './src/index.js'

console.log('\n--- Debug callback subscription tracking ---')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log('Initial: input=', input(), ', output=', output())

const values1: number[] = []
const values2: number[] = []

console.log('\nSetting up callbacks...')
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 fired: output=', output())
  values1.push(output())
})

const unsubscribe2 = createCallback(() => {
  console.log('Callback 2 fired: output=', output())
  values2.push(output())
})

console.log('After setup: values1=', values1, ', values2=', values2)
console.log('Setting input to 2...')
setInput(2)
console.log('After setInput(2): values1=', values1, ', values2=', values2)

console.log('\nUnsubscribing callback 1...')
unsubscribe1()
console.log('Setting input to 3...')
setInput(3)
console.log('After setInput(3) and unsubscribe: values1=', values1, ', values2=', values2)

console.log('\nExpected: values1 should have one more element than values2')