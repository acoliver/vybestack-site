import { createInput, createComputed, createCallback } from './src/index.js'

console.log('\n--- Direct test from failing test ---')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
console.log('Before callback: value =', value, 'input =', input(), 'output =', output())
createCallback(() => (value = output()))
console.log('After callback: value =', value)
setInput(3)
console.log('After setInput(3): value =', value, 'expected: 4')

console.log('\n--- Unsubscribe test ---')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output2()))
const values2: number[] = []
createCallback(() => values2.push(output2()))

setInput2(31)
console.log('After setInput2(31): values1.length =', values1.length, 'values2.length =', values2.length)

unsubscribe1()
setInput2(41)
console.log('After unsubscribe and setInput2(41): values1.length =', values1.length, 'values2.length =', values2.length)
console.log('Expected: values2.length > values1.length')