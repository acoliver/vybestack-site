import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Debug test: Investigating subjects and observers')

// Simple input test
console.log('\n--- Simple input test ---')
const [input, setInput] = createInput(11)
console.log('Initial input:', input())
console.log('Setting input to 31')
setInput(31)
console.log('After setInput, input:', input())

// Computed test
console.log('\n--- Computed test ---')
const output = createComputed(() => input() + 1)
console.log('Initial output:', output())

// Callback test
console.log('\n--- Callback test ---')
const values1: number[] = []
const values2: number[] = []

const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 triggered, output:', output())
  values1.push(output())
})

const unsubscribe2 = createCallback(() => {
  console.log('Callback 2 triggered, output:', output())
  values2.push(output())
})

console.log('Before setInput(41):')
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nSetting input to 41')
setInput(41)

console.log('After setInput(41):')
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nUnsubscribing callback 1')
unsubscribe1()

console.log('\nSetting input to 51')
setInput(51)

console.log('After unsubscribe and setInput:')
console.log('values1:', values1)
console.log('values2:', values2)