import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;
let db: Database | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
const validateForm = (values: FormValues): ValidationError[] => {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!values.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!values.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!values.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!values.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!values.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }
  
  if (!values.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  }
  
  if (!values.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!values.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!isValidEmail(values.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!values.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!isValidPhone(values.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  return errors;
};

const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const isValidPhone = (phone: string): boolean => {
  // Accept international formats: digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?\d[\d\s\-()]*$/;
  return phoneRegex.test(phone) && phone.replace(/[^\d+]/g, '').length >= 7;
};

// Database initialization
const initializeDatabase = async (): Promise<void> => {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    let dbData: Uint8Array | null = null;
    
    // Load existing database if it exists
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      dbData = new Uint8Array(dbBuffer);
    }
    
    db = new SQL.Database(dbData);
    
    // Create table if it doesn't exist
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
};

// Save database to disk
const saveDatabase = (): void => {
  if (!db) return;
  
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    values: {}, 
    errors: [] 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  if (!db) {
    res.status(500).send('Database not initialized');
    return;
  }

  const values: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateForm(values);

  if (errors.length > 0) {
    // Return form with errors
    res.status(400).render('form', {
      values,
      errors: errors.map(e => e.message)
    });
    return;
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      values.firstName || '',
      values.lastName || '',
      values.streetAddress || '',
      values.city || '',
      values.stateProvince || '',
      values.postalCode || '',
      values.country || '',
      values.email || '',
      values.phone || ''
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      values,
      errors: ['An error occurred while saving your submission. Please try again.']
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // For now, we'll use a generic first name since we don't have session state
  // In a real app, you might get this from a session or query parameter
  res.render('thank-you', { firstName: 'friend' });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    values: {},
    errors: ['An unexpected error occurred. Please try again.']
  });
});

// Graceful shutdown
const gracefulShutdown = (signal: string) => {
  console.log(`\nReceived ${signal}, shutting down gracefully...`);
  
  if (db) {
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
const startServer = async () => {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer().catch(console.error);