#!/usr/bin/env node

import * as fs from 'node:fs';
import { parseJsonFile, validateReportData } from '../utils.js';
import { getFormatter } from '../formatters.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 1) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('Missing required argument: --format <format>');
  }
  const format = args[formatIndex + 1];

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  return { inputFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const rawData = parseJsonFile(args.inputFile);
    const data = validateReportData(rawData);

    const formatter = getFormatter(args.format);
    const output = formatter(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();

