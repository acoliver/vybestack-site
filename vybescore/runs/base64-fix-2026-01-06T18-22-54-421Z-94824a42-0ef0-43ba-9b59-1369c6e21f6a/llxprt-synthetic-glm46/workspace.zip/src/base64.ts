/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes padding '=' characters when required for compliance.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws an error for clearly invalid Base64.
 */
export function decode(input: string): string {
  // Check for clearly invalid characters
  const invalidChars = input.match(/[^A-Za-z0-9+/=]/g);
  if (invalidChars) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding (max 2 '=' characters at the end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.slice(paddingIndex);
    if (padding.length > 2 || !/^(=+)?$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
