import { describe, expect, it } from 'vitest';
import request from 'supertest';
import app from '../../src/server';
import fs from 'node:fs';
import path from 'node:path';

// let app: any; // Imported from server module
const dbPath = path.resolve('data', 'submissions.sqlite');

// beforeAll/afterAll are not needed as server is already handled in server.ts

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(app)
      .get('/')
      .expect(200);
    
    expect(res.text).toContain('Get in Touch!');
    expect(res.text).toContain('first_name');
    expect(res.text).toContain('last_name');
    expect(res.text).toContain('email');
    expect(res.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    // Clean up existing database file
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Test City',
      state_province: 'Test State',
      postal_code: 'ABC123',
      country: 'Test Country',
      email: 'test@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form data
    await request(app)
      .post('/submit')
      .type('form')
      .send(formData)
      .expect(302);
    
    // Check if database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow redirect to thank you page
    await request(app)
      .get('/thank-you')
      .expect(200)
      .expect((res) => {
        expect(res.text).toContain('Thank You');
        expect(res.text).toContain('super secure');
      });
  });
});
