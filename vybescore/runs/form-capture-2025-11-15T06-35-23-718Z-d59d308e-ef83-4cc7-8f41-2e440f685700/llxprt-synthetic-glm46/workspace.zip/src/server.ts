import express, { Request, Response } from "express";
import * as fs from "fs";
import * as path from "path";

import { createRequire } from "node:module";
const require = createRequire(import.meta.url);

// Type definition for sql.js module
type SqlJsInitializer = () => Promise<SqlJs>;
interface SqlJs {
  Database: new (data?: Uint8Array) => Database;
}

// Load sql.js dynamically at runtime
let initSqlJs: SqlJsInitializer;
async function loadSqlJs(): Promise<void> {
  try {
    initSqlJs = require("sql.js");
  } catch (error) {
    console.error("Failed to load sql.js:", error);
    throw error;
  }
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware to parse request bodies
app.use(express.urlencoded({ extended: false }));
app.use(express.json());


const DB_PATH = path.join(process.cwd(), "data/submissions.sqlite");
const SQL_SCHEMA_PATH = path.join(process.cwd(), "db/schema.sql");
const TEMPLATES_PATH = path.join(process.cwd(), "src/templates");
const PUBLIC_PATH = path.join(process.cwd(), "public");

let db: Database | null = null;

// Interface for form submission
interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Interface for validation errors
interface ValidationError {
  [key: string]: string;
}

// Database type reference using sql.js
interface Database {
  run(sql: string, args?: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(args?: unknown[]): unknown;
  free(): void;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    await loadSqlJs();
    const SQL = await initSqlJs();
    
    let dbBuffer: Uint8Array = new Uint8Array([]);

    // Load existing database if it exists
    if (fs.existsSync(DB_PATH)) {
      dbBuffer = fs.readFileSync(DB_PATH);
    }

    // Initialize database
    db = new SQL.Database(dbBuffer);

    // Create tables if they don't exist
    if (fs.existsSync(SQL_SCHEMA_PATH)) {
      const schema = fs.readFileSync(SQL_SCHEMA_PATH, "utf8");
      db.run(schema);
    }
  } catch (error) {
    console.error("Failed to initialize database:", error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;

  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error("Failed to save database:", error);
  }
}

// Close database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Validate form submission
function validateForm(data: FormSubmission): ValidationError {
  const errors: ValidationError = {};

  // Required fields
  const requiredFields = [
    "first_name",
    "last_name",
    "street_address",
    "city",
    "state_province",
    "postal_code",
    "country",
    "email",
    "phone",
  ];

  requiredFields.forEach((field) => {
    if (!data[field as keyof FormSubmission] || data[field as keyof FormSubmission].trim() === "") {
      errors[field] = `${field.replace(/_/g, " ")} is required`;
    }
  });

  // Email validation (simple regex)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = "Please enter a valid email address";
  }

  // Phone validation (international formats)
  if (data.phone && !/^\+?[0-9\s()-]+$/.test(data.phone)) {
    errors.phone = "Please enter a valid phone number";
  }

  // Postal code validation (alphanumeric)
  if (data.postal_code && !/^[a-zA-Z0-9\s-]+$/.test(data.postal_code)) {
    errors.postal_code = "Please enter a valid postal/zip code";
  }

  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(PUBLIC_PATH));
app.set("view engine", "ejs");
app.set("views", TEMPLATES_PATH);

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("form", { errors: {}, data: {} });
});

app.post("/submit", (req: Request, res: Response) => {
  const formData = req.body as FormSubmission;
  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render("form", { errors, data: formData });
  }

  try {
    if (!db) throw new Error("Database not initialized");

    // Insert submission into database
    const stmt = (db as Database).prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();
    saveDatabase();

    res.redirect("/thank-you");
  } catch (error) {
    console.error("Error submitting form:", error);
    res.status(500).render("form", {
      errors: { general: "An error occurred while submitting the form" },
      data: formData,
    });
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  res.render("thank-you");
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log("Shutting down gracefully...");
  closeDatabase();
  process.exit(0);
}

process.on("SIGTERM", gracefulShutdown);
process.on("SIGINT", gracefulShutdown);

// Start server
async function startServer() {
  try {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

// Only start server if this file is run directly (not imported by tests)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

// Workaround for sql.js in Node.js
// This is needed for the sql.js package to work properly in a Node.js environment
if (typeof window === "undefined") {
  // @ts-expect-error - Adding global window for sql.js compatibility
  global.window = {};
}

// Initialize database when importing the module (for tests)
initializeDatabase().catch(error => {
  console.error("Failed to initialize database on import:", error);
});

export { app };
export default app;