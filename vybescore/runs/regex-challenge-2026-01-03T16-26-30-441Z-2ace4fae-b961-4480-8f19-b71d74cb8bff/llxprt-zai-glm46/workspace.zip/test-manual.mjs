import { 
  isValidEmail, 
  isValidUSPhone, 
  isValidArgentinePhone, 
  isValidName, 
  isValidCreditCard 
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== Comprehensive Manual Tests ===\n');

// Validators
console.log('--- VALIDATORS ---');
console.log('Email name+tag@example.co.uk:', isValidEmail('name+tag@example.co.uk'));
console.log('Email user@domain_.com (underscore):', isValidEmail('user@domain_.com'));
console.log('Email user..name@example.com (double dot):', isValidEmail('user..name@example.com'));

console.log('\nUS Phone (212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('US Phone 012-555-7890 (bad area):', isValidUSPhone('012-555-7890'));
console.log('US Phone 212-055-7890 (bad exchange):', isValidUSPhone('212-055-7890'));

console.log('\nAR Phone +54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('AR Phone +54 011 1234 5678 (trunk with country):', isValidArgentinePhone('+54 011 1234 5678'));

console.log('\nName José María:', isValidName('José María'));
console.log('Name X Æ A-12:', isValidName('X Æ A-12'));

console.log('\nCC Visa (valid Luhn):', isValidCreditCard('4111111111111111'));
console.log('CC Visa (bad Luhn):', isValidCreditCard('4111111111111112'));

// Transformations
console.log('\n--- TRANSFORMATIONS ---');
console.log('Capitalize:', capitalizeSentences('hello.how are you?'));
console.log('Capitalize abbrev:', capitalizeSentences('dr. smith is here. hello world'));

console.log('\nExtract URLs:', extractUrls('Visit http://example.com/path and https://test.org today!'));
console.log('Enforce HTTPS:', enforceHttps('Go to http://example.com'));

console.log('\nRewrite docs:', rewriteDocsUrls('See http://example.com/docs/guide'));
console.log('Rewrite dynamic:', rewriteDocsUrls('See http://example.com/docs/api.jsp?id=1'));

console.log('\nExtract year 01/31/2024:', extractYear('01/31/2024'));
console.log('Extract year 13/01/2024:', extractYear('13/01/2024'));

// Puzzles
console.log('\n--- PUZZLES ---');
console.log('Prefixed words:', findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));

console.log('\nEmbedded token:', findEmbeddedToken('xfoo 1foo foo', 'foo'));

console.log('\nStrong password Abcdef!234:', isStrongPassword('Abcdef!234'));
console.log('Strong password ababABAB1!:', isStrongPassword('ababABAB1!'));

console.log('\nIPv6 2001:db8::1:', containsIPv6('2001:db8::1'));
console.log('IPv6 ::1:', containsIPv6('::1'));
console.log('IPv6 12:30:45 (time):', containsIPv6('12:30:45'));
console.log('IPv6 example.com:8080:', containsIPv6('example.com:8080'));

console.log('\n=== All tests completed ===');
