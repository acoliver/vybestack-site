/**
 * Find words starting with the given prefix but excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create pattern to match words with the prefix
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));

  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookahead/lookbehind to ensure proper positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match digit + token, but not at the start of the string
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to strength policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Minimum length
  if (value.length < 10) return false;

  // No whitespace
  if (/\s/.test(value)) return false;

  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // At least one digit
  if (!/\d/.test(value)) return false;

  // At least one symbol
  const symbolRegex = new RegExp('[!@#$%^&*()_+\\-={};:\'"\\|,.<>/?\\[\\]]');
  if (!symbolRegex.test(value)) return false;

  // Check for repeated sequences (e.g., abab, 123123)
  // Look for patterns of 2-4 characters that repeat
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) return false;

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Must contain at least one colon for IPv6 notation
  if (!value.includes(':')) return false;

  // IPv6 pattern - matches valid IPv6 formats while excluding:
  // - Time strings like "12:30:45" or "1:2:3"
  // - URL ports like "example.com:8080"
  // - Single colons like "test:"
  
  // Valid IPv6 must have either:
  // - At least 3 colons (minimum for valid IPv6)
  // - Double colon :: shorthand
  // - Hex digits 0-9, a-f, A-F (not decimal like time or port numbers)
  
  const colonCount = (value.match(/:/g) || []).length;
  
  // Single or double colon is not enough for IPv6 (exclude ports, single colons)
  // But :: is valid for IPv6
  if (colonCount < 2 && !value.includes('::')) return false;
  
  // For 2 colons, must be :: shorthand or have hex digits
  if (colonCount === 2 && !value.includes('::')) return false;

  // Check if it looks like time (digits separated by single colons)
  const timePattern = /^\d{1,2}:\d{2}(:\d{2})?$/;
  if (timePattern.test(value.trim())) return false;

  // Check if it looks like URL with port (domain:port pattern)
  const portPattern = /^[a-zA-Z0-9.-]+:\d+$/;
  if (portPattern.test(value.trim())) return false;

  // IPv6 pattern: hex groups separated by colons, may contain ::
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}|::|[0-9a-fA-F]{1,4}::/;

  const hasIPv6 = ipv6Pattern.test(value);

  if (!hasIPv6) return false;

  // Exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value.trim())) return false;

  return true;
}
