export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical formats like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const emailRegex = /^[a-zA-Z0-9]+([._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;

  if (!emailRegex.test(value)) return false;

  const [localPart, domain] = value.split('@');

  // Reject double dots
  if (/\.\./.test(value)) return false;

  // Reject trailing dots
  if (localPart.endsWith('.') || domain.endsWith('.')) return false;

  // Reject leading dots
  if (localPart.startsWith('.')) return false;

  // Reject domains with underscores
  if (domain.includes('_')) return false;

  // Reject if local part or domain starts/ends with dot
  if (/^[.-]|[.-]$/.test(localPart) || /^[.-]|[.-]$/.test(domain)) return false;

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0 or 1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const cleaned = value.replace(/[\s\-()]/g, '');

  let digits = cleaned;

  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    digits = digits.slice(1);
  }

  if (!/^\d{10}$/.test(digits)) return false;

  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Exchange code (first digit of central office code) cannot be 0 or 1
  const exchangeCode = digits[3];
  if (exchangeCode === '0' || exchangeCode === '1') return false;

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (without country code)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline without country code)
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const cleaned = value.replace(/[\s-]/g, '');

  const argentinaPhoneRegex = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;

  if (!argentinaPhoneRegex.test(cleaned)) return false;

  const match = cleaned.match(argentinaPhoneRegex);
  if (!match) return false;

  const [, countryCode, , areaCode, subscriberNumber] = match;

  // If country code is omitted, must have trunk prefix 0 before area code
  if (!countryCode && !areaCode.startsWith('0')) return false;

  // If country code is present, area code should not start with 0
  if (countryCode && areaCode.startsWith('0')) return false;

  const actualAreaCode = countryCode ? areaCode : areaCode.slice(1);

  // Area code must be 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(actualAreaCode)) return false;

  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and strange formats like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) return false;

  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;

  // Reject names with digits
  if (/\d/.test(value)) return false;

  // Reject names with symbols (other than apostrophe, hyphen, space)
  const invalidSymbols = new Set(['!', '"', '#', '$', '%', '&', '*', '+', ',', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', '(', ')']);
  for (const char of value) {
    if (invalidSymbols.has(char)) return false;
  }

  // Reject names that look like "X Æ A-12" (mix of letters, numbers, symbols in strange ways)
  if (/\w.*\d/.test(value)) return false;

  return true;
}

/**
 * Luhn checksum algorithm helper.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const cleaned = value.replace(/\s/g, '');

  if (!/^\d{13,19}$/.test(cleaned)) return false;

  const prefixes = {
    visa: /^4/,
    mastercard: /^5[1-5]/,
    amex: /^3[47]/
  };

  let isValid = false;

  if (prefixes.visa.test(cleaned)) {
    isValid = cleaned.length === 13 || cleaned.length === 16;
  } else if (prefixes.mastercard.test(cleaned)) {
    isValid = cleaned.length === 16;
  } else if (prefixes.amex.test(cleaned)) {
    isValid = cleaned.length === 15;
  }

  if (!isValid) return false;

  return runLuhnCheck(cleaned);
}
