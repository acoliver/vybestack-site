/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (.?!)
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces while preserving single spaces between words
 * - Preserves abbreviations when possible (e.g., "Dr." in middle of text)
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Common abbreviations that shouldn't trigger sentence capitalization
  const abbreviations = ['Dr', 'Mr', 'Mrs', 'Ms', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'etc'];

  // First, normalize spacing: collapse multiple spaces to one
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Ensure exactly one space after sentence-ending punctuation
  normalized = normalized.replace(/([.!?])\s*/g, '$1 ').trim();

  // Capitalize first character of the string
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);

  // Capitalize after sentence-ending punctuation, but skip abbreviations
  const capitalizeAfterPunctuation = (str: string): string => {
    return str.replace(/([.!?]\s+)([a-z])/g, (match, prefix, char) => {
      // Check if the preceding word might be an abbreviation
      const beforePunctuation = str.slice(0, str.indexOf(match));
      const lastWordMatch = beforePunctuation.match(/(\w+)\.\s*$/);

      if (lastWordMatch) {
        const lastWord = lastWordMatch[1];
        if (abbreviations.includes(lastWord)) {
          return prefix + char; // Don't capitalize after abbreviation
        }
      }

      return prefix + char.toUpperCase();
    });
  };

  return capitalizeAfterPunctuation(normalized);
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL pattern matching http/https URLs
  const urlPattern = /https?:\/\/[^\s<>"{}|^`[\]]+[^\s<>"{}|^`[\].,!?;:]/g;

  const matches = text.match(urlPattern) || [];

  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade the scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  return text.replace(/https?:\/\/example\.com(\/[^\s<>"{}|^`[\]]*)/g, (match, path) => {
    // Always upgrade to https
    const secureMatch = match.replace(/^http:/, 'https:');

    // Check if path contains dynamic hints
    const dynamicHints = [
      'cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp',
      '.aspx', '.do', '.cgi', '.pl', '.py'
    ];

    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));

    // If docs path and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      return `https://docs.example.com${path}`;
    }

    // Otherwise just upgrade the scheme
    return secureMatch;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

  if (!dateMatch) return 'N/A';

  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Allow Feb 29 for leap year simplicity

  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';

  return yearStr;
}
