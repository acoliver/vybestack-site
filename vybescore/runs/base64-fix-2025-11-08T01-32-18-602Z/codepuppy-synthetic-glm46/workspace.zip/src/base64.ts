/**
 * Encode plain text to Base64 using RFC 4648 canonical format.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and throws errors for invalid input.
 */
export function decode(input: string): string {
  // Validate that input contains only valid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Remove whitespace and validate padding pattern
  const trimmed = input.trim();
  const paddingIndex = trimmed.indexOf('=');
  
  if (paddingIndex !== -1) {
    // If padding exists, it must be at the end and can be 1 or 2 '=' characters
    const padding = trimmed.slice(paddingIndex);
    if (!/^={1,2}$/.test(padding) || paddingIndex < trimmed.length - 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(trimmed, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
