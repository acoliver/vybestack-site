/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  dependencies?: (() => void)[]
  unsubscribe?: () => void
}

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
  observers?: ObserverR[]
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const dependencyStack: Observer<unknown>[] = []

// Track dependencies between subjects and observers
export const subjectDependencyMap = new Map<SubjectR, Set<Observer<unknown>>>()
export const observerDependencyMap = new Map<Observer<unknown>, Set<SubjectR>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function beginDependencyTracking(observer: Observer<unknown>): void {
  dependencyStack.push(observer)
  activeObserver = observer
}

export function endDependencyTracking(): void {
  dependencyStack.pop()
  activeObserver = dependencyStack.length > 0 
    ? dependencyStack[dependencyStack.length - 1] 
    : undefined
}

export function getCurrentObserver(): Observer<unknown> | undefined {
  return dependencyStack[dependencyStack.length - 1]
}

export function addDependency(dependent: Observer<unknown>): void {
  const observer = getCurrentObserver()
  if (observer && observer.dependencies) {
    const updateDependent = () => updateObserver(dependent)
    
    // Prevent duplicate dependencies
    if (!observer.dependencies.includes(updateDependent)) {
      observer.dependencies.push(updateDependent)
    }
  }
}

export function trackSubjectDependency(subject: SubjectR): void {
  const observer = getCurrentObserver()
  if (!observer) return
  
  // Track subject -> observer relationship
  if (!subjectDependencyMap.has(subject)) {
    subjectDependencyMap.set(subject, new Set())
  }
  const observerSet = subjectDependencyMap.get(subject)!
  observerSet.add(observer)
  
  // Track observer -> subject relationship
  if (!observerDependencyMap.has(observer)) {
    observerDependencyMap.set(observer, new Set())
  }
  const subjectSet = observerDependencyMap.get(observer)!
  subjectSet.add(subject)
}

export function notifySubjectDependencies(subject: SubjectR): void {
  const observerSet = subjectDependencyMap.get(subject)
  if (!observerSet) return
  
  // Create a copy to avoid issues with modifications during iteration
  const observerCopy = new Set(observerSet)
  
  // Update each dependent observer directly
  for (const observer of observerCopy) {
    // Skip disposed observers
    if (observer.unsubscribe) continue
    updateObserver(observer)
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  // Convert to Observer<unknown> to match the type system
  const unknownObserver = observer as unknown as Observer<unknown>
  activeObserver = unknownObserver
  try {
    // Clear previous subject dependencies before updating
    const oldSubjectDeps = observerDependencyMap.get(unknownObserver)
    if (oldSubjectDeps) {
      // For each subject this observer depends on, remove this observer from its dependency set
      for (const subject of oldSubjectDeps) {
        const subjectObservers = subjectDependencyMap.get(subject)
        if (subjectObservers) {
          subjectObservers.delete(unknownObserver)
        }
      }
      // Clear all tracked dependencies for this observer
      oldSubjectDeps.clear()
    }
    
    // Recompute value, which will track new dependencies
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Trigger dependent updates after the value is updated
  if (observer.dependencies && observer.dependencies.length > 0) {
    // Create a copy to avoid potential issues with modifications during iteration
    const deps = [...(observer.dependencies || [])]
    for (const updateFn of deps) {
      try {
        updateFn()
      } catch (e) {
        console.error('Error updating dependency:', e)
      }
    }
  }
}