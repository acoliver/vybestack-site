/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  beginDependencyTracking,
  endDependencyTracking
} from '../types/reactive.js'

// Import the maps directly to avoid circular references
import { observerDependencyMap, subjectDependencyMap } from '../types/reactive.js'

// Helper function to type cast Observer<T> to Observer<unknown>
function observerAsUnknown<T>(observer: Observer<T>): Observer<unknown> {
  return observer as unknown as Observer<unknown>
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let lastValue: T | undefined = value
  
  const observer: Observer<T> = {
    name: 'callback',
    value: lastValue,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue!
      const result = updateFn(prevValue)
      lastValue = result
      return result
    },
    dependencies: [],
    unsubscribe: undefined  // Will be set to a function when disposed
  }
  
  // Track dependencies by triggering observer initialization
  // This will track any inputs/computed values accessed in the updateFn
  const unknownObserver = observerAsUnknown(observer)
  beginDependencyTracking(unknownObserver)
  try {
    updateObserver(unknownObserver)
  } finally {
    endDependencyTracking()
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark as disposed to prevent further updates
    observer.unsubscribe = () => {} // This is our disposal marker
    
    // Clean up dependency mappings
    const subjectDeps = observerDependencyMap.get(unknownObserver)
    if (subjectDeps) {
      // Remove this observer from all subject dependency sets
      for (const subject of subjectDeps) {
        const subjectObservers = subjectDependencyMap.get(subject)
        if (subjectObservers) {
          subjectObservers.delete(unknownObserver)
        }
      }
      // Clear all tracked subject dependencies for this observer
      subjectDeps.clear()
    }
    
    // Remove from observer dependency map entirely
    observerDependencyMap.delete(unknownObserver)
    
    // Clear the observer's own dependencies
    observer.dependencies = []
  }
}