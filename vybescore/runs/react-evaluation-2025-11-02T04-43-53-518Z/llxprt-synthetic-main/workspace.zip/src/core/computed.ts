/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  addDependency,
  beginDependencyTracking,
  endDependencyTracking
} from '../types/reactive.js'

// Helper function to type cast Observer<T> to Observer<unknown>
function observerAsUnknown<T>(observer: Observer<T>): Observer<unknown> {
  return observer as unknown as Observer<unknown>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const _createEqualFn = (): EqualFn<T> | undefined => {
    if (equal === true) {
      return (a: T, b: T): boolean => a === b
    }
    
    if (equal === false || equal === undefined) {
      return undefined
    }
    
    return equal as EqualFn<T>
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: []
  }

  let isInitialized = false
  
  // Initialize value once
  if (o.value === undefined) {
    beginDependencyTracking(observerAsUnknown(o))
    try {
      o.value = updateFn(o.value)
      isInitialized = true
    } finally {
      endDependencyTracking()
    }
  }
  
  const getter: GetterFn<T> = () => {
    // Start tracking dependencies if there's an active observer
    const observer = getActiveObserver()
    if (observer) {
      // Add this computed observer as a dependency
      addDependency(observerAsUnknown(o))
      
      // Re-compute when accessed in a reactive context
      beginDependencyTracking(observerAsUnknown(o))
      try {
        o.value = updateFn(o.value)
      } finally {
        endDependencyTracking()
      }
    } else if (!isInitialized) {
      // Initialize if not done yet
      beginDependencyTracking(observerAsUnknown(o))
      try {
        o.value = updateFn(o.value)
        isInitialized = true
      } finally {
        endDependencyTracking()
      }
    }
    
    return o.value! as T
  }
  
  return getter
}