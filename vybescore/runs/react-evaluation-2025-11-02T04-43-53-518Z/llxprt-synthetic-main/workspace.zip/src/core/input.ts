/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  trackSubjectDependency,
  notifySubjectDependencies,
  SubjectR
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const createEqualFn = (): EqualFn<T> | undefined => {
    if (equal === true) {
      return (a: T, b: T): boolean => a === b
    }
    
    if (equal === false || equal === undefined) {
      return undefined
    }
    
    return equal as EqualFn<T>
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: createEqualFn(),
  }

  const read: GetterFn<T> = () => {
    // Track this subject as a dependency for the active observer
    trackSubjectDependency(s as SubjectR)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    let shouldNotify = true
    
    if (s.equalFn) {
      shouldNotify = !s.equalFn(s.value, nextValue)
    }
    
    if (shouldNotify) {
      s.value = nextValue
      // Notify all dependent observers immediately
      notifySubjectDependencies(s as SubjectR)
    }
    
    return s.value
  }

  return [read, write]
}
