/**
 * Type definitions for the reactive programming system.
 */



export type EqualFn<T> = (lhs: T, rhs: T) => boolean
// Type declaration for globalThis extension
declare global {
  interface GlobalThisWithActiveObserver {
    __activeObserver?: ObserverR
  }
}

const globalThisWithObserver = globalThis as GlobalThisWithActiveObserver


export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: ObserverR[] // Support multiple observers for proper subscription management
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updateDepth = 0
const updateStack: ObserverR[] = []

export function getActiveObserver(): ObserverR | undefined {
  // Check both local and global state
  return activeObserver || globalThisWithObserver.__activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Circular dependency detection
  if (updateStack.includes(observer)) {
    const cyclePath = updateStack.slice(updateStack.indexOf(observer))
    const cycleNames = cyclePath.map(o => o.name || 'anonymous').join(' -> ')
    throw new Error(`Circular dependency detected: ${cycleNames} -> ${observer.name || 'anonymous'}`)
  }

  const previous = activeObserver
  activeObserver = observer
  globalThisWithObserver.__activeObserver = observer
  updateDepth++
  updateStack.push(observer)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    updateDepth--
    updateStack.pop()
    activeObserver = previous
    globalThisWithObserver.__activeObserver = previous
  }
}

// Memory cleanup utilities
export function cleanupDisposal(): void {
  // Implementation for cleanup can be added later if needed
}

// Get current update depth for debugging
export function getUpdateDepth(): number {
  return updateDepth
}
