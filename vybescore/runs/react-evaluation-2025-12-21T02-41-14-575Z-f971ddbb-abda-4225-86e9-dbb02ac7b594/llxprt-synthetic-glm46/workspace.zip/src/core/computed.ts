/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Check if we have dependencies (by checking if there's an active observer)
  const hasDependencies = getActiveObserver() !== undefined
  
  if (hasDependencies) {
    // Initialize the computed value and track dependencies
    updateObserver(o)
  }
  
  // Return getter that re-evaluates when dependencies change
  const getter: GetterFn<T> = () => {
    // Store the computed observer as active to track dependencies
    const previousActive = (globalThis as unknown as { __activeObserver?: ObserverR }).__activeObserver
    ;(globalThis as unknown as { __activeObserver?: ObserverR }).__activeObserver = o
    try {
      // Re-evaluate the computed value to get fresh value
      o.value = o.updateFn(o.value)
    } finally {
      (globalThis as unknown as { __activeObserver?: ObserverR }).__activeObserver = previousActive
    }
    return o.value!
  }
  
  return getter
}
