/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T> | undefined
  if (_equal === false || _equal === true) {
    // If boolean, use strict equality when true, reference equality when false
    equalFn = _equal ? (a, b) => a === b : (a, b) => a === b
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  } else {
    // Default to strict equality
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: [],
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Also add to observers array if not already present
      if (s.observers && !s.observers.includes(observer)) {
        s.observers.push(observer)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update and notify if value actually changed
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      // Notify single observer (backward compatibility)
      if (s.observer) updateObserver(s.observer as Observer<unknown>)
      // Notify all observers in the array
      if (s.observers) {
        s.observers.forEach(observer => {
          updateObserver(observer as Observer<unknown>)
        })
      }
    }
    return s.value
  }

  return [read, write]
}
