/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  // Create a hybrid object that acts as both Observer and Subject
  const hybrid: Observer & Subject = {
    name: options?.name,
    value,
    updateFn: updateFn as (value?: unknown) => unknown,
    dependencies: new Set(),
    observers: new Set(),
    equalFn: undefined,
  }
  
  const getter: GetterFn<T> = () => {
    // Re-evaluate to get the current value and track dependencies
    const newValue = updateObserver(hybrid) as T
    const previousValue = hybrid.value
    hybrid.value = newValue
    
    // Always notify observers when getter is called and value might have changed
    // This ensures callbacks are triggered
    if (hybrid.observers.size > 0) {
      notifyObservers(hybrid)
    }
    
    return newValue
  }
  
  return getter
}
