/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  Observer,
  getActiveObserver,
  clearDependencies,
  setActiveObserver,
  addObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create a callback observer
  const callbackObserver: Observer = {
    value,
    updateFn: updateFn as (value?: unknown) => unknown,
    dependencies: new Set(),
    observers: new Set(),
    name: 'callback'
  }
  
  // Execute the callback to establish dependencies and get initial value
  const prev = getActiveObserver()
  setActiveObserver(callbackObserver)
  try {
    callbackObserver.value = callbackObserver.updateFn(callbackObserver.value)
  } finally {
    setActiveObserver(prev)
  }
  
  // Register this callback as an observer of each dependency
  callbackObserver.dependencies.forEach(dependency => {
    addObserver(dependency as any, callbackObserver)
  })
  
  const unsubscribe = () => {
    // Remove from all dependencies
    callbackObserver.dependencies.forEach(dependency => {
      (dependency as any).observers.delete(callbackObserver)
    })
    clearDependencies(callbackObserver)
  }
  
  return unsubscribe
}
