/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  value?: unknown
  updateFn: (value?: unknown) => unknown
  dependencies: Set<Subject>
  observers?: Set<Observer> // Optional for computed values
}

export interface Subject {
  name?: string
  observers: Set<Observer>
  value: unknown
  equalFn?: (lhs: unknown, rhs: unknown) => boolean
}

// Union type for anything that can be observed (both Subject and computed Observer)
export type Observable = Subject | Observer

export type ObserverT<T> = Observer & { value?: T; updateFn: (value?: T) => T }
export type SubjectT<T> = Subject & { value: T; equalFn?: EqualFn<T> }

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}

export function addObserver(subject: Subject, observer: Observer): void {
  // Avoid duplicate registrations
  if (!subject.observers.has(observer)) {
    subject.observers.add(observer)
    observer.dependencies.add(subject)
  }
}

export function removeObserver(subject: Subject, observer: Observer): void {
  subject.observers.delete(observer)
  observer.dependencies.delete(subject)
}

export function clearDependencies(observer: Observer): void {
  observer.dependencies.forEach(subject => {
    subject.observers.delete(observer)
  })
  observer.dependencies.clear()
}

export function notifyObservers(subject: Subject): void {
  // Create a copy to avoid issues if observers modify the set during notification
  const observers = new Set(subject.observers)
  observers.forEach(observer => {
    if (observer) {
      // Re-evaluate the observer and update its value
      updateObserver(observer)
    }
  })
}

export function updateObserver<T>(observer: Observer): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Clear dependencies - they will be re-registered during re-evaluation
    observer.dependencies.clear()
    
    // Re-evaluate
    const newValue = observer.updateFn(observer.value) as T
    observer.value = newValue
    return newValue
  } finally {
    activeObserver = previous
  }
}
