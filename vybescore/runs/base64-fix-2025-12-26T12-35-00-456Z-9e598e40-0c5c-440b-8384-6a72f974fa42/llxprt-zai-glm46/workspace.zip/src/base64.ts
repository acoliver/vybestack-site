const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validates if a string is valid Base64 input.
 * Base64 uses characters A-Z, a-z, 0-9, +, /, and optional padding =.
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }
  // Check for valid characters only
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }
  // Check proper padding (if present, must be 1 or 2 = chars at end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding characters can only appear at the end
    const padding = input.slice(paddingIndex);
    if (!/^={1,2}$/.test(padding)) {
      return false;
    }
    // And must be at the correct position based on total length
    const unpaddedLength = paddingIndex;
    const expectedPadding = (4 - (unpaddedLength % 4)) % 4;
    // Allow inputs without padding or with correct padding
    if (padding.length !== expectedPadding && padding.length !== 0) {
      return false;
    }
  }
  return true;
}

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  const buffer = Buffer.from(input, 'utf8');
  return buffer.toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding resulted in empty buffer for non-empty input
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
