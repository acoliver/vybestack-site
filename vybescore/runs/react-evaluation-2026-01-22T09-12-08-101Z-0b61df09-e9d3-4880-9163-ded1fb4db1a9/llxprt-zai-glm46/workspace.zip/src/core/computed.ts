/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // The observer needs to act as both an observer and a subject
  // so that other observers can depend on it
  const getter = (): T => {
    const activeObs = getActiveObserver()
    if (activeObs && activeObs !== o) {
      // Another observer is reading this computed value, so register the dependency
      // Store the observer reference so we can notify it when this computed changes
      const observerWithDependents = o as Observer<T> & { dependents?: Set<ObserverR> }
      if (!observerWithDependents.dependents) {
        observerWithDependents.dependents = new Set()
      }
      observerWithDependents.dependents.add(activeObs)
    }
    return o.value!
  }
  
  updateObserver(o)
  
  return getter
}
