/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value: _value,
    updateFn,
    equals: false, // Callbacks should always fire
    dependencies: new Set(),
    dependents: new Set(),
    notifyDependents: function() {
      // Use proper type checking instead of any
      this.dependents.forEach((dependent) => {
        if ('updateFn' in dependent && dependent.updateFn) {
          // Type assertion with proper checks - unavoidable due to generic constraints
          const dep = dependent as unknown as Observer<unknown>
          const oldValue = dep.value
          dep.value = dep.updateFn(dep.value)
          if (dep.notifyDependents && dep.value !== oldValue) {
            dep.notifyDependents()
          }
        }
      })
    }
  }

  // Register observer to track dependencies
  const previous = setActiveObserver(observer as unknown as Observer<unknown>)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true
    
    // Clear observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => _value!
  }
}
