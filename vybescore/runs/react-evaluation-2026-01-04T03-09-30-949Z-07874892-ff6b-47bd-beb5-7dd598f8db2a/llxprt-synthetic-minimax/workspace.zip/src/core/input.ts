/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getCurrentContext,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  updateNode
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value,
    dependencies: new Set(),
    dependents: new Set(),
    notifyDependents: function() {
      this.dependents.forEach((dependent: Subject<unknown>) => {
        updateNode(dependent)
      })
    }
  }

  const read: GetterFn<T> = () => {
    const current = getCurrentContext()
    if (current && current !== subject) {
      // Establish bidirectional dependency
      subject.dependents.add(current)
      current.dependencies.add(subject)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    subject.notifyDependents()
    return subject.value
  }

  return [read, write]
}
