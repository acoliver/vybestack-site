/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core reactive node interface
export interface ReactiveNode<T> {
  name?: string
  value: T
  dependencies: Set<ReactiveNode<unknown>> // What this node depends on
  dependents: Set<ReactiveNode<unknown>> // What depends on this node
  notifyDependents(): void
}

// Observer interface for computed and callback nodes
export interface Observer<T> {
  name?: string
  value: T | undefined
  updateFn: UpdateFn<T>
  equals: boolean | EqualFn<T> | false
  dependencies: Set<ReactiveNode<unknown>>
  dependents: Set<ReactiveNode<unknown>>
  notifyDependents(): void
}

// Subject interface for input nodes
export interface Subject<T> extends ReactiveNode<T> {
  name?: string
  value: T
  dependencies: Set<ReactiveNode<unknown>>
  dependents: Set<ReactiveNode<unknown>>
  notifyDependents(): void
}

// Helper type for cross-generic operations
export type AnyUpdateFn = (value?: unknown) => unknown

// Interface for unified observer operations
export interface UnifiedObserver {
  name?: string
  value: unknown
  updateFn: AnyUpdateFn
  equals: boolean | ((lhs: unknown, rhs: unknown) => boolean) | false
  dependencies: Set<ReactiveNode<unknown>>
  dependents: Set<ReactiveNode<unknown>>
  notifyDependents(): void
}

// Global tracking for current computation context
let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): Observer<unknown> | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

// Legacy context tracking (for compatibility)
export type Context = Observer<unknown> | undefined

export function getCurrentContext(): Context {
  return activeObserver
}

// Core update function for nodes
export function updateNode<T>(node: ReactiveNode<T>): void {
  // For subjects, value is set externally
  // For observers, recomputation happens in updateObserver
  if ('updateFn' in node) {
    const observer = node as Observer<T>
    updateObserver(observer)
  }
}

// Core update function for observers
export function updateObserver<T>(observer: Observer<T>): void {
  const previous = setActiveObserver(observer as Observer<unknown>)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
  observer.notifyDependents()
}

// Function to update unified observers
export function updateUnifiedObserver(observer: UnifiedObserver): void {
  const previous = setActiveObserver(observer as Observer<unknown>)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
  observer.notifyDependents()
}
