#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { formatters } from '../formats/index.js';
import { CLIOptions, ReportData } from '../types.js';

function parseArgs(args: string[]): CLIOptions & { inputFile: string } {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  const options: Partial<CLIOptions> = {};
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const format = args[++i];
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Unsupported format: ${format}`);
        console.error('Supported formats: markdown, text');
        process.exit(1);
      }
      options.format = format;
    } else if (arg === '--output') {
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Missing required argument: --format');
    process.exit(1);
  }

  return {
    inputFile,
    format: options.format,
    output: options.output,
    includeTotals: options.includeTotals || false
  };
}

function validateReportData(data: unknown): data is ReportData {
  const objData = data as Record<string, unknown>;
  
  if (!objData || typeof objData !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  if (!objData.title || typeof objData.title !== 'string') {
    throw new Error('Invalid JSON: missing required field "title" (string)');
  }

  if (!objData.summary || typeof objData.summary !== 'string') {
    throw new Error('Invalid JSON: missing required field "summary" (string)');
  }

  if (!Array.isArray(objData.entries)) {
    throw new Error('Invalid JSON: missing required field "entries" (array)');
  }

  for (let i = 0; i < objData.entries.length; i++) {
    const entry = objData.entries[i] as Record<string, unknown>;
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}] missing required field "label" (string)`);
    }

    if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}] missing required field "amount" (number)`);
    }
  }

  return true;
}

function main(): void {
  const args = process.argv.slice(2);
  const { inputFile, format, output, includeTotals } = parseArgs(args);

  try {
    // Read and parse JSON file
    const fileContent = readFileSync(inputFile, 'utf-8');
    const data: ReportData = JSON.parse(fileContent);

    // Validate the data structure
    validateReportData(data);

    // Get the appropriate formatter
    const formatter = formatters[format];
    if (!formatter) {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }

    // Render the report
    const report = formatter(data, { format, output, includeTotals });

    // Output the result
    if (output) {
      writeFileSync(output, report);
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
