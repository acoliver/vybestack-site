import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { CLIOptions, ReportData } from '../types.js';

export type Formatter = (data: ReportData, options: CLIOptions) => string;

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};

export { renderMarkdown, renderText };