/* eslint-disable @typescript-eslint/no-explicit-any */
declare module 'sql.js' {
  export default class Database {
    constructor(data?: ArrayBuffer);
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class Statement {
    run(...params: unknown[]): unknown;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }
  
  export function initSqlJs(options?: unknown): Promise<{ Database: typeof Database }>;
}