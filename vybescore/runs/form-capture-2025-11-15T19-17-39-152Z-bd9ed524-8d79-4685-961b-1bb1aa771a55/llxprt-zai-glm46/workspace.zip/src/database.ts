import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type SqlJsType = any;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type DatabaseType = any;

export default async function initDatabase(): Promise<{
  prepare: (sql: string) => {
    run: (...params: unknown[]) => void;
    free: () => void;
  };
  close: () => void;
}> {
  const sqlJsModule = await import('sql.js');
  const initSqlJs: unknown = sqlJsModule.default;
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const SQL: SqlJsType = await (initSqlJs as SqlJsType)({ locateFile: (file: string) => `node_modules/sql.js/dist/${file}` });
  
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  
  let db: unknown;
  
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new (SQL.Database as new (data?: Uint8Array) => DatabaseType)(fileBuffer);
    } else {
      db = new (SQL.Database as new (data?: Uint8Array) => DatabaseType)();
      // Create schema
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      (db as DatabaseType).exec(schema);
    }
    
    // eslint-disable-next-line no-inner-declarations
    function saveDatabase() {
      const data = (db as DatabaseType).export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    }
    
    return {
      prepare: (sql: string) => {
        const stmt = (db as DatabaseType).prepare(sql);
        return {
          run: (...params: unknown[]) => {
            try {
              stmt.run(...params);
              saveDatabase(); // Save after each insert
            } finally {
              stmt.free();
            }
          },
          free: () => {
            stmt.free();
          }
        };
      },
      close: () => {
        (db as DatabaseType).close();
      }
    };
    
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
}