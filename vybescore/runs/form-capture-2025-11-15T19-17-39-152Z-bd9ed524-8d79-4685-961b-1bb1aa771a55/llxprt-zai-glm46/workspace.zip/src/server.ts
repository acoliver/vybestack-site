import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initDatabase from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: {
  prepare: (sql: string) => {
    run: (...params: unknown[]) => void;
    free: () => void;
  };
  close: () => void;
} | null = null;

async function startServer() {
  try {
    db = await initDatabase();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }

  // Validation functions
  function validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  function validatePhone(phone: string): boolean {
    const phoneRegex = /^\+?[0-9\s\-\(\)]+$/;
    return phoneRegex.test(phone) && phone.trim().length > 0;
  }

  function validatePostalCode(postalCode: string): boolean {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.trim().length > 0;
  }

  function validateRequired(value: string): boolean {
    return Boolean(value && value.trim().length > 0);
  }

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      title: 'Contact Form',
      errors: {},
      formData: {}
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const {
      first_name,
      last_name,
      street_address,
      city,
      state_province,
      postal_code,
      country,
      email,
      phone
    } = req.body;

    const errors: Record<string, string> = {};

    // Validate required fields
    if (!validateRequired(first_name)) errors.first_name = 'First name is required';
    if (!validateRequired(last_name)) errors.last_name = 'Last name is required';
    if (!validateRequired(street_address)) errors.street_address = 'Street address is required';
    if (!validateRequired(city)) errors.city = 'City is required';
    if (!validateRequired(state_province)) errors.state_province = 'State/Province is required';
    if (!validateRequired(postal_code)) errors.postal_code = 'Postal code is required';
    if (!validateRequired(country)) errors.country = 'Country is required';
    if (!validateRequired(email)) errors.email = 'Email is required';
    if (!validateRequired(phone)) errors.phone = 'Phone number is required';

    // Validate format
    if (email && !validateEmail(email)) errors.email = 'Please enter a valid email address';
    if (phone && !validatePhone(phone)) errors.phone = 'Please enter a valid phone number';
    if (postal_code && !validatePostalCode(postal_code)) errors.postal_code = 'Please enter a valid postal code';

    if (Object.keys(errors).length > 0) {
      res.status(400).render('form', {
        title: 'Contact Form',
        errors,
        formData: req.body
      });
      return;
    }

    // Insert into database
    if (db) {
      try {
        const stmt = db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        stmt.run(
          first_name,
          last_name,
          street_address,
          city,
          state_province,
          postal_code,
          country,
          email,
          phone
        );
        stmt.free();
      } catch (error) {
        console.error('Database insertion error:', error);
        res.status(500).render('form', {
          title: 'Contact Form',
          errors: { general: 'An error occurred while saving your submission. Please try again.' },
          formData: req.body
        });
        return;
      }
    }

    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', { 
      title: 'Thank You!'
    });
  });

  // Start server
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('HTTP server closed');
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      process.exit(0);
    });
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  return server;
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default startServer;