import { describe, expect, it } from 'vitest';

describe('database initialization', () => {
  it('should create Database with new keyword', async () => {
    // Import sql.js dynamically to test the Database constructor
    const sqlJsModule = await import('sql.js');
    const initSqlJs = sqlJsModule.default;
    const SQL = await initSqlJs({ locateFile: (file: string) => `node_modules/sql.js/dist/${file}` });
    
    // Test that Database constructor requires 'new' keyword
    const db = new SQL.Database();
    expect(db).toBeDefined();
    db.close();
  });
});