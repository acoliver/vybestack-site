/**
 * Encode plain text to Base64 using standard Base64 encoding.
 * Returns Base64 string with proper padding when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws an error for clearly invalid Base64.
 */
export function decode(input: string): string {
  // Validate that input only contains valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters not in Base64 alphabet');
  }

  try {
    // Base64 strings are valid with or without padding
    // Remove padding for character validation
    const base64Chars = input.replace(/=/g, '');
    if (base64Chars.length === 0) {
      throw new Error('Empty Base64 input');
    }

    // Check if input can be padded to multiple of 4
    const totalLength = input.length;
    if (totalLength % 4 !== 0) {
      // This is where we would normally check padding,
      // but Buffer.from handles missing padding fine
      // Just ensure it's reasonably close to a valid length
      const paddedLength = Math.ceil(totalLength / 4) * 4;
      if (paddedLength - totalLength > 2) {
        throw new Error('Invalid Base64 length: too much padding needed');
      }
    }

    // Decode using standard Base64 (Buffer.from handles missing padding)
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes('decode')) {
      throw new Error('Failed to decode Base64 input');
    }
    throw error;
  }
}
