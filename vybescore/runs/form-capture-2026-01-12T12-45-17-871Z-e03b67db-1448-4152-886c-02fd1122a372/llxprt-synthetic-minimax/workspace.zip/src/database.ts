import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  submittedAt?: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        return require.resolve(`sql.js/dist/${file}`);
      },
    });

    try {
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw new Error('Failed to initialize database');
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schema = fs.readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schema);
      await this.saveToDisk();
    } catch (error) {
      console.error('Schema creation failed:', error);
      throw new Error('Failed to create database schema');
    }
  }

  async saveSubmission(formData: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.step();
    stmt.free();

    await this.saveToDisk();

    // Get the last inserted ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    if (
      result.length > 0 &&
      result[0] &&
      result[0].values &&
      result[0].values.length > 0 &&
      result[0].values[0] &&
      result[0].values[0].length > 0 &&
      result[0].values[0][0] !== undefined
    ) {
      return result[0].values[0][0] as number;
    }

    throw new Error('Failed to get submission ID');
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const binaryArray = this.db.export();
      const buffer = Buffer.from(binaryArray);
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database to disk:', error);
      throw new Error('Failed to persist database');
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  validateFormData(formData: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    const requiredFields: (keyof FormData)[] = [
      'firstName',
      'lastName',
      'streetAddress',
      'city',
      'stateProvinceRegion',
      'postalCode',
      'country',
      'email',
      'phone',
    ];

    for (const field of requiredFields) {
      const value = formData[field];
      if (!value || typeof value !== 'string' || value.trim().length === 0) {
        errors.push({
          field: field,
          message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`,
        });
      }
    }

    // Email validation
    if (formData.email && formData.email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address',
        });
      }
    }

    // Phone validation
    if (formData.phone && formData.phone.trim()) {
      const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
      if (!phoneRegex.test(formData.phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number',
        });
      }
    }

    // Postal code validation (accepts alphanumeric)
    if (formData.postalCode && formData.postalCode.trim()) {
      const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
      if (!postalRegex.test(formData.postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal code',
        });
      }
    }

    return errors;
  }
}
