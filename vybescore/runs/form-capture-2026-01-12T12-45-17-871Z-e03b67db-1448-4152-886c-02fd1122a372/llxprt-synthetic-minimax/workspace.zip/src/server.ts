import express, { Request, Response } from 'express';
import * as path from 'path';
import { DatabaseManager, FormData } from './database';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Database manager instance
const dbManager = new DatabaseManager();

// Initialize database
async function initializeServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize server:', error);
    process.exit(1);
  }
}

// GET / - Form page
app.get('/', (req: Request, res: Response) => {
  res.status(200).render('form', {
    title: 'Contact Form',
    errors: [],
    formData: {},
    submitted: false,
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    // Validate form data
    const errors = dbManager.validateFormData(formData);

    if (errors.length > 0) {
      // Return to form with errors
      return res.status(400).render('form', {
        title: 'Contact Form - Please Fix Errors',
        errors: errors,
        formData: formData,
        submitted: false,
      });
    }

    // Save submission to database
    await dbManager.saveSubmission(formData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Form submission error:', error);
    res.status(500).render('form', {
      title: 'Contact Form - Error',
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      formData: req.body,
      submitted: false,
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.status(200).render('thank-you', {
    title: 'Thank You!',
  });
});

// Graceful shutdown
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}. Starting graceful shutdown...`);

  try {
    await dbManager.close();
    console.log('Database connection closed');
  } catch (error) {
    console.error('Error closing database:', error);
  }

  console.log('Server shutting down gracefully');
  process.exit(0);
}

// Handle SIGTERM and SIGINT
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  await initializeServer();

  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to see the form`);
  });

  // Handle server errors
  server.on('error', (error: NodeJS.ErrnoException) => {
    if (error.syscall !== 'listen') {
      throw error;
    }

    switch (error.code) {
      case 'EACCES':
        console.error(`Port ${PORT} requires elevated privileges`);
        process.exit(1);
        break;
      case 'EADDRINUSE':
        console.error(`Port ${PORT} is already in use`);
        process.exit(1);
        break;
      default:
        throw error;
    }
  });
}

// Start the server if this file is run directly
if (require.main === module) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default app;
