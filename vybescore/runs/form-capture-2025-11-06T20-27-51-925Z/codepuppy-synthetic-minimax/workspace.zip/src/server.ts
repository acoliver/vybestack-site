import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import createDatabase from 'sql.js';

// Type definitions for sql.js
interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatement {
  run(...params: unknown[]): void;
  get(): Record<string, unknown> | undefined;
  free(): void;
}

interface SqlJsModule {
  Database: new (data?: Uint8Array) => SqlJsDatabase;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}
const PORT = process.env.PORT || 3000;
const app = express();
const dbPath = path.resolve('data', 'submissions.sqlite');

let db: SqlJsDatabase;
let serverInstance: unknown;

// Ensure data directory exists
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await createDatabase() as SqlJsModule;
    
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      const uInt8Array = new Uint8Array(dbFile);
      db = new SQL.Database(uInt8Array);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
      db.run(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error instanceof Error ? error.message : String(error));
  }
}

// Validation functions
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return {
      field: fieldName,
      message: `${fieldName} is required`
    };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) {
    return {
      field: 'email',
      message: 'Please enter a valid email address'
    };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^[+]?[\d\s()\-]+$/;
  if (!phoneRegex.test(phone.trim())) {
    return {
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +'
    };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  if (!postalRegex.test(postalCode.trim())) {
    return {
      field: 'postalCode',
      message: 'Postal code can only contain letters, digits, spaces, and dashes'
    };
  }
  return null;
}

function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Check required fields
  const requiredError = validateRequired(formData.firstName, 'First name');
  if (requiredError) errors.push(requiredError);

  const lastNameError = validateRequired(formData.lastName, 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const streetError = validateRequired(formData.streetAddress, 'Street address');
  if (streetError) errors.push(streetError);

  const cityError = validateRequired(formData.city, 'City');
  if (cityError) errors.push(cityError);

  const stateError = validateRequired(formData.stateProvince, 'State / Province / Region');
  if (stateError) errors.push(stateError);

  const postalError = validateRequired(formData.postalCode, 'Postal / Zip code');
  if (postalError) errors.push(postalError);

  const countryError = validateRequired(formData.country, 'Country');
  if (countryError) errors.push(countryError);

  const emailRequiredError = validateRequired(formData.email, 'Email');
  if (emailRequiredError) errors.push(emailRequiredError);

  const phoneRequiredError = validateRequired(formData.phone, 'Phone number');
  if (phoneRequiredError) errors.push(phoneRequiredError);

  // Format validations (only if field is not empty)
  if (formData.email && formData.email.trim() !== '') {
    const emailError = validateEmail(formData.email);
    if (emailError) errors.push(emailError);
  }

  if (formData.phone && formData.phone.trim() !== '') {
    const phoneError = validatePhone(formData.phone);
    if (phoneError) errors.push(phoneError);
  }

  if (formData.postalCode && formData.postalCode.trim() !== '') {
    const postalCodeError = validatePostalCode(formData.postalCode);
    if (postalCodeError) errors.push(postalCodeError);
  }

  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
    return;
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    );

    stmt.free();
    saveDatabase();

    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error instanceof Error ? error.message : String(error));
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the first name from the last submission for personalization
  let firstName = 'friend';
  try {
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    const result = stmt.get();
    if (result && result.first_name) {
      firstName = result.first_name;
    }
    stmt.free();
  } catch (error) {
    console.error('Error fetching first name:', error instanceof Error ? error.message : String(error));
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  if (serverInstance) {
    // Type assertion to access the close method
    const server = serverInstance as { close: (callback?: () => void) => void };
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  serverInstance = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Handle graceful shutdown
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// For testing purposes
export { app, db, gracefulShutdown };

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}