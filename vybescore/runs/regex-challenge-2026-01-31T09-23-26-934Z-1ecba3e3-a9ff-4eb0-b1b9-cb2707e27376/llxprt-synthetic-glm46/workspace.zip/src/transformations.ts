/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Find boundaries after sentence-ending punctuation and capitalize the next word
  return text.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, char) => {
    // Preserve original punctuation and capitalize following letter
    return punctuation + char.toUpperCase();
  }).replace(/^([a-z])/, (match, char) => {
    // Capitalize first character of the text
    return char.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern with negative lookahead to avoid trailing punctuation
  const urlRegex = /(https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+~#?&//=]*))(?![\]).,;:?!"])/g;
  
  const matches = text.match(urlRegex) || [];
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// without affecting https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to find URLs with http://example.com/... format
  const exampleUrlPattern = /(https?):\/\/example\.com(\/[^?\s]*)(?:\?([^#\s]*))?/g;
  
  // Replace function to transform matched URLs
  return text.replace(exampleUrlPattern, (match, protocol, path, query) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite host to docs.example.com
      return `${newProtocol}://docs.example.com${path}${query ? '?' + query : ''}`;
    }
    
    // For paths with dynamic hints, only upgrade the scheme
    if (path.includes('cgi-bin') || 
        path.includes('.jsp') || 
        path.includes('.php') || 
        path.includes('.asp') || 
        path.includes('.aspx') || 
        path.includes('.do') || 
        path.includes('.cgi') || 
        path.includes('.pl') || 
        path.includes('.py')) {
      return `${newProtocol}://example.com${path}${query ? '?' + query : ''}`;
    }
    
    // For query strings, only upgrade the scheme
    if (query) {
      return `${newProtocol}://example.com${path}?${query}`;
    }
    
    // Default case: upgrade scheme only
    return `${newProtocol}://example.com${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const matches = value.match(datePattern);
  
  if (!matches) {
    return 'N/A';
  }
  
  // Extract month, day, and year
  const month = parseInt(matches[1], 10);
  const day = parseInt(matches[2], 10);
  const year = matches[3];
  
  // Additional validation for day value based on month
  const maxDaysPerMonth = {
    1: 31,
    2: 29, // February (leap year not checked as it's not required)
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31
  };
  
  // Check if day is valid for the month
  const maxDay = maxDaysPerMonth[month as keyof typeof maxDaysPerMonth];
  if (day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
