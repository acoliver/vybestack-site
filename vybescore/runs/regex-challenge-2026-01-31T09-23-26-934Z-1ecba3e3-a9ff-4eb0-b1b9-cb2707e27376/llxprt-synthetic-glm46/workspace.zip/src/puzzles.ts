/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for any special regex characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find words starting with the prefix
  // Use word boundaries to match whole words only
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z0-9]*)\\b`, 'g');
  
  // Find all matches
  const matches = [...text.matchAll(wordPattern)];
  
  // Get the matched words and filter out exceptions
  const foundWords = matches.map(match => match[0]);
  
  // Filter out the exceptions
  return [...new Set(foundWords.filter(word => !exceptions.includes(word)))];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for any special regex characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find the token after a digit and not at the start of the string
  // We want to match the digit+token pattern anywhere except at the start
  const tokenPattern = new RegExp(`\\d(${escapedToken})`, 'g');
  
  const results: string[] = [];
  
  // Split the text by whitespace to get individual words
  const words = text.split(/\s+/);
  
  // For each word, check if it matches our pattern
  for (const word of words) {
    if (word.match(tokenPattern)) {
      results.push(word);
    }
  }
  
  // Return unique results
  return [...new Set(results)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>]/.test(value)) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like abab
  // Check for repeated 2-character sequences (e.g., abab)
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern with support for shorthand and full notation
  // This is a comprehensive pattern that detects IPv6 addresses but excludes IPv4
  const ipv6Pattern = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|(([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4})?::(([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4})?\b/;
  
  // IPv4 pattern to exclude IPv4 addresses
  const ipv4Pattern = /\b([0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // Check if the value contains IPv6
  const containsIpv6 = ipv6Pattern.test(value);
  
  // Check if the value contains IPv4
  const containsIpv4 = ipv4Pattern.test(value);
  
  // Return true only if IPv6 is detected and IPv4 is not
  return containsIpv6 && !containsIpv4;
}
