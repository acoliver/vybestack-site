export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that:
  // - Allows unicode letters in local part
  // - Rejects double dots
  // - Rejects trailing dots in local part
  // - Rejects domains with underscores
  // - Rejects other invalid forms
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // More specific regex for email validation
  const emailSpecificRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Check for double dots, trailing dots, and domain underscores
  const hasDoubleDots = /\.\./.test(value);
  const hasTrailingDot = /\.(?=@)/.test(value);
  const hasUnderscoreInDomain = /_.*@|@.*_/.test(value);
  
  // Basic format check
  if (!emailRegex.test(value) || !emailSpecificRegex.test(value)) {
    return false;
  }
  
  // Additional validation for edge cases
  if (hasDoubleDots || hasTrailingDot || hasUnderscoreInDomain) {
    return false;
  }
  
  return true;
}

/**
 * Helper function for Luhn algorithm
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for US phone numbers)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Optional +1 country code at the beginning
  if (digitsOnly.length > 10 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract the 10-digit phone number (without country code)
  const phoneNumber = digitsOnly.length === 10 ? digitsOnly : digitsOnly.substring(1);
  
  // Check area code - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Check if the format is valid (with separators or all together)
  // Valid formats: (212) 555-7890, 212-555-7890, 2125557890, or with optional +1 prefix
  const validFormats = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/,
    /^\+?1?\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/,
    /^\+?1?\s*\d{10}$/
  ];
  
  // Test against valid formats
  const isValidFormat = validFormats.some(regex => regex.test(value));
  
  // For extensibility options (not specified in requirements but included for future)
  if (options?.allowExtensions) {
    return isValidFormat && digitsOnly.length >= 10;
  }
  
  return isValidFormat && digitsOnly.length >= 10 && digitsOnly.length <= 11;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators, spaces, and plus sign for validation
  const digitsOnly = value.replace(/[\s-+]/g, '');
  
  // Handle different formats:
  // 1. With country code +54: +54 9 11 1234 5678, +54 341 123 4567
  // 2. Without country code: 011 1234 5678, 0341 4234567
  
  // Format 1: With country code +54
  if (digitsOnly.startsWith('54')) {
    // Remove country code
    const digitsWithoutCountry = digitsOnly.substring(2);
    
    // Try to parse as: [optional 9][area code][subscriber number]
    // First, try with mobile indicator 9
    if (digitsWithoutCountry.startsWith('9')) {
      // Mobile format: 9 + area code (2-4 digits) + subscriber number
      const digitsWithoutMobile = digitsWithoutCountry.substring(1);
      
      // Try to extract area code (2-4 digits)
      for (let areaCodeLen = 4; areaCodeLen >= 2; areaCodeLen--) {
        if (digitsWithoutMobile.length >= areaCodeLen + 6) {
          const areaCode = digitsWithoutMobile.substring(0, areaCodeLen);
          const subscriberNumber = digitsWithoutMobile.substring(areaCodeLen);
          
          // Area code must start with 1-9 and subscriber number must be 6-8 digits
          if (/^[2-9]/.test(areaCode) && 
              subscriberNumber.length >= 6 && 
              subscriberNumber.length <= 8) {
            return true;
          }
        }
      }
    } else {
      // Landline format: area code (2-4 digits) + subscriber number
      // Try to extract area code (2-4 digits)
      for (let areaCodeLen = 4; areaCodeLen >= 2; areaCodeLen--) {
        if (digitsWithoutCountry.length >= areaCodeLen + 6) {
          const areaCode = digitsWithoutCountry.substring(0, areaCodeLen);
          const subscriberNumber = digitsWithoutCountry.substring(areaCodeLen);
          
          // Area code must start with 1-9 and subscriber number must be 6-8 digits
          if (/^[2-9]/.test(areaCode) && 
              subscriberNumber.length >= 6 && 
              subscriberNumber.length <= 8) {
            return true;
          }
        }
      }
    }
  } 
  // Format 2: Without country code, must start with trunk prefix 0
  else if (digitsOnly.startsWith('0')) {
    // Remove trunk prefix
    const digitsWithoutTrunk = digitsOnly.substring(1);
    
    // Try to parse as: [optional 9][area code][subscriber number]
    // First, try with mobile indicator 9
    if (digitsWithoutTrunk.startsWith('9')) {
      // Mobile format: 0 + 9 + area code (2-4 digits) + subscriber number
      const digitsWithoutMobile = digitsWithoutTrunk.substring(1);
      
      // Try to extract area code (2-4 digits)
      for (let areaCodeLen = 4; areaCodeLen >= 2; areaCodeLen--) {
        if (digitsWithoutMobile.length >= areaCodeLen + 6) {
          const areaCode = digitsWithoutMobile.substring(0, areaCodeLen);
          const subscriberNumber = digitsWithoutMobile.substring(areaCodeLen);
          
          // Area code must start with 1-9 and subscriber number must be 6-8 digits
          if (/^[2-9]/.test(areaCode) && 
              subscriberNumber.length >= 6 && 
              subscriberNumber.length <= 8) {
            return true;
          }
        }
      }
    } else {
      // Landline format: 0 + area code (2-4 digits) + subscriber number
      // Try to extract area code (2-4 digits)
      for (let areaCodeLen = 4; areaCodeLen >= 2; areaCodeLen--) {
        if (digitsWithoutTrunk.length >= areaCodeLen + 6) {
          const areaCode = digitsWithoutTrunk.substring(0, areaCodeLen);
          const subscriberNumber = digitsWithoutTrunk.substring(areaCodeLen);
          
          // Area code must start with 1-9 and subscriber number must be 6-8 digits
          if (/^[2-9]/.test(areaCode) && 
              subscriberNumber.length >= 6 && 
              subscriberNumber.length <= 8) {
            return true;
          }
        }
      }
    }
  }
  
  // If we get here, the format doesn't match any valid Argentine phone format
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  // X Æ A-12 style names should be rejected due to digits
  
  const nameRegex = /^[\p{L}\p{M} '-]+$/u;
  
  // Check if the name contains any digits or certain symbols
  const invalidChars = /[0-9@#$%^&*()+=/\\|[\]{}<>~`]/;
  
  if (invalidChars.test(value)) {
    return false;
  }
  
  // Check for valid Unicode letter/character content
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check valid length (13-19 digits for most cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths by card type
  let validFormat = false;
  
  // Visa: starts with 4, length 13 or 16
  if (/^4/.test(digitsOnly) && (digitsOnly.length === 13 || digitsOnly.length === 16)) {
    validFormat = true;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if ((/^5[1-5]/.test(digitsOnly) || /^2(2[2-9]|[3-6]\d|7[01])/.test(digitsOnly)) && digitsOnly.length === 16) {
    validFormat = true;
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^3[47]/.test(digitsOnly) && digitsOnly.length === 15) {
    validFormat = true;
  }
  
  // If no valid format found, return false
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
