/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Create a new observer instance
  const observer: Observer<T> = {
    name: options?.name,
    value,  // Use undefined initially to force initial calculation
    updateFn,
  }
  
  // Store the latest value
  let latestValue: T | undefined = value
  
  // Register observer to track dependencies and perform initial computation
  updateObserver(observer)
  latestValue = observer.value
  
  const getter: GetterFn<T> = () => {
    // If accessed within an observer context, establish dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      observer.observer = activeObserver
    }
    
    // Only recalculate if we have dependencies; otherwise use cached value
    if (activeObserver) {
      observer.value = originalUpdateFn(observer.value)
      latestValue = observer.value
    }
    
    return latestValue as T
  }
  
  // Replace the original updateFn to propagate changes
  const originalUpdateFn = updateFn
  observer.updateFn = (currentValue?: T): T => {
    // Recalculate using the original update function
    const newValue = originalUpdateFn(currentValue)
    
    // Only update if value has changed
    if (newValue !== observer.value) {
      observer.value = newValue
      latestValue = newValue
        
      // Propagate to dependent observers
      if (observer.observer && observer.observer !== getActiveObserver()) {
        updateObserver(observer.observer as Observer<T>)
      }
    }

    return latestValue as T
  }
  
  return getter
}
