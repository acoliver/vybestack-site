/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track all subjects that depend on this callback
  const dependentObservers: Set<ObserverR> = new Set()
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear all references to prevent memory leaks
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Clear references from dependent observers
    dependentObservers.clear()
        
    // Note: In a more sophisticated implementation, we would maintain
    // a registry of subjects and their observers for proper cleanup
  }
}
