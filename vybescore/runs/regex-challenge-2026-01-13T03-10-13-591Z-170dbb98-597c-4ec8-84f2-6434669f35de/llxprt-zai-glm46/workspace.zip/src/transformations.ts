/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences if input omitted it.
 * Collapse extra spaces sensibly while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence terminators
  // Ensure there's exactly one space after .!? when followed by a letter
  let normalized = text.replace(/([.!?])(\s*)([a-zA-Z])/g, '$1 $3');

  // Capitalize first character of string
  normalized = normalized.replace(/^[a-z]/, c => c.toUpperCase());

  // Capitalize after sentence terminators, but be careful with abbreviations
  // Common abbreviations that don't start sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'No', 'etc', 'eg', 'ie', 'vs', 'approx', 'est', 'min', 'max', 'St', 'Ave', 'Blvd', 'Rd', 'Dept', 'Univ', 'Assn', 'Ave', 'Co', 'Corp', 'Inc', 'Ltd', 'PhD', 'MD', 'DO', 'DDS'];

  // Build a regex pattern that avoids capitalizing after abbreviations
  // This is complex, so we'll use a simpler approach:
  // Capitalize after .!? when preceded by more than one space or when the word before is not a common abbreviation
  const abbrPattern = new RegExp(`\\b(${abbreviations.join('|')})\\.$`, 'i');

  const sentences = normalized.split(/(?<=[.!?])\s+/);
  const capitalized = sentences.map((sentence, index) => {
    if (index === 0) {
      // First character already capitalized above
      return sentence;
    }

    // Check if previous sentence ended with an abbreviation
    const prevSentence = sentences[index - 1];
    if (abbrPattern.test(prevSentence.trim())) {
      return sentence;
    }

    // Capitalize first letter
    return sentence.replace(/^[a-z]/, c => c.toUpperCase());
  });

  // Rejoin with single spaces
  let result = capitalized.join(' ');

  // Collapse multiple spaces (but preserve newlines if they existed)
  result = result.replace(/[ \t]+/g, ' ');

  return result;
}

/**
 * Find URLs in the text.
 * Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http://, https://, and www. URLs
  // Captures the URL but excludes trailing punctuation
  // Using a simpler pattern that definitely matches
  const urlRegex = /https?:\/\/[^\s<>"']+|www\.[^\s<>"']+/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation characters that aren't part of URL
    return url.replace(/[.,;:!?)\]>"]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https://
  // Use a negative lookahead to ensure we don't match https://
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrade scheme to https://.
 * When path begins with /docs/, rewrite host to docs.example.com.
 * Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs with various paths
  // We need to handle the domain carefully
  const urlPattern = /(http:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)?/g;

  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if we should rewrite the host (docs.example.com)
    // Only rewrite if:
    // 1. Path starts with /docs/
    // 2. No dynamic hints in the URL
    const shouldRewriteHost = path && path.startsWith('/docs/');

    // Check for dynamic hints that prevent host rewrite
    const dynamicHints = [
      /cgi-bin/,
      /\?/,
      /&/,
      /=/,
      /\.jsp$/,
      /\.php$/,
      /\.asp$/,
      /\.aspx$/,
      /\.do$/,
      /\.cgi$/,
      /\.pl$/,
      /\.py$/
    ];

    const hasDynamicHint = dynamicHints.some(hint => hint.test(path || ''));

    if (shouldRewriteHost && !hasDynamicHint) {
      // Rewrite host to docs.[original-host]
      // But only if the host isn't already a subdomain
      const parts = host.split('.');
      if (parts.length >= 2) {
        // For example.com -> docs.example.com
        // For sub.example.com -> docs.sub.example.com (or sub.docs.example.com?)
        // Let's assume we want docs.example.com style
        const newHost = `docs.${host}`;
        return `${newProtocol}${newHost}${path}`;
      }
    }

    // Just upgrade the protocol
    return `${newProtocol}${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;

  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  // Basic year validation (should be 4 digits, reasonable range)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) {
    return 'N/A';
  }

  return year;
}
