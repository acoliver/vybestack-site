export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex - local part allows letters, digits, and common special chars
  // Domain part allows letters, digits, hyphens, and dots (but no underscores)
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

  // Must match basic pattern first
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for double dots anywhere
  if (/\.\./.test(value)) {
    return false;
  }

  // Check for trailing dot
  if (/\.$/.test(value)) {
    return false;
  }

  // Check for dot immediately after @
  if (/(@\.)/.test(value)) {
    return false;
  }

  // Check for dot immediately before @
  if (/(\.@)/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove common separators and spaces
  const cleaned = value.replace(/[\s\-()]/g, '');

  // Optional +1 country code
  const withCountryCodeRegex = /^\+1(\d{10})$/;
  const withoutCountryCodeRegex = /^(\d{10})$/;

  let digits = cleaned;

  // Strip +1 prefix if present
  const ccMatch = cleaned.match(withCountryCodeRegex);
  if (ccMatch) {
    digits = ccMatch[1];
  } else {
    const noCcMatch = cleaned.match(withoutCountryCodeRegex);
    if (noCcMatch) {
      digits = noCcMatch[1];
    } else {
      return false;
    }
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens only (keep parentheses for now)
  const cleaned = value.replace(/[\s-]/g, '');

  // Remove parentheses if present
  const noParens = cleaned.replace(/[()]/g, '');

  // Argentine phone number pattern:
  // Optional +54 country code
  // If no country code, must start with 0 (trunk prefix)
  // Optional 9 (mobile indicator) - only allowed after country code or trunk prefix
  // Area code: 2-4 digits, leading digit must be 1-9, not 0
  // Subscriber number: 6-8 digits total

  // Use separate patterns for WITH and WITHOUT mobile indicator
  // to avoid backtracking issues where the "9" gets absorbed into the area code

  // Pattern 1: +54 9 area subscriber (with country code AND mobile)
  // Mobile numbers: area code is exactly 2 digits, subscriber is 6-8 digits
  const withCountryWithMobile = /^\+54(9)([1-9]\d)(\d{6,8})$/;
  // Pattern 2: +54 area subscriber (with country code, NO mobile)
  // Landline numbers: area code is 2-4 digits
  // Must NOT match if area code starts with 9 followed by 0-2 (that would be a malformed mobile)
  const withCountryNoMobile = /^\+54([1-9]\d{1,3})(\d{6,8})$/;
  // Pattern 3: 0 9 area subscriber (trunk AND mobile)
  const trunkWithMobile = /^0(9)([1-9]\d)(\d{6,8})$/;
  // Pattern 4: 0 area subscriber (trunk, NO mobile)
  const trunkNoMobile = /^0([1-9]\d{1,3})(\d{6,8})$/;

  let match = noParens.match(withCountryWithMobile);
  if (match) {
    const areaCode = match[2];
    const subscriberNumber = match[3];

    // Area code must be exactly 2 digits for mobile numbers
    if (areaCode.length !== 2) {
      return false;
    }

    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }

    // For mobile numbers, require at least 7 digits in subscriber
    // (6-digit subscribers are only valid for landlines)
    if (subscriberNumber.length < 7) {
      return false;
    }

    return true;
  }

  match = noParens.match(withCountryNoMobile);
  if (match) {
    const areaCode = match[1];
    const subscriberNumber = match[2];

    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }

    // Special check: if area code starts with 9, ensure it's not actually
    // a malformed mobile number (like "90" or "901" which should be "9" + "0x" area)
    // Only reject if the area code is "9" followed by 0-2 at the start
    // (area codes starting with 9 followed by 0, 1, or 2 are suspicious)
    if (areaCode.startsWith('9')) {
      // Check if this could be a mobile prefix followed by area starting with 0-2
      // e.g., "90" could be mobile "9" + area "0x" (invalid)
      if (/^9[0-2]/.test(areaCode)) {
        return false;
      }
    }

    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }

    return true;
  }

  match = noParens.match(trunkWithMobile);
  if (match) {
    const areaCode = match[2];
    const subscriberNumber = match[3];

    // Area code must be exactly 2 digits for mobile numbers
    if (areaCode.length !== 2) {
      return false;
    }

    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }

    // For mobile numbers, require at least 7 digits in subscriber
    // (6-digit subscribers are only valid for landlines)
    if (subscriberNumber.length < 7) {
      return false;
    }

    return true;
  }

  match = noParens.match(trunkNoMobile);
  if (match) {
    const areaCode = match[1];
    const subscriberNumber = match[2];

    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }

    // Same special check for trunk prefix numbers
    if (areaCode.startsWith('9')) {
      if (/^9[0-2]/.test(areaCode)) {
        return false;
      }
    }

    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }

    return true;
  }

  return false;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters (including accented chars), apostrophes, hyphens, spaces
  // Must have at least one letter
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Must match the basic pattern
  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter (unicode)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }

  // Reject common symbol patterns (anything not already allowed)
  // We're very permissive with unicode letters, so this catches remaining symbols
  const allowedChars = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!allowedChars.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper: Run Luhn checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));

  let sum = 0;
  let double = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    double = !double;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 4, 13-16 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // Mastercard: 51-55 or 2221-2720, 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  // AmEx: 34 or 37, 15 digits
  const amexRegex = /^3[47]\d{13}$/;

  let validLength = false;

  if (visaRegex.test(cleaned) && cleaned.length >= 13 && cleaned.length <= 16) {
    validLength = true;
  } else if (mastercardRegex.test(cleaned) && cleaned.length === 16) {
    validLength = true;
  } else if (amexRegex.test(cleaned) && cleaned.length === 15) {
    validLength = true;
  }

  if (!validLength) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
