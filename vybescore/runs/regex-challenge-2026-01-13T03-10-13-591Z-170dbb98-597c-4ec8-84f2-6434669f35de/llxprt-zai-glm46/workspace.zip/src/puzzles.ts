/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Word boundary, then prefix, then word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(ex => ex.toLowerCase() === lowerWord);
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // We need to find patterns like: digit + token
  // The result should include the digit as well (based on the test expecting '1foo')
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, 123123)
  // We'll check for patterns of 2-4 characters repeated
  for (let len = 2; len <= 4; len++) {
    const repeatedPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatedPattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (including :: shorthand)
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can appear once to represent one or more groups of zeros
  // IPv4 embedded: ::ffff:192.168.1.1

  // First, let's check for IPv4 and exclude those
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;

  // IPv6 pattern - this is complex due to shorthand
  // We'll use a pattern that matches the various IPv6 formats
  const ipv6Pattern = /(?:^|[\s[\]:])(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}::|(?:[0-9a-fA-F]{1,4}:){1,6}:(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|::|::(?:ffff:)?(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3})(?:$|[\s[\]:])/;

  // Check if it's an IPv6 address
  // We need to be careful not to match IPv4
  const match = value.match(ipv6Pattern);

  if (!match) {
    return false;
  }

  // Verify it's not just an IPv4 address
  // The pattern above might match some edge cases, so we double-check
  const ipv4Match = match[0].match(ipv4Pattern);

  // If the matched string contains only IPv4, it's not IPv6
  if (ipv4Match && ipv4Match[0] === match[0].trim()) {
    return false;
  }

  // Check for colons (IPv6 must have colons)
  if (!match[0].includes(':')) {
    return false;
  }

  return true;
}
