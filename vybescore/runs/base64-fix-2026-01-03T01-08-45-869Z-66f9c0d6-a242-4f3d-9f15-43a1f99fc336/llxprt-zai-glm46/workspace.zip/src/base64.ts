/**
 * Regular expression to validate Base64 strings.
 * Matches standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with optional padding (=).
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Encode plain text to Base64 using the standard alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding).
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate that input only contains valid Base64 characters
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Try to decode; Node.js will throw if the padding or encoding is invalid
  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Additional validation: if the result is empty but input wasn't, something's wrong
    if (result === '' && trimmed !== '') {
      // This could be valid Base64 that decodes to empty bytes, but let's verify
      // by checking if the buffer is actually empty
      const buffer = Buffer.from(trimmed, 'base64');
      if (buffer.length === 0 && trimmed.length > 0) {
        throw new Error('Invalid Base64 input: failed to decode');
      }
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
