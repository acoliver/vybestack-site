import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Starting debug test ===')

// Test 1: Basic computed dependency
console.log('Test 1: Basic computed dependency')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())
const timesTwo = createComputed(() => input() * 2)
console.log('Initial timesTwo:', timesTwo())
const timesThirty = createComputed(() => input() * 30)
console.log('Initial timesThirty:', timesThirty())
const sum = createComputed(() => timesTwo() + timesThirty())
console.log('Initial sum:', sum())
setInput(3)
console.log('After setInput(3):')
console.log('Input:', input())
console.log('TimesTwo:', timesTwo())
console.log('TimesThirty:', timesThirty())
console.log('Sum:', sum())
console.log('Expected sum: 96, Actual:', sum())

console.log('\nTest 2: Computed with callback')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => (value = output()))
console.log('Before update - Output:', output(), 'Value:', value)
setInput2(3)
console.log('After update - Output:', output(), 'Value:', value)
console.log('Expected value: 4, Actual:', value)

console.log('\nTest 3: Multiple callbacks')
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)
const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output3()))
const values2 = []
createCallback(() => values2.push(output3()))
console.log('Before update - Values1:', values1, 'Values2:', values2)
setInput3(31)
console.log('After setInput3(31) - Values1:', values1, 'Values2:', values2)
unsubscribe1()
setInput3(41)
console.log('After unsubscribe and setInput3(41) - Values1:', values1, 'Values2:', values2)
console.log('Expected: values2.length > values1.length, Actual:', values2.length, 'vs', values1.length)