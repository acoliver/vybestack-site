/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: updateFn,
  }
  
  // Execute initial callback to track dependencies
  function executeTrackDependencies() {
    // Set this callback as the active observer to track dependencies
    setActiveObserver(observer)
    try {
      // Execute initial callback to build dependency graph
      observer.value = updateFn(observer.value)
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Initial execution to set up dependencies
  executeTrackDependencies()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // Replace updateFn with a no-op function to prevent further execution
    observer.updateFn = () => value as T
  }
}
