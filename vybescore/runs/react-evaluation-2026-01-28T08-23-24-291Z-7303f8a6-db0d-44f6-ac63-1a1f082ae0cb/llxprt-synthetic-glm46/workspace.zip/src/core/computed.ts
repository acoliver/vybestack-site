/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFunction: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const dependentObservers = new Set<Observer<unknown>>()
  let isDirty = true
  let cachedValue: T = value as T
  let equalFn: EqualFn<T> | undefined
  
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === false) {
    // Always trigger updates when equal is false
    equalFn = () => false
  } else if (_equal === true || _equal === undefined) {
    // Default strict equality
    equalFn = (a, b) => a === b
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value: cachedValue,
    updateFn: (currentValue) => {
      // Mark as dirty to force recomputation on next access
      isDirty = true
      const newValue = updateFunction(currentValue)
      
      // Check if value actually changed using the equal function
      if (equalFn && !equalFn(cachedValue, newValue)) {
        // Notify all dependent observers that this value has changed
        for (const dependent of dependentObservers) {
          try {
            updateObserver(dependent)
          } catch (error) {
            // Prevent infinite recursion if there are circular dependencies
          }
        }
      }
      
      cachedValue = newValue
      isDirty = false
      return newValue
    },
  }
  
  const getter = (): T => {
    // If this computed value is being accessed within a reactive context,
    // register it as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      dependentObservers.add(activeObserver as Observer<unknown>)
    }
    
    // Only recompute if dirty
    if (isDirty) {
      // Set this computed value as the active observer to track its dependencies
      setActiveObserver(observer)
      try {
        const oldValue = cachedValue
        cachedValue = updateFunction(cachedValue)
        isDirty = false
        
        // Notify all dependent observers that this value may have changed
        if (!equalFn || !equalFn(oldValue, cachedValue)) {
          for (const dependent of dependentObservers) {
            try {
              updateObserver(dependent)
            } catch (error) {
              // Prevent infinite recursion if there are circular dependencies
            }
          }
        }
      } finally {
        setActiveObserver(undefined)
      }
    }
    
    return cachedValue
  }
  
  // Initial computation to track dependencies
  getter()
  
  return getter
}
