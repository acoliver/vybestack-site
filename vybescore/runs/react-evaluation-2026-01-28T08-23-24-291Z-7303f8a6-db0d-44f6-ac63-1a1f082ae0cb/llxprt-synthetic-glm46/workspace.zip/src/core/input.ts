/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers = new Set<Observer<unknown>>()
  let equalFn: EqualFn<T> | undefined
  
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === false) {
    // Always trigger updates when equal is false
    equalFn = () => false
  } else if (_equal === true || _equal === undefined) {
    // Default strict equality
    equalFn = (a, b) => a === b
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      observers.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    
    // Check if value actually changed using the equal function
    if (s.equalFn && s.equalFn(prevValue, nextValue)) return s.value
    
    // Update all dependent observers
    for (const observer of observers) {
      updateObserver(observer)
    }
    
    return s.value
  }

  return [read, write]
}
