export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email regex that handles most cases including plus tags
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots, trailing dots
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) return false;
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  // Validate local part (before @)
  const localPart = value.split('@')[0];
  if (!localPart || localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Ensure domain has at least one period
  if (!domain || !domain.includes('.')) return false;
  
  // Validate TLD (last part of domain)
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) return false;
  
  return true;
}

/**
 * Helper function to calculate Luhn checksum for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement US phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for standard US number)
  if (digits.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code and exchange code
  const areaCode = phoneNumber.slice(0, 3);
  const exchangeCode = phoneNumber.slice(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code cannot start with 0 or 1
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Handle optional +54 country code
  let phoneNumber = digits;
  if (phoneNumber.startsWith('54')) {
    phoneNumber = phoneNumber.slice(2);
  }
  
  // When country code is omitted, must start with trunk prefix 0
  if (!value.includes('+54') && !phoneNumber.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix 0 if present
  if (phoneNumber.startsWith('0')) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Remove mobile indicator 9 if present
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // At this point, phoneNumber should have area code + subscriber number
  if (phoneNumber.length < 8) return false; // Minimum: 2-digit area code + 6-digit subscriber
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode: string;
  let subscriberNumber: string;
  
  // Try 2-digit area code first
  if (phoneNumber.length >= 8) {
    areaCode = phoneNumber.slice(0, 2);
    subscriberNumber = phoneNumber.slice(2);
    
    // Check if subscriber number length is valid (6-8 digits)
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && 
        !areaCode.startsWith('0')) {
      return true;
    }
  }
  
  // Try 3-digit area code
  if (phoneNumber.length >= 9) {
    areaCode = phoneNumber.slice(0, 3);
    subscriberNumber = phoneNumber.slice(3);
    
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && 
        !areaCode.startsWith('0')) {
      return true;
    }
  }
  
  // Try 4-digit area code
  if (phoneNumber.length >= 10) {
    areaCode = phoneNumber.slice(0, 4);
    subscriberNumber = phoneNumber.slice(4);
    
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && 
        !areaCode.startsWith('0')) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Implement name validation.
 * Requirements are described in problem.md.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and "X Æ A-12" style names
  const nameRegex = /^[\p{L}\p{M}'\- .]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names with digits
  if (/\d/.test(value)) return false;
  
  // Reject names with certain symbols that shouldn't be in real names
  if (/[@#$%^&*()+=\\|[\]{}<>]/.test(value)) return false;
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject obviously fake patterns like "X Æ A-12"
  if (/^[A-Za-z]\s+Æ\s+[A-Za-z]-\d+$/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Implement credit card validation.
 * Requirements are described in problem.md.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if digits match any of the card patterns
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digits);
}