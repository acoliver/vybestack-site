/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  let result = text;
  
  // Capitalize first letter of the entire text
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Find sentences and capitalize first letter after sentence-ending punctuation
  // Look for ., ?, or ! followed by optional spaces and then a lowercase letter
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Clean up spacing - ensure exactly one space between sentences
  result = result.replace(/([.!?])\s+/g, '$1 '); // Single space after punctuation
  result = result.replace(/\s+([.!?])/g, '$1'); // Remove spaces before punctuation
  result = result.replace(/\s{2,}/g, ' '); // Collapse multiple spaces
  
  return result.trim();
}

/**
 * TODO: Extract all URLs from the text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern that matches most common URL formats
  // Includes protocol (http, https), domain with subdomains, optional paths, query, fragment
  const urlRegex = new RegExp('https?://[a-zA-Z0-9\\-._~:/?#\\[\\]@!$&\'()*+,;=%]+', 'g');
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation but keep it if it's part of the URL
  return matches.map(url => url.replace(/[.,;:!?)\]\\"'}]+$/g, ''));
}

/**
 * TODO: Replace http:// with https:// for all URLs in the text.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// for all URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Pattern to match URLs with the specified rules
  const urlPattern = /(https?):\/\/([^/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to HTTPS
    const secureProtocol = 'https';
    
    // Check if we should rewrite the host for docs paths
    // Skip if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /[?&=]/.test(path) || 
                           /cgi-bin/.test(path) ||
                           /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (protocol === 'http') {
      // Upgrade to HTTPS
      if (path.startsWith('/docs/') && !hasDynamicHints) {
        // Move docs to docs.example.com
        return `${secureProtocol}://docs.${host}${path}`;
      } else {
        // Just upgrade protocol
        return `${secureProtocol}://${host}${path}`;
      }
    }
    
    return match; // Leave unchanged
  });
}

/**
 * TODO: Extract the year from a mm/dd/yyyy format date string.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format where month is 1-12 and day is 1-31
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (match && match[3]) {
    // Validate that it's a reasonable year (e.g., between 1900 and 2100)
    const year = parseInt(match[3], 10);
    if (year >= 1900 && year <= 2100) {
      return match[3];
    }
  }
  
  return 'N/A';
}