/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create regex pattern for words starting with the prefix
  // \b ensures we match whole words only
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and return unique matches
  return [...new Set(matches.filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  ))];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to match token only when preceded by a digit
  // Match the digit + token pattern
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, abcabc, etc.)
  // Check for patterns of 2+ characters repeated immediately
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First check if this contains IPv6-like patterns (colons)
  if (!value.includes(':')) return false;
  
  // IPv6 patterns (simplified version)
  // Full IPv6: eight groups of 1-4 hex digits separated by colons
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed IPv6 with :: 
  const compressedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}?\b/;
  
  // IPv6 with mixed IPv4 at end
  const mixedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Simple IPv6 pattern catch-all
  const simpleIPv6 = /\b[0-9a-fA-F:]+\b/;
  
  // Make sure it's not just IPv4 with a colon
  const hasIPv6Pattern = fullIPv6.test(value) || compressedIPv6.test(value) || mixedIPv6.test(value);
  
  if (!hasIPv6Pattern && simpleIPv6.test(value)) {
    // Check for basic IPv6 characteristics
    const parts = value.split(':');
    if (parts.length >= 2 && parts.some(part => part.length > 0 && part.length <= 4)) {
      return true;
    }
  }
  
  return hasIPv6Pattern;
}
