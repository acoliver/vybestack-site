/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  subscribeObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Subscribe observer to track dependencies
  subscribeObserver(o)
  
  // Initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    // Track dependencies when this computed value is accessed
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // This computed value becomes a dependency of the active observer
      const originalUpdateFn = o.updateFn
      o.updateFn = (prev?: T) => {
        const result = originalUpdateFn(prev)
        // Notify the dependent observer
        updateObserver(activeObserver as Observer<T>)
        return result
      }
    }
    
    return o.value!
  }
  
  return getter
}
