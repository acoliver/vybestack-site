import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server.js';

let close: (() => void) | null = null;
let app: Parameters<typeof request>[0];
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const server = await startServer();
  app = server.app;
  close = server.close;
});

afterAll(() => {
  if (close) {
    close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Remove existing database for clean test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'jane.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Test thank-you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('.thankyou-card').length).toBeGreaterThan(0);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Smith',
      streetAddress: '456 High Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'invalid-email',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('email');
  });

  it('validates phone format', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Smith',
      streetAddress: '456 High Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john@example.com',
      phone: 'invalid-phone!'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text().toLowerCase();
    expect(errorText).toContain('phone');
  });

  it('accepts international postal codes', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const ukData = {
      firstName: 'James',
      lastName: 'Bond',
      streetAddress: 'MI6 Building',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: '007@mi6.gov.uk',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(ukData);

    expect(response.status).toBe(302);
  });
});
