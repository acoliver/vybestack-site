import express, { Express } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';
import fs from 'node:fs';
import { Server } from 'node:http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateForm(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code must contain only letters, digits, spaces, and hyphens' });
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +' });
  }

  return errors;
}

async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  let dbInstance: Database;
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, buffer);
  }

  return dbInstance;
}

function saveDatabase(dbInstance: Database): void {
  const data = dbInstance.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

async function createApp(): Promise<express.Express> {
  const app = express();

  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));

  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });

  app.post('/submit', (req, res) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvince: req.body.stateProvince?.trim() || '',
      postalCode: req.body.postalCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone: req.body.phone?.trim() || '',
    };

    const errors = validateForm(formData);

    if (errors.length > 0) {
      res.status(400);
      return res.render('form', {
        errors: errors.map(e => e.message),
        values: formData
      });
    }

    if (!db) {
      throw new Error('Database not initialized');
    }

    db.run(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );

    saveDatabase(db);

    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });

  return app;
}

async function startServer(): Promise<{ app: Express; close: () => void }> {
  db = await initDatabase();
  
  const app = await createApp();
  
  // In dist, __dirname will be dist/, so we need to go to ../src/templates
  // In src (dev mode), __dirname will be src/, so templates is in templates/
  const isDist = __dirname.endsWith('dist');
  const templatesPath = isDist 
    ? path.join(__dirname, '..', 'src', 'templates')
    : path.join(__dirname, 'templates');
  
  app.set('views', templatesPath);
  app.set('view engine', 'ejs');
  
  const httpServer: Server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  const close = (): void => {
    if (db) {
      db.close();
      db = null;
    }
    if (httpServer) {
      httpServer.close();
    }
  };

  process.on('SIGTERM', close);
  process.on('SIGINT', close);

  return { app, close };
}

// Only auto-start the server when run directly (not when imported)
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { startServer };
