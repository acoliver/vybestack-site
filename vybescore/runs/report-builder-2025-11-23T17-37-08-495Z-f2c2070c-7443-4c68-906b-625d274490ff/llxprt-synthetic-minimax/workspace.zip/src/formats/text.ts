import { ReportData, CliOptions, Formatter } from '../types.js';

export const renderText: Formatter = {
  render(data: ReportData, options: CliOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Render each entry
    for (const entry of data.entries) {
      const formattedAmount = `$${entry.amount.toFixed(2)}`;
      lines.push(`- ${entry.label}: ${formattedAmount}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push('');
      lines.push(`Total: $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
};