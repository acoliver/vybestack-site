import { describe, it, expect } from 'vitest';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';
import { ReportData } from './types.js';

describe('Formatters', () => {
  const sampleData: ReportData = {
    title: 'Quarterly Financial Summary',
    summary: 'Highlights include record revenue across regions and a healthy outlook for the next quarter.',
    entries: [
      { label: 'North Region', amount: 12345.67 },
      { label: 'South Region', amount: 23456.78 },
      { label: 'West Region', amount: 34567.89 }
    ]
  };

  describe('Markdown Formatter', () => {
    it('should render markdown without totals', () => {
      const output = renderMarkdown.render(sampleData, {
        format: 'markdown',
        includeTotals: false
      });

      const expected = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;

      expect(normalizeWhitespace(output)).toBe(normalizeWhitespace(expected));
    });

    it('should render markdown with totals', () => {
      const output = renderMarkdown.render(sampleData, {
        format: 'markdown',
        includeTotals: true
      });

      const expected = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34`;

      expect(normalizeWhitespace(output)).toBe(normalizeWhitespace(expected));
    });
  });

  describe('Text Formatter', () => {
    it('should render text without totals', () => {
      const output = renderText.render(sampleData, {
        format: 'text',
        includeTotals: false
      });

      const expected = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;

      expect(normalizeWhitespace(output)).toBe(normalizeWhitespace(expected));
    });

    it('should render text with totals', () => {
      const output = renderText.render(sampleData, {
        format: 'text',
        includeTotals: true
      });

      const expected = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34`;

      expect(normalizeWhitespace(output)).toBe(normalizeWhitespace(expected));
    });
  });
});

// Helper function to normalize whitespace for comparison
function normalizeWhitespace(str: string): string {
  return str.trim().replace(/\n\s*\n/g, '\n');
}