import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions, Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(argv: string[]): { filePath: string; options: CliOptions } {
  if (argv.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const filePath = argv[2];
  const args = argv.slice(3);
  
  let format: string | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[++i];
    } else if (arg === '--output') {
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('Missing required --format argument');
  }

  return {
    filePath,
    options: { format: format as 'markdown' | 'text', output, includeTotals }
  };
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const typedEntry = entry as Record<string, unknown>;

    if (typeof typedEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }

    if (typeof typedEntry.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid JSON:')) {
        throw error;
      }
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      }
      throw new Error(`Failed to read file: ${error.message}`);
    }
    throw new Error('Unknown error reading file');
  }
}

function main(): void {
  try {
    const { filePath, options } = parseArgs(process.argv);
    
    if (!(options.format in formatters)) {
      throw new Error(`Unsupported format: ${options.format}`);
    }

    const data = loadReportData(filePath);
    const formatter = formatters[options.format];
    const output = formatter.render(data, options);

    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    }
    console.error('Unknown error occurred');
    process.exit(1);
  }
}

main();