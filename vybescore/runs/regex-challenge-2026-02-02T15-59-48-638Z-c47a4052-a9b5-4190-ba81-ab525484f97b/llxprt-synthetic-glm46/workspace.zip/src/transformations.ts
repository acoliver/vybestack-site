/**
 * Capitalizes the first character of each sentence, inserts exactly one space 
 * between sentences even if input omitted it, and collapses extra spaces while 
 * preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces to single spaces
  text = text.replace(/\s+/g, ' ');
  
  // Add space after sentence-ending punctuation if missing
  text = text.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Capitalize first character of each sentence after sentence boundaries
  text = text.replace(/^([a-z])|([.!?]\s+)([a-z])/g, (match, startLetter, sep, sentenceStart) => {
    if (startLetter) {
      return startLetter.toUpperCase();
    }
    return sep + sentenceStart.toUpperCase();
  });
  
  // Capitalize the very first character if it's lowercase
  if (text.length > 0) {
    text = text.charAt(0).toUpperCase() + text.slice(1);
  }
  
  return text;
}

/**
 * Returns all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https and various domain formats
  const urlRegex = /\b(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?\b/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each match
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// protocols with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // First, ensure all http protocols become https
  text = text.replace(/http:\/\//g, 'https://');
  
  // Find all https://example.com/... URLs and potentially rewrite them
  return text.replace(/\bhttps:\/\/example\.com(\/(?:docs\/[^\s?]*)?)\b/g, (match, path) => {
    // If there's no path or it starts with /docs/, we might need to rewrite
    if (!path) {
      // No path, don't rewrite
      return match;
    }
    
    // Check if path contains dynamic hints that should prevent rewriting
    const dynamicPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)/
    ];
    
    if (dynamicPatterns.some(pattern => pattern.test(path))) {
      // Contains dynamic hints, only keep the protocol upgrade
      return match;
    }
    
    // Path starts with /docs/ and doesn't have dynamic content
    if (path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
    
    // Regular path, keep as is
    return match;
  });
}

/**
 * Returns the four-digit year for mm/dd/yyyy format.
 * If the format is invalid or month/day are invalid, returns 'N/A'.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Validate actual month and day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for valid days in each month
  const maxDays = [
    31, // January
    29, // February (we're not checking leap years explicitly)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (dayNum > maxDays[monthNum - 1]) {
    return 'N/A';
  }
  
  // Check for February 29 specifically (simple leap year check)
  if (monthNum === 2 && dayNum === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return year;
}
