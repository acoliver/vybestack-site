export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address according to common requirements.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (/\.{2,}/.test(value)) {
    return false;
  }
  
  // Reject dot at start or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject domain with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject invalid characters in domain
  if (!/^[a-zA-Z0-9.-]+$/.test(domain)) {
    return false;
  }
  
  // Reject double dots in domain
  if (/\.{2,}/.test(domain)) {
    return false;
  }
  
  // Reject domain segments starting or ending with dot
  const domainSegments = domain.split('.');
  if (domainSegments.some(segment => segment.startsWith('-') || segment.endsWith('-') || segment === '')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 country code.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // If options are unused, note that we might use them in future
  if (options?.allowExtensions) {
    // Future extension handling could be added here
  }
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be at least 10 digits (without country code) or 11 digits (with country code)
  if (digits.length < 10) {
    return false;
  }
  
  // If 11 digits, country code must be 1
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }
  
  // If more than 11 digits, invalid
  if (digits.length > 11) {
    return false;
  }
  
  // Extract area code (last 10 digits, or if 11 digits, last 10 digits)
  const areaCode = digits.length === 11 ? digits.substring(1, 4) : digits.substring(0, 4);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Basic format validation
  if (digits.length === 10) {
    // Accept formats like (212) 555-7890, 212-555-7890, 2125557890
    return /^\d{10}$/.test(digits);
  } else if (digits.length === 11) {
    // Must start with 1
    return /^1\d{10}$/.test(digits);
  }
  
  return false;
}

/**
 * Validates Argentine phone numbers including landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code when country code is present
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0 before area code
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Basic pattern: [+54][9][area][subscriber] or [0][area][subscriber]
  const argentinePhoneRegex = /^(\+54|0)?9?(\d{2,4})(\d{6,8})$/;
  const match = argentinePhoneRegex.exec(cleanValue);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, areaCode, subscriber] = match;
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }
  
  // Check rules for country code presence
  if (countryCode) {
    // When country code is present, trunk prefix is optional
    // Mobile prefix (9) is allowed
    return true;
  } else {
    // When country code is omitted, must begin with trunk prefix '0'
    // This is already handled by the regex (cleanValue must start with 0)
    if (!cleanValue.startsWith('0')) {
      return false;
    }
    return true;
  }
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/[A-Za-z\u00C0-\uFFFF]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens, and common diacritics
  const nameRegex = /^[A-Za-z\u00C0-\uFFFF\s'-]+$/;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject consecutive dots, apostrophes, or hyphens
  if (/[.'']{2,}|--/.test(value)) {
    return false;
  }
  
  // Cannot start or end with space, apostrophe, or hyphen
  if (/^[\s'-]|['\s-]$/.test(value)) {
    return false;
  }
  
  // Reject names that look like "X Æ A-12" (should not have numbers)
  // This is a guard against overly complex symbol combinations
  const nonLetterChars = /[^\p{L}\s'-]/u;
  if (nonLetterChars.test(value)) {
    // If there are non-letter characters besides spaces, apostrophes, and hyphens, reject
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be 13-19 digits (typical credit card length range)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check if it matches known credit card formats
  const isVisa = /^4/.test(digits) && [13, 16].includes(digits.length);
  const isMastercard = /^5[1-5]/.test(digits) && digits.length === 16;
  const isMastercardNew = /^2(2[2-9]|[3-6]\d|7[01]|720)/.test(digits) && digits.length === 16;
  const isAmex = /^3[47]/.test(digits) && digits.length === 15;
  
  if (!isVisa && !isMastercard && !isMastercardNew && !isAmex) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(digits);
}

/**
 * Runs Luhn checksum validation on a credit card number.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    const digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled = doubled - 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
