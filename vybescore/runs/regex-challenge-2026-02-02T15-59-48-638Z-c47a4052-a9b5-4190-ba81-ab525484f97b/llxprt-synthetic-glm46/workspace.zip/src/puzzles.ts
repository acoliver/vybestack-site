/**
 * Finds words beginning with the prefix excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern that finds words starting with the prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[A-Za-z]+)\\b`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    
    // Check if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern that matches token preceded by a digit, including the digit in the match
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  
  // Replace to find all matches
  text.replace(tokenPattern, (match) => {
    matches.push(match);
    return match;
  });
  
  return matches;
}

/**
 * Validates passwords: At least 10 characters, one uppercase, one lowercase, 
 * one digit, one symbol, no whitespace, and no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[{};'":|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab", "123123", etc.)
  for (let i = 2; i <= value.length / 2; i++) {
    // Check for patterns repeated exactly twice immediately
    const repeatedPatternRegex = new RegExp(`(.{${i}})\\1`);
    if (repeatedPatternRegex.test(value)) {
      // Check if the repetition is immediate (no other characters between)
      for (let j = 0; j <= value.length - (2 * i); j++) {
        const segment1 = value.substring(j, j + i);
        const segment2 = value.substring(j + i, j + (2 * i));
        // If both segments are equal and identical, it's an immediate repeat
        if (segment1 === segment2) {
          // Additional check: make sure the segment has at least 2 distinct characters
          const uniqueChars = new Set(segment1).size;
          if (uniqueChars >= 2) {
            return false;
          }
        }
      }
    }
  }
  
  // Check for obviously weak patterns like "password", "qwerty", etc.
  const weakPatterns = [
    /password/i,
    /qwerty/i,
    /letmein/i,
    /admin/i,
    /12345678/,
    /abcdefgh/i,
    /abc123/i
  ];
  
  if (weakPatterns.some(pattern => pattern.test(value))) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns - use word boundaries to ensure we match full IPv6 addresses
  const ipv6Patterns = [
    // Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /\b[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}\b/,
    // Shortened form with :: (like 2001:db8::8a2e:370:7334)
    /\b[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,7}::[0-9a-fA-F]{0,4}(:[0-9a-fA-F]{1,4}){0,7}\b/,
    // With IPv4 embedded: ::ffff:192.0.2.128
    /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/,
    // Just :: (standalone)
    /\b::\b/,
    // Loopback: ::1
    /\b::1\b/,
    // Link-local: fe80::1
    /\bfe80:([0-9a-fA-F]{1,4}:){0,4}[0-9a-fA-F]{1,4}\b/,
    // Unique local: fc00::
    /\bfc[0-9a-fA-F]{1}:/,
    // Multicast: ff0e::
    /\bff[0-9a-fA-F]{2}:/
  ];
  
  // Check if any IPv6 pattern matches
  const hasIPv6Pattern = ipv6Patterns.some(pattern => pattern.test(value));
  
  // If no IPv6 pattern matches, return false
  if (!hasIPv6Pattern) {
    return false;
  }
  
  // Check if the entire string is a valid IPv4 address - if so, return false
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // If we found an IPv6 pattern and it's not a pure IPv4 address, return true
  return true;
}
