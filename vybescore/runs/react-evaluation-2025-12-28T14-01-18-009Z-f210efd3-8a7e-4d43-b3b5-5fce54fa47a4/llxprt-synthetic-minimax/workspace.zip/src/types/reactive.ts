/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T
export type InputPair<T> = [GetterFn<T>, SetterFn<T>]
export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  observers: Set<Observer<any>>
  subjects: Subject<any>[]
}

export interface Subject<T> {
  name?: string
  value: T
  observers: Set<Observer<any>>
  equalFn?: EqualFn<T>
}

// Global tracking for reactive dependencies
let activeObserver: Observer<any> | undefined = undefined
const allObservers = new Set<Observer<any>>()

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T | undefined {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    if (result !== undefined) {
      observer.value = result
    }
    return result
  } finally {
    activeObserver = previous
  }
}

export function registerObserver<T>(observer: Observer<T>): void {
  allObservers.add(observer)
}

export function cleanupObserver<T>(observer: Observer<T>): void {
  allObservers.delete(observer)
}

export function registerDependency<T>(subject: Subject<T>, observer: Observer<T>): void {
  // Register the observer with the subject
  subject.observers = subject.observers || new Set()
  subject.observers.add(observer)
  
  // Register the subject with the observer
  observer.subjects = observer.subjects || []
  if (!observer.subjects.includes(subject)) {
    observer.subjects.push(subject)
  }
}

export function notifySubject<T>(subject: Subject<T>): void {
  // Notify all observers of this subject
  if (subject.observers) {
    const observerList = Array.from(subject.observers)
    observerList.forEach(obs => {
      if (allObservers.has(obs)) {
        updateObserver(obs)
      }
    })
  }
}

export function notifyDependents<T>(observer: Observer<T>): void {
  // Notify all observers that depend on this one
  if (observer.observers) {
    const dependentList = Array.from(observer.observers)
    dependentList.forEach(dep => {
      if (allObservers.has(dep)) {
        updateObserver(dep)
      }
    })
  }
}
