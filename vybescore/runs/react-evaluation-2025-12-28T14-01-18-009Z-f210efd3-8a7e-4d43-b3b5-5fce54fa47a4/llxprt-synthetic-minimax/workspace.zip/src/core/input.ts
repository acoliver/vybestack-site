/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  registerDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    observers: new Set(),
    equalFn: equal,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    
    // Notify all observers if value changed
    if (!s.equalFn || !s.equalFn(prevValue, nextValue)) {
      if (s.observers) {
        // Create snapshot to avoid iterator issues
        const observerList = Array.from(s.observers)
        observerList.forEach(obs => {
          updateObserver(obs)
        })
      }
    }
    return s.value
  }

  return [read, write]
}
