/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerObserver, cleanupObserver, setActiveObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: [],
    observers: new Set(),
  }
  
  // Register observer to track dependencies and set up reactivity
  registerObserver(observer)
  
  let disposed = false
  
  // Execute the callback with proper observer context and establish dependencies
  const executeCallback = () => {
    if (disposed) return
    const previousActive = getActiveObserver()
    try {
      setActiveObserver(observer)
      const result = updateObserver(observer)
      if (result !== undefined) {
        observer.value = result
      }
    } finally {
      setActiveObserver(previousActive)
    }
  }
  
  // Execute callback to establish dependencies and set initial value
  executeCallback()
  
  // Set up reactivity: register callback as dependent of all computed values it accesses
  observer.subjects.forEach(subject => {
    if (!subject.observers) subject.observers = new Set()
    subject.observers.add(observer as unknown as Observer<unknown>)
  })
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove callback from all dependency lists
    observer.subjects.forEach(subject => {
      if (subject.observers) {
        subject.observers.delete(observer as unknown as Observer<unknown>)
      }
    })
    
    // Cleanup by unregistering 
    cleanupObserver(observer)
  }
}
