/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  notifyDependents,
  registerObserver,
  updateObserver,
  registerDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: [],
    observers: new Set(),
  }
  
  // Register the computed observer to enable dependency tracking
  registerObserver(o)
  
  const getter: GetterFn<T> = () => {
    // Check if we're being accessed during dependency tracking
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // Register dependency between this computed value and the active observer
      registerDependency(o as unknown as any, activeObserver)
      
      // Also register the active observer as a dependent of this computed value
      o.observers.add(activeObserver as unknown as Observer<any>)
    }
    
    // Re-evaluate our value
    const prevValue = o.value
    updateObserver(o)
    
    // Notify dependents if value changed
    if (prevValue !== o.value && o.observers.size > 0) {
      notifyDependents(o)
    }
    
    return o.value!
  }
  
  return getter
}
