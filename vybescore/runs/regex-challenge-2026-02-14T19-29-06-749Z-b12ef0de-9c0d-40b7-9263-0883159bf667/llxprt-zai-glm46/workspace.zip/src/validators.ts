export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Based on RFC 5322 with practical restrictions
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)(?!.*\.@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for consecutive dots anywhere
  if (/\.\./.test(value)) return false;
  
  // Check for trailing dot in local part or domain
  if (/\.(?=@)|@\./.test(value)) return false;
  
  // Check for underscore in domain
  const domainMatch = value.match(/@(.+)$/);
  if (domainMatch && /_/.test(domainMatch[1])) return false;
  
  // Check for leading/trailing dots in the entire email
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Check for dot at the start of local part
  if (/^\./.test(value)) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Minimum length check (area code + 7 digits = 10, or 11 with country code)
  if (cleaned.length < 10 || cleaned.length > 11) return false;
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.length === 11) {
    if (digits.startsWith('1')) {
      digits = digits.slice(1);
    } else {
      return false; // 11 digits but doesn't start with 1
    }
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check exchange code (first digit of central office code) doesn't start with 0 or 1
  const exchangeCode = digits[3];
  if (exchangeCode === '0' || exchangeCode === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match: optional +54, optional 0 trunk prefix, optional 9 mobile indicator, area code, subscriber number
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentineRegex = /^(?:\+?54)?(?:0)?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentineRegex);
  if (!match) return false;
  
  // When country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  const startsWithZero = value.trim().startsWith('0');
  
  if (!hasCountryCode && !startsWithZero) return false;
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check for minimum length and no whitespace-only names
  if (!value || value.trim().length < 1) return false;
  
  // Reject names with digits
  if (/\d/.test(value)) return false;
  
  // Reject common special symbols that shouldn't be in names
  const invalidSymbols = /[!"#$%&()*+,.:;<=>?@[\\\]^`{|}~°©®™]/u;
  if (invalidSymbols.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length: Visa (16), Mastercard (16), AmEx (15)
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check prefixes
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const validPrefixes = [
    /^4\d{12,18}$/, // Visa
    /^5[1-5]\d{14}$/, // Mastercard 51-55
    /^2[2-7]\d{14}$/, // Mastercard 2xxx
    /^2[2-7][0-9]{2}\d{12}$/, // Mastercard 4-digit prefix
    /^3[47]\d{13}$/ // AmEx
  ];
  
  const validPrefix = validPrefixes.some(pattern => pattern.test(cleaned));
  if (!validPrefix) return false;
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
