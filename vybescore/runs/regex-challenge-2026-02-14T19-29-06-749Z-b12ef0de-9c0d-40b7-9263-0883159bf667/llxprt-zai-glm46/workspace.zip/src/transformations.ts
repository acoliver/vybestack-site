/**
 * Capitalizes the first character of each sentence.
 * Insert exactly one space between sentences and collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ');
  
  // Insert space after sentence endings if missing (but not before punctuation)
  normalized = normalized.replace(/([.!?])([a-z])/gi, '$1 $2');
  
  // Split into sentences by sentence-ending punctuation
  // Use a regex that matches .!? followed by whitespace or end of string
  const sentences = normalized.split(/([.!?]\s*)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (!part) continue;
    
    // If this is a sentence-ending punctuation
    if (/^[.!?]+\s*$/.test(part)) {
      result += part;
      capitalizeNext = true;
    } else {
      // This is actual text
      if (capitalizeNext && part.length > 0) {
        result += part.charAt(0).toUpperCase() + part.slice(1);
        capitalizeNext = false;
      } else {
        result += part;
      }
    }
  }
  
  return result;
}

/**
 * Extracts all URLs from the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http, https, www)
  // Captures the URL without trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"'()]+[^.,;!?)\s<>"']/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;!)?]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs.
 * - Always upgrades scheme to https://
 * - Rewrites /docs/ paths to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, ?, &, =, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com/... URLs
  const urlRegex = /(https?:\/\/example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, host, path) => {
    // Always upgrade to https
    const secureHost = host.replace(/^http:/, 'https:');
    
    // Check if path contains dynamic hints
    const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return `${secureHost}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
