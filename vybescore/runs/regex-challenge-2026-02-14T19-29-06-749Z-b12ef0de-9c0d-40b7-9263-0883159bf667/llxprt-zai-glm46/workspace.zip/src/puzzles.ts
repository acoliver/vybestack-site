/**
 * Finds words starting with the given prefix, excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words starting with prefix
  // \b word boundary ensures we match whole words
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
}

/**
 * Finds occurrences of token that appear after a digit.
 * Token must not be at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to find token preceded by digit (not at start)
  const regex = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[1] + match[2]);
  }
  
  return matches;
}

/**
 * Validates passwords according to strength policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like "abab", "123123")
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatedPatternRegex = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatedPatternRegex.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Extract potential IPs from text
  const ipRegex = /[0-9a-fA-F:]+/g;
  const matches = value.match(ipRegex) || [];
  
  for (const match of matches) {
    // Check if it looks like an IPv6 address (contains at least one colon)
    if (match.includes(':')) {
      // Must not look like a time (HH:MM:SS or HH:MM)
      const timePattern = /^\d{1,2}:\d{2}(:\d{2})?$/;
      if (timePattern.test(match)) continue;
      
      // Must have at least 2 colons to be IPv6 (or be compressed form)
      if ((match.match(/:/g) || []).length < 2) continue;
      
      // Check for :: anywhere in the string
      if (match.includes('::') && match.length > 2) {
        return true;
      }
      
      // Check for 8 groups of hex separated by 7 colons (full form)
      const fullForm = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/.test(match);
      if (fullForm) return true;
      
      // Check for compressed form (starts with :: or has :: in middle)
      const compressedForm = /^::|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*$/.test(match);
      if (compressedForm && match.length > 2) return true;
    }
  }
  
  return false;
}
