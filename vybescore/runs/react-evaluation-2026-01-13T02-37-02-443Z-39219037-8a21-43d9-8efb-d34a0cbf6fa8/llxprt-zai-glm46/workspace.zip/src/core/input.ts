/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Track multiple observers that depend on this input
  const observers = new Set<Observer<T>>()
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<T>)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Always update and propagate - even if value is the same
    // This ensures computed values re-evaluate properly
    value = nextValue
    
    // Update all observers that depend on this input
    // Use a copy to avoid issues if observers are modified during iteration
    const observersToUpdate = Array.from(observers)
    for (const observer of observersToUpdate) {
      // Use updateObserver to properly manage the active observer context
      // This ensures dependency tracking works correctly when the observer
      // reads from other reactive sources
      updateObserver(observer)
    }
    
    return value
  }

  return [read, write]
}
