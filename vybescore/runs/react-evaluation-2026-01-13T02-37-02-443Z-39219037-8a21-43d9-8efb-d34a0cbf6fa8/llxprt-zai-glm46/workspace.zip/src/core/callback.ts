/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Wrap the update function to set ourselves as active
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    // Set ourselves as active to track dependencies
    setActiveObserver(observer)
    
    try {
      const result = originalUpdateFn(prevValue)
      return result
    } finally {
      // Restore previous observer
      setActiveObserver(undefined)
    }
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
