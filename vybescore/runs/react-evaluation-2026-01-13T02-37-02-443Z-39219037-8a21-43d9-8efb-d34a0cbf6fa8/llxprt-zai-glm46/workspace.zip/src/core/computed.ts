/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed value
  const dependentObservers = new Set<Observer<T>>()
  
  // Track which inputs this computed depends on (set during each update)
  const dependencies = new Set<Observer<T>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Wrap the update function to handle dependency tracking and propagation
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Clear old dependencies before re-computing
    dependencies.clear()
    
    // Set ourselves as active to track which inputs we read
    setActiveObserver(o)
    
    try {
      // Compute the new value - this will register dependencies
      const updateResult = originalUpdateFn(prevValue)
      
      // Store the result in the observer
      o.value = updateResult
      
      return updateResult
    } finally {
      // Restore previous observer
      setActiveObserver(undefined)
      
      // After computing, propagate updates to dependent observers
      // Convert Set to Array to avoid concurrent modification
      const dependentsArray = Array.from(dependentObservers)
      for (const observer of dependentsArray) {
        updateObserver(observer)
      }
    }
  }
  
  // Compute initial value
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    // Track dependencies when this computed value is read
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add this computed as a dependent of the active observer
      dependentObservers.add(activeObserver as Observer<T>)
      
      // Also add the active observer to our dependencies
      // This creates a bidirectional link for proper propagation
      dependencies.add(activeObserver as Observer<T>)
    }
    
    return o.value!
  }
  
  return read
}
