/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string contains only Base64 valid characters.
 * According to the Base64 specification, lengths not divisible by 4 are allowed
 * if they represent valid Base64 strings without padding.
 */
function isValidBase64(input: string): boolean {
  // Empty string is technically valid Base64 (represents empty input)
  if (input.length === 0) {
    return true;
  }
  
  // Base64 valid characters: A-Z, a-z, 0-9, +, /, and optional padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check padding rules
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding characters can only appear at the end
    if (paddingIndex < input.length - 2) {
      return false;
    }
    
    // After padding starts, only padding characters are allowed
    const padding = input.slice(paddingIndex);
    if (!/^(=|==)$/.test(padding)) {
      return false;
    }
    
    // If there's padding, the length must be divisible by 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Empty input is valid and decodes to an empty string
  if (input.length === 0) {
    return '';
  }
  
  // Validate the input is a properly formatted Base64 string
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters or incorrect padding');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify that encoding back to Base64 produces a valid representation
    // This helps catch cases where Node.js silently decodes invalid input
    const encodedBack = Buffer.from(result, 'utf8').toString('base64');
    
    // Check if the input is equivalent (modulo optional padding)
    const normalizedInput = input.replace(/=*$/, '');
    const normalizedEncoded = encodedBack.replace(/=*$/, '');
    
    if (normalizedInput !== normalizedEncoded) {
      throw new Error('Invalid Base64 input: fails round-trip validation');
    }
    
    return result;
  } catch (error) {
    // Re-throw with a clear message
    throw new Error('Invalid Base64 input: contains invalid characters or incorrect padding');
  }
}
