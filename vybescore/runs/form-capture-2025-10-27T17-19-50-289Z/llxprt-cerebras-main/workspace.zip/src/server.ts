import express, { Application, Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app: Application = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: Database | null = null;
let server: any = null;

async function initializeDatabase() {
  // Initialize sql.js with local files
  const SQL = await initSqlJs({
    locateFile: (filename: string) => path.join(__dirname, `../node_modules/sql.js/dist/${filename}`)
  });

  const dbPath = path.join(__dirname, '../data/submissions.sqlite');

  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+\d\s()-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes with spaces and dashes
  const postalCodeRegex = /^[\dA-Za-z\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body;
  const errors: Record<string, string> = {};
  
  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!formData[field] || formData[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  });
  
  // Email validation - only if field is provided
  if (formData.email && !validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation - only if field is provided
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation - only if field is provided
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }
  
  // Insert data into database
  const stmt = db!.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
  
  // Save database to file
  const data = db!.export();
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  fs.writeFileSync(dbPath, data);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Start server and initialize database
async function startServer() {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
  return server;
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing server');
  if (server) {
    server.close(() => {
      console.log('Server closed');
    });
  }
  
  // Close database
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    fs.writeFileSync(dbPath, buffer);
    db.close();
  }
});

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(console.error);
}

export default app;
export { server, startServer };