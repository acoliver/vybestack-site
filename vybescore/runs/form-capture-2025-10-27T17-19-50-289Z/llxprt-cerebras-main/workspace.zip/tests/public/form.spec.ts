import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');
let server: any;

beforeAll(async () => {
  server = await startServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(server).get('/');
    expect(res.status).toBe(200);
    
    const $ = load(res.text);
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1-555-123-4567'
      })
      .expect(302);
      
    expect(res.header.location).toBe('/thank-you');
  });
  
  it('shows validation errors for invalid email', async () => {
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1-555-123-4567'
      })
      .expect(400);
      
    const $ = load(res.text);
    expect($('.form-error').text()).toContain('Please enter a valid email address');
  });
  
  it('shows validation errors for invalid phone number', async () => {
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: 'invalid-phone'
      })
      .expect(400);
      
    const $ = load(res.text);
    expect($('.form-error').text()).toContain('Please enter a valid phone number');
  });
  
  it('accepts international postal codes and phone numbers', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Test with Argentine format postal code and phone number
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'María',
        lastName: 'González',
        streetAddress: 'Calle Falsa 123',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria@example.com',
        phone: '+54 9 11 1234-5678'
      })
      .expect(302);
      
    expect(res.header.location).toBe('/thank-you');
  });
  
  it('renders thank-you page with humorous content', async () => {
    const res = await request(server).get('/thank-you');
    expect(res.status).toBe(200);
    
    const $ = load(res.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('p').eq(0).text()).toContain('safe(ish)');
    expect($('p').eq(1).text()).toContain('stranger on the internet');
  });
});