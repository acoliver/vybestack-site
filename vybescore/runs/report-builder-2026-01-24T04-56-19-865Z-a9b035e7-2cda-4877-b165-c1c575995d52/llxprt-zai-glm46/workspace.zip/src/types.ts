/**
 * Data model for report entries.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering.
 */
export interface RenderOptions {
  includeTotals: boolean;
}
