#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Map of format names to renderer functions.
 */
const formatters: Record<string, (data: ReportData, options: RenderOptions) => string> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * CLI configuration parsed from command line arguments.
 */
interface CliConfig {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parse command line arguments.
 */
function parseArgs(argv: string[]): CliConfig {
  const args = argv.slice(2);

  if (args.length === 0) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Validate report data structure.
 */
function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI entry point.
 */
function main(): void {
  const config = parseArgs(process.argv);

  // Read and parse input file
  let jsonData: unknown;
  try {
    const content = fs.readFileSync(config.inputFile, 'utf-8');
    jsonData = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON in ${config.inputFile}: ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${config.inputFile}`);
      process.exit(1);
    }
    console.error(`Error: Failed to read ${config.inputFile}: ${error}`);
    process.exit(1);
  }

  // Validate data structure
  const data = validateReportData(jsonData);

  // Check format support
  const formatter = formatters[config.format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${config.format}`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  // Render report
  const options: RenderOptions = { includeTotals: config.includeTotals };
  const output = formatter(data, options);

  // Write output
  if (config.outputPath) {
    try {
      fs.writeFileSync(config.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to ${config.outputPath}: ${error}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();

