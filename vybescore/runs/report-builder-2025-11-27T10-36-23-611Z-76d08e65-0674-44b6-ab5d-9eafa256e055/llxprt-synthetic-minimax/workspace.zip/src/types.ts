// Shared types and interfaces for the report builder

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface RenderOptions {
  includeTotals: boolean;
}

export interface Formatter {
  format: (data: ReportData, options: RenderOptions) => string;
}