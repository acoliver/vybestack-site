import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  filePath: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const filePath = args[2];
  const formatArgIndex = args.findIndex(arg => arg === '--format');
  
  if (formatArgIndex === -1) {
    throw new Error('Missing --format argument');
  }

  if (formatArgIndex + 1 >= args.length) {
    throw new Error('Missing format value');
  }

  const format = args[formatArgIndex + 1];
  
  // Validate supported formats
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  const outputIndex = args.findIndex(arg => arg === '--output');
  const output = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    filePath,
    format,
    output,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(rawData) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${i} missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entry ${i} missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown.format(data, options);
    case 'text':
      return renderText.format(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const parsedArgs = parseArgs(args);
    
    const reportData = loadReportData(parsedArgs.filePath);
    
    const renderOptions: RenderOptions = {
      includeTotals: parsedArgs.includeTotals
    };
    
    const renderedOutput = renderReport(reportData, parsedArgs.format, renderOptions);
    
    if (parsedArgs.output) {
      writeFileSync(parsedArgs.output, renderedOutput, 'utf-8');
    } else {
      console.log(renderedOutput);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();