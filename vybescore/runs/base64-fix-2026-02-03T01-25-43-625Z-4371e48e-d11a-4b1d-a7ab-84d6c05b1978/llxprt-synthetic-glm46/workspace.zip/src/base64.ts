import { TextEncoder, TextDecoder } from 'util';

const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const BASE64_PADDING = '=';

function isValidBase64Char(char: string): boolean {
  return BASE64_ALPHABET.includes(char) || char === BASE64_PADDING;
}

function validateBase64Input(input: string): void {
  if (input.length === 0) {
    throw new Error('Empty input is not valid Base64');
  }

  for (const char of input) {
    if (!isValidBase64Char(char)) {
      throw new Error(`Invalid Base64 character: ${char}`);
    }
  }

  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Too many padding characters in Base64 input');
  }

  const nonPaddingIndex = input.indexOf('=');
  if (nonPaddingIndex !== -1) {
    validatePaddingPosition(input, nonPaddingIndex);
  }
}

function validatePaddingPosition(input: string, nonPaddingIndex: number): void {
  let i = nonPaddingIndex;
  while (i < input.length) {
    if (input[i] !== '=') {
      throw new Error('Padding characters must be at the end of Base64 input');
    }
    i++;
  }
}

export function encode(input: string): string {
  try {
    const encoder = new TextEncoder();
    const uint8Array = encoder.encode(input);
    
    let binary = '';
    const chars = [];
    for (const char of uint8Array) {
      chars.push(String.fromCharCode(char));
    }
    binary = chars.join('');
    
    return Buffer.from(binary, 'binary').toString('base64');
  } catch (error) {
    throw new Error('Failed to encode input to Base64');
  }
}

export function decode(input: string): string {
  validateBase64Input(input);

  try {
    const binary = Buffer.from(input, 'base64').toString('binary');
    const uint8Array = new Uint8Array(binary.length);
    
    for (let i = 0; i < binary.length; i++) {
      uint8Array[i] = binary.charCodeAt(i);
    }
    
    const decoder = new TextDecoder();
    return decoder.decode(uint8Array);
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
