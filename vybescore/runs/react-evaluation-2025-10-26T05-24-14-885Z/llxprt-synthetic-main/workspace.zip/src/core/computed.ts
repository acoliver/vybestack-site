/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Store all observers that depend on this computed value
  const observers = new Set<Observer<T>>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      return updateFn(prevValue)
    },
  }
  
  // Track computation and dependencies
  let computing = false
  
  const compute = () => {
    if (computing) return observer.value
    computing = true
    
    try {
      const currentValue = observer.value
      // Set this observer as active to track dependencies
      setActiveObserver(observer)
      
      // Execute the computation
      observer.value = updateFn(currentValue)
    } finally {
      computing = false
      // Restore the previous active observer
      setActiveObserver(undefined)
    }
  }
  
  // Initial computation
  compute()
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register the active observer as a dependency of this computed value
      observers.add(activeObserver as Observer<T>)
    }
    
    return observer.value as T
  }
  
  // Update observer's update function to recompute and notify dependencies
  observer.updateFn = (_prevValue?: T): T => {
    // Recompute
    compute()
    
    // Notify dependent observers
    observers.forEach(dep => {
      updateObserver(dep)
    })
    
    return observer.value as T
  }
  
  return getter
}