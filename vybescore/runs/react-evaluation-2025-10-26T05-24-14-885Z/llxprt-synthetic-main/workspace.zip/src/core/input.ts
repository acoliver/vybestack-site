/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Store all observers that depend on this input
  const observers = new Set<Observer<T>>()
  
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : equal ? 
      (a: T, b: T) => a === b : undefined,
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register the observer as a dependency of this input
      subject.observer = observer
      observers.add(observer as Observer<T>)
    }
    return subject.value
  }

  const setter: SetterFn<T> = (nextValue) => {
    const shouldUpdate = subject.equalFn ? 
      !subject.equalFn(subject.value, nextValue) : 
      subject.value !== nextValue
    
    if (shouldUpdate) {
      subject.value = nextValue
      
      // Update all dependent observers
      observers.forEach(observer => {
        updateObserver(observer)
      })
    }
    return subject.value
  }

  return [getter, setter]
}