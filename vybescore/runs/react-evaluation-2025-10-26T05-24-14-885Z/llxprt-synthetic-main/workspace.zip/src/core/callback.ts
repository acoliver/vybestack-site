/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>, 
  value?: T
): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: (prevValue?: T) => {
      // Execute the side-effect function
      return updateFn(prevValue)
    },
  }
  
  // Track computation and dependencies
  let computing = false
  
  // Helper to track dependencies
  const trackDependencies = () => {
    if (computing) return
    
    computing = true
    try {
      // Set this observer as active to track dependencies
      setActiveObserver(observer)
      
      // Execute the callback to establish dependencies
      observer.value = updateFn(observer.value)
    } finally {
      computing = false
      // Restore the previous active observer
      setActiveObserver(undefined)
    }
  }
  
  // Call this once to establish dependencies (if any)
  trackDependencies()
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  // Override updateFn to execute the callback and track dependencies
  observer.updateFn = (prevValue?: T): T => {
    if (disposed) return prevValue as T
    
    // Execute the callback to handle side effects
    trackDependencies()
    
    return observer.value as T
  }
  
  return unsubscribe
}