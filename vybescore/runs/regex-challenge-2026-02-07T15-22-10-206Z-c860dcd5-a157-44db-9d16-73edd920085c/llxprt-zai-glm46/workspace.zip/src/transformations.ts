/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences if input omitted it.
 * Collapses extra spaces sensibly while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Normalize multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Single-dot abbreviations
  const singleDotAbbrs = ['mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'gen', 'rep', 'sen', 'st',
    'dept', 'univ', 'assn', 'ave', 'blvd', 'mt', 'ft', 'rd', 'no', 'vol', 'ed', 'est',
    'min', 'max', 'approx', 'esp', 'capt', 'lt', 'col', 'sgt', 'adm', 'rev', 'hon', 'pres', 'gov'];
  
  // Multi-dot abbreviations (regex patterns with escaped dots)
  const multiDotPatterns = [/\be\.g\./gi, /\bi\.e\./gi, /\betc\./gi, /\bvs\./gi];
  
  // Titles to capitalize
  const titles = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof'];
  
  // First, protect multi-dot abbreviations by replacing with placeholders
  const stored: {[key: string]: string} = {};
  let placeholderIdx = 0;
  for (const regex of multiDotPatterns) {
    result = result.replace(regex, (match) => {
      const placeholder = `__ABBR${placeholderIdx}__`;
      stored[placeholder] = match.toLowerCase();
      placeholderIdx++;
      return placeholder;
    });
  }
  
  // Process character by character to find sentence endings
  const chars = result.split('');
  for (let i = 0; i < chars.length; i++) {
    const char = chars[i];
    
    // Check if this is a sentence-ending punctuation
    if (char === '.' || char === '!' || char === '?') {
      // Look backward to see if it's an abbreviation
      let wordStart = i - 1;
      while (wordStart >= 0 && /[a-zA-Z_]/.test(chars[wordStart])) {
        wordStart--;
      }
      wordStart++;
      
      const word = chars.slice(wordStart, i).join('').toLowerCase();
      
      // Check if it's a placeholder or single-dot abbreviation
      if (!word.includes('__abbr') && !singleDotAbbrs.includes(word)) {
        // Not an abbreviation, find the next alphabetic character and capitalize it
        let j = i + 1;
        while (j < chars.length && (chars[j] === ' ' || chars[j] === '_')) j++;
        
        if (j < chars.length && /[a-z]/.test(chars[j])) {
          chars[j] = chars[j].toUpperCase();
        }
      }
    }
  }
  
  result = chars.join('');
  
  // Capitalize titles
  for (const t of titles) {
    result = result.replace(new RegExp(`\\b${t}\\.`, 'gi'), t + '.');
  }
  
  // Capitalize first letter (before restoring abbreviations)
  result = result.replace(/^[^a-zA-Z]*([a-z])/, (_, letter) => letter.toUpperCase());
  
  // Restore multi-dot abbreviations
  for (const [placeholder, abbr] of Object.entries(stored)) {
    result = result.replace(new RegExp(placeholder, 'g'), abbr);
  }
  
  return result;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: protocol://domain/path...
  // Domains can have subdomains, paths can have various characters including query strings
  // Stop at whitespace or certain delimiters
  // Include common URL characters: letters, digits, and many symbols used in URLs
  const urlPattern = /(https?:\/\/[^\s<>"'`()[\]{},;]+)/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  // But keep query strings, fragments, and path components
  return matches.map(url => {
    // Remove trailing sentence punctuation (.,;!?) but not if it's part of the URL
    // Query strings contain ? and &, so we need to be careful
    // Also remove trailing closing brackets/parentheses if not matched
    return url.replace(/[,.;!?)\]]+$/, '');
  });
}

/**
 * Forces all http:// URLs to https://, leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When path begins with /docs/, rewrite host to docs.example.com
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  // Include ? & = for query strings in the path pattern
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s<>"'()[\]{},;!]*)/g;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Only rewrite to docs.example.com if:
    // 1. Path starts with /docs/
    // 2. AND does NOT contain cgi-bin
    // 3. AND does NOT contain legacy extensions (.jsp, .php, etc.)
    // 4. AND does NOT contain query strings (?, &, =)
    
    if (path.startsWith('/docs/')) {
      // Check for skip conditions
      const hasCgiBin = /\/cgi-bin/i.test(path);
      const hasLegacyExt = /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
      const hasQueryString = /[?&=]/.test(path);
      
      if (hasCgiBin || hasLegacyExt || hasQueryString) {
        // Skip host rewrite, just upgrade protocol
        return newProtocol + host + path;
      }
      
      // Safe to rewrite host
      return newProtocol + 'docs.example.com' + path;
    }
    
    // Not a /docs/ path, just upgrade protocol
    return newProtocol + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Allow 29 for February (leap year check is complex)
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return yearStr;
}
