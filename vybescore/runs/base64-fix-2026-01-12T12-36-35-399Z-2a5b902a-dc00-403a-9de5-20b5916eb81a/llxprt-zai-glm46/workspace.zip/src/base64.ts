/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (trimmed.length === 0) {
    return '';
  }

  // Validate that the input contains only valid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for valid padding (only 0, 1, or 2 = characters at the end)
  const paddingMatch = trimmed.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }

  // Check for = characters not at the end
  const equalsIndex = trimmed.indexOf('=');
  if (equalsIndex !== -1) {
    // All = chars must be at the end
    const suffix = trimmed.substring(equalsIndex);
    if (!/^={1,2}$/.test(suffix)) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // If the resulting buffer is empty but we had meaningful input, it's invalid
    // (e.g., "AAA=" or just invalid data that produces empty buffer)
    const meaningfulLength = trimmed.replace(/=+$/, '').length;
    if (buffer.length === 0 && meaningfulLength > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
