/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, startTracking, finishTracking } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let isExecuting = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // Prevent recursive calls
      if (isExecuting) return prevValue as T
      
      isExecuting = true
      try {
        const newValue = updateFn(prevValue)
        observer.value = newValue
        return newValue
      } finally {
        isExecuting = false
      }
    },
  }
  
  // Start tracking to establish dependencies
  startTracking()
  
  // Register observer to track dependencies by executing it once
  // This will establish the dependency relationships
  updateObserver(observer)
  
  // Finish tracking and move dependencies to global map
  finishTracking()
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // Set updateFn to a no-op to prevent further execution
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
