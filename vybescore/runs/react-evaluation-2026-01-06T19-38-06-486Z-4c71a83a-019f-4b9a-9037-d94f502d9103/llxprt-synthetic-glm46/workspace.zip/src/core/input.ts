/**
 * Input closure implementation for reactive primitives.
 */

import {
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  InputPair,
  Subject
} from '../types/reactive.js'

import { 
  track,
  trigger,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process the equal parameter to get an equality function
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? (a: T, b: T) => a === b :
    equal === false ? undefined :
    typeof equal === 'function' ? equal as EqualFn<T> :
    undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Track this dependency relationship using WeakMap to prevent leaks
      track(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has actually changed using equality function if provided
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Trigger notification to update all observers that depend on this subject
    trigger(s)
    
    return s.value
  }

  return [read, write]
}
