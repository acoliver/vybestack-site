/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  startTracking,
  finishTracking,
  registerComputed,
  getComputedObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Cache the computed value to avoid re-computation when not needed
  let cachedValue: T | undefined
  let needsRecompute = true
  
  // Using direct reference to avoid TypeScript issues with any
  const getterInstanceMarker = Symbol('computed-getter')
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    observers: new Set(),
    updateFn: (prevValue?: T) => {
      startTracking()
      try {
        const newResult = updateFn(prevValue)
        cachedValue = newResult
        o.value = newResult
        needsRecompute = false
        return newResult
      } finally {
        finishTracking()
      }
    },
  }
  
  // Compute initial value
  updateObserver(o)
  
  // Store reference to getter for dependency tracking
  // Return a getter function that properly tracks dependencies
  const getterInstance: GetterFn<T> = () => {
    // Track this computed as a dependency if in a reactive context
    const observer = getActiveObserver()
    if (observer) {
      // Add the observer to our observer set
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(observer)
    }
    
    // Re-compute if needed
    if (needsRecompute) {
      updateObserver(o)
    }
    
    // Ensure we have a cached value
    if (cachedValue === undefined && o.value !== undefined) {
      cachedValue = o.value
    }
    
    return cachedValue as T
  }
  
  // Store state on the getter instance for invalidation
  const getterState = {
    needsRecompute,
    cachedValue,
    observer: o
  }
  
  // Store observer reference on getter for tracking
  ;(getterInstance as unknown as Record<symbol, unknown>)[getterInstanceMarker] = getterState
  registerComputed(getterInstance, o)
  
  // When one of our dependencies changes, we need to invalidate and 
  // notify all our observers to recompute
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Execute the original logic
    const result = originalUpdateFn(prevValue)
    
    // Invalidate cache
    getterState.needsRecompute = true
    
    // Notify all our observers to recompute
    if (o.observers) {
      // Create a copy to avoid issues with observers being removed during iteration
      const observersToNotify = Array.from(o.observers)
      for (const obs of observersToNotify) {
        // Check if this observer is a computed value and invalidate it
        const computedObserver = getComputedObserver(obs as (...args: unknown[]) => unknown)
        if (computedObserver) {
          // Get the dependent computed's getter state
          const dependentGetterState = (obs as unknown as Record<symbol, unknown>)[getterInstanceMarker]
          if (dependentGetterState && typeof dependentGetterState === 'object') {
            // Mark as needing recompute
            (dependentGetterState as { needsRecompute: boolean }).needsRecompute = true
          }
        }
        
        // Trigger the observer to update
        updateObserver(obs as Observer<unknown>)
      }
    }
    
    return result
  }
  
  // Override the getter to access the latest state
  const originalGetter = getterInstance
  
  // Store the getter state again since we replaced the getter
  ;(originalGetter as unknown as Record<symbol, unknown>)[getterInstanceMarker] = getterState
  registerComputed(originalGetter, o)
  
  return originalGetter
}
