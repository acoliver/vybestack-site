/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observers?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>  // Track multiple observers
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global reactive registry with WeakMap to prevent memory leaks
const targetsToObservers = new WeakMap<object, Set<ObserverR>>()

// Dependency tracking similar to Vue's implementation
const trackedTargets: Array<{ target: object, observers: Set<ObserverR> }> = []

// Define a function type for computed getters
type ComputedGetter = (...args: unknown[]) => unknown

// Registry to store computed getter mappings for dependency tracking
const computedToObserver = new WeakMap<ComputedGetter, ObserverR>()
const computedRegistry = new Set<ComputedGetter>()

export function registerComputed(getterFn: ComputedGetter, observer: ObserverR): void {
  computedToObserver.set(getterFn, observer)
  computedRegistry.add(getterFn)
}

export function getComputedObserver(getterFn: ComputedGetter): ObserverR | undefined {
  return computedToObserver.get(getterFn)
}

export function startTracking(): void {
  // Clear any previous tracked targets
  trackedTargets.length = 0
}

export function finishTracking(): void {
  if (trackedTargets.length === 0) return
  
  // For each tracked target, copy observed dependencies to the global map
  for (const { target, observers } of trackedTargets) {
    let globalObservers = targetsToObservers.get(target)
    if (!globalObservers) {
      targetsToObservers.set(target, (globalObservers = new Set()))
    }
    
    // Add each new observer to the global map
    for (const observer of observers) {
      globalObservers.add(observer)
    }
  }
  
  // Clear the tracking array
  trackedTargets.length = 0
}

export function track(target: object, observer: ObserverR): void {
  // Check if this is a computed function and get its observer
  if (computedRegistry.has(target as ComputedGetter)) {
    const computedObserver = computedToObserver.get(target as ComputedGetter)
    if (computedObserver) {
      // Add the observer to the computed's observer set
      if (!computedObserver.observers) {
        computedObserver.observers = new Set()
      }
      computedObserver.observers.add(observer)
      return
    }
  }
  
  // If tracking is not active, we need to detect that
  const isTracking = trackedTargets.length > 0
  
  if (!isTracking) {
    // If tracking is not active, add directly to global map
    let observers = targetsToObservers.get(target)
    if (!observers) {
      targetsToObservers.set(target, (observers = new Set()))
    }
    observers.add(observer)
    return
  }
  
  // While tracking is active, use the temporary tracking array
  let existingItem = trackedTargets.find(item => item.target === target)
  if (!existingItem) {
    existingItem = { target, observers: new Set() }
    trackedTargets.push(existingItem)
  }
  existingItem.observers.add(observer)
}

export function trigger(target: object): void {
  const observers = targetsToObservers.get(target)
  if (observers) {
    // Create a copy to avoid issues with observers being removed during iteration
    const observersToTrigger = Array.from(observers)
    for (const observer of observersToTrigger) {
      // Check if observer still exists (might have been unsubscribed)
      if (observers.has(observer)) {
        updateObserver(observer as Observer<unknown>)
      }
    }
  }
}

// Export for use in computed.ts
export { computedToObserver }
