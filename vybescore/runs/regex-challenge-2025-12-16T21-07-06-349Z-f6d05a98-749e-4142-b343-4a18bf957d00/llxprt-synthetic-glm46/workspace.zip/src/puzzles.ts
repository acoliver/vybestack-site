/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with the prefix
  // We need to use dynamic regex with properly escaped prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefixPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  const allMatches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return allMatches.filter(match => 
    !exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex with lookbehind to find the token only when preceded by a digit
  // But not at the start of the string
  // We include the digit in the match to get the full token with the digit
  const tokenPattern = new RegExp(`(?<!^)(\\d)${escapedToken}`, 'g');
  
  const results: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    // Return the digit+token combination
    results.push(match[0]);
  }
  
  return results;
}

/**
 * TODO: Implement strong password validation.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
// Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':\\"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must not contain immediate repeated sequences (like abab)
  for (let i = 0; i < value.length - 3; i++) {
    // Check for patterns like abab (character repeats after 2 positions)
    if (value[i] === value[i+2] && value[i+1] === value[i+3]) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses while avoiding false positives with IPv4.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches:
  // - Full IPv6 addresses (8 groups of 4 hex chars)
  // - Compressed IPv6 with :: shorthand
  // - IPv6 with embedded IPv4 (e.g., ::ffff:192.0.2.128)
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9]))/;
  
  // First check if the text contains an IPv6 address
  if (!ipv6Pattern.test(value)) {
    return false;
  }
  
  // Now check if the text contains any IPv4 addresses
  // If it contains both, we need to make sure we're not matching IPv4
  const ipv4Pattern = /((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Extract all potential matches
  const ipv6Matches = value.match(ipv6Pattern);
  const ipv4Matches = value.match(ipv4Pattern);
  
  // If there are no IPv4 addresses, any IPv6 match is valid
  if (!ipv4Matches) {
    return true;
  }
  
  // Check if any of the IPv6 matches are actually IPv4 addresses
  // This would happen if our IPv6 regex is too broad
  for (const match of ipv6Matches || []) {
    // If the match doesn't contain any colons, it's likely IPv4
    if (!match.includes(':')) {
      continue;
    }
    
    // If it contains colons, it's a valid IPv6
    return true;
  }
  
  return false;
}