/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Split text into sentences, handling abbreviations where possible
  // This regex captures the sentence ending punctuation and following whitespace
  const sentences = text.split(/([.!?]+)(\s*)/);
  
  // Process every other element (the actual text content, not the punctuation or whitespace)
  for (let i = 0; i < sentences.length; i += 3) {
    const sentenceText = sentences[i];
    const sentenceEnd = sentences[i + 1]; // The punctuation (.!?)
    const sentenceSpace = sentences[i + 2] || ''; // The whitespace after punctuation
    
    // Capitalize the first character if it exists and is lowercase
    if (sentenceText && sentenceText.length > 0) {
      // Find the first character that's not whitespace
      const firstNonSpaceIdx = sentenceText.search(/\S/);
      if (firstNonSpaceIdx >= 0 && /[a-z]/.test(sentenceText[firstNonSpaceIdx])) {
        sentences[i] = sentenceText.substring(0, firstNonSpaceIdx) + 
                      sentenceText[firstNonSpaceIdx].toUpperCase() + 
                      sentenceText.substring(firstNonSpaceIdx + 1);
      }
    }
    
    // Ensure exactly one space between sentences
    if (sentenceEnd && sentenceSpace) {
      sentences[i + 2] = ' '; // Standardize to exactly one space
    }
  }
  
  // Rejoin the sentences
  return sentences.join('');
}

/**
 * TODO: Extract all URLs from the given text.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with different protocols
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[,.!?;:]$/, ''));
}

/**
 * TODO: Convert HTTP URLs to HTTPS.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite docs URLs to proper subdomain.
 */
export function rewriteDocsUrls(text: string): string {
// Pattern to match any http:// URL with optional subdomains
  // Use lazy matching to properly capture hostname and path
  return text.replace(
    /http:\/\/([^\s/:]+)(\/[^\s]*)?/g,
    (match, hostname, path) => {
      // Add path if it exists
      if (path) {
        // Check if we need to rewrite to docs subdomain
        if (
          path.startsWith('/docs/') && 
          !path.match(/(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/)
        ) {
          // Extract the domain part without subdomains
          const domainParts = hostname.split('.');
          if (domainParts.length >= 2) {
            const baseDomain = domainParts.slice(-2).join('.');
            return 'https://docs.' + baseDomain + path;
          } else {
            return 'https://docs.' + hostname + path;
          }
        }
        
        // Just upgrade the scheme if no docs path
        return 'https://' + hostname + path;
      }
      
      // Just upgrade the scheme if no path
      return 'https://' + hostname;
    }
  );
}

/**
 * TODO: Extract the year from a date string in mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}