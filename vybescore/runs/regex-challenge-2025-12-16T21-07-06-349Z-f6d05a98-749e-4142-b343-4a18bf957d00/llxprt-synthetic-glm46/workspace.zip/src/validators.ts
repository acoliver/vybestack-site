export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation that:
  // - Supports standard email format with optional +tag
  // - Allows common domain extensions like .co.uk
  // - Rejects double dots, trailing dots, underscore in domains
  
  // Basic regex pattern for email validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific requirements
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check domain part for underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Currently not using options, but keep parameter for future extensibility
  void options;
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Extract country code if present
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length === 10) {
    phoneNumber = digitsOnly;
  } else {
    return false; // Invalid length
  }
  
  // Validate area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1 (NPA rules)
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Check if the format matches common US phone patterns
  // Using regex for formats like (555) 555-1234, 555-555-1234, 5555551234
  const usPhoneRegex = /^(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation with country code support.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove any whitespace and hyphens for easier validation
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Pattern to match +54 341 1234567 (country code + area code + subscriber)
  const pattern1 = /^\+54[0-9][1-9]\d{1,10}$/;
  
  // Pattern to match +54 9 11 12345678 (country code + mobile indicator + area code + subscriber)
  const pattern2 = /^\+549[1-9]\d{1}\d{6,8}$/;
  
  // Pattern to match 011 12345678 (trunk prefix + area code + subscriber)
  const pattern3 = /^[01][1-9]\d{8}$/;
  
  // Test each pattern
  return pattern1.test(cleaned) || pattern2.test(cleaned) || pattern3.test(cleaned);
}

/**
 * TODO: Implement name validation with unicode support.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, and spaces
  // Also reject digits and special symbols like "X Æ A-12" style names
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\u0400-\u04FF\u0250-\u02AF\u1E00-\u1EFF\u02B0-\u02FF\u0370-\u03FF'\-\s]+$/;
  return nameRegex.test(value);
}

/**
 * Helper function to perform Luhn checksum validation for credit cards
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  const digits = cardNumber.split('').map(Number);
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement credit card validation with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Must be purely numeric and valid length
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card prefixes
  const visa = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercard = /^5[1-5][0-9]{14}$|^2[2-7][0-9]{14}$/;
  const amex = /^3[47][0-9]{13}$/;
  
  if (!visa.test(cleaned) && !mastercard.test(cleaned) && !amex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}