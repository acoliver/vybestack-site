import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Load sql.js WASM module
let db: Database | null = null;

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load schema
    const schemaSql = fs.readFileSync(
      path.join(__dirname, '..', 'db', 'schema.sql'),
      'utf8'
    );
    
    // Check if database already exists
    const initSqlJs = await import('sql.js');
    const SQL = await initSqlJs.default();
    
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      const arrayBuffer = new ArrayBuffer(dbBuffer.length);
      const view = new Uint8Array(arrayBuffer);
      for (let i = 0; i < dbBuffer.length; ++i) {
        view[i] = dbBuffer[i];
      }
      db = new SQL.Database(arrayBuffer);
    } else {
      db = new SQL.Database();
      db.run(schemaSql);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('views', path.join(__dirname, 'templates'));

// Set view engine
app.set('view engine', 'ejs');

// Define form data type
interface FormData {
  [key: string]: string | undefined;
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Form validation
function validateForm(formData: FormData): { errors: string[]; valid: boolean } {
  const errors: string[] = [];

  // Required fields
  const requiredFields = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  requiredFields.forEach((field) => {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').trim()} is required`);
    }
  });

  // Email validation
  if (formData.email && !/^\S+@\S+\.\S+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
  if (formData.phone && !/^[\d\s()\-+]+$/.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Postal code validation - accept alphanumeric strings
  if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return { errors, valid: errors.length === 0 };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const validation = validateForm(req.body);
  
  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: req.body,
    });
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.body.firstName,
        req.body.lastName,
        req.body.streetAddress,
        req.body.city,
        req.body.stateProvince,
        req.body.postalCode,
        req.body.country,
        req.body.email,
        req.body.phone,
      ]
    );
    
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(`/thank-you?firstName=${encodeURIComponent(req.body.firstName || '')}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

startServer();
