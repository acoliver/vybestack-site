// Type declarations for sql.js module
declare module 'sql.js' {
  export class Database {
    constructor(data?: ArrayBuffer);
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: typeof Database;
  }

  export default function(opts?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
}