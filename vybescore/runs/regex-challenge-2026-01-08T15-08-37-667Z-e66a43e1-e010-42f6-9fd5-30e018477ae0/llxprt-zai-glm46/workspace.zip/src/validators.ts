export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts: name+tag@example.co.uk, user@example.com, etc.
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Local part: alphanumeric, dots, hyphens, underscores, plus sign
  // Cannot start/end with dot, no consecutive dots
  // Domain: alphanumeric parts separated by dots, ending with 2-6 letter TLD
  // No underscores in domain
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots in local or domain part
  if (value.includes('..')) {
    return false;
  }
  
  // Check for underscore in domain
  const [local, domain] = value.split('@');
  if (domain.includes('_')) {
    return false;
  }
  
  // Local part cannot start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects: impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumberDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumberDigits = digitsOnly.slice(1);
  } else if (digitsOnly.length > 11) {
    // If we have allowExtensions option, handle extensions
    if (options?.allowExtensions) {
      // Try to extract the main 10 or 11 digit number
      if (digitsOnly.length >= 10 && digitsOnly.startsWith('1')) {
        phoneNumberDigits = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly.slice(1, 11);
      } else {
        phoneNumberDigits = digitsOnly.slice(0, 10);
      }
    } else {
      return false;
    }
  }
  
  // Must be exactly 10 digits now
  if (phoneNumberDigits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumberDigits.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check the overall format with common separators
  const phoneRegex = /^\+?1?[\s.-]?(\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?\d{3}[\s.-]?\d{4}(?:\s*(?:ext|ex|x)\s*\d+)?$/i;
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to get just digits
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with optional country code +54
  // Optional trunk prefix 0 before area code
  // Optional mobile indicator 9 between country code and area code
  // Area code: 2-4 digits, must start with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?[1-9]\d{0,2}(?:9)?[1-9]\d{5,7}$/;
  
  if (!argentinePhoneRegex.test(digitsOnly)) {
    return false;
  }
  
  // Extract components for detailed validation
  let remaining = digitsOnly;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  } else {
    // If no country code, must start with trunk prefix 0
    if (!remaining.startsWith('0')) {
      return false;
    }
    remaining = remaining.slice(1);
  }
  
  // Remove optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Now we should have area code + subscriber number
  // Area code is 2-4 digits starting with 1-9
  const areaCodeMatch = remaining.match(/^([1-9]\d{0,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const subscriber = areaCodeMatch[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects: digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and special symbols (except apostrophes and hyphens)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for forbidden symbols like Æ and digits (that would be caught by regex but let's be explicit)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Cannot be just symbols (apostrophes, hyphens, spaces)
  const stripped = value.replace(/['\-\s]/g, '');
  if (stripped.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * Accepts valid prefixes and lengths, then runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check length and prefix for each card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidLength = visaRegex.test(digitsOnly) || 
                        mastercardRegex.test(digitsOnly) || 
                        amexRegex.test(digitsOnly);
  
  if (!isValidLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
