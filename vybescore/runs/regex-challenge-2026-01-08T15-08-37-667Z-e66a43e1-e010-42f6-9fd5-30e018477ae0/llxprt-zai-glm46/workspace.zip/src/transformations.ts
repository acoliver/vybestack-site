/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence boundaries
  // Replace any sequence of whitespace after ., ?, or ! with a single space
  let normalized = text.replace(/([.!?])\s+/g, '$1 ');
  
  // Collapse multiple spaces into single space (but be careful with abbreviations)
  normalized = normalized.replace(/ +/g, ' ');
  
  // Trim leading/trailing whitespace
  normalized = normalized.trim();
  
  // Capitalize first character of the string
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence boundaries (. ! ?)
  const sentenceEndings = /[.!?]\s*([a-z])/g;
  normalized = normalized.replace(sentenceEndings, (match, letter) => match.replace(letter, letter.toUpperCase()));
  
  return normalized;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching common URL formats
  // Matches http://, https://, www. followed by domain
  // Excludes trailing punctuation
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:\.[a-zA-Z]{2,})(?:\/[^\s.,!?;:'"()[\]{}]*)?/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,!?;:'"()[\]{}]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  // Capture the path separately to check if it starts with /docs/
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // Check if path starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check for exceptions: cgi-bin, query strings, or legacy extensions
      const exceptions = [
        /cgi-bin/,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\/|$)/
      ];
      
      const shouldSkipHostRewrite = exceptions.some(exception => exception.test(path));
      
      if (shouldSkipHostRewrite) {
        // Only upgrade scheme, keep host as is
        return newScheme + host + path;
      }
      
      // Rewrite host to docs.example.com
      const newHost = 'docs.' + host;
      return newScheme + newHost + path;
    }
    
    // Not a /docs/ path, just upgrade scheme
    return newScheme + host + (path || '');
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  // Basic year validation (reasonable range)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}
