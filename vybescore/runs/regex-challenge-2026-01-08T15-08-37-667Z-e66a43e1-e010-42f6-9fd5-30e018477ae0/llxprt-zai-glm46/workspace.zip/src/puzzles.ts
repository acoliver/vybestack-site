/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix (word boundary at start)
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+=[{};':"\\|,.<>/?~]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns of length 2-4 that repeat immediately
  for (let patternLength = 2; patternLength <= 4; patternLength++) {
    for (let i = 0; i <= value.length - (patternLength * 2); i++) {
      const pattern = value.slice(i, i + patternLength);
      const nextChunk = value.slice(i + patternLength, i + (patternLength * 2));
      if (pattern === nextChunk) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern - matches addresses with colons and hex digits
  // Must have at least 2 colons and contain hex digits
  const hasColonsAndHex = /:[0-9a-fA-F]/.test(value);
  
  if (!hasColonsAndHex) {
    return false;
  }
  
  // Look for IPv6 patterns:
  // - Multiple groups of hex separated by colons
  // - :: shorthand notation
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}|::/;
  
  if (!ipv6Pattern.test(value)) {
    return false;
  }
  
  // Make sure it's not IPv4 (which has dots, not colons)
  // IPv6 can have embedded IPv4, but we want to detect the IPv6 format
  const hasIPv6Structure = value.includes(':') && 
                          (value.includes('::') || value.split(':').length >= 3);
  
  return hasIPv6Structure;
}
