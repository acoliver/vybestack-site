import express, { Request, Response } from 'express';
import path from 'path';
import databaseService from './database.js';
import { ValidationService, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'dist', 'templates'));

// Make ValidationService available to all templates
app.use((req: Request, res: Response, next: () => void) => {
  res.locals.ValidationService = ValidationService;
  next();
});

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: [],
    formData: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  try {
    // Validate form data
    const errors = ValidationService.validateForm(formData);

    if (errors.length > 0) {
      // Validation failed, redisplay form with errors
      res.status(400).render('index', {
        errors,
        formData,
        title: 'Friendly Contact Form - Please Fix Errors'
      });
      return;
    }

    // Validation passed, save to database
    databaseService.insertSubmission(formData)
      .then(() => {
        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      })
      .catch(error => {
        console.error('Database error:', error);
        res.status(500).render('index', {
          errors: [{ field: 'database', message: 'Failed to save submission. Please try again.' }],
          formData,
          title: 'Friendly Contact Form - Database Error'
        });
      });

  } catch (error) {
    console.error('Form submission error:', error);
    res.status(500).render('index', {
      errors: [{ field: 'server', message: 'Internal server error. Please try again.' }],
      formData,
      title: 'Friendly Contact Form - Server Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You (Seriously, Why Did You Do That?)'
  });
});

// Error handler
app.use((error: unknown, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await databaseService.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await databaseService.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await databaseService.initialize();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
