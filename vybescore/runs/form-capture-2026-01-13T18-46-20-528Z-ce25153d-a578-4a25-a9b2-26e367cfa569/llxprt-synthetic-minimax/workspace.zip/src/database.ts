import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define types for sql.js
interface SqlJsDatabase {
  exec(sql: string): Array<{ values: string[][] }>;
  prepare(sql: string): SqlJsStatement;
  close(): void;
  export(): Uint8Array;
}

interface SqlJsStatement {
  run(params?: unknown[]): SqlJsStatement;
  free(): void;
}

interface SqlJsModule {
  Database: new(buffer?: Uint8Array) => SqlJsDatabase;
  Statement: new() => SqlJsStatement;
}

class DatabaseService {
  private db: SqlJsDatabase | null = null;
  private sqlJs: SqlJsModule | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      const SqlJsModule = await initSqlJs({
        locateFile: (file: string) => {
          return join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        }
      });

      this.sqlJs = SqlJsModule;

      // Create data directory if it doesn't exist
      const dataDir = join(process.cwd(), 'data');
      if (!existsSync(dataDir)) {
        mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (existsSync(this.dbPath)) {
        const dbBuffer = readFileSync(this.dbPath);
        this.db = new SqlJsModule.Database(dbBuffer);
      } else {
        this.db = new SqlJsModule.Database();
      }

      // Initialize schema
      await this.initializeSchema();
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async initializeSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schema = readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schema);
    } catch (error) {
      console.error('Failed to initialize schema:', error);
      throw error;
    }
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    if (!this.sqlJs) {
      throw new Error('SQL.js not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();

    // Get the last insert row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = Number(result[0].values[0][0]);

    // Save changes to disk
    await this.save();

    return id;
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbBuffer = this.db.export();
    writeFileSync(this.dbPath, dbBuffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default new DatabaseService();