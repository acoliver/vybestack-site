declare module 'sql.js' {
  interface Database {
    exec(sql: string): Array<{ values: string[][] }>;
    prepare(sql: string): DatabaseStatement;
    close(): void;
    export(): Uint8Array;
  }

  interface DatabaseStatement {
    run(params?: unknown[]): DatabaseStatement;
    free(): void;
  }

  interface InitConfig {
    locateFile: (filename: string) => string;
  }

  interface SqlJsModule {
    Database: {
      new(buffer?: Uint8Array): Database;
    };
    Statement: {
      new(): DatabaseStatement;
    };
  }

  const initSqlJs: (config?: Partial<InitConfig>) => Promise<SqlJsModule>;
  export default initSqlJs;
}