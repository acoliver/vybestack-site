import express from 'express';
import path from 'path';
import fs from 'fs';
import './sqljs';

const app = express();
const port = process.env.PORT || 3000;

// Set up EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Serve static files from the public directory
app.use(express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

// Database type for sql.js Database
interface Database {
  exec: (sql: string) => void;
  prepare: (sql: string) => Statement;
  export: () => Uint8Array;
  close: () => void;
}

interface Statement {
  run: (...args: unknown[]) => void;
  free: () => void;
}

// Database will be initialized later
let db: Database | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    // Dynamic import for sql.js
    const { Database } = await import('sql.js');
    
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    let fileBuffer: Uint8Array | null = null;
    
    if (fs.existsSync(dbPath)) {
      const fileContent = fs.readFileSync(dbPath);
      fileBuffer = new Uint8Array(fileContent);
    }
    
    db = new Database(fileBuffer || undefined);
    
    // Create tables if they don't exist
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    if (db) {
      db.exec(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dataDir = path.join(process.cwd(), 'data');
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateForm(formData: Record<string, string>): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  
  // Required fields validation
  const requiredFields = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  }
  
  // Email validation
  const email = formData.email;
  if (email && ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation (international formats)
  const phone = formData.phone;
  if (phone && ! /^[+]?[(]?[0-9]{1,4}[)]?[-\s.]?[(]?[0-9]{1,4}[)]?[-\s.]?[0-9]{1,9}$/.test(phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation (alphanumeric)
  const postalCode = formData.postal_code;
  if (postalCode && ! /^[A-Za-z0-9\s]+$/.test(postalCode)) {
    errors.postal_code = 'Postal code can only contain letters, numbers, and spaces';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  try {
    res.render('form', { 
      errors: {},
      formData: {},
      showThankYou: false
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/submit', (req, res) => {
  try {
    const { isValid, errors } = validateForm(req.body);
    
    if (!isValid) {
      return res.status(400).render('form', {
        errors,
        formData: req.body,
        showThankYou: false
      });
    }
    
    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(
      req.body.first_name,
      req.body.last_name,
      req.body.street_address,
      req.body.city,
      req.body.state_province,
      req.body.postal_code,
      req.body.country,
      req.body.email,
      req.body.phone
    );
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req, res) => {
  try {
    res.render('thank-you', {});
  } catch (error) {
    console.error('Error rendering thank you page:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database connection closed');
  }
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle shutdown signals
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});