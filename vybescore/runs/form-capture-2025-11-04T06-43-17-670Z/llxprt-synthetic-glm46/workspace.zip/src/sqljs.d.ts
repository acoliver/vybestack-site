declare module 'sql.js' {
  export interface Database {
    exec: (sql: string) => void;
    prepare: (sql: string) => Statement;
    export: () => Uint8Array;
    close: () => void;
  }

  export interface Statement {
    run: (...args: unknown[]) => void;
    free: () => void;
  }

  export let Database: {
    new(data?: Uint8Array): Database;
  };
}