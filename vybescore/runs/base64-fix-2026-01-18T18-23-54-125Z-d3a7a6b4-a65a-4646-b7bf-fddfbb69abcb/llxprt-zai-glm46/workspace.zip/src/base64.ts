/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error
 * for invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 input - must contain only valid Base64 characters
  // Valid characters: A-Z, a-z, 0-9, +, /, and = (padding only at end)
  // Allow optional whitespace
  const trimmed = input.trim();
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;

  if (!validBase64Pattern.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check that = characters only appear at the end
  const firstEqualsIndex = trimmed.indexOf('=');
  if (firstEqualsIndex !== -1) {
    // Verify all characters after the first = are also =
    const suffix = trimmed.slice(firstEqualsIndex);
    if (!/^=+$/.test(suffix)) {
      throw new Error('Invalid Base64 input: padding characters in the middle');
    }
  }

  // Check for valid padding length (must be 0, 1, or 2 = characters at the end)
  const paddingMatch = trimmed.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }

  // Node.js Buffer.from handles base64 decoding automatically, including
  // inputs with or without padding. The validation above ensures the
  // characters are valid.
  try {
    const buffer = Buffer.from(trimmed, 'base64');

    // Detect invalid base64 by checking if the buffer contains
    // replacement characters (U+FFFD) which indicate decoding errors
    const decoded = buffer.toString('utf8');
    if (decoded.includes('\uFFFD')) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
