/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  enqueueBatchedUpdate,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed value
  const observers = new Set<Observer<unknown>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Function to get the current value
  const getter = (): T => {
    // If there's an active observer, register it as depending on this computed
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      observers.add(activeObserver as Observer<unknown>)
    }
    return o.value!
  }
  
  // Wrap the updateFn to notify observers after computation
  const originalUpdateFn = updateFn
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    // Recompute the value
    const newValue = originalUpdateFn(prevValue)
    
    // Create a copy of observers to notify
    const observersToNotify = Array.from(observers)
    
    // Queue notifications to be sent after all updates complete
    observersToNotify.forEach(observer => {
      enqueueBatchedUpdate(() => {
        updateObserver(observer)
      })
    })
    
    return newValue
  }
  
  o.updateFn = wrappedUpdateFn
  
  // Initial computation to establish dependencies and get initial value
  updateObserver(o)
  
  return getter
}
