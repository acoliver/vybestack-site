/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  runBatched
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Use a Set to track multiple observers
  const observers = new Set<Observer<unknown>>()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as dependent on this input
      observers.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    return runBatched(() => {
      s.value = nextValue
      
      // Immediately update all observers (synchronously)
      // They will queue their own updates which will flush after we return
      const observersToUpdate = Array.from(observers)
      observersToUpdate.forEach(observer => {
        updateObserver(observer)
      })
      
      return s.value
    })
  }

  return [read, write]
}
