import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, parseAndValidatePageParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = parseAndValidatePageParams(pageParam, limitParam);
    if (!validation.valid) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
