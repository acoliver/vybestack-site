import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export interface ValidationResult {
  valid: true;
  page: number;
  limit: number;
}

export interface ValidationError {
  valid: false;
  error: string;
}

export type PageParamValidation = ValidationResult | ValidationError;

export function parseAndValidatePageParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): PageParamValidation {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : DEFAULT_LIMIT;

  // Validate page parameter
  if (pageParam !== undefined) {
    if (isNaN(page) || !Number.isInteger(page)) {
      return { valid: false, error: 'Invalid page: must be a positive integer' };
    }
    if (page < 1) {
      return { valid: false, error: 'Invalid page: must be >= 1' };
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    if (isNaN(limit) || !Number.isInteger(limit)) {
      return { valid: false, error: 'Invalid limit: must be a positive integer' };
    }
    if (limit < 1) {
      return { valid: false, error: 'Invalid limit: must be >= 1' };
    }
    if (limit > MAX_LIMIT) {
      return { valid: false, error: `Invalid limit: must be <= ${MAX_LIMIT}` };
    }
  }

  return { valid: true, page, limit };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page: number; limit: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = Math.floor(options.page);
  const limit = Math.floor(options.limit);

  // Fixed: offset should be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
