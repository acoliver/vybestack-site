import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let server: import('http').Server;
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { app: expressApp, initializeDatabase } = await import('../../src/server.js');
  app = expressApp;
  await initializeDatabase();

  server = app.listen(0); // Use random available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const load = cheerio.load(response.text);

    expect(load('input[name="firstName"]').length).toBe(1);
    expect(load('input[name="lastName"]').length).toBe(1);
    expect(load('input[name="streetAddress"]').length).toBe(1);
    expect(load('input[name="city"]').length).toBe(1);
    expect(load('input[name="stateProvince"]').length).toBe(1);
    expect(load('input[name="postalCode"]').length).toBe(1);
    expect(load('input[name="country"]').length).toBe(1);
    expect(load('input[name="email"]').length).toBe(1);
    expect(load('input[name="phone"]').length).toBe(1);

    expect(load('label[for="firstName"]').length).toBe(1);
    expect(load('label[for="email"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app).post('/submit').send({
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    expect(fs.existsSync(dbPath)).toBe(true);

    const { initializeDatabase } = await import('../../src/server.js');
    await initializeDatabase();
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email',
      phone: '+54 9 11 1234-5678',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Email must be valid');
  });

  it('shows validation errors for empty required fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email is required');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('stranger on the internet');
  });
});
