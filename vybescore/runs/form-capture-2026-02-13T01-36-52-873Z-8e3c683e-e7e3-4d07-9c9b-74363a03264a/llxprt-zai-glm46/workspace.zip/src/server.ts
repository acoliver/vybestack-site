import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || 3535;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

app.use('/public', express.static(path.resolve('public')));

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

function validateForm(values: FormValues): string[] {
  const errors: string[] = [];

  if (!values.firstName || values.firstName.trim() === '') {
    errors.push('First name is required.');
  }
  if (!values.lastName || values.lastName.trim() === '') {
    errors.push('Last name is required.');
  }
  if (!values.streetAddress || values.streetAddress.trim() === '') {
    errors.push('Street address is required.');
  }
  if (!values.city || values.city.trim() === '') {
    errors.push('City is required.');
  }
  if (!values.stateProvince || values.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required.');
  }
  if (!values.postalCode || values.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required.');
  }
  if (!values.country || values.country.trim() === '') {
    errors.push('Country is required.');
  }
  if (!values.email || values.email.trim() === '') {
    errors.push('Email is required.');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(values.email.trim())) {
      errors.push('Email must be valid.');
    }
  }
  if (!values.phone || values.phone.trim() === '') {
    errors.push('Phone number is required.');
  } else {
    const phoneRegex = /^@?[\d\s\-()+]+$/;
    if (!phoneRegex.test(values.phone.trim())) {
      errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and a leading @.');
    }
  }

  return errors;
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(values);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', { errors, values });
    return;
  }

  if (db) {
    db.run(
      `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        values.firstName?.trim() || '',
        values.lastName?.trim() || '',
        values.streetAddress?.trim() || '',
        values.city?.trim() || '',
        values.stateProvince?.trim() || '',
        values.postalCode?.trim() || '',
        values.country?.trim() || '',
        values.email?.trim() || '',
        values.phone?.trim() || '',
      ]
    );
    saveDatabase();
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = 'Friend';
  res.render('thank-you', { firstName });
});

async function startServer(): Promise<void> {
  await initializeDatabase();

  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  function gracefulShutdown(): void {
    console.log('Shutting down gracefully...');
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server closed.');
      process.exit(0);
    });
  }
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export { app, initializeDatabase };
