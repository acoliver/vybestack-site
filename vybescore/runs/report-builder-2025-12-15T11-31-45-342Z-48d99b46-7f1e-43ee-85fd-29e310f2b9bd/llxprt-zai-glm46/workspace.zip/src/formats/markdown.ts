import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

/**
 * Format amount as currency with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total from report entries
 */
function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report data as Markdown format
 */
export const renderMarkdown: ReportRenderer = (data: ReportData, options: ReportOptions): string => {
  const lines: string[] = [];
  
  // Add title as h1
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries section
  lines.push('## Entries');
  
  // Add each entry as a bullet list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};