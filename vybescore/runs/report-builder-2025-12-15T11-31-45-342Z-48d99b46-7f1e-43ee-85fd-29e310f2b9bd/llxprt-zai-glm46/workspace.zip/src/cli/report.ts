#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, ReportFormat, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments
 */
function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2); // Skip node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as ReportFormat;
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: data must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: title is required and must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: summary is required and must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: entries is required and must be an array');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${index} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${index} must have a string label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${index} must have a number amount`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

/**
 * Main CLI function
 */
function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Cannot read file "${args.inputFile}"`);
      process.exit(1);
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${args.inputFile}"`);
      process.exit(1);
    }
    
    // Validate and structure data
    const reportData: ReportData = validateReportData(jsonData);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals
    };
    
    // Render report based on format
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        console.error(`Error: Unsupported format: ${args.format}`);
        process.exit(1);
    }
    
    // Write output
    if (args.outputPath) {
      writeFile(args.outputPath, output, 'utf-8')
        .then(() => {
          console.log(`Report written to ${args.outputPath}`);
        })
        .catch(() => {
          console.error(`Error: Cannot write to file "${args.outputPath}"`);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

// Run the CLI
main();
