/**
 * Interface for report entry data
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for complete report data
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Interface for report rendering options
 */
export interface ReportOptions {
  includeTotals: boolean;
}

/**
 * Type for supported report formats
 */
export type ReportFormat = 'markdown' | 'text';

/**
 * Interface for report renderer functions
 */
export interface ReportRenderer {
  (data: ReportData, options: ReportOptions): string;
}