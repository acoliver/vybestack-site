/**
 * Capitalize the first character of each sentence after .?! punctuation.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure there's a space after sentences ending with punctuation
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Capitalize the first character after sentence boundaries (start of string or after .?!)
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, $1, $2) => $1 + $2.toUpperCase());
  
  // Handle the very first character
  result = result.replace(/^(\s*)([a-z])/, (_, $1, $2) => $1 + $2.toUpperCase());
  
  return result;
}

/**
 * Extract URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regex to match URLs with common protocols, excluding trailing punctuation
  const urlRegex = /https?:\/\/[^\s]+?\.com[^\s]*(?=[\s,;.)\]}"']|$)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove any trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[,.!?;:'")\\]\\}]+$/, ''));
}

/**
 * Replace http:// with https:// while leaving existing https URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but not if it's already https://
  return text.replace(/http:\/\/\b/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade http to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/http:\/\/example\.com(\/.*)/g, (match, path) => {
    // Always upgrade to https first
    let result = 'https://example.com' + path;
    
    // Check if we should rewrite the host to docs.example.com
    // Skip if cgi-bin, query string, or legacy extensions are present
    if (/^\/docs\//.test(path) && 
        !/(cgi-bin|\?|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)$)/.test(path)) {
      result = 'https://docs.example.com' + path;
    }
    
    return result;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const [, month, day, year] = dateMatch;
  
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month and day ranges
  if (
    isNaN(monthNum) || monthNum < 1 || monthNum > 12 ||
    isNaN(dayNum) || dayNum < 1 || dayNum > 31
  ) {
    return 'N/A';
  }
  
  // Additional validation for specific months with fewer days
  if (monthNum === 2 && dayNum > 29) return 'N/A'; // February (simplified)
  if ([4, 6, 9, 11].includes(monthNum) && dayNum > 30) return 'N/A'; // 30-day months
  
  return year;
}
