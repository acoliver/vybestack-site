export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validated email addresses with typical rules.
 * Rejects double dots, trailing dots, underscore domains, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional checks
  if (value.includes('..')) return false;
  if (value.endsWith('.')) return false;
  if (value.startsWith('.')) return false;
  
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return true;
}

/**
 * Validate US phone numbers with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value) return false;

  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 10) return false;
  
  if (digitsOnly.length > 11) return false;
  
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Check for impossible area codes (leading 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate overall format
  const usPhoneRegex = /^(?:\+?1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})(?:\s*x\d*)?$/;
  return usPhoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Supports numbers like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Clean the input by removing spaces and hyphens
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Regex to validate Argentine phone numbers according to the specs
  // Optional +54 country code, optional 0 trunk prefix, optional 9 mobile indicator,
  // 2-4 digit area code (leading digit 1-9), 6-8 digit subscriber number
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // If country code is omitted, the number must begin with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols like 'X Æ A-12' style names.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;
  
  // Names with only unicode letters, spaces, hyphens, and apostrophes
  // Also allow accented characters (unicode letters)
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject if any digits are present
  if (/\d/.test(value)) return false;
  
  // Reject if it's just symbols/spaces (needs at least one letter)
  if (!/\p{L}/u.test(value)) return false;
  
  // Check for problematic sequences like "X Æ A-12"
  if (/[XÆ]/.test(value) && /[\d-]/.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers with proper prefixes and Luhn checksum.
 * Supports Visa (4), Mastercard (51-55, 2221-2720), and Amex (34, 37).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check length based on card type
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex1 = /^5[1-5]\d{14}$/; // 16 digits starting with 51-55
  const mastercardRegex2 = /^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/; // Starting with 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  const isValidFormat = visaRegex.test(cleanValue) || 
                      mastercardRegex1.test(cleanValue) || 
                      mastercardRegex2.test(cleanValue) || 
                      amexRegex.test(cleanValue);
  
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to validate credit card using Luhn algorithm.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Starting from the rightmost digit
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
