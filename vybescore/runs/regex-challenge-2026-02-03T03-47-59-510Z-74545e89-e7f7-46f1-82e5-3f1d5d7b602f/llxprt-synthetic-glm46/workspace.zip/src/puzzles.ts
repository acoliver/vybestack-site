/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to match words with the prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)`, 'g');
  
  const matches = [...text.matchAll(wordRegex)];
  const allMatches = matches.map(match => match[0]);
  
  // Filter out exceptions
  const filteredMatches = allMatches.filter(word => !exceptions.includes(word));
  
  // Return unique matches
  return [...new Set(filteredMatches)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to find the right match pattern.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to match token when preceded by a digit and not at the beginning of the string
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = [...text.matchAll(tokenRegex)];
  return matches.map(match => match[0]);
}

/**
 * Validate strong passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences like abab
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must have at least one uppercase, lowercase, digit, and symbol
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (i.e., abab pattern)
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) return false;
  
  // Check for repetition of any character in sequence (i.e., aaaa)
  const charRepetition = /(.)\1{3,}/;
  if (charRepetition.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex patterns, including shorthand with ::
  const ipv6FullRegex = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/; // Full XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX
  const ipv6CompressedRegex = /([0-9a-fA-F]{1,4}:){1,7}:/; // Ends with : (for ::N format)
  const ipv6CompressedStartRegex = /:([0-9a-fA-F]{1,4}:){1,7}/; // Starts with : (for N:: format)
  const ipv6CompressedMiddleRegex = /([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}/; // :: in middle
  const ipv6DoubleColonRegex = /::/;
  
  // Check for IPv4 mapped to IPv6 address (e.g., ::ffff:192.168.1.1)
  // This is IPv6 even though it contains IPv4-like patterns
  const ipv6MappedRegex = /::ffff:(?:\d{1,3}\.){3}\d{1,3}/i;
  
  // Check for IPv6 address patterns (must contain at least one colon)
  return (
    ipv6FullRegex.test(value) ||
    ipv6CompressedRegex.test(value) ||
    ipv6CompressedStartRegex.test(value) ||
    ipv6CompressedMiddleRegex.test(value) ||
    ipv6DoubleColonRegex.test(value) ||
    ipv6MappedRegex.test(value)
  );
}
