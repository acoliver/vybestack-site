import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, saveDatabase, FormData, insertSubmission } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: Awaited<ReturnType<typeof initDatabase>>;

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
};

const validateForm = (formData: FormData): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};

  if (!formData.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!formData.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!formData.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!formData.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!formData.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province is required';
  }

  if (!formData.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Invalid postal code format';
  }

  if (!formData.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Invalid email format';
  }

  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Invalid phone number format';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    submitted: false 
  });
});

app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || '',
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.render('form', {
      errors: validation.errors,
      formData,
      submitted: false,
    });
  }

  try {
    await insertSubmission(db, formData);
    await saveDatabase(db);
    
    // Redirect to thank-you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.render('form', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      formData,
      submitted: false,
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  try {
    if (db?.db) {
      await saveDatabase(db);
      db.db.close();
      console.log('Database closed');
    }
  } catch (error) {
    console.error('Error during shutdown:', error);
  }
  process.exit(0);
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  try {
    // Initialize database
    db = await initDatabase();
    console.log('Database initialized');
    
    // Start server
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
