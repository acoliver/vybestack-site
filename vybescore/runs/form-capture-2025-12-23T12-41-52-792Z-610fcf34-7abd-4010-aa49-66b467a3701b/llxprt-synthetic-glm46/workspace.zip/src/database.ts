import fs from 'fs/promises';
import fsSync from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js module doesn't have TypeScript definitions
import initSqlJs from 'sql.js';

// TypeScript interfaces for sql.js module
interface DatabaseInterface {
  prepare(sql: string): StatementInterface;
  exec(sql: string): void;
  export(): Uint8Array;
  close(): void;
}

interface StatementInterface {
  run(params?: unknown[]): void;
  step(): boolean;
  free(): void;
  getAsObject(): Record<string, unknown>;
}



export interface DatabaseWrapper {
  db: DatabaseInterface;
  filePath: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Read schema SQL file
async function readSchemaSQL(): Promise<string> {
  const schemaPath = join(__dirname, '../db/schema.sql');
  const schema = await fs.readFile(schemaPath, 'utf-8');
  return schema;
}

// Initialize database
export async function initDatabase(): Promise<DatabaseWrapper> {
  const dbPath = join(__dirname, '../data/submissions.sqlite');
  const SQL = await initSqlJs();
  let db: DatabaseInterface;
  
  // Try to load existing database from file
  try {
    const databaseFile = fsSync.readFileSync(dbPath);
    db = new SQL.Database(new Uint8Array(databaseFile));
    console.log('Loaded existing database from:', dbPath);
  } catch (error) {
    // If file doesn't exist, create new database with schema
    db = new SQL.Database();
    console.log('Creating new database');
    
    // Load and execute schema
    const schema = await readSchemaSQL();
    db.exec(schema);
    console.log('Database schema initialized');
  }
  
  return {
    db,
    filePath: dbPath,
  };
}

// Save database to file
export async function saveDatabase(dbWrapper: DatabaseWrapper): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = dirname(dbWrapper.filePath);
    await fs.mkdir(dataDir, { recursive: true });
    
    // Export database
    const data = dbWrapper.db.export();
    
    // Save to file
    await fs.writeFile(dbWrapper.filePath, Buffer.from(data));
    console.log('Database saved to:', dbWrapper.filePath);
  } catch (error) {
    console.error('Error saving database:', error);
    throw error;
  }
}

// Insert form submission
export async function insertSubmission(dbWrapper: DatabaseWrapper, formData: FormData): Promise<void> {
  const stmt = dbWrapper.db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
  } finally {
    stmt.free();
  }
}

// Get all submissions (for potential debugging/admin use)
export function getAllSubmissions(dbWrapper: DatabaseWrapper): Record<string, unknown>[] {
  const stmt = dbWrapper.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
  const results: Record<string, unknown>[] = [];
  
  while (stmt.step()) {
    results.push(stmt.getAsObject() as Record<string, unknown>);
  }
  
  stmt.free();
  return results;
}