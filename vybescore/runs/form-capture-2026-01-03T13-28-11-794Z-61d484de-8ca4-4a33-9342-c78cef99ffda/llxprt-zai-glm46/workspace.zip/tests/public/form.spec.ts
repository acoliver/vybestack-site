import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import { readFileSync, unlinkSync, existsSync } from 'fs';
import { join } from 'path';
import app from '../../src/server.js';

const DB_PATH = join(process.cwd(), 'data', 'submissions.sqlite');

describe('Form Capture App', () => {
  beforeAll(() => {
    // Clean up database before tests
    if (existsSync(DB_PATH)) {
      unlinkSync(DB_PATH);
    }
  });

  afterAll(() => {
    // Clean up database after tests
    if (existsSync(DB_PATH)) {
      unlinkSync(DB_PATH);
    }
  });

  describe('GET /', () => {
    it('should render the form page', async () => {
      const response = await request(app).get('/');
      expect(response.status).toBe(200);
      expect(response.text).toContain('Friendly International Contact Form');
    });

    it('should include form inputs with proper attributes', async () => {
      const response = await request(app).get('/');
      expect(response.text).toContain('name="first_name"');
      expect(response.text).toContain('name="last_name"');
      expect(response.text).toContain('name="email"');
      expect(response.text).toContain('name="phone"');
      expect(response.text).toContain('name="postal_code"');
    });

    it('should link to external stylesheet', async () => {
      const response = await request(app).get('/');
      expect(response.text).toContain('/styles.css');
    });
  });

  describe('POST /submit - Validation', () => {
    it('should reject submission with empty required fields', async () => {
      const response = await request(app).post('/submit').send({});
      expect(response.status).toBe(400);
      expect(response.text).toContain('is required');
    });

    it('should reject invalid email', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'John',
          last_name: 'Doe',
          street_address: '123 Main St',
          city: 'London',
          state_province: 'England',
          postal_code: 'SW1A 1AA',
          country: 'UK',
          email: 'invalid-email',
          phone: '+44 20 7946 0958',
        });
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid email');
    });

    it('should reject invalid phone number', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'John',
          last_name: 'Doe',
          street_address: '123 Main St',
          city: 'London',
          state_province: 'England',
          postal_code: 'SW1A 1AA',
          country: 'UK',
          email: 'john@example.com',
          phone: 'abc123',
        });
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid phone');
    });

    it('should reject invalid postal code', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'John',
          last_name: 'Doe',
          street_address: '123 Main St',
          city: 'London',
          state_province: 'England',
          postal_code: 'A',
          country: 'UK',
          email: 'john@example.com',
          phone: '+44 20 7946 0958',
        });
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid postal');
    });

    it('should preserve user input on validation error', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'Jane',
          last_name: 'Smith',
          email: 'not-an-email',
        });
      expect(response.status).toBe(400);
      expect(response.text).toContain('value="Jane"');
      expect(response.text).toContain('value="Smith"');
    });
  });

  describe('POST /submit - Success', () => {
    beforeEach(() => {
      // Clear database before each test
      if (existsSync(DB_PATH)) {
        unlinkSync(DB_PATH);
      }
    });

    it('should accept valid UK submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'John',
          last_name: 'Smith',
          street_address: '221B Baker Street',
          city: 'London',
          state_province: 'England',
          postal_code: 'SW1A 1AA',
          country: 'United Kingdom',
          email: 'john.smith@example.co.uk',
          phone: '+44 20 7946 0958',
        });
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should accept valid Argentine submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'Maria',
          last_name: 'Garcia',
          street_address: 'Av. Corrientes 1234',
          city: 'Buenos Aires',
          state_province: 'Buenos Aires',
          postal_code: 'C1000',
          country: 'Argentina',
          email: 'maria.garcia@example.com.ar',
          phone: '+54 9 11 1234-5678',
        });
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should accept valid US submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'Jane',
          last_name: 'Doe',
          street_address: '123 Main Street',
          city: 'New York',
          state_province: 'NY',
          postal_code: '10001',
          country: 'USA',
          email: 'jane.doe@example.com',
          phone: '+1 (212) 555-1234',
        });
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should store submission in database', async () => {
      await request(app)
        .post('/submit')
        .send({
          first_name: 'Test',
          last_name: 'User',
          street_address: '123 Test St',
          city: 'Test City',
          state_province: 'Test State',
          postal_code: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone: '+1 234 567 8900',
        });

      // Give the database a moment to write
      await new Promise((resolve) => setTimeout(resolve, 100));

      // Verify database file exists and has content
      expect(existsSync(DB_PATH)).toBe(true);
      const dbContent = readFileSync(DB_PATH);
      expect(dbContent.length).toBeGreaterThan(0);
    });
  });

  describe('GET /thank-you', () => {
    it('should render thank you page', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.status).toBe(200);
      expect(response.text).toContain('Thank You');
    });

    it('should contain humorous spam warning', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.text).toMatch(/stranger on the internet/i);
      expect(response.text).toMatch(/spam|identity/i);
    });

    it('should link back to form', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.text).toContain('href="/"');
    });
  });

  describe('Public Assets', () => {
    it('should serve stylesheet', async () => {
      const response = await request(app).get('/styles.css');
      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toContain('text/css');
      expect(response.text.length).toBeGreaterThan(0);
    });
  });
});
