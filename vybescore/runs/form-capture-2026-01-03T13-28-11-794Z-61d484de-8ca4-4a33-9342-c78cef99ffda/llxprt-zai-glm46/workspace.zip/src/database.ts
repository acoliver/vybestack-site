import initSqlJs, { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { dirname, join } from 'path';

const DB_PATH = join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = join(process.cwd(), 'db', 'schema.sql');

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

let dbInstance: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  const SQL = await initSqlJs();

  // Ensure data directory exists
  if (!existsSync(dirname(DB_PATH))) {
    mkdirSync(dirname(DB_PATH), { recursive: true });
  }

  // Load or create database
  if (existsSync(DB_PATH)) {
    const buffer = readFileSync(DB_PATH);
    const db = new SQL.Database(buffer);
    dbInstance = db;
  } else {
    const db = new SQL.Database();
    const schema = readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    dbInstance = db;
  }

  if (!dbInstance) {
    throw new Error('Failed to initialize database');
  }

  return dbInstance;
}

export function saveDatabase(): void {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const data = dbInstance.export();
  const buffer = Buffer.from(data.buffer || data);
  writeFileSync(DB_PATH, buffer);
}

export function insertSubmission(submission: Submission): number {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const stmt = dbInstance.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone,
  ]);

  stmt.free();

  const result = dbInstance.exec('SELECT last_insert_rowid() as id');
  const lastId = result[0].values[0][0] as number;

  saveDatabase();

  return lastId;
}

export function getDatabase(): Database {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }
  return dbInstance;
}

export function closeDatabase(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}
