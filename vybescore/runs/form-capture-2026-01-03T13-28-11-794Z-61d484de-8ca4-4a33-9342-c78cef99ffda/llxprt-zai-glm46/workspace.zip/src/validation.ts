export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export function validateFormData(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      errors[field] = `${formatFieldName(field)} is required`;
    }
  }

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postal_code && !isValidPostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

function formatFieldName(field: string): string {
  return field
    .split('_')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

function isValidEmail(email: string): boolean {
  // Simple but effective email regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function isValidPhone(phone: string): boolean {
  // Accept international formats: digits, spaces, parentheses, dashes, leading +
  // Must have at least 5 digits total and can be formatted in various ways
  const trimmed = phone.trim();
  // Remove all non-digit characters except leading +
  const digitsOnly = trimmed.replace(/^\+/, '').replace(/\D/g, '');
  // Check basic format - allow very flexible patterns for international phone numbers
  // Accepts: +XX XX XX XXXX-XXXX, +1 (XXX) XXX-XXXX, +44 XX XXXX XXXX, etc.
  const phoneRegex = /^[+]?\d[\d\s\-()]*\d[\d\s\-()]*$/;
  // Must have between 5 and 15 digits (international standard)
  return phoneRegex.test(trimmed) && digitsOnly.length >= 5 && digitsOnly.length <= 15;
}

function isValidPostalCode(postal: string): boolean {
  // Accept alphanumeric strings with spaces (e.g., "SW1A 1AA", "C1000", "B1675", "12345")
  const postalRegex = /^[A-Za-z0-9][A-Za-z0-9\s-]*[A-Za-z0-9]$/;
  const trimmed = postal.trim();
  return trimmed.length >= 3 && trimmed.length <= 10 && postalRegex.test(trimmed);
}

export function sanitizeFormData(data: FormData): FormData {
  const sanitized: FormData = {};
  for (const [key, value] of Object.entries(data)) {
    if (typeof value === 'string') {
      (sanitized as Record<string, string>)[key] = value.trim();
    }
  }
  return sanitized;
}
