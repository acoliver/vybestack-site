import express, { Request, Response, NextFunction } from 'express';
import { join } from 'path';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateFormData, sanitizeFormData, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || '3535';

// Middleware
app.use(express.static(join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', join(process.cwd(), 'src', 'views'));

// Track if database is initialized
let dbReady = false;

// Initialize database on startup
initializeDatabase()
  .then(() => {
    dbReady = true;
    console.log('Database initialized successfully');
  })
  .catch((err) => {
    console.error('Failed to initialize database:', err);
    process.exit(1);
  });

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    formData: {},
    errors: undefined,
  });
});

app.post('/submit', (req: Request, res: Response) => {
  if (!dbReady) {
    return res.status(500).send('Database not ready. Please try again.');
  }

  const sanitizedData = sanitizeFormData(req.body);
  const validation = validateFormData(sanitizedData);

  if (!validation.isValid) {
    return res.status(400).render('index', {
      formData: sanitizedData,
      errors: validation.errors,
    });
  }

  try {
    insertSubmission(sanitizedData as Required<FormData>);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('index', {
      formData: sanitizedData,
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).render('index', {
    formData: {},
    errors: { general: 'An unexpected error occurred. Please try again.' },
  });
});

// Only start server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}` || import.meta.url === `file://${process.cwd()}/src/server.ts`) {
  // Start server
  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('Express server closed');
      closeDatabase();
      console.log('Database connection closed');
      process.exit(0);
    });

    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      closeDatabase();
      process.exit(1);
    }, 10000);
  };

  // Handle shutdown signals
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

export default app;
