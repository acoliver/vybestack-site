declare module 'sql.js' {
  export interface DatabaseExport {
    buffer: ArrayLike<number>;
    size(): number;
  }

  export interface Statement {
    bind(values: unknown[]): boolean;
    step(): boolean;
    get(params?: string[]): unknown[];
    run(values?: unknown[]): void;
    getColumnNames(): string[];
    free(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export default interface SqlJsStatic {
    Database: {
      new (data?: ArrayLike<number> | Buffer): Database;
    };
  }

  export interface Database {
    run(sql: string): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): DatabaseExport;
    close(): void;
  }

  export default function initSqlJs(config?: { locateFile?: (filename: string) => string }): Promise<SqlJsStatic>;
}
