#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { ReportData, RenderOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const cliArgs: Partial<CliArgs> = {
    dataFile: args[0],
    includeTotals: false
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const formatValue = args[i + 1];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      cliArgs.format = formatValue;
      i++; // Skip the next argument
    } else if (arg === '--output') {
      const outputPath = args[i + 1];
      if (!outputPath) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      cliArgs.outputPath = outputPath;
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      cliArgs.includeTotals = true;
    }
  }

  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return cliArgs as CliArgs;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "amount" field`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

function main(): void {
  try {
    const args = parseArguments();
    
    // Read and parse the JSON file
    const dataPath = resolve(args.dataFile);
    const fileContent = readFileSync(dataPath, 'utf-8');
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (parseError) {
      throw new Error(`Invalid JSON in file ${args.dataFile}: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
    }

    const reportData = validateReportData(jsonData);
    const renderOptions: RenderOptions = {
      includeTotals: args.includeTotals
    };

    // Select the appropriate formatter
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown.render(reportData, renderOptions);
        break;
      case 'text':
        output = renderText.render(reportData, renderOptions);
        break;
    }

    // Write output
    if (args.outputPath) {
      const outputPath = resolve(args.outputPath);
      try {
        writeFileSync(outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to ${args.outputPath}:`, error instanceof Error ? error.message : 'Unknown error');
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
