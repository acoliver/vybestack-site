/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof _equal === 'function' ? _equal : undefined
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Only do initial computation if value is provided
  if (value !== undefined) {
    o.value = value
  }

  const read: GetterFn<T> = () => {
    // Compute the value using the update function
    // If no current value exists, call updateFn without arguments to use defaults
    const newValue = o.value === undefined ? updateFn() : updateFn(o.value)
    
    // Check if value changed and update
    const shouldUpdate = o.value === undefined || !equalFn || !equalFn(o.value, newValue)
    if (shouldUpdate) {
      o.value = newValue
    }
    
    return o.value!
  }

  return read
}
