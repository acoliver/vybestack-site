const STANDARD_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using standard alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmedInput = input.trim();
  
  if (!trimmedInput) {
    throw new Error('Input cannot be empty');
  }
  
  // Check if input contains only valid Base64 characters
  if (!STANDARD_BASE64_REGEX.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  try {
    const buffer = Buffer.from(trimmedInput, 'base64');
    
    // If Buffer.from with 'base64' encoding doesn't throw but creates an empty buffer
    // when the input is clearly invalid, we should still consider it an error
    if (buffer.length === 0 && trimmedInput.length > 0) {
      throw new Error('Invalid Base64 input: no data could be decoded');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
