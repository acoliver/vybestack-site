import express, { Application, Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app: Application = express();
const port: number = parseInt(process.env.PORT || '3000', 10);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database path
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Database initialization
let db: Database;
initSqlJs().then((SQL) => {
  // Check if database file exists
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}).catch((error) => {
  console.error('Failed to initialize SQL.js:', error);
  process.exit(1);
});

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  // Fixed regex to avoid range out of order error by escaping the dash and parentheses properly
  // Moving the dash to the end of the character class to avoid it being interpreted as a range
  const phoneRegex = /^\\+?[\\d\\s\\(\\)-]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Supports alphanumeric postal codes with optional spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\\s\\-]+$/;
  return postalCodeRegex.test(postalCode);
};

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

app.post('/submit', (req: Request, res: Response) => {
  const data: FormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  // Validation
  const errors: string[] = [];
  if (!data.firstName) errors.push('First name is required');
  if (!data.lastName) errors.push('Last name is required');
  if (!data.streetAddress) errors.push('Street address is required');
  if (!data.city) errors.push('City is required');
  if (!data.stateProvince) errors.push('State/Province is required');
  if (!data.postalCode) errors.push('Postal code is required');
  if (!data.country) errors.push('Country is required');
  if (!data.email) errors.push('Email is required');
  else if (!validateEmail(data.email)) errors.push('Email is invalid');
  if (!data.phone) errors.push('Phone is required');
  else if (!validatePhone(data.phone)) errors.push('Phone number format is invalid');
  if (!validatePostalCode(data.postalCode)) errors.push('Postal code format is invalid');

  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: data });
  }

  // Insert data into database
  const stmt = db.prepare(
    'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone
  ]);
  stmt.free();

  // Save database back to file
  const dataBuffer = db.export();
  fs.writeFileSync(dbPath, dataBuffer);

  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(data.firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
const shutdown = () => {
  console.log('Closing HTTP server and database');
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
    db.close();
    console.log('Database closed');
  }
};

// Store server instance for shutdown
const server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

export default app;