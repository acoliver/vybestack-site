import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { Application } from 'express';
import http from 'http';

let server: http.Server;
let app: Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Ensure the database is cleaned up before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Dynamically import the app to start server
  app = (await import('../../src/server')).default;
  
  // Create a promise that resolves when server is listening
  server = await new Promise((resolve) => {
    const serverInstance = app.listen(0, () => resolve(serverInstance));
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up the database file if it exists
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(server).get('/');
    expect(res.status).toBe(200);
    
    const $ = cheerio.load(res.text);
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1 555 123 4567'
      });
    
    expect(res.status).toBe(302);
    expect(res.header.location).toBe('/thank-you?firstName=John');
  });
});