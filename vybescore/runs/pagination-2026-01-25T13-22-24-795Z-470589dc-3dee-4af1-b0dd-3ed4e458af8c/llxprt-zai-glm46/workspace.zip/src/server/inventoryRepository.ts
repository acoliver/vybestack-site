import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

interface InventoryPageParams {
  page?: number;
  limit?: number;
}

interface ValidationError {
  error: string;
}

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationParams(
  page?: number,
  limit?: number
): ValidationError | InventoryPageParams {
  if (page !== undefined) {
    if (isNaN(page) || !Number.isFinite(page)) {
      return { error: 'Invalid page parameter: must be a number' };
    }
    if (page <= 0) {
      return { error: 'Invalid page parameter: must be greater than 0' };
    }
    if (page !== Math.floor(page)) {
      return { error: 'Invalid page parameter: must be a whole number' };
    }
  }

  if (limit !== undefined) {
    if (isNaN(limit) || !Number.isFinite(limit)) {
      return { error: 'Invalid limit parameter: must be a number' };
    }
    if (limit <= 0) {
      return { error: 'Invalid limit parameter: must be greater than 0' };
    }
    if (limit !== Math.floor(limit)) {
      return { error: 'Invalid limit parameter: must be a whole number' };
    }
    if (limit > MAX_LIMIT) {
      return { error: `Invalid limit parameter: must not exceed ${MAX_LIMIT}` };
    }
  }

  return { page, limit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage | ValidationError {
  const validation = validatePaginationParams(options.page, options.limit);
  if ('error' in validation) {
    return validation;
  }

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = validation.page ?? 1;
  const limit = validation.limit ?? DEFAULT_LIMIT;

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = (page + 1) * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
