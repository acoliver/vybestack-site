/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  getActiveObserver,
  trackDependency,
  notifyDependents,
  BaseObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let currentValue = value

  const observer: BaseObserver = {
    value: currentValue,
    updateFn: (value?: unknown) => {
      const newValue = updateFn(value as T)
      currentValue = newValue
      observer.value = newValue
      // Notify dependents when the value changes
      if (newValue !== value) {
        notifyDependents(observer)
      }
      return newValue
    },
    dependents: new Set()
  }

  const getter: GetterFn<T> = () => {
    // Track this computation as the active observer for dependency tracking
    const active = getActiveObserver()
    if (active && active !== observer) {
      trackDependency(observer)
    }
    
    // Re-evaluate the computation
    const newValue = updateFn(currentValue)
    const oldValue = currentValue
    currentValue = newValue
    observer.value = newValue
    
    // If the value changed, notify dependents
    if (oldValue !== newValue) {
      notifyDependents(observer)
    }
    
    return newValue as T
  }

  return getter
}
