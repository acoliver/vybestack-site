/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn, getActiveObserver, setActiveObserver, trackDependency, BaseObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let observer: BaseObserver = {
    value,
    updateFn,
    dependents: new Set(),
    trigger: () => {
      // Re-execute the callback when dependencies change
      if (isActive) {
        executeCallback()
      }
    }
  }

  let isActive = true

  function executeCallback() {
    // Set this callback as the active observer for dependency tracking
    const previous = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      // Execute the callback which will access dependencies
      // and establish the dependency graph
      observer.updateFn?.(observer.value)
    } finally {
      // Restore the previous active observer
      setActiveObserver(previous)
    }
  }

  // Execute callback initially to establish dependencies
  executeCallback()

  // Return an unsubscribe function that disables the callback
  return () => {
    isActive = false
    observer.updateFn = () => observer.value as unknown
  }
}
