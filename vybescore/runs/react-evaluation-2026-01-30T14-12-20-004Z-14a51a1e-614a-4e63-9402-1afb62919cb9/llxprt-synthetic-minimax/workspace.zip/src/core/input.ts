/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getActiveObserver,
  trackDependency,
  BaseObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    dependents: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Track this read as a dependency for the active observer
    const active = getActiveObserver()
    if (active && active !== subject) {
      trackDependency(subject as BaseObserver)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = subject.value
    subject.value = nextValue
    
    // Notify all dependents that value has changed
    if (oldValue !== nextValue) {
      const dependents = Array.from(subject.dependents || [])
      for (const dependent of dependents) {
        if (dependent && 'updateFn' in dependent) {
          dependent.updateFn?.(nextValue)
        }
      }
    }
    return subject.value
  }

  return [read, write]
}
