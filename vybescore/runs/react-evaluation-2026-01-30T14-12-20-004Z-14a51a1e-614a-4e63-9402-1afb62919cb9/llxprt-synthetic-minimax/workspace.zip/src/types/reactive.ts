/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ReactiveNode<T = unknown> {
  value: T
  dependents: Set<ReactiveNode<unknown>>
  isComputing?: boolean
  lastValue?: T
}

export interface Observable<T = unknown> {
  value: T
  dependents: Set<Observable<unknown>>
  trigger?: () => void
}

export interface BaseObserver {
  value?: unknown
  updateFn?: (value?: unknown) => unknown
  dependents?: Set<BaseObserver>
  trigger?: () => void
}

export type ObserverR = {
  name?: string
  readonly?: boolean
  dependents?: Set<BaseObserver>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependents?: Set<BaseObserver>
  trigger?: () => void
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  dependents: Set<BaseObserver>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: BaseObserver | undefined

export function getActiveObserver(): BaseObserver | undefined {
  return activeObserver
}

export function setActiveObserver(observer?: BaseObserver) {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    return newValue
  } finally {
    activeObserver = previous
  }
}

export function trackDependency(source: BaseObserver) {
  const active = getActiveObserver()
  if (active && active !== source && 'dependents' in source) {
    if (!source.dependents) {
      source.dependents = new Set()
    }
    source.dependents.add(active)
  }
}

export function notifyDependents(source: BaseObserver) {
  if (!('dependents' in source) || !source.dependents) return
  
  const dependents = Array.from(source.dependents)
  for (const dependent of dependents) {
    if (dependent && 'updateFn' in dependent) {
      dependent.updateFn?.(source.value)
    }
  }
}
