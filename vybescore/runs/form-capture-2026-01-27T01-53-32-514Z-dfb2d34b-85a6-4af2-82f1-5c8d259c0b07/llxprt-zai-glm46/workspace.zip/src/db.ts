import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH = join(__dirname, '../data/submissions.sqlite');
const SCHEMA_PATH = join(__dirname, '../db/schema.sql');

let SQL: Awaited<ReturnType<typeof initSqlJs>> | null = null;
let databaseInstance:
  | InstanceType<
      typeof initSqlJs extends (...args: never[]) => Promise<{ Database: infer T }> ? T : never
    >
  | null = null;

// Ensure data directory exists
function ensureDataDir(): void {
  const dataDir = dirname(DB_PATH);
  if (!existsSync(dataDir)) {
    mkdirSync(dataDir, { recursive: true });
  }
}

// Initialize database
export async function initDb(): Promise<void> {
  SQL = await initSqlJs();

  ensureDataDir();

  // Load existing database or create new one
  let dbData: Uint8Array | null = null;
  if (existsSync(DB_PATH)) {
    const buffer = readFileSync(DB_PATH);
    dbData = new Uint8Array(buffer);
  }

  databaseInstance = new SQL.Database(dbData);

  // Create tables from schema
  const schema = readFileSync(SCHEMA_PATH, 'utf-8');
  databaseInstance.run(schema);
}

// Insert submission into database
export async function insertSubmission(data: Record<string, string>): Promise<void> {
  if (!databaseInstance) {
    throw new Error('Database not initialized');
  }

  const stmt = databaseInstance.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone,
  ]);

  stmt.free();

  // Save database to disk
  saveDb();
}

// Save database to disk
function saveDb(): void {
  if (!databaseInstance) {
    throw new Error('Database not initialized');
  }

  const data = databaseInstance.export();
  const buffer = Buffer.from(data);
  writeFileSync(DB_PATH, buffer);
}

// Close database
export async function closeDb(): Promise<void> {
  if (databaseInstance) {
    databaseInstance.close();
    databaseInstance = null;
  }
}
