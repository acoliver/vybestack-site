import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initDb, closeDb, insertSubmission } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Track initialization status
let dbInitialized = false;

// Initialize database on startup
async function ensureDbInitialized(): Promise<void> {
  if (!dbInitialized) {
    await initDb();
    dbInitialized = true;
  }
}

// Routes
app.get('/', async (_req, res, next) => {
  try {
    await ensureDbInitialized();
    res.render('index', { errors: {}, data: {} });
  } catch (error) {
    next(error);
  }
});

app.post('/submit', async (req, res, next) => {
  try {
    await ensureDbInitialized();
    const data = req.body;
    const errors = validateSubmission(data);

    if (Object.keys(errors).length > 0) {
      return res.status(400).render('index', { errors, data });
    }

    await insertSubmission(data);
    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', async (_req, res, next) => {
  try {
    await ensureDbInitialized();
    res.render('thank-you');
  } catch (error) {
    next(error);
  }
});

// Graceful shutdown
let server: ReturnType<typeof app.listen>;

export function start() {
  server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Handle SIGTERM for graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('SIGTERM received, closing server...');
    server.close(async () => {
      await closeDb();
      process.exit(0);
    });
  });

  // Also handle SIGINT for development
  process.on('SIGINT', async () => {
    console.log('SIGINT received, closing server...');
    server.close(async () => {
      await closeDb();
      process.exit(0);
    });
  });

  return server;
}

function validateSubmission(data: Record<string, string>): Record<string, string> {
  const errors: Record<string, string> = {};

  // Required fields validation
  const requiredFields = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value) {
      errors[field] = `${fieldToLabel(field)} is required`;
    }
  }

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !isValidPhone(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }

  // Postal code validation
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Postal code can contain letters, digits, and spaces';
  }

  return errors;
}

function fieldToLabel(field: string): string {
  const labels: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State/Province/Region',
    postalCode: 'Postal/Zip code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone number',
  };
  return labels[field] || field;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow leading +, then digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow letters, digits, and spaces (for UK, Argentina, etc.)
  const postalRegex = /^[\dA-Za-z\s]+$/;
  return postalRegex.test(postalCode);
}

// Start server if this is the main module
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  start();
}
