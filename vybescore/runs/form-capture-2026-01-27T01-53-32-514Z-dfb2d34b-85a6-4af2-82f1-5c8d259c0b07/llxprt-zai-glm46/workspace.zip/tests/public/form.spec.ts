import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerioModule from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';

const cheerio = (cheerioModule.default || cheerioModule) as typeof cheerioModule;
let app: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Import and start the server
  const serverModule = await import('../../dist/server.js');
  app = serverModule.app;
});

afterAll(async () => {
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);

    const $ = cheerio.load(response.text);

    // Check for all form fields
    expect($('form[action="/submit"][method="POST"]')).toHaveLength(1);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check for labels associated with inputs
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    expect($('label[for="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Follow redirect
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain('Thanks');
  });

  it('shows validation errors for invalid data', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      email: 'invalid-email',
      phone: 'invalid-phone-!@#',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    // Should show form again with errors
    expect($('form')).toHaveLength(1);
    expect($('.error-message').length).toBeGreaterThan(0);
  });

  it('accepts international phone and postal formats', async () => {
    const formData = {
      firstName: 'Maria',
      lastName: 'Garcia',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.garcia@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').send(formData);
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
