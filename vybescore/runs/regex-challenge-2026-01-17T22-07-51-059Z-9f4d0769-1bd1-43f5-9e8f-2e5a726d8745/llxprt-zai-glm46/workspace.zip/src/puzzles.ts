/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const pattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = pattern.exec(text)) !== null) {
    const word = match[1];
    
    // Check if word is in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookahead to find token preceded by a digit
  // Match the digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 1212)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (including shorthand ::)
  // Match valid IPv6 addresses with :: shorthand
  const ipv6Pattern = /(?:^|[\s[])(?:[0-9a-fA-F]{1,4}:){1,7}(?::[0-9a-fA-F]{1,4})?(?:$|[\s]])/;
  
  // Also match the full form with 8 groups
  const ipv6FullPattern = /(?:^|[\s[])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:$|[\s]])/;
  
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check for IPv6
  const hasIPv6 = ipv6Pattern.test(value) || ipv6FullPattern.test(value);
  
  // Check for IPv4
  const hasIPv4 = ipv4Pattern.test(value);
  
  // Only return true if we have IPv6 but not standalone IPv4
  if (hasIPv4 && !hasIPv6) {
    return false;
  }
  
  return hasIPv6;
}
