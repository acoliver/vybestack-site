export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+\-/=?^_`{|}~]+(?:\.[a-zA-Z0-9!#$%&'*+\-/=?^_`{|}~]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for underscores in domain
  if (/_/.test(value.split('@')[1] || '')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally with +1)
  const hasCountryCode = digitsOnly.startsWith('1');
  const phoneNumberDigits = hasCountryCode ? digitsOnly.slice(1) : digitsOnly;
  
  // Must have exactly 10 digits after optional +1
  if (phoneNumberDigits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumberDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumberDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex
  const phoneRegex = /^(?:\+1\s?)?(?:\(\s*(\d{3})\s*\)|(\d{3}))[\s-]?(\d{3})[\s-]?(\d{4})(?:\s*x\s*\d+)?$/i;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles
 * Format: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54, optional 0 trunk prefix, optional 9 for mobile, area code (2-4 digits starting 1-9), subscriber (6-8 digits)
  const argPhoneRegex = /^(?:\+54)?(?:0?)(9)?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(argPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, , areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }
  
  // When country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = cleaned.startsWith('0') || (cleaned.startsWith('+540'));
  
  if (!hasCountryCode && !hasTrunkPrefix && !cleaned.startsWith('054')) {
    // Check if there's a 0 before the area code
    const withoutOptionalZero = cleaned.replace(/^0/, '');
    if (withoutOptionalZero === cleaned) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF]+(?:['\-\s][a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF]+)*$/;
  
  // Check for digits or other invalid characters
  if (/\d/.test(value) || /[^a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF\s'-]/.test(value)) {
    return false;
  }
  
  // Must not be empty
  if (value.trim().length === 0) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa/Mastercard/AmEx prefixes and lengths
 * Runs: Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2[2-7][0-1]|[3-6][0-9]{2}|71[0-1])\d{12}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || 
                        mastercardRegex.test(cleaned) || 
                        amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
