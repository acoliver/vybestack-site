/**
 * Capitalize the first character of each sentence.
 * - Insert exactly one space between sentences even if input omitted it
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence boundaries
  let result = text
    // Add space after .?! if followed by a lowercase letter and no space
    .replace(/([.!?])([a-z])/g, '$1 $2')
    // Collapse multiple spaces to one
    .replace(/\s+/g, ' ')
    // Trim leading/trailing whitespace
    .trim();
  
  // Capitalize first letter of text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize after sentence terminators, but avoid common abbreviations
  // Common abbreviations: Mr, Mrs, Ms, Dr, Prof, Sr, Jr, etc.
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'etc', 'vs', 'i\\.e', 'e\\.g'];
  const abbrPattern = new RegExp(`\\b(?:${abbreviations.join('|')})\\.$`, 'i');
  
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punct, letter) => {
    // Check if this is likely an abbreviation by looking at the word before the period
    const beforePunct = result.substring(0, result.indexOf(match)).split(/\s+/).pop() || '';
    
    if (abbrPattern.test(beforePunct)) {
      return punct + ' ' + letter; // Don't capitalize
    }
    
    return punct + ' ' + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlPattern = /(https?:\/\/(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])+(?:[:/][^\s.,!?;:()\]{}"']*)?)/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Strip trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,!?;:()\]{}"']+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/(https?):\/\/example\.com(\/[^\s]*)?/gi, (match, protocol, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';
    const fullPath = path || '/';
    
    // Check if we should skip host rewrite
    // Dynamic hints: cgi-bin, query strings, legacy extensions
    const skipHostRewrite = /\/cgi-bin\/|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i.test(fullPath);
    
    // Check if path starts with /docs/
    const isDocsPath = fullPath.startsWith('/docs/');
    
    if (isDocsPath && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return `${newProtocol}://docs.example.com${fullPath}`;
    } else {
      // Just upgrade the protocol
      return `${newProtocol}://example.com${fullPath}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for days in month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
