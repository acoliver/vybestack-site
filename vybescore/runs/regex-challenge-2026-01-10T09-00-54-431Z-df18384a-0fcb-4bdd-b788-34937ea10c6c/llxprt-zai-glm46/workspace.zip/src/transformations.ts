/**
 * Capitalize the first character of each sentence.
 * Rules:
 * - Capitalize first character of each sentence (after .?!)
 * - Insert exactly one space between sentences even if input omitted it
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible (e.g., "e.g.")
 */
export function capitalizeSentences(text: string): string {
  // First, add space after sentence terminators if missing
  let result = text.replace(/([.!?])([^.!?])/g, '$1 $2');

  // Collapse multiple spaces to single spaces
  result = result.replace(/\s+/g, ' ');

  // Trim leading/trailing whitespace
  result = result.trim();

  // Capitalize first character of the string
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }

  // Common abbreviations list (case-insensitive)
  const abbreviations = /\b(?:mr|mrs|ms|dr|prof|sr|jr|e\.g|i\.e|vs|etc|st|ave|blvd|rd|lt|col|gen|sen|rep|gov|pres)\.$/i;

  // Find and capitalize after each sentence terminator
  let i = 0;
  while (i < result.length) {
    const char = result[i];

    if (char === '.' || char === '!' || char === '?') {
      // Look ahead to see if this might be an abbreviation
      const beforeEnd = result.slice(0, i);

      // If not an abbreviation and not at the end, capitalize next letter
      if (!abbreviations.test(beforeEnd) && i < result.length - 1) {
        // Find the next alphabetic character
        let j = i + 1;
        while (j < result.length && !/[a-zA-Z]/.test(result[j])) {
          j++;
        }

        if (j < result.length) {
          // Capitalize this character
          result = result.slice(0, j) + result[j].toUpperCase() + result.slice(j + 1);
        }
      }
    }

    i++;
  }

  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, and www.
  // Does not include trailing punctuation like .,;?!()
  const urlRegex = /\b(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9][a-zA-Z0-9-]*)+(?:\/[^\s.,;:!?(){}[\]"']*)?(?<!\.,;:!?(){}[\]"'])/g;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation that might have been caught
  return matches.map(url => {
    // Remove trailing dots, commas, semicolons, colons, etc.
    return url.replace(/[.,;:!?(){}[\]"']+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * Rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints:
 *   - cgi-bin
 *   - query strings (?, &, =)
 *   - legacy extensions (.jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for http://example.com URLs
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade scheme
    const newProtocol = 'https://';

    // Check if path contains dynamic hints (skip host rewrite)
    const skipHostRewrite = /\/cgi-bin[/?]|[?=&]|[.](jsp|php|asp|aspx|do|cgi|pl|py)(?=[/?]|$)/i.test(path);

    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');

    if (isDocsPath && !skipHostRewrite) {
      // Rewrite host to docs.example.com
      return newProtocol + 'docs.example.com' + path;
    } else {
      // Just upgrade scheme
      return newProtocol + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex for mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  // If February, check for leap year if day is 29
  if (month === 2 && day === 29) {
    // Leap year check
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }

  // Year should be reasonable (e.g., 1000-9999)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }

  return yearStr;
}
