export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: alphanumeric + special chars like . _ % + - but no consecutive dots or trailing/leading dots
  // Domain: alphanumeric with hyphens, dots as separators, but no underscores or leading/trailing dots
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks
  const [local, domain] = value.split('@');

  // No double dots in local part
  if (local.includes('..')) {
    return false;
  }

  // No trailing dot in local part
  if (local.endsWith('.')) {
    return false;
  }

  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Domain should not have consecutive dots
  if (domain.includes('..')) {
    return false;
  }

  // Domain should not start or end with dot
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }

  // Domain labels should be valid (no consecutive hyphens, no leading/trailing hyphens)
  const labels = domain.split('.');
  for (const label of labels) {
    if (label.startsWith('-') || label.endsWith('-') || label.includes('--')) {
      return false;
    }
    if (label.length === 0) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');

  // Check for optional +1 prefix (digits 1 at start)
  let digits = digitsOnly;
  if (digits.startsWith('1') && digits.length > 10) {
    digits = digits.slice(1);
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Supports landlines and mobiles like:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - When country code omitted, must start with trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Regex pattern for Argentine phone numbers
  // ^\+?54?            - Optional +54 country code
  // \s?0?              - Optional trunk prefix 0 (when +54 is omitted, 0 is required)
  // \s?9?              - Optional mobile indicator 9
  // \s?(\d{2,4})       - Area code (2-4 digits, leading 1-9)
  // [\s-]?             - Optional separator
  // (\d{6,8})$         - Subscriber number (6-8 digits)

  const fullRegex = /^\+?54\s?9?\s?[1-9]\d{1,3}[\s-]?\d{6,8}$/;
  const withoutCountryRegex = /^0\s?9?\s?[1-9]\d{1,3}[\s-]?\d{6,8}$/;

  // Check if it matches either format
  if (!fullRegex.test(cleaned) && !withoutCountryRegex.test(cleaned)) {
    return false;
  }

  // Parse components for detailed validation
  let working = cleaned;

  // Check for country code
  const hasCountryCode = working.startsWith('+54');
  if (hasCountryCode) {
    working = working.slice(3);
  }

  // Check for trunk prefix (0)
  const hasTrunkPrefix = working.startsWith('0');
  if (hasTrunkPrefix) {
    working = working.slice(1);
  } else if (!hasCountryCode) {
    // Must have trunk prefix if no country code
    return false;
  }

  // Check for mobile indicator (9)
  const hasMobileIndicator = working.startsWith('9');
  if (hasMobileIndicator) {
    working = working.slice(1);
  }

  // Now working should be area code + subscriber number
  // Extract area code (2-4 digits)
  const areaCodeMatch = working.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }

  const [, areaCode, subscriber] = areaCodeMatch;

  // Area code must be 2-4 digits with leading 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }

  // Check for other symbols (beyond allowed apostrophe and hyphen)
  // Allow unicode letters, apostrophe, hyphen, space
  const disallowedSymbols = /[^\p{L}'\-\s]/u;
  if (disallowedSymbols.test(value)) {
    return false;
  }

  // Must have at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }

  // Cannot be only special characters
  const lettersOnly = value.replace(/['\-\s]/g, '');
  if (lettersOnly.length === 0) {
    return false;
  }

  return true;
}

/**
 * Helper function to run Luhn checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);

  let sum = 0;
  let double = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    double = !double;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(?:\d{3})?$/;

  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const mastercard2SeriesRegex = /^2[2-7][2-9][01]\d{11}$/;

  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  let validPrefix = false;

  if (visaRegex.test(cleaned) || mastercardRegex.test(cleaned) ||
      mastercard2SeriesRegex.test(cleaned) || amexRegex.test(cleaned)) {
    validPrefix = true;
  }

  if (!validPrefix) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
