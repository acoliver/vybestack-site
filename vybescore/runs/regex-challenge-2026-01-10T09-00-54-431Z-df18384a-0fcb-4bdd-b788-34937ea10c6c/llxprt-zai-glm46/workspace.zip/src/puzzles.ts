/**
 * Find words starting with the prefix but excluding banned words.
 * Returns array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Regex to find words starting with prefix (whole word boundary)
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9_-]*\\b`, 'g');

  const matches = text.match(wordRegex) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());

  return matches.filter(word => {
    return !exceptionsLower.includes(word.toLowerCase());
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Find all matches with their preceding digit
  // Uses lookbehind to ensure token is preceded by a digit
  const fullMatchRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const fullMatches = text.match(fullMatchRegex) || [];

  return fullMatches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences
  // Look for patterns like "abab", "abcabc", "123123", etc.
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const pattern = value.slice(i, i + len);
      const next = value.slice(i + len, i + 2 * len);
      if (pattern === next) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // Supports:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed zeros: 2001:db8::1
  // - Mixed notation (IPv4 embedded): ::ffff:192.168.1.1
  // - Loopback: ::1
  // - All zeros: ::

  // First, exclude IPv4-only patterns
  // IPv4: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;

  // If it looks like pure IPv4, return false
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false;
  }

  // IPv6 patterns - must have at least one colon
  const ipv6Patterns = [
    // Full IPv6
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Compressed with ::
    /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}?\b/,
    // Leading compressed
    /\b::(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}?\b/,
    // Trailing compressed
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/,
    // Single ::
    /\b::\b/,
    // Loopback
    /\b::1\b/,
  ];

  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Make sure it's not just an IPv4 address with colons
      // Extract the match and verify it has valid IPv6 structure
      const match = value.match(pattern);
      if (match) {
        const matched = match[0];
        // Must have at least 2 colons for valid IPv6 (except ::1 and similar)
        if ((matched.includes('::') || (matched.split(':').length >= 3)) && !ipv4Pattern.test(matched)) {
          return true;
        }
      }
    }
  }

  // Check for embedded IPv6 in text
  // Look for patterns like "2001:db8::1" within larger text
  const ipv6InText = /(?:^|[\s[(])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}(?:[\s]|$)/;
  if (ipv6InText.test(value)) {
    return true;
  }

  return false;
}
