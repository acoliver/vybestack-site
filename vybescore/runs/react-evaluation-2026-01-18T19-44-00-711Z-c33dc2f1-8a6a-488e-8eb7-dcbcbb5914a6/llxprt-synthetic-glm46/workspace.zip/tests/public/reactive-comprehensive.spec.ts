import { describe, it, expect } from 'vitest'
import { createInput, createComputed, createCallback } from '../../src/index.js'

describe('Reactive Programming - Additional Regression Cases', () => {
  // Extra regression coverage to catch edge cases in the reactive system
 
  it('compute cells can depend on other compute cells', () => {
    const [input, setInput] = createInput(1)
    const timesTwo = createComputed(() => input() * 2)
    const timesThirty = createComputed(() => input() * 30)
    const sum = createComputed(() => timesTwo() + timesThirty())
    expect(sum()).toEqual(32)
    setInput(3)
    expect(sum()).toEqual(96)
  })

  it('compute cells fire callbacks', () => {
    console.log('** Debug compute cells fire callbacks **')
    const [input, setInput] = createInput(1)
    const output = createComputed(() => {
      console.log('  inside computed: input =', input())
      return input() + 1
    })

    console.log('Initial: input =', input(), 'output =', output())
    
    let value = 0
    createCallback(() => {
      console.log('Callback fired! output =', output(), 'setting value to', output())
      value = output()
    })
    
    console.log('Before setInput: value =', value)
    console.log('Calling setInput(3)')
    setInput(3)
    console.log('After setInput: value =', value)
    expect(value).toEqual(4)
  })

  it('callbacks can be added and removed', () => {
    console.log('** Debug callbacks can be added and removed **')
    const [input, setInput] = createInput(11)
    const output = createComputed(() => input() + 1)

    const values1: number[] = []
    const unsubscribe1 = createCallback(() => {
      console.log('Callback1 fired, adding value:', output())
      values1.push(output())
    })
    
    const values2: number[] = []
    createCallback(() => {
      console.log('Callback2 fired, adding value:', output())
      values2.push(output())
    })

    console.log('Setting input to 31');
    setInput(31)
    console.log('After setInput(31): values1 =', values1, 'values2 =', values2)
    
    console.log('Calling unsubscribe1');
    unsubscribe1()
    console.log('Setting input to 41');
    setInput(41)
    console.log('After setInput(41): values1 =', values1, 'values2 =', values2)

    expect(values1.length).toBeGreaterThan(0)
    expect(values2.length).toBeGreaterThan(values1.length)
  })
})
