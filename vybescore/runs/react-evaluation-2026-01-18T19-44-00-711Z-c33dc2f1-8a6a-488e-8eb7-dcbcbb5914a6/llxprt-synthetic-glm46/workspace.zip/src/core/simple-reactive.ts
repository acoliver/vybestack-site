// Simple reactive system test to understand the issue

import {
  Observer,
  ObserverR,
  setActiveObserver
} from '../types/reactive.js'

// Simple dependency tracking system - tracks which observers depend on which
const dependencies = new Map<ObserverR, Set<ObserverR>>()

export function notifyObserver(observer: ObserverR): void {
  const dependents = dependencies.get(observer)
  if (!dependents) return
  
  // Create a copy to avoid issues with modifications during iteration
  const dependentsCopy = Array.from(dependents)
  
  for (const dependent of dependentsCopy) {
    const fullObserver = dependent as Observer<unknown> & { disposed?: boolean }
    if (fullObserver.disposed === true) {
      continue // Skip disposed observers
    }
    
    // Set this observer as active so its dependencies are re-tracked when it runs
    const prev = setActiveObserver(dependent)
    try {
      // Call the update function to execute the side effect or compute new value
      fullObserver.value = fullObserver.updateFn(fullObserver.value)
    } finally {
      setActiveObserver(prev)
    }
  }
}

export function trackDependency(dependent: ObserverR, dependency: ObserverR): void {
  // When an observer accesses some data source, record that dependency
  // This is called from getter functions to establish the reactive relationship
  
  // Prevent self-tracking and circular dependencies
  if (dependent === dependency) {
    return
  }
  
  let deps = dependencies.get(dependency)
  if (!deps) {
    deps = new Set()
    dependencies.set(dependency, deps)
  }
  
  // Only add if not already present
  if (!deps.has(dependent)) {
    deps.add(dependent)
  }
}

export function removeObserver(dependent: ObserverR): void {
  // Mark the observer as disposed if it has that property
  const fullDependent = dependent as Observer<unknown> & { disposed?: boolean }
  if ('disposed' in fullDependent) {
    fullDependent.disposed = true
  }
  
  // Clean up all dependency relationships
  for (const [, deps] of dependencies.entries()) {
    deps.delete(dependent)
  }
}