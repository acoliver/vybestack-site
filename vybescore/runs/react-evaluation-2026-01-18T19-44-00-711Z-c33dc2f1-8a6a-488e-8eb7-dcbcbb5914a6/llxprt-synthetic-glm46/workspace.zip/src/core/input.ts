/**
 * Simple input closure implementation.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'
import { notifyObserver, trackDependency } from './simple-reactive.js'
import { getActiveObserver } from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  // This input acts as a dependency source
  const inputObserver: ObserverR = {
    name: options?.name,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track that this observer depends on this input
      trackDependency(observer, inputObserver)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if we should update based on equality function
    if (equalFn && equalFn(value, nextValue)) {
      return value
    }
    
    value = nextValue
    
    // Notify all dependent observers
    notifyObserver(inputObserver)
    
    return value
  }

  return [read, write]
}
