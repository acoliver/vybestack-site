/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'
import { trackDependency } from './simple-reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    updateFn,
  }
  
  // Create the getter function
  const getter: GetterFn<T> = () => {
    // Get the currently active observer (could be a callback)
    const activeObserver = getActiveObserver()
    
    // If there's an active observer, track that this observer depends on this computed value
    if (activeObserver && activeObserver !== o) {
      trackDependency(activeObserver, o)
    }
    
    // Use updateObserver which handles setting the active observer
    updateObserver(o)
    return o.value!
  }
  
  // Initialize with initial computation
  updateObserver(o)
  
  return getter
}
