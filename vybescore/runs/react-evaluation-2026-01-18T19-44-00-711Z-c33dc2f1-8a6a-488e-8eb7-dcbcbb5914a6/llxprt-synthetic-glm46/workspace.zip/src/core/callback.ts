/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver } from '../types/reactive.js'
import { removeObserver } from './simple-reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const callbackFn = updateFn // Store the original callback function
  
  const observer: Observer<T> & { disposed?: boolean } = {
    value,
    disposed: false,
    updateFn: (prevVal?: T): T => {
      if (!disposed) {
        // Set this observer as active when executing the callback
        // so that dependencies are properly tracked
        const prev = setActiveObserver(observer)
        try {
          const result = callbackFn(prevVal) as T
          return result
        } finally {
          setActiveObserver(prev)
        }
      }
      return value as T
    },
  }
  
  // Initialize by running once to establish dependencies
  const prev = setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(prev)
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    observer.disposed = true
    
    // Clean up all dependencies
    removeObserver(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
  }
  
  return unsubscribe
}
