/**
 * Validate a Base64 string.
 * Standard Base64 uses: A-Z, a-z, 0-9, +, /, and = for padding.
 */
function isValidBase64(input: string): boolean {
  // Remove any whitespace for validation
  const trimmed = input.trim();

  // Empty string is invalid
  if (trimmed.length === 0) {
    return false;
  }

  // Check for valid Base64 characters (standard alphabet)
  // Valid characters: A-Z, a-z, 0-9, +, /, and = (only at the end)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmed)) {
    return false;
  }

  // Padding must only appear at the end
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Check there's no non-padding characters after the first =
    const afterPadding = trimmed.substring(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      return false;
    }
  }

  // Length must be a multiple of 4 (for standard Base64 with optional padding)
  const unpaddedLength = trimmed.replace(/=+$/, '').length;
  return unpaddedLength % 4 !== 1;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate input before attempting to decode
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced valid output
    // If the input was invalid base64, Node.js may produce an empty buffer
    // or partial results without throwing an error
    if (trimmed.length > 0 && buffer.length === 0 && !/^=+$/.test(trimmed)) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
