/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (const word of words) {
    // Check if word starts with the prefix
    if (word.startsWith(prefix)) {
      // Check if the word is in the exceptions list
      if (!exceptions.includes(word)) {
        results.push(word);
      }
    }
  }
  
  return results;
}



/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  // Look for patterns where token is preceded by a digit, but not at string start
  // Use lookbehind to ensure the digit is there, and negative lookbehind to avoid string start
  const pattern = new RegExp(`(?<!^)(\\d+${token})`, 'g');
  
  const matches = text.match(pattern);
  
  if (matches) {
    // Add all the full matches (includes the digit part)
    for (const match of matches) {
      results.push(match);
    }
  }
  
  return results;
}

/**
 * Helper function to check for repeated sequences.
 */
function hasRepeatedSequence(password: string): boolean {
  for (let i = 0; i < password.length - 3; i++) {
    const sequence1 = password.substring(i, i + 2);
    if (password.substring(i + 2).startsWith(sequence1)) {
      // Found a pattern like XYXY (two-character pattern repeated)
      return true;
    }
  }
  
  for (let i = 0; i < password.length - 5; i++) {
    const sequence1 = password.substring(i, i + 3);
    if (password.substring(i + 3).startsWith(sequence1)) {
      // Found a pattern like XYXYXY (three-character pattern repeated)
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) return false;
  
  // Check for repeated sequences
  if (hasRepeatedSequence(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern - this should NOT match for our IPv6-only detection
  const ipv4Pattern = /(\d{1,3}\.){3}\d{1,3}/;
  
  // IPv6 address patterns
  // Full format: 8 groups of 4 hex digits separated by colons
  const ipv6FullPattern = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Shorthand format with :: (one or more groups of zeros)
  const ipv6ShorthandPattern = /([0-9a-fA-F]{1,4}:){0,6}:([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with embedded IPv4
  const ipv6WithIPv4Pattern = /([0-9a-fA-F]{1,4}:){0,5}:(\d{1,3}\.){3}\d{1,3}/;
  
  // Pattern for addresses that might match both IPv4 and IPv6
  const potentialIPv4 = value.match(ipv4Pattern);
  
  // Check for IPv6 patterns
  const isIPv6Full = ipv6FullPattern.test(value);
  const isIPv6Shorthand = ipv6ShorthandPattern.test(value);
  const isIPv6WithIPv4 = ipv6WithIPv4Pattern.test(value);
  
  // If it matches IPv4 exactly, it's not IPv6
  if (potentialIPv4 && potentialIPv4[0] === value && !value.includes(':')) {
    return false;
  }
  
  return isIPv6Full || isIPv6Shorthand || isIPv6WithIPv4;
}
