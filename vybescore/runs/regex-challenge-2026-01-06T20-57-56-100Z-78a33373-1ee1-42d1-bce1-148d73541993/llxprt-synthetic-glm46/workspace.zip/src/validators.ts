export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  if (value.includes('..')) return false;
  if (value.includes('@.') || value.includes('.@')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@')) {
    const [local, domain] = value.split('@');
    // Domain with underscores is invalid
    if (domain.includes('_')) return false;
    // Domain with consecutive dots is invalid
    if (domain.includes('..')) return false;
    // Local part with leading or trailing dot is invalid
    if (local.startsWith('.') || local.endsWith('.')) return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
// Handle extension validation if enabled
  if (options?.allowExtensions && value.includes('x') && /[a-zA-Z]/.test(value)) {
    // Extensions contain letters, so we need to validate the numeric part separately
    const numericPart = value.split('x')[0].replace(/\D/g, '');
    if (numericPart.length < 10) return false;
    
    // Validate area code for the numeric part
    const areaCode = numericPart.substring(0, 3);
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  }
  // Check for minimum length (10 digits standard, 11 digits with +1 country code)
  if (digitsOnly.length < 10) return false;
  
  // If 11 digits, must start with 1 (US country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // If more than 11 digits, it's invalid
  if (digitsOnly.length > 11) return false;
  
  // Extract the actual 10-digit phone number (remove country code if present)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Check area code: must not start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check format with optional country code, separators
  const phoneRegex = /^(\+1\s?)?(\(?[2-9]\d{2}\)?[\s-]?)?[2-9]\d{2}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation, but keep other characters for regex matching
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Full Argentine phone regex
  const argentinePhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})\d{6,8}$/;
  
  // Test the clean format
  if (!argentinePhoneRegex.test(cleanValue)) {
    // Alternative format: with trunk prefix 0 when country code is omitted
    const withTrunkPrefixRegex = /^0([1-9]\d{1,3})\d{6,8}$/;
    if (withTrunkPrefixRegex.test(cleanValue)) {
      // With trunk prefix but without country code
      return true;
    }
    return false;
  }
  
  // Extract the area code to validate its length (2-4 digits, leading digit 1-9)
  const match = cleanValue.match(argentinePhoneRegex);
  if (match) {
    const areaCode = match[3]; // The area code part
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    // Extract and validate the subscriber number (6-8 digits after area code)
    const afterAreaCode = cleanValue.split(areaCode)[1];
    if (!afterAreaCode || afterAreaCode.length < 6 || afterAreaCode.length > 8) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name regex that allows unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if the value matches the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional checks for common invalid patterns
  if (/\d/.test(value)) return false; // Contains digits
  
  // Check for multiple consecutive spaces/hyphens/apostrophes
  if (/\s{2,}/.test(value)) return false; // Multiple consecutive spaces
  if (/-{2,}/.test(value)) return false; // Multiple consecutive hyphens
  if (/'{2,}/.test(value)) return false; // Multiple consecutive apostrophes
  
  // Check for invalid start/end characters
  if (value.startsWith(' ') || value.startsWith('-') || value.startsWith("'")) return false;
  if (value.endsWith(' ') || value.endsWith('-') || value.endsWith("'")) return false;
  
  // Reject names with only special characters
  const lettersOnly = value.replace(/['\-\s]/g, '');
  if (!lettersOnly) return false; // No actual letters
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check valid lengths:
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  if (cleanValue.length === 13 && cleanValue.startsWith('4')) {
    // Visa 13-digit
    return runLuhnCheck(cleanValue);
  }
  
  if (cleanValue.length === 15 && (cleanValue.startsWith('34') || cleanValue.startsWith('37'))) {
    // AmEx
    return runLuhnCheck(cleanValue);
  }
  
  if (cleanValue.length === 16) {
    // Visa 16-digit or Mastercard
    if (cleanValue.startsWith('4')) {
      // Visa 16-digit
      return runLuhnCheck(cleanValue);
    }
    
    // Mastercard ranges
    const prefix = parseInt(cleanValue.substring(0, 2), 10);
    const prefix4 = parseInt(cleanValue.substring(0, 4), 10);
    
    if (prefix >= 51 && prefix <= 55) {
      // Standard Mastercard (51-55)
      return runLuhnCheck(cleanValue);
    }
    
    if (prefix4 >= 2221 && prefix4 <= 2720) {
      // New Mastercard (2221-2720)
      return runLuhnCheck(cleanValue);
    }
  }
  
  return false;
}
