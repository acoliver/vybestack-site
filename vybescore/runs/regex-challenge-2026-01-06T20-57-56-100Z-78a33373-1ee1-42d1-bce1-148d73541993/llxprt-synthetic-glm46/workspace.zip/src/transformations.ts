/**
 * List of common abbreviations that don't indicate sentence endings.
 */
const ABBREVIATIONS = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'St.', 'Sr.', 'Jr.', 'etc.', 'vs.', 'e.g.', 'i.e.'];

/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spaces between sentences
  let normalized = text.replace(/([.?!])([^ ])/g, '$1 $2'); // Add space after punctuation if missing
  normalized = normalized.replace(/ +/g, ' '); // Collapse multiple spaces to single
  
  // Split by sentence endings using lookbehind to keep punctuation with preceding text
  const sentences = normalized.split(/(?<=[.?!])/);
  
  let result = '';
  
  for (const sentence of sentences) {
    if (!sentence.trim()) {
      // Just whitespace, add as-is
      result += sentence;
      continue;
    }
    
    // Check if this contains an abbreviation (shouldn't start new sentence)
    const isAbbreviation = ABBREVIATIONS.some(abbr => 
      sentence.toLowerCase().includes(abbr.toLowerCase())
    );
    
    if (isAbbreviation && result) {
      // This continues the previous sentence, add as-is
      result += sentence;
    } else {
      // New sentence, capitalize first letter
      // Find first non-space character to capitalize
      const firstNonSpace = sentence.search(/\S/);
      if (firstNonSpace >= 0) {
        result += sentence.substring(0, firstNonSpace) + 
                  sentence.charAt(firstNonSpace).toUpperCase() + 
                  sentence.substring(firstNonSpace + 1);
      } else {
        // All whitespace
        result += sentence;
      }
    }
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex);
  
  if (!matches) return [];
  
  // Trim trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]}>]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https:// already
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match example.com URLs with optional www and subdomains, including path
  const urlRegex = /(https:\/\/(?:www\.)?example\.com)(\/[^ \n]*)?/g;
  
  // Check for dynamic hints that should prevent host rewriting
  const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  
  result = result.replace(urlRegex, (match, host, path = '') => {
    // Check if any part of the URL contains dynamic hints or query params
    const hasDynamicHints = dynamicHints.some(hint => match.includes(hint));
    const hasQueryParams = match.includes('?') || match.includes('&') || match.includes('=');
    
    if (hasDynamicHints || hasQueryParams) {
      // Don't rewrite host, just keep the protocol upgrade
      return match;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite to docs.example.com, preserving the path
      return `https://docs.example.com${path}`;
    }
    
    // No special conditions, return as-is
    return match;
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Simple case first: mm/dd/yyyy format
  const simpleDateRegex = /^\d{2}\/\d{2}\/(\d{4})$/;
  const simpleMatch = value.match(simpleDateRegex);
  
  if (simpleMatch) {
    const [, year] = simpleMatch;
    
    // Extract month and day to validate them
    const monthStr = value.substring(0, 2);
    const dayStr = value.substring(3, 5);
    
    const month = parseInt(monthStr, 10);
    const day = parseInt(dayStr, 10);
    
    // Check if month and day are valid
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return year;
    }
  }
  
  // More general case: find any year pattern in the text, but only if mm/dd/yyyy is around it
  // This is a more complex regex that tries to ensure the date format is mm/dd/yyyy
  const complexDateRegex = /(?:^|[\s[(])(\d{1,2})\/(\d{1,2})\/(\d{4})(?:$|[\s\]).,;:?])/;
  const complexMatch = value.match(complexDateRegex);
  
  if (complexMatch) {
    const month = parseInt(complexMatch[1], 10);
    const day = parseInt(complexMatch[2], 10);
    const year = complexMatch[3];
    
    // Validate month and day
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return year;
    }
  }
  
  return 'N/A';
}
