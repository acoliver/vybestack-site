/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof _equal === "function") {
    equalFn = _equal
  }
  
  const observers = new Set<Observer<T>>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    if (observer) {
      observers.add(observer as Observer<T>)
    }
    
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(value, nextValue)) {
      return value
    }
    
    value = nextValue
    
    // Notify all observers
    const oldObservers = Array.from(observers)
    oldObservers.forEach(observer => {
      updateObserver(observer)
    })
    
    return value
  }

  return [read, write]
}
