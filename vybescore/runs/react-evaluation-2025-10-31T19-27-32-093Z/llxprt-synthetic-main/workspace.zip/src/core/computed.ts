/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Setup equality function if needed
  let equalFn: EqualFn<T> | undefined
  
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof _equal === "function") {
    equalFn = _equal
  }
  
  let currentValue = value
  const observers = new Set<Observer<T>>()
  
  // We need to track when dependencies change by connecting to the input objects
  // Use a flag to track if we're currently updating to prevent infinite recursion
  let isUpdating = false
  
  // Create an observer that will be notified when dependencies change
  const observer: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: () => {
      if (isUpdating) return value as T
      
      isUpdating = true
      try {
        const newValue = updateFn(currentValue)
        
        if (currentValue === undefined || (equalFn && !equalFn(currentValue, newValue)) || !equalFn) {
          currentValue = newValue
          
          // Notify all observers
          const oldObservers = Array.from(observers)
          oldObservers.forEach(obs => {
            if (obs !== observer) { // Don't notify ourselves to prevent infinite recursion
              updateObserver(obs)
            }
          })
        }
        
        return currentValue as T
      } finally {
        isUpdating = false
        observer.value = currentValue
      }
    }
  }
  
  // Register dependencies for the computed value
  updateObserver(observer)
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver() as Observer<T> | undefined
    if (currentObserver) {
      observers.add(currentObserver)
    }
    
    return currentValue as T
  }
  
  return getter
}