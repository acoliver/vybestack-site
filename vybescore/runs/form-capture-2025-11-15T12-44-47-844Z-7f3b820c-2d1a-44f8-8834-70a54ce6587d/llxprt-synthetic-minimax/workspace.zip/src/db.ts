import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

let db: Database | null = null;

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

export async function initDb(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file) => `file://${path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)}`
    });

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      
      // Create the schema using the provided schema.sql content
      const schema = `
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `;
      
      db.run(schema);
      await saveDb();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export async function saveSubmission(formData: {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);

  stmt.free();
  await saveDb();
}

async function saveDb(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const dbBuffer = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(dbBuffer));
}

export async function closeDb(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}