import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDb, saveSubmission, closeDb } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3535');

// View engine setup
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Validation functions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateFormData(data: FormData): { errors: Record<string, string>, isValid: boolean } {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const fieldValue = data[field as keyof FormData] as string;
    if (!fieldValue || fieldValue.trim() === '') {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !/^[+]?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return { errors, isValid: Object.keys(errors).length === 0 };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req, res) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData,
      title: 'Contact Form'
    });
  }

  try {
    await saveSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: { submit: 'There was an error processing your request. Please try again.' },
      formData,
      title: 'Contact Form'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await closeDb();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await closeDb();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await initDb();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();