/**
 * Helper function to escape special characters in a string for use in a regex
 */
function escapeRegexString(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create a Set for faster exception lookup
  const exceptionSet = new Set(exceptions);
  
  // Create regex to find words starting with the prefix
  // Word boundary \b ensures we match whole words
  // The regex captures the full word (not just the prefix)
  const prefixRegex = new RegExp(`\\b${escapeRegexString(prefix)}\\w+`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = prefixRegex.exec(text)) !== null) {
    const word = match[0];
    
    // Skip if the word is in the exceptions list
    if (!exceptionSet.has(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = escapeRegexString(token);
  
  // Create a regex pattern that captures the token when it appears after a digit
  // but not at the beginning of the string
  // This captures the entire match including the preceding digit
  const embeddedTokenRegex = new RegExp(`(?<!^)(\\d${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = embeddedTokenRegex.exec(text)) !== null) {
    matches.push(match[1]);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string' || value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (非字母数字字符)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab should fail)
  // This pattern checks for any character sequence repeated 2 or more times in immediate succession
  const repeatedSequencePattern = /(..+?)\1+/;
  if (repeatedSequencePattern.test(value)) return false;
  
  // If all checks pass, the password is strong
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') return false;
  
  // IPv4 address regex to exclude IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // IPv6 address regex (including shorthand ::)
  // This pattern covers:
  // - Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Compressed with :: 
  // - Leading zeros omitted
  const ipv6Pattern = /(?:^|(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$)|(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|:(?::[0-9a-fA-F]{1,4}){1,7}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){1,5}(?::[0-9a-fA-F]{1,4})?|::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Split the input into tokens that might be IP addresses
  const tokens = value.split(/\s+/);
  
  for (const token of tokens) {
    // Skip if it's clearly an IPv4 address
    if (ipv4Pattern.test(token)) continue;
    
    // Check if it matches IPv6 pattern
    if (ipv6Pattern.test(token)) {
      return true;
    }
  }
  
  return false;
}