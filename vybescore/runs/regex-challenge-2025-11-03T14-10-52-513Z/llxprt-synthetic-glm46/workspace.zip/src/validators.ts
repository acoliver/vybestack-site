export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Email regex that follows RFC 5322 simplified rules
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject emails with double dots
  if (value.includes('..')) return false;
  
  // Reject emails ending with a dot
  if (value.endsWith('.')) return false;
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let normalizedDigits = digitsOnly;
  if (digitsOnly.length >= 11 && digitsOnly.startsWith('1')) {
    normalizedDigits = digitsOnly.substring(1);
  }
  
  // Too short or too long
  if (normalizedDigits.length < 10 || normalizedDigits.length > 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = normalizedDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Basic US phone number validation pattern
  const phonePattern = /^(\+1[\s-]?)?(\(?[2-9]\d{2}\)?[\s-]?)[2-9]\d{2}[\s-]?\d{4}$/;
  
  return phonePattern.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers:
  // Optional +54 country code
  // Either +54 or 0 before area code, but not both
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  
  // Try matching with country code
  if (cleaned.startsWith('+54')) {
    const match = cleaned.match(/^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/);
    if (match) {
      // Area code validation (2-4 digits)
      const areaCode = match[2];
      const subscriber = match[3];
      return areaCode.length >= 2 && areaCode.length <= 4 && 
             subscriber.length >= 6 && subscriber.length <= 8;
    }
  } 
  // Try matching with trunk prefix (0)
  else if (cleaned.startsWith('0')) {
    const match = cleaned.match(/^0([1-9]\d{1,3})(\d{6,8})$/);
    if (match) {
      // Area code validation (2-4 digits)
      const areaCode = match[1];
      const subscriber = match[2];
      return areaCode.length >= 2 && areaCode.length <= 4 && 
             subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  // Try matching with country code and trunk indicator
  else {
    const match = cleaned.match(/^(\+54)?(9)?0?([1-9]\d{1,3})(\d{6,8})$/);
    if (match) {
      // Area code validation (2-4 digits)
      const areaCode = match[3];
      const subscriber = match[4];
      return areaCode.length >= 2 && areaCode.length <= 4 && 
             subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Regex that allows:
  // Unicode letters (\p{L}) including accented characters
  // Apostrophes and hyphens
  // Spaces
  // But not digits or symbols other than apostrophes and hyphens
  const nameRegex = /^[\p{L}'\- ]+$/u;
  
  // Check if the entire string matches the pattern
  return nameRegex.test(value);
}

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) return false;
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Basic pattern for credit card validation
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  // Visa
  const visaPattern = /^4(\d{12}|\d{15})$/;
  
  // Mastercard
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // American Express
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if the card number matches any of the patterns
  const isValidLength = visaPattern.test(digits) || mastercardPattern.test(digits) || amexPattern.test(digits);
  
  // Run Luhn checksum validation
  const passesLuhn = runLuhnCheck(value);
  
  return isValidLength && passesLuhn;
}
