/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') return '';
  
  // First, add a space between sentences if missing
  let result = text.replace(/([.!?])(?=\w)/g, '$1 ');
  
  // Then collapse multiple spaces into one space
  result = result.replace(/ +/g, ' ');
  
  // Finally, capitalize the first character after sentence boundaries and at the beginning
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string') return [];
  
  // Regular expression to match URLs
  // This regex captures the entire URL including the protocol
  const urlRegex = /https?:\/\/[^\s]+/g;
  
  const urls = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:?!'")\]\}]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') return '';
  
  // This pattern matches http://example.com URLs
  const httpUrlRegex = /http:\/\/example\.com(\/[^\s]*)?/g;
  
  // Replace all matched URLs
  return text.replace(httpUrlRegex, (match, path) => {
    // If there's no path, just upgrade to https
    if (!path) return 'https://example.com';
    
    // Skip host rewrite if path contains dynamic hints, query strings, or legacy extensions
    if (
      path.includes('cgi-bin') ||
      path.includes('?') ||
      path.includes('&') ||
      path.includes('=') ||
      path.endsWith('.jsp') ||
      path.endsWith('.php') ||
      path.endsWith('.asp') ||
      path.endsWith('.aspx') ||
      path.endsWith('.do') ||
      path.endsWith('.cgi') ||
      path.endsWith('.pl') ||
      path.endsWith('.py')
    ) {
      // Just upgrade the scheme to https
      return `https://example.com${path}`;
    }
    
    // If the path starts with /docs/, rewrite host to docs.example.com
    if (path.startsWith('/docs/')) {
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise, just upgrade the scheme
    return `https://example.com${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month/day combinations
  // April, June, September, November have 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // February has 28 days (ignoring leap years for simplicity)
  if (month === 2 && day > 28) {
    return 'N/A';
  }
  
  // All other months have 31 days
  if (!((month === 4 || month === 6 || month === 9 || month === 11) || month === 2) && day > 31) {
    return 'N/A';
  }
  
  return year;
}
