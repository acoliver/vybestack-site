/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to find words starting with the prefix
  // Using word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex pattern using lookbehind to ensure token appears after a digit
  // and not at the beginning of the string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  const matches = text.match(new RegExp(`${escapedToken}`, 'g')) || [];
  const result = [];
  
  // Manually check each match to ensure it meets our criteria
  let index = 0;
  for (const match of matches) {
    const currentIndex = text.indexOf(match, index);
    
    // Check if this match is at the beginning of string (skip)
    if (currentIndex === 0) {
      index = currentIndex + 1;
      continue;
    }
    
    // Check if previous character is a digit
    const prevChar = text.charAt(currentIndex - 1);
    if (/\d/.test(prevChar)) {
      result.push(prevChar + match);
    }
    
    index = currentIndex + 1;
  }
  
  return result;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab" should fail)
  // This checks for any 4-character sequence that repeats immediately
  for (let i = 0; i <= value.length - 4; i++) {
    const sequence = value.substring(i, i + 2);
    const nextSequence = value.substring(i + 2, i + 4);
    if (sequence === nextSequence) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns - simplified to handle common cases
  // This includes shorthand :: patterns
  const ipv6Patterns = [
    /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,           // Full IPv6
    /([0-9a-fA-F]{1,4}:)*([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/, // Shorthand with middle ::
    /::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/,           // Shorthand at start
    /([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}::/,           // Shorthand at end
    /::/,                                               // Just ::
    /([0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}/      // IPv4-mapped IPv6
  ];
  
  // Test against all patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
