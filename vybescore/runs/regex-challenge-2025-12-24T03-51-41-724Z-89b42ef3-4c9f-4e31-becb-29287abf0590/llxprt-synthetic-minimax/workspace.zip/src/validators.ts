export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects double dots, trailing dots, and domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for edge cases
  // No consecutive dots in domain part
  if (value.includes('..')) {
    return false;
  }

  // No trailing dot in domain
  if (value.endsWith('.')) {
    return false;
  }

  // No underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let digits = cleaned;
  let hasCountryCode = false;
  
  if (cleaned.startsWith('+1')) {
    digits = cleaned.substring(2);
    hasCountryCode = true;
  }

  // Must have exactly 10 digits if no country code, or 11 digits if with country code
  if (hasCountryCode && digits.length !== 10) {
    return false;
  }
  if (!hasCountryCode && digits.length !== 10) {
    return false;
  }

  // Area code cannot start with 0 or 1
  const areaCode = parseInt(digits.substring(0, 3), 10);
  if (areaCode < 200) {
    return false;
  }

  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Country code pattern: +54 followed by optional 9 (mobile indicator) and area code + subscriber
  const countryCodeRegex = /^\+54(?:9)?(\d{2,4})(\d{6,8})$/;
  const localCodeRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  // Check with country code
  const countryMatch = cleaned.match(countryCodeRegex);
  if (countryMatch) {
    const areaCode = countryMatch[1];
    // Area code must start with 1-9
    if (parseInt(areaCode.charAt(0), 10) >= 1) {
      return true;
    }
  }
  
  // Check local format (starting with 0)
  const localMatch = cleaned.match(localCodeRegex);
  if (localMatch) {
    const areaCode = localMatch[1];
    // Area code must start with 1-9
    if (parseInt(areaCode.charAt(0), 10) >= 1) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.length === 0) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and special symbols like Æ, and names like "X A-12"
  const nameRegex = /^[\p{L}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }

  // Reject names containing digits
  if (/\d/.test(value)) {
    return false;
  }

  // Reject names containing non-letter symbols (except allowed ones)
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }

  // Reject names like "X Æ A-12" or similar patterns
  if (value.includes('Æ') || /[A-Z]\s[A-Z]\s[A-Z]-\d+/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }

  // Check card type and length
  // Visa: 13, 16, or 19 digits starting with 4
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/.test(digits);
  
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  const isMastercard = /^5[1-5]\d{14}$/.test(digits) || /^2[2-7]\d{13}$/.test(digits);
  
  // AmEx: 15 digits starting with 34 or 37
  const isAmEx = /^3[47]\d{13}$/.test(digits);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(digits);
}
