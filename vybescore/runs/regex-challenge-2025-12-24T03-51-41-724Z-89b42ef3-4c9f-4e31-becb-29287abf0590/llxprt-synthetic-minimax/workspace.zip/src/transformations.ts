/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to find sentence boundaries followed by optional spaces and lowercase letters
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, sentenceStart, firstLetter) => {
    return sentenceStart + firstLetter.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https URLs and captures the URL without trailing punctuation
  const urlRegex = /https?:\/\/[^\s)]+[.,;:!?]?/g;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  return text.replace(/https?:\/\/([^/\s]+)(\/[^?\s]*)?/g, (match, host, path = '') => {
    const isHttp = match.startsWith('http://');
    const hasDynamicContent = /(\?.*$|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$)/i.test(match);
    
    if (isHttp && !hasDynamicContent) {
      // Upgrade to https
      let newUrl = 'https://';
      
      if (path.startsWith('/docs/')) {
        // Rewrite host to docs.domain.com
        newUrl += `docs.${host}${path}`;
      } else {
        // Just upgrade scheme, keep original host
        newUrl += `${host}${path}`;
      }
      
      return newUrl;
    }
    
    return match; // Return unchanged if already https or has dynamic content
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic check for valid days in each month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
