import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, CLIOptions } from '../types.js';

function parseArguments(argv: string[]): CLIOptions {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  let format: CLIOptions['format'] | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        format = args[i + 1] as CLIOptions['format'];
        i++; // Skip next argument as it's the value
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        outputPath = args[i + 1];
        i++; // Skip next argument as it's the value
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        // Ignore unknown arguments for now
        break;
    }
  }
  
  if (!format) {
    throw new Error('--format is required');
  }
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  // Validate title
  if (typeof reportData.title !== 'string' || reportData.title.trim() === '') {
    throw new Error('Invalid JSON: "title" must be a non-empty string');
  }
  
  // Validate summary
  if (typeof reportData.summary !== 'string' || reportData.summary.trim() === '') {
    throw new Error('Invalid JSON: "summary" must be a non-empty string');
  }
  
  // Validate entries
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }
  
  if (reportData.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" must not be empty');
  }
  
  // Validate each entry
  const entries = reportData.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || entryObj.label.trim() === '') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a non-empty string`);
    }
    
    if (typeof entryObj.amount !== 'number' || !isFinite(entryObj.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
  
  return data as ReportData;
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const fullPath = join(process.cwd(), filePath);
    const content = readFileSync(fullPath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    } else if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      }
      throw error;
    } else {
      throw new Error(`Unexpected error reading ${filePath}`);
    }
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    const fullPath = join(process.cwd(), outputPath);
    writeFileSync(fullPath, content, 'utf-8');
  } else {
    process.stdout.write(content + '\n');
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    const data = loadAndValidateData(options.dataFile);
    
    let output: string;
    
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(data, options.includeTotals);
        break;
      case 'text':
        output = renderText(data, options.includeTotals);
        break;
      default:
        throw new Error(`Unsupported format: ${options.format}`);
    }
    
    writeOutput(output, options.outputPath);
    
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
