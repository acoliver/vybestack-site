/**
 * Match words starting with the prefix but excluding banned words.
 * Uses lookaheads to find words beginning with the specified prefix.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: word boundary, prefix, word characters, word boundary
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      exception.toLowerCase() === word.toLowerCase()
    )
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookbehinds and lookaheads to find tokens in specific contexts.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Lookahead: find token preceded by a digit
  // Negative lookbehind: ensure not at start of string (or preceded by start)
  // Actually, we need: digit followed by token
  // Use positive lookbehind for digit: (?<=\d)
  // The pattern should match the token only when preceded by a digit
  
  // We want to match "1foo" not just "foo", so we need to capture the digit too
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const pattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 * Matches full IPv6, compressed (::), and mixed formats while rejecting pure IPv4.
 */
export function containsIPv6(value: string): boolean {
  // Check if it's a pure IPv4 address first - should NOT match
  const ipv4Regex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Full IPv6 pattern (8 groups of 1-4 hex digits)
  const ipv6FullRegex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Compressed IPv6 with ::
  // Must have :: somewhere
  const ipv6CompressedRegex = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/;
  
  // Check if the value contains an IPv6 address (not necessarily the whole string)
  if (ipv6FullRegex.test(value) || ipv6CompressedRegex.test(value)) {
    return true;
  }
  
  // Also check for IPv6 patterns embedded in text
  const embeddedIPv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?!\d)/;
  const embeddedIPv6Compressed = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}(?!\d)/;
  
  if (embeddedIPv6Full.test(value) || embeddedIPv6Compressed.test(value)) {
    return true;
  }
  
  // Check for IPv6 with IPv4 embedded (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4Regex = /(?:[0-9a-fA-F]{1,4}:)*::?(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}/;
  
  if (ipv6WithIPv4Regex.test(value)) {
    return true;
  }
  
  return false;
}
