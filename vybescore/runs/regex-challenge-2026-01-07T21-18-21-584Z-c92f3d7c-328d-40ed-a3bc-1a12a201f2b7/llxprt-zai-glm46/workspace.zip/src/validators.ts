export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant simplified email regex
  // Local part: alphanumeric, dots, hyphens, underscores, plus (but not consecutive dots, leading/trailing dots)
  // Domain: alphanumeric labels separated by dots, ending with valid TLD (2+ letters)
  // No underscores in domain part
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots in local part
  const [localPart, domain] = value.split('@');
  if (localPart.includes('..') || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Check for double dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length (10 digits for US number)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Remove optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }
  
  // Must have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if the format matches common patterns
  // Should handle: (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890
  const formatRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  
  return formatRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits, leading digit 1-9
 * - Subscriber number must be 6-8 digits
 * - When country code omitted, must start with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens to get raw digits
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Parse the components
  // Pattern: [+54][9][area_code][subscriber]
  // Or: 0[area_code][subscriber] (without country code)
  const withCountryRegex = /^\+?54(\d)(\d{2,4})(\d{6,8})$/;
  const withoutCountryRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  const withCountryMatch = cleaned.match(withCountryRegex);
  const withoutCountryMatch = cleaned.match(withoutCountryRegex);
  
  if (withCountryMatch) {
    const [, , areaCode, subscriber] = withCountryMatch;
    
    // Validate area code: 2-4 digits, leading digit 1-9
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
      return false;
    }
    
    // Validate subscriber: 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  if (withoutCountryMatch) {
    const [, areaCode, subscriber] = withoutCountryMatch;
    
    // Validate area code: 2-4 digits, leading digit 1-9
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
      return false;
    }
    
    // Validate subscriber: 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Regex explanation:
  // ^\p{L}+ - starts with unicode letter(s)
  // [\p{L}\s'-]* - followed by letters, spaces, apostrophes, hyphens
  // \p{L}$ - ends with a letter (no trailing spaces/punctuation)
  // Also check: no digits, no consecutive symbols
  const nameRegex = /^\p{L}+(?:[\p{L}\s'-]*\p{L})?$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject certain symbols (like Æ, etc.) - check for only allowed chars
  // The main regex handles this, but let's also reject edge cases
  // "X Æ A-12" should fail due to digit check and invalid chars
  
  // Also reject multiple consecutive symbols like '-- or '' 
  if (/--|''|\s\s/.test(value)) {
    return false;
  }
  
  // Must have at least 2 characters
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length based on card type
  // Visa: 13, 16 or 19 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/; // 13, 16, or 19 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{13})$/; // 16 digits starting with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  let isValid = false;
  
  if (visaRegex.test(cleaned)) {
    isValid = cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19;
  } else if (mastercardRegex.test(cleaned)) {
    isValid = cleaned.length === 16;
  } else if (amexRegex.test(cleaned)) {
    isValid = cleaned.length === 15;
  }
  
  if (!isValid) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
