/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces sensibly while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing - replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Process by finding sentence boundaries
  // Look for .!? that are followed by space and then lowercase letter
  // But not after abbreviations
  
  // Common abbreviations that don't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'i.e', 'e.g', 'St', 'Ave', 'Blvd', 'Rd'];
  
  // Capitalize first letter of text
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Find all sentence endings and capitalize the next letter
  const result = normalized.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    // Check if this is after an abbreviation
    const beforeMatch = normalized.substring(0, normalized.indexOf(match) + punctuation.length);
    const wordsBefore = beforeMatch.split(/\s+/);
    const lastWord = wordsBefore[wordsBefore.length - 1].replace(/[.!?]/g, '');
    
    // If last word is an abbreviation, don't capitalize
    if (abbreviations.includes(lastWord)) {
      return punctuation + letter;
    }
    
    return punctuation + letter.toUpperCase();
  });
  
  // Ensure single space after sentence punctuation
  return result.replace(/([.!?])\s+/g, '$1 ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches http, https, www, and common TLDs
  // Also excludes trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:[/?][^\s,.!?;:)]*)?(?<![,.!?;:)])(?![,.!?;:])/gi;
  
  const matches = text.match(urlRegex);
  return matches || [];
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * - Always upgrade scheme to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  // We need to be careful about what we match
  
  return text.replace(/(https?:\/\/)(example\.com)(\/[^\s]*)?/gi, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';
    let newHost = host;
    
    // If path exists and starts with /docs/, potentially rewrite host
    if (path && path.startsWith('/docs/')) {
      // Check for exclusion patterns (dynamic content indicators)
      const exclusionPatterns = [
        /\/cgi-bin/,
        /\?|&|=/,  // query strings
        /\.jsp$/,
        /\.php$/,
        /\.asp$/,
        /\.aspx$/,
        /\.do$/,
        /\.cgi$/,
        /\.pl$/,
        /\.py$/
      ];
      
      const shouldExclude = exclusionPatterns.some(pattern => pattern.test(path));
      
      if (!shouldExclude) {
        // Rewrite host for docs paths
        newHost = 'docs.example.com';
      }
    }
    
    return newProtocol + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  // Special check for February and leap years (simplified - accept Feb 29 as valid)
  // Year validation: must be a reasonable year (e.g., 1900-2100)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}
