import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server';

let server: {
  close: () => void;
};

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up the database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start server
  server = await startServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    expect(true).toBe(true);
  });
});
