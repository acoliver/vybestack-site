interface DatabaseLike {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): { run(...params: unknown[]): void; step(): boolean; free(): void; };
  export(): Uint8Array;
  close(): void;
}

declare module 'sql.js' {
  export type Database = DatabaseLike;
  export function initSqlJs(): Promise<{ Database: new (data?: Uint8Array) => Database }>;
  export default function initSqlJs(): Promise<{ Database: new (data?: Uint8Array) => Database }>;
}