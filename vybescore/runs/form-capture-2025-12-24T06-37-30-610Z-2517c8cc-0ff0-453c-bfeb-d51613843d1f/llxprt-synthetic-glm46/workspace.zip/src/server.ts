import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Using dynamic imports for sql.js to avoid TypeScript declaration issues

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization - using interface type to avoid sql.js declaration issues
let db: {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): { run(...params: unknown[]): void; free(): void; };
  export(): Uint8Array;
  close(): void;
} | null = null;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<{
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): { run(...params: unknown[]): void; free(): void; };
  export(): Uint8Array;
  close(): void;
}> {
  const initSqlJs = (await import('sql.js')).default;
  const fs = await import('node:fs');
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  let dbBuffer: Uint8Array;
  if (fs.existsSync(dbPath)) {
    const dbFile = fs.readFileSync(dbPath);
    dbBuffer = new Uint8Array(dbFile);
  } else {
    // Create a new database
    dbBuffer = new Uint8Array(0);
  }
  
  const SQL = await initSqlJs();
  const database = new SQL.Database(dbBuffer);
  
  // Initialize schema if needed
  const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  database.run(schema);
  
  return database;
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  const fs = await import('node:fs');
  const data = (db as { export(): Uint8Array }).export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// Validation functions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateFormData(data: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required field validation
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');
  
  // Email validation (simple regex)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (international format)
  if (data.phone && !/^[+]?[\d\s\-()]+$/.test(data.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s]+$/.test(data.postalCode)) {
    errors.push('Postal code can only contain letters, numbers, and spaces');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
// GET / - Render the contact form
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

// POST /submit - Process form submission
app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    return res.render('form', { 
      errors: validation.errors, 
      values: formData
    });
  }
  
  // Store in database
  try {
    if (db) {
      const stmt = (db as { prepare(sql: string): { run(...params: unknown[]): void; free(): void; } }).prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database to disk
      await saveDatabase();
    }
  } catch (error) {
    console.error('Database error:', error);
    const errors = ['An error occurred while saving your submission. Please try again.'];
    return res.render('form', { 
      errors, 
      values: formData
    });
  }
  
  // Redirect to thank you page with first name
  res.redirect(`/thank-you?name=${encodeURIComponent(formData.firstName)}`);
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req, res) => {
  const firstName = req.query.name as string || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  try {
    db = await initializeDatabase();
    console.log('Database initialized successfully');
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        if (db) {
          (db as { close(): void }).close();
        }
        console.log('Server shutdown complete');
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    if (import.meta.url === `file://${process.argv[1]}`) {
      process.exit(1);
    }
    throw error;
  }
}

export { startServer, app };

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
