import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { startApp, closeApp } from '../../src/app.js';
import { initializeDatabase } from '../../src/database.js';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let server: any;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let app: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  try {
    // Start the app
    app = await startApp();
    // Listen on a random port for testing
    server = app.listen(0);
  } catch (error) {
    console.error('Failed to start test server:', error);
  }
});

afterAll(async () => {
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  }
  closeApp();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/').expect(200);
    const content = response.text;
    // Using a simple check instead of cheerio for now
    expect(content).toContain('<form method="post" action="/submit"');
    expect(content).toContain('id="firstName"');
    expect(content).toContain('id="lastName"');
    expect(content).toContain('id="streetAddress"');
    expect(content).toContain('id="city"');
    expect(content).toContain('id="stateProvince"');
    expect(content).toContain('id="postalCode"');
    expect(content).toContain('id="country"');
    expect(content).toContain('id="email"');
    expect(content).toContain('id="phone"');
    expect(content).toContain('name="firstName"');
    expect(content).toContain('name="lastName"');
    expect(content).toContain('name="streetAddress"');
    expect(content).toContain('name="city"');
    expect(content).toContain('name="stateProvince"');
    expect(content).toContain('name="postalCode"');
    expect(content).toContain('name="country"');
    expect(content).toContain('name="email"');
    expect(content).toContain('name="phone"');
  });

  it('persists submission and redirects', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Reinitialize database
    await initializeDatabase();
    
    // Submit form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '12345',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit the form and check for redirect
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Check if data is valid
    expect(response.status).toBe(302);
    
    // Check redirect location
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    
    // Check thank you page renders
    const thankYouResponse = await request(server)
      .get(response.headers.location)
      .expect(200);
    
    const thankYouContent = thankYouResponse.text;
    expect(thankYouContent).toContain('Thank you, John!');
    expect(thankYouContent).toContain('Thank You!');
    expect(thankYouContent).toContain('Return to the form');
    
    // Check database has the submission
    if (fs.existsSync(dbPath)) {
      const dbPathExists = fs.existsSync(dbPath);
      expect(dbPathExists).toBe(true);
    } else {
      // The database file doesn't exist, which means nothing was saved
      expect(true).toBe(false);
    }
  });
});
