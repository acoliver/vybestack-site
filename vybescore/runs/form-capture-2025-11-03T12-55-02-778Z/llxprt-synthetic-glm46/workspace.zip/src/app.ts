import express, { Request, Response, Express } from 'express';
import path from 'path';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, FormValues } from './validation.js';

const app: Express = express();

// Middleware to serve static files
app.use('/public', express.static('public'));

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));

// Configure EJS
app.set('views', path.join('src', 'templates'));
app.set('view engine', 'ejs');

// Render the form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

// Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  

  // Validate form data
  const errors = validateForm(formData);
  
  // If validation fails, re-render the form with errors and previously entered values
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(error => error.message),
      values: formData
    });
  }

  // If validation passes, save to database
  try {
    insertSubmission(formData);
    
    // Redirect to thank you page with first name as query parameter
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || 'friend')}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      values: formData
    });
  }
});

// Thank you page with query parameter for first name
app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

export async function startApp() {
  try {
    await initializeDatabase();
    console.log('Database initialized');
    return app;
  } catch (error) {
    console.error('Failed to initialize app:', error);
    throw error;
  }
}

export function closeApp() {
  closeDatabase();
}