import { startApp, closeApp } from './app.js';

// Let the app start listening, but first initialize the database
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let server: any;

async function startServer() {
  try {
    const app = await startApp();
    
    const port = parseInt(process.env.PORT || '3000', 10);
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      closeApp();
      console.log('App closed');
      process.exit(0);
    });
  } else {
    closeApp();
    console.log('App closed');
    process.exit(0);
  }
});

// Start the server
startServer();
