import fs from 'fs';
import path from 'path';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import * as sqljsInit from 'sql.js';

// Define a simple SQL.js interface to avoid any type
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let SQL: any;

// Loading sql.js synchronously to avoid type issues
try {
  SQL = sqljsInit.default || sqljsInit;
} catch (e) {
  // if that fails, try require
  // eslint-disable-next-line @typescript-eslint/no-var-requires, @typescript-eslint/no-explicit-any
  SQL = require('sql.js') as any;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
interface Database {
  exec(query: string): void;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  prepare(query: string): any;
  export(): Buffer;
  close(): void;
}

const DB_PATH = path.join('data', 'submissions.sqlite');
let db: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load database file if exists, otherwise create new database
    let fileBuffer;
    if (fs.existsSync(DB_PATH)) {
      fileBuffer = fs.readFileSync(DB_PATH);
    } else {
      fileBuffer = null;
    }

    const sqlite = await SQL();
    db = new sqlite.Database(fileBuffer) as Database;
    
    // Run schema if needed
    if (fileBuffer === null) {
      // Read schema from file
      const schemaPath = path.join('db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema);
    }

    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export function insertSubmission(formData: {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, postal_code, 
        country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName || '',
      formData.lastName || '',
      formData.streetAddress || '',
      formData.city || '',
      formData.stateProvince || '',
      formData.postalCode || '',
      formData.country || '',
      formData.email || '',
      formData.phone || ''
    ]);
    
    stmt.free();
    
    // Save database after insertion
    saveDatabase();
  } catch (error) {
    console.error('Failed to insert submission:', error);
    throw error;
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}