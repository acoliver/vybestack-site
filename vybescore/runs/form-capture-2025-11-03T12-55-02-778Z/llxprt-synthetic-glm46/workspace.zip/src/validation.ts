export interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export function validateForm(values: FormValues): ValidationError[] {
  const errors: ValidationError[] = [];

  // First name validation
  if (!values.firstName || values.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  // Last name validation
  if (!values.lastName || values.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  // Street address validation
  if (!values.streetAddress || values.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  // City validation
  if (!values.city || values.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }

  // State/Province/Region validation
  if (!values.stateProvince || values.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  // Postal code validation (alphanumeric, allow spaces, dashes)
  if (!values.postalCode || values.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(values.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces and dashes' });
  }

  // Country validation
  if (!values.country || values.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  if (!values.email || values.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation (international format)
  if (!values.phone || values.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+]?[(]?[0-9]{1,4}[)]?[-s.]?[(]?[0-9]{1,4}[)]?([-s.]?[0-9]{1,9})+$/.test(values.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}