// Type declarations for sql.js
// This is a simplified declaration for sql.js to fix build errors

declare module 'sql.js' {
  class Database {
    constructor(data?: Buffer);
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Buffer;
    close(): void;
  }
  
  class Statement {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    run(...params: any[]): void;
    free(): void;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    get(...params: any[]): any;
  }
  
  interface SqlJsStatic {
    (): Promise<SqlJsStatic>;
    Database: typeof Database;
  }
  
  const SqlJs: SqlJsStatic;
  
  export default SqlJs;
}