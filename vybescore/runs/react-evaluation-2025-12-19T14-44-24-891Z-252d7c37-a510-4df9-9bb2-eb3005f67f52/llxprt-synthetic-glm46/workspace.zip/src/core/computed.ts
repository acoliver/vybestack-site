/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  computedRegistry,
  registerDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Equality function is accepted for API compatibility but not used in this implementation
  void _equal

  // Create the observer with initial value
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Register this computed value in the global registry to track it
  computedRegistry.set(o as unknown as Observer<unknown>, new Set())

  return (): T => {
    const activeObserver = getActiveObserver()
    
    // If there's an active observer (during tracking), register this computed as a dependency
    if (activeObserver && activeObserver !== o) {
      registerDependency(activeObserver as Observer<unknown>, o as unknown as Observer<unknown>)
    }
    
    // Track dependencies by running the computation each time this getter is called
    // When called within an update context, this will automatically register dependencies
    const previousActiveObserver = getActiveObserver()
    setActiveObserver(o)
    
    try {
      // Always re-evaluate to get current value and track dependencies
      o.value = o.updateFn(o.value)
    } finally {
      setActiveObserver(previousActiveObserver)
    }
    
    return o.value!
  }
}
