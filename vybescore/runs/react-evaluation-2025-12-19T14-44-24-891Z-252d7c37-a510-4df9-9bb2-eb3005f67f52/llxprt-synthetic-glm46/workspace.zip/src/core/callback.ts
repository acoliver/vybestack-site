/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, computedRegistry, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Define wrapped function to handle the callback logic
  const wrappedUpdateFn: UpdateFn<T> = (prev) => {
    if (!disposed) {
      return updateFn(prev)
    }
    return prev as T
  }
  
  // Create a specialized observer for callbacks
  const observer: Observer<T> = {
    value,
    updateFn: wrappedUpdateFn,
  }
  
  // Store all dependencies of this callback to know when to update it
  // Create an empty dependency set in the registry to track this observer
  const observerKey = observer as unknown as Observer<unknown>
  computedRegistry.set(observerKey, new Set())
  
  // Execute the callback function initially to track its dependencies
  // This ensures the callback knows what it depends on
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute the callback to track dependencies
    updateFn(value)
  } finally {
    setActiveObserver(previousObserver)
  }
  
  // Store cleanup function reference
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // Remove from registry to stop receiving updates
    computedRegistry.delete(observerKey)
  }
  
  return unsubscribe
}
