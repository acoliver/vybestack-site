/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerDependency
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function parameter
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }
  
  // Add updateFn to make Subject compatible with updateObserver
  const subjectAsObserver: Observer<T> = {
    name: options?.name,
    observer: undefined,
    value,
    updateFn: () => s.value,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // If the observer is a computed value, register this input as a dependency
      registerDependency(observer as Observer<unknown>, subjectAsObserver as unknown as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has changed using equality function if provided
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    if (s.observer) {
      // Convert ObserverR back to Observer for updateObserver
      const fullObserver = s.observer as Observer<unknown>
      updateObserver(fullObserver)
    }
    
    // Update all computed values and callbacks that depend on this input
    // via the computed registry using the properly typed observer
    updateObserver(subjectAsObserver as unknown as Observer<unknown>)
    
    return s.value
  }

  return [read, write]
}
