/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: ObserverR | undefined
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Global registry to track all computed values and their dependencies
export const computedRegistry = new Map<Observer<unknown>, Set<Observer<unknown>>>()

// Helper to register dependencies for computed values
export function registerDependency(computed: Observer<unknown>, dependency: Observer<unknown>): void {
  if (!computedRegistry.has(computed)) {
    computedRegistry.set(computed, new Set())
  }
  const deps = computedRegistry.get(computed)!
  deps.add(dependency)
}

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // First clear dependencies if this is a computed value
    if (isComputed(observer as Observer<unknown>)) {
      const dependencies = computedRegistry.get(observer as Observer<unknown>)
      if (dependencies) {
        dependencies.clear()
      }
    }
    
    // Update the value by running the update function
    observer.value = observer.updateFn(observer.value)
    
    // For inputs or any observer that changed, find and update all computed values that depend on it
    // We need to handle propagation correctly, including through transitive dependencies
    
    // Collect all direct dependents first
    const directDependents: Observer<unknown>[] = []
    for (const [dependent, dependencies] of computedRegistry.entries()) {
      if (dependencies.has(observer as Observer<unknown>)) {
        directDependents.push(dependent)
      }
    }
    
    // Update all direct dependents, and then handle their dependents
    const visited = new Set<Observer<unknown>>()
    
    // Define update function outside of nested scope to avoid declaration issues
    const updateDependent = (dependent: Observer<unknown>) => {
      if (visited.has(dependent)) return
      visited.add(dependent)
      
      const beforeUpdate = activeObserver
      activeObserver = dependent
      
      try {
        // Clear dependencies for recomputed values
        const currentDeps = computedRegistry.get(dependent)
        if (currentDeps) {
          currentDeps.clear()
        }
        
        // Update the dependent value
        dependent.value = dependent.updateFn(dependent.value)
      } finally {
        activeObserver = beforeUpdate
      }
    }
    
    // Update all direct dependents and their transitive dependents
    for (const dependent of directDependents) {
      updateDependent(dependent)
    }
    
    // Second pass: handle transitive dependencies
    let changed = true
    let iterations = 0
    while (changed && iterations < 10) {
      changed = false
      iterations++
      
      for (const [dependent, dependencies] of computedRegistry.entries()) {
        // Check if this dependent should be updated
        if (!visited.has(dependent)) {
          let shouldUpdate = false
          for (const dependency of dependencies) {
            if (visited.has(dependency)) {
              shouldUpdate = true
              break
            }
          }
          
          if (shouldUpdate) {
            updateDependent(dependent)
            changed = true
          }
        }
      }
    }
    
    // For simple observer relationships (not in registry)
    if (observer.observer) {
      // Check if observer.observer has updateFn before trying to update it
      const obs = observer.observer
      if ('updateFn' in obs && obs.updateFn) {
        const dependentObserver = obs as Observer<unknown>
        updateObserver(dependentObserver)
      }
    }
  } finally {
    activeObserver = previous
  }
}

// Helper function to check if an observer is a computed value
function isComputed(observer: Observer<unknown>): boolean {
  return computedRegistry.has(observer)
}