// Simple test to help debug the callback issue
import { createInput, createComputed, createCallback } from './dist/index.js'

console.log('Testing reactive system...')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0

console.log('input:', input())
console.log('output:', output())

createCallback(() => {
  console.log('Callback triggered - input:', input(), 'output:', output())
  value = output()
})

console.log('After callback setup - value:', value)

setInput(3)

console.log('After setInput - input:', input(), 'output:', output(), 'value:', value)