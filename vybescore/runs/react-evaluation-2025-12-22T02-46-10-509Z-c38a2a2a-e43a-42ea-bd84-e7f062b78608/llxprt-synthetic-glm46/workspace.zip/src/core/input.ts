/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  trackDependency,
  notifyDependents,
  subjectAsObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (equal === false || equal === undefined) {
    equalFn = () => false
  } else {
    equalFn = equal as EqualFn<T>
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track that the active observer depends on this input
      trackDependency(observer, subjectAsObserver(s))
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all observers that depend on this input
      notifyDependents(subjectAsObserver(s))
    }
    return s.value
  }

  return [read, write]
}
