/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  trackDependency,
  EqualFn
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Don't initialize the computed value during creation
  // We'll compute it on first access
  
  // Create a getter function that tracks dependencies and computes value
  const getter = (): T => {
    const previous = getActiveObserver()
    if (previous && previous !== o) {
      // Track that the previous observer depends on this computed value
      trackDependency(previous, o)
    }
    
    // Compute when needed to get fresh values from dependencies
    // For computed with default value only (no dependencies),
    // this will be called once, get the value, and then cache it
    if (previous === o) {
      return o.value!
    }
    
    // When accessed from a tracked context and value exists, return cached value
    // Avoid infinite recursion when computed values depend on each other
    if (previous !== undefined && o.value !== undefined) {
      return o.value
    }
    
// Direct access, compute and return
    updateObserver(o)
    
    return o.value!
  }
  
  return getter
}
