/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & { _unsubscribed?: boolean }

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Global registry to track observers and their dependencies
export const observerDependencies = new Map<ObserverR, ObserverR[]>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // For computed values, pass the old value as the argument
    // For computed with default value, this will be undefined initially
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Only notify dependents for computed values or inputs, not for callbacks
  // Callbacks should not trigger further notifications
  if (observer.name !== 'callback') {
    // Notify all observers that depend on this observer
    notifyDependents(observer)
  }
}

// Track dependencies between observers
export function trackDependency(observer: ObserverR, dependency: ObserverR): void {
  if (!observerDependencies.has(observer)) {
    observerDependencies.set(observer, [])
  }
  const deps = observerDependencies.get(observer)!
  if (!deps.includes(dependency)) {
    deps.push(dependency)
  }
}

// Notify all observers that depend on a given observer
export function notifyDependents(changedObserver: ObserverR): void {
  // Create a static copy to avoid modification during iteration
  const entries = Array.from(observerDependencies.entries())
  
  for (const [observer, dependencies] of entries) {
    if (dependencies.includes(changedObserver)) {
      const obs = observer as Observer<unknown>
      // Skip notifying observers that have been unsubscribed
      if (!(obs as any)._unsubscribed) {
        updateObserver(obs)
      }
    }
  }
}

// Cast function to allow treating Subject as ObserverR for notification purposes
export function subjectAsObserver<T>(subject: Subject<T>): ObserverR {
  return subject as unknown as ObserverR
}
