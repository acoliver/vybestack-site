// Simple test of computed with default values
import { createComputed } from './src/index'

console.log('=== Create computed test ===')
const computed = createComputed((x: number = 3) => {
  console.log('Computed function called with x =', x)
  const result = x * 2  
  console.log('Computed result =', result)
  return result
})

console.log('First call computed():')
const result1 = computed()
console.log('Result1 =', result1)

console.log('Second call computed():')
const result2 = computed()
console.log('Result2 =', result2)