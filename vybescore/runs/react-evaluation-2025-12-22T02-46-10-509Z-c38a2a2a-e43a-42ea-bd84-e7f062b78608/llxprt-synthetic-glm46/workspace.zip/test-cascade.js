// Test cascade notifications
function testCascadingNotifications() {
  var observerDependencies = new Map();
  
  function trackDependency(observer, dependency) {
    if (!observerDependencies.has(observer)) {
      observerDependencies.set(observer, []);
    }
    const deps = observerDependencies.get(observer);
    if (!deps.includes(dependency)) {
      deps.push(dependency);
    }
  }
  
  function updateObserver(observer) {
    console.log(`Updating ${observer.name || 'unnamed observer'}`);
    observer.updateFn(observer.value);
    
    // After updating, cascade to dependents
    notifyDependents(observer);
  }
  
  function notifyDependents(changedObserver) {
    const entries = Array.from(observerDependencies.entries());
    console.log(`Notifying dependents of ${changedObserver.name || 'unnamed observer'}`);
    
    for (const [observer, dependencies] of entries) {
      if (dependencies.includes(changedObserver)) {
        updateObserver(observer);
      }
    }
  }
  
  // Setup
  let input = 11;
  const inputSubject = { 
    name: 'inputSubject',
    value: input 
  };
  
  const output = {
    name: 'computedOutput',
    updateFn: () => inputSubject.value + 1,
    value: undefined
  };
  
  // Initialize computed
  output.value = output.updateFn();
  console.log(`Initial output: ${output.value}`);
  
  var values1 = [];
  var values2 = [];
  
  const callback1 = {
    name: 'callback1',
    value: undefined,
    updateFn: () => { 
      const val = output.value;
      values1.push(val); 
      console.log(`callback1 executed with value ${val}`);
    }
  };
  
  const callback2 = {
    name: 'callback2',
    value: undefined,
    updateFn: () => { 
      const val = output.value;
      values2.push(val); 
      console.log(`callback2 executed with value ${val}`);
    }
  };
  
  // Track dependencies
  trackDependency(output, inputSubject);
  trackDependency(callback1, output);
  trackDependency(callback2, output);
  console.log(`Dependencies tracked`);
  
  // Initial execution
  updateObserver(callback1);
  updateObserver(callback2);
  console.log(`After setup - values1: [${values1}], values2: [${values2}]`);
  
  // Input change - should cascade through output to callbacks
  console.log(`\nChanging input to 31`);
  inputSubject.value = 31;
  
  // Update output, which should cascade
  output.value = output.updateFn();
  console.log(`Output updated to ${output.value}`);
  notifyDependents(inputSubject);
  
  console.log(`After first change - values1: [${values1}], values2: [${values2}]`);
  
  // Unsubscribe callback1
  console.log(`\nUnsubscribing callback1`);
  callback1.updateFn = () => {};
  observerDependencies.delete(callback1);
  
  // Input change again
  console.log(`\nChanging input to 41`);
  inputSubject.value = 41;
  output.value = output.updateFn();
  console.log(`Output updated to ${output.value}`);
  notifyDependents(inputSubject);
  
  console.log(`After second change - values1: [${values1}], values2: [${values2}]`);
  console.log(`Final values1 length: ${values1.length}, values2 length: ${values2.length}`);
  console.log(`Expected: values1 length 2, values2 length 3`);
}

testCascadingNotifications();