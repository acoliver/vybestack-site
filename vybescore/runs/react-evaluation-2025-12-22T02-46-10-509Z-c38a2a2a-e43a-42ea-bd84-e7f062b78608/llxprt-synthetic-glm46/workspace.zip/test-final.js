// Final test to replicate the actual test behavior

function testFinal() {
  var observerDependencies = new Map();
  
  function trackDependency(observer, dependency) {
    if (!observerDependencies.has(observer)) {
      observerDependencies.set(observer, []);
    }
    const deps = observerDependencies.get(observer);
    if (!deps.includes(dependency)) {
      deps.push(dependency);
    }
  }
  
  function updateObserver(observer) {
    observer.updateFn(observer.value);
    
    // Check if we should cascade
    if (observer.name !== 'callback') {
      notifyDependents(observer);
    }
  }
  
  function notifyDependents(changedObserver) {
    const entries = Array.from(observerDependencies.entries());
    
    for (const [observer, dependencies] of entries) {
      if (dependencies.includes(changedObserver)) {
        updateObserver(observer);
      }
    }
  }
  
  // Setup objects like our real implementation
  let inputValue = 11;
  const inputSubject = { 
    name: 'inputSubject',
    value: inputValue 
  };
  
  // Create read and write like createInput
  const read = () => {
    console.log(`Input read: ${inputSubject.value}`);
    return inputSubject.value;
  };
  
  const write = (nextValue) => {
    if (inputSubject.value !== nextValue) {
      inputSubject.value = nextValue;
      notifyDependents(inputSubject);
    }
    return inputSubject.value;
  };
  
  // Create computed like createComputed
  const output = {
    name: 'computed',
    value: undefined,
    updateFn: () => {
      console.log(`Output updateFn called`);
      return read() + 1;
    },
  };
  
  // Initialize computed
  output.value = output.updateFn();
  console.log(`Initial output value: ${output.value}`);
  
  // Create a getter
  const getOutput = () => {
    const previous = undefined; // No active observer in test
    
    if (previous !== output && (previous === undefined || output.value === undefined)) {
      output.value = output.updateFn();
    }
    
    return output.value;
  };
  
  // Create callbacks like createCallback
  var values1 = [];
  var values2 = [];
  
  const callback1 = {
    name: 'callback',
    value: undefined,
    updateFn: () => { 
      console.log(`Callback1 executing`);
      values1.push(getOutput()); 
    }
  };
  
  const callback2 = {
    name: 'callback',
    value: undefined,
    updateFn: () => { 
      console.log(`Callback2 executing`);
      values2.push(getOutput()); 
    }
  };
  
  // Track dependencies
  trackDependency(output, inputSubject);
  trackDependency(callback1, inputSubject); // Directly depends on input for proper notification
  trackDependency(callback2, inputSubject);
  
  console.log(`Dependencies tracked`);
  
  // Initial execution
  updateObserver(callback1);
  updateObserver(callback2);
  console.log(`After setup - values1: [${values1}], values2: [${values2}]`);
  
  // First change
  console.log(`\nCalling setInput(31)`);
  write(31);
  console.log(`After first change - values1: [${values1}], values2: [${values2}]`);
  
  // Unsubscribe
  console.log(`\nUnsubscribing callback1`);
  callback1.updateFn = () => {};
  observerDependencies.delete(callback1);
  
  // Second change
  console.log(`\nCalling setInput(41)`);
  write(41);
  console.log(`After second change - values1: [${values1}], values2: [${values2}]`);
  
  console.log(`\nFinal - values1 length: ${values1.length}, values2 length: ${values2.length}`);
  console.log(`Expected: values1 length 2, values2 length 3`);
}

testFinal();