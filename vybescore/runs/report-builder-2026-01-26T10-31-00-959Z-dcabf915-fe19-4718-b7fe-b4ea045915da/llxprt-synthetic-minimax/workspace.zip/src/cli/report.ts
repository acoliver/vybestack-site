#!/usr/bin/env node

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): CLIOptions {
  const args = argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputPath = args[0];
  const formatIndex = args.findIndex(arg => arg === '--format');
  
  if (formatIndex === -1 || !args[formatIndex + 1]) {
    console.error('Error: --format option is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }

  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && args[outputIndex + 1] ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    inputPath,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i] as Record<string, unknown>;
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }

  return true;
}

function loadReportData(inputPath: string): ReportData {
  if (!existsSync(inputPath)) {
    throw new Error(`Input file not found: ${inputPath}`);
  }

  let content: string;
  try {
    content = readFileSync(inputPath, 'utf8');
  } catch {
    throw new Error(`Failed to read input file: ${inputPath}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch {
    throw new Error('Invalid JSON: malformed JSON syntax');
  }

  validateReportData(data);

  return data as ReportData;
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  if (format === 'markdown') {
    return renderMarkdown(data, includeTotals);
  } else {
    return renderText(data, includeTotals);
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    const data = loadReportData(options.inputPath);
    const output = renderReport(data, options.format, options.includeTotals);

    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf8');
    } else {
      process.stdout.write(output);
    }
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
