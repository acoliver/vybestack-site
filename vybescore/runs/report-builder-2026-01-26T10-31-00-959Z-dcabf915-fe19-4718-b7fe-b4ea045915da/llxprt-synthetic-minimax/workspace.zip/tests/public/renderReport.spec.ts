import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { execSync } from 'node:child_process';

describe('report CLI (public smoke)', () => {
  const fixturesDir = join(process.cwd(), 'fixtures');
  const dataPath = join(fixturesDir, 'data.json');

  it('should render markdown format with totals', () => {
    const data = readFileSync(dataPath, 'utf8');
    const result = execSync(
      `node dist/cli/report.js fixtures/data.json --format markdown --includeTotals`,
      { encoding: 'utf8', cwd: process.cwd() }
    );

    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('**Total:** $70370.34');
  });

  it('should render markdown format without totals', () => {
    const result = execSync(
      `node dist/cli/report.js fixtures/data.json --format markdown`,
      { encoding: 'utf8', cwd: process.cwd() }
    );

    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).not.toContain('**Total:**');
  });

  it('should render text format without totals', () => {
    const result = execSync(
      `node dist/cli/report.js fixtures/data.json --format text`,
      { encoding: 'utf8', cwd: process.cwd() }
    );

    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).not.toContain('Total:');
  });

  it('should render text format with totals', () => {
    const result = execSync(
      `node dist/cli/report.js fixtures/data.json --format text --includeTotals`,
      { encoding: 'utf8', cwd: process.cwd() }
    );

    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('Total: $70370.34');
  });

  it('should reject unsupported format', () => {
    expect(() => {
      execSync(
        `node dist/cli/report.js fixtures/data.json --format invalid`,
        { encoding: 'utf8', cwd: process.cwd() }
      );
    }).toThrow();
  });

  it('should handle malformed JSON', () => {
    const tempFile = '/tmp/test-bad.json';
    require('node:fs').writeFileSync(tempFile, '{"invalid": "json"}');

    expect(() => {
      execSync(
        `node dist/cli/report.js ${tempFile} --format markdown`,
        { encoding: 'utf8', cwd: process.cwd() }
      );
    }).toThrow();

    require('node:fs').unlinkSync(tempFile);
  });

  it('should handle JSON syntax errors', () => {
    const tempFile = '/tmp/test-syntax.json';
    require('node:fs').writeFileSync(tempFile, 'not valid json');

    expect(() => {
      execSync(
        `node dist/cli/report.js ${tempFile} --format markdown`,
        { encoding: 'utf8', cwd: process.cwd() }
      );
    }).toThrow();

    require('node:fs').unlinkSync(tempFile);
  });

  it('should write to file when --output is specified', () => {
    const outputFile = '/tmp/test-output.txt';
    
    execSync(
      `node dist/cli/report.js fixtures/data.json --format markdown --output ${outputFile}`,
      { encoding: 'utf8', cwd: process.cwd() }
    );

    const content = require('node:fs').readFileSync(outputFile, 'utf8');
    expect(content).toContain('# Quarterly Financial Summary');
    expect(content).toContain('## Entries');

    require('node:fs').unlinkSync(outputFile);
  });
});
