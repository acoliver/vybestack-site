/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverBase = {
  name?: string
  dependencies?: Set<ObserverBase>
  dependents?: Set<Observer<any>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverBase & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverBase | undefined
  dependents?: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & ObserverV<T> & ObserverBase

let activeObserver: ObserverBase | undefined

export function getActiveObserver(): ObserverBase | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  
  const previous = activeObserver
  
  // Set this observer as active to track dependencies
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    // Only update if value changed (if we have a comparison function)
    if (newValue !== observer.value) {
      observer.value = newValue
    }
  } finally {
    activeObserver = previous
  }
  
  // Notify all dependents that a dependency has changed
  if (observer.dependents) {
    observer.dependents.forEach(dependent => {
      updateObserver(dependent as Observer<any>)
    })
  }
}
  
  // Notify all dependents that a dependency has changed
  if (observer.dependents) {
    observer.dependents.forEach(dependent => {
      updateObserver(dependent as Observer<any>)
    })
  }
}

export function addDependency(dependent: ObserverBase, dependency: ObserverBase): void {
  if (!dependency.dependents) {
    dependency.dependents = new Set()
  }
  dependency.dependents.add(dependent as Observer<any>)
}

export function defaultEqual<T>(a: T, b: T): boolean {
  return a === b
}
}