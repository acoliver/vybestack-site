/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addDependency,
  getActiveObserver,
  EqualFn,
  defaultEqual
} from '../types/reactive'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal) {
    equalFn = defaultEqual
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    dependencies: new Set(),
    dependents: new Set(),
    updateFn,
  }
  updateObserver(o)
  
  // Return getter that tracks dependencies
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this computed observer as a dependency to the current observer
      if (observer.dependencies) {
        observer.dependencies.add(o)
      } else {
        observer.dependencies = new Set([o])
      }
      
      // Add the current observer as a dependent to this computed observer
      addDependency(observer, o)
    }
    return o.value!
  }
}
