/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  defaultEqual
} from '../types/reactive'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : (equal ? defaultEqual : undefined),
    updateFn: (val: T | undefined) => val || value,
    dependents: new Set(),
    dependencies: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // Add this subject as a dependency to the current observer
      if (observer.dependencies) {
        observer.dependencies.add(s)
      } else {
        observer.dependencies = new Set([s])
      }
      
      // Add the current observer as a dependent to this subject
      addDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value has actually changed
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all dependents that this value has changed
    if (s.dependents) {
      s.dependents.forEach(dependent => {
        updateObserver(dependent as Observer<unknown>)
      })
    }
    
    return s.value
  }

  return [read, write]
}
