#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { createWriteStream } from 'node:fs';
import type { ReportData, ReportOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const FORMATTERS = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

function parseCliArgs(args: string[]): {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: Format | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }

      if (nextArg !== 'markdown' && nextArg !== 'text') {
        console.error(`Error: Unsupported format "${nextArg}"`);
        process.exit(1);
      }

      format = nextArg;
      i++;
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }

      outputPath = nextArg;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function parseReportData(dataContent: string): ReportData {
  try {
    const data = JSON.parse(dataContent) as unknown;

    // Basic validation
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected object');
    }

    const reportData = data as Record<string, unknown>;

    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid "title"');
    }

    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid "summary"');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid "entries" array');
    }

    // Validate entries
    const entries = [];
    for (const [index, entry] of reportData.entries.entries()) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid entry at index ${index}: expected object`);
      }

      const entryObj = entry as Record<string, unknown>;

      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid "label"`);
      }

      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid "amount"`);
      }

      entries.push({
        label: entryObj.label,
        amount: entryObj.amount,
      });
    }

    return {
      title: reportData.title,
      summary: reportData.summary,
      entries,
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error parsing data');
    }
    process.exit(1);
  }
}

function main(): void {
  const args = process.argv.slice(2);
  const { dataFile, format, outputPath, includeTotals } = parseCliArgs(args);

  // Read and parse data file
  let dataContent: string;
  try {
    dataContent = readFileSync(dataFile, 'utf8');
  } catch (error) {
    console.error(`Error reading file "${dataFile}": ${(error as Error).message}`);
    process.exit(1);
  }

  const reportData = parseReportData(dataContent);
  const options: ReportOptions = { includeTotals };

  // Render report
  const formatter = FORMATTERS[format];
  const reportContent = formatter.render(reportData, options);

  // Write output
  if (outputPath) {
    try {
      const stream = createWriteStream(outputPath, { encoding: 'utf8' });
      stream.write(reportContent);
      stream.end();
    } catch (error) {
      console.error(`Error writing to file "${outputPath}": ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(reportContent);
  }
}

main();
