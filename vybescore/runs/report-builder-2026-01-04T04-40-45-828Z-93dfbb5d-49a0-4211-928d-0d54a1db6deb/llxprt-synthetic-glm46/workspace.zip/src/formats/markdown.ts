/**
 * Markdown format renderer
 */

import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export const renderMarkdown: ReportRenderer = {
  render(data: ReportData, options: ReportOptions): string {
    const lines = [];

    // Add title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Add summary
    lines.push(data.summary);
    lines.push('');
    
    // Add entries
    lines.push('## Entries');
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }
    
    // Add total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(``);
      lines.push(`**Total:** ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
};