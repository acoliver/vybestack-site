const PADDING_REGEX = /=+$/;
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  // Use standard base64 encoding (not base64url) to get '+' and '/' characters
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that a string is valid Base64.
 * Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, with optional = padding
 */
function isValidBase64(input: string): boolean {
  // Remove padding for validation
  const unpadded = input.replace(PADDING_REGEX, '');
  
  // Empty string after removing padding is invalid
  if (unpadded.length === 0) {
    return false;
  }
  
  // Check that all characters are valid Base64 characters
  // Valid pattern: only A-Z, a-z, 0-9, +, / allowed, with 0-2 = at the end
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Pattern.test(input)) {
    return false;
  }
  
  // Check that padding is only at the end and length is correct
  // Base64 encoded length should be a multiple of 4 (with padding)
  const paddedLength = Math.ceil(unpadded.length / 4) * 4;
  return input.length === unpadded.length || input.length === paddedLength;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate the input first
  if (!isValidBase64(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  // Use standard base64 decoding
  const buffer = Buffer.from(input, 'base64');
  
  // Check if decoding succeeded (Node's Buffer.from doesn't always throw)
  // If the input contains invalid characters, the result will be empty or incorrect
  const decoded = buffer.toString('utf8');
  
  // Verify by re-encoding and comparing (normalized for padding)
  // This catches cases where Node.js silently ignores invalid characters
  const normalizedInput = input.replace(PADDING_REGEX, '');
  const normalizedExpected = buffer.toString('base64').replace(PADDING_REGEX, '');
  
  if (normalizedInput !== normalizedExpected) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  return decoded;
}
