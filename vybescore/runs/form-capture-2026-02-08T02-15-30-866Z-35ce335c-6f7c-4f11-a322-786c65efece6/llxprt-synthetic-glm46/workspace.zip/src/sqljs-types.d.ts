declare module 'sql.js' {
  interface Statement {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(): unknown[];
    free(): void;
  }
  
  interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  function initSqlJs(config?: unknown): Promise<{ Database: new (data?: Uint8Array) => Database }>;
  
  export default initSqlJs;
  export { Database, Statement };
}