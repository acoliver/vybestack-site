import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
/// <reference path="./sqljs-types.d.ts" />
/// <reference path="./sqljs-types.d.ts" />
import initSqlJs from 'sql.js';
import { Database } from 'sql.js';

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

async function initializeDatabase(): Promise<Database> {
  const dbPath = path.resolve('data', 'submissions.sqlite');
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Load or initialize SQLite database
  let db: Database;
  if (fs.existsSync(dbPath)) {
    const dbFile = fs.readFileSync(dbPath);
    const SQL = await initSqlJs();
    const { Database } = SQL;
    db = new Database(dbFile);
  } else {
    const SQL = await initSqlJs();
    const { Database } = SQL;
    db = new Database();
    const schemaPath = path.resolve('db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
  }
  
  return db;
}

function validateForm(values: Partial<FormSubmission>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!values.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!values.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!values.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!values.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!values.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }
  
  if (!values.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!/^[A-Za-z0-9\s-]+$/.test(values.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code contains invalid characters' });
  }
  
  if (!values.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!values.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.push({ field: 'email', message: 'Email address is invalid' });
  }
  
  if (!values.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[\d\s()()-]+$/.test(values.phone)) {
    errors.push({ field: 'phone', message: 'Phone number contains invalid characters' });
  }
  
  return errors;
}

async function saveSubmission(db: Database, submission: FormSubmission): Promise<void> {
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone
  ]);
  
  stmt.free();
}

function saveDatabase(db: Database): void {
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

async function createServer(): Promise<express.Express> {
  const app = express();
  let db: Database;
  
  // Initialize database
  try {
    db = await initializeDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use('/public', express.static(path.resolve('public')));
  
  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve('src', 'templates'));
  
  // Routes
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {}
    });
  });
  
  app.post('/submit', async (req, res) => {
    const values: Partial<FormSubmission> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };
    
    const errors = validateForm(values);
    
    if (errors.length > 0) {
      res.status(400).render('form', {
        errors: errors.map(e => e.message),
        values
      });
      return;
    }
    
    try {
      // Cast to FormSubmission since validation passed
      await saveSubmission(db, values as FormSubmission);
      saveDatabase(db);
      
      // Redirect to thank you page with first name for personalization
      res.redirect(302, `/thank-you?name=${encodeURIComponent(values.firstName!)}`);
    } catch (error) {
      console.error('Failed to save submission:', error);
      res.status(500).render('form', {
        errors: ['An unexpected error occurred. Please try again.'],
        values
      });
    }
  });
  
  app.get('/thank-you', (req, res) => {
    // Extract first name from query parameter or fallback to "friend"
    const firstName = req.query.name ? String(req.query.name) : 'friend';
    
    res.render('thank-you', { firstName });
  });
  
  // Graceful shutdown handling
  const gracefulShutdown = (): void => {
    console.log('Shutting down gracefully...');
    if (db) {
      saveDatabase(db);
      db.close();
    }
    process.exit(0);
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  return app;
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  createServer()
    .then(app => {
      const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
      const server = app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });
      
      return server;
    })
    .catch(err => {
      console.error('Failed to start server:', err);
      process.exit(1);
    });
}

export default createServer;
