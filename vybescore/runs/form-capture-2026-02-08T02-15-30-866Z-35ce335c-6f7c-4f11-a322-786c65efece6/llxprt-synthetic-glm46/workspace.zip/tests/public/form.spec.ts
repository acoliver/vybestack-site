import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import createServer from '../../src/server.js';
import express from 'express';

let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await createServer();
  server = (app as express.Express).listen(0); // 0 -> assign random port
});

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server) {
    (server as { close: () => void }).close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app as string)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app as string)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'California',
        postalCode: '90210',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555 1234567'
      })
      .expect(302);
    
    expect(response.headers.location).toMatch(/^\/thank-you\?name=/);
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
