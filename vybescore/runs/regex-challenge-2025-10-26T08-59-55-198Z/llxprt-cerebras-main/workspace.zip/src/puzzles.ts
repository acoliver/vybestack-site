/**
 * Finds words in text that start with a given prefix but are not in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to match words starting with the prefix
  // Using word boundaries to match complete words only
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex pattern with:
  // - Positive lookbehind for a digit
  // - The token
  // - Negative lookahead for start of string (^ would not work in lookbehind, so we check position)
  // Using a more compatible approach without lookbehind since it might not be supported in all environments
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates passwords according to a strict policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase, lowercase, digit, and symbol
  if (!/[A-Z]/.test(value) || 
      !/[a-z]/.test(value) || 
      !/\d/.test(value) || 
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This regex looks for any sequence of 2 or more characters that repeats immediately
  if (/(\w{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles various formats including ::
  // This pattern detects IPv6 addresses with different formats
  // Covers full addresses, compressed addresses with ::, and mixed formats
  const ipv6Regex = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:)/;
  
  // IPv4 regex for exclusion
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // Check if it matches IPv6 but not IPv4
  return ipv6Regex.test(value) && !ipv4Regex.test(value);
}