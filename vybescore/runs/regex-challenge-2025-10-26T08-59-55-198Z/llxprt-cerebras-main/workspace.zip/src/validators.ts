export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses following standard conventions.
 * Accepts addresses like 'name+tag@example.co.uk'
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  value = value.trim();
  
  // Email validation regex:
  // - Local part (before @): alphanumeric, dots, hyphens, plus signs
  // - No double dots, no leading/trailing dots
  // - Domain part: alphanumeric, dots, hyphens (no underscores)
  // - TLD must exist and be at least 2 chars
  const emailRegex = /^[a-zA-Z0-9]+([._-][a-zA-Z0-9]+)*(\+[a-zA-Z0-9._-]+)?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.([a-zA-Z0-9]{2,})$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks:
  // - No double dots
  // - No trailing dot in local part
  // - No underscores in domain part
  const [localPart, domainPart] = value.split('@');
  
  if (localPart.includes('..') || localPart.endsWith('.')) {
    return false;
  }
  
  if (domainPart.includes('_') || domainPart.includes('..') || domainPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with flexible formatting.
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // If starts with +1, remove it for validation
  let phoneNumber = digits;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize the input by removing all spaces, hyphens and parentheses
  const normalized = value.replace(/[\s()-]/g, '');
  
  // Check if it has a country code (+54) or trunk prefix (0)
  let phoneNumber = normalized;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  if (phoneNumber.startsWith('+54')) {
    phoneNumber = phoneNumber.substring(3);
    hasCountryCode = true;
  }
  
  if (phoneNumber.startsWith('0')) {
    hasTrunkPrefix = true;
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check for mobile indicator '9'
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Validate area code (2-4 digits, starting with 1-9)
  const areaCodeMatch = phoneNumber.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const remaining = phoneNumber.substring(areaCode.length);
  
  // Validate subscriber number (6-8 digits total)
  if (remaining.length < 6 || remaining.length > 8 || !/^\d+$/.test(remaining)) {
    return false;
  }
  
  // When country code is omitted, must start with trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and names with patterns like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Check that value is not empty
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u017F]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and other symbols
  return /^[a-zA-Z\u00C0-\u017F\s'-]+$/.test(value) && 
         !/\d/.test(value) && 
         !value.includes('X Æ A-12');
}

/**
 * Helper function to run the Luhn algorithm check
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers based on prefix, length and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Check format with regex patterns:
  // Visa: starts with 4, 16 digits
  // Mastercard: starts with 5[1-5], 16 digits
  // American Express: starts with 3[47], 15 digits
  const visaRegex = /^4\d{15}$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type
  const isValidFormat = visaRegex.test(cardNumber) || 
                        mastercardRegex.test(cardNumber) || 
                        amexRegex.test(cardNumber);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cardNumber);
}