/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces between sentences
  // This regex handles multiple spaces, newlines, etc. between sentences
  let normalized = text.replace(/([.?!])\s+([a-zA-Z])/g, '$1 $2');
  
  // Then capitalize first letter of each sentence
  // This regex finds the first letter after sentence ending punctuation or at the beginning
  normalized = normalized.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  // Trim any leading/trailing whitespace
  return normalized.trim();
}

/**
 * Extracts all URLs from text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https URLs
  // Excludes trailing punctuation like .,!,?,;,:),}
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?[^\s.]*)?(?:#[^\s.]*)?)?/g;
  const matches = text.match(urlRegex);
  
  // Return empty array if no matches
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.!?;:)}\]]+$/, ''));
}

/**
 * Forces all http URLs to https while preserving already secure URLs.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://, but not those already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs to use https and docs.example.com when appropriate.
 * For URLs like http://example.com/docs/..., upgrades to https://docs.example.com/...
 * unless path contains dynamic indicators.
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match http URLs with docs paths, excluding those with dynamic elements
  // Preserve the full match including /docs part
  const docsUrlRegex = /http:\/\/([a-zA-Z0-9.-]+)(\/docs\/[a-zA-Z0-9/_-]*)/g;
  
  // Dynamic path indicators that prevent host rewrite
  const dynamicIndicators = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
  
  return text.replace(docsUrlRegex, (match, host, path) => {
    // Check if path contains any dynamic indicators
    const hasDynamicElements = dynamicIndicators.some(indicator => 
      path.includes(indicator) || match.includes(indicator)
    );
    
    if (hasDynamicElements) {
      // Just upgrade to https, keep the original host
      return `https://${host}${path}`;
    } else {
      // Upgrade to https and rewrite host to docs.HOST
      return `https://docs.${host}${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}