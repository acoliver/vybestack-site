import { describe, expect, it, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

afterAll(() => {
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('should have required files', () => {
    // Check that required files exist
    expect(fs.existsSync('src/server.ts')).toBe(true);
    expect(fs.existsSync('src/templates/form.ejs')).toBe(true);
    expect(fs.existsSync('src/templates/thank-you.ejs')).toBe(true);
    expect(fs.existsSync('public/styles.css')).toBe(true);
    expect(fs.existsSync('db/schema.sql')).toBe(true);
  });

  it('should have valid CSS content', () => {
    const cssContent = fs.readFileSync('public/styles.css', 'utf8');
    expect(cssContent.length).toBeGreaterThan(100);
    expect(cssContent).toContain('.form-shell');
    expect(cssContent).toContain('.submit-btn');
    expect(cssContent).toContain('.thank-you-container');
  });

  it('should have valid form template', () => {
    const formTemplate = fs.readFileSync('src/templates/form.ejs', 'utf8');
    expect(formTemplate).toContain('firstName');
    expect(formTemplate).toContain('lastName');
    expect(formTemplate).toContain('email');
    expect(formTemplate).toContain('phone');
    expect(formTemplate).toContain('country');
    expect(formTemplate).toContain('action="/submit"');
  });

  it('should have valid thank-you template', () => {
    const thankYouTemplate = fs.readFileSync('src/templates/thank-you.ejs', 'utf8');
    expect(thankYouTemplate).toContain('Thank You');
    expect(thankYouTemplate).toContain('warning');
    expect(thankYouTemplate).toContain('href="/"');
  });

  it('should have database schema', () => {
    const schema = fs.readFileSync('db/schema.sql', 'utf8');
    expect(schema).toContain('submissions');
    expect(schema).toContain('first_name');
    expect(schema).toContain('email');
    expect(schema).toContain('phone');
  });
});

describe('form validation logic', () => {
  it('should validate email format', () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test('test@example.com')).toBe(true);
    expect(emailRegex.test('invalid-email')).toBe(false);
    expect(emailRegex.test('test@')).toBe(false);
  });

  it('should validate phone format', () => {
    const phoneRegex = /^[0-9\s\-+()]+$/;
    expect(phoneRegex.test('+44 20 7946 0958')).toBe(true);
    expect(phoneRegex.test('+54 9 11 1234-5678')).toBe(true);
    expect(phoneRegex.test('invalid-phone')).toBe(false);
  });

  it('should validate postal code format', () => {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    expect(postalRegex.test('SW1A 1AA')).toBe(true);
    expect(postalRegex.test('10001')).toBe(true);
    expect(postalRegex.test('C1000')).toBe(true);
    expect(postalRegex.test('B1675')).toBe(true);
    expect(postalRegex.test('invalid@postal')).toBe(false);
  });
});
