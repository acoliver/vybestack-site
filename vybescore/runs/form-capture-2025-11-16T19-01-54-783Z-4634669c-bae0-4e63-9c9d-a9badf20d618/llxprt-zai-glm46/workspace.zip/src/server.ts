import express, { Express } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  [key: string]: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private server: ReturnType<Express['listen']> | undefined;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, '..', 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });

      let dbBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const fileContent = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(fileContent);
      }

      this.db = new SQL.Database(dbBuffer);

      const schema = fs.readFileSync(
        path.join(__dirname, '..', 'db', 'schema.sql'), 
        'utf8'
      );
      this.db.run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.dbPath, buffer);
      console.log('Database saved to', this.dbPath);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateFormData(formData: FormData): ValidationError {
    const errors: ValidationError = {};

    if (!formData.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!formData.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!formData.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!formData.city?.trim()) {
      errors.city = 'City is required';
    }

    if (!formData.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }

    if (!formData.postalCode?.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
      errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and hyphens';
    }

    if (!formData.country?.trim()) {
      errors.country = 'Country is required';
    }

    if (!formData.email?.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!formData.phone?.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!/^[0-9\s\-+()]+$/.test(formData.phone)) {
      errors.phone = 'Phone number can only contain digits, spaces, dashes, parentheses, and a leading +';
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', {
        formData: null,
        errors: null
      });
    });

    this.app.post('/submit', (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateFormData(formData);

      if (Object.keys(errors).length > 0) {
        return res.status(400).render('form', {
          formData,
          errors
        });
      }

      try {
        if (this.db) {
          this.db.run(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);

          this.saveDatabase();
        }

        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error saving submission:', error);
        res.status(500).render('form', {
          formData,
          errors: { general: 'An error occurred while saving your submission. Please try again.' }
        });
      }
    });

    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });
  }

  public async start(): Promise<void> {
    try {
      await this.initializeDatabase();
      
      const port = process.env.PORT || 3535;
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      process.on('SIGTERM', () => this.gracefulShutdown());
      process.on('SIGINT', () => this.gracefulShutdown());
      
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private gracefulShutdown(): void {
    console.log('Shutting down gracefully...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('HTTP server closed');
      });
    }

    if (this.db) {
      this.db.close();
      console.log('Database connection closed');
    }

    process.exit(0);
  }
}

const app = new FormCaptureApp();
app.start().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
