export interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function validateFormData(data: FormData): ValidationResult {
  const errors: { [key: string]: string } = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province_region',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field]?.trim();
    if (!value) {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  });

  // Email validation (simple but effective regex)
  if (data.email && data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (international format support)
  if (data.phone && data.phone.trim()) {
    const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (alphanumeric support for international formats)
  if (data.postal_code && data.postal_code.trim()) {
    // Support formats like "SW1A 1AA", "C1000", "B1675", etc.
    const postalRegex = /^[A-Za-z0-9\s-]{3,12}$/;
    if (!postalRegex.test(data.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export function sanitizeFormData(data: FormData): FormData {
  const sanitized: FormData = { ...data };
  
  // Trim whitespace from all string fields
  (Object.keys(sanitized) as (keyof FormData)[]).forEach(key => {
    if (typeof sanitized[key] === 'string') {
      sanitized[key] = (sanitized[key] as string).trim();
    }
  });

  return sanitized;
}