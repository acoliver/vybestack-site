import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { dbManager } from './database';
import { validateFormData, sanitizeFormData, FormData, ValidationResult } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Error handling middleware
interface AppError extends Error {
  status?: number;
}

app.use((err: AppError, _req: Request, res: Response, /* eslint-disable @typescript-eslint/no-unused-vars */_next: NextFunction) => {
  console.error(err.stack);
  res.status(err.status || 500).send('Internal Server Error');
});

// GET / - Render the contact form
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: {},
    data: {} as FormData
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province_region: req.body.state_province_region || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Sanitize form data
    const sanitizedData = sanitizeFormData(formData);
    
    // Validate form data
    const validation: ValidationResult = validateFormData(sanitizedData);
    
    if (!validation.isValid) {
      // Re-render form with errors and previously entered values
      return res.status(400).render('index', {
        errors: validation.errors,
        data: sanitizedData
      });
    }

    // Insert into database
    const submissionId = await dbManager.insertSubmission(sanitizedData);
    
    console.log(`Form submission saved with ID: ${submissionId}`);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
