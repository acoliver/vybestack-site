import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sqlJs = await initSqlJs({
        locateFile: (file: string) => {
          // Use local WASM file instead of remote URL
          return require.resolve(`sql.js/dist/${file}`);
        }
      });

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new this.sqlJs.Database(dbBuffer);
      } else {
        this.db = new this.sqlJs.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db || !fs.existsSync(this.schemaPath)) {
      throw new Error('Database not initialized or schema file not found');
    }

    const schemaSql = fs.readFileSync(this.schemaPath, 'utf-8');
    this.db.exec(schemaSql);
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const sql = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const stmt = this.db.prepare(sql);
    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province_region,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
    stmt.free();

    // Get the last insert ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0].values[0][0] as number;

    // Save to disk immediately
    await this.saveToDisk();

    return id;
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbData = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbData));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Singleton instance
export const dbManager = new DatabaseManager();