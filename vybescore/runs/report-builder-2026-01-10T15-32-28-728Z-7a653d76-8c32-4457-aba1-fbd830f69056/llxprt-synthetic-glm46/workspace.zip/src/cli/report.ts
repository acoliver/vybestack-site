#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { Report, ReportOptions } from '../types/report.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';

function parseArgs(): ReportOptions & { inputFile: string } {
  const args = process.argv.slice(2);
  const result = {
    inputFile: '',
    format: 'markdown' as 'markdown' | 'text',
    output: undefined as string | undefined,
    includeTotals: false
  };

  if (args.length === 0) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  result.inputFile = args[0];
  let i = 1;

  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i] as 'markdown' | 'text';
      if (format !== 'markdown' && format !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      result.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.output = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument ${arg}`);
      process.exit(1);
    }
    
    i++;
  }

  return result;
}

function validateReport(data: unknown): Report {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid report: missing or invalid title');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid report: missing or invalid summary');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid report: missing or invalid entries');
  }

  const entries = report.entries.map((entry: unknown) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: expected object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid label');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid amount');
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries
  };
}

function main(): void {
  try {
    const options = parseArgs();

    const fileContent = readFileSync(options.inputFile, 'utf-8');
    const jsonData = JSON.parse(fileContent) as unknown;
    
    const report = validateReport(jsonData);

    const formatters = {
      markdown: new MarkdownFormatter(),
      text: new TextFormatter()
    };

    const formatter = formatters[options.format];
    const output = formatter.render(report, options.includeTotals);

    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'An unknown error occurred');
    process.exit(1);
  }
}

main();
