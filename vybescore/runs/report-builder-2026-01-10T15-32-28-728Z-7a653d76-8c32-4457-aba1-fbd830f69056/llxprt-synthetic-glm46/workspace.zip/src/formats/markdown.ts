import { Report, Formatter } from '../types/report.js';

export class MarkdownFormatter implements Formatter {
  render(report: Report, includeTotals: boolean): string {
    let output = `# ${report.title}\n\n${report.summary}\n\n## Entries\n`;
    
    for (const entry of report.entries) {
      output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
    }
    
    if (includeTotals) {
      const total = report.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `\n**Total:** $${total.toFixed(2)}`;
    }
    
    return output;
  }
}