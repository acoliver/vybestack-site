import { Report, Formatter } from '../types/report.js';

export class TextFormatter implements Formatter {
  render(report: Report, includeTotals: boolean): string {
    let output = `${report.title}\n${report.summary}\nEntries:\n`;
    
    for (const entry of report.entries) {
      output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
    }
    
    if (includeTotals) {
      const total = report.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `Total: $${total.toFixed(2)}`;
    }
    
    return output;
  }
}