/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Ensure proper padding for standard Base64
  const padded = ensurePadding(input.trim());

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Ensures proper Base64 padding for the input string.
 */
function ensurePadding(input: string): string {
  // Remove any existing padding first
  const withoutPadding = input.replace(/=+$/, '');
  
  // Calculate required padding
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  
  return withoutPadding + '='.repeat(paddingLength);
}
