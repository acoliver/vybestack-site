/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation
  // Allow typical addresses such as name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // No leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain segments should not start or end with hyphens
  const domainSegments = domain.split('.');
  for (const segment of domainSegments) {
    if (segment.startsWith('-') || segment.endsWith('-')) {
      return false;
    }
  }
  
  // Local part should not start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Support formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Clean the input by removing common separators
  const cleaned = value.replace(/[\s-()]/g, '');
  
  // Check if it's too short
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Should have exactly 10 digits after removing country code
  if (digits.length !== 10 || !/^\d+$/.test(digits)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code should not start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the overall structure with the original format
  const phoneRegex = /^(?:\+1[\s-]?)?\(?[2-9]\d{2}\)?[\s-]?[2-9]\d{2}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles such as:
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  
  // Clean the input by removing spaces and hyphens for easier validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern to extract components
  // Optional country code +54, optional trunk prefix 0, optional mobile indicator 9, area code (2-4 digits), subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(0?)(9?)([1-9]\d{0,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, the number must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !trunkPrefix) {
    return false;
  }
  
  // Additional validation using the original format
  // Allow spaces and hyphens as separators
  const officialRegex = /^(?:\+54[\s-]?)?(?:0)?(?:9[\s-]?)?[1-9]\d{0,3}[\s-]?\d{3,4}[\s-]?\d{4}$/;
  
  return officialRegex.test(value);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate names - permit unicode letters, accents, apostrophes, hyphens, spaces. Reject digits, symbols.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  // Basic format validation
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Should not contain consecutive apostrophes or hyphens
  if (/''|--/.test(value)) {
    return false;
  }
  
  // Should not start or end with apostrophe or hyphen
  if (/^['-]|['-]$/.test(value)) {
    return false;
  }
  
return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid lengths: Visa (13,16), Mastercard (16), AmEx (15)
  if (![13, 15, 16].includes(cleaned.length)) {
    return false;
  }
  
  // Validate prefixes based on length and expected card type
  const isValidPrefix = 
    // Visa: starts with 4, length 13 or 16
    (cleaned.startsWith('4') && [13, 16].includes(cleaned.length)) ||
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    (cleaned.length === 16 && (
      (/^5[1-5]/.test(cleaned)) || 
      (/^2(2[2-9]|[3-6]\d|7[01])/.test(cleaned))
    )) ||
    // AmEx: starts with 34 or 37, length 15
    (cleaned.length === 15 && (cleaned.startsWith('34') || cleaned.startsWith('37')));
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleaned);
}
