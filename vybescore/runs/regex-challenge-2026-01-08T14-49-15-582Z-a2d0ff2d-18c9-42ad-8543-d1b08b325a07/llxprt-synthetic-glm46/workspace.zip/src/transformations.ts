/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Return empty string as is
  if (!text) return text;
  
  // Process sentence boundaries: . ? ! followed by any number of spaces
  const result = text.replace(/(^|[.!?]\s*)([a-z])/g, (match, boundary, char) => {
    return boundary + char.toUpperCase();
  });
  
  // Collapse multiple spaces between sentences to exactly one space
  return result.replace(/([.!?])\s+/g, '$1 ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https, www, domain names, and optional ports/paths
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>()"'{}|\\^`[\]]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>()"'{}|\\^`[\]]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but preserve https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First upgrade http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match example.com URLs with docs paths
  // Skip URLs with dynamic hints: cgi-bin, query strings, or legacy extensions
  const docsRewriteRegex = /(https?:\/\/)example\.com(\/docs\/[^?\s]*)(?![?&](.*=|.jsp|.php|.asp|.aspx|.do|.cgi|.pl|.py))/g;
  
  // Rewrite URLs to docs.example.com when path starts with /docs/ and doesn't contain dynamic hints
  result = result.replace(docsRewriteRegex, 'https://docs.example.com$2');
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month/day combinations
  if (monthNum === 2) {
    // February - simple validation, not accounting for leap years in detail
    if (dayNum > 29) {
      return 'N/A';
    }
  } else if ([4, 6, 9, 11].includes(monthNum)) {
    // April, June, September, November have 30 days
    if (dayNum > 30) {
      return 'N/A';
    }
  } else {
    // All other months have 31 days
    if (dayNum > 31) {
      return 'N/A';
    }
  }
  
  return year;
}
