/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create patterns for word boundaries and prefix matching
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*`, 'g');
  
  // Find all words matching the prefix
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex to handle special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token preceded by a digit but not at string start
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one special character/symbol
  if (!/[!@#$%^&*()_+=[\]{}':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences of 2 or more characters (e.g., abab, abcabc)
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches various forms including shorthand :: notation
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::1?|::|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/i;
  
  // IPv4 pattern to exclude false positives
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check for IPv6 addresses that are not part of IPv4 addresses
  return ipv6Pattern.test(value) && !ipv4Pattern.test(value);
}
