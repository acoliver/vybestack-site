import { createInput, createComputed } from './src/index.ts';

const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const timesThirty = createComputed(() => input() * 30);

// Let's debug what happens to the observers
console.log('Initial timesTwo value:', timesTwo());
// Access timesThirty to establish dependency
console.log('Initial timesThirty value:', timesThirty());

// Now create sum
const sum = createComputed(() => {
  const twoVal = timesTwo(); 
  const thirtyVal = timesThirty();
  const result = twoVal + thirtyVal;
  console.log(`sum() recomputing: timesTwo=${twoVal}, timesThirty=${thirtyVal}, result=${result}`);
  return result;
});

console.log('Initial sum value:', sum());

console.log('\nAfter setInput(3):');
setInput(3);

console.log('Post update input:', input());
console.log('Post update timesTwo:', timesTwo());
console.log('Post update timesThirty:', timesThirty());
console.log('Post update sum:', sum(), '(expected: 96)');