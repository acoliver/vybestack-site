/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: ObserverR[]
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Global registry of all dependency relationships
const dependencyGraph = new Map<ObserverR, Set<ObserverR>>()

// Also track反向 relationships (target -> sources) for efficient notification
const reverseDependencyGraph = new Map<ObserverR, Set<ObserverR>>()

export function addDependency(source: ObserverR, target: ObserverR): void {
  // Source depends on target (source reads from target)
  if (!dependencyGraph.has(source)) {
    dependencyGraph.set(source, new Set())
  }
  dependencyGraph.get(source)!.add(target)
  
  // Also update reverse mapping
  if (!reverseDependencyGraph.has(target)) {
    reverseDependencyGraph.set(target, new Set())
  }
  reverseDependencyGraph.get(target)!.add(source)
}

export function removeDependency(source: ObserverR, target: ObserverR): void {
  const deps = dependencyGraph.get(source)
  if (deps) {
    deps.delete(target)
    if (deps.size === 0) {
      dependencyGraph.delete(source)
    }
  }
  
  // Also update reverse mapping
  const sources = reverseDependencyGraph.get(target)
  if (sources) {
    sources.delete(source)
    if (sources.size === 0) {
      reverseDependencyGraph.delete(target)
    }
  }
}

export function getDependents(target: ObserverR): ObserverR[] {
  // Use reverse dependency graph for efficiency
  const dependents = reverseDependencyGraph.get(target)
  return dependents ? Array.from(dependents) : []
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // Find all observers that depend on this one and update them
    const dependents = getDependents(observer)
    
    // Update all dependents
    for (const dependent of dependents) {
      try {
const dependentObserver = dependent as Observer<unknown>
if (typeof dependentObserver.updateFn === 'function') {
          // Re-execute the dependent's update function to get the new value
          const prevActiveObserver: ObserverR | undefined = activeObserver
          activeObserver = dependentObserver
          try {
            dependentObserver.value = dependentObserver.updateFn(dependentObserver.value)
          } finally {
            activeObserver = prevActiveObserver
          }
        }
      } catch (e) {
        console.error('Error updating dependent observer:', e)
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function invalidateObserver<T>(observer: Observer<T>): void {
  // Get all dependents and recursively invalidate them
  const dependents = getDependents(observer)
  
  // Invalidate all dependents
for (const dependent of dependents) {
      try {
        const dependentObserver = dependent as Observer<unknown>
        if (typeof dependentObserver.updateFn === 'function') {
        // Mark the value as undefined to force recomputation
        dependentObserver.value = undefined
        
        // Recursively invalidate dependents
        invalidateObserver(dependentObserver as Observer<unknown>)
      }
    } catch (e) {
      console.error('Error invalidating dependent observer:', e)
    }
  }
}

// Track all active callbacks for cleanup
const activeCallbacks = new Set<Observer<any>>()

export function addCallbackObserver<T>(observer: Observer<T>): void {
  activeCallbacks.add(observer)
}

export function removeCallbackObserver<T>(observer: Observer<T>): void {
  activeCallbacks.delete(observer)
}

export function disposeAllCallbacks(): void {
  for (const callback of activeCallbacks) {
    if (callback.updateFn) {
      callback.value = undefined
      // Clear the update function to prevent further execution
      callback.updateFn = () => ({} as unknown)
    }
  }
  activeCallbacks.clear()
}

// Helper function to trigger callbacks that depend on changed values
export function notifyDependents(observer: ObserverR): void {
  const dependents = getDependents(observer)
  for (const dependent of dependents) {
    const dependentObserver = dependent as Observer<unknown>
    if (typeof dependentObserver.updateFn === 'function') {
      // Execute the callback/computed value
      const prevActiveObserver = getActiveObserver()
      setActiveObserver(dependentObserver)
      try {
        dependentObserver.value = dependentObserver.updateFn(dependentObserver.value)
      } finally {
        setActiveObserver(prevActiveObserver)
      }
    }
  }
}
