/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create a subject that also works as an observer
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }
  
  // Create observer representation for the input
  const inputObserver: Observer<T> = {
    name: options?.name,
    value: s.value,
    updateFn: (_val?: T) => s.value
  }

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // This input is being accessed within another observer
      // so we register it as a dependency
      addDependency(currentObserver, inputObserver)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (!hasChanged) return s.value
    
    s.value = nextValue
    inputObserver.value = nextValue
    
    // Update all dependent observers (both callbacks and computed values)
    notifyDependents(inputObserver)
    
    return s.value
  }

  return [read, write]
}
