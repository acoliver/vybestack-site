/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  EqualFn,
  Options,
  getActiveObserver,
  setActiveObserver,
  addDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Store the original update function
  const originalUpdateFn = updateFn
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (_val?: T) => {
      // Set this observer as active to track dependencies
      const prevActiveObserver = getActiveObserver()
      setActiveObserver(o)
      
      try {
        // Always recompute using the original update function
        const newValue = originalUpdateFn(o.value)
        o.value = newValue
        
        // Notify all dependents that this computed value has changed
        notifyDependents(o)
        
        return newValue
      } finally {
        // Restore the previous active observer
        setActiveObserver(prevActiveObserver)
      }
    },
  }
  
  const computed = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // This computed value is being accessed within another observer
      // so we register this observer as a dependency
      addDependency(currentObserver, o)
    }
    
    // If we have no value yet or need to recompute, do it
    if (typeof o.value === 'undefined') {
      // Set this observer as active to track dependencies
      const prevActiveObserver = getActiveObserver()
      setActiveObserver(o)
      
      try {
        o.value = originalUpdateFn(o.value)
      } finally {
        // Restore the previous active observer
        setActiveObserver(prevActiveObserver)
      }
    }
    
    return o.value as T
  }
  
  // Initialize the computed value
  computed()
  
  return computed
}
