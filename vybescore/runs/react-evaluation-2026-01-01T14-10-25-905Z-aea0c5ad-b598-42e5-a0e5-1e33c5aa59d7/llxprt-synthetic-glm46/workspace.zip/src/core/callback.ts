/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, getActiveObserver, addCallbackObserver, removeCallbackObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Keep track of the callback to ensure proper cleanup
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: (val?: T) => {
      if (disposed) return value as T
      
      // Set this observer as active to track dependencies
      const prevActiveObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        // Execute the callback and return the new value
        const newValue = updateFn(val)
        observer.value = newValue
        return newValue
      } finally {
        // Restore the previous active observer
        setActiveObserver(prevActiveObserver)
      }
    },
  }
  
  // Register the callback for tracking
  addCallbackObserver(observer)
  
  // Execute the callback initially to track dependencies
  observer.updateFn(value)
  
  // Return unsubscribe function
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove from active callbacks
    removeCallbackObserver(observer)
    
    // Clear the observer references to break circular dependencies
    observer.value = undefined
    observer.updateFn = () => (typeof value !== 'undefined' ? value : ({} as unknown as T))
  }
  
  return unsubscribe
}
