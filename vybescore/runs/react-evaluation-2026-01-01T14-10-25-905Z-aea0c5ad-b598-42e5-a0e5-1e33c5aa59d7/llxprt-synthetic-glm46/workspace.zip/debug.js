import { createInput, createComputed, createCallback } from './src/index.js'

// Simple reactive test
console.log('=== Simple Reactive Test ===')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let callbackValue = 0
createCallback(() => {
  callbackValue = output()
  console.log(`Callback: value changed to ${callbackValue}`)
})

console.log('Initial values:')
console.log(`input: ${input()}, output: ${output()}, callbackValue: ${callbackValue}`)

console.log('Setting input to 3...')
setInput(3)
console.log(`After change - input: ${input()}, output: ${output()}, callbackValue: ${callbackValue}`)

// More complex test
console.log('\n=== Complex Reactive Test ===')
const [input2, setInput2] = createInput(1)
const timesTwo = createComputed(() => input2() * 2)
const timesThirty = createComputed(() => input2() * 30)
const sum = createComputed(() => timesTwo() + timesThirty)

console.log('Initial values:')
console.log(`input2: ${input2()}, timesTwo: ${timesTwo()}, timesThirty: ${timesThirty()}, sum: ${sum()}`)
console.log('Setting input2 to 3...')
setInput2(3)
console.log(`After change - input2: ${input2()}, timesTwo: ${timesTwo()}, timesThirty: ${timesThirty()}, sum: ${sum()}`)