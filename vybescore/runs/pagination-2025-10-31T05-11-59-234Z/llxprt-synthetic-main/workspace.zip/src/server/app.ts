import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      // Check if page is a valid number
      if (isNaN(Number(pageParam)) || !Number.isInteger(Number(pageParam)) || Number(pageParam) <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      page = Number(pageParam);
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      // Check if limit is a valid number
      if (isNaN(Number(limitParam)) || !Number.isInteger(Number(limitParam)) || Number(limitParam) <= 0 || Number(limitParam) > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer not exceeding 100.' });
      }
      limit = Number(limitParam);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
