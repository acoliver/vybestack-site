import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - No type definitions available for sql.js
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

let db: unknown;
let app: express.Application;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Invalid postal code format' });
  }
  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }
  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone number format' });
  }

  return errors;
}

function initializeDatabase(SQL: unknown): unknown {
  let database: unknown;
  
  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      const dataBuffer = fileBuffer.buffer || fileBuffer;
      database = new (SQL as any).Database(dataBuffer);
    } else {
      database = new (SQL as any).Database();
      const schema = fs.readFileSync(schemaPath, 'utf8');
      (database as any).run(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
  
  return database;
}

function saveDatabase(database: unknown): void {
  try {
    if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
      fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
    }
    
    const data = (database as any).export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Database save failed:', error);
    throw error;
  }
}

function initializeApp(): express.Application {
  app = express();
  
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [],
      values: {} 
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      const errorMessages = errors.map(err => err.message);
      return res.status(400).render('form', {
        errors: errorMessages,
        values: formData
      });
    }

    try {
      if (!db) {
        throw new Error('Database not initialized');
      }
      
      const stmt = (db as any).prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      saveDatabase(db);
      
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', { firstName: 'Friend' });
  });
  
  return app;
}

function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}, shutting down gracefully...`);
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed.');
      if (db) {
        try {
          (db as any).close();
          console.log('Database connection closed.');
        } catch (error) {
          console.error('Error closing database:', error);
        }
      }
      process.exit(0);
    });
  } else {
    if (db) {
      try {
        (db as any).close();
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
    process.exit(0);
  }
}

async function startServer(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    if (!fs.existsSync(path.join(__dirname, '..', 'data'))) {
      fs.mkdirSync(path.join(__dirname, '..', 'data'), { recursive: true });
    }
    
    db = initializeDatabase(SQL);
    app = initializeApp();
    
    const port = Number(process.env.PORT) || 3535;
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

let server: import('http').Server | null = null;
startServer();
