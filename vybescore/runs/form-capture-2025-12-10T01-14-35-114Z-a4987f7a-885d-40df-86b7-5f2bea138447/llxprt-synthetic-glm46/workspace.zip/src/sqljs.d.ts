declare module 'sql.js';

declare module 'sql.js' {
  interface Database {
    export(): Uint8Array;
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    close(): void;
  }

  interface Statement {
    run(params?: unknown[]): unknown;
    free(): void;
  }

  interface SqlJsStatic {
    Database: new (data?: ArrayBuffer) => Database;
  }
  
  const initSqlJs: (options?: { locateFile?: (file: string) => string }) => Promise<SqlJsStatic>;
  
  export = initSqlJs;
  export default initSqlJs;
}