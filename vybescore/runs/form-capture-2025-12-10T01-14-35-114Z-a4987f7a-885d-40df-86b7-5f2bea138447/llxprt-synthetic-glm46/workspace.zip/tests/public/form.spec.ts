import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import initSqlJs from 'sql.js';

let server: any;
let app: express.Application;
let db: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Mock the database for testing
function initializeDatabase(SQL: any): any {
  let database;
  
  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      database = new SQL.Database(fileBuffer.buffer);
    } else {
      database = new SQL.Database();
      const schema = fs.readFileSync('db/schema.sql', 'utf8');
      database.run(schema);
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    database = new SQL.Database();
    const schema = fs.readFileSync('db/schema.sql', 'utf8');
    database.run(schema);
  }
  
  return database;
}

beforeAll(async () => {
  // Initialize the app for testing
  app = express();
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static('public'));
  
  app.set('view engine', 'ejs');
  app.set('views', 'src/templates');
  
  const SQL = await initSqlJs();
  db = initializeDatabase(SQL);
  
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [],
      values: {} 
    });
  });

  app.post('/submit', (req, res) => {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validation functions
    const validateEmail = (email: string): boolean => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    };
    
    const validatePhone = (phone: string): boolean => {
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      return phoneRegex.test(phone) && phone.trim().length > 0;
    };
    
    const validatePostalCode = (postalCode: string): boolean => {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      return postalRegex.test(postalCode) && postalCode.trim().length > 0;
    };
    
const errors = [];
    if (!formData.firstName.trim()) {
      errors.push('First name is required');
    }
    if (!formData.lastName.trim()) {
      errors.push('Last name is required');
    }
    if (!formData.streetAddress.trim()) {
      errors.push('Street address is required');
    }
    if (!formData.city.trim()) {
      errors.push('City is required');
    }
    if (!formData.stateProvince.trim()) {
      errors.push('State/Province/Region is required');
    }
    if (!formData.postalCode.trim()) {
      errors.push('Postal/Zip code is required');
    }
    if (!formData.country.trim()) {
      errors.push('Country is required');
    }
    if (!formData.email.trim()) {
      errors.push('Email is required');
    } else if (!validateEmail(formData.email)) {
      errors.push('Invalid email format');
    }
    if (!formData.phone.trim()) {
      errors.push('Phone number is required');
    } else if (!validatePhone(formData.phone)) {
      errors.push('Invalid phone number format');
    }
    if (!formData.lastName.trim()) {
      errors.push('Last name is required');
    }
    if (!formData.streetAddress.trim()) {
      errors.push('Street address is required');
    }
    if (!formData.city.trim()) {
      errors.push('City is required');
    }
    if (!formData.stateProvince.trim()) {
      errors.push('State/Province/Region is required');
    }
    if (!formData.postalCode.trim()) {
      errors.push('Postal code is required');
    } else if (!validatePostalCode(formData.postalCode)) {
      errors.push('Invalid postal code format');
    }
    if (!formData.country.trim()) {
      errors.push('Country is required');
    }
    if (!formData.email.trim()) {
      errors.push('Email is required');
    } else if (!validateEmail(formData.email)) {
      errors.push('Invalid email format');
    }
    if (!formData.phone.trim()) {
      errors.push('Phone number is required');
    } else if (!validatePhone(formData.phone)) {
      errors.push('Invalid phone number format');
    }
    
    if (errors.length > 0) {
      return res.status(400).render('form', {
        errors: errors,
        values: formData
      });
    }

    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      saveDatabase(db);
      
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  });

  app.get('/thank-you', (req, res) => {
    res.render('thank-you', { firstName: 'Friend' });
  });
  
  server = app.listen(0); // Random port
});

function saveDatabase(database: any): void {
  const data = database.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that all form fields are present
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check that the form has the correct action and method
    const form = $('form');
    expect(form.attr('action')).toBe('/submit');
    expect(form.attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit a valid form
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    await request(app)
      .post('/submit')
      .type('form')
      .send(formData)
      .expect(302)
      .expect('Location', '/thank-you');
    
    // Check that the database was created and contains the submission
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify the thank-you page works
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('.thankyou-card h1').text()).toContain('Thank you');
  });

  it('validates form properly', async () => {
    // Submit an invalid form (missing required fields)
    const invalidFormData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(invalidFormData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    expect($('.error-list li').length).toBeGreaterThan(0); // At least one validation error
  });
});
