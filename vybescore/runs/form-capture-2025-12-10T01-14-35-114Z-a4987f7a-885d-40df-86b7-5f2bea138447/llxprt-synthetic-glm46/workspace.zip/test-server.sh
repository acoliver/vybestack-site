#!/bin/bash
cd /home/runner/work/vybestack-site/vybestack-site/evals/outputs/form-capture-2025-12-10T01-14-35-114Z-a4987f7a-885d-40df-86b7-5f2bea138447
npm run build
node dist/server.js &
SERVER_PID=$!
sleep 3
curl -s -o /dev/null -w "%{http_code}" http://localhost:3535/
kill $SERVER_PID