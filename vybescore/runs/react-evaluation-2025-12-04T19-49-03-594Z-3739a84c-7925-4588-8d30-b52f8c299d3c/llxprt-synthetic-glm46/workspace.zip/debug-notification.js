import { createInput, createComputed } from './src/index.js';

const [input, setInput] = createInput(1);
console.log('Input value:', input());

const timesTwo = createComputed(() => {
  console.log('timesTwo executing with input:', input());
  return input() * 2;
});
console.log('timesTwo initial value:', timesTwo());

const timesThirty = createComputed(() => {
  console.log('timesThirty executing with input:', input());
  return input() * 30;
});
console.log('timesThirty initial value:', timesThirty());

const sum = createComputed(() => {
  const twoVal = timesTwo();
  const thirtyVal = timesThirty();
  console.log('sum executing with timesTwo:', twoVal, 'timesThirty:', thirtyVal);
  return twoVal + thirtyVal;
});
console.log('sum initial value:', sum());

console.log('\nSetting input to 3...');
setInput(3);
console.log('Input after change:', input());
console.log('timesTwo after change:', timesTwo());
console.log('timesThirty after change:', timesThirty());
console.log('sum after change:', sum());
console.log('Expected final sum:', 96);