// Simple debug test to understand reactive system behavior
import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Testing compute cells fire callbacks ===')
const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('COMPUTED: Getting input value:', input())
  return input() + 1
})

let value = 0

console.log('Initial input:', input())
console.log('Initial output:', output())

const unsubscribe = createCallback(() => {
  console.log('CALLBACK: triggered, output() =', output())
  value = output()
  console.log('CALLBACK: value set to', value)
})

console.log('After setting input to 3')
setInput(3)

console.log('Expected value: 4, Actual value:', value)

// Add delay to check if callbacks happen later
setTimeout(() => {
  console.log('After delay: Expected value: 4, Actual value:', value)
}, 100)