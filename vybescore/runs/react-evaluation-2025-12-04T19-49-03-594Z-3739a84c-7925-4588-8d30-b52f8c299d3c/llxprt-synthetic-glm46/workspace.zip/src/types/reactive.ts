/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observers?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T | undefined {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    return observer.value
  } finally {
    activeObserver = previous
  }
}

/**
 * Creates a queue to properly manage dependency updates in correct order
 */
export function createUpdateQueue(initialObservers: Set<ObserverR>): (() => void)[] {
  const updates: (() => void)[] = []
  const processed = new Set<ObserverR>()
  const queue: ObserverR[] = []
  
  // Add initial observers to queue
  initialObservers.forEach(observer => {
    if (!processed.has(observer)) {
      queue.push(observer)
      processed.add(observer)
    }
  })
  
  // Process queue to determine update order
  while (queue.length > 0) {
    const observer = queue.shift()!
    
    // Add this observer's update function to the updates array
    updates.push(() => updateObserver(observer as Observer<any>))
    
    // Add this observer's observers to the queue for later processing
    if (observer.observers) {
      observer.observers.forEach(obs => {
        if (!processed.has(obs)) {
          queue.push(obs)
          processed.add(obs)
        }
      })
    }
  }
  
  return updates
}

/**
 * Tracks dependencies and triggers cascading updates in proper order
 * First updates all direct observers, then recursively updates their observers
 */
export function notifyObservers<T>(observers: Set<ObserverR>, visited: Set<ObserverR> = new Set()): T | undefined {
  let result: T | undefined
  
  // First pass: update all direct observers without recursing
  const observerArray = Array.from(observers)
  observerArray.forEach(observer => {
    if (!visited.has(observer)) {
      visited.add(observer)
      result = updateObserver(observer as Observer<T>)
    }
  })
  
  // Second pass: notify observers of the updated observers
  observerArray.forEach(observer => {
    if (observer.observers) {
      notifyObservers(observer.observers, visited) as T | undefined
    }
  })
  
  return result
}

/**
 * Notifies all observers of a subject and returns the last result.
 * @param subject The subject whose observers should be notified
 * @returns The last computed value from any observer, or undefined if no observers
 */
export function notifyObserversOfSubject<T>(subject: Subject<T>): T | undefined {
  return notifyObservers(subject.observers)
}

/**
 * Notifies all observers of an observer and returns the last result.
 * @param observer The observer whose observers should be notified
 * @returns The last computed value from any observer, or undefined if no observers
 */
export function notifyObserversOfObserver<T>(observer: ObserverR): T | undefined {
  if (observer.observers) {
    return notifyObservers(observer.observers) as T | undefined
  }
  return undefined
}