/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  notifyObserversOfSubject
} from '../types/reactive.js'

// Import triggerCallbacksSync directly
import { triggerCallbacksSync } from './callback.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? Object.is 
    : typeof equal === 'function' 
      ? equal 
      : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observers.add(observer)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      
      // Use the reactive system's notification approach
      notifyObserversOfSubject(s)
      
      // Trigger callbacks after updating dependencies (synchronously)
      triggerCallbacksSync()
    }
    return s.value
  }

  return [read, write]
}