/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? Object.is 
    : typeof equal === 'function' 
      ? equal 
      : undefined

  // TODO: Implement equality checking for computed values to prevent unnecessary updates
  void equalFn // Mark as used (currently unused but kept for future implementation)

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this computed observer to the current observer's list
      // ObserverR now has an optional observers property
      if (!observer.observers) {
        observer.observers = new Set()
      }
      observer.observers.add(o)
    }
    
    // Simply return the current computed value without recomputing
    // The value was already initialized in updateObserver(o) above
    return o.value as T
  }
  
  return getter
}