/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Global array to store all active callbacks
const activeCallbacks: Set<Observer<any>> = new Set()

// Simple flag to prevent infinite callback loops
let isUpdatingCallbacks = false

// Export for use by other modules
export function getActiveCallbacks(): Set<Observer<any>> {
  return activeCallbacks
}

export function setActiveCallbacksUpdating(updating: boolean): void {
  isUpdatingCallbacks = updating
}

export function isCallbacksUpdating(): boolean {
  return isUpdatingCallbacks
}

/**
 * Synchronously triggers all active callbacks
 */
export function triggerCallbacksSync(): void {
  // Prevent infinite callback loops
  if (isUpdatingCallbacks) return
  
  setActiveCallbacksUpdating(true)
  try {
    const callbacks = Array.from(activeCallbacks)
    callbacks.forEach(callback => {
      updateObserver(callback)
    })
  } finally {
    setActiveCallbacksUpdating(false)
  }
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies and execute initial effect
  updateObserver(observer)
  activeCallbacks.add(observer)
  
  // Execute initial effect if value provided
  if (value !== undefined) {
    updateFn(value)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from active callbacks
    activeCallbacks.delete(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}