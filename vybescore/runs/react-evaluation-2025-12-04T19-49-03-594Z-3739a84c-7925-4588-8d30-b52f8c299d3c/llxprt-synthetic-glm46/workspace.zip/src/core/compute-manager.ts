/**
 * Centralized computation manager for coordinating reactive updates
 */

import { updateObserver } from '../types/reactive.js'
import { getActiveCallbacks, setActiveCallbacksUpdating, isCallbacksUpdating } from './callback.js'

export function triggerCallbacks(): void {
  // Prevent infinite callback loops
  if (isCallbacksUpdating()) return
  
  setActiveCallbacksUpdating(true)
  try {
    const callbacks = getActiveCallbacks()
    callbacks.forEach(callback => {
      updateObserver(callback)
    })
  } finally {
    setActiveCallbacksUpdating(false)
  }
}