import { createInput, createComputed } from './src/index.js';

const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => {
  console.log('timesTwo recalculating with input:', input());
  return input() * 2;
});
const timesThirty = createComputed(() => {
  console.log('timesThirty recalculating with input:', input());
  return input() * 30;
});
const sum = createComputed(() => {
  const twoVal = timesTwo();
  const thirtyVal = timesThirty();
  console.log('sum recalculating with timesTwo:', twoVal, 'timesThirty:', thirtyVal);
  return twoVal + thirtyVal;
});

console.log('Initial sum:', sum());
setInput(3);
console.log('Final sum:', sum());
console.log('Expected final sum:', 96);