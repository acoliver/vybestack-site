import { createInput, createComputed } from './src/index.js';

const [input, setInput] = createInput(1);
console.log('Input value:', input());

// Let's test just one level of dependency
const timesTwo = createComputed(() => {
  console.log('timesTwo executing with input:', input());
  return input() * 2;
});
console.log('timesTwo initial value:', timesTwo());

const timesFour = createComputed(() => {
  const twoVal = timesTwo();
  console.log('timesFour executing with timesTwo:', twoVal);
  return twoVal * 2;
});
console.log('timesFour initial value:', timesFour());

console.log('\nSetting input to 3...');
setInput(3);

console.log('Input after change:', input());
console.log('timesTwo after change:', timesTwo());
console.log('timesFour after change:', timesFour());
console.log('Expected final timesFour:', 12);