import { createComputed } from './src/index.js';

// Test the failing case
const computed = createComputed((x) => {
  console.log('updateFn called with x:', x);
  return x * 2;
}, 3);
console.log('Result:', computed());
console.log('Expected:', 6);