// Very simple test to understand the issue
import { createInput, createComputed } from './src/index.ts'

console.log('=== Simplified Test ===')
const [getValue, setValue] = createInput(1)

console.log('Initial value:', getValue())

// Create computed that depends on input
const plusOne = createComputed(() => {
  console.log('PLUS ONE: Computing with value', getValue())
  const result = getValue() + 1
  console.log('PLUS ONE: Result is', result)
  return result
})

console.log('First computed call:', plusOne())

console.log('Setting input to 3...')
setValue(3)

console.log('Second computed call:', plusOne())