#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

const require = createRequire(import.meta.url);

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: Partial<CliArgs> = {
    includeTotals: false,
  };
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (!result.dataFile && !arg.startsWith('--')) {
      result.dataFile = arg;
      i++;
      continue;
    }
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        console.error('Unsupported format');
        process.exit(1);
      }
      result.format = format;
      i += 2;
      continue;
    }
    
    if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      result.output = args[i + 1];
      i += 2;
      continue;
    }
    
    if (arg === '--includeTotals') {
      result.includeTotals = true;
      i++;
      continue;
    }
    
    console.error(`Unknown argument: ${arg}`);
    process.exit(1);
  }
  
  if (!result.dataFile) {
    console.error('Error: data file path is required');
    process.exit(1);
  }
  
  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return result as CliArgs;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    // Validate the structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    const entries = obj.entries;
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid JSON: entry ${i} is not an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid JSON: entry ${i} missing or invalid "label" field`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid JSON: entry ${i} missing or invalid "amount" field`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

function getFormatter(format: string): ReportFormatter {
  switch (format) {
    case 'markdown':
      return markdownFormatter;
    case 'text':
      return textFormatter;
    default:
      throw new Error('Unsupported format');
  }
}

function main(): void {
  const args = parseArguments();
  
  const data = loadReportData(args.dataFile);
  
  const formatter = getFormatter(args.format);
  
  const options: ReportOptions = {
    includeTotals: args.includeTotals,
  };
  
  const output = formatter.render(data, options);
  
  if (args.output) {
    const { writeFileSync } = require('fs');
    writeFileSync(args.output, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();