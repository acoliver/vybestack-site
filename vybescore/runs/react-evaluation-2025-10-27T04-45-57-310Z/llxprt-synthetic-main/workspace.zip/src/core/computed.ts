/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
/**
 * Creates a computed (derived) closure that automatically updates
 * when its dependencies change.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a simple computed value getter that computes on access
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If there's an active observer, register this computed as a dependency
    if (activeObserver) {
      // Store the observer that will be notified when this computed changes
      ;(activeObserver as any).observer = activeObserver
    }
    
    // Compute the value on access
    return updateFn(value)
  }
  
  return getter
}