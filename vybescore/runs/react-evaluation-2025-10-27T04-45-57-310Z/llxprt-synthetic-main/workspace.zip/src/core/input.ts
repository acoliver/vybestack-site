/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Store the observer that depends on this input
      ;(s as any).observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    let changed = true
    if (s.equalFn) {
      changed = !s.equalFn(s.value, nextValue)
    } else {
      changed = s.value !== nextValue
    }
    
    if (!changed) return s.value
    
    s.value = nextValue
    
    // Simple chain notification: notify the observer, which will update and potentially notify its own observer
    const observer = s.observer
    if (observer && 'updateFn' in observer) {
      updateObserver(observer as Observer<T>)
    }
    
    return s.value
  }

  return [read, write]
}
