const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const URL_SAFE_REGEX = /^[A-Za-z0-9_-]*$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!BASE64_REGEX.test(input) && !URL_SAFE_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  let processedInput = input;
  
  // Handle URL-safe Base64 by converting to standard Base64
  if (URL_SAFE_REGEX.test(input)) {
    processedInput = input.replace(/-/g, '+').replace(/_/g, '/');
  }

  // Add padding if missing (required for proper decoding)
  const padding = 4 - (processedInput.length % 4);
  if (padding !== 4 && padding > 0) {
    processedInput += '='.repeat(padding);
  }

  try {
    return Buffer.from(processedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
