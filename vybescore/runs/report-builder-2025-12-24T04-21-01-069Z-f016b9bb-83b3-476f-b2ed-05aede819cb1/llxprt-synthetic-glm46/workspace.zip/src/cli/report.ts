#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      if (!result.dataFile) {
        result.dataFile = arg;
      } else {
        console.error('Unexpected positional argument:', arg);
        process.exit(1);
      }
    } else if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Missing value for --format');
        process.exit(1);
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Missing value for --output');
        process.exit(1);
      }
      result.output = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error('Unknown option:', arg);
      process.exit(1);
    }
    
    i++;
  }
  
  if (!result.dataFile) {
    console.error('Missing data file argument');
    process.exit(1);
  }
  
  if (!result.format) {
    console.error('Missing --format option');
    process.exit(1);
  }
  
  if (result.format !== 'markdown' && result.format !== 'text') {
    console.error('Unsupported format:', result.format);
    process.exit(1);
  }
  
  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries array');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid amount');
    }
  }
  
  return data as ReportData;
}

function getRenderer(format: string): ReportRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs();
    
    let data: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing file "${args.dataFile}":`);
      if (error instanceof SyntaxError) {
        console.error('Invalid JSON format');
      } else {
        console.error(error instanceof Error ? error.message : String(error));
      }
      process.exit(1);
    }
    
    let reportData: ReportData;
    try {
      reportData = validateReportData(data);
    } catch (error) {
      console.error('Invalid report data:');
      console.error(error instanceof Error ? error.message : String(error));
      process.exit(1);
    }
    
    const renderer = getRenderer(args.format);
    const renderOptions: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    const output = renderer.render(reportData, renderOptions);
    
    if (args.output) {
      try {
        writeFileSync(args.output, output, 'utf-8');
        console.log(`Report written to ${args.output}`);
      } catch (error) {
        console.error(`Error writing to file "${args.output}":`);
        console.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Unexpected error:');
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
