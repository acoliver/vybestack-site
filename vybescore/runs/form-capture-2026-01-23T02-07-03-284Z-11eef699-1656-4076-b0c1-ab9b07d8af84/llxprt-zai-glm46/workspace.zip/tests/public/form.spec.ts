import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJsFactory from 'sql.js';

// Import the app from server
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Build the project first
  const { execSync } = await import('node:child_process');
  execSync('npm run build', { cwd: path.resolve(process.cwd()) });

  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Import and start server from dist
  const serverModule = await import('../../dist/server.js');
  app = serverModule.app;

  // Wait a moment for server to be ready
  await new Promise(resolve => setTimeout(resolve, 100));
});

afterAll(async () => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

async function loadDatabase() {
  const initSqlJs = await initSqlJsFactory();
  const SQL = initSqlJs;
  let db: Database | null = null;
  if (fs.existsSync(dbPath)) {
    const dbBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(dbBuffer);
  }
  return db;
}

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app as string).get('/');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    // Check if response has text
    expect(response.text).toBeTruthy();
    expect(response.text.length).toBeGreaterThan(0);

    const $ = cheerio.load(response.text);

    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app as string).post('/submit').send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);

    // Load database and verify data was saved
    const db = await loadDatabase();
    expect(db).toBeTruthy();

    const result = db.exec('SELECT * FROM submissions');
    expect(result).toHaveLength(1);
    expect(result[0].values).toHaveLength(1);

    const row = result[0].values[0] as (string | number)[];
    expect(row[1]).toBe(formData.firstName); // first_name
    expect(row[2]).toBe(formData.lastName); // last_name
    expect(row[3]).toBe(formData.streetAddress); // street_address
    expect(row[4]).toBe(formData.city); // city
    expect(row[5]).toBe(formData.stateProvince); // state_province
    expect(row[6]).toBe(formData.postalCode); // postal_code
    expect(row[7]).toBe(formData.country); // country
    expect(row[8]).toBe(formData.email); // email
    expect(row[9]).toBe(formData.phone); // phone
  });

  it('shows validation errors for missing fields', async () => {
    const response = await request(app as string)
      .post('/submit')
      .send('firstName=&lastName=&email=invalid-email&phone=invalid-phone-!');

    expect(response.status).toBe(400);
    expect(response.text).toBeTruthy();
    expect(response.text.length).toBeGreaterThan(0);

    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBeGreaterThan(0);

    // Check that form is re-rendered with submitted values
    expect($('input[name="email"]').val()).toBe('invalid-email');
  });

  it('validates email format', async () => {
    const response = await request(app as string)
      .post('/submit')
      .send(
        'firstName=Test&lastName=User&streetAddress=123+Test+St&city=Test+City&stateProvince=TS&postalCode=12345&country=Testland&email=not-an-email&phone=+1+234+567+8900'
      );

    expect(response.status).toBe(400);
    expect(response.text).toBeTruthy();
    expect(response.text.length).toBeGreaterThan(0);

    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/email/i);
  });

  it('accepts international phone formats', async () => {
    const response = await request(app as string)
      .post('/submit')
      .send(
        'firstName=International&lastName=User&streetAddress=456+Global+Ave&city=London&stateProvince=England&postalCode=SW1A+1AA&country=United+Kingdom&email=user@example.com&phone=+44+20+7946+0958'
      );

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);
  });

  it('accepts alphanumeric postal codes', async () => {
    const response = await request(app as string)
      .post('/submit')
      .send(
        'firstName=Postal&lastName=Test&streetAddress=789+Zip+Code+Ln&city=London&stateProvince=England&postalCode=SW1A+1AA&country=United+Kingdom&email=postal@example.com&phone=+44+20+1234+5678'
      );

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);
  });

  it('renders thank-you page', async () => {
    const response = await request(app as string).get('/thank-you?firstName=Alice');

    expect(response.status).toBe(200);
    expect(response.text).toMatch(/Thank you/);
    expect(response.text).toMatch(/Alice/);
    expect(response.text).toMatch(/stranger on the internet/i);
  });

  it('handles required field validation', async () => {
    const response = await request(app as string)
      .post('/submit')
      .send('firstName=Only&lastName=Name');

    expect(response.status).toBe(400);
    expect(response.text).toBeTruthy();
    expect(response.text.length).toBeGreaterThan(0);

    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/required/i);
  });
});
