// Simple test to check the app directly
import express from 'express';
import request from 'supertest';

// Create a minimal test app
const app = express();

app.set('views', './src/templates');
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('form.ejs', {
    errors: [],
    values: {},
  });
});

// Test it
async function test() {
  try {
    const response = await request(app).get('/');
    console.log('Status:', response.status);
    console.log('Content-Type:', response.headers['content-type']);
    console.log('Has form:', response.text.includes('<form'));
    console.log('SUCCESS!');
  } catch (error) {
    console.error('FAILED:', error.message);
    process.exit(1);
  }
}

test();
