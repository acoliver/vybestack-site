// Test importing the actual server
async function test() {
  try {
    console.log('Importing server from dist...');
    const serverModule = await import('../../dist/server.js');
    console.log('Server module imported');
    console.log('App type:', typeof serverModule.app);
    console.log('App constructor:', serverModule.app?.constructor?.name);

    // Try to use it
    const request = (await import('supertest')).default;
    const response = await request(serverModule.app).get('/');
    console.log('Response status:', response.status);
    console.log('Response text length:', response.text.length);
  } catch (error) {
    console.error('Error:', error.message);
    console.error('Stack:', error.stack);
    process.exit(1);
  }
}

test();
