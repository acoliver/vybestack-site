// Debug test for server
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();

app.set('views', path.resolve(__dirname, 'templates'));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  try {
    console.log('Rendering form...');
    const result = res.render('form.ejs', {
      errors: [],
      values: {},
    });
    console.log('Render result:', result);
  } catch (error) {
    console.error('Render error:', error);
    res.status(500).send(`Error: ${error.message}`);
  }
});

const PORT = 3536;
app.listen(PORT, () => {
  console.log(`Debug server running on http://localhost:${PORT}`);

  // Test request
  import('node:http').then((http) => {
    http.get(`http://localhost:${PORT}/`, (response) => {
      let data = '';
      response.on('data', (chunk) => { data += chunk; });
      response.on('end', () => {
        console.log('Status:', response.statusCode);
        console.log('First 200 chars:', data.substring(0, 200));
        process.exit(0);
      });
    }).on('error', (err) => {
      console.error('Request error:', err);
      process.exit(1);
    });
  });
});
