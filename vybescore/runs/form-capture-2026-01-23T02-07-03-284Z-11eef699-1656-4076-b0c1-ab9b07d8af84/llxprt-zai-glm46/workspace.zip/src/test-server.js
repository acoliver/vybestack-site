// Simple test to debug the server
import http from 'node:http';

const PORT = 3535;

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end('<h1>Hello</h1>');
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

server.listen(PORT, () => {
  console.log(`Test server running on http://localhost:${PORT}`);

  // Make a test request
  http.get(`http://localhost:${PORT}/`, (response) => {
    let data = '';
    response.on('data', (chunk) => { data += chunk; });
    response.on('end', () => {
      console.log('Response status:', response.statusCode);
      console.log('Response data:', data);
      server.close();
    });
  });
});
