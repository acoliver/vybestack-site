import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[\d\s()+-]+$/;
  return phoneRegex.test(phone) && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = formData[field]?.trim();
    if (!value || value.length === 0) {
      errors.push({ field, message: `${fieldToLabel(field)} is required` });
    }
  }

  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and +',
    });
  }

  // Postal code validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code can only contain letters, digits, spaces, and dashes',
    });
  }

  return errors;
}

function fieldToLabel(field: string): string {
  const labels: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State / Province / Region',
    postalCode: 'Postal / Zip code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone number',
  };
  return labels[field] || field;
}

// Initialize database
async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  let dbInstance: Database;

  try {
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      dbInstance = new SQL.Database(dbBuffer);
      console.log(`Loaded existing database from ${DB_PATH}`);
    } else {
      dbInstance = new SQL.Database();
      console.log('Created new in-memory database');
    }
  } catch (error) {
    // If file doesn't exist or can't be read, create new database
    dbInstance = new SQL.Database();
    console.log('Created new in-memory database');
  }

  // Ensure schema exists
  const schemaSql = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  dbInstance.run(schemaSql);
  console.log('Database schema initialized');

  return dbInstance;
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;

  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    const dir = path.dirname(DB_PATH);

    // Ensure directory exists
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(DB_PATH, buffer);
    console.log(`Database saved to ${DB_PATH}`);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('form.ejs', {
      errors: errors.map((e) => e.message),
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    try {
      db.run(
        `INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone,
        ]
      );

      // Save database after insert
      saveDatabase();

      // Redirect to thank-you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500);
      res.render('form.ejs', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData,
      });
    }
  } else {
    res.status(500);
    res.render('form.ejs', {
      errors: ['Database not initialized. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you.ejs', { firstName });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');

  if (db) {
    try {
      db.close();
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
    db = null;
  }

  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<unknown> {
  try {
    db = await initDatabase();
    app.set('views', path.resolve(__dirname, 'templates'));
    app.set('view engine', 'ejs');

    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, start, shutdown, initDatabase, saveDatabase };

// Start server if this file is run directly
start();
