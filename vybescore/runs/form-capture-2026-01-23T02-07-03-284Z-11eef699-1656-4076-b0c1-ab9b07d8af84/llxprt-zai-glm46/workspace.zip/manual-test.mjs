// Manual integration test
import http from 'node:http';
import { spawn } from 'node:child_process';

console.log('Starting server...');
const server = spawn('node', ['dist/server.js'], {
  cwd: process.cwd(),
  stdio: ['ignore', 'pipe', 'pipe']
});

// Wait for server to start
await new Promise(resolve => setTimeout(resolve, 2000));

console.log('Testing server...');

// Test GET /
http.get('http://localhost:3535/', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    console.log('GET / Status:', res.statusCode);
    console.log('Has form tag:', data.includes('<form'));
    console.log('Has firstName field:', data.includes('name="firstName"'));

    // Test POST /submit
    const postData = 'firstName=Test&lastName=User&streetAddress=123+Test&city=Test&stateProvince=TS&postalCode=12345&country=USA&email=test@example.com&phone=+1+234+567+8900';

    const postReq = http.request('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    }, (postRes) => {
      console.log('POST /submit Status:', postRes.statusCode);
      console.log('Redirected to:', postRes.headers.location);

      // Test GET /thank-you
      http.get('http://localhost:3535/thank-you?firstName=Test', (thankRes) => {
        let thankData = '';
        thankRes.on('data', (chunk) => { thankData += chunk; });
        thankRes.on('end', () => {
          console.log('GET /thank-you Status:', thankRes.statusCode);
          console.log('Has thank you message:', thankData.includes('Thank you'));

          // Cleanup
          console.log('\nShutting down server...');
          server.kill('SIGTERM');
          setTimeout(() => process.exit(0), 500);
        });
      });
    });

    postReq.write(postData);
    postReq.end();
  });
}).on('error', (err) => {
  console.error('Request error:', err.message);
  server.kill();
  process.exit(1);
});
