import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

export class FormDatabase {
  private db: Database | null = null;
  private initialized = false;

  async initialize(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      let dbData: Uint8Array | null = null;
      
      // Try to load existing database
      if (fs.existsSync(DB_PATH)) {
        const fileBuffer = fs.readFileSync(DB_PATH);
        dbData = new Uint8Array(fileBuffer);
      }

      // Initialize database
      this.db = new SQL.Database(dbData);
      
      // Create schema if needed
      if (fs.existsSync(SCHEMA_PATH)) {
        const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
        this.db.run(schema);
      }
      
      this.initialized = true;
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private ensureInitialized(): void {
    if (!this.initialized || !this.db) {
      throw new Error('Database not initialized. Call initialize() first.');
    }
  }

  async insertSubmission(submission: {
    first_name: string;
    last_name: string;
    street_address: string;
    city: string;
    state_province: string;
    postal_code: string;
    country: string;
    email: string;
    phone: string;
  }): Promise<number> {
    this.ensureInitialized();
    
    const stmt = this.db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    stmt.free();
    
    // Get the last inserted row ID
    const result = this.db!.exec('SELECT last_insert_rowid() as id');
    const insertedId = result[0].values[0][0] as number;
    
    // Save database to disk
    await this.saveToDisk();
    
    return insertedId;
  }

  private async saveToDisk(): Promise<void> {
    this.ensureInitialized();
    
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Export database to file
      const data = this.db!.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database to disk:', error);
      throw error;
    }
  }

  async getSubmissions(): Promise<Array<Record<string, unknown>>> {
    this.ensureInitialized();
    
    const result = this.db!.exec('SELECT * FROM submissions ORDER BY created_at DESC');
    
    if (result.length === 0) {
      return [];
    }
    
    const columns = result[0].columns;
    const values = result[0].values;
    
    return values.map(row => {
      const obj: Record<string, unknown> = {};
      columns.forEach((col, index) => {
        obj[col] = row[index];
      });
      return obj;
    });
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
      this.initialized = false;
      console.log('Database connection closed');
    }
  }
}

// Singleton instance
export const formDatabase = new FormDatabase();