import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { formDatabase } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3535;
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
function validateForm(data: Record<string, string | undefined>): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  // Required field validation
  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }

  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }

  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s().-]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', async (req, res) => {
  try {
    res.render('form', {
      title: 'Friendly Contact Form (Definitely Not a Scam)',
      errors: {},
      formData: {}
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/submit', async (req, res) => {
  try {
    const formData = req.body;
    const validation = validateForm(formData);

    if (!validation.isValid) {
      // Re-render form with errors and submitted data
      return res.status(400).render('form', {
        title: 'Friendly Contact Form (Definitely Not a Scam)',
        errors: validation.errors,
        formData
      });
    }

    // Insert submission into database
    const submissionId = await formDatabase.insertSubmission({
      first_name: formData.first_name.trim(),
      last_name: formData.last_name.trim(),
      street_address: formData.street_address.trim(),
      city: formData.city.trim(),
      state_province: formData.state_province.trim(),
      postal_code: formData.postal_code.trim(),
      country: formData.country.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim()
    });

    console.log(`Form submission saved with ID: ${submissionId}`);
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req, res) => {
  try {
    res.render('thank-you', {
      title: 'Thank You! (Your Data is Safe With Us... Probably)'
    });
  } catch (error) {
    console.error('Error rendering thank-you page:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start server and initialize database
async function startServer(): Promise<void> {
  try {
    await formDatabase.initialize();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM signal received: closing server gracefully');
      server.close(() => {
        console.log('Server closed');
        formDatabase.close();
        process.exit(0);
      });
    });

    process.on('SIGINT', () => {
      console.log('SIGINT signal received: closing server gracefully');
      server.close(() => {
        console.log('Server closed');
        formDatabase.close();
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server when this file is run directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  startServer();
}

export { app, startServer };