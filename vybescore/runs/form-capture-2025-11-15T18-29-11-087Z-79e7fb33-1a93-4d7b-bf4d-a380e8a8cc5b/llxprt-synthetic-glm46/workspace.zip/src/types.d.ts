declare module 'sql.js/dist/sql-wasm' {
  interface SqlJsConfig {
    locateFile?: (file: string) => string;
  }

  interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): unknown[][];
    prepare(sql: string): {
      run(...params: unknown[]): void;
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  }

  interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(options?: SqlJsConfig): Promise<SqlJsStatic>;
  export = initSqlJs;
}