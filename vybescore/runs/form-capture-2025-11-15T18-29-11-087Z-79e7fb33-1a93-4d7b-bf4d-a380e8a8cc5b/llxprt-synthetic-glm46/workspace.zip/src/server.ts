import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Type definitions for our form data
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Type definition for validation errors
interface FieldErrors {
  [key: string]: string;
}

// Get the current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.dirname(__dirname);

// Database instance
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;

// Type for sql.js Database constructor
interface SqlJsStatic {
  Database: new (data?: Uint8Array) => unknown;
}

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    // Check if database file exists
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    let databaseFile: Buffer | null = null;
    
    if (fs.existsSync(dbPath)) {
      databaseFile = fs.readFileSync(dbPath);
    }
    
    // Initialize SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(projectRoot, 'node_modules', 'sql.js', 'dist', file)
    }) as SqlJsStatic;
    
    // Create database
    db = new SQL.Database(databaseFile ? new Uint8Array(databaseFile) : undefined);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(projectRoot, 'db', 'schema.sql'), 'utf8');
    if (db) {
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    // Type assertion for db.export method
    const dataArray = (db as { export: () => Uint8Array }).export();
    fs.writeFileSync(dbPath, Buffer.from(dataArray));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateForm(formData: FormData): { isValid: boolean; fieldErrors: FieldErrors } {
  const fieldErrors: FieldErrors = {};
  
  // First name validation
  if (!formData.first_name.trim()) {
    fieldErrors.first_name = 'First name is required';
  }
  
  // Last name validation
  if (!formData.last_name.trim()) {
    fieldErrors.last_name = 'Last name is required';
  }
  
  // Street address validation
  if (!formData.street_address.trim()) {
    fieldErrors.street_address = 'Street address is required';
  }
  
  // City validation
  if (!formData.city.trim()) {
    fieldErrors.city = 'City is required';
  }
  
  // State/Province validation
  if (!formData.state_province.trim()) {
    fieldErrors.state_province = 'State / Province / Region is required';
  }
  
  // Postal code validation (alphanumeric)
  if (!formData.postal_code.trim()) {
    fieldErrors.postal_code = 'Postal / Zip code is required';
  } else if (!/^[A-Za-z0-9\s-]+$/.test(formData.postal_code.trim())) {
    fieldErrors.postal_code = 'Postal code can only contain letters, numbers, spaces and hyphens';
  }
  
  // Country validation
  if (!formData.country.trim()) {
    fieldErrors.country = 'Country is required';
  }
  
  // Email validation
  if (!formData.email.trim()) {
    fieldErrors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
    fieldErrors.email = 'Please enter a valid email address';
  }
  
  // Phone validation (international formats)
  if (!formData.phone.trim()) {
    fieldErrors.phone = 'Phone number is required';
  } else if (!/^\+?[\d\s\-()]+$/.test(formData.phone.trim())) {
    fieldErrors.phone = 'Please enter a valid phone number';
  }
  
  return {
    isValid: Object.keys(fieldErrors).length === 0,
    fieldErrors
  };
}

// Save form submission to database
function saveSubmission(formData: FormData): void {
  if (!db) return;
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    );
    
    stmt.free();
    saveDatabase();
    console.log('Form submission saved successfully');
  } catch (error) {
    console.error('Failed to save submission:', error);
  }
}

// Create Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(projectRoot, 'public')));

// Set up EJS views
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    title: 'Contact Information',
    data: {
      first_name: '',
      last_name: '',
      street_address: '',
      city: '',
      state_province: '',
      postal_code: '',
      country: '',
      email: '',
      phone: ''
    },
    errors: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  console.log('Form submitted:', formData);
  
  // Validate form data
  const { isValid, fieldErrors } = validateForm(formData);
  
  if (!isValid) {
    return res.status(400).render('form', {
      title: 'Contact Information',
      data: formData,
      errors: fieldErrors
    });
  }
  
  // Save submission to database
  saveSubmission(formData);
  
  // Redirect to thank you page
  return res.status(302).redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You'
  });
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to see the form`);
  });
  
  // Handle graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    saveDatabase();
    if (db) {
      (db as { close: () => void }).close();
      console.log('Database connection closed');
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});