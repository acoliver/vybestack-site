import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}



const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
};

const validateForm = (values: FormValues): string[] => {
  const errors: string[] = [];
  
  if (!values.firstName.trim()) {
    errors.push('First name is required');
  }
  
  if (!values.lastName.trim()) {
    errors.push('Last name is required');
  }
  
  if (!values.streetAddress.trim()) {
    errors.push('Street address is required');
  }
  
  if (!values.city.trim()) {
    errors.push('City is required');
  }
  
  if (!values.stateProvince.trim()) {
    errors.push('State / Province / Region is required');
  }
  
  if (!values.postalCode.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(values.postalCode)) {
    errors.push('Invalid postal / zip code format');
  }
  
  if (!values.country.trim()) {
    errors.push('Country is required');
  }
  
  if (!values.email.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(values.email)) {
    errors.push('Invalid email format');
  }
  
  if (!values.phone.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(values.phone)) {
    errors.push('Invalid phone number format');
  }
  
  return errors;
};

app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(values);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { 
      errors, 
      values 
    });
  }
  
  const { initDatabase, insertSubmission, closeDatabase } = await import('./database.js');
  const db = await initDatabase();
  insertSubmission(db, values);
  closeDatabase(db);
  
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { firstName: 'Friend' });
});

const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing server');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export default app;
