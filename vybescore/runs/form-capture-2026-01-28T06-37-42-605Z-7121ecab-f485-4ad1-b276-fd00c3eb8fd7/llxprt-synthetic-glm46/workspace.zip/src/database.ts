import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have proper type definitions
import sqlite3InitModule from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Database type interface
interface Database {
  exec: (sql: string) => void;
  prepare: (sql: string) => Statement;
  export: () => Uint8Array;
  close: () => void;
}

interface Statement {
  bind: (values: unknown[]) => void;
  run: () => void;
  free: () => void;
}



const getDatabasePath = (): string => {
  return path.join(__dirname, '..', 'data', 'submissions.sqlite');
};

const ensureDataDirectory = async (): Promise<void> => {
  const dataDir = path.join(__dirname, '..', 'data');
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }
};

const readSchema = async (): Promise<string> => {
  const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
  return await fs.readFile(schemaPath, 'utf-8');
};

const initDatabase = async (): Promise<Database> => {
  await ensureDataDirectory();
  
  const SQL = await sqlite3InitModule();
  const dbPath = getDatabasePath();
  
  try {
    const dbFile = await fs.readFile(dbPath);
    return new SQL.Database(dbFile);
  } catch {
    const db = new SQL.Database();
    const schema = await readSchema();
    
    const statements = schema.split(';').map(stmt => stmt.trim()).filter(stmt => stmt.length > 0);
    statements.forEach(statement => {
      if (statement.trim()) {
        db.exec(statement);
      }
    });
    
    return db;
  }
};

const saveDatabase = async (db: Database): Promise<void> => {
  const data = db.export();
  await ensureDataDirectory();
  await fs.writeFile(getDatabasePath(), Buffer.from(data));
};

const insertSubmission = (db: Database, values: FormValues): void => {
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.bind([
    values.firstName,
    values.lastName,
    values.streetAddress,
    values.city,
    values.stateProvince,
    values.postalCode,
    values.country,
    values.email,
    values.phone
  ] as unknown[]);
  
  stmt.run();
  stmt.free();
  saveDatabase(db);
};

const closeDatabase = (db: Database): void => {
  db.close();
};

export { initDatabase, insertSubmission, closeDatabase, FormValues };