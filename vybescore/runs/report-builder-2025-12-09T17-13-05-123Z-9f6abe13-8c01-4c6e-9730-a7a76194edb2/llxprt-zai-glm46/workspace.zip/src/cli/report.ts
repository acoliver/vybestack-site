#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { validateReportData } from '../utils.js';
import type { ReportRenderer } from '../types.js';

const renderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(): {
  inputFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  
  let format = '';
  let outputFile: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        outputFile = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (args[i].startsWith('--')) {
          console.error(`Error: Unknown option ${args[i]}`);
          process.exit(1);
        }
        break;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputFile, includeTotals };
}

function main(): void {
  try {
    const { inputFile, format, outputFile, includeTotals } = parseArguments();

    if (!renderers[format]) {
      console.error(`Error: Unsupported format "${format}"`);
      process.exit(1);
    }

    let fileContent: string;
    try {
      fileContent = fs.readFileSync(inputFile, 'utf8');
    } catch (error) {
      console.error(`Error: Cannot read file "${inputFile}"`);
      process.exit(1);
    }

    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${inputFile}"`);
      process.exit(1);
    }

    const reportData = validateReportData(data);
    const output = renderers[format](reportData, { includeTotals });

    if (outputFile) {
      fs.writeFileSync(outputFile, output, 'utf8');
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
