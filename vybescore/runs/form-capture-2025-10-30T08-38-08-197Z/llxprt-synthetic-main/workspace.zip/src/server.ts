import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

// @ts-expect-error - We'll type this ourselves
interface Database {
  run: (sql: string, params?: unknown[]) => unknown;
  prepare: (sql: string) => Statement;
  export: () => Uint8Array;
  close: () => void;
}

// @ts-expect-error - We'll type this ourselves
interface Statement {
  run: (params?: unknown[]) => unknown;
  free: () => void;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ServerState {
  db: Database | null;
  server: express.Application | null;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const serverState: ServerState = {
  db: null,
  server: null
};

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
  
  let db: Database;
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Load existing database or create a new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    // Initialize the database schema
    const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
  }
  
  return db;
}

function saveDatabase(db: Database): void {
  const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-(),]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with optional spaces
  // This covers UK formats like "SW1A 1AA" and Argentine formats like "C1000" or "B1675"
  const postalCodeRegex = /^[a-zA-Z0-9\s]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check required fields
  if (!formData.firstName.trim()) {
    errors.push('First name is required');
  }
  
  if (!formData.lastName.trim()) {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress.trim()) {
    errors.push('Street address is required');
  }
  
  if (!formData.city.trim()) {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince.trim()) {
    errors.push('State / Province / Region is required');
  }
  
  if (!formData.postalCode.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Invalid postal code format');
  }
  
  if (!formData.country.trim()) {
    errors.push('Country is required');
  }
  
  if (!formData.email.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Invalid email format');
  }
  
  if (!formData.phone.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Invalid phone number format');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

async function startServer(): Promise<void> {
  const app = express();
  serverState.server = app;
  
  // Initialize database
  try {
    serverState.db = await initializeDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Serve static files
  app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
  
  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, 'templates'));
  
  // Form route
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });
  
  // Form submission route
  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.render('form', {
        errors: validation.errors,
        values: formData
      });
    }
    
    // Insert into database
    try {
      const stmt = serverState.db!.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database to file
      saveDatabase(serverState.db!);
      
      // Redirect to thank you page
      res.redirect('/thank-you?firstName=' + encodeURIComponent(formData.firstName));
    } catch (error) {
      console.error('Database error:', error);
      return res.render('form', {
        errors: ['Something went wrong. Please try again.'],
        values: formData
      });
    }
  });
  
  // Thank you route
  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'there';
    res.render('thank-you', {
      firstName: decodeURIComponent(firstName)
    });
  });
  
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      if (serverState.db) {
        serverState.db.close();
      }
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});