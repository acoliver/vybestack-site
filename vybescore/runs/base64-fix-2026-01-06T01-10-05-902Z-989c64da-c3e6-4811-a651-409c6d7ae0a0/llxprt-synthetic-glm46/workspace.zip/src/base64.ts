

/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 alphabet with or without padding.
 * Rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate input contains only Base64 characters (and optional padding)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check padding is valid
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const nonPaddingAfter = input.slice(paddingIndex + 1).replace(/=/g, '');
    if (nonPaddingAfter.length > 0) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
    
    // Padding can only be 1 or 2 characters
    const paddingCount = input.length - paddingIndex;
    if (paddingCount > 3) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }

  

  try {
    // Try to decode using standard Base64
    try {
      return Buffer.from(input, 'base64').toString('utf8');
    } catch (error) {
      // If that fails and there was no padding, try with padding
      if (!input.endsWith('=') && (input.length % 4) !== 0) {
        const padded = input + '='.repeat(4 - (input.length % 4));
        return Buffer.from(padded, 'base64').toString('utf8');
      }
      throw new Error('Failed to decode Base64 input');
    }
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
