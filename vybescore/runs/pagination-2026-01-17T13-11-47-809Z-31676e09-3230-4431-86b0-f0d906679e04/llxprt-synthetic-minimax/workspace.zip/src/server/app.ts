import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Validate query parameters
      if (pageParam !== undefined && (!Number.isFinite(Number(pageParam)) || Number(pageParam) <= 0)) {
        return res.status(400).json({ error: 'Page must be a positive number' });
      }
      if (limitParam !== undefined && (!Number.isFinite(Number(limitParam)) || Number(limitParam) <= 0)) {
        return res.status(400).json({ error: 'Limit must be a positive number' });
      }

      // Set reasonable bounds to prevent excessive values
      const limit = limitParam ? Math.min(Number(limitParam), 100) : undefined;
      if (limitParam && Number(limitParam) > 100) {
        return res.status(400).json({ error: 'Limit cannot exceed 100' });
      }

      const payload = listInventory(db, { page: Number(pageParam), limit });
      res.json(payload);
    } catch (error) {
      res.status(400).json({ error: 'Invalid query parameters' });
    }
  });

  return app;
}
