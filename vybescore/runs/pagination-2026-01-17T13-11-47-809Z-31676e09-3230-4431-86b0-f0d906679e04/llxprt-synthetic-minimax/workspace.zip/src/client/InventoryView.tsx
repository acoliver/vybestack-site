import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  limit, 
  total, 
  hasNext, 
  onPageChange 
}: { 
  page: number; 
  limit: number; 
  total: number; 
  hasNext: boolean; 
  onPageChange: (newPage: number) => void;
}): JSX.Element {
  const totalPages = Math.ceil(total / limit);
  const isFirstPage = page <= 1;
  const isLastPage = totalPages === 0 || page >= totalPages;

  return (
    <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', alignItems: 'center' }}>
      <button 
        onClick={() => onPageChange(page - 1)}
        disabled={isFirstPage}
        aria-disabled={isFirstPage}
      >
        Previous
      </button>
      
      <span>
        Page {page} of {totalPages || 1} ({total} total items)
      </span>
      
      <button 
        onClick={() => onPageChange(page + 1)}
        disabled={!hasNext || isLastPage}
        aria-disabled={!hasNext || isLastPage}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePageChange = (newPage: number): void => {
    if (newPage >= 1) {
      setCurrentPage(newPage);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        page={data.page}
        limit={data.limit}
        total={data.total}
        hasNext={data.hasNext}
        onPageChange={handlePageChange}
      />
    </section>
  );
}
