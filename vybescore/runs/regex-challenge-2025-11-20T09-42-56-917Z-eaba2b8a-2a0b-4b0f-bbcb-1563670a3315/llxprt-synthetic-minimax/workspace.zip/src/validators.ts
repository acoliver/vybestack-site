export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implements Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  value = value.trim();
  
  // Basic structure check: must have exactly one @ and at least one dot after @
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for common invalid patterns
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dots in local part
  const [localPart, domainPart] = value.split('@');
  if (localPart.endsWith('.') || localPart.startsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain (but allow in subdomain after first level)
  const domainParts = domainPart.split('.');
  for (let i = 0; i < domainParts.length; i++) {
    if (domainParts[i].includes('_') && i === 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, 11 for +1)
  if (cleanNumber.length < 10 || cleanNumber.length > 11) {
    return false;
  }
  
  // Handle 11-digit numbers starting with 1
  if (cleanNumber.length === 11 && cleanNumber.startsWith('1')) {
    // Remove the leading 1 for validation
    const numberWithoutCountry = cleanNumber.substring(1);
    
    // Check area code (first 3 digits) - first digit cannot be 0 or 1
    const areaCodeStr = numberWithoutCountry.substring(0, 3);
    const firstDigit = parseInt(areaCodeStr[0]);
    if (firstDigit < 2 || firstDigit > 9) {
      return false;
    }
    
    return numberWithoutCountry.length === 10;
  }
  
  // Handle 10-digit numbers
  if (cleanNumber.length === 10) {
    // Check area code (first 3 digits) - first digit cannot be 0 or 1
    const areaCodeStr = cleanNumber.substring(0, 3);
    const firstDigit = parseInt(areaCodeStr[0]);
    if (firstDigit < 2 || firstDigit > 9) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters temporarily for counting
  const digitsOnly = value.replace(/\D/g, '');

  // Pattern breakdown:
  // Optional +54 (country code)
  // Optional 0 (trunk prefix)
  // Optional 9 (mobile indicator)
  // 2-4 digit area code (first digit 1-9)
  // 6-8 digit subscriber number
  // Total should be 10-13 digits

  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }

  // Clean up separators and check the actual format with spaces/hyphens preserved
  // The pattern allows for optional spaces/hyphens between all number groups
  const phonePattern = /^(\+54)?\s*0?\s*9?\s*([1-9]\d{1,3})\s*[\d\s-]{6,8}$/;
  const match = value.trim().match(phonePattern);

  if (!match) {
    return false;
  }

  // Extract area code and clean subscriber number
  const areaCode = parseInt(match[2]);
  const fullNumberDigitsOnly = value.replace(/\D/g, '');

  // Validate area code range (2-4 digits, first digit 1-9)
  if (areaCode < 2 || areaCode > 9999) {
    return false;
  }

  // Calculate subscriber number length correctly
  let subscriberLength = fullNumberDigitsOnly.length;
  
  // Subtract country code if present
  if (fullNumberDigitsOnly.startsWith('54')) {
    subscriberLength -= 2;
  }
  
  // Subtract area code length
  subscriberLength -= match[2].length;

  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }

  // Additional check: when country code is omitted, must start with trunk prefix
  if (!fullNumberDigitsOnly.startsWith('54')) {
    const trimmed = value.trim();
    if (!trimmed.startsWith('0')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Name cannot be empty or too short
  if (trimmed.length < 2 || trimmed.length > 100) {
    return false;
  }
  
  // Pattern for valid names:
  // - Unicode letters (including accents)
  // - Spaces
  // - Apostrophes ('`)
  // - Hyphens (-)
  // - May have multiple parts (first name, last name, etc.)
  const namePattern = /^[\p{L}\s'’-]+$/u;
  
  if (!namePattern.test(trimmed)) {
    return false;
  }
  
  // Additional checks for invalid patterns:
  // Cannot be all spaces or separators
  if (!trimmed.match(/[\p{L}]/u)) {
    return false;
  }
  
  // Cannot start or end with certain characters
  if (trimmed.match(/^[\s'’-]|[\s'’-]$/)) {
    return false;
  }
  
  // Check for obvious fake names like "X Æ A-12"
  if (trimmed.match(/[ÆØÅæøå]/) && !trimmed.match(/^[A-Za-z\s'’-]+$/)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit cards using Luhn checksum and proper prefix/length validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits is typical range)
  if (cleanNumber.length < 13 || cleanNumber.length > 19) {
    return false;
  }
  
  // Must start with a valid digit
  if (!/^[0-9]/.test(cleanNumber)) {
    return false;
  }
  
  // Card type validation (prefixes and lengths)
  let isValidType = false;
  
  // Visa: 16 digits, starts with 4
  if (cleanNumber.length === 16 && cleanNumber.startsWith('4')) {
    isValidType = true;
  }
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  else if (cleanNumber.length === 16) {
    const prefix = parseInt(cleanNumber.substring(0, 2));
    const first4 = parseInt(cleanNumber.substring(0, 4));
    if ((prefix >= 51 && prefix <= 55) || (first4 >= 2221 && first4 <= 2720)) {
      isValidType = true;
    }
  }
  // American Express: 15 digits, starts with 34 or 37
  else if (cleanNumber.length === 15 && (cleanNumber.startsWith('34') || cleanNumber.startsWith('37'))) {
    isValidType = true;
  }
  // Discover: 16 digits, starts with 6011, 65, or 644-649
  if (!isValidType && cleanNumber.length === 16) {
    const prefix3 = parseInt(cleanNumber.substring(0, 3));
    const prefix2 = parseInt(cleanNumber.substring(0, 2));
    if (cleanNumber.startsWith('6011') || prefix2 === 65 || (prefix3 >= 644 && prefix3 <= 649)) {
      isValidType = true;
    }
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanNumber);
}