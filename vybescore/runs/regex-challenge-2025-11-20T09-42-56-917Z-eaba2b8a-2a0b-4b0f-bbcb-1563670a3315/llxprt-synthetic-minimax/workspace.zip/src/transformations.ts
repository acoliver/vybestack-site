/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }

  // First, normalize multiple spaces to single spaces
  const normalized = text.replace(/\s+/g, ' ');
  
  // Use regex to find sentence boundaries and capitalize
  // Pattern: start of string OR after .?! followed by optional spaces and uppercase/digit
  return normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // Simple pattern: match everything after URL scheme until whitespace or punctuation
  const urlPattern = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s]+/gi;
  
  const urls = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  const cleanedUrls = urls.map(url => {
    let cleanUrl = url;
    
    // Remove trailing punctuation but keep URLs that end with valid characters
    cleanUrl = cleanUrl.replace(/[.,;:!?]+$/g, '');
    
    // Ensure www URLs have http:// prefix
    if (cleanUrl.startsWith('www.')) {
      cleanUrl = 'http://' + cleanUrl;
    }
    
    return cleanUrl;
  });
  
  return cleanedUrls;
}

/**
 * Replace http:// with https:// while preserving existing https:// URLs.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https:// but don't touch existing https://
  // Pattern: word boundary, http://, followed by valid URL characters
  return text.replace(/\bhttp:\/\/[^\s<>"'()[\]\\.,;!?]+/gi, (match) => {
    return match.replace(/^http:/, 'https:');
  });
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Pattern to match http URLs - capture the full URL after http://
  const httpUrlPattern = /\bhttp:\/\/([^\s<>"'()[\]\\,;!?]+)/gi;
  
  return text.replace(httpUrlPattern, (match, url) => {
    // Check if this is a docs URL
    const isDocsUrl = url.includes('/docs/');
    
    if (isDocsUrl) {
      // Extract domain and path correctly
      const firstSlashIndex = url.indexOf('/');
      const domain = firstSlashIndex > -1 ? url.substring(0, firstSlashIndex) : url;
      const path = firstSlashIndex > -1 ? url.substring(firstSlashIndex) : '';
      
      // Check for dynamic hints that should prevent host rewrite
      const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.domain.com
        const docsDomain = 'docs.' + domain;
        return 'https://' + docsDomain + path;
      }
    }
    
    // Default: just upgrade to https
    return match.replace(/^http:/, 'https:');
  });
}

/**
 * Extract the year from a date string in mm/dd/yyyy format.
 * Returns the four-digit year or 'N/A' if format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Simple day validation (1-31, not accounting for month variations)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate that year is reasonable (1000-9999)
  const yearNum = parseInt(year);
  if (yearNum < 1000 || yearNum > 9999) {
    return 'N/A';
  }
  
  return year;
}