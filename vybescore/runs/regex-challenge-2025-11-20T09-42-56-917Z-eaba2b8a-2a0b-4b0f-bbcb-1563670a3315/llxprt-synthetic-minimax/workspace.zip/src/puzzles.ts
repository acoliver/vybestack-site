/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Create pattern to find words starting with prefix
  // Using word boundaries to ensure we get complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9_-]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(exc => exc.toLowerCase());
  const result = matches.filter(match => 
    !lowerExceptions.includes(match.toLowerCase())
  );
  
  return result;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use match with global flag to find all occurrences
  const regex = new RegExp(escapedToken, 'gi');
  const matches = [];
  let match;
  
  // Use exec in a loop to find all matches with their positions
  while ((match = regex.exec(text)) !== null) {
    const matchIndex = match.index;
    // Check if this match is preceded by a digit and not at the beginning
    if (matchIndex > 0) {
      const prevChar = text[matchIndex - 1];
      if (/\d/.test(prevChar)) {
        // Return the full match including the digit
        matches.push(text.substring(matchIndex - 1, matchIndex + match[0].length));
      }
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like "abab", "1212", etc.)
  // Look for any 2-character sequence repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    if (seq1 === seq2) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIPv6 = /(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}/;
  
  // Compressed IPv6: uses :: for consecutive zero groups
  const compressedIPv6 = /[a-fA-F0-9]*::[a-fA-F0-9]*/;
  
  // IPv4-mapped IPv6
  const ipv4MappedIPv6 = /::(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check for IPv4 addresses to exclude them (pure IPv4 addresses should return false)
  const ipv4Pattern = /(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])/;
  
  // If it's only an IPv4 address, return false
  const cleanValue = value.replace(/\s+/g, ' ').trim();
  if (ipv4Pattern.test(cleanValue) && !compressedIPv6.test(cleanValue)) {
    // Make sure it's not an IPv4-mapped IPv6
    return false;
  }

  // Check for any IPv6 pattern
  return fullIPv6.test(cleanValue) || compressedIPv6.test(cleanValue) || ipv4MappedIPv6.test(cleanValue);
}