/**
 * Encode plain text to Base64 using the standard alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input format and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  // Check for invalid characters in standard Base64
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Validate padding is correct (only allowed at the end and in proper amounts)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const padding = input.substring(paddingIndex);
    if (!/^(=|==)$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }
  
  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    // Verify the decoded content is valid UTF-8
    if (input.length > 0 && decoded.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
