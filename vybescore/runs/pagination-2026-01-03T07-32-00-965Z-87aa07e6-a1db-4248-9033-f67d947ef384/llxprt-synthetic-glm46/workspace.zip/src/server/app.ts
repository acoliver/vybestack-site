import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined = undefined;
    if (pageParam !== undefined) {
      if (!/^\d+$/.test(pageParam)) {
        return res.status(400).json({ error: 'Page parameter must be a positive integer' });
      }
      page = Number(pageParam);
      if (page < 1) {
        return res.status(400).json({ error: 'Page parameter must be greater than 0' });
      }
    }

    // Validate limit parameter
    let limit: number | undefined = undefined;
    if (limitParam !== undefined) {
      if (!/^\d+$/.test(limitParam)) {
        return res.status(400).json({ error: 'Limit parameter must be a positive integer' });
      }
      limit = Number(limitParam);
      if (limit < 1) {
        return res.status(400).json({ error: 'Limit parameter must be greater than 0' });
      }
      // Set a reasonable maximum limit to prevent excessive data transfer
      if (limit > 100) {
        return res.status(400).json({ error: 'Limit parameter cannot exceed 100' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
