import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('views', path.join(__dirname, '../views'));
app.set('view engine', 'ejs');

// Database setup
let db: Database;
const dbPath = path.join(__dirname, '../../data/submissions.sqlite');
const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');

async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => {
      // Calculate the correct path from dist/server.js to node_modules/sql.js/dist/
      const wasmPath = path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      console.log('Looking for WASM file at:', wasmPath);
      return wasmPath;
    },
  });

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  let buffer: Uint8Array;
  if (fs.existsSync(dbPath)) {
    const dbFile = fs.readFileSync(dbPath);
    buffer = new Uint8Array(dbFile);
  } else {
    buffer = new Uint8Array();
  }

  db = new SQL.Database(buffer);

  // Run schema if table doesn't exist
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schema);
}

function saveDatabase(): void {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

// Form field validation interface
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) errors.firstName = 'First name is required';
  if (!data.lastName.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city.trim()) errors.city = 'City is required';
  if (!data.stateProvinceRegion.trim()) errors.stateProvinceRegion = 'State/Province/Region is required';
  if (!data.postalZipCode.trim()) errors.postalZipCode = 'Postal/ZIP code is required';
  if (!data.country.trim()) errors.country = 'Country is required';
  if (!data.email.trim()) errors.email = 'Email is required';
  if (!data.phone.trim()) errors.phone = 'Phone number is required';

  // Email validation (simple regex)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (digits, spaces, parentheses, dashes, leading +)
  if (data.phone && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalZipCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalZipCode)) {
    errors.postalZipCode = 'Please enter a valid postal/ZIP code';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: {},
    formData: {},
    pageTitle: 'Contact Us'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalZipCode: req.body.postalZipCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('index', {
      errors,
      formData,
      pageTitle: 'Contact Us'
    });
  }

  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region,
        postal_zip_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalZipCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();
    saveDatabase();

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('index', {
      errors: { general: 'An error occurred while saving your information. Please try again.' },
      formData,
      pageTitle: 'Contact Us'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    pageTitle: 'Thank You'
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await initDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the application`);
    });
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

startServer();