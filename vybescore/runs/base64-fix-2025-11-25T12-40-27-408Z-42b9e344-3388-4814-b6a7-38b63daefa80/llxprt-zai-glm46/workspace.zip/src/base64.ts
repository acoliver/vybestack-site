/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check for clearly invalid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for invalid padding structure
  const trimmed = input.trim();
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = trimmed.substring(paddingIndex);
    // Padding can only be 1 or 2 '=' characters and must be at the end
    if (padding.length > 2 || !/^[=]+$/.test(padding)) {
      throw new Error('Invalid Base64 input: invalid padding structure');
    }
    // If there's padding, the total length must be a multiple of 4
    if (trimmed.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length with padding');
    }
  } else {
    // Without padding, length should ideally be a multiple of 4,
    // but we're more lenient as long as the input can be properly decoded
    // Many real-world Base64 strings omit padding
    if (trimmed.length % 4 === 1) {
      // Length of % 4 === 1 is always invalid for Base64
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Additional validation: ensure the decoded result contains only valid Unicode
    if (result.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
