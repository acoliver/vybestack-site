#!/usr/bin/env node

import { readFileSync } from 'fs';
import { writeFile } from 'fs/promises';
import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(): { dataFile: string; options: CliOptions } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: report-cli <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  // Default options
  const options: CliOptions = {
    format: '',
    output: undefined,
    includeTotals: false,
  };
  
  // Parse options
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      options.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataFile, options };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be array)');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "label" field (must be string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "amount" field (must be number)`);
    }
  }
  
  return obj as unknown as ReportData;
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs();
    
    // Check if format is supported
    if (!formatters[options.format]) {
      console.error(`Error: Unsupported format "${options.format}"`);
      process.exit(1);
    }
    
    // Read and parse JSON file
    let data: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${dataFile}": ${error.message}`);
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: "${dataFile}"`);
      } else {
        console.error(`Error reading file "${dataFile}": ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }
    
    // Validate data structure
    const reportData = validateReportData(data);
    
    // Render report
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals,
    };
    
    const formatter = formatters[options.format];
    const output = formatter(reportData, renderOptions);
    
    // Write output
    if (options.output) {
      writeFile(options.output, output, 'utf-8')
        .then(() => {
          console.log(`Report written to ${options.output}`);
        })
        .catch((error) => {
          console.error(`Error writing to file "${options.output}": ${error instanceof Error ? error.message : String(error)}`);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run the CLI
main();
