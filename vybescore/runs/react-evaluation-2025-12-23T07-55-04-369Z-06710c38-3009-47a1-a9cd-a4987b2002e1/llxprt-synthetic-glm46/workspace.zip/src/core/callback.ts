/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    currentObservers: new Set(),
  }
  
  // Register observer to track dependencies and establish relationships
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it's observing
    // This prevents memory leaks
    observer.currentObservers?.clear()
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
