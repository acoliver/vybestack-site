/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // \b ensures word boundary, so we match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    
    // Check if any exception matches this word
    return !exceptions.some(exception => 
      lowerWord === exception.toLowerCase()
    );
  });
  
  // Remove duplicates while preserving order
  const uniqueMatches = [...new Set(filteredMatches)];
  
  return uniqueMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex to match digit followed by token
  // We want to match the full "digit + token" sequence
  const pattern = new RegExp(`\\d${token}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter matches to ensure the token is indeed at the end
  // (since our regex includes the digit, we need to verify the token is complete)
  const filteredMatches = matches.filter(match => {
    // Check if the match ends with the token
    return match.endsWith(token);
  });
  
  return filteredMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length requirement: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace - should not contain any
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"|,.<>?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab" should fail)
  // Look for patterns where 2+ characters repeat immediately
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if IPv4 pattern exists - if so, exclude to ensure no false positives
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Comprehensive IPv6 pattern including shorthand notation
  // IPv6 addresses can be:
  // - Full: 8 groups of 4 hex digits separated by colons
  // - Shorthand: Use :: to represent multiple zero groups
  // - Mixed: IPv4-mapped IPv6 addresses
  
  const ipv6Pattern = /\b(?:(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?:%[0-9a-zA-Z]+)?\b/i;
  
  // Check for IPv6 pattern
  const hasIpv6 = ipv6Pattern.test(value);
  
  // If no IPv6 found, return false
  if (!hasIpv6) {
    return false;
  }
  
  // Additional check: ensure it's not just an IPv4 address
  // This prevents false positives where IPv4 might be mistaken
  if (ipv4Pattern.test(value)) {
    // Check if this is purely an IPv4 address or contains IPv6
    // IPv4 embedded in IPv6 (like ::ffff:192.168.1.1) should still return true
    // Pure IPv4 should return false
    
    // Simple check: pure IPv4 addresses don't contain colons
    // IPv6 addresses must contain at least one colon (unless using :: shorthand)
    const hasColons = value.includes(':');
    
    if (!hasColons) {
      // No colons means this is likely a pure IPv4, not IPv6
      return false;
    }
  }
  
  return true;
}
