/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing - collapse multiple spaces but preserve sentence structure
  let result = text.trim();
  
  // Capitalize first character of the text
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Pattern to match sentence endings followed by lowercase/start of new sentence
  // This regex finds positions where .?! are followed by lowercase letters or start of text
  // and ensures proper spacing
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, lowercase) => {
    return punctuation + lowercase.toUpperCase();
  });
  
  // Handle cases where sentences are not properly spaced
  // Insert space after sentence endings if missing
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Collapse multiple spaces back to single space
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  // Matches http:// or https:// followed by domain and optional path
  const urlRegex = /\bhttps?:\/\/[^\s<>"'()]+[^\s<>"'.,!?;:')]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    let cleanUrl = url;
    while (cleanUrl.length > 0 && /[.,!?;:)]$/.test(cleanUrl.charAt(cleanUrl.length - 1))) {
      cleanUrl = cleanUrl.slice(0, -1);
    }
    return cleanUrl;
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, leaving https:// untouched
  // Use word boundaries to avoid partial replacements
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const urlRegex = /\bhttp:\/\/[^\s<>"'()]+/gi;
  
  return text.replace(urlRegex, (match) => {
    try {
      // Simple URL parsing - we'll handle this with regex since we can't assume URL constructor
      const parts = match.match(/^http:\/\/([^/]+)(.*)$/);
      
      if (!parts) {
        // If parsing fails, just upgrade scheme
        return match.replace(/^http:\/\//, 'https://');
      }
      
      const host = parts[1];
      const path = parts[2] || '';
      
      // Check if path contains dynamic hints that skip host rewrite
      const hasDynamicHints = /(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
      
      let newUrl = 'https://' + host;
      
      // Only rewrite host for /docs/ paths without dynamic hints
      if (path.startsWith('/docs/') && !hasDynamicHints) {
        // Extract original domain and prepend docs.
        newUrl = 'https://docs.' + host + path;
      } else {
        // Keep original host but upgrade scheme
        newUrl += path;
      }
      
      return newUrl;
    } catch {
      // Fallback: just upgrade scheme
      return match.replace(/^http:\/\//, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31, with basic range check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic day validation per month (not perfect but reasonable)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Validate leap year for February
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    if (yearNum % 4 !== 0 || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
