export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  value = value.trim();
  
  // Basic structure check - must have exactly one @ and parts
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for domains with underscores
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Additional validation for domain structure
  const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  
  // Check for optional +1 prefix - pattern should match 212-555-7890
  const phoneRegex = /^\+?1?[\s-]*\(?([2-9][0-9]{2})\)?[\s-]*([2-9][0-9]{2})[\s-]*([0-9]{4})$/;
  
  // Test the cleaned number
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract parts to verify area code and exchange code don't start with 0 or 1
  const matches = cleaned.match(/^\+?1?[\s-]*\(?([2-9][0-9]{2})\)?[\s-]*([2-9][0-9]{2})[\s-]*([0-9]{4})$/);
  
  if (!matches) {
    return false;
  }
  
  const areaCode = matches[1];
  const exchangeCode = matches[2];
  
  // Area code and exchange code must not start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1' || exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  let cleaned = value.replace(/[\s-]/g, '');
  
  // Remove leading + if present
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.slice(1);
  }
  
  // Pattern breakdown:
  // Optional +54 (country code)
  // Optional 9 (mobile indicator) 
  // Optional 0 (trunk prefix) - but this must come immediately before area code
  // Area code: 2-4 digits, first 1-9
  // Subscriber number: remaining digits (6-8 total)
  
  // Check if starts with 54 (country code)
  const hasCountryCode = cleaned.startsWith('54');
  let remaining = hasCountryCode ? cleaned.slice(2) : cleaned;
  
  if (hasCountryCode) {
    // After +54, can have 9 (mobile) then area code
    if (remaining.startsWith('9')) {
      remaining = remaining.slice(1);
    }
    // Now should have area code + subscriber
    // Area code: 2-4 digits, first 1-9
    const areaCodeMatch = remaining.match(/^([1-9][0-9]{1,3})(.+)$/);
    if (!areaCodeMatch) {
      return false;
    }
    
    const areaCode = areaCodeMatch[1];
    const subscriber = areaCodeMatch[2];
    
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    // Subscriber must be 6-8 digits total after area code
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    // All remaining must be digits
    if (!/^\d+$/.test(subscriber)) {
      return false;
    }
    
    return true;
  } else {
    // No country code - must start with 0 (trunk prefix)
    if (!remaining.startsWith('0')) {
      return false;
    }
    
    remaining = remaining.slice(1); // Remove trunk prefix
    
    // Now should have area code + subscriber
    const areaCodeMatch = remaining.match(/^([1-9][0-9]{1,3})(.+)$/);
    if (!areaCodeMatch) {
      return false;
    }
    
    const areaCode = areaCodeMatch[1];
    const subscriber = areaCodeMatch[2];
    
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    // Subscriber must be 6-8 digits total after area code
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    // All remaining must be digits
    if (!/^\d+$/.test(subscriber)) {
      return false;
    }
    
    return true;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  value = value.trim();
  
  if (value.length === 0) {
    return false;
  }
  
  // Check for prohibited elements: digits and X Æ A-12 style names
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for the specific pattern "X Æ A-12" style (this would catch problematic names)
  if (/^X\s*Æ\s*A-12/.test(value)) {
    return false;
  }
  
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Pattern: letters (including accents), spaces, apostrophes, hyphens
  const nameRegex = /^[a-zA-ZÀ-ÖØ-öø-ÿ' -]+$/;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check: should not start or end with separator unless it's part of a compound name
  // Allow names like "John-Paul", "Mary Anne", but reject just separators
  if (value === '-' || value === "'" || value === ' ') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check prefixes for major card types
  const isVisa = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const isMastercard = /^5[1-5][0-9]{14}$/; // includes 51-55
  const isAmex = /^3[47][0-9]{13}$/; // 34 or 37 with length 15
  
  // Also handle newer Mastercard range 2221-2720
  const isMastercardNew = /^2[2-7][0-9]{14}$/;
  
  // Check if it matches any valid card pattern
  const isValidType = isVisa.test(cleaned) || isMastercard.test(cleaned) || 
                     isAmex.test(cleaned) || isMastercardNew.test(cleaned);
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
