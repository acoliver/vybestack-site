export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email regex that covers most cases but avoids the pitfalls
  // of overly complex regex patterns
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional checks to reject invalid forms
  if (value.includes('..')) return false; // Reject double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // Reject leading/trailing dots
  
  // Split into local and domain parts
  const [localPart, domainPart] = value.split('@');
  if (!localPart || !domainPart) return false;
  
  // Domain validation
  if (domainPart.includes('_')) return false; // Reject domains with underscores
  if (domainPart.includes('..')) return false; // Reject double dots in domain
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits
  // 10 digits for standard number, 11 if includes country code
  if (digits.length < 10) return false;
  
  // Extract the relevant digits based on length
  let cleanDigits = digits;
  if (digits.length === 11) {
    // If 11 digits, first must be 1 for US country code
    if (digits[0] !== '1') return false;
    cleanDigits = digits.substring(1);
  } else if (digits.length > 11) {
    return false; // Too many digits
  }
  
  // At this point, should have exactly 10 digits
  if (cleanDigits.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = cleanDigits.substring(0, 3);
  
  // Area code can't start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if the format matches one of the valid US phone patterns
  const usPhoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all whitespace and hyphens for validation, but not plus signs
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone patterns
  const argentinePhoneRegex = /^(\+54|0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = argentinePhoneRegex.exec(normalized);
  
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // If country code is present, it must be +54
  if (countryCode && countryCode !== '+54' && countryCode !== '0') return false;
  
  // If country code is absent, the number must start with trunk prefix 0
  if (!countryCode && !normalized.startsWith('0')) return false;
  
  // Area code validation (2-4 digits, starting with 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Regex that allows:
  // - Unicode letters (\p{L})
  // - Accents and other marks (\p{M})
  // - Apostrophes (')
  // - Hyphens (-)
  // - Spaces ( )
  // But rejects:
  // - Digits
  // - Symbols, including weird combinations like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional check to reject names that contain excessive symbols
  // For example, names like "X Æ A-12" would contain the "Æ" which is valid,
  // but the combination with digits makes it invalid
  if (/\d/.test(value)) return false;
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isSecond = false;
  
  // Iterate from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = digits[i];
    
    // Double every second digit
    if (isSecond) {
      d = d * 2;
      // If result is greater than 9, subtract 9
      if (d > 9) {
        d = d - 9;
      }
    }
    
    sum += d;
    isSecond = !isSecond;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanCardNumber = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanCardNumber)) return false;
  
  // Basic validation based on common credit card patterns
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55, 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card matches any of the patterns
  const isValidPattern = visaRegex.test(cleanCardNumber) || 
                         mastercardRegex.test(cleanCardNumber) || 
                         amexRegex.test(cleanCardNumber);
  
  if (!isValidPattern) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanCardNumber);
}
