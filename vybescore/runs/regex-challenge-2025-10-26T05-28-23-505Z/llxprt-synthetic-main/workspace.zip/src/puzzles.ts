/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  if (!Array.isArray(exceptions)) return [];
  
  // Create a regex to match words starting with the prefix
  // Word boundary (\b) ensures we match whole words
  const wordRegex = /\b\w+\b/g;
  const matches = text.match(wordRegex) || [];
  
  // Filter words that start with the prefix
  const filtered = matches.filter(word => {
    // Check if word starts with prefix (case-insensitive)
    if (!word.toLowerCase().startsWith(prefix.toLowerCase())) return false;
    
    // Check if word is in exceptions
    return !exceptions.includes(word);
  });
  
  return filtered;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex using lookbehind to match the token when preceded by a digit
  // Negative lookbehind ensures we're not at the start of the string
  // Match the digit and token together
  const tokenRegex = new RegExp(`([0-9])${escapedToken}(?![0-9])`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Include the digit with the token
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length (10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, xyzxyz)
  const repeatedSequenceRegex = /((.{1,3})\2+)/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 pattern: eight groups of hexadecimal digits separated by colons
  // Can include shorthand :: (double colon)
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::/;
  
  // Check for IPv6 pattern matches
  const matches = value.match(ipv6Pattern);
  
  return !!matches;
}