/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Common abbreviations to avoid breaking sentences at
  const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'Mt.', 'e.g.', 'i.e.'];
  
  let result = text;
  
  // First, ensure proper spacing between sentences
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Collapse multiple spaces into a single space
  result = result.replace(/\s+/g, ' ');
  
  // Trim leading and trailing spaces
  result = result.trim();
  
  // Capitalize the first letter of the text
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  // Capitalize after sentence-ending punctuation
  // We'll use a more complex regex that tries to handle abbreviations
  const sentenceRegex = /([.?!])(\s+)([a-z])/g;
  result = result.replace(sentenceRegex, (match, punctuation, space, letter) => {
    // Check if this might be an abbreviation
    const prevText = result.substring(0, result.indexOf(match));
    
    for (const abbr of abbreviations) {
      if (prevText.includes(abbr) && prevText.endsWith(abbr)) {
        return match; // Don't capitalize if it's likely an abbreviation
      }
    }
    
    return punctuation + space + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern that matches most common URL formats
  // Matches http://, https://, and www. protocols
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Pattern to match URLs from example.com
  const exampleUrlRegex = /https?:\/\/example\.com\/([^\s]+)/g;
  
  return text.replace(exampleUrlRegex, (match, path) => {
    // Always upgrade to HTTPS
    let result = 'https://';
    
    // Check if we should rewrite the host
    // Skip if the path contains cgi-bin or has query strings or legacy extensions
    const shouldSkipHostRewrite = path.includes('cgi-bin') || 
                                 path.includes('?') || 
                                 path.includes('&') ||
                                 path.includes('=') ||
                                 /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/.test(path);
    
    if (path.startsWith('docs/') && !shouldSkipHostRewrite) {
      // Rewrite to docs.example.com
      result += 'docs.example.com/' + path;
    } else {
      // Keep the original host
      result += 'example.com/' + path;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy pattern
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // February leap year check (simplified, not considering all leap year rules)
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(year)) {
    if (day < 1 || day > 29) return 'N/A';
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
