import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Database } from 'sql.js';
import type { Express } from 'express';

describe('inventory API', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns default paginated results', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBe(5); // Default limit
    expect(response.body.page).toBe(1); // Default page
    expect(response.body.limit).toBe(5); // Default limit
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('returns the correct slice of data for a mid-page request', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(3);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    // Should return items with IDs 4, 5, 6 (since offset = (2-1)*3 = 3)
    expect(response.body.items[0].id).toBe(4);
    expect(response.body.items[1].id).toBe(5);
    expect(response.body.items[2].id).toBe(6);
  });

  it('validates page parameter rejects non-numeric values', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates page parameter rejects negative values', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates page parameter rejects zero', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates limit parameter rejects non-numeric values', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('validates limit parameter rejects excessive values', async () => {
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('calculates hasNext correctly', async () => {
    // First page with limit 5 should have next
    const page1Response = await request(app).get('/inventory?page=1&limit=5');
    expect(page1Response.body.hasNext).toBe(true);

    // Last page (assuming 15 total items, page 3 with limit 5) should not have next
    const page3Response = await request(app).get('/inventory?page=3&limit=5');
    expect(page3Response.body.hasNext).toBe(false);
  });

  it('returns empty result for page beyond data', async () => {
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.page).toBe(100);
    expect(response.body.hasNext).toBe(false);
  });
});
