import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse and validate parameters
    let page: number | undefined;
    let limit: number | undefined;

    // Validate pagination parameters
    const MAX_PAGE = 1000;
    const MAX_LIMIT = 100;

    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || parsedPage <= 0 || parsedPage > MAX_PAGE || !Number.isInteger(parsedPage)) {
        return res.status(400).json({ 
          error: 'Invalid page parameter. Must be a positive integer between 1 and ' + MAX_PAGE 
        });
      }
      page = parsedPage;
    }

    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || parsedLimit <= 0 || parsedLimit > MAX_LIMIT || !Number.isInteger(parsedLimit)) {
        return res.status(400).json({ 
          error: 'Invalid limit parameter. Must be a positive integer between 1 and ' + MAX_LIMIT 
        });
      }
      limit = parsedLimit;
    }

    // Provide default values for undefined parameters
    const finalPage = page ?? 1;
    const finalLimit = limit ?? 5;

    const payload = listInventory(db, { page: finalPage, limit: finalLimit });
    res.json(payload);
  });

  return app;
}
