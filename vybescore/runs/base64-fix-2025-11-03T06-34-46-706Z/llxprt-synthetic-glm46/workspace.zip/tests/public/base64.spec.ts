import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  // Additional tests to verify padding behavior
  it('encodes 1-byte input with double padding', () => {
    const result = encode('a');
    expect(result).toBe('YQ==');
  });

  it('encodes 2-byte input with single padding', () => {
    const result = encode('ab');
    expect(result).toBe('YWI=');
  });

  it('encodes 3-byte input without padding', () => {
    const result = encode('abc');
    expect(result).toBe('YWJj');
  });

  it('decodes input without padding', () => {
    const result = decode('aGVsbG8');
    expect(result).toBe('hello');
  });

  it('rejects invalid characters', () => {
    expect(() => decode('!invalid!')).toThrow();
  });

  it('rejects incorrect padding', () => {
    expect(() => decode('aGVsbG8===')).toThrow();
  });

  it('decodes simple non-ASCII characters', () => {
    const result = decode('Y2Fmw6k=');
    expect(result).toBe('café');
  });
});
