/**
 * Encode plain text to Base64 using RFC 4648 standard.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Normalize whitespace and validate characters
  const normalized = input.trim().replace(/\s+/g, '');
  
  // Check if input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Special case: if no padding and not a multiple of 4, add padding and try decode
  let paddedInput = normalized;
  if (!normalized.includes('=') && normalized.length % 4 !== 0) {
    // Normalize by adding padding and checking if this creates a valid base64
    paddedInput = normalized + '='.repeat(4 - (normalized.length % 4));
  } else if (normalized.includes('=')) {
    // Check padding logic
    const paddingIndex = normalized.indexOf('=');
    // Padding must only appear at the end
    if (paddingIndex < normalized.length - 2) {
      throw new Error('Invalid Base64 input: incomplete padding');
    }
    // Padding must be 1 or 2 characters
    if (normalized.length - paddingIndex > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    // Valid base64 length with padding must be a multiple of 4
    if (normalized.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
    paddedInput = normalized;
  } else {
    // Length is already a multiple of 4 and no padding
    paddedInput = normalized;
  }
  
  try {
    // Verify that Buffer can actually decode it
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
