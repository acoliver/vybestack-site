// Test script to verify padding behavior
import { encode } from './dist/index.js';

// Test cases with known correct outputs
const testCases = [
  { input: "f", expected: "Zg==" },
  { input: "fo", expected: "Zm8=" },
  { input: "foo", expected: "Zm9v" },
  { input: "foob", expected: "Zm9vYg==" },
  { input: "fooba", expected: "Zm9vYmE=" },
  { input: "foobar", expected: "Zm9vYmFy" },
];

let allPassed = true;
testCases.forEach((test) => {
  const actual = encode(test.input);
  const passed = actual === test.expected;
  console.log(`Input: "${test.input}" -> ${actual} ${passed ? '[OK]' : ''}`);
  if (!passed) {
    console.log(`  Expected: ${test.expected}`);
    allPassed = false;
  }
});

process.exit(allPassed ? 0 : 1);