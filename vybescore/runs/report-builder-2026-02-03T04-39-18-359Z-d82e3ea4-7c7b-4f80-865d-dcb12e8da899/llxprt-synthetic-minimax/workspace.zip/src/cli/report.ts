#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions, CliArguments, SupportedFormat } from '../types/report.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

// Supported formatters registry
const formatters: Record<SupportedFormat, typeof markdownFormatter> = {
  markdown: markdownFormatter,
  text: textFormatter
};

// Parse command line arguments using Node's standard library
function parseArguments(argv: string[]): CliArguments {
  const args: CliArguments = {
    dataFile: '',
    format: 'markdown' as SupportedFormat, // default format
    includeTotals: false
  };

  // Skip first two args (node and script path)
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format' || arg === '-f') {
      const formatArg = argv[i + 1];
      if (formatArg === 'markdown' || formatArg === 'text') {
        args.format = formatArg as SupportedFormat;
        i++; // Skip next arg since we consumed it
      } else {
        throw new Error('Unsupported format');
      }
    } else if (arg === '--output' || arg === '-o') {
      const outputArg = argv[i + 1];
      if (outputArg && !outputArg.startsWith('-')) {
        args.output = outputArg;
        i++; // Skip next arg since we consumed it
      } else {
        throw new Error('Output path must be provided after --output');
      }
    } else if (arg === '--includeTotals' || arg === '-t') {
      args.includeTotals = true;
    } else if (arg.startsWith('-')) {
      // Unknown flag
      throw new Error(`Unknown option: ${arg}`);
    } else {
      // Data file argument
      args.dataFile = arg;
    }
  }

  // Validate required arguments
  if (!args.dataFile) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  if (!args.format) {
    throw new Error('--format option is required');
  }

  return args;
}

// Read and parse JSON data file
function readReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field in JSON data');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field in JSON data');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field in JSON data');
    }
    
    // Validate entries
    data.entries.forEach((entry: unknown, index: number) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Entry ${index + 1}: invalid entry object`);
      }
      
      const { label, amount } = entry as Record<string, unknown>;
      
      if (!label || typeof label !== 'string') {
        throw new Error(`Entry ${index + 1}: missing or invalid "label" field`);
      }
      
      if (typeof amount !== 'number' || isNaN(amount)) {
        throw new Error(`Entry ${index + 1}: missing or invalid "amount" field`);
      }
    });
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    if (typeof error === 'object' && error !== null && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

// Main CLI execution
function main(): void {
  try {
    const args = parseArguments(process.argv);
    
    // Read and validate report data
    const reportData = readReportData(args.dataFile);
    
    // Check if format is supported
    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Unsupported format: ${args.format}`);
      console.error(`Supported formats: ${Object.keys(formatters).join(', ')}`);
      process.exit(1);
    }
    
    // Generate report
    const options: ReportOptions = {
      format: args.format,
      includeTotals: args.includeTotals,
      output: args.output
    };
    
    const report = formatter.format(reportData, options);
    
    // Output report
    if (args.output) {
      writeFileSync(args.output, report, 'utf8');
    } else {
      process.stdout.write(report);
    }
    
  } catch (error) {
    let errorMessage: string;
    if (error instanceof Error) {
      errorMessage = error.message;
    } else if (typeof error === 'string') {
      errorMessage = error;
    } else {
      errorMessage = String(error);
    }
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }
}

// Run CLI if this file is being executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
