import { ReportData, ReportOptions, Formatter } from '../types/report.js';

// Utility function to format amounts as currency
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

// Calculate total from entries
function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

// Text formatter implementation
export const textFormatter: Formatter = {
  format: (data: ReportData, options: ReportOptions): string => {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push(''); // Blank line
    
    // Summary
    lines.push(data.summary);
    lines.push(''); // Blank line
    
    // Entries heading
    lines.push('Entries:');
    
    // Entry bullets
    data.entries.forEach(entry => {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    });
    
    // Optional totals
    if (options.includeTotals) {
      lines.push('');
      const total = calculateTotal(data.entries);
      lines.push(`Total: ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
};