// Shared types for report data and CLI options

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  format: 'markdown' | 'text';
  includeTotals: boolean;
  output?: string;
}

export interface Formatter {
  format: (data: ReportData, options: ReportOptions) => string;
}

export type SupportedFormat = 'markdown' | 'text';

export interface CliArguments {
  dataFile: string;
  format: SupportedFormat;
  includeTotals: boolean;
  output?: string;
}