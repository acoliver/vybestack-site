import { describe, expect, it } from 'vitest';
import { execSync } from 'child_process';
import { writeFileSync, unlinkSync, readFileSync } from 'fs';
import { join } from 'path';

describe('report CLI (public smoke)', () => {
  const cliPath = 'dist/cli/report.js';
  const fixturesPath = 'fixtures/data.json';

  it('renders markdown report with includeTotals', () => {
    const result = execSync(`node ${cliPath} ${fixturesPath} --format markdown --includeTotals`, {
      encoding: 'utf8'
    });
    
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('- **South Region** — $23456.78');
    expect(result).toContain('- **West Region** — $34567.89');
    expect(result).toContain('**Total:** $70370.34');
  });

  it('renders text report with includeTotals', () => {
    const result = execSync(`node ${cliPath} ${fixturesPath} --format text --includeTotals`, {
      encoding: 'utf8'
    });
    
    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('- South Region: $23456.78');
    expect(result).toContain('- West Region: $34567.89');
    expect(result).toContain('Total: $70370.34');
  });

  it('renders markdown report without totals', () => {
    const result = execSync(`node ${cliPath} ${fixturesPath} --format markdown`, {
      encoding: 'utf8'
    });
    
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).not.toContain('**Total:**');
  });

  it('handles malformed JSON gracefully', () => {
    const malformedPath = 'temp-malformed.json';
    writeFileSync(malformedPath, '{"title": "Test", "invalid": json}');
    
    try {
      const result = execSync(`node ${cliPath} ${malformedPath} --format markdown`, {
        encoding: 'utf8',
        stdio: 'pipe'
      });
      // Should not reach here
      expect(false).toBe(true);
    } catch (error: any) {
      expect(error.stderr).toMatch(/Invalid JSON|Error:/);
    } finally {
      unlinkSync(malformedPath);
    }
  });

  it('handles missing required fields in JSON', () => {
    const invalidPath = 'temp-invalid.json';
    writeFileSync(invalidPath, '{"title": "Test"}'); // missing summary and entries
    
    try {
      const result = execSync(`node ${cliPath} ${invalidPath} --format markdown`, {
        encoding: 'utf8',
        stdio: 'pipe'
      });
      // Should not reach here
      expect(false).toBe(true);
    } catch (error: any) {
      expect(error.stderr).toMatch(/missing|unable|enoent|not found/i);
    } finally {
      unlinkSync(invalidPath);
    }
  });

  it('handles unsupported format', () => {
    try {
      const result = execSync(`node ${cliPath} ${fixturesPath} --format invalid`, {
        encoding: 'utf8',
        stdio: 'pipe'
      });
      // Should not reach here
      expect(false).toBe(true);
    } catch (error: any) {
      expect(error.stderr).toContain('Unsupported format');
    }
  });

  it('handles missing data file', () => {
    try {
      const result = execSync(`node ${cliPath} nonexistent.json --format markdown`, {
        encoding: 'utf8',
        stdio: 'pipe'
      });
      // Should not reach here
      expect(false).toBe(true);
    } catch (error: any) {
      expect(error.stderr).toMatch(/not found|enoent/i);
    }
  });

  it('writes to output file when specified', () => {
    const outputPath = 'temp-output.md';
    
    try {
      execSync(`node ${cliPath} ${fixturesPath} --format markdown --includeTotals --output ${outputPath}`, {
        encoding: 'utf8'
      });
      
      const output = readFileSync(outputPath, 'utf8');
      expect(output).toContain('# Quarterly Financial Summary');
      expect(output).toContain('**Total:** $70370.34');
    } finally {
      unlinkSync(outputPath);
    }
  });
});
