/**
 * Capitalize the first character of each sentence.
 * Handles punctuation . ? ! as sentence boundaries.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence boundaries
  // Replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence-ending punctuation
  // This handles cases like "word.Next" -> "word. Next"
  normalized = normalized.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Remove leading space
  normalized = normalized.replace(/^\s+/, '');
  
  // Capitalize first letter of the text
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence-ending punctuation
  // Use negative lookbehind to avoid capitalizing after abbreviations
  const sentenceEndings = /([.!?]\s+)([a-z])/g;
  normalized = normalized.replace(sentenceEndings, (_match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Find all URLs in the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, and www. prefixes
  // Captures the URL excluding trailing punctuation
  const urlRegex = /(https?:\/\/[^\s<]+|www\.[^\s<]+)/gi;
  
  const urls: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation: .,?!;:)
    url = url.replace(/[.,!?;:)]+$/, '');
    
    // Remove trailing quotes, brackets, parens
    url = url.replace(/["'\])>]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Convert all http:// URLs to https://
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite documentation URLs.
 * - Always upgrade http to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // First, ensure all URLs use https
  let result = text.replace(/http:\/\//gi, 'https://');
  
  // Rewrite example.com URLs with /docs/ path to docs.example.com
  // But skip if path contains dynamic indicators
  const docsUrlRegex = /(https?:\/\/)(example\.com)(\/docs\/[^\s]*?)(?=[\s,.)]|$)/gi;
  
  result = result.replace(docsUrlRegex, (match, protocol, host, path) => {
    // Check for dynamic content indicators that should skip host rewrite
    const dynamicIndicators = [
      /\?/,          // Query string
      /&/,           // Ampersand in query
      /=/,           // Equals in query
      /cgi-bin/i,    // CGI scripts
      /\.jsp$/i,     // JSP
      /\.php$/i,     // PHP
      /\.asp$/i,     // ASP
      /\.aspx$/i,    // ASP.NET
      /\.do$/i,      // Java Web
      /\.cgi$/i,     // CGI
      /\.pl$/i,      // Perl
      /\.py$/i,      // Python
    ];
    
    // Extract just the path portion (without trailing punctuation)
    const cleanPath = path.replace(/[.,;:]$/, '');
    
    // Check if path contains any dynamic indicators
    const hasDynamicIndicator = dynamicIndicators.some(regex => regex.test(cleanPath));
    
    if (hasDynamicIndicator) {
      // Only upgrade scheme, don't change host
      return `${protocol}${host}${cleanPath}`;
    } else {
      // Rewrite host to docs.example.com
      return `${protocol}docs.example.com${cleanPath}`;
    }
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days in each month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Validate day based on month
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
