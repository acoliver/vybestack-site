export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex:
  // - Local part: alphanumeric, dots, hyphens, underscores, plus (but no consecutive dots, no leading/trailing dots)
  // - Domain: alphanumeric labels with hyphens, separated by dots
  // - TLD: at least 2 letters
  // - No underscores in domain
  // - No double dots anywhere
  const emailRegex = /^(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9+._%+-]*[a-zA-Z0-9])?@(?!.*\.\.)(?!.*[_])(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks to prevent trailing dots in local or domain parts
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check that local part doesn't end with dot or have consecutive dots
  const localPart = value.split('@')[0];
  if (!localPart || localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // Check domain part for underscores and valid structure
  const domainPart = value.split('@')[1];
  if (!domainPart || domainPart.includes('_') || domainPart.startsWith('.') || domainPart.endsWith('.') || domainPart.includes('..')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  const hasCountryCode = cleaned.startsWith('+1');
  if (hasCountryCode) {
    cleaned = cleaned.slice(2);
  }
  
  // Must be exactly 10 digits after removing country code
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleaned.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the full format
  const phoneRegex = /^\+?1?[\s-]?\(?[2-9]\d{2}\)?[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code is omitted)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and names with numbers mixed in
  const nameRegex = /^[\p{L}][\p{L}'\-\s]*[\p{L}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that contain digits or special symbols
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for forbidden symbols (anything that's not a letter, apostrophe, hyphen, or space)
  const forbiddenRegex = /[^\p{L}'\-\s]/u;
  if (forbiddenRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check valid prefixes and lengths
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const hasValidFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!hasValidFormat) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}
