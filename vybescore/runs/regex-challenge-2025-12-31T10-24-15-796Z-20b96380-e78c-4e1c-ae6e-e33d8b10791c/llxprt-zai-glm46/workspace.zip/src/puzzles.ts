/**
 * Find words starting with a prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words starting with prefix
  // Word boundary at start, then prefix, then word characters
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[\\w']+)\\b`, 'gi');
  
  const matches = text.matchAll(wordPattern);
  const results: string[] = [];
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));
  
  for (const match of matches) {
    const word = match[0];
    // Check if word is not in exceptions (case-insensitive)
    if (!exceptionsLower.has(word.toLowerCase())) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at string start.
 * Returns the digit + token combination.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token
  // Match and capture the digit + token combination
  const pattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  const matches = text.matchAll(pattern);
  const results: string[] = [];
  
  for (const match of matches) {
    // Verify it's not at the start of the string
    if (match.index !== undefined && match.index > 0) {
      results.push(match[0]);
    }
  }
  
  return results;
}

/**
 * Validate password strength.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences (abab pattern).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (anything that's not letter or digit)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (abab, abcabc, abcdabcd)
  // Must be case-sensitive to catch "AbAb" pattern
  if (/(..)\1/i.test(value)) {
    return false;
  }
  
  if (/(...)\1/i.test(value)) {
    return false;
  }
  
  if (/(....)\1/i.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // Supports:
  // - Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed form with :: (double colon)
  // - Mixed IPv4 embedded: ::ffff:192.168.1.1
  // But NOT plain IPv4 addresses
  
  // First, check for potential IPv6 patterns
  // IPv6 contains colons and hex digits
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?::[0-9a-fA-F]{1,4}){1,7}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|::(?:ffff(?::0{1,4})?:)?(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)/;
  
  // Check if value contains IPv6 pattern
  if (!ipv6Pattern.test(value)) {
    return false;
  }
  
  // Exclude pure IPv4 addresses (dotted decimal)
  // IPv4 pattern: 1-3 digits, repeated 4 times, separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Make sure we have at least one colon (IPv6 characteristic)
  if (!value.includes(':')) {
    return false;
  }
  
  // Ensure it's not just an IPv4-like pattern with some colons
  // Real IPv6 must have hex digits and proper structure
  const hasHexComponent = /[0-9a-fA-F]{1,4}:[0-9a-fA-F:]/.test(value);
  if (!hasHexComponent && !value.includes('::')) {
    return false;
  }
  
  return true;
}
