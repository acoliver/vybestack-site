import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

// Configure Express
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Set view engine to EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

let db: Database;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    let dbData: Uint8Array | null = null;
    
    // Load existing database if it exists
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      dbData = new Uint8Array(fileBuffer);
    }
    
    db = new SQL.Database(dbData);
    
    // Create schema if it doesn't exist
    const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Graceful shutdown function
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      // Export database to file
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
      console.log('Database saved to disk');
      db.close();
    } catch (error) {
      console.error('Error saving database:', error);
    }
  }
  
  process.exit(0);
}

// Handle SIGTERM signal for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Validation function
function validateForm(values: FormValues): string[] {
  const errors: string[] = [];
  
  // Required fields
  if (!values.firstName?.trim()) errors.push('First name is required');
  if (!values.lastName?.trim()) errors.push('Last name is required');
  if (!values.streetAddress?.trim()) errors.push('Street address is required');
  if (!values.city?.trim()) errors.push('City is required');
  if (!values.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!values.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!values.country?.trim()) errors.push('Country is required');
  if (!values.email?.trim()) errors.push('Email is required');
  if (!values.phone?.trim()) errors.push('Phone number is required');
  
  // Email validation
  if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (international format)
  if (values.phone && !/^\+?[0-9\s\-()]+$/.test(values.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes and a leading +');
  }
  
  // Postal code validation (alphanumeric support)
  if (values.postalCode && !/^[a-zA-Z0-9\s]+$/.test(values.postalCode)) {
    errors.push('Postal code can only contain letters, digits and spaces');
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req, res) => {
  const values = req.body as FormValues;
  const errors = validateForm(values);
  
  if (errors.length > 0) {
    return res.render('form', { errors, values });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      values.firstName || '',
      values.lastName || '',
      values.streetAddress || '',
      values.city || '',
      values.stateProvince || '',
      values.postalCode || '',
      values.country || '',
      values.email || '',
      values.phone || ''
    ]);
    
    stmt.free();
    
    // Save database to disk
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req, res) => {
  // Get the most recent submission to extract the first name
  try {
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    const result = stmt.getAsObject() as { first_name: string };
    stmt.free();
    
    const firstName = result.first_name || 'friend';
    res.render('thank-you', { firstName });
  } catch (error) {
    console.error('Error retrieving data:', error);
    // Fallback to a generic greeting if there's an error
    res.render('thank-you', { firstName: 'friend' });
  }
});

// Start server
let server: {
  close?: () => void;
} | null = null;
async function startServer() {
  await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  return server;
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for tests
export default app;
export { server };
