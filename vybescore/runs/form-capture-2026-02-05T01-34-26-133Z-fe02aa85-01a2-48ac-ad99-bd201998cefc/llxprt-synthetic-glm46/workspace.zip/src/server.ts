import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Dynamic import for sql.js in ES module
const initSqlJs = async () => {
  const sqlJsModule = await import('sql.js');
  return sqlJsModule.default;
};

// Type definitions for sql.js
interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...args: unknown[]): void;
  free(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');

const app = express();
const PORT = process.env.PORT || 3535;

let db: Database | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const initSqlJs = await import('sql.js');
    const initJs = (initSqlJs.default as unknown) as (config?: unknown) => Promise<{ Database: new(data?: Uint8Array) => Database }>;
    const SQL = await initJs();
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    // Ensure data directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    let dbBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const fileContent = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileContent);
    }

    db = new SQL.Database(dbBuffer ?? undefined);

    // Create tables if they don't exist
    const schemaPath = path.join(projectRoot, 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    db!.exec(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  process.exit(0);
}

// Setup middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve public files
app.use('/public', express.static(path.join(projectRoot, 'public')));

// Set view engine
app.set('views', path.join(projectRoot, 'src', 'templates'));
app.set('view engine', 'ejs');

// Validation functions
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  [key: string]: string | undefined;
}

function validateForm(formData: FormData): { errors: string[]; valid: boolean } {
  const errors: string[] = [];
  
  // Required fields validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field]!.trim() === '') {
      errors.push(`${getFieldLabel(field)} is required`);
    }
  }
  
  // Email validation
  if (formData.email && !isValidEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation
  if (formData.phone && !isValidPhone(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation - allow alphanumeric
  if (formData.postalCode && !isValidPostalCode(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return { errors, valid: errors.length === 0 };
}

function getFieldLabel(fieldName: string): string {
  const labels: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State / Province / Region',
    postalCode: 'Postal / Zip code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone number'
  };
  return labels[fieldName] || fieldName;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?\d[\d\s\-()]*$/;
  return phoneRegex.test(phone);
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  const trimmed = String(postalCode).trim();
  return trimmed.length > 0 && postalRegex.test(trimmed);
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const { errors, valid } = validateForm(req.body);
  
  if (!valid) {
    return res.status(400).render('form', { 
      errors, 
      values: req.body 
    });
  }
  
  // Insert into database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        req.body.firstName,
        req.body.lastName,
        req.body.streetAddress,
        req.body.city,
        req.body.stateProvince,
        req.body.postalCode,
        req.body.country,
        req.body.email,
        req.body.phone
      ]);
      
      stmt.free();
      saveDatabase();
      
      // Redirect to thank you page with first name
      res.redirect(`/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
    } catch (error) {
      console.error('Database insertion error:', error);
      errors.push('Database error occurred. Please try again.');
      return res.status(500).render('form', { 
        errors, 
        values: req.body 
      });
    }
  } else {
    errors.push('Database unavailable. Please try again later.');
    return res.status(500).render('form', { 
      errors, 
      values: req.body 
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// For testing purposes
export { app, initializeDatabase, saveDatabase, shutdown };

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(console.error);
}
