declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...args: unknown[]): void;
    free(): void;
  }

  export function initSqlJs(options?: unknown): Promise<{
    Database: new(data?: Uint8Array) => Database;
  }>;

  export const Database: new(data?: Uint8Array) => Database;
}