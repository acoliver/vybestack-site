import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';
import { Server as HttpServer } from 'http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
let db: Database | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  formData: FormData;
}

async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });

    let dbBuffer: Uint8Array | null = null;
    
    try {
      const existingDb = await fs.readFile(DB_PATH);
      dbBuffer = new Uint8Array(existingDb);
    } catch (error) {
      // Database file doesn't exist, will create new one
    }

    if (dbBuffer) {
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      // Create table from schema
      const schema = await fs.readFile(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validateFormData(data: Record<string, string | undefined>): ValidationResult {
  const errors: string[] = [];
  const formData: FormData = {
    firstName: (data.firstName || '').trim(),
    lastName: (data.lastName || '').trim(),
    streetAddress: (data.streetAddress || '').trim(),
    city: (data.city || '').trim(),
    stateProvince: (data.stateProvince || '').trim(),
    postalCode: (data.postalCode || '').trim(),
    country: (data.country || '').trim(),
    email: (data.email || '').trim(),
    phone: (data.phone || '').trim(),
  };

  if (!formData.firstName) errors.push('First name is required');
  if (!formData.lastName) errors.push('Last name is required');
  if (!formData.streetAddress) errors.push('Street address is required');
  if (!formData.city) errors.push('City is required');
  if (!formData.stateProvince) errors.push('State/Province/Region is required');
  if (!formData.postalCode) errors.push('Postal code is required');
  if (!formData.country) errors.push('Country is required');
  
  if (!formData.email) {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Email format is invalid');
  }
  
  if (!formData.phone) {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Phone number format is invalid');
  }

  return {
    isValid: errors.length === 0,
    errors,
    formData,
  };
}

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Configure EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    formData: {},
  });
});

app.post('/submit', async (req, res) => {
  const validation = validateFormData(req.body);
  
  if (!validation.isValid) {
      res.status(400).render('form', {
        errors: validation.errors,
        formData: validation.formData,
      });
      return;
    }

  try {
    const stmt = db!.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      validation.formData.firstName,
      validation.formData.lastName,
      validation.formData.streetAddress,
      validation.formData.city,
      validation.formData.stateProvince,
      validation.formData.postalCode,
      validation.formData.country,
      validation.formData.email,
      validation.formData.phone,
    ]);
    
    stmt.free();
    
    // Write database to file
    const data = db!.export();
    await fs.writeFile(DB_PATH, Buffer.from(data));
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
});

async function startServer() {
  await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Store server reference for tests
  (globalThis as unknown as { __server: HttpServer }).__server = server;
  (globalThis as unknown as { __app: express.Application }).__app = app;
}

startServer().catch(console.error);

export default app;