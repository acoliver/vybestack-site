// Debug validation issue
import request from 'supertest';

// Import server
import server from './dist/server.js';
const app = server.default;

const testData = {
  firstName: 'John',
  lastName: 'Doe',
  streetAddress: '123 Main St',
  city: 'New York',
  stateProvince: 'NY',
  postalCode: '10001',
  country: 'USA',
  email: 'john.doe@example.com',
  phone: '+1 555 123 4567'
};

console.log('Testing form submission with data:', testData);

try {
  const response = await request(app)
    .post('/submit')
    .send(testData);
    
  console.log('Status:', response.status);
  console.log('Location:', response.headers.location);
  console.log('Body length:', response.text?.length);
  if (response.status !== 302) {
    console.log('Response text preview:', response.text?.substring(0, 500));
  }
} catch (error) {
  console.log('Error:', error.message);
}