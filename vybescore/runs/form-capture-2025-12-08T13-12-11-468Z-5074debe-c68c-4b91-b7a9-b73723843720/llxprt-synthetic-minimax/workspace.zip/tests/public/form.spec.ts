import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import { createRequire } from 'module';

let app: import('express').Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import server after cleanup
  const require = createRequire(import.meta.url);
  const serverModule = require('../../dist/server.js');
  app = serverModule.default;
  
  // Wait a moment for database to initialize
  await new Promise(resolve => setTimeout(resolve, 100));
});

afterAll(() => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    // Check for form fields using string matching instead of cheerio
    expect(response.text).toContain('name="firstName"');
    expect(response.text).toContain('name="lastName"');
    expect(response.text).toContain('name="streetAddress"');
    expect(response.text).toContain('name="city"');
    expect(response.text).toContain('name="stateProvince"');
    expect(response.text).toContain('name="postalCode"');
    expect(response.text).toContain('name="country"');
    expect(response.text).toContain('name="email"');
    expect(response.text).toContain('name="phone"');
    
    // Check that form has proper method and action
    expect(response.text).toContain('action="/submit"');
    expect(response.text).toContain('method="POST"');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
  
  it('shows validation errors for invalid data', async () => {
    const invalidData = {
      firstName: '', // Empty required field
      lastName: 'Doe',
      email: 'invalid-email', // Invalid email
      phone: '123' // Invalid phone
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email format is invalid');
    expect(response.text).toContain('Phone number format is invalid');
  });
  
  it('shows thank you page after successful submission', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Los Angeles',
      stateProvince: 'CA',
      postalCode: '90210',
      country: 'USA',
      email: 'jane.smith@example.com',
      phone: '+1 555 987 6543'
    };
    
    await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    expect(thankYouResponse.text).toContain('Thank You!');
    expect(thankYouResponse.text).toContain('Why did you give your personal information');
  });
});
