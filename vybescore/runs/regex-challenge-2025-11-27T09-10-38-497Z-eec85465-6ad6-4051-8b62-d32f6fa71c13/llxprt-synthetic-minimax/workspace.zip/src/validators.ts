export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  // Check for obviously invalid patterns that regex might miss
  if (value.includes('..') || value.endsWith('.') || value.includes('@.') || value.includes('.@')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace
  const clean = value.replace(/[\s\-().]/g, '');
  
  // Check minimum length (10 digits without country code, 11 with +1)
  if (clean.length < 10) return false;
  if (clean.length > 11) return false;
  
  // Handle country code
  if (clean.length === 11) {
    if (!clean.startsWith('1')) return false;
    // Remove country code for area code validation
    const number = clean.substring(1);
    return isValidUSNumber(number);
  } else {
    return isValidUSNumber(clean);
  }
}

function isValidUSNumber(number: string): boolean {
  // Validate area code (first digit 2-9, second and third can be any digit)
  const areaCode = number.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  if (!/^[2-9][0-9]{2}$/.test(areaCode)) return false;
  
  // Validate exchange code (first digit 2-9, second and third can be any digit)
  const exchangeCode = number.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  if (!/^[2-9][0-9]{2}$/.test(exchangeCode)) return false;
  
  // Validate subscriber number (last 4 digits)
  const subscriberNumber = number.substring(6);
  if (!/^[0-9]{4}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation with flexible formatting.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens, keep only digits and + sign
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (cleaned.startsWith('+54')) {
    // Pattern: +54[9] area_code subscriber_number
    // The 9 is optional for mobile indicator
    const match = cleaned.match(/^\+54(9)?(\d{2,4})(\d{6,8})$/);
    if (!match) return false;
    
    const areaCode = match[2];
    const subscriber = match[3];
    
    // Validate area code (2-4 digits, first digit 1-9)
    if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]\d*$/.test(areaCode)) return false;
    
    // Validate subscriber number (6-8 digits total)
    if (subscriber.length < 6 || subscriber.length > 8 || !/^\d+$/.test(subscriber)) return false;
    
    return true;
  } else {
    // Pattern: 0 area_code subscriber_number (landlines without country code)
    const match = cleaned.match(/^0(\d{2,4})(\d{6,8})$/);
    if (!match) return false;
    
    const areaCode = match[1];
    const subscriber = match[2];
    
    // Validate area code (2-4 digits, first digit 1-9)
    if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]\d*$/.test(areaCode)) return false;
    
    // Validate subscriber number (6-8 digits total)
    if (subscriber.length < 6 || subscriber.length > 8 || !/^\d+$/.test(subscriber)) return false;
    
    return true;
  }
}

/**
 * TODO: Implement name validation allowing unicode letters, accents, apostrophes, hyphens, spaces.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and special symbols like "X Æ A-12"
  const nameRegex = /^[\p{L}][\p{L}'\s-]*[\p{L}]$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional validation: no consecutive special characters
  if (/['\s-]{2,}/.test(value)) return false;
  
  // Check for obviously invalid patterns like "X Æ A-12"
  if (/[^\p{L}\s'\-]/u.test(value)) return false;
  
  return true;
}

/**
 * TODO: Implement credit card validation with Luhn checksum and prefix validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const clean = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(clean)) return false;
  
  // Check card length (13-19 digits for major cards)
  if (clean.length < 13 || clean.length > 19) return false;
  
  // Check card type by prefix
  const cardType = getCardType(clean);
  if (!cardType) return false;
  
  // Validate length for card type
  if (!isValidLength(clean.length, cardType)) return false;
  
  // Apply Luhn checksum
  return luhnCheck(clean);
}

function getCardType(number: string): string | null {
  // Visa: starts with 4, length 13, 16, or 19
  if (number.match(/^4/)) return 'visa';
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (number.match(/^(5[1-5]|2(2[2-9]|[3-6]\d|7[01]|720))/)) return 'mastercard';
  
  // American Express: starts with 34 or 37, length 15
  if (number.match(/^3[47]/)) return 'amex';
  
  // Discover: starts with 6011, 622126-622925, 644-649, or 65, length 16-19
  if (number.match(/^(6011|622(12[6-9]|1[3-9]\d|[2-8]\d{2}|9[01]\d|92[0-5])|64[4-9]|65)/)) return 'discover';
  
  return null;
}

function isValidLength(length: number, cardType: string): boolean {
  switch (cardType) {
    case 'visa':
      return [13, 16, 19].includes(length);
    case 'mastercard':
      return length === 16;
    case 'amex':
      return length === 15;
    case 'discover':
      return [16, 17, 18, 19].includes(length);
    default:
      return false;
  }
}

function luhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}