/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper sentence separation
  let result = text.replace(/\s+/g, ' ').trim();
  
  // First pass: ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(\S)/g, '$1 $2');
  
  // Second pass: capitalize the first letter of each sentence
  // Match sentence start after .!? followed by space and lowercase letter
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs including http, https, ftp
  const urlPattern = /(?:https?:\/\/|ftp:\/\/)[^\s)>";]+/gi;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]*$/, ''));
}

/**
 * TODO: Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlPattern = /http:\/\/([^\/\s]+)([^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Check if path starts with /docs/
    const startsWithDocs = path.startsWith('/docs/');
    
    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    // Always upgrade scheme to https
    let newUrl = 'https://';
    
    if (startsWithDocs && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.' + host;
    } else {
      // Keep original host
      newUrl += host;
    }
    
    // Add the path
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the four-digit year from mm/dd/yyyy format. Return N/A for invalid dates.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return year.toString();
}