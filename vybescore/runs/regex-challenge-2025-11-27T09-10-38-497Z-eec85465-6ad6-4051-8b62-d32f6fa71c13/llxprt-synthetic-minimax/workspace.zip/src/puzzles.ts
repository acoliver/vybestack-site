/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern to find words that start with the prefix
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Match the token when it immediately follows a digit and is not at the start
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'g');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate password strength with specific requirements.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // One uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // One lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // One digit
  if (!/\d/.test(value)) return false;
  
  // One symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // No immediate repeated sequences (like "abab")
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns - comprehensive but simplified
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: shorthand (one or more consecutive groups of zeros)
  // This is a simplified pattern that handles most common cases
  const shorthandIPv6 = /^(?:[0-9a-fA-F]{1,4}:){0,6}(?::[0-9a-fA-F]{1,4}){0,6}$|^::$/;
  
  // IPv4-mapped IPv6 addresses (::ffff:192.168.1.1)
  const ipv4Mapped = /^::(?:ffff:)?(\d{1,3}\.){3}\d{1,3}$/;
  
  // IPv6 with embedded IPv4 (2001:db8::192.168.1.1)
  const ipv6WithIPv4 = /^(?:[0-9a-fA-F]{1,4}:){0,6}(?:[0-9a-fA-F]{1,4})?:(?:\d{1,3}\.){3}\d{1,3}$/;
  
  // Split on whitespace to check individual addresses/tokens
  const tokens = value.split(/\s+/);
  
  for (const token of tokens) {
    // Skip pure IPv4 addresses
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(token)) {
      continue;
    }
    
    // Check for IPv6 patterns
    if (fullIPv6.test(token) || shorthandIPv6.test(token) || 
        ipv4Mapped.test(token) || ipv6WithIPv4.test(token)) {
      return true;
    }
  }
  
  return false;
}