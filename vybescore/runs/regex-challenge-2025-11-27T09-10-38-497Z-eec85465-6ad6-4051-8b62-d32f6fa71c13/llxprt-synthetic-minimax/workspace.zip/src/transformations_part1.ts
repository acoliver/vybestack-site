/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper sentence separation
  let result = text.replace(/\s+/g, " ").trim();
  
  // First pass: ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(\S)/g, "$1 $2");
  
  // Second pass: capitalize the first letter of each sentence
  // Match sentence start after .!? followed by space and lowercase letter
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}
