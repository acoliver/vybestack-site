import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

// Validation function
function validateForm(values: FormValues): ValidationResult {
  const errors: string[] = [];

  // Required fields validation
  if (!values.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!values.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!values.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!values.city?.trim()) {
    errors.push('City is required');
  }
  if (!values.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  if (!values.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  }
  if (!values.country?.trim()) {
    errors.push('Country is required');
  }
  if (!values.email?.trim()) {
    errors.push('Email is required');
  }
  if (!values.phone?.trim()) {
    errors.push('Phone number is required');
  }

  // Email validation (simple regex)
  if (values.email?.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(values.email.trim())) {
      errors.push('Please enter a valid email address');
    }
  }

  // Phone validation: allows digits, spaces, parentheses, dashes, and leading @
  if (values.phone?.trim()) {
    const allowedChars = /^@?[\d\s()\\-]+$/;
    if (!allowedChars.test(values.phone.trim())) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading @');
    }
  }

  // Postal code validation: alphanumeric with spaces allowed
  if (values.postalCode?.trim()) {
    const postalRegex = /^[A-Za-z0-9\s]+$/;
    if (!postalRegex.test(values.postalCode.trim())) {
      errors.push('Postal code can only contain letters, digits, and spaces');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Initialize database
export async function initializeDatabase(): Promise<void> {
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Load or create database
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    },
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(values);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values,
    });
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        values.firstName.trim(),
        values.lastName.trim(),
        values.streetAddress.trim(),
        values.city.trim(),
        values.stateProvince.trim(),
        values.postalCode.trim(),
        values.country.trim(),
        values.email.trim(),
        values.phone.trim(),
      ]
    );
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission for the thank you message
  let firstName = 'friend';
  if (db) {
    const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  }

  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err);
  res.status(500).send('Internal Server Error');
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down server...');
    server.close(() => {
      console.log('Server closed');
      if (db) {
        db.close();
        db = null;
      }
      process.exit(0);
    });

    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Export app for testing
export { app, db };

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
