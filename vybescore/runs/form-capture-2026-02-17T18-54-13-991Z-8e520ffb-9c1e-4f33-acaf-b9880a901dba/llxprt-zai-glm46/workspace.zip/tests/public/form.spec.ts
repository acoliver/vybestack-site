import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase } from '../../src/server.js';

let server: ReturnType<typeof app.listen>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await initializeDatabase();
  // Start the server on a random port for testing
  await new Promise<void>((resolve) => {
    server = app.listen(0, () => {
      resolve();
    });
  });
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);
    
    // Check all required fields exist
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'invalid-email',
        phone: '555-123-4567',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid@phone!',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number can only contain');
  });

  it('accepts international phone formats', async () => {
    const response1 = await request(app)
      .post('/submit')
      .send({
        firstName: 'Alice',
        lastName: 'Smith',
        streetAddress: '456 High St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'alice@example.com',
        phone: '@44 20 7946 0958',
      });

    expect(response1.status).toBe(302);
    expect(response1.headers.location).toBe('/thank-you');

    const response2 = await request(app)
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '@54 9 11 1234-5678',
      });

    expect(response2.status).toBe(302);
    expect(response2.headers.location).toBe('/thank-you');
  });

  it('accepts alphanumeric postal codes', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Bob',
        lastName: 'Jones',
        streetAddress: '789 Broad St',
        city: 'Manchester',
        stateProvince: 'England',
        postalCode: 'M1 1AA',
        country: 'UK',
        email: 'bob@example.com',
        phone: '@44 161 123 4567',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('persists submission and redirects', async () => {
    // Clean up database file before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Doe',
        streetAddress: '321 Oak Ave',
        city: 'Seattle',
        stateProvince: 'WA',
        postalCode: '98101',
        country: 'USA',
        email: 'jane@example.com',
        phone: '206-555-7890',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Follow redirect
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('Jane');
  });

  it('shows thank you page with humor', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('stranger on the internet');
    expect(response.text).toContain('Return to the form');
  });
});
