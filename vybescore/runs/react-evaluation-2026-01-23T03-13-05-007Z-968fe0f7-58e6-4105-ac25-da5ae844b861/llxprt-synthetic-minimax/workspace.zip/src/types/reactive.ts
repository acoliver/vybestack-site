/**
 * Type definitions for the reactive programming system.
 */

// Basic type definitions
export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export interface Options {
  name?: string
}

// Core reactive interfaces
export interface ObserverR {
  name?: string
  isComputing?: boolean
  value: any
  listeners?: Set<() => void>
  dependents?: Set<() => void>
  updateFn?: any
}

export interface SubjectR {
  name?: string
  value: any
  observer?: ObserverR | undefined
  listeners?: Set<() => void>
  equalFn?: any
}

// Value and update specific interfaces for type safety
export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
}

// Combined generic types
export type Observer<T> = ObserverR & ObserverV<T>
export type Subject<T> = SubjectR & SubjectV<T>

// Active observer tracking
let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): ObserverR | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const currentValue = observer.value
    const newValue = observer.updateFn?.(currentValue)
    observer.value = newValue
  } finally {
    activeObserver = previous
  }
}

// Core reactive functions
export function addListener(observer: ObserverR, listener: () => void): void {
  if (!observer.listeners) {
    observer.listeners = new Set()
  }
  observer.listeners.add(listener)
}

export function notifyListeners(observer: ObserverR): void {
  if (observer.listeners && observer.listeners.size > 0) {
    // Create a copy to avoid modification during iteration
    const listeners = Array.from(observer.listeners)
    listeners.forEach(listener => listener())
  }
}

export function registerDependent(source: ObserverR, dependent: () => void): void {
  if (!source.dependents) {
    source.dependents = new Set()
  }
  source.dependents.add(dependent)
}

export function notifyDependents(source: ObserverR): void {
  if (source.dependents && source.dependents.size > 0) {
    // Create a copy to avoid modification during iteration
    const dependents = Array.from(source.dependents)
    dependents.forEach(dependent => dependent())
  }
}
