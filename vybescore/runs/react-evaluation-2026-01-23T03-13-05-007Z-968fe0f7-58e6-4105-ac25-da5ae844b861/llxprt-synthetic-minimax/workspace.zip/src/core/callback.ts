/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver,
  setActiveObserver,
  addListener,
  registerDependent,
  notifyDependents,
  notifyListeners,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value: value as T,
    updateFn,
    listeners: new Set(),
    dependents: new Set()
  }
  
  // Track if this callback has been disposed
  let disposed = false
  
  // Create the callback execution function
  const executeCallback = () => {
    if (disposed) return
    
    const currentValue = observer.value as T
    const result = observer.updateFn(currentValue)
    observer.value = result as T
    
    // Notify dependents and listeners when callback executes
    notifyDependents(observer as unknown as ObserverR)
    notifyListeners(observer as unknown as ObserverR)
  }
  
  // Establish initial dependency tracking by making this observer active
  const previous = setActiveObserver(observer as ObserverR)
  try {
    // Execute the update function to establish dependencies
    executeCallback()
  } finally {
    setActiveObserver(previous)
  }
  
  // Register this callback as dependent and listener on all currently active observers
  const activeObserver = getActiveObserver()
  if (activeObserver) {
    const callback = () => {
      if (disposed) return
      executeCallback()
    }
    
    // Register as both dependent and listener for comprehensive notifications
    registerDependent(activeObserver, callback)
    addListener(activeObserver, callback)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear observer dependencies
    observer.dependents?.clear()
    observer.listeners?.clear()
    observer.value = undefined as T
    observer.updateFn = () => undefined as T
  }
}
