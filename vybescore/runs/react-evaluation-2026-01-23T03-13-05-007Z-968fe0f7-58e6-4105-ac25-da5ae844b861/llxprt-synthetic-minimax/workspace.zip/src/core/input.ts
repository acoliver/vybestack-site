import {
  InputPair,
  SubjectR,
  getActiveObserver,
  notifyListeners,
  registerDependent,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: SubjectR = {
    name: options?.name,
    value,
    equalFn: undefined,
    listeners: new Set()
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this subject as being read by the active observer
      registerDependent(activeObserver, () => {
        // When the active observer changes, this subject should notify its own listeners
        notifyListeners(subject as unknown as ObserverR)
      })
    }
    return subject.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    
    // Notify all listeners when value changes
    notifyListeners(subject as unknown as ObserverR)
    
    return subject.value as T
  }

  return [read, write]
}
