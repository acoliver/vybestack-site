/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  notifyListeners,
  registerDependent,
  notifyDependents,
  EqualFn,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn,
    listeners: new Set(),
    dependents: new Set()
  }
  
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register dependency: this computed value depends on the active observer
      registerDependent(activeObserver, () => {
        // When the active observer changes, trigger re-evaluation
        if (!observer.isComputing) {
          observer.isComputing = true
          try {
            const currentValue = observer.value as T
            observer.value = observer.updateFn(currentValue)
            notifyDependents(observer as unknown as ObserverR)
          } finally {
            observer.isComputing = false
          }
        }
      })
    }
    
    // Re-evaluate the computed value
    if (!observer.isComputing) {
      observer.isComputing = true
      const previous = setActiveObserver(observer as ObserverR)
      try {
        const currentValue = observer.value as T
        observer.value = observer.updateFn(currentValue)
      } finally {
        setActiveObserver(previous)
        observer.isComputing = false
      }
      
      // Notify dependents after re-evaluation
      notifyDependents(observer as unknown as ObserverR)
      notifyListeners(observer as unknown as ObserverR)
    }
    
    return observer.value as T
  }

  return read
}
