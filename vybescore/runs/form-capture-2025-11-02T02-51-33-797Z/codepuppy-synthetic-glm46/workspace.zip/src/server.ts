import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

/// <reference path="./types/sqljs.d.ts" />

// Extend express Request and Response interfaces for cookies
declare module 'express' {
  interface Request {
    cookies?: Record<string, string>;
  }
  interface Response {
    cookie(name: string, value: string, options?: Record<string, unknown>): void;
  }
}

// Type definitions for sql.js
interface SqlJsStatic {
  Database: new (data?: Uint8Array | null) => SqlJsDatabase;
}

interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string, ...params: unknown[]): unknown[];
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatement {
  run(...params: unknown[]): void;
  get(...params: unknown[]): unknown;
  all(...params: unknown[]): unknown[];
  free(): void;
}



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private server: import('http').Server | null = null;
  private db: SqlJsDatabase | null = null;
  private SQL: SqlJsStatic | null = null;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  // Expose initializeDatabase for external use
  public async initializeDatabase(): Promise<void> {
    await this.initializeDatabaseInternal();
  }

  private async initializeDatabaseInternal(): Promise<void> {
    try {
      this.SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
      }) as SqlJsStatic;

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      let dbBuffer: Uint8Array | null = null;
      if (fs.existsSync(dbPath)) {
        const dbFile = fs.readFileSync(dbPath);
        dbBuffer = new Uint8Array(dbFile);
      }

      this.db = new this.SQL.Database(dbBuffer);

      // Read and execute schema
      const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      this.db.run(schema);
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }
      const data = this.db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    
    // Add cookie parser middleware
    this.app.use((req: express.Request, res: express.Response, next: express.NextFunction) => {
      const cookieHeader = req.headers.cookie || '';
      const cookies: Record<string, string> = {};
      
      cookieHeader.split(';').forEach((cookie: string) => {
        const [name, ...rest] = cookie.split('=');
        if (name && rest.length) {
          cookies[name.trim()] = rest.join('=').trim();
        }
      });
      
      req.cookies = cookies;
      
      res.cookie = (name: string, value: string, options: Record<string, unknown> = {}) => {
        let cookieString = `${name}=${value}`;
        if (options.maxAge && typeof options.maxAge === 'number') {
          cookieString += `; Max-Age=${Math.floor(options.maxAge / 1000)}`;
        }
        if (options.httpOnly) {
          cookieString += '; HttpOnly';
        }
        res.setHeader('Set-Cookie', cookieString);
      };
      
      next();
    });
    
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private validatePhone(phone: string): boolean {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.trim().length > 0;
  }

  private validatePostalCode(postalCode: string): boolean {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.trim().length > 0;
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName',
      'lastName',
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim().length === 0) {
        const fieldName = field.replace(/([A-Z])/g, ' $1').trim();
        errors.push({
          field,
          message: `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`
        });
      }
    }

    // Email validation
    if (data.email && !this.validateEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation
    if (data.phone && !this.validatePhone(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number (digits, spaces, dashes, parentheses optional)'
      });
    }

    // Postal code validation
    if (data.postalCode && !this.validatePostalCode(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code (letters and digits allowed)'
      });
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req: express.Request, res: express.Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    this.app.post('/submit', async (req: express.Request, res: express.Response) => {
      try {
        // Ensure database is initialized
        if (!this.db) {
          await this.initializeDatabaseInternal();
        }
        
        if (!this.db) {
          throw new Error('Database initialization failed');
        }
        
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        // Debug logging for form data
        console.log('Form data received:', JSON.stringify(formData, null, 2));

        const errors = this.validateForm(formData);

        if (errors.length > 0) {
          return res.status(400).render('form', {
            errors: errors.map(e => e.message),
            values: formData
          });
        }

        // Insert into database
        console.log('Database initialized:', !!this.db);
        
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        try {
          stmt.run([
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);
          console.log('Database insertion successful');
        } finally {
          stmt.free();
        }
        this.saveDatabase();

        // Store first name in a cookie for the thank you page
        res.cookie('submittedFirstName', formData.firstName, { maxAge: 300000, httpOnly: false }); // 5 minutes
        res.redirect(302, '/thank-you');
      } catch (error: unknown) {
        console.error('Error submitting form:', error);
        res.status(500).render('form', {
          errors: ['An unexpected error occurred. Please try again.'],
          values: req.body
        });
      }
    });

    this.app.get('/thank-you', (req: express.Request, res: express.Response) => {
      // Get first name from cookie or use generic greeting
      const firstName = req.cookies?.submittedFirstName || 'friend';
      res.render('thank-you', {
        firstName
      });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabaseInternal();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  private shutdown(): void {
    console.log('Shutting down gracefully...');
    
    if (this.db) {
      this.saveDatabase();
      this.db.close();
    }
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    }
  }

  public getApp(): express.Application {
    return this.app;
  }
}

// Create and initialize server
let formServer: FormServer;
let app: express.Application;
let isInitialized = false;

async function initializeServer() {
  formServer = new FormServer();
  await formServer.initializeDatabase();
  app = formServer.getApp();
  isInitialized = true;
  
  if (import.meta.url === `file://${process.argv[1]}`) {
    await formServer.start();
  }
}

// Initialize synchronously using the module initialization
const initPromise = initializeServer().catch(error => {
  console.error('Failed to initialize server:', error);
  if (import.meta.url === `file://${process.argv[1]}`) {
    process.exit(1);
  }
});

// Export function to get app, waiting for initialization if needed
async function getApp(): Promise<express.Application> {
  if (!isInitialized) {
    await initPromise;
  }
  return app;
}

// For synchronous access in tests (after waiting)
// Export after ensuring initialization happens
export { formServer, app, getApp, initPromise };