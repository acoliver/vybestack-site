/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  // Track observers that depend on this value
  observers?: Set<ObserverR>
}

export type ObserverV<T> = {
  value: T | undefined
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer?: ObserverR): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = undefined
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Update dependent observers - use a copy to avoid issues with set modification during iteration
  if (observer.observers && observer.observers.size > 0) {
    const dependentObservers = Array.from(observer.observers)
    // Copy the set to avoid issues with modification during iteration
    const currentObservers = new Set(observer.observers)
    for (const dependent of dependentObservers) {
      if (currentObservers.has(dependent)) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
  }
}