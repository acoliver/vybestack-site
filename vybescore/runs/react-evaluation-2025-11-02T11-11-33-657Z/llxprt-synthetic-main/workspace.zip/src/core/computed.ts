/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process equal parameter
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof equal === 'boolean') {
    if (equal) {
      equalFn = (lhs: T, rhs: T) => lhs === rhs
    } else {
      equalFn = () => false // Always trigger updates
    }
  } else {
    equalFn = equal
  }

  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Store dependencies to know when to trigger recomputation
  // This tracks which values this computed value depends on
  const dependencies = new Set<ObserverR>()
  
  // Store dependents to avoid circular updates
  const dependents = new Set<ObserverR>()
  
  // Flag to prevent infinite recursion during observer updates
  let computing = false
  
  // Execute the computation function in a tracking context to establish dependencies
  function computeValue(): T {
    const previousObserver = getActiveObserver()
    setActiveObserver(computedObserver)
    
    try {
      // Run the original update function which will track dependencies
      return updateFn(computedObserver.value as T)
    } finally {
      // Restore the previous observer
      setActiveObserver(previousObserver)
    }
  }
  
  // Initialize the computed value
  computedObserver.value = computeValue()
  
  // Initialize dependencies
  if (computedObserver.observers) {
    for (const dependency of computedObserver.observers) {
      dependencies.add(dependency)
      
      // Register this computed observer as a dependent of the dependency
      if (!dependency.observers) {
        dependency.observers = new Set()
      }
      if (!dependency.observers.has(computedObserver)) {
        dependency.observers.add(computedObserver)
      }
    }
  }
  
  // Override the update function to trigger recomputation
  computedObserver.updateFn = () => {
    // Prevent infinite recursion
    if (computing) return computedObserver.value as T
    
    try {
      computing = true
      const oldValue = computedObserver.value as T
      const previousDependencies = new Set(dependencies)
      dependencies.clear()
      
      // Clear the old observer dependencies
      computedObserver.observers!.clear()
      
      // Recompute the value
      computedObserver.value = computeValue()
      
      // Add new dependencies
      if (computedObserver.observers) {
        for (const dependency of computedObserver.observers) {
          dependencies.add(dependency)
          
          // Register this computed observer as a dependent of the dependency
          if (!dependency.observers) {
            dependency.observers = new Set()
          }
          if (!dependency.observers.has(computedObserver)) {
            dependency.observers.add(computedObserver)
          }
        }
      }
      
      // Clean up old dependencies
      for (const oldDep of previousDependencies) {
        if (!dependencies.has(oldDep) && oldDep.observers) {
          oldDep.observers.delete(computedObserver)
        }
      }
      
      // If the value changed, notify dependent observers
      if (!equalFn(oldValue, computedObserver.value as T)) {
        // Use the separate dependents set to avoid circular dependencies
        const dependentsArray = Array.from(dependents)
        for (const observer of dependentsArray) {
          updateObserver(observer as Observer<unknown>)
        }
      }
    } finally {
      computing = false
    }
    
    return computedObserver.value as T
  }
  
  // Return getter function that establishes dependencies on access
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    // If there's an active observer, establish a dependency
    if (currentObserver && currentObserver !== computedObserver) {
      // Add the current observer to our dependents set
      dependents.add(currentObserver)
      
      // Track this dependency
      if (!computedObserver.observers) {
        computedObserver.observers = new Set()
      }
      if (!computedObserver.observers.has(currentObserver)) {
        computedObserver.observers.add(currentObserver)
      }
    }
    
    return computedObserver.value as T
  }
  
  return getter
}