/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    name: `callback-${Math.random().toString(36).substring(2, 9)}`,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Track dependencies separately
  const dependencies = new Set<ObserverR>()
  
  // Execute the callback function to establish dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(callbackObserver)
  
  try {
    // Store initial result of the callback
    callbackObserver.value = callbackObserver.updateFn(callbackObserver.value)
    
    // Store all dependencies that the callback accessed
    if (callbackObserver.observers) {
      for (const dep of callbackObserver.observers) {
        dependencies.add(dep)
        
        // Make sure we're added to the dependency's observer list
        if (!dep.observers) {
          dep.observers = new Set()
        }
        dep.observers.add(callbackObserver)
      }
    }
  } finally {
    // Restore the previous active observer
    setActiveObserver(previousObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this callback from all dependencies to stop further updates
    for (const dep of dependencies) {
      if (dep.observers) {
        dep.observers.delete(callbackObserver)
      }
    }
    
    // Set the callback updateFn to a no-op to prevent any further execution
    callbackObserver.updateFn = () => value as T
  }
}