/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equal parameter
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof equal === 'boolean') {
    if (equal) {
      equalFn = (lhs: T, rhs: T) => lhs === rhs
    } else {
      equalFn = () => false // Always trigger updates
    }
  } else {
    equalFn = equal
  }

  // Create input observer that other values can depend on
  const inputObserver: Observer<T> & { value: T; updateFn: () => T } = {
    name: options?.name,
    value: value, // Initial value for the input
    updateFn: () => value, // Return the initial value - not used for updates but required by type
    observers: new Set(), // Holds observers that depend on this input
  }

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Establish a dependency: the current observer depends on this input
      if (!inputObserver.observers) {
        inputObserver.observers = new Set()
      }
      if (!currentObserver.observers) {
        currentObserver.observers = new Set()
      }
      
      // Add the current observer to this input's observer set if not already there
      if (!inputObserver.observers.has(currentObserver)) {
        inputObserver.observers.add(currentObserver)
      }
    }
    // Input observers always have a value after initialization
    return inputObserver.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Input observers always have a value after initialization
    const currentValue = inputObserver.value
    if (!equalFn(currentValue, nextValue)) {
      inputObserver.value = nextValue
      
      // Update all observers that depend on this input
      if (inputObserver.observers && inputObserver.observers.size > 0) {
        // Convert to array to prevent issues with Set modification during iteration
        const dependentObservers = Array.from(inputObserver.observers)
        for (const observer of dependentObservers) {
          updateObserver(observer as Observer<unknown>)
        }
      }
    }
    return nextValue
  }

  return [read, write]
}