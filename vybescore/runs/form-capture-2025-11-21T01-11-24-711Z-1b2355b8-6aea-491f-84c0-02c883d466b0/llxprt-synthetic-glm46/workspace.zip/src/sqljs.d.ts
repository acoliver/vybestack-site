// Minimal type definitions for sql.js to avoid using @types/sql.js
/* eslint-disable @typescript-eslint/no-explicit-any */
declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: any[]): void;
    free(): void;
  }

  export interface SqlJs {
    Database: new (data?: ArrayBuffer) => Database;
  }

  export default function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJs>;
}