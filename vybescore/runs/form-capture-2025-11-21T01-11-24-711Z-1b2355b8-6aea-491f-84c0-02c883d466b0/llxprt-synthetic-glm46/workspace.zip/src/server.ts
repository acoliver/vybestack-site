import express, { type Request, type Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { type Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;
let db: Database | null = null;

// Middleware
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
const validateRequired = (value: string): boolean => {
  return Boolean(value && value.trim() !== '');
};

const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric codes with spaces
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postalCode);
};

// Form validation
const validateForm = (data: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];

  // First name
  if (!validateRequired(data.first_name || '')) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  // Last name
  if (!validateRequired(data.last_name || '')) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  // Street address
  if (!validateRequired(data.street_address || '')) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }

  // City
  if (!validateRequired(data.city || '')) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  // State/Province/Region
  if (!validateRequired(data.state_province || '')) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }

  // Postal code
  if (!validateRequired(data.postal_code || '')) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(data.postal_code || '')) {
    errors.push({ field: 'postal_code', message: 'Postal code must be alphanumeric' });
  }

  // Country
  if (!validateRequired(data.country || '')) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email
  if (!validateRequired(data.email || '')) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email || '')) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone
  if (!validateRequired(data.phone || '')) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone || '')) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }

  return errors;
};

// Initialize database
const initDatabase = async (): Promise<void> => {
  try {
    // Ensure data directory exists
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    // Load SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Try to load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      const arrayBuffer = fileBuffer.buffer.slice(fileBuffer.byteOffset, fileBuffer.byteOffset + fileBuffer.byteLength);
      db = new SQL.Database(arrayBuffer);
    } else {
      db = new SQL.Database();
    }

    // Create table if not exists
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    if (db) {
      db.exec(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

// Save database to disk
const saveDatabase = (): void => {
  if (db) {
    const data = db.export();
    // Convert Uint8Array to Buffer properly to handle NonSharedBuffer type
    fs.writeFileSync(DB_PATH, Buffer.from(data.buffer, data.byteOffset, data.byteLength));
  }
};

// Routes
app.get('/', (req: Request, res: Response) => {
  const errors = req.query.errors ? JSON.parse(req.query.errors as string) : [];
  const formData = req.query.formData ? JSON.parse(req.query.formData as string) : {};
  
  res.render('form', {
    errors,
    formData,
    errorMap: errors ? errors.reduce((map: Record<string, string>, error: ValidationError) => {
      map[error.field] = error.message;
      return map;
    }, {}) : {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.redirect(`/?errors=${encodeURIComponent(JSON.stringify(errors))}&formData=${encodeURIComponent(JSON.stringify(formData))}`);
  }

  if (!db) {
    return res.status(500).send('Database not available');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Failed to save submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown
const shutdown = () => {
  console.log('Shutting down...');
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  process.exit(0);
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
const startServer = async () => {
  try {
    await initDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer().catch((error) => {
  console.error('Error starting application:', error);
  process.exit(1);
});