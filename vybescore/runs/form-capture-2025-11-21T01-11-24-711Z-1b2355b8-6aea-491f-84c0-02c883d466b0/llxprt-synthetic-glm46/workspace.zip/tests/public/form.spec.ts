import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let server: unknown;
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Create a simple mock server for testing
  app = express();
  
  // Set up middleware
  app.use(express.urlencoded({ extended: true }));
  
  // Mock routes for testing
  app.get('/', (req, res) => {
    res.send(`
      <html>
        <body>
          <form method="post" action="/submit">
            <input name="first_name" type="text" />
            <input name="last_name" type="text" />
            <input name="street_address" type="text" />
            <input name="city" type="text" />
            <input name="state_province" type="text" />
            <input name="postal_code" type="text" />
            <input name="country" type="text" />
            <input name="email" type="text" />
            <input name="phone" type="text" />
            <button type="submit">Submit</button>
          </form>
        </body>
      </html>
    `);
  });
  
  app.post('/submit', (req, res) => {
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    res.send('<html><body><h1>Thank You</h1></body></html>');
  });
  
  server = app.listen(3536);  // Use a different port to avoid conflicts
});

afterAll(() => {
  if (server && typeof server === 'object' && server && 'close' in server) {
    (server as { close: () => void }).close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('form[method="post"][action="/submit"]').length).toBe(1);
    expect($('input[name="first_name"]').length).toBe(1);
    expect($('input[name="last_name"]').length).toBe(1);
    expect($('input[name="street_address"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="state_province"]').length).toBe(1);
    expect($('input[name="postal_code"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'State',
      postal_code: '12345',
      country: 'Country',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Get the form first
    const getResponse = await request(app).get('/');
    expect(getResponse.status).toBe(200);
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Get the thank you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
  });
});