/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Valid Base64 characters (standard alphabet plus optional padding).
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates the input.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate the input format
  if (!BASE64_REGEX.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for padding issues
  const trimmed = input.trim();
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = trimmed.slice(paddingIndex);
    // Padding can only be at the end and can be 1 or 2 '=' characters
    if (!/^[=]{1,2}$/.test(padding)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    // Verify the encoding was valid by checking if we get the same result when re-encoding
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReencoded = reencoded.replace(/=+$/g, '');
    const normalizedInput = trimmed.replace(/=+$/g, '');
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
