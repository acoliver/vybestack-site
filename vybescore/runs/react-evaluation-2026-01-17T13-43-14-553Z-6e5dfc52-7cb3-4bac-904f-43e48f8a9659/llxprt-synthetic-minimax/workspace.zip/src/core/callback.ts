/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  Reactive,
  Observer,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Reactive<T> = {
    value,
    updateFn,
    observers: new Set()
  }
  
  // Store the unsubscribe state
  let disposed = false
  
  // Execute the callback to establish dependencies
  const executeCallback = () => {
    if (observer.updateFn && !disposed) {
      const result = observer.updateFn(observer.value)
      observer.value = result
    }
  }
  
  // Execute immediately once to establish dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(observer as unknown as Observer<unknown>)
  
  try {
    executeCallback()
  } finally {
    setActiveObserver(previousObserver)
  }
  
  // Return unsubscribe function that also handles updates
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear references to stop updates
    observer.value = undefined as unknown
    observer.updateFn = undefined
  }
}
