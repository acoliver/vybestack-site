/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  Reactive,
  Observer,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const o: Reactive<T> = {
    value,
    updateFn,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    // Set this observer as active during dependency collection
    const previousObserver = getActiveObserver()
    setActiveObserver(o as unknown as Observer<unknown>)
    
    try {
      // This will execute updateFn and track dependencies
      if (o.updateFn) {
        o.value = o.updateFn(o.value)
      }
    } finally {
      // Restore previous observer after we've computed the value
      setActiveObserver(previousObserver)
    }
    
    return o.value!
  }

  return read
}
