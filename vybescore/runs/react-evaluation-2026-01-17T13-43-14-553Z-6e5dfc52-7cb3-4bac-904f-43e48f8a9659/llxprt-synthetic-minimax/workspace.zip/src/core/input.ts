/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  GetterFn,
  SetterFn,
  EqualFn,
  Options,
  Node,
  getActiveObserver,
  setActiveObserver,
  updateReactive,
  Reactive
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const node: Node<T> = {
    value,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      node.observers.add(observer as unknown as Node<unknown>)
    }
    return node.value
  }

  const write: SetterFn<T> = (nextValue) => {
    node.value = nextValue
    
    // Clear global state before triggering updates
    const previousObserver = getActiveObserver()
    setActiveObserver(undefined)
    
    try {
      // Notify all observers when input changes
      const observers = Array.from(node.observers)
      for (const observer of observers) {
        if (observer && typeof observer === 'object' && observer.updateFn) {
          updateReactive(observer as unknown as Reactive<unknown>)
        }
      }
    } finally {
      // Restore previous observer state
      setActiveObserver(previousObserver)
    }
    
    return node.value
  }

  return [read, write]
}
