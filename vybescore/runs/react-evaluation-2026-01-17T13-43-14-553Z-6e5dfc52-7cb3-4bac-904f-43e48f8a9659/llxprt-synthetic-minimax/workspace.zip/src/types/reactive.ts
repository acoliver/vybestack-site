/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core interfaces for the reactive system
export interface Node<T> {
  value: T
  observers: Set<Node<unknown>>
}

export interface Reactive<T> {
  value?: T
  updateFn?: UpdateFn<T>
  observers: Set<Reactive<unknown>>
}

export interface Observer<T> {
  value?: T
  updateFn?: UpdateFn<T>
  subjects: Set<Reactive<unknown>>
  observers: Set<Reactive<unknown>>
}

export interface Subject<T> {
  value: T
  observers: Set<Observer<unknown>>
  get(): T
  set(value: T): void
}

// Global state for tracking active observer during dependency collection
let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateReactive<T>(reactive: Reactive<T>): void {
  if (!reactive.updateFn) return
  
  const previous = activeObserver
  setActiveObserver(reactive as unknown as Observer<unknown>)
  try {
    reactive.value = reactive.updateFn!(reactive.value)
  } finally {
    setActiveObserver(previous)
  }
  
  // Notify all observers after this reactive is updated
  for (const dependent of reactive.observers) {
    updateReactive(dependent as unknown as Reactive<unknown>)
  }
}
