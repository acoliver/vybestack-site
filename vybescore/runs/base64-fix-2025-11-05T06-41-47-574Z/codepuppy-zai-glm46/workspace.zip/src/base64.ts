/**
 * Encode plain text to Base64 using RFC 4648 canonical alphabet.
 * Uses standard Base64 with + and / characters, and includes required = padding.
 */
export function encode(input: string): string {
  // Convert input string to bytes using UTF-8 encoding
  const bytes = Buffer.from(input, 'utf8');
  
  // Use built-in base64 encoding which already follows RFC 4648
  // This gives us the correct alphabet (+ and /) and proper padding (=)
  return bytes.toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8, following RFC 4648.
 * Accepts valid Base64 input (with or without padding) and throws errors
 * for invalid input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Empty input provided');
  }

  // Validate Base64 format - must contain only valid characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 format');
  }

  // Check for invalid padding patterns
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding exists, it must be at the end and最多 2 characters
    const paddingPart = input.substring(paddingIndex);
    if (paddingPart.length > 2 || !/^[=]+$/.test(paddingPart)) {
      throw new Error('Invalid Base64 padding');
    }
    // Non-padding characters cannot appear after padding
    if (paddingPart.length !== input.length - paddingIndex) {
      throw new Error('Invalid Base64 padding in middle');
    }
  }

  try {
    // Buffer's base64 decoding handles padding automatically
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}