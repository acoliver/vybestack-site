import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

interface ValidationError {
  field: string;
  message: string;
}

function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } | { error: ValidationError[] } {
  const errors: ValidationError[] = [];

  let page = DEFAULT_PAGE;
  let limit = DEFAULT_LIMIT;

  if (pageParam !== undefined) {
    const pageNum = Number(pageParam);
    if (Number.isNaN(pageNum)) {
      errors.push({ field: 'page', message: 'must be a number' });
    } else if (!Number.isInteger(pageNum)) {
      errors.push({ field: 'page', message: 'must be an integer' });
    } else if (pageNum < 1) {
      errors.push({ field: 'page', message: 'must be greater than 0' });
    } else {
      page = pageNum;
    }
  }

  if (limitParam !== undefined) {
    const limitNum = Number(limitParam);
    if (Number.isNaN(limitNum)) {
      errors.push({ field: 'limit', message: 'must be a number' });
    } else if (!Number.isInteger(limitNum)) {
      errors.push({ field: 'limit', message: 'must be an integer' });
    } else if (limitNum < 1) {
      errors.push({ field: 'limit', message: 'must be greater than 0' });
    } else if (limitNum > MAX_LIMIT) {
      errors.push({ field: 'limit', message: `must not exceed ${MAX_LIMIT}` });
    } else {
      limit = limitNum;
    }
  }

  if (errors.length > 0) {
    return { error: errors };
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);

    if ('error' in validation) {
      res.status(400).json({ errors: validation.error });
      return;
    }

    const { page, limit } = validation;
    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
