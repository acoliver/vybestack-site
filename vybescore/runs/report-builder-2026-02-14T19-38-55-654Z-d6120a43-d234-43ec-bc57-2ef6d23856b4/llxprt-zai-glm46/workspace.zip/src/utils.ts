import type { ReportData } from './types.js';

export function formatAmount(amount: number): string {
  return '$' + amount.toFixed(2);
}

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  const obj = data as Record<string, unknown>;
  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid title field');
  }
  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid summary field');
  }
  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid entries field');
  }
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
    }
  }
  return data as ReportData;
}
