import type { Formatter } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';
import { formatAmount, validateReportData } from './utils.js';

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: string): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

export type { Formatter } from './types.js';
export type { ReportData, ReportEntry, FormatOptions } from './types.js';
export { formatAmount, validateReportData };
