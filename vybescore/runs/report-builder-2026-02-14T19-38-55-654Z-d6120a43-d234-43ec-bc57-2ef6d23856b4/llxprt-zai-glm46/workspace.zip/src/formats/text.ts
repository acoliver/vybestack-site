import type { ReportData, FormatOptions } from '../types.js';
import { formatAmount } from '../utils.js';

export function renderText(data: ReportData, options: FormatOptions): string {
  const lines: string[] = [];
  lines.push(data.title);
  lines.push(data.summary);
  lines.push('Entries:');

  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
}
