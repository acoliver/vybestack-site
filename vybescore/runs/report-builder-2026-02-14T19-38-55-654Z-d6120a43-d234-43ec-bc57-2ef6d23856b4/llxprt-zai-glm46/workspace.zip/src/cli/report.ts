#!/usr/bin/env node
import * as fs from 'fs';
import { getFormatter, validateReportData } from '../index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    dataFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (result.dataFile === '') {
      result.dataFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
    i++;
  }

  if (!result.dataFile) {
    throw new Error('Missing required argument: data file path');
  }
  if (!result.format) {
    throw new Error('Missing required option: --format');
  }

  return result;
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));

    const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (err) {
      throw new Error(`Failed to parse JSON file: ${args.dataFile}`);
    }

    const reportData = validateReportData(data);

    const formatter = getFormatter(args.format);
    const output = formatter(reportData, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
