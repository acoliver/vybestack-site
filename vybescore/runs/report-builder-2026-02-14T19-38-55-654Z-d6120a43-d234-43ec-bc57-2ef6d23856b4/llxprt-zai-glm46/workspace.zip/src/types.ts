/**
 * Data model for report entries
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure from JSON input
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options passed to formatters
 */
export interface FormatOptions {
  includeTotals: boolean;
}

/**
 * Formatter function interface
 */
export type Formatter = (data: ReportData, options: FormatOptions) => string;
