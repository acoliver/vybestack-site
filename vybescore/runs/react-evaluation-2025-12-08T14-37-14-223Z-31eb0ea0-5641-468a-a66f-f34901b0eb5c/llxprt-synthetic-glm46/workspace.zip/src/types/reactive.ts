/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (_lhs: T, _rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (_value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: Observer<unknown> | undefined
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export { activeObserver }

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion using type assertion for set compatibility
  if (updatingObservers.has(observer as Observer<unknown>)) {
    return
  }
  
  updatingObservers.add(observer as Observer<unknown>)
  try {
    const previous = activeObserver
    activeObserver = observer
    try {
      if (typeof observer.updateFn === 'function') {
        observer.value = observer.updateFn(observer.value)
      }
    } finally {
      activeObserver = previous
    }
    // Recursively update observer's observer if it exists and has updateFn
    if (observer.observer) {
      const obsWithUpdate = observer.observer as Observer<unknown>
      if (typeof obsWithUpdate.updateFn === 'function') {
        updateObserver(obsWithUpdate)
      }
    }
  } finally {
    updatingObservers.delete(observer as Observer<unknown>)
  }
}

// Set to track currently updating observers to prevent infinite recursion
const updatingObservers = new Set<Observer<unknown>>()

export function shouldUpdate<T>(prevValue: T, nextValue: T, equalFn?: EqualFn<T>): boolean {
  if (equalFn) {
    return !equalFn(prevValue, nextValue)
  }
  return prevValue !== nextValue
}