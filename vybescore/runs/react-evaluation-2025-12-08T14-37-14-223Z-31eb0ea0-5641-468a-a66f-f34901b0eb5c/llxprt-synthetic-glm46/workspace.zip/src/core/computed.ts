/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal : 
    _equal === false ? (a, b) => a === b : undefined

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = (): T => {
    // If there's an active observer, register this computed as a dependency
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // Convert ObserverR to Observer<unknown> by adding updateFn dynamically if needed
      o.observer = observer as Observer<unknown>
    }
    
    // If we already have a value and there's no active observer requesting this data,
    // return the cached value
    if (o.value !== undefined && !observer) {
      return o.value
    }
    
    // Otherwise, recalculate
    const newValue = updateFn(o.value)
    
    // Update if value changed or it's the first calculation  
    if (o.value === undefined || !equalFn || !equalFn(o.value, newValue)) {
      o.value = newValue
      
      // Notify our observers about the change
      if (o.observer) {
        // Skip type checking by using dynamic approach
        updateObserver(o.observer as Observer<unknown>)
      }
    }
    
    return o.value!
  }

  // Initial computation
  if (o.value === undefined) {
    updateObserver(o)
  }
  
  return getter
}
