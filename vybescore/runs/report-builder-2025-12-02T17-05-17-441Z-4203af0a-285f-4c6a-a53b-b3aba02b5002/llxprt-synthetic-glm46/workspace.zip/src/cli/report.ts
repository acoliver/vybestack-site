#!/usr/bin/env node

import fs from 'fs';

import { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CLIArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: Partial<CLIArgs> = {
    includeTotals: false
  };
  
  let i = 0;
  result.dataPath = args[i++];
  
  while (i < args.length) {
    const arg = args[i++];
    
    if (arg === '--format') {
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[i++];
    } else if (arg === '--output') {
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = args[i++];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument ${arg}`);
      process.exit(1);
    }
  }
  
  if (!result.dataPath || !result.format) {
    console.error('Error: Missing required arguments');
    process.exit(1);
  }
  
  return result as CLIArgs;
}

function loadData(dataPath: string): ReportData {
  try {
    const content = fs.readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (
      typeof data !== 'object' || data === null ||
      !('title' in data) || !('summary' in data) || !('entries' in data)
    ) {
      throw new Error('Invalid report data structure');
    }
    
    const { title, summary, entries } = data as { title: unknown; summary: unknown; entries: unknown };
    
    if (
      typeof title !== 'string' ||
      typeof summary !== 'string' ||
      !Array.isArray(entries)
    ) {
      throw new Error('Invalid report data structure');
    }
    
    for (const entry of entries) {
      if (
        typeof entry !== 'object' || entry === null ||
        !('label' in entry) || !('amount' in entry) ||
        typeof (entry as { label: unknown }).label !== 'string' ||
        typeof (entry as { amount: unknown }).amount !== 'number'
      ) {
        throw new Error('Invalid entry structure');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${dataPath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    }
    process.exit(1);
  }
}

function getRenderer(format: string): ReportRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
      process.exit(1);
  }
}

function main(): void {
  const args = parseArgs();
  const data = loadData(args.dataPath);
  const renderer = getRenderer(args.format);
  const options: ReportOptions = {
    includeTotals: args.includeTotals
  };
  
  const output = renderer(data, options);
  
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing to ${args.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();