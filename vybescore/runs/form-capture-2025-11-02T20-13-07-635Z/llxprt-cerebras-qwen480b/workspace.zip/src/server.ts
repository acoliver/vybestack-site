import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { validateEmail, validatePhone, validatePostalCode, validateRequiredField } from './validation.js';
import { initDatabase, saveSubmission, closeDatabase } from './database.js';
import { Server } from 'http';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Validation helpers
function validateForm(req: Request): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  
  // Validate required fields
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    const error = validateRequiredField(req.body[field]);
    if (error) {
      errors[field] = error;
    }
  }
  
  // Validate email
  const emailError = validateEmail(req.body.email);
  if (emailError) {
    errors.email = emailError;
  }
  
  // Validate phone
  const phoneError = validatePhone(req.body.phone);
  if (phoneError) {
    errors.phone = phoneError;
  }
  
  // Validate postal code
  const postalCodeError = validatePostalCode(req.body.postalCode);
  if (postalCodeError) {
    errors.postalCode = postalCodeError;
  }
  
  return { isValid: Object.keys(errors).length === 0, errors };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const { isValid, errors } = validateForm(req);
  
  if (!isValid) {
    return res.status(400).render('form', { errors, formData: req.body });
  }
  
  try {
    saveSubmission(
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    );
    res.redirect(302, '/thank-you');
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).render('form', { 
      errors: { general: 'An error occurred while saving your data. Please try again.' }, 
      formData: req.body 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
let server: Server | null = null;
let dbInitialized = false;

initDatabase().then(() => {
  dbInitialized = true;
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  if (process.env.NODE_ENV !== 'test') {
    process.exit(1);
  }
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server?.close(() => {
    console.log('Express server closed');
    closeDatabase();
    console.log('Database closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  server?.close(() => {
    console.log('Express server closed');
    closeDatabase();
    console.log('Database closed');
    process.exit(0);
  });
});

export default app;
export { dbInitialized };