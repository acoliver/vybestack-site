// Validation functions for form inputs

export function validateRequiredField(value: string): string | null {
  if (!value || value.trim() === '') {
    return 'This field is required';
  }
  return null;
}

export function validateEmail(email: string): string | null {
  const error = validateRequiredField(email);
  if (error) return error;
  
  // Simple email regex pattern
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
}

export function validatePhone(phone: string): string | null {
  const error = validateRequiredField(phone);
  if (error) return error;
  
  // Allow digits, spaces, parentheses, dashes, and a leading +
  // We need to be careful with the regex pattern to avoid range errors
  const phoneRegex = /^[0-9+\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return 'Please enter a valid phone number';
  }
  return null;
}

export function validatePostalCode(postalCode: string): string | null {
  const error = validateRequiredField(postalCode);
  if (error) return error;
  
  // Accept alphanumeric strings with spaces and dashes
  const postalCodeRegex = /^[0-9a-zA-Z\s-]+$/;
  if (!postalCodeRegex.test(postalCode)) {
    return 'Please enter a valid postal code';
  }
  return null;
}