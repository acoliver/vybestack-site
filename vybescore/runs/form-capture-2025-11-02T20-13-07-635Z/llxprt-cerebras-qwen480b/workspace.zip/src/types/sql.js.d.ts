declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: Array<unknown>): Database;
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  export default function initSqlJs(config?: { locateFile: (file: string) => string }): Promise<SqlJsStatic>;
}