import * as fs from 'fs';
import * as path from 'path';
import initSqlJs, { Database } from 'sql.js';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure data directory exists
const dataDir = path.resolve(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Database file path
const dbPath = path.resolve(dataDir, 'submissions.sqlite');

// Initialize database
let db: Database | null = null;

export async function initDatabase(): Promise<Database> {
  // In test environments, we may not have access to CDN - so we'll mock the DB behavior
  if (process.env.NODE_ENV === 'test') {
    const SQL = await initSqlJs();
    db = new SQL.Database();
    const schema = fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    return db;
  }

  // For non-test environments (production/development)
  const SQL = await initSqlJs({
    locateFile: (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.3/${file}`
  });

  // Load existing database or create a new one
  let dbData: Uint8Array | undefined = undefined;
  if (fs.existsSync(dbPath)) {
    dbData = fs.readFileSync(dbPath);
  }

  db = new SQL.Database(dbData);
  
  // Create table if it doesn't exist
  const schema = fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8');
  db.run(schema);
  
  return db;
}

export function saveSubmission(
  firstName: string,
  lastName: string,
  streetAddress: string,
  city: string,
  stateProvince: string,
  postalCode: string,
  country: string,
  email: string,
  phone: string
): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const query = `
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.run(query, [
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  ]);

  // Write database to file (not needed for test environment)
  if (process.env.NODE_ENV !== 'test') {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}