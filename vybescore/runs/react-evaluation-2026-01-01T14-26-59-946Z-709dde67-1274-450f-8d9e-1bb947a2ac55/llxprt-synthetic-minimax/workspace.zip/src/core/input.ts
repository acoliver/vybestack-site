/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  InputNode,
  getCurrentObserver,
  setCurrentObserver,
  updateInputNode,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const input: any = {
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
    dependents: new Set()
  }

  const read: GetterFn<T> = () => {
    // Track dependencies when this input is read
    const observer = getCurrentObserver()
    if (observer) {
      // Register this input as the dependency of the observer
      observer.dependency = input
      input.dependents.add(observer)
    }
    return input.value
  }

  const write: SetterFn<T> = (nextValue) => {
    input.value = nextValue
    
    // Notify all dependents when the input changes
    updateInputNode(input)
    
    return input.value
  }

  return [read, write]
}
