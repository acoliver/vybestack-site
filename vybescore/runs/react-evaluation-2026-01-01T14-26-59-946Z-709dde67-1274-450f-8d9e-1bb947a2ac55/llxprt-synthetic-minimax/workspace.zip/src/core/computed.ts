/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  ComputedNode,
  InputNode,
  Observer,
  updateComputedNode,
  getCurrentObserver,
  setCurrentObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

export type ComputedFn<T> = () => T

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  computeFn: ComputedFn<T>,
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const node: ComputedNode<T> = {
    value: _value as T,
    computeFn,
    dependents: new Set()
  }

  const getter: GetterFn<T> = () => {
    // Set this computed node as current observer for dependency tracking
    const prevObserver = getCurrentObserver()
    try {
      setCurrentObserver(node as any)
      // Recompute value during access
      node.value = computeFn()
    } finally {
      setCurrentObserver(prevObserver)
    }
    
    return node.value
  }

  return getter
}
