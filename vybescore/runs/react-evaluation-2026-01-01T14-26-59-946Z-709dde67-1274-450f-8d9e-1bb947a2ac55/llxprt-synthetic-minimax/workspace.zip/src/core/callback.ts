/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let isDisposed = false
  
  const observer: any = {
    value,
    updateFn,
    dependents: new Set()
  }
  
  // Execute the callback once to initialize
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    if (isDisposed) return
    isDisposed = true
    
    // Clear the observer's update function to stop further execution
    observer.updateFn = () => {
      return undefined as unknown
    }
    observer.value = undefined
    
    // Remove from all dependency relationships
    if (observer.dependency && 'dependents' in observer.dependency && observer.dependency.dependents) {
      observer.dependency.dependents.delete(observer)
    }
  }
}
