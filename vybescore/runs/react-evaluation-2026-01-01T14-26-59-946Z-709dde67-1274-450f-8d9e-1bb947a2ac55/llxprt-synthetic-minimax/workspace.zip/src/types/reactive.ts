/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core interfaces for the reactive system
export interface InputNode<T> {
  value: T
  equalFn?: EqualFn<T>
  dependents: Set<any>
}

export interface ComputedNode<T> {
  value: T
  computeFn: () => T
  dependency?: InputNode<any>
  dependents: Set<any>
}

export interface CallbackNode<T> {
  value?: T
  updateFn: UpdateFn<T>
  dependency?: ComputedNode<any>
}

// Core observer interface for the reactive system
export interface Observer<T = unknown> {
  value?: T
  name?: string
  updateFn: UpdateFn<T>
  dependency?: any
  dependents?: Set<any>
}

// Subject types for different value types
export interface SubjectR<T> {
  readonly value: T
}

export interface SubjectV<T> {
  value: T
}

export interface Subject<T> extends SubjectV<T> {}

// Additional observer types for reactive pattern
export interface ObserverR<T> extends Observer<T> {
  readonly value: T
}

export interface ObserverV<T> extends Observer<T> {
  value: T
}

// Global state for tracking the current observer being created
let currentObserver: any = undefined

export function setCurrentObserver(observer: any) {
  currentObserver = observer
}

export function getCurrentObserver() {
  return currentObserver
}

// Update functions for each type of node
export function updateInputNode<T>(input: InputNode<T>) {
  // When an input changes, notify all its dependents
  for (const dependent of [...input.dependents]) {
    if ('computeFn' in dependent) {
      // It's a computed node - trigger recomputation
      updateComputedNode(dependent)
    } else {
      // It's a callback node - trigger immediately
      updateObserver(dependent)
    }
  }
}

export function updateComputedNode<T>(computed: ComputedNode<T>) {
  // Recompute the value when dependencies change
  const prevObserver = getCurrentObserver()
  try {
    // Set as current observer so inputs can register dependencies
    setCurrentObserver(computed)
    computed.value = computed.computeFn()
  } finally {
    setCurrentObserver(prevObserver)
  }
  
  // Notify dependents (callbacks)
  for (const dependent of [...computed.dependents]) {
    updateObserver(dependent)
  }
}

export function updateObserver<T>(observer: any) {
  // Execute the observer's update function
  if (observer.updateFn) {
    observer.value = observer.updateFn(observer.value)
  }
}
