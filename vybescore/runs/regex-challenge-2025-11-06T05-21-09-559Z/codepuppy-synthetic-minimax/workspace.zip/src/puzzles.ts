/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex to find words starting with the prefix
  const regexPattern = new RegExp('\\b' + prefix + '[a-zA-Z]*\\b', 'g');
  const matches = text.match(regexPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  return matches
    .filter(word => !exceptionsSet.has(word.toLowerCase()))
    .sort();
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create regex to find digit + token combos
  const regexPattern = new RegExp('(?<!^)\\d' + token, 'g');
  return text.match(regexPattern) || [];
}

/**
 * Validate password strength: at least 10 chars, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (like 'abab').
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like 'abab', '123123', etc.)
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // Check for colon-separated hex patterns (IPv6 signature)
  // Look for patterns with colons that aren't just IPv4 addresses
  const hasColon = value.includes(':');
  if (!hasColon) return false;
  
  // IPv6 patterns - simplified detection
  const ipv6Patterns = [
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/, // Full IPv6
    /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*/, // Compressed with ::
    /(?:[0-9a-fA-F]{1,4}:)*:(?:\d{1,3}\.){3}\d{1,3}/, // IPv6 with embedded IPv4
    /::ffff:(?:\d{1,3}\.){3}\d{1,3}/ // IPv6-mapped IPv4
  ];
  
  return ipv6Patterns.some(pattern => pattern.test(value));
}