/**
 * Capitalize the first character of each sentence, insert proper spacing between sentences,
 * and collapse extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Normalize multiple spaces to single spaces, but preserve sentence boundaries
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Insert space between sentences if missing (after .!? followed by capital letter)
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Capitalize first letter of sentences
  // Look for sentence boundaries (start of string or after .!? followed by whitespace)
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize the very first character if it's lowercase
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  return result;
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern matching:
  // - http:// or https:// protocols
  // - www. without protocol
  // - Domain names with optional subdomains
  // - Optional port numbers
  // - Optional paths, query strings, fragments
  // - Don't include trailing punctuation like .,!?) etc.
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<>"']+)(?<![.,!?;:')])/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:')">\]}]+$/g, ''));
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but don't touch https://
  // Use word boundary to ensure we're matching the protocol
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match example.com URLs
  // Captures: full URL, protocol, domain, path
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check for dynamic content that should skip host rewrite
    const hasDynamicContent = /[\/](?:cgi-bin|.*\/[^\/]*\.(?:jsp|php|asp|aspx|do|cgi|pl|py))(?:[?#]|$)/i.test(path) ||
                               /[?#]/.test(path);
    
    // If path starts with /docs/ and no dynamic content, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicContent) {
      return secureProtocol + 'docs.example.com' + path;
    }
    
    // Otherwise just upgrade the protocol
    return secureProtocol + domain + path;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const [, month, day, year] = dateMatch;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day against month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  const maxDays = monthNum === 2 ? (isLeapYear ? 29 : 28) : daysInMonth[monthNum - 1];
  
  if (dayNum > maxDays) return 'N/A';
  
  return year;
}
