export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses supporting common formats like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows letters, numbers, dots, hyphens, plus signs in local part
  // - Prevents consecutive dots, leading/trailing dots in local part
  // - Allows unicode letters but not underscores in domain
  // - Prevents double dots, trailing dots in domain
  // - Requires 2-64 char TLD
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?<![.])@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,64}$/;
  
  // Additional checks for patterns that regex can't easily catch
  if (!emailRegex.test(value)) return false;
  
  // Prevent consecutive dots anywhere
  if (value.includes('..')) return false;
  
  // Prevent domain starting/ending with hyphen or dot
  const [, domain] = value.split('@');
  if (domain.startsWith('-') || domain.endsWith('-') || domain.startsWith('.')) return false;
  
  return true;
}

/**
 * Validate US phone numbers supporting formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Extract area code (first 3 digits, or digits 2-4 if +1 prefix)
  let areaCode: string;
  if (digitsOnly.length === 11) {
    // Must start with 1 for US country code
    if (!digitsOnly.startsWith('1')) return false;
    areaCode = digitsOnly.substring(1, 4);
  } else {
    areaCode = digitsOnly.substring(0, 3);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check overall format supports common patterns
  const phoneRegex = /^\+?(1[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers supporting landlines and mobiles.
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces and hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Try to match with optional mobile indicator 9
  
  // Try to match with optional mobile indicator 9
  const match = cleaned.match(/^(\+54)?9?(0?[1-9]\d{1,3})(\d{6,8})$/);
  if (!match) return false;
  
  const [, countryCode, areaCode, subscriber] = match;
  
  // If no country code, must start with trunk prefix 0
  if (!countryCode && !areaCode.startsWith('0')) return false;
  
  // Validate area code length (2-4 digits after removing optional 0)
  const areaCodeDigits = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (areaCodeDigits.length < 2 || areaCodeDigits.length > 4) return false;
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Must contain at least one letter
  // Reject digits and most symbols except allowed punctuation
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  // Reject names that contain multiple consecutive symbols or look unconventional
  const symbolPattern = /['’\-]{2,}/;
  if (symbolPattern.test(value)) return false;
  
  // Reject names that are just symbols or too short
  const trimmed = value.trim();
  if (trimmed.length < 1) return false;
  
  // Additional check to reject overly symbolic names like 'X Æ A-12'
  // Count the ratio of letters to total characters
  const letterCount = (trimmed.match(/[\p{L}\p{M}]/gu) || []).length;
  const totalNonSpaceCount = (trimmed.match(/[^\s]/g) || []).length;
  
  if (totalNonSpaceCount > 0 && letterCount / totalNonSpaceCount < 0.5) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check basic length requirements (13-19 digits for major cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4(\d{12}|\d{15}|\d{18})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9][3-9]\d|2[3-9]\d{2}|[3-6]\d{3}|7([01]\d|20))\d{12}))$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type pattern
  const isValidFormat = visaRegex.test(digitsOnly) || 
                       mastercardRegex.test(digitsOnly) || 
                       amexRegex.test(digitsOnly);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
