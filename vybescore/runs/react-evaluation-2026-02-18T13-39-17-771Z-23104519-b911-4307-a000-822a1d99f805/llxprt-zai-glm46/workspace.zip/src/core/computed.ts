/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: Set<Observer<unknown>> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Track this computed as a dependency of the active observer
      observers.add(activeObserver as Observer<unknown>)
    }
    return o.value!
  }
  
  // Override updateFn to propagate changes to our observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Recompute value
    o.value = originalUpdateFn(prevValue)
    // Notify all our observers
    observers.forEach(obs => updateObserver(obs))
    return o.value!
  }
  
  return getter
}
