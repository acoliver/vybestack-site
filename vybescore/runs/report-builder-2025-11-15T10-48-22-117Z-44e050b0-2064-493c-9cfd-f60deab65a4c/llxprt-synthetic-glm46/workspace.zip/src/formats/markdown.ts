import { ReportData, ReportOptions, FormatRenderer } from '../types.js';

export const renderMarkdown: FormatRenderer = (data: ReportData, options: ReportOptions): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;
  
  // Calculate total if needed
  const total = includeTotals 
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : 0;
  
  // Build the output
  const output: string[] = [
    `# ${title}`,
    '',
    summary,
    '',
    '## Entries',
    ''
  ];
  
  // Add entries
  for (const entry of entries) {
    output.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }
  
  // Add total if requested
  if (includeTotals) {
    output.push('');
    output.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return output.join('\n');
};