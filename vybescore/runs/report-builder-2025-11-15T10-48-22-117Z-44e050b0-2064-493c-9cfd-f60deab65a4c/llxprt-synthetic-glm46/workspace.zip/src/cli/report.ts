#!/usr/bin/env node

import fs from 'fs';
import { formatters, getSupportedFormats } from '../formatters.js';
import { validateReportData } from '../validation.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): { filePath: string; options: CliOptions } {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    console.error(`Supported formats: ${getSupportedFormats().join(', ')}`);
    process.exit(1);
  }

  const filePath = args[0];
  
  if (!args.includes('--format')) {
    console.error('Error: --format option is required');
    console.error(`Supported formats: ${getSupportedFormats().join(', ')}`);
    process.exit(1);
  }

  const formatIndex = args.indexOf('--format');
  const format = args[formatIndex + 1];
  
  if (!format || !getSupportedFormats().includes(format)) {
    console.error(`Error: Unsupported format "${format}"`);
    console.error(`Supported formats: ${getSupportedFormats().join(', ')}`);
    process.exit(1);
  }

  const options: CliOptions = {
    format,
    includeTotals: args.includes('--includeTotals')
  };

  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1 && outputIndex + 1 < args.length) {
    options.output = args[outputIndex + 1];
  }

  return { filePath, options };
}

function main(): void {
  try {
    const { filePath, options } = parseArguments();

    // Read and parse the JSON file
    let rawData: string;
    try {
      rawData = fs.readFileSync(filePath, 'utf8');
    } catch (error) {
      console.error(`Error: Could not read file "${filePath}"`);
      console.error(error instanceof Error ? error.message : String(error));
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(rawData);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${filePath}"`);
      console.error(error instanceof Error ? error.message : String(error));
      process.exit(1);
    }

    // Validate the data structure
    const reportData = validateReportData(jsonData);

    // Get the appropriate formatter
    const formatter = formatters[options.format];
    if (!formatter) {
      console.error(`Error: Unsupported format "${options.format}"`);
      process.exit(1);
    }

    // Render the report
    const output = formatter(reportData, { includeTotals: options.includeTotals });

    // Write output
    if (options.output) {
      try {
        fs.writeFileSync(options.output, output, 'utf8');
      } catch (error) {
        console.error(`Error: Could not write to file "${options.output}"`);
        console.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
      }
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();