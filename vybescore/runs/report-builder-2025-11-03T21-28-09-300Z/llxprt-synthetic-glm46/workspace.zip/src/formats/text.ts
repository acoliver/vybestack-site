import { ReportFormatter } from '../types.js';

export const renderText: ReportFormatter = (
  data,
  includeTotals
): string => {
  const { title, summary, entries } = data;

  // Calculate total if needed
  const totalAmount = includeTotals
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : 0;

  // Format amount with two decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  // Build the report
  let report = `${title}\n${summary}\n\nEntries:\n`;

  // Add entries
  entries.forEach((entry) => {
    report += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  });

  // Add total if requested
  if (includeTotals) {
    report += `Total: ${formatAmount(totalAmount)}`;
  }

  return report;
};