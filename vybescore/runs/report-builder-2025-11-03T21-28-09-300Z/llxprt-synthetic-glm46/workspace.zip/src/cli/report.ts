#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown, renderText } from '../formats/index.js';

// Available formatters
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

// Parse command line arguments
function parseArguments(args: string[]): ReportOptions & { filePath: string } {
  if (args.length < 4) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    process.exit(1);
  }

  const result = {
    filePath: args[2],
    format: 'markdown' as 'markdown' | 'text',
    includeTotals: false,
    output: undefined as string | undefined,
  };

  // Parse arguments
  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format': {
        if (i + 1 >= args.length) {
          console.error('Missing format value after --format');
          process.exit(1);
        }
        const format = args[i + 1] as 'markdown' | 'text';
        if (format !== 'markdown' && format !== 'text') {
          console.error(`Unsupported format: ${format}`);
          process.exit(1);
        }
        result.format = format;
        i++; // Skip next argument
        break;
      }
      case '--includeTotals':
        result.includeTotals = true;
        break;
      case '--output': {
        if (i + 1 >= args.length) {
          console.error('Missing output path after --output');
          process.exit(1);
        }
        result.output = args[i + 1];
        i++; // Skip next argument
        break;
      }
      default:
        console.error(`Unknown argument: ${args[i]}`);
        process.exit(1);
    }
  }

  return result;
}

// Validate JSON data
function validateData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }

  const entries = reportData.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i] as Record<string, unknown>;
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
    }
    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
    }
  }

  return reportData as unknown as ReportData;
}

// Read and parse JSON file
function readDataFile(filePath: string): ReportData {
  try {
    const resolvedPath = path.resolve(filePath);
    if (!fs.existsSync(resolvedPath)) {
      throw new Error(`File not found: ${resolvedPath}`);
    }

    const fileContents = fs.readFileSync(resolvedPath, 'utf8');
    const data = JSON.parse(fileContents);

    return validateData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${error.message}`);
    }
    throw error;
  }
}

// Generate and output the report
function generateReport() {
  try {
    // Parse command line arguments
    const { filePath, format, includeTotals, output } = parseArguments(
      process.argv
    );

    // Read and validate data file
    const data = readDataFile(filePath);

    // Select formatter
    const formatter = formatters[format];
    if (!formatter) {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }

    // Generate report
    const report = formatter(data, includeTotals);

    // Output report
    if (output) {
      fs.writeFileSync(output, report, 'utf8');
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

// Run the report generator
generateReport();
