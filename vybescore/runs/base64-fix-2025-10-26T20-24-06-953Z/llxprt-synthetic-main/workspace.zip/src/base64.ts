/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input against RFC 4648 specification.
 * Only allows A-Z, a-z, 0-9, +, /, and padding characters.
 */
function isValidBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard alphabet.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
