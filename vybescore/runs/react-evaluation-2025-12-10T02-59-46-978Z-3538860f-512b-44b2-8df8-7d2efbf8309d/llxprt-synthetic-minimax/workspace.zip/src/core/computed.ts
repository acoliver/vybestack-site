/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  registerDependency,
  notifySubscribers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
  }
  
  const compute = () => {
    const previous = getActiveObserver()
    try {
      setActiveObserver(o) // Set this as active observer during computation
      // Call updateFn without arguments to allow default parameters
      const newValue = updateFn()
      o.value = newValue
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Initial computation
  compute()
  
  return (): T => {
    // Always recompute to get fresh value
    compute()
    
    // Register as dependency for any active observer
    const active = getActiveObserver()
    if (active && active !== o) {
      registerDependency(o, active)
    }
    
    // Notify subscribers that this computed value has been updated
    notifySubscribers(o)
    
    return o.value!
  }
}