/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  trackObserver,
  notifySubscribers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      trackObserver(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all subscribers when the value changes
    if (s.subscribers && s.subscribers.size > 0) {
      // Create a dummy observer to trigger notifications
      const dummyObserver = {
        subscribers: s.subscribers
      }
      notifySubscribers(dummyObserver as ObserverR)
    }
    return s.value
  }

  return [read, write]
}
