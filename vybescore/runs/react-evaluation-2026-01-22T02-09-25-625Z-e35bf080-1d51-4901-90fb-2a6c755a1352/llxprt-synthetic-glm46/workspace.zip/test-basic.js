// Basic test to check if reactive core functions work
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing basic functionality...');

try {
  // Test createInput
  const [getter, setter] = createInput(42);
  if (getter() !== 42) throw new Error('Input initial value wrong');
  
  setter(100);
  if (getter() !== 100) throw new Error('Input set value wrong');
  
  // Test createComputed
  const input = getter;
  const double = createComputed(() => input() * 2);
  if (double() !== 200) throw new Error('Computed value wrong');
  
  // Test createCallback returns function
  const unsubscribe = createCallback(() => console.log('test callback'));
  if (typeof unsubscribe !== 'function') throw new Error('Callback should return function');
  unsubscribe(); // Should not throw
  
  console.log('Basic tests passed!');
} catch (error) {
  console.error('Test failed:', error.message);
  process.exit(1);
}