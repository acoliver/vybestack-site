// Direct test of comprehensive functionality
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing comprehensive scenario...');

try {
  // Test compute cells can depend on other compute cells
  const [input, setInput] = createInput(1);
  const timesTwo = createComputed(() => input() * 2);
  const timesThirty = createComputed(() => input() * 30);
  const sum = createComputed(() => timesTwo() + timesThirty());
  
  console.log('Initial sum should be 32:', sum());
  setInput(3);
  console.log('After setInput(3), sum should be 96:', sum());
  
  // Test compute cells fire callbacks
  const [input2, setInput2] = createInput(1);
  const output = createComputed(() => input2() + 1);
  let value = 0;
  createCallback(() => (value = output()));
  setInput2(3);
  console.log('Value after callback should be 4:', value);
  
  // Test callbacks can be added and removed
  const [input3, setInput3] = createInput(11);
  const output2 = createComputed(() => input3() + 1);

  const values1 = [];
  const unsubscribe1 = createCallback(() => values1.push(output2()));
  const values2 = [];
  createCallback(() => values2.push(output2()));

  setInput3(31);
  unsubscribe1();
  setInput3(41);

  console.log('values1 length:', values1.length);
  console.log('values2 length:', values2.length);
  console.log('values2 should have more values:', values2.length > values1.length);
  
  console.log('All comprehensive tests passed!');
} catch (error) {
  console.error('Test failed:', error);
  process.exit(1);
}