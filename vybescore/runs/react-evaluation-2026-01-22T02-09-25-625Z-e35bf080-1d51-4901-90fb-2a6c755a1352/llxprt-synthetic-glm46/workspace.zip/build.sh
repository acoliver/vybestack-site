#!/bin/bash
tsc -p tsconfig.build.json
echo 'export * from "./src/index.js"' > dist/index.js
echo 'export * from "./src/types/reactive.js"' >> dist/index.js