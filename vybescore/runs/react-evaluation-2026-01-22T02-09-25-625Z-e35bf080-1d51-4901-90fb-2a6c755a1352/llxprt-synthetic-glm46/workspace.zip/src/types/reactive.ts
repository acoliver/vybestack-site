/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & ReactiveNode

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & ReactiveNode

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  // Clear existing dependencies before recomputing
  observer.cleanup()
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Dependency tracking system

export class ReactiveNode {
  subscribers: Set<Observer<unknown>> = new Set()
  dependencies: Set<ReactiveNode> = new Set()
  
  subscribe(subscriber: Observer<unknown>): void {
    this.subscribers.add(subscriber)
  }
  
  unsubscribe(subscriber: Observer<unknown>): void {
    this.subscribers.delete(subscriber)
  }
  
  addDependency(node: ReactiveNode): void {
    this.dependencies.add(node)
  }
  
  removeDependency(node: ReactiveNode): void {
    this.dependencies.delete(node)
  }
  
  notify(): void {
    for (const subscriber of this.subscribers) {
      updateObserver(subscriber)
    }
  }
  
  cleanup(): void {
    // Clear dependencies first
    for (const dependency of this.dependencies) {
      dependency.unsubscribe(this as unknown as Observer<unknown>)
    }
    this.dependencies.clear()
    // Clear subscribers
    this.subscribers.clear()
  }
}
