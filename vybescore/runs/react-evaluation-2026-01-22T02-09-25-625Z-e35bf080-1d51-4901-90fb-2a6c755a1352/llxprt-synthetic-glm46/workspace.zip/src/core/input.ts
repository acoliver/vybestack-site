/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = typeof _equal === 'function' ? _equal : 
    _equal === true ? (a: T, b: T) => a === b : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    subscribers: new Set(),
    dependencies: new Set(),
    subscribe: (subscriber) => s.subscribers.add(subscriber),
    unsubscribe: (subscriber) => s.subscribers.delete(subscriber),
    addDependency: (node) => s.dependencies.add(node),
    removeDependency: (node) => s.dependencies.delete(node),
    notify: () => {
      for (const subscriber of s.subscribers) {
        updateObserver(subscriber)
      }
    },
    cleanup: () => {
      // Clear dependencies first
      for (const dependency of s.dependencies) {
        dependency.unsubscribe(s as unknown as Observer<unknown>)
      }
      s.dependencies.clear()
      // Clear subscribers
      s.subscribers.clear()
    }
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Use type assertion because ObserverR doesn't have addDependency method
      // but active observer should be Observer<T> implementation
      const fullObserver = observer as Observer<T>
      s.subscribe(observer as unknown as Observer<unknown>)
      fullObserver.addDependency(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed if equalFn is provided
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    s.notify()
    return s.value
  }

  return [read, write]
}
