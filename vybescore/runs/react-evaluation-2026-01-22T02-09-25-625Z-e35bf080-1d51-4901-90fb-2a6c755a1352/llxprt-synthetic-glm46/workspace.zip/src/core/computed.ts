/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
    dependencies: new Set(),
    subscribe: (subscriber) => o.subscribers.add(subscriber),
    unsubscribe: (subscriber) => o.subscribers.delete(subscriber),
    addDependency: (node) => o.dependencies.add(node),
    removeDependency: (node) => o.dependencies.delete(node),
    notify: () => {
      for (const subscriber of o.subscribers) {
        updateObserver(subscriber)
      }
    },
    cleanup: () => {
      // Clear dependencies first
      for (const dependency of o.dependencies) {
        dependency.unsubscribe(o as unknown as Observer<unknown>)
      }
      o.dependencies.clear()
      // Clear subscribers
      o.subscribers.clear()
    }
  }

  // Initial computation to get the value
  updateObserver(o)

  return (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Subscribe to this computed value
      o.subscribe(activeObserver as unknown as Observer<unknown>)
      // Use type assertion because ObserverR doesn't have addDependency method
      // but active observer should be Observer<T> implementation
      const fullObserver = activeObserver as Observer<T>
      fullObserver.addDependency(o)
    }
    return o.value!
  }
}
