/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subscribers: new Set(),
    dependencies: new Set(),
    subscribe: (subscriber) => observer.subscribers.add(subscriber),
    unsubscribe: (subscriber) => observer.subscribers.delete(subscriber),
    addDependency: (node) => observer.dependencies.add(node),
    removeDependency: (node) => observer.dependencies.delete(node),
    notify: () => {
      for (const subscriber of observer.subscribers) {
        updateObserver(subscriber)
      }
    },
    cleanup: () => {
      // Clear dependencies first
      for (const dependency of observer.dependencies) {
        dependency.unsubscribe(observer as unknown as Observer<unknown>)
      }
      observer.dependencies.clear()
      // Clear subscribers
      observer.subscribers.clear()
    }
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Cleanup dependencies and remove subscriptions
    observer.cleanup()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
