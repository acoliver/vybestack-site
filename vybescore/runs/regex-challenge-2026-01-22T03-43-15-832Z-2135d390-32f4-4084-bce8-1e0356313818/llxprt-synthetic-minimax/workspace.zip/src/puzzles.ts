/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with prefix
  // Use word boundaries to match complete words
  const prefixPattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  const normalizedExceptions = exceptions.map(ex => ex.toLowerCase());
  
  const result = matches.filter(word => {
    const normalizedWord = word.toLowerCase();
    return !normalizedExceptions.includes(normalizedWord);
  });
  
  // Return unique words
  return [...new Set(result)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that appears after a digit but not at string start
  // Use negative lookbehind to ensure not at start, and positive lookbehind to ensure digit before
  // But we need the full match including the digit, so match digit+token
  const fullMatchPattern = new RegExp(`(?<!^)(\\d${token})`, 'gi');
  const fullMatches = text.match(fullMatchPattern) || [];
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(input: string): boolean {
  // Check minimum length (10 characters)
  if (input.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(input)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(input)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(input)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(input)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^\w\s]/.test(input)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (e.g., abab should fail)
  // This pattern looks for repeated sequences like abab, 1212, etc.
  const seq2 = /([A-Za-z0-9])\1/;
  const seq3 = /([A-Za-z0-9]{2})\1/;
  const seq4 = /([A-Za-z0-9]{3})\1/;
  
  if (seq2.test(input) || seq3.test(input) || seq4.test(input)) {
    return false;
  }
  
  // Additional check: no consecutive repeated characters (like aa, bb, 11, 22)
  if (/(.)\1/.test(input)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(input: string): boolean {
  // IPv6 address patterns to match:
  // 1. Full IPv6: groups of hex digits separated by colons
  // 2. Compressed IPv6: with :: shorthand
  // 3. IPv4-mapped IPv6: IPv6 with embedded IPv4
  
  // First, let's exclude pure IPv4 patterns that shouldn't match
  const pureIpv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (pureIpv4Pattern.test(input)) {
    return false;
  }
  
  // IPv6 patterns:
  // Pattern 1: Full IPv6 (8 groups, 4 hex chars each, separated by colons)
  const fullIpv6Pattern = /^(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}$/;
  
  // Pattern 2: Compressed IPv6 with :: (allows variable group counts)
  const compressedIpv6Pattern = /^(?:[A-Fa-f0-9]{1,4}:){0,7}:(?:[A-Fa-f0-9]{1,4}:){0,7}$/;
  
  // Pattern 3: IPv6 with embedded IPv4 at the end (e.g., 2001:db8::192.168.1.1)
  const mixedIpv6Pattern = /^(?:[A-Fa-f0-9]{1,4}:){0,6}(?:[A-Fa-f0-9]{1,4}:)?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  
  // Pattern 4: Single or double compressed groups
  const doubleCompressedPattern = /^(?:[A-Fa-f0-9]{1,4}:){1,7}(?::[A-Fa-f0-9]{1,4}){1,7}$/;
  
  // Test against all patterns
  if (fullIpv6Pattern.test(input) || 
      compressedIpv6Pattern.test(input) || 
      mixedIpv6Pattern.test(input) ||
      doubleCompressedPattern.test(input)) {
    return true;
  }
  
  // Additional check for IPv6 with embedded patterns
  // Look for patterns that contain colons but not pure IPv4 format
  const hasColonPattern = /.*:.*/;
  const hasHexPattern = /[A-Fa-f0-9]/;
  
  if (hasColonPattern.test(input) && hasHexPattern.test(input)) {
    // Make sure it's not just an IPv4 with colons (which shouldn't happen)
    // Check if the input looks more like IPv6 than IPv4
    const colonCount = (input.match(/:/g) || []).length;
    
    // IPv6 should have more colons than dots typically
    // But this is heuristic - be more specific
    
    // Check for typical IPv6 characteristics:
    // - Multiple colons (at least 2 for IPv6)
    // - Contains hex digits (a-f, A-F)
    // - Not pure dotted decimal like IPv4
    if (colonCount >= 2 && 
        /[A-Fa-f0-9]/.test(input) && 
        !/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(input)) {
      return true;
    }
  }
  
  return false;
}
