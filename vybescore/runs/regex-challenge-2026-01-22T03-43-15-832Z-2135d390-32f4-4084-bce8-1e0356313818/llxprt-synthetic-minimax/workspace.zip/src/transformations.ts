/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // List of common abbreviations that should not trigger sentence capitalization
  const abbreviations = [
    'Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'St.', 'Rd.', 'Ave.', 'Blvd.',
    'U.S.', 'U.K.', 'U.N.', 'N.A.S.A.', 'F.B.I.', 'C.I.A.',
    'Jan.', 'Feb.', 'Mar.', 'Apr.', 'Jun.', 'Jul.', 'Aug.', 'Sep.', 'Oct.', 'Nov.', 'Dec.',
    'etc.', 'e.g.', 'i.e.', 'vs.', 'pp.', 'Fig.', 'Eq.'
  ];
  
  // First, clean up multiple spaces - collapse to single space
  let result = text.replace(/\s{2,}/g, ' ');
  
  // Find sentence endings (., ?, !) followed by space and lowercase letter
  const sentencePattern = /([.!?])(\s*)([a-z])/g;
  
  result = result.replace(sentencePattern, (match, punctuation, spaces, letter) => {
    // Check if this follows an abbreviation
    const beforeMatch = result.substring(0, result.indexOf(match));
    const words = beforeMatch.split(/\s+/);
    const lastWord = words[words.length - 1];
    
    if (abbreviations.includes(lastWord?.trim())) {
      // Don't capitalize after abbreviations
      return punctuation + (spaces || ' ') + letter;
    } else {
      // Capitalize the letter
      return punctuation + (spaces || ' ') + letter.toUpperCase();
    }
  });
  
  // Handle the first sentence if it doesn't follow punctuation
  result = result.replace(/^(\s*)([a-z])/gm, (match, spaces, letter) => {
    return (spaces || '') + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(input: string): string[] {
  // Pattern to match URLs with common protocols
  const urlPattern = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
  
  const urls = input.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  return urls.map(url => {
    // Remove trailing punctuation but keep internal dots and slashes
    return url.replace(/[.,!?;:]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(input: string): string {
  // Replace http:// with https://
  const httpsPattern = /http:\/\/([^\s<>"']+)/gi;
  
  return input.replace(httpsPattern, (match, rest) => {
    return 'https://' + rest;
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(input: string): string {
  // Pattern to match URLs with http scheme
  const httpUrlPattern = /http:\/\/([^\s<>"']+)/gi;
  
  return input.replace(httpUrlPattern, (match, rest) => {
    const fullUrl = rest.startsWith('http://') ? rest : 'http://' + rest;
    
    // Try to parse the URL to get scheme, host, and path
    try {
      const urlObj = new URL(fullUrl);
      
      // Check if path begins with /docs/
      const path = urlObj.pathname;
      const host = urlObj.hostname;
      
      // Check for dynamic hints or legacy extensions that should skip host rewrite
      const dynamicHints = /(cgi-bin|\?|&|=|(\.(jsp|php|asp|aspx|do|cgi|pl|py)$))/i;
      
      if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
        // Rewrite host to docs.example.com and upgrade scheme
        const docsHost = host.replace(/^/, 'docs.');
        return `https://${docsHost}${path}`;
      } else {
        // Just upgrade scheme to https
        return `https://${host}${path}${urlObj.search}`;
      }
    } catch {
      // If URL parsing fails, just upgrade scheme
      return 'https://' + rest;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(input: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = input.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // February has 29 (simplified)
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Validate year is reasonable (1000-9999)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return year.toString();
}
