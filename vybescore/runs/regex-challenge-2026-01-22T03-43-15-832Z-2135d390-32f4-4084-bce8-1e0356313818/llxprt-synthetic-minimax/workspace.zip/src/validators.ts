export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Pattern: local@domain.tld
  // Local part can contain letters, numbers, dots, underscores, hyphens, plus signs
  // Domain part: letters, numbers, dots, hyphens
  // TLD: at least 2 letters
  
  const emailRegex = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation for invalid patterns
  
  // Check for double dots in local part
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for underscore in domain (invalid TLD structure)
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Check for domain starting or ending with dot
  const domainParts = domain.split('.');
  if (domainParts.some(part => part === '')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(_value: string): boolean {
  // Remove all non-digit characters for analysis
  const digitsOnly = _value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Allow optional +1 prefix
  let cleanNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    cleanNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length > 11) {
    // Too many digits
    return false;
  }
  
  // Extract area code (first 3 digits)
  if (cleanNumber.length !== 10) {
    return false;
  }
  
  const areaCode = cleanNumber.substring(0, 3);
  
  // US area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check format variations
  const formats = [
    // (212) 555-7890
    /^\(\d{3}\)\s?\d{3}-\d{4}$/,
    // 212-555-7890  
    /^\d{3}-\d{3}-\d{4}$/,
    // 212.555.7890
    /^\d{3}\.\d{3}\.\d{4}$/,
    // 212 555 7890
    /^\d{3}\s\d{3}\s\d{4}$/,
    // 2125557890
    /^\d{10}$/,
    // +1 212-555-7890
    /^\+1\s?\d{3}-\d{3}-\d{4}$/,
    // +1(212) 555-7890
    /^\+1\(\d{3}\)\s?\d{3}-\d{4}$/,
    // +12125557890
    /^\+1\d{10}$/
  ];
  
  // Check against all formats
  return formats.some(format => format.test(_value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(input: string): boolean {
  // Validate against common formats - use patterns directly
  const formats = [
    // +54 9 11 1234 5678 (mobile)
    /^\+54\s?9\s?\d{2}\s?\d{4}\s?\d{4}$/,
    // +54 341 123 4567 (landline)
    /^\+54\s?\d{3}\s?\d{3}\s?\d{4}$/,
    // 011 1234 5678 (local landline)
    /^\d{3}\s?\d{4}\s?\d{4}$/,
    // 0341 4234567 (local landline)
    /^\d{4}\s?\d{7}$/,
    // +549 11 1234 5678 (mobile with country code)
    /^\+54\s?9\s?\d{2}\s?\d{4}\s?\d{4}$/
  ];
  
  return formats.some(format => format.test(input));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if name is empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[a-zA-ZÀ-ÿƒŒœŠšŽžÇç]/.test(value)) {
    return false;
  }
  
  // Cannot contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Cannot contain symbols except apostrophes, hyphens, and spaces
  if (/[^\w\s\-'À-ÿƒŒœŠšŽžÇç]/.test(value)) {
    return false;
  }
  
  // Check for the pattern X Æ A-12 style names (should fail)
  if (/[^\w\s\-'À-ÿƒŒœŠšŽžÇç]/.test(value)) {
    return false;
  }
  
  // Must start and end with letters or allowed characters
  if (!/^[a-zA-ZÀ-ÿƒŒœŠšŽžÇç\s\-']+/.test(value)) {
    return false;
  }
  
  if (!/[a-zA-ZÀ-ÿƒŒœŠšŽžÇç\s\-']+$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have enough digits (13-19 for most cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid card number patterns
  const cardPatterns = [
    // Visa: starts with 4, 13 or 16 digits total
    /^4\d{12}(\d{3})?$/,
    // Mastercard: starts with 51-55 or 2221-2720, 16 digits total
    /^(5[1-5]\d{14}|2(2[7-9]\d{13}|3\d{14}))$/,
    // American Express: starts with 34 or 37, 15 digits total
    /^3[47]\d{13}$/,
    // Discover: starts with 6011 or 65, 16 digits total
    /^(6011\d{12}|65\d{14})$/
  ];
  
  // Check against card patterns
  if (!cardPatterns.some(pattern => pattern.test(digitsOnly))) {
    return false;
  }
  
  // Run Luhn algorithm for checksum validation
  return runLuhnCheck(digitsOnly);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
