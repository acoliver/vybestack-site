/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Observer represents a computed value or callback
export type ObserverR = {
  name?: string
  dirty?: boolean
  subjects: Set<Subject<unknown> | ObserverR>  // What this observer reads from
  dependents: Set<ObserverR>  // Who reads from this observer
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

// Subject represents an input value
export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): ObserverR | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = setActiveObserver(observer)
  // Clear dependencies before running updateFn to rebuild the dependency graph
  observer.subjects.clear()
  observer.dependents.clear()
  try {
    observer.value = observer.updateFn(observer.value)
    observer.dirty = false
  } finally {
    activeObserver = previous
  }
}

export function linkObserverToSubject<T>(observer: ObserverR, subject: Subject<T>): void {
  if ('observers' in subject) {
    subject.observers.add(observer)
  }
  observer.subjects.add(subject as Subject<unknown>)
}

export function linkObserverToObserver(observer: ObserverR, dependency: ObserverR): void {
  dependency.dependents.add(observer)
  observer.subjects.add(dependency)
}

export function unlinkObserverFromSubject<T>(observer: ObserverR, subject: Subject<T>): void {
  if ('observers' in subject) {
    subject.observers.delete(observer)
  }
  observer.subjects.delete(subject as Subject<unknown>)
}

export function notifyObserver(observer: ObserverR): void {
  if (!observer.dirty) {
    observer.dirty = true
    // Recursively update the observer
    updateObserver(observer as Observer<unknown>)
  }
}

export function collectDirtyObservers(rootObservers: Set<ObserverR>): Set<ObserverR> {
  const dirty = new Set<ObserverR>()
  
  function collect(observer: ObserverR): void {
    if (dirty.has(observer)) return
    dirty.add(observer)
    
    // Recursively collect all dependents
    for (const dependent of observer.dependents) {
      collect(dependent)
    }
  }
  
  for (const observer of rootObservers) {
    collect(observer)
  }
  
  return dirty
}

// Global registry of all observers for proper update ordering
const allObservers: ObserverR[] = []

export function registerObserver(observer: ObserverR): void {
  allObservers.push(observer)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Collect all observers that need to be updated (transitively)
  const dirty = collectDirtyObservers(subject.observers)
  
  // Update in registration order (which is creation order)
  for (const observer of allObservers) {
    if (dirty.has(observer)) {
      if (!observer.dirty) {
        observer.dirty = true
      }
    }
  }
  
  // Then execute updates in order
  for (const observer of allObservers) {
    if (dirty.has(observer)) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
