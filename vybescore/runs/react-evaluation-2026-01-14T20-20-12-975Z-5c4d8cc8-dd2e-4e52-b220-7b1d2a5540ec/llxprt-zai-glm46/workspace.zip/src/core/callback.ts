/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, unlinkObserverFromSubject, registerObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dirty: true,
    subjects: new Set(),
    dependents: new Set(),
  }
  
  // Register observer globally for proper update ordering
  registerObserver(observer)
  
  // Initial execution
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unlink from all subjects to stop receiving updates
    for (const item of observer.subjects) {
      if ('observers' in item) {
        unlinkObserverFromSubject(observer, item)
      }
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
