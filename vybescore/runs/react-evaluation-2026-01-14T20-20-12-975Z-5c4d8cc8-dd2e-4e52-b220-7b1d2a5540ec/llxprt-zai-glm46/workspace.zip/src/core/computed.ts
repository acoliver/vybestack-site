/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  linkObserverToObserver,
  registerObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dirty: true,
    subjects: new Set(),
    dependents: new Set(),
  }
  
  // Register observer globally for proper update ordering
  registerObserver(o)
  
  // Initial computation
  updateObserver(o)
  
  return (): T => {
    // Link active observer to this computed (as a dependency)
    const active = getActiveObserver()
    if (active && active !== o) {
      linkObserverToObserver(active, o)
    }
    
    // Lazy update if dirty
    if (o.dirty) {
      updateObserver(o)
    }
    
    return o.value!
  }
}
