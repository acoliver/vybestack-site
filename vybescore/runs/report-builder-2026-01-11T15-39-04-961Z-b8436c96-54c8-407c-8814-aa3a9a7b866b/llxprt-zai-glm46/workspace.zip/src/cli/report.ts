#!/usr/bin/env node
/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats
 */

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { validateReportData } from '../utils.js';
import { getFormatter } from '../formatters.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments using Node's standard library
 */
function parseArgs(args: string[]): CliArgs {
  const dataFile = args[0];

  if (!dataFile) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const options = {
    format: '',
    outputPath: undefined as string | undefined,
    includeTotals: false,
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        options.format = args[i];
        break;

      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        options.outputPath = args[i];
        break;

      case '--includeTotals':
        options.includeTotals = true;
        break;

      default:
        console.error(`Error: Unknown argument: ${arg}`);
        process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataFile,
    format: options.format,
    outputPath: options.outputPath,
    includeTotals: options.includeTotals,
  };
}

/**
 * Reads and parses JSON from a file
 */
function readJsonFile(path: string): unknown {
  try {
    const content = readFileSync(path, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${path}`);
    }
    if ((error as SyntaxError).name === 'SyntaxError') {
      throw new Error(`Invalid JSON in file: ${path}`);
    }
    throw error;
  }
}

/**
 * Writes content to a file or stdout
 */
async function writeOutput(content: string, outputPath?: string): Promise<void> {
  if (outputPath) {
    await writeFile(resolve(outputPath), content, 'utf-8');
    console.error(`Report written to: ${outputPath}`);
  } else {
    console.log(content);
  }
}

/**
 * Main entry point
 */
async function main(): Promise<void> {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and validate input data
    const rawData = readJsonFile(args.dataFile);
    const data = validateReportData(rawData);

    // Get formatter and render
    const formatter = getFormatter(args.format);
    const output = formatter(data, { includeTotals: args.includeTotals });

    // Write output
    await writeOutput(output, args.outputPath);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
