import type { Formatter } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

/**
 * Map of supported format names to their formatter implementations
 */
export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Returns a list of supported format names
 */
export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}

/**
 * Checks if a format is supported
 */
export function isFormatSupported(format: string): boolean {
  return format in formatters;
}

/**
 * Gets a formatter by name, throwing an error if not supported
 */
export function getFormatter(format: string): Formatter {
  if (!isFormatSupported(format)) {
    const supported = getSupportedFormats().join(', ');
    throw new Error(`Unsupported format: ${format}. Supported formats: ${supported}`);
  }
  return formatters[format];
}
