/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
  observer?: ObserverR | undefined // For backward compatibility
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // For callback observers, always pass undefined to trigger fresh execution
    if (isCallbackObserver(observer)) {
      observer.value = observer.updateFn(undefined)
    } else if (observerRecomputation || observer.value !== undefined) {
      // Normal recomputation with current value
      observer.value = observer.updateFn(observer.value)
    } else {
      // Initial computation or standalone computed - use undefined to trigger default params
      observer.value = observer.updateFn(undefined)
    }
  } finally {
    activeObserver = previous
  }
}

let observerRecomputation: boolean = false

export function setObserverRecomputation(value: boolean): void {
  observerRecomputation = value
}

export function isObserverRecomputation(): boolean {
  return observerRecomputation
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Update all registered observers
  subject.observers.forEach(observer => {
    updateObserver(observer as Observer<T>)
  })
  // Also notify the legacy single observer for backward compatibility
  if (subject.observer) {
    updateObserver(subject.observer as Observer<T>)
  }
}

// Global observer registry for callbacks
const callbackRegistry = new WeakMap<Observer<any>, true>()

export function registerCallbackObserver<T>(observer: Observer<T>): void {
  callbackRegistry.set(observer, true)
}

export function isCallbackObserver<T>(observer: Observer<T>): boolean {
  return callbackRegistry.has(observer)
}

export function unregisterCallbackObserver<T>(observer: Observer<T>): void {
  callbackRegistry.delete(observer)
}
