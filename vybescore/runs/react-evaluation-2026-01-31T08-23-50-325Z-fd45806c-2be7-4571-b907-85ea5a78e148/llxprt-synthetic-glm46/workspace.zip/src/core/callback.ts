/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerCallbackObserver, unregisterCallbackObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register this as a callback observer so it gets proper notification behavior
  registerCallbackObserver(observer)
  
  // Register observer to track dependencies
  // This will cause the callback to execute and immediately track any inputs it reads
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unregister from callback registry
    unregisterCallbackObserver(observer)
    
    // Clear observer to prevent memory leaks
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
