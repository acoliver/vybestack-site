/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setObserverRecomputation,
  isObserverRecomputation
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value: undefined, // Always start with undefined to force computation
    updateFn,
  }
  
  const computed: GetterFn<T> = () => {
    // Check if we have a cached value and we're not in an observer context
    const observer = getActiveObserver()
    if (observer && o !== observer) {
      // Being accessed by another observer, register this computed as a dependency
      o.value = undefined // Clear cache to force recompute
      setObserverRecomputation(true)
      try {
        updateObserver(o)
      } finally {
        setObserverRecomputation(false)
      }
      return o.value!
    }
    
    // Standalone access - recompute every time for consistency
    if (!isObserverRecomputation()) {
      o.value = undefined // Clear cache to ensure fresh computation
      setObserverRecomputation(true)
      try {
        updateObserver(o)
        return o.value!
      } finally {
        setObserverRecomputation(false)
      }
    }
    
    // We're in a recomputation cycle, use cached value if available
    return o.value!
  }
  
  // Don't compute during creation - let the first access handle it
  // This ensures proper default parameter handling
  
  return computed
}
