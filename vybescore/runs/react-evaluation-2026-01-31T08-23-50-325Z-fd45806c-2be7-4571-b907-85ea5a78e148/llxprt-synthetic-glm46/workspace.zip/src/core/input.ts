/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    observer: undefined, // For backward compatibility
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      s.observers.add(observer)
      // When a computed value reads this input, we need to track the relationship
      // so that when this input changes, the computed will be notified
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = typeof _equal === 'function' ? _equal : undefined
    const hasChanged = !equalFn ? true : !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
