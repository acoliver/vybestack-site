import { useState, ReactElement } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): ReactElement {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  total, 
  limit, 
  hasNext, 
  onPageChange 
}: { 
  page: number;
  total: number;
  limit: number;
  hasNext: boolean;
  onPageChange: (newPage: number) => void;
}): ReactElement {
  const totalPages = Math.ceil(total / limit);
  const isFirstPage = page === 1;

  return (
    <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', marginTop: '1rem' }}>
      <button 
        onClick={() => onPageChange(page - 1)}
        disabled={isFirstPage}
        aria-label="Previous page"
      >
        Previous
      </button>
      
      <span>
        Page {page} of {totalPages === 0 ? 1 : totalPages}
      </span>
      
      <button 
        onClick={() => onPageChange(page + 1)}
        disabled={!hasNext}
        aria-label="Next page"
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): ReactElement {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePageChange = (newPage: number): void => {
    if (newPage >= 1) {
      setCurrentPage(newPage);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        page={data.page}
        total={data.total}
        limit={data.limit}
        hasNext={data.hasNext}
        onPageChange={handlePageChange}
      />
    </section>
  );
}
