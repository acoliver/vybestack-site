/**
 * Encode plain text to Base64 using standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64 decoding.
 * Validates input to ensure it contains only valid Base64 characters.
 */
export function decode(input: string): string {
  // Validate that input contains only valid Base64 characters
  // Allow letters, numbers, +, /, = (padding), and whitespace for flexibility
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains disallowed characters');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
