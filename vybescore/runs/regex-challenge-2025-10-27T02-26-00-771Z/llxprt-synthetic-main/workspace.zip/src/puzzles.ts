/**
 * Finds words starting with the specified prefix but excluding the listed exceptions.
 * @param text - The input text to search
 * @param prefix - The prefix to match words against
 * @param exceptions - Array of words to exclude from results
 * @returns Array of words that start with the prefix but aren't in exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to match words starting with the prefix
  // \b ensures we're matching whole words
  // [a-zA-Z]+ matches the rest of the word characters
  const pattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => exception.toLowerCase() === lowerMatch);
  });
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * @param text - The input text to search
 * @param token - The token to find
 * @returns Array of matched token occurrences with their preceding digit
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern that matches digit followed by the token
  const pattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out any matches that are at the start of the string
  return matches.filter(match => {
    const matchPos = text.indexOf(match);
    return matchPos > 0;
  });
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 * @param value - The password to validate
 * @returns True if the password meets all requirements
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (pattern where the first half repeats)
  // Examples like abab, 123123, hellohello should fail
  const length = value.length;
  
  // Check for patterns where the first half repeats
  for (let i = 4; i <= length / 2; i++) { // Start with patterns of length 4 or more
    const firstHalf = value.substring(0, i);
    const secondHalf = value.substring(i, i * 2);
    
    if (secondHalf.length === i && firstHalf === secondHalf) {
      return false;
    }
  }
  
  // More general check for repeated sequences anywhere in the password
  // Look for patterns like abab where a and b are equal length
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 * @param value - The input string to check
 * @returns True if an IPv6 address is found
 */
export function containsIPv6(value: string): boolean {
  // First, define a pattern for IPv4 addresses (to ensure we don't match them)
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Check if the value is an IPv4 address
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address patterns
  // Regular IPv6: 8 groups of 4 hex digits separated by colons
  // Shortened with :: for zero groups
  // Embedded IPv4: ::ffff:192.168.0.1
    
  // Pattern for full IPv6
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Pattern for IPv6 with :: shorthand
  const ipv6CompressedPattern = /(?:[0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}/;
  
  // Pattern for IPv6 with leading ::
  const ipv6LeadingCompressedPattern = /^::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // Pattern for IPv6 with trailing ::
  const ipv6TrailingCompressedPattern = /(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}:$/;
  
  // Pattern for IPv6 with :: in the middle
  const ipv6MiddleCompressedPattern = /(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{1,4}){1,7}/;
  
  // Pattern for IPv6 with embedded IPv4
  const ipv6EmbeddedIPv4Pattern = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Pattern for IPv6 with :: before embedded IPv4
  const ipv6CompressedWithIPv4Pattern = /::(?:ffff:)?(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check for any valid IPv6 pattern
  return (
    ipv6FullPattern.test(value) ||
    ipv6CompressedPattern.test(value) ||
    ipv6LeadingCompressedPattern.test(value) ||
    ipv6TrailingCompressedPattern.test(value) ||
    ipv6MiddleCompressedPattern.test(value) ||
    ipv6EmbeddedIPv4Pattern.test(value) ||
    ipv6CompressedWithIPv4Pattern.test(value)
  );
}