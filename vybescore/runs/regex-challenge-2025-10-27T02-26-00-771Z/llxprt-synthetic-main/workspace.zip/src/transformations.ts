/**
 * Capitalizes the first character of each sentence.
 * Handles proper spacing after punctuation (.?!), inserts exactly one space between sentences,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split the text into sentences using punctuation as delimiters
  const sentences = [];
  let currentSentence = '';
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    
    if (char === '.' || char === '?' || char === '!') {
      currentSentence += char;
      sentences.push(currentSentence);
      currentSentence = '';
    } else {
      currentSentence += char;
    }
  }
  
  // Add any remaining text as the last sentence
  if (currentSentence.trim()) {
    sentences.push(currentSentence);
  }
  
  // Process each sentence
  const processedSentences = [];
  
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i];
    
    // Trim leading spaces from all but the first sentence
    if (i > 0) {
      sentence = sentence.trimLeft();
    }
    
    // Capitalize the first character if it's a lowercase letter
    if (sentence.length > 0 && sentence[0] >= 'a' && sentence[0] <= 'z') {
      sentence = sentence[0].toUpperCase() + sentence.slice(1);
    }
    
    // Add a space before this sentence unless it's the first one
    if (i > 0 && !sentence.startsWith(' ')) {
      // Check if the previous sentence ends with punctuation
      const prevSentenceEnd = processedSentences.length > 0 ? processedSentences[processedSentences.length - 1] : '';
      if (prevSentenceEnd && (prevSentenceEnd.endsWith('.') || prevSentenceEnd.endsWith('?') || prevSentenceEnd.endsWith('!'))) {
        sentence = ' ' + sentence;
      }
    }
    
    processedSentences.push(sentence);
  }
  
  // Join all sentences back together
  return processedSentences.join('');
}

/**
 * Extracts URLs from the given text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http, https, ftp protocols and www
  // Excludes trailing punctuation like commas, periods, etc.
  const urlRegex = /((https?:\/\/|ftp:\/\/|www\.)[^\s<>"]+)(?<![.,;:!?)}\]])/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation that might have been captured
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,;:!?)}\]]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Forces all http URLs to use https while leaving already secure URLs untouched.
 * @param text - The input string containing URLs
 * @returns The text with all http URLs converted to https
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't double-up https
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs for http://example.com/...
 * - Always upgrades the scheme to https://
 * - When the path begins with /docs/, rewrites the host to docs.example.com
 * - Skips the host rewrite when the path contains dynamic hints (cgi-bin, query strings, or legacy extensions)
 * @param text - The input string containing URLs
 * @returns The text with URLs rewritten according to the rules
 */
export function rewriteDocsUrls(text: string): string {
  // This pattern captures the full URL and its components
  const urlRegex = /\b(https?):\/\/(example\.com)(\/[^\s<>"]*)/gi;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Default domain remains unchanged
    let newDomain = domain;
    
    // Check if we need to rewrite the domain for docs paths
    // Only rewrite if:
    // 1. The path starts with /docs/
    // 2. The path doesn't contain dynamic hints or legacy extensions
    
    // Pattern for dynamic hints and legacy extensions
    const hasDynamicHints = /(?:cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    
    // Check if path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints.test(path)) {
      newDomain = 'docs.example.com';
    }
    
    // Reassemble the URL
    return `${newProtocol}://${newDomain}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted dates.
 * Returns 'N/A' when the format is invalid or the month/day are invalid.
 * @param value - The input string potentially containing a date
 * @returns The four-digit year or 'N/A' if invalid
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combinations
  // Days in each month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Index 0 unused
  
  // Check for leap year for February
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && (parseInt(year, 10) % 100 !== 0 || parseInt(year, 10) % 400 === 0));
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month]) {
    // Check if day exceeds the number of days in the month
    return 'N/A';
  }
  
  return year;
}