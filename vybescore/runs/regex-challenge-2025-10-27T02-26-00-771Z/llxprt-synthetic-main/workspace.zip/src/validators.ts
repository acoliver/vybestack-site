export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common standards.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: alphanumeric characters plus special chars like +, -, _, .
  // Domain part: alphanumeric with hyphens, dots, and must end with valid TLD
  // Disallows: double dots, dots at start/end, underscores in domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Check for basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  // Disallow consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domain] = value.split('@');
  
  // Local part can't start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain part can't contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain part can't start or end with hyphen or dot
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Clean the input: remove all non-digit characters except +
  const cleanedValue = value.replace(/[^\d+]/g, '');
  
  // Check if it has +1 country code
  let digits = cleanedValue;
  
  if (digits.startsWith('+1')) {
    digits = digits.substring(2); // Remove +1
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1); // Remove leading 1
  }
  
  // US phone number should have exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code and exchange
  const areaCode = digits.substring(0, 3);
  const exchange = digits.substring(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Exchange cannot start with 0 or 1
  if (exchange.charAt(0) === '0' || exchange.charAt(0) === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54.
 * Optional trunk prefix 0 immediately before the area code.
 * Optional mobile indicator 9 between country/trunk and the area code.
 * Area code must be 2-4 digits (leading digit 1-9).
 * Subscriber number must contain 6-8 digits.
 * Allow single spaces or hyphens as separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input: remove all spaces, hyphens, and other separators, but keep +
  let cleanedValue = value.replace(/[\s-]/g, '');
  
  // Check if it has country code +54
  let hasCountryCode = false;
  if (cleanedValue.startsWith('+54')) {
    cleanedValue = cleanedValue.substring(3); // Remove +54
    hasCountryCode = true;
  }
  
  // Check for trunk prefix 0
  let hasTrunkPrefix = false;
  if (cleanedValue.startsWith('0')) {
    cleanedValue = cleanedValue.substring(1); // Remove 0
    hasTrunkPrefix = true;
  }
  
  // If country code is omitted, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator 9 (only if trunk prefix was present or country code was provided)
  if (cleanedValue.startsWith('9')) {
    cleanedValue = cleanedValue.substring(1); // Remove 9
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCodeFound = false;
  
  // Try to extract area code of 2-4 digits
  for (let areaCodeLength = 4; areaCodeLength >= 2; areaCodeLength--) {
    if (cleanedValue.length >= areaCodeLength) {
      const potentialAreaCode = cleanedValue.substring(0, areaCodeLength);
      if (potentialAreaCode.match(/^[1-9]\d{1,3}$/)) {
        areaCodeFound = true;
        const subscriberNumber = cleanedValue.substring(areaCodeLength);
        
        // Subscriber number should be 6-8 digits
        if (!subscriberNumber.match(/^\d{6,8}$/)) {
          return false;
        }
        break;
      }
    }
  }
  
  return areaCodeFound;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Empty string is not valid
  if (!value.trim()) {
    return false;
  }
  
  // Name regex:
  // ^ - start of string
  // [ \p{L}\p{M}'-]+ - Unicode letters, marks (accents), apostrophes, hyphens, and spaces
  // $ - end of string
  // We use the u flag to enable Unicode property escapes
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if it contains digits or the special chars that might indicate a problematic name
  // Check specifically for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol-like characters that shouldn't be in a name
  // This is a simple check for common symbols not allowed in names
  if (/[!@#$%^&*()_+=\[\]{}|\\:";'<>?,.\/]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx).
 * Accepts correct prefixes and lengths.
 * Runs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have only digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55, or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9][1-9]|3[0-9][1-9]|4[0-9][1-9]|5[0-9][1-9]|6[0-9][1-9]|7[01][1-9]|720)\d{12}))$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the number matches any card type
  const isValidPrefixAndLength = visaRegex.test(digitsOnly) || 
                                mastercardRegex.test(digitsOnly) || 
                                amexRegex.test(digitsOnly);
  
  if (!isValidPrefixAndLength) {
    return false;
  }
  
  // Luhn algorithm
  return luhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 * @param digitsOnly - The credit card number with only digits
 * @returns True if valid according to Luhn algorithm
 */
function luhnCheck(digitsOnly: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    let digit = parseInt(digitsOnly.substring(i, i + 1), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return (sum % 10) === 0;
}
