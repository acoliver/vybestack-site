import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows with default pagination', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('validates pagination parameters', async () => {
    // Test negative page
    const response1 = await request(app).get('/inventory?page=-1');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toContain('positive integer');

    // Test zero page
    const response2 = await request(app).get('/inventory?page=0');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toContain('positive integer');

    // Test non-numeric page
    const response3 = await request(app).get('/inventory?page=abc');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toContain('positive integer');

    // Test negative limit
    const response4 = await request(app).get('/inventory?limit=-5');
    expect(response4.status).toBe(400);
    expect(response4.body.error).toContain('positive integer');

    // Test excessive limit
    const response5 = await request(app).get('/inventory?limit=101');
    expect(response5.status).toBe(400);
    expect(response5.body.error).toContain('cannot exceed 100');
  });

  it('returns correct pagination results', async () => {
    // First page
    const response1 = await request(app).get('/inventory?page=1&limit=3');
    expect(response1.status).toBe(200);
    expect(response1.body.items.length).toBe(3);
    expect(response1.body.page).toBe(1);
    expect(response1.body.limit).toBe(3);
    expect(response1.body.total).toBe(15);
    expect(response1.body.hasNext).toBe(true);
    expect(response1.body.items[0].id).toBe(1);
    expect(response1.body.items[2].id).toBe(3);

    // Second page
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    expect(response2.status).toBe(200);
    expect(response2.body.items.length).toBe(3);
    expect(response2.body.page).toBe(2);
    expect(response2.body.limit).toBe(3);
    expect(response2.body.total).toBe(15);
    expect(response2.body.hasNext).toBe(true);
    expect(response2.body.items[0].id).toBe(4);
    expect(response2.body.items[2].id).toBe(6);

    // Last page (page 5 with limit 3) - should have items 13, 14, 15
    const response3 = await request(app).get('/inventory?page=5&limit=3');
    expect(response3.status).toBe(200);
    expect(response3.body.items.length).toBe(3);
    expect(response3.body.page).toBe(5);
    expect(response3.body.limit).toBe(3);
    expect(response3.body.total).toBe(15);
    expect(response3.body.hasNext).toBe(false);
    expect(response3.body.items[0].id).toBe(13);
    expect(response3.body.items[2].id).toBe(15);

    // Last page with items (page 4 with limit 4) - should have items 13, 14, 15
    const response4 = await request(app).get('/inventory?page=4&limit=4');
    expect(response4.status).toBe(200);
    expect(response4.body.items.length).toBe(3);
    expect(response4.body.hasNext).toBe(false);
    expect(response4.body.items[0].id).toBe(13);
    expect(response4.body.items[2].id).toBe(15);
  });

  it('handles page beyond data correctly', async () => {
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.page).toBe(100);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });
});
