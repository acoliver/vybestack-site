import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(page: unknown, limit: unknown): { page?: number; limit?: number } {
  const result: { page?: number; limit?: number } = {};
  
  if (page !== undefined) {
    const pageNum = Number(page);
    if (isNaN(pageNum) || !Number.isInteger(pageNum) || pageNum < 1) {
      throw new Error('Page must be a positive integer');
    }
    result.page = pageNum;
  }
  
  if (limit !== undefined) {
    const limitNum = Number(limit);
    if (isNaN(limitNum) || !Number.isInteger(limitNum) || limitNum < 1) {
      throw new Error('Limit must be a positive integer');
    }
    if (limitNum > 100) {
      throw new Error('Limit cannot exceed 100');
    }
    result.limit = limitNum;
  }
  
  return result;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const { page, limit } = validatePaginationParams(pageParam, limitParam);

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid pagination parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
