import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import path from 'node:path';
import fs from 'node:fs';
import { spawn } from 'child_process';

const dbPath = path.resolve('data', 'submissions.sqlite');
let serverProcess: ReturnType<typeof spawn> | null = null;

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server before tests
  serverProcess = spawn('node', ['dist/server.js'], {
    cwd: process.cwd(),
    stdio: 'inherit'
  });
  
  // Wait for server to start
  await new Promise((resolve) => setTimeout(resolve, 2000));
});

afterAll(() => {
  // Stop the server after tests
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
  
  // Database cleanup happens automatically on server shutdown
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // Test that the form page loads successfully
    const response = await fetch('http://localhost:3535/');
    expect(response.status).toBe(200);
    
    const html = await response.text();
    expect(html).toContain('first_name');
    expect(html).toContain('last_name');
    expect(html).toContain('street_address');
    expect(html).toContain('city');
    expect(html).toContain('state_province');
    expect(html).toContain('postal_code');
    expect(html).toContain('country');
    expect(html).toContain('email');
    expect(html).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Test successful form submission
    const formData = new URLSearchParams({
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 (555) 123-4567'
    });

    const response = await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
      redirect: 'manual'
    });

    expect(response.status).toBe(302);
    expect(response.headers.get('location')).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
