export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  errors: ValidationError[];
  isValid: boolean;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/[\d]/g, '').length >= 3; // At least some digits
}

export function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings, including international formats like UK "SW1A 1AA" and Argentine "C1000" or "B1675"
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

export function validateRequired(field: string, value: string): boolean {
  return value.trim().length > 0;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Validate required fields
  const requiredFields: Array<keyof FormData> = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!validateRequired(field, data[field])) {
      errors.push({
        field,
        message: `${field.replace('_', ' ').toUpperCase()} is required`
      });
    }
  });

  // Validate email if present
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Validate phone if present
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Validate postal code if present
  if (data.postal_code && !validatePostalCode(data.postal_code)) {
    errors.push({
      field: 'postal_code',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    errors,
    isValid: errors.length === 0
  };
}