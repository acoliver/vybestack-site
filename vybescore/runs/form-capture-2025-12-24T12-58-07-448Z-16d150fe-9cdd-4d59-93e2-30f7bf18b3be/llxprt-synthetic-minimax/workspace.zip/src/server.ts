import express from 'express';
import path from 'path';
import { initializeDatabase, insertSubmission, saveDatabase, closeDatabase, FormSubmission } from './db.js';
import { validateForm, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Configure Express middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Configure EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Serve static files from public directory
app.use(express.static(path.join(process.cwd(), 'public')));

// GET / - Render the contact form
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', {
    errors: [],
    formData: null
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  // Validate the form data
  const validationResult = validateForm(formData);

  if (!validationResult.isValid) {
    // Re-render form with errors and previous values
    return res.status(400).render('form', {
      errors: validationResult.errors,
      formData
    });
  }

  try {
    // Insert submission into database
    const submission: FormSubmission = {
      first_name: formData.first_name,
      last_name: formData.last_name,
      street_address: formData.street_address,
      city: formData.city,
      state_province: formData.state_province,
      postal_code: formData.postal_code,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    insertSubmission(submission);
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'An error occurred while processing your submission. Please try again.' }],
      formData
    });
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you');
});

// Graceful shutdown handler
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  
  try {
    closeDatabase();
    console.log('Database closed successfully');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  
  try {
    closeDatabase();
    console.log('Database closed successfully');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
