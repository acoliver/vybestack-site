import initSqlJs, { SqlJsStatic, Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

let db: Database | null = null;
let sqlJsStatic: SqlJsStatic | null = null;

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

export interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export async function initializeDatabase(): Promise<void> {
  try {
    if (!sqlJsStatic) {
      // Initialize SQL.js without custom locateFile (it will find the wasm file automatically)
      const SqlJs = await initSqlJs();
      sqlJsStatic = SqlJs;
    }

    if (!sqlJsStatic) {
      throw new Error('Failed to initialize SQL.js');
    }

    let existingDbBuffer: Uint8Array | null = null;
    
    // Load existing database file if it exists
    if (fs.existsSync(DB_FILE_PATH)) {
      const dbBuffer = fs.readFileSync(DB_FILE_PATH);
      existingDbBuffer = new Uint8Array(dbBuffer);
    }

    // Initialize database with existing data or empty
    db = new sqlJsStatic.Database(existingDbBuffer);

    // Read and execute schema
    if (fs.existsSync(SCHEMA_PATH)) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export function insertSubmission(submission: FormSubmission): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  try {
    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
  } finally {
    stmt.free();
  }
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  fs.writeFileSync(DB_FILE_PATH, Buffer.from(data));
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}