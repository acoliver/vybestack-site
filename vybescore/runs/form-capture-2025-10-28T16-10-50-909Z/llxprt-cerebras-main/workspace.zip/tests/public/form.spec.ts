import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let app: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Set env port to avoid conflicts
  process.env.PORT = '0';
  
  // Remove existing db if any
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and set up the express app
  app = (await import('../../dist/server.js')).default;
});

afterAll(() => {
  // No need to close server in tests as it's handled by supertest
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    
    // Parse HTML with cheerio
    const $ = cheerio.load(res.text);
    
    // Check all form fields exist
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Another City',
      stateProvince: 'NY',
      postalCode: '54321',
      country: 'USA',
      email: 'jane.smith@example.com',
      phone: '+1 555 987 6543'
    };

    const res = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(res.header.location).toBe('/thank-you');
    
    // Check thank-you page includes firstName
    const thankYouRes = await request(app).get('/thank-you');
    expect(thankYouRes.status).toBe(200);
    expect(thankYouRes.text).toContain('Jane');
    
    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check entry in database - we're just checking if any rows exist
    const dbBuffer = fs.readFileSync(dbPath);
    expect(dbBuffer.length).toBeGreaterThan(0);
  });
  
  it('handles validation errors correctly', async () => {
    // Submit with missing fields to trigger validation errors
    const res = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      })
      .expect(400);
      
    // Parse HTML with cheerio
    const $ = cheerio.load(res.text);
    
    // Check error messages exist
    expect($('.error').length).toBeGreaterThan(0);
  });
  
  it('accepts international phone numbers and postal codes', async () => {
    // Test with an international phone number and postal code
    const formData = {
      firstName: 'Juan',
      lastName: 'Perez',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'juan.perez@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const res = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(res.header.location).toBe('/thank-you');
  });
});