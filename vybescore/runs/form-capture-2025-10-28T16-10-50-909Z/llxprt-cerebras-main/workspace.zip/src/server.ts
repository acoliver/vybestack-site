import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// SQLite database setup
let db: Database;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
const initializeDB = async () => {
  const SQL = await initSqlJs();
  let dbData: Uint8Array | null = null;
  
  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    dbData = new Uint8Array(fileBuffer);
  }
  
  db = new SQL.Database(dbData);
  
  // Create table if it doesn't exist
  const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
  db.run(schemaSql);
};

// Save database to file
const saveDB = () => {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
};

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric postal codes with spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {},
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  // Debug output for request body
  console.log('Request body:', req.body);
  
  const formData: Submission = {
    first_name: req.body.firstName || '',
    last_name: req.body.lastName || '',
    street_address: req.body.streetAddress || '',
    city: req.body.city || '',
    state_province: req.body.stateProvince || '',
    postal_code: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  // Validation errors
  const errors: Record<string, string> = {};
  
  if (!formData.first_name.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!formData.last_name.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!formData.street_address.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.state_province.trim()) {
    errors.stateProvince = 'State/Province is required';
  }
  
  if (!formData.postal_code.trim()) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(formData.postal_code)) {
    errors.postalCode = 'Invalid postal code format';
  }
  
  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Invalid email format';
  }
  
  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Invalid phone number format';
  }
  
  // Debug logs for validation
  console.log('Form data:', formData);
  console.log('Validation errors:', errors);
  
  // If there are validation errors, re-render the form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }
  
  // Insert data into database
  const insertSql = `
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  
  db.run(insertSql, [
    formData.first_name,
    formData.last_name,
    formData.street_address,
    formData.city,
    formData.state_province,
    formData.postal_code,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  // Save database to file
  saveDB();
  
  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the latest submission's first name for the thank-you message
  const result = db.exec("SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1");
  const firstName = result.length > 0 && result[0].values.length > 0 ? result[0].values[0][0] as string : 'friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown handling
let server: ReturnType<typeof app.listen>;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  saveDB();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  saveDB();
  process.exit(0);
});

// Start server after DB initialization
initializeDB().then(() => {
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

export default app;