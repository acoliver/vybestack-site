/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  let result = text;
  
  // Capitalize first letter if it's lowercase (for beginning of text)
  if (result.length > 0 && /^[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  // Pattern to find sentence endings followed by lowercase letters
  // Replace with punctuation followed by exactly one space and capitalized letter
  const pattern = /([.!?])\s*([a-z])/g;
  
  return result.replace(pattern, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https with optional www)
  // Pattern handles trailing punctuation by using negative lookahead
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"']+[^\s<>"'.,!?]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;:]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs (not https://)
  const httpPattern = /http:\/\/[^\s<>"']+/gi;
  
  return text.replace(httpPattern, (match) => {
    return match.replace(/^http:\/\//, 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpPattern = /http:\/\/([^/\s<>"']+)([^<>"'\s]*)/gi;
  
  return text.replace(httpPattern, (match, host, path) => {
    // Always upgrade scheme to https
    let newUrl = `https://${host}`;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should skip host rewrite
      // Use word boundaries to avoid matching partial words like "do" in "docs"
      const dynamicPattern = /(\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|cgi-bin)/i;
      
      if (!dynamicPattern.test(path)) {
        // Rewrite host to docs.host
        newUrl = `https://docs.${host}${path}`;
      } else {
        // Just upgrade scheme, keep original host
        newUrl += path;
      }
    } else {
      // Not a docs path, just upgrade scheme
      newUrl += path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  if (month === 2) {
    // Check for leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    const maxDay = isLeapYear ? 29 : 28;
    if (day < 1 || day > maxDay) {
      return 'N/A';
    }
  } else if ([4, 6, 9, 11].includes(month)) {
    // Months with 30 days
    if (day < 1 || day > 30) {
      return 'N/A';
    }
  } else {
    // Months with 31 days
    if (day < 1 || day > 31) {
      return 'N/A';
    }
  }
  
  // Return the year as string
  return match[3];
}
