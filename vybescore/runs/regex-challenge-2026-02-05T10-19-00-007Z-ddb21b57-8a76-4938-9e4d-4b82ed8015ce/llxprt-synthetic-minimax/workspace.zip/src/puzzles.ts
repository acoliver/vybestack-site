/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with the prefix
  // Word boundary, prefix, then rest of word characters
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(match => {
    const cleanMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === cleanMatch
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern: any digit followed by the token
  const pattern = new RegExp(`\\d${token}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Return the matches as found
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check character requirements
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9\s]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // Pattern: any 2-character sequence repeated immediately
  const repeatedPattern = /(..)\1/g;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern for IPv4 addresses - to exclude them
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // If it contains IPv4, don't consider it IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Pattern for IPv6 addresses including shorthand
  // IPv6 uses 8 groups of 4 hexadecimal digits separated by colons
  // Shorthand: groups of zeros can be represented by :: (at most once)
  const ipv6Pattern = /(?<![A-Fa-f0-9:])[A-Fa-f0-9]{1,4}(:[A-Fa-f0-9]{1,4}){1,7}(?!::)(?![A-Fa-f0-9:])/;
  
  // Check if pattern finds any IPv6 address
  if (ipv6Pattern.test(value)) {
    return true;
  }
  
  // Alternative pattern for shorthand IPv6 (with ::)
  // This handles compressed notation like 2001:db8::1
  const shorthandPattern = /(?<![A-Fa-f0-9:])[A-Fa-f0-9]{0,4}(?::[A-Fa-f0-9]{0,4}){2,7}(?!::)(?![A-Fa-f0-9:])/;
  
  // Check for shorthand pattern as well
  if (shorthandPattern.test(value)) {
    return true;
  }
  
  // More comprehensive IPv6 pattern including :: shorthand
  // This pattern specifically looks for :: which indicates IPv6 shorthand
  const anyShorthandPattern = /::/;
  if (anyShorthandPattern.test(value)) {
    // Check that it's not just having two colons (might be time notation)
    // IPv6 should have hex digits around the ::
    const hexAroundColon = /[A-Fa-f0-9]:|:[A-Fa-f0-9]/;
    if (hexAroundColon.test(value)) {
      return true;
    }
  }
  
  return false;
}
