export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects double dots, trailing dots, domains with underscores
  // Pattern: local@domain.tld where domain can have multiple parts separated by dots
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.([a-zA-Z]{2,})$/;
  
  // Additional checks to reject invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for leading + with optional country code
  if (cleaned.startsWith('+1')) {
    const number = cleaned.substring(3); // Remove +1
    return isValidUSPhone(number, options);
  }
  
  // Must be 10 digits for valid US number
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = parseInt(cleaned.substring(0, 1), 10);
  
  // Area code cannot start with 0 or 1
  if (cleaned.length === 10 && (cleaned[0] === '0' || cleaned[0] === '1')) {
    return false;
  }
  
  // Area code validation (first digit 2-9)
  if (areaCode < 2 || areaCode > 9) {
    return false;
  }
  
  // Check for invalid patterns like all same digits
  if (/^(\d)\1{9}$/.test(cleaned)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be at least 10 digits (without country code)
  if (digits.length < 10) {
    return false;
  }
  
  // Check for international format with country code (+54)
  if (digits.startsWith('54')) {
    // Remove country code and check remaining number
    const numberWithoutCode = digits.substring(2);
    
    // Check if it starts with mobile indicator 9
    if (numberWithoutCode.startsWith('9')) {
      // International mobile: 54 + 9 + area + subscriber
      const numberAfterMobile = numberWithoutCode.substring(1);
      if (numberAfterMobile.length >= 8 && numberAfterMobile.length <= 10) {
        const areaCode = parseInt(numberAfterMobile.substring(0, 3), 10);
        if (areaCode >= 11 && areaCode <= 8999) {
          return true;
        }
      }
    } else {
      // International landline: 54 + area + subscriber  
      const areaCode = parseInt(numberWithoutCode.substring(0, 3), 10);
      if (numberWithoutCode.length >= 8 && numberWithoutCode.length <= 10 && 
          areaCode >= 11 && areaCode <= 8999) {
        return true;
      }
    }
  }
  
  // Check for domestic format (without country code)
  if (digits.length >= 10 && digits.length <= 11) {
    const areaCode = parseInt(digits.substring(0, 3), 10);
    if (areaCode >= 11 && areaCode <= 8999) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for obvious non-name patterns first
  if (/\d/.test(value)) {
    return false; // Reject names with digits
  }
  
  if (/[^\p{L}\p{M}\p{Nd}\s'-]/u.test(value)) {
    return false; // Reject names with symbols that aren't letters, digits, spaces, apostrophes, or hyphens
  }
  
  // Pattern allowing unicode letters, accents (marks), digits, spaces, apostrophes, hyphens
  // Must have at least 2 parts when split by spaces (first and last name)
  const nameParts = value.trim().split(/\s+/);
  if (nameParts.length < 2) {
    return false;
  }
  
  // Check each part follows name patterns
  for (const part of nameParts) {
    // Each part should start with a letter (unicode aware)
    if (!/^\p{L}/u.test(part)) {
      return false;
    }
    
    // Reject parts that are obviously fake names like "XÆA-12"
    if (/^[XÆA][ÆA-]*\d*$/.test(part)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/[^\d]/g, '');
  
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Card type validation patterns
  // Visa: 4 followed by 12-18 more digits (total 13-19)
  const visaPattern = /^4\d{12,18}$/;
  // Mastercard: 51-55 or 2221-2720 followed by 11-15 more digits (total 16)
  const mastercardPattern = /^(5[1-5]\d{14}|2(2[2-9]\d{2}|3[0-8]\d|4[0-8]\d|5[0-8]\d|6[0-9]\d|7[0-8]\d|8[0-9]\d|9[0-8]\d)\d{12})$/;
  // AmEx: 34 or 37 followed by 13-14 more digits (total 15)
  const amexPattern = /^3[47]\d{13,14}$/;
  
  // Check if card matches any of the supported patterns
  if (!visaPattern.test(cardNumber) && 
      !mastercardPattern.test(cardNumber) && 
      !amexPattern.test(cardNumber)) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return isValidLuhnChecksum(cardNumber);
}

// Helper function for Luhn checksum
function isValidLuhnChecksum(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}
