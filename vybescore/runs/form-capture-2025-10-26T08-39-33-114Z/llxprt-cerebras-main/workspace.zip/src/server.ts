import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
let db: Database;

// Initialize database
async function initDB() {
  const SQL = await initSqlJs({ locateFile: (filename) => `node_modules/sql.js/dist/${filename}` });
  
  // Read existing database or create a new one
  let dbData: Uint8Array | null = null;
  try {
    dbData = fs.readFileSync(DB_PATH);
  } catch (err) {
    // File doesn't exist, we'll create a new database
  }
  
  if (dbData) {
    db = new SQL.Database(dbData);
  } else {
    db = new SQL.Database();
    // Create the submissions table if the database is new
    db.run(fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8'));
    // Save the initial database structure
    saveDB();
  }
}

// Save database to file
function saveDB() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes with spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateRequiredFields(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field} is required` });
    }
  });
  
  return errors;
}

// Apply all validations
function validateForm(data: FormData): ValidationError[] {
  const errors = validateRequiredFields(data);
  
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }
  
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone format' });
  }
  
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Invalid postal code format' });
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    // Re-render form with errors and previously entered values
    res.status(400).render('form', { 
      errors: errors.map(e => e.message), 
      values: formData 
    });
    return;
  }
  
  // Insert data into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
  saveDB();
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Check if we have recent submissions to get firstName for the thank-you page
  const result = db.exec("SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1");
  const firstName = result.length > 0 && result[0].values.length > 0 ? result[0].values[0][0] as string : 'Friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown handling
let server: ReturnType<typeof app.listen>;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  server.close(() => {
    console.log('Server closed.');
    db.close();
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, closing server...');
  server.close(() => {
    console.log('Server closed.');
    db.close();
    process.exit(0);
  });
});

// Initialize database and start server
initDB().then(() => {
  server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

export { app, server };