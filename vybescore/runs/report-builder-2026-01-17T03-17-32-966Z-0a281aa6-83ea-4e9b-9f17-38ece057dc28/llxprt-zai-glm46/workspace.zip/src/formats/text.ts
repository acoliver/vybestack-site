import type { ReportRenderer } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export const renderText: ReportRenderer = (data, options) => {
  const lines: string[] = [];

  lines.push(data.title);
  lines.push(data.summary);
  lines.push('Entries:');

  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
