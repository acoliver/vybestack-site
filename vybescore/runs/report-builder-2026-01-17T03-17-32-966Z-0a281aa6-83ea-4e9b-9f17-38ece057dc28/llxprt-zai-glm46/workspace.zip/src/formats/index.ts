import type { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText
};

export function getFormatter(format: string): ReportRenderer {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
