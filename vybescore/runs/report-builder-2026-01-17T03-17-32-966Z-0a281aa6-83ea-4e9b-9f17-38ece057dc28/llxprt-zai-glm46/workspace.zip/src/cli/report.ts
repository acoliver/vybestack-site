#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { validateReportData } from '../utils.js';
import { getFormatter } from '../formats/index.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const formatFlagIndex = args.indexOf('--format');
  if (formatFlagIndex === -1 || formatFlagIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  const format = args[formatFlagIndex + 1];

  const outputFlagIndex = args.indexOf('--output');
  const outputPath = outputFlagIndex !== -1 && outputFlagIndex + 1 < args.length ? args[outputFlagIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const inputPath = path.resolve(args.dataFile);
    let fileContent: string;
    try {
      fileContent = fs.readFileSync(inputPath, 'utf-8');
    } catch (error) {
      const err = error as NodeJS.ErrnoException;
      if (err.code === 'ENOENT') {
        console.error(`Error: file not found: ${inputPath}`);
      } else {
        console.error(`Error: unable to read file: ${err.message}`);
      }
      process.exit(1);
      return;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: invalid JSON in file ${args.dataFile}`);
      process.exit(1);
      return;
    }

    const data = validateReportData(jsonData);
    const formatter = getFormatter(args.format);
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter(data, options);

    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        const err = error as NodeJS.ErrnoException;
        console.error(`Error: unable to write output file: ${err.message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
