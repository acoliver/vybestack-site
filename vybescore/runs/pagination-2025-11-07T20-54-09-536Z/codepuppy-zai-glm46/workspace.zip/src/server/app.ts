import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Validate and parse query parameters
      let page: number | undefined;
      let limit: number | undefined;

      if (pageParam !== undefined) {
        if (pageParam === '' || isNaN(Number(pageParam))) {
          return res.status(400).json({
            error: 'Invalid page parameter',
            message: 'Page must be a positive integer'
          });
        }
        page = Number(pageParam);
      }

      if (limitParam !== undefined) {
        if (limitParam === '' || isNaN(Number(limitParam))) {
          return res.status(400).json({
            error: 'Invalid limit parameter',
            message: 'Limit must be a positive integer'
          });
        }
        limit = Number(limitParam);
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error && typeof error === 'object' && 'code' in error) {
        const validationError = error as { code: string; message: string; details: string };
        return res.status(400).json({
          error: validationError.code,
          message: validationError.message,
          details: validationError.details
        });
      }
      
      console.error('Unexpected error:', error);
      res.status(500).json({
        error: 'Internal server error',
        message: 'An unexpected error occurred'
      });
    }
  });

  return app;
}
