import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

interface PaginationOptions {
  page?: number;
  limit?: number;
}

interface ValidationError extends Error {
  code: 'INVALID_PAGE' | 'INVALID_LIMIT';
  details: string;
}

function validatePaginationOptions(options: PaginationOptions): { page: number; limit: number } {
  const { page, limit } = options;
  
  let validatedPage = 1;
  let validatedLimit = DEFAULT_LIMIT;
  
  if (page !== undefined) {
    if (!Number.isInteger(page) || page < 1) {
      const error = new Error('Page must be a positive integer') as ValidationError;
      error.code = 'INVALID_PAGE';
      error.details = `Invalid page value: ${page}`;
      throw error;
    }
    validatedPage = page;
  }
  
  if (limit !== undefined) {
    if (!Number.isInteger(limit) || limit < 1) {
      const error = new Error('Limit must be a positive integer') as ValidationError;
      error.code = 'INVALID_LIMIT';
      error.details = `Invalid limit value: ${limit}`;
      throw error;
    }
    if (limit > MAX_LIMIT) {
      const error = new Error(`Limit cannot exceed ${MAX_LIMIT}`) as ValidationError;
      error.code = 'INVALID_LIMIT';
      error.details = `Limit ${limit} exceeds maximum of ${MAX_LIMIT}`;
      throw error;
    }
    validatedLimit = limit;
  }
  
  return { page: validatedPage, limit: validatedLimit };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: PaginationOptions
): InventoryPage {
  const { page, limit } = validatePaginationOptions(options);
  
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Fixed: offset should be (page - 1) * limit for proper pagination
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
