/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  removeObserverFromAllSubjects
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: (prevValue: T | undefined): T => {
      // Don't execute if disposed
      if (disposed) {
        // Return the current value to maintain type consistency
        return observer.value as T
      }
      
      // Execute the callback function and return the same value
      // Callbacks perform side effects but don't change the value
      updateFn(prevValue)
      return observer.value as T
    },
  }
  
  // Execute initial update to track dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it was subscribed to
    removeObserverFromAllSubjects(observer)
  }
}