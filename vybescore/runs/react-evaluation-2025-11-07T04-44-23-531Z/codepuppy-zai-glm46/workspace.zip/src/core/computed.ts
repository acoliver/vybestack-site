/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  EqualFn,
  createEqualFn,
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  addObserverToSubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Create a subject for this computed value to manage observers
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
    observers: new Set(),
  }
  
  // Flag to track if we've computed the initial value
  let hasComputedInitial = false
  
  // Create an observer for this computed value
  const observer: Observer<T> = {
    name: options?.name,
    value: subject.value,
    updateFn: (prevValue) => {
      // When this observer is updated (by dependencies changing),
      // recompute the value and notify its own observers
      const previousActive = getActiveObserver()
      setActiveObserver(observer)
      try {
        const newValue = updateFn(prevValue)
        
        // Check equality if equalFn is provided
        if (equalFn && equalFn(subject.value, newValue)) {
          return subject.value
        }
        
        subject.value = newValue
        observer.value = newValue
        hasComputedInitial = true
        
        // Notify all observers that depend on this computed value
        notifyObservers(subject)
        
        return newValue
      } finally {
        setActiveObserver(previousActive)
      }
    },
  }
  
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      // Another observer is accessing this computed value
      // Register that observer to be notified when this computed value changes
      addObserverToSubject(subject, activeObserver)
    }
    
    // Compute initial value only once when first accessed
    if (!hasComputedInitial) {
      hasComputedInitial = true
      const previousActive = getActiveObserver()
      setActiveObserver(observer)
      try {
        const initialValue = updateFn(subject.value)
        subject.value = initialValue
        observer.value = initialValue
      } finally {
        setActiveObserver(previousActive)
      }
    }
    
    return subject.value
  }
  
  return read
}