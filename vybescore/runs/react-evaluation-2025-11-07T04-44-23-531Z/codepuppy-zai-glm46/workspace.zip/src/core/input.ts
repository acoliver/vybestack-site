/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  addObserverToSubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  createEqualFn
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = createEqualFn(equal)
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as a dependency
      addObserverToSubject(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check equality if equalFn is provided
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers of the change
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}