/**
 * Base64 alphabet validation regex
 * Matches valid Base64 characters (A-Z, a-z, 0-9, +, /) and optional padding (=)
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * 
 * @throws {Error} If the input contains invalid Base64 characters or malformed padding
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for malformed padding (padding in wrong position)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    const paddingOnly = input.substring(paddingIndex);
    if (!/^=+$/.test(paddingOnly)) {
      throw new Error('Invalid Base64 input: malformed padding');
    }
    
    // Total length (with padding) must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  } else {
    // Without padding, length must be a multiple of 4, or we need to add padding
    // for Buffer to decode correctly
    const normalizedLength = Math.ceil(input.length / 4) * 4;
    const paddingNeeded = normalizedLength - input.length;
    if (paddingNeeded > 2) {
      throw new Error('Invalid Base64 input: invalid length');
    }
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: check that the decoded result is valid UTF-8
    // If the input was invalid base64, Buffer.from may produce garbage
    // We verify by re-encoding and comparing (handles padding variations)
    const reEncoded = Buffer.from(result, 'utf8').toString('base64');
    // Normalize both for comparison (remove trailing padding)
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReEncoded) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
