import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { readFileSync, existsSync } from 'fs';
import initSqlJs, { Database, Statement, SqlJsStatic } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize sql.js
let SQL: SqlJsStatic | null = null;
let db: Database | null = null;

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// Database functions
async function initializeDatabase() {
  try {
    SQL = await initSqlJs();
    
    if (!SQL) throw new Error('Failed to initialize SQL.js');
    
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    if (existsSync(dbPath)) {
      const fileBuffer = readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      // Create schema from schema.sql
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schema = readFileSync(schemaPath, 'utf8');
      if (db) {
        db.exec(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

async function saveDatabase() {
  try {
    if (!db || !SQL) return;
    const fs = await import('fs');
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const data = db.export();
    await fs.promises.writeFile(dbPath, Buffer.from(data));
    console.log('Database saved to:', dbPath);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field validation
  if (!data.firstName?.trim()) errors.push({ field: 'firstName', message: 'First name is required' });
  if (!data.lastName?.trim()) errors.push({ field: 'lastName', message: 'Last name is required' });
  if (!data.streetAddress?.trim()) errors.push({ field: 'streetAddress', message: 'Street address is required' });
  if (!data.city?.trim()) errors.push({ field: 'city', message: 'City is required' });
  if (!data.stateProvince?.trim()) errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  if (!data.postalCode?.trim()) errors.push({ field: 'postalCode', message: 'Postal code is required' });
  if (!data.country?.trim()) errors.push({ field: 'country', message: 'Country is required' });
  if (!data.email?.trim()) errors.push({ field: 'email', message: 'Email is required' });
  if (!data.phone?.trim()) errors.push({ field: 'phone', message: 'Phone number is required' });
  
  // Email validation
  if (data.email?.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }
  
  // Phone validation (international formats)
  if (data.phone?.trim()) {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    values: {}, 
    errors: [],
    title: 'Contact Form - Definitely Not A Scam'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  if (!db) {
    res.status(500).render('form', { 
      values: {}, 
      errors: [{ field: 'general', message: 'Database not initialized. Please try again later.' }],
      title: 'Contact Form - Error'
    });
    return;
  }
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    res.status(400).render('form', { 
      values: formData, 
      errors,
      title: 'Contact Form - Please Fix Errors'
    });
    return;
  }
  
  // Insert into database
  try {
    if (!db) throw new Error('Database not initialized');
    
    const stmt: Statement = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    await saveDatabase();
  } catch (error) {
    console.error('Database insertion failed:', error);
    res.status(500).render('form', { 
      values: formData, 
      errors: [{ field: 'general', message: 'Database error. Please try again.' }],
      title: 'Contact Form - Error'
    });
    return;
  }
  
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get first name from session or database query if available
  res.render('thank-you', { 
    title: 'Thank You - Here\'s What Happens Next...',
    firstName: 'friend' // Default if firstName not passed
  });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (db) {
    try {
      saveDatabase().then(() => {
        console.log('Database saved during shutdown');
        process.exit(0);
      }).catch((error) => {
        console.error('Error saving database during shutdown:', error);
        process.exit(1);
      });
    } catch (error) {
      console.error('Error saving database during shutdown:', error);
      process.exit(1);
    }
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize and start server
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}).catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
