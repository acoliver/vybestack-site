/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: SubjectR[]
  observers?: ObserverR[]
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: ObserverR[]
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type DependentsMap = Map<ObserverR, ObserverR[]>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer as ObserverR
  try {
    observer.value = observer.updateFn(observer.value)
    
    // Clear dependencies after update to force fresh tracking on next access
    if (observer.dependencies) {
      observer.dependencies = []
    }
  } finally {
    activeObserver = previous as ObserverR
  }
  
  return observer.value
}

// Function to notify all observers recursively when dependencies change
export function notifyDependencies(observer: ObserverR): void {
  // Update this observer to get the latest value
  const typedObserver = observer as Observer<unknown>
  updateObserver(typedObserver)
  
  // Notify all dependent observers recursively
  if (observer.observers) {
    const currentObservers = [...observer.observers]
    currentObservers.forEach(depObserver => {
      notifyDependencies(depObserver)
    })
  }
  
  // Clear dependencies after update to force fresh tracking on next access
  if (observer.dependencies) {
    observer.dependencies = []
  }
}

// Function to notify all observers of a subject when its value changes
export function notifySubjects(subjects: SubjectR[]): void {
  subjects.forEach(subject => {
    subject.observers.forEach(observer => {
      notifyDependencies(observer as ObserverR)
    })
  })
}
