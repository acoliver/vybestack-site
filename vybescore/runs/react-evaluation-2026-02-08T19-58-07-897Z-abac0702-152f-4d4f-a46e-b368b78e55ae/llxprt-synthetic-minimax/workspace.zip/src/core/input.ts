/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyDependencies,
  ObserverR,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track this subject as a dependency of the active observer
      if (!observer.dependencies) observer.dependencies = []
      if (!observer.dependencies.includes(s)) {
        observer.dependencies.push(s)
      }
      // Register this observer to this subject
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Only update if value actually changed
    const hasChanged = oldValue !== nextValue
    
    if (hasChanged) {
      // Create a fresh copy of observers to avoid mutation during iteration
      const currentObservers = [...s.observers]
      
      // Notify all observers through the dependency notification system
      currentObservers.forEach(observer => {
        notifyDependencies(observer as ObserverR)
      })
    }
    
    return s.value
  }

  return [read, write]
}
