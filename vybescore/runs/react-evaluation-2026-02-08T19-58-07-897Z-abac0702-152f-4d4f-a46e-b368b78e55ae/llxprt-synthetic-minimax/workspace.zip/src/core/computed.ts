/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  SubjectR,
  notifyDependencies
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: []
  }

  const read: GetterFn<T> = () => {
    // Update this observer to get the latest value
    // The updateFn will access any dependencies which will register them
    const result = updateObserver(o)
    
    // If there's an active observer, register this as a dependency
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o) {
      if (!currentObserver.dependencies) currentObserver.dependencies = []
      if (!currentObserver.dependencies.includes(o as unknown as SubjectR)) {
        currentObserver.dependencies.push(o as unknown as SubjectR)
      }
    }
    
    // Notify all dependent observers recursively
    if (o.observers) {
      const currentObservers = [...o.observers]
      currentObservers.forEach(depObserver => {
        notifyDependencies(depObserver)
      })
    }
    
    return result
  }

  return read
}
