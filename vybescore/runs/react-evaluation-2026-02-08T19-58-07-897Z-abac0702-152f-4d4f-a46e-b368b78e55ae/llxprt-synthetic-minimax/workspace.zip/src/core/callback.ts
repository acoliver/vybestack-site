/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: []
  }
  
  // Register this observer with active observer if one exists
  // This handles the case where callback is created within a computed getter
  const activeObserver = getActiveObserver()
  if (activeObserver) {
    if (!activeObserver.observers) {
      activeObserver.observers = []
    }
    activeObserver.observers.push(observer as ObserverR)
  }
  
  // Execute callback initially to establish dependencies and perform side effect
  updateObserver(observer)
  
  // Return unsubscribe function that disposes the callback
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to prevent further notifications
    observer.dependencies = []
    
    // Remove from active observer's observers list if present
    if (activeObserver && activeObserver.observers) {
      const index = activeObserver.observers.indexOf(observer as ObserverR)
      if (index > -1) {
        activeObserver.observers.splice(index, 1)
      }
    }
  }
}
