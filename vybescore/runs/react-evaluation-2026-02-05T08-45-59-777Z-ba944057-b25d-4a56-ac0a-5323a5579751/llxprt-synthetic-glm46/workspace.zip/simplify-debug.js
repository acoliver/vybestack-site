import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing basic reactive behavior...\n');

// Just test basic callback
const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;

console.log('Before callback creation, value =', value);
createCallback(() => {
  console.log('  Callback running, output() =', output());
  value = output();
});

console.log('After callback creation, value =', value);
console.log('Setting input to 3...');
setInput(3);

setTimeout(() => {
  console.log('After timeout, value =', value);
  console.log('Expected 4, got', value);
}, 100);