// Manual test to understand timing
import { createInput, createComputed, createCallback } from './src/index.js';

const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;

console.log('Initial state:');
console.log('  input() =', input());
console.log('  output() =', output());

createCallback(() => {
  console.log('Callback triggered');
  console.log('  Inside callback, input() =', input());
  console.log('  Inside callback, output() =', output());
  value = output();
});

console.log('Changed input from 1 to 3');
setInput(3);

// Test 1: Check immediate values
console.log('Immediately after setInput(3):');
console.log('  input() =', input());
console.log('  output() =', output());
console.log('  value =', value);

// Test 2: Wait then check
setTimeout(() => {
  console.log('After setTimeout:');
  console.log('  input() =', input());
  console.log('  output() =', output());
  console.log('  value =', value);
}, 50);