import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Simplified test...\n');

const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;

console.log('Before callback, value =', value);

createCallback(() => {
  console.log('  Callback called! output() =', output());
  value = output();
});

console.log('After callback creation, value =', value);
console.log('Calling setInput(3)...');
setInput(3);

// Wait for async update
setTimeout(() => {
  console.log('After timeout, value =', value);
  process.exit(0);
}, 100);