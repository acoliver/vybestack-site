/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subscriptions?: Set<Observer<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<T>>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const updatingObservers = new Set<Observer<unknown>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion
  if (updatingObservers.has(observer as any)) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  updatingObservers.add(observer as any)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    updatingObservers.delete(observer as any)
  }
  
  // Asynchronously notify any observers that depend on this observer
  if (observer.subscriptions && observer.subscriptions.size > 0) {
    const subscriptions = Array.from(observer.subscriptions)
    setTimeout(() => {
      for (const subscriber of subscriptions) {
        updateObserver(subscriber as any)
      }
    }, 0)
  }
}

// Add subscription management functions
export function addObserverSubscription<T>(observer: Observer<T>, subscriber: Observer<unknown>): void {
  if (!observer.subscriptions) {
    observer.subscriptions = new Set()
  }
  observer.subscriptions.add(subscriber as any)
}

export function removeObserverSubscription<T>(observer: Observer<T>, subscriber: Observer<unknown>): void {
  if (observer.subscriptions) {
    observer.subscriptions.delete(subscriber as any)
  }
}
