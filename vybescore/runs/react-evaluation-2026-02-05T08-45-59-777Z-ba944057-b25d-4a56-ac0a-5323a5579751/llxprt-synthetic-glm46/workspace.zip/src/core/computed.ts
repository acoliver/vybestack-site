/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  addObserverSubscription
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If being accessed by another observer, establish dependency
    if (activeObserver && activeObserver !== observer) {
      // The current computed observer should be subscribed to by the active observer
      // to create the dependency chain
      addObserverSubscription(observer, activeObserver as Observer<unknown>)
    }
    
    // Update the value by recomputing dependencies and running the update function
    return updateObserver(observer), observer.value!
  }
  
  return getter
}
