/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equality function parameter
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === true) {
    // Default strict equality if true
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set(), // Track multiple observers
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observers) {
      // Register this subject as a dependency
      if (!s.observers.has(observer as Observer<T>)) {
        s.observers.add(observer as Observer<T>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers that depend on this input
    if (s.observers) {
      const currentObservers = Array.from(s.observers)
      for (const obs of currentObservers) {
        updateObserver(obs)
      }
    }
    
    // Also notify direct observer if set
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
