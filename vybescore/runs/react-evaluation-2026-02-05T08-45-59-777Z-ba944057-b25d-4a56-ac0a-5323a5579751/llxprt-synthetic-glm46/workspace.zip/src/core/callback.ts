/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, removeObserverSubscription } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clean up subscriptions to prevent memory leaks
    if (observer.subscriptions) {
      // Remove this observer from all subjects it subscribes to
      for (const subject of observer.subscriptions) {
        removeObserverSubscription(subject, observer as unknown as Observer<unknown>)
      }
      // Clear the subscriptions set
      observer.subscriptions.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
