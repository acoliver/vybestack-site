import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing reactive system...\n');

// Test 1: Basic computed dependency
console.log('Test 1: Basic computed dependency');
const [input1, setInput1] = createInput(1);
const output1 = createComputed(() => input1() + 1);
console.log('Initial output:', output1()); // Should be 2
setInput1(3);
console.log('After set to 3, output:', output1()); // Should be 4

// Test 2: Multiple computed dependencies
console.log('\nTest 2: Multiple computed dependencies');
const [input2, setInput2] = createInput(1);
const timesTwo2 = createComputed(() => input2() * 2);
const timesThirty2 = createComputed(() => input2() * 30);
const sum2 = createComputed(() => timesTwo2() + timesThirty2());
console.log('Initial sum:', sum2()); // Should be 32
setInput2(3);
console.log('After set to 3, sum:', sum2()); // Should be 96

// Test 3: Callbacks
console.log('\nTest 3: Callbacks');
const [input3, setInput3] = createInput(1);
const output3 = createComputed(() => input3() + 1);
let value3 = 0;
createCallback(() => {
  console.log('  Callback triggered, output3() =', output3());
  value3 = output3();
});
console.log('Initial value:', value3); // Should be 2
setInput3(3);
setTimeout(() => {
  console.log('After set to 3, value:', value3); // Should be 4
}, 10);

// Test 4: Multiple callbacks and unsubscribe
console.log('\nTest 4: Multiple callbacks and unsubscribe');
const [input4, setInput4] = createInput(11);
const output4 = createComputed(() => input4() + 1);

const values1_4 = [];
const unsubscribe1_4 = createCallback(() => {
  console.log('  Callback1 triggered, output4() =', output4());
  values1_4.push(output4());
});

const values2_4 = [];
createCallback(() => {
  console.log('  Callback2 triggered, output4() =', output4());
  values2_4.push(output4());
});

console.log('Before setInput4, values1 length:', values1_4.length);
console.log('Before setInput4, values2 length:', values2_4.length);
setInput4(31);
setTimeout(() => {
  unsubscribe1_4();
  setInput4(41);
  
  setTimeout(() => {
    console.log('After all operations, values1 length:', values1_4.length);
    console.log('After all operations, values2 length:', values2_4.length);
    console.log('values2 length > values1 length?', values2_4.length > values1_4.length);
  }, 10);
}, 10);