/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

import { setDependenciesMap } from './input.js'

// Map to track which computed observers depend on which subjects
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const dependencies = new Map<Observer<any>, Set<Observer<any>>>()

// Register the dependencies map with input module
setDependenciesMap(dependencies)

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initial computation to establish dependencies and set initial value
  updateObserver(o)
  
  // Return getter that tracks this observer as active when accessed
  const getter: GetterFn<T> = (): T => {
    // When this computed value is accessed, register as dependency of parent
    const parentObserver = getActiveObserver()
    if (parentObserver) {
      // The parent observer depends on this computed value
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const parent = parentObserver as Observer<any>
      let deps = dependencies.get(parent)
      if (!deps) {
        deps = new Set()
        dependencies.set(parent, deps)
      }
      deps.add(o)
    }
    return o.value!
  }
  
  // Override the updateFn to handle re-computation
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T) => {
    // Clear old dependencies
    dependencies.delete(o)
    
    // Recompute
    const newValue = originalUpdateFn(prevValue)
    return newValue
  }
  
  return getter
}
