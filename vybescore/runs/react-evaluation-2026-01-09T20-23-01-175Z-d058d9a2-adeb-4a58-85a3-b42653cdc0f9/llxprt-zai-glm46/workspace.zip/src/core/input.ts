/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Import the dependencies map from computed
// We need to access it to notify dependent computed values
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let dependenciesMap: Map<Observer<any>, Set<Observer<any>>> | undefined

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function setDependenciesMap(map: Map<Observer<any>, Set<Observer<any>>>) {
  dependenciesMap = map
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Store observers separately to allow multiple observers
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const observers: Observer<any>[] = []
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    observers,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer if not already registered
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const obs = observer as Observer<any>
      if (!observers.includes(obs)) {
        observers.push(obs)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all direct observers of the change
    const observersToNotify = [...observers]
    for (const observer of observersToNotify) {
      updateObserver(observer)
    }
    
    // Also notify any computed values that depend on these observers
    if (dependenciesMap) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const notified = new Set<Observer<any>>()
      
      for (const observer of observersToNotify) {
        // Find all computed values that depend on this observer
        for (const [computed, deps] of dependenciesMap.entries()) {
          if (deps.has(observer) && !notified.has(computed)) {
            updateObserver(computed)
            notified.add(computed)
          }
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
