import express, { Request, Response } from 'express';
import { dbManager } from './lib/database.js';
import { Validator } from './lib/validation.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface RequestWithFormData extends Request {
  body: Partial<FormData>;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', 'src/views');

// Route: GET home page (form)
app.get('/', (req: Request, res: Response) => {
  res.status(200).render('index', {
    errors: [],
    formData: {} as Partial<FormData>
  });
});

// Route: POST form submission
app.post('/submit', (req: RequestWithFormData, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim(),
    lastName: req.body.lastName?.trim(),
    streetAddress: req.body.streetAddress?.trim(),
    city: req.body.city?.trim(),
    stateProvince: req.body.stateProvince?.trim(),
    postalCode: req.body.postalCode?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim()
  };

  const validation = Validator.validateSubmission(formData);

  if (!validation.valid) {
    return res.status(400).render('index', {
      errors: validation.errors,
      formData
    });
  }

  // Insert into database
  try {
    const submission = formData as Required<FormData>;
    dbManager.insertSubmission(submission);
    
    // Redirect to thank-you page on success
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('index', {
      errors: [{ field: 'general', message: 'Server error. Please try again later.' }],
      formData
    });
  }
});

// Route: GET thank-you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.status(200).render('thank-you');
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  dbManager.close();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
