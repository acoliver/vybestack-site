import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import path from 'path';

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    // Ensure data directory exists
    const dataDir = path.join(process.cwd(), 'data');
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }

    // Initialize sql.js
    this.sqlJs = await initSqlJs();

    // Load existing database or create new one
    if (existsSync(this.dbPath)) {
      const dbBuffer = readFileSync(this.dbPath);
      this.db = new (this.sqlJs!).Database(dbBuffer);
    } else {
      this.db = new (this.sqlJs!).Database();
      await this.initializeSchema();
    }
  }

  private async initializeSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaSql = readFileSync(this.schemaPath, 'utf-8');
    this.db.exec(schemaSql);
  }

  insertSubmission(submission: FormSubmission): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    this.saveDatabase();
  }

  private saveDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbBuffer = this.db.export();
    writeFileSync(this.dbPath, dbBuffer);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();