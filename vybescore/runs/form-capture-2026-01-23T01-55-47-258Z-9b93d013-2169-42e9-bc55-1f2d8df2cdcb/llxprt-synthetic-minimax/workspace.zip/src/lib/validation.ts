import { FormSubmission } from './database.js';

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

export class Validator {
  static validateSubmission(data: Partial<FormSubmission>): ValidationResult {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ] as const;

    for (const field of requiredFields) {
      const value = data[field];
      if (!value || value.trim() === '') {
        errors.push({
          field,
          message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
        });
      }
    }

    // Email validation
    if (data.email && data.email.trim() !== '') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation
    if (data.phone && data.phone.trim() !== '') {
      // Accept international formats with digits, spaces, parentheses, dashes, and leading @
      const phoneRegex = /^@?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number'
        });
      }
    }

    // Postal code validation (accept alphanumeric for international formats)
    if (data.postalCode && data.postalCode.trim() !== '') {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal code'
        });
      }
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }
}