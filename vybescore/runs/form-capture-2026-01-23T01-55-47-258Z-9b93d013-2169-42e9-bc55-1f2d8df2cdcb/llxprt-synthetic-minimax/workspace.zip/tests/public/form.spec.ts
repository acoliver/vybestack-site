import { describe, expect, it } from 'vitest';
import fs from 'node:fs';

describe('friendly form (public smoke)', () => {
  it('builds successfully without errors', () => {
    // Basic smoke test to ensure the code compiles
    expect(true).toBe(true);
  });

  it('creates required directories and files', () => {
    // Check that the build creates the necessary output
    expect(fs.existsSync('dist')).toBe(true);
  });

  it('has valid database schema', () => {
    // Check that schema file exists and is valid SQL
    expect(fs.existsSync('db/schema.sql')).toBe(true);
    const schema = fs.readFileSync('db/schema.sql', 'utf-8');
    expect(schema).toContain('CREATE TABLE');
    expect(schema).toContain('submissions');
  });

  it('includes all required form fields in template', () => {
    // Check that EJS templates exist and contain expected fields
    expect(fs.existsSync('src/views/index.ejs')).toBe(true);
    expect(fs.existsSync('src/views/thank-you.ejs')).toBe(true);
    
    const indexTemplate = fs.readFileSync('src/views/index.ejs', 'utf-8');
    expect(indexTemplate).toContain('name="firstName"');
    expect(indexTemplate).toContain('name="lastName"');
    expect(indexTemplate).toContain('name="streetAddress"');
    expect(indexTemplate).toContain('name="city"');
    expect(indexTemplate).toContain('name="stateProvince"');
    expect(indexTemplate).toContain('name="postalCode"');
    expect(indexTemplate).toContain('name="country"');
    expect(indexTemplate).toContain('name="email"');
    expect(indexTemplate).toContain('name="phone"');
  });

  it('has proper styling', () => {
    // Check that CSS file exists and has content
    expect(fs.existsSync('public/styles.css')).toBe(true);
    const styles = fs.readFileSync('public/styles.css', 'utf-8');
    expect(styles.length).toBeGreaterThan(100); // Non-trivial CSS
  });
});
