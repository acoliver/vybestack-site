/**
 * Capitalizes the first character of each sentence.
 * After punctuation marks (., ?, !), inserts exactly one space and capitalizes the next non-space character.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Trim leading/trailing spaces
  result = result.trim();
  
  // Capitalize first character
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize the first letter after each sentence-ending punctuation
  const capitalizeAfterPunctuationRegex = /([.!?])(\s*)([a-z])/g;
  result = result.replace(capitalizeAfterPunctuationRegex, (match, punctuation, spaces, letter) => {
    // Always use exactly one space after punctuation
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 * Returns an array of URL strings found in the text.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // URL regex pattern
  // http://|https:// - protocol
  // [a-zA-Z0-9.-]+\.[a-zA-Z]{2,} - domain
  // (:[0-9]+)? - optional port
  // (\/[^\s]*)? - optional path
  // We'll extract matches and then remove trailing punctuation
  const urlRegex = /https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?::[0-9]+)?(?:\/[^\s]*)?/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation: . , ; : ? ! ) ] } " '
    return url.replace(/[.,;:?!)\]\}"']+$/, '');
  });
}

/**
 * Replaces all http:// URLs with https:// while leaving already secure URLs untouched.
 * Returns the text with all HTTP URLs converted to HTTPS.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Use regex to find http:// URLs and replace with https://
  // Negative lookahead to avoid matching https://
  const httpRegex = /http:\/\//g;
  
  return text.replace(httpRegex, 'https://');
}

/**
 * Rewrites http://example.com/... URLs following these rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths (/docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // First, upgrade all http to https
  let result = enforceHttps(text);
  
  // Pattern to find example.com URLs
  // Capture groups: (1) full URL, (2) domain, (3) path
  const exampleUrlRegex = /(https:\/\/example\.com)(\/[^\s]*)/g;
  
  result = result.replace(exampleUrlRegex, (match, domain, path) => {
    // Check if path should be rewritten
    // Skip if path contains dynamic hints or legacy extensions
    const shouldRewrite = !(
      path.includes('cgi-bin') ||
      path.includes('?') ||
      path.includes('&') ||
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i.test(path)
    );
    
    // If path starts with /docs/ and should be rewritten
    if (path.startsWith('/docs/') && shouldRewrite) {
      return `https://docs.example.com${path}`;
    }
    
    return match;
  });
  
  return result;
}

/**
 * extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Pattern to match date format mm/dd/yyyy
  // Capture groups: (1) month, (2) day, (3) year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day based on month (simplified validation)
  // February (assuming non-leap year for simplicity)
  if (month === 2 && day > 28) {
    return 'N/A';
  }
  
  // April, June, September, November have 30 days
  const thirtyDayMonths = [4, 6, 9, 11];
  if (thirtyDayMonths.includes(month) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
