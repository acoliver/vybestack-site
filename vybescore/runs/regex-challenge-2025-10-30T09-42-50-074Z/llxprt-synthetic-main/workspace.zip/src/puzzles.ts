/**
 * Finds words beginning with the specified prefix but excluding those in the exceptions list.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
  // Create a regex pattern to find words beginning with the prefix
  // \b - word boundary
  // ([a-zA-Z]+) - capture word
  const wordRegex = new RegExp(`\\b([a-zA-Z]*${prefix}[a-zA-Z]*)\\b`, 'g');
  
  // Find all matching words
  const matches = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Check if the word starts with the prefix and is not in exceptions
    if (word.startsWith(prefix) && !exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to identify the correct positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: token that appears after a digit and not at the beginning
  // \d - match a digit but don't consume it
  // ${escapedToken} - the token
  const tokenRegex = new RegExp(`\\d(${escapedToken})`, 'g');
  
  // Find all matches
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the full match (digit + token), not just the captured group
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates password strength according to the following rules:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (like "abab")
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab")
  // We'll look for any 2-character sequence repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    const twoChar = value.substring(i, i + 2);
    const nextTwoChar = value.substring(i + 2, i + 4);
    
    if (twoChar === nextTwoChar) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses, including shorthand notation with ::.
 * Ensures IPv4 addresses do not trigger a positive result.
 * Returns true if the text contains a valid IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv6 regex pattern that covers standard and shorthand forms
  // This excludes IPv4 addresses by specifically checking for IPv6 patterns
  
  // Full IPv6 pattern without IPv4 embedded
  const ipv6Pattern = new RegExp(
    // Standard IPv6 (eight groups of 1-4 hex digits separated by colons)
    '(' +
    '(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|' +
    // IPv6 with :: replacing one or more groups of zeros
    '(?:[0-9a-fA-F]{1,4}:){1,7}:|' +
    '(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|' +
    '[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|' +
    ':(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)' +
    ')',
    'g'
  );
  
  // Test for IPv6 patterns
  return ipv6Pattern.test(value);
}