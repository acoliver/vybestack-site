export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common email standards.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic email validation using regex
  // Local part: letters, digits, and special chars except leading/trailing dots, consecutive dots
  // Domain part: letters, digits, hyphens (no underscores), with proper TLD structure
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Check if it matches the basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }

  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // Extract local and domain parts
  const [localPart, domain] = value.split('@');
  
  // Local part cannot start or end with a dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Domain cannot start or end with a dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 country code.
 * Accepts formats like: (212) 555-7890, 212-555-7890, 2125557890, +1-212-555-7890
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it has valid length (10 digits or 11 digits with leading 1 or country code)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Remove the leading country code
    const normalizedDigits = digitsOnly.substring(1);
    
    // Area code validation: cannot start with 0 or 1
    const areaCode = normalizedDigits.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    // Validate format with optional separators
    const phoneRegex = /^\+?1[\s-]?\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})$/;
    return phoneRegex.test(value);
  } else if (digitsOnly.length === 10) {
    // Area code validation: cannot start with 0 or 1
    const areaCode = digitsOnly.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    // Validate format with optional separators
    const phoneRegex = /^\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})$/;
    return phoneRegex.test(value);
  }
  
  return false;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Accepts formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code (+54)
 * - Optional trunk prefix (0) before area code
 * - Optional mobile indicator (9) between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all spaces and hyphens for pattern matching
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // ^\+?54    -> Start with optional +54 (country code)
  // [\s-]*9?  -> Optional 9 (mobile indicator)
  // [\s-]*0?  -> Optional 0 (trunk prefix)
  // [1-9]\d{1,3} -> Area code (2-4 digits, first digit 1-9)
  // \d{6,8}$   -> Subscriber number (6-8 digits)
  const arPhoneRegex = /^\+?54[\s-]*9?[\s-]*0?[1-9]\d{1,3}\d{6,8}$/;
  
  // Check if it matches the pattern
  if (!arPhoneRegex.test(normalized)) {
    return false;
  }
  
  // Extract parts for validation
  const matches = normalized.match(/^(\+?54)?[\s-]*(9)?[\s-]*(0?)([1-9]\d{1,3})(\d+)$/);
  
  if (!matches) {
    return false;
  }
  
  const [, countryCode, , trunkPrefix, , subscriberNumber] = matches;
  
  // If country code is omitted, trunk prefix is required
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate subscriber number length
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Name validation regex
  // ^[ \p{L}][\p{L}\p{M}'\- ]*[ \p{L}]$ -> 
  // Start and end with a letter or space
  // Allow letters (including Unicode), mark combining characters, apostrophes, hyphens, and spaces in between
  const nameRegex = /^[ \p{L}][ \p{L}\p{M}'\- ]*[ \p{L}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // No consecutive spaces or special chars
  if (/[  '-]{2,}/.test(value)) {
    return false;
  }
  
  // At least one letter is required beyond spaces and special chars
  const hasValidLetter = /[\p{L}\p{M}]+/u.test(value.trim());
  if (!hasValidLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers based on format and Luhn checksum.
 * Accepts Visa (13 or 16 digits starting with 4), Mastercard (16 digits starting with 51-55),
 * and American Express (15 digits starting with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens from the input
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Validate card type and length
  const isVisa = /^4\d{12}(\d{3})?$/.test(normalized); // 13 or 16 digits
  const isMastercard = /^5[1-5]\d{14}$/.test(normalized); // 16 digits
  const isAmEx = /^3[47]\d{13}$/.test(normalized); // 15 digits
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(normalized);
}

/**
 * Helper function to perform Luhn checksum validation on a credit card number.
 */
function runLuhnCheck(number: string): boolean {
  const digits = number.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
