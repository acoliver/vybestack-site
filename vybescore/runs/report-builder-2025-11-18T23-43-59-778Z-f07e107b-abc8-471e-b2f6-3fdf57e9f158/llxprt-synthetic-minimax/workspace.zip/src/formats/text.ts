import { ReportData, RenderOptions, Formatter } from '../types.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

const calculateTotal = (entries: { amount: number }[]): number => {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
};

export const renderText: Formatter = {
  format: (data: ReportData, options: RenderOptions): string => {
    let output = `${data.title}\n`;
    output += `${data.summary}\n\n`;
    output += `Entries:\n`;

    for (const entry of data.entries) {
      output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
    }

    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      output += `\nTotal: ${formatAmount(total)}\n`;
    }

    return output;
  }
};