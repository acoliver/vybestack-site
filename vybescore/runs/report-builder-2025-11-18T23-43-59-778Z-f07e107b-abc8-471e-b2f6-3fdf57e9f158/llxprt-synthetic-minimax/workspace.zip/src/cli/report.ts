import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

const parseArguments = (args: string[]): { filePath: string; options: CliOptions } => {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = args[0];
  const options: CliOptions = {
    format: '',
    includeTotals: false
  };

  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { filePath, options };
};

const loadReportData = (filePath: string): ReportData => {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'label'`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'amount'`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${filePath}': ${error.message}`);
    } else if (error instanceof Error && error.message.startsWith('Error:')) {
      console.error(error.message);
    } else {
      console.error(`Error: Failed to read or parse file '${filePath}': ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
};

const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText
};

const main = (): void => {
  const args = process.argv.slice(2);
  const { filePath, options } = parseArguments(args);
  
  const data = loadReportData(filePath);
  
  const renderer = formatRenderers[options.format as keyof typeof formatRenderers];
  if (!renderer) {
    console.error(`Error: Unsupported format '${options.format}'. Supported formats: ${Object.keys(formatRenderers).join(', ')}`);
    process.exit(1);
  }
  
  const output = renderer.format(data, { includeTotals: options.includeTotals });
  
  if (options.output) {
    try {
      writeFileSync(options.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${options.output}': ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
};

main();