import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

/**
 * Formats report data as markdown
 */
export const renderMarkdown: ReportFormatter = (data: ReportData, options: ReportOptions): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries header
  lines.push('## Entries');
  lines.push('');

  // Entries list
  data.entries.forEach((entry) => {
    lines.push(`- **${entry.label}** — ${entry.amount.toFixed(2)}`);
  });

  // Add totals if requested
  if (options.includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum: number, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** ${total.toFixed(2)}`);
  }

  return lines.join('\n');
};