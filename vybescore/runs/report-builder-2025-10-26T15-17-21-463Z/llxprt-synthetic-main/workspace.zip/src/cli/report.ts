import { promises as fs } from 'fs';
import type { ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseArguments, type CLIArguments } from '../utils/cli.js';
import { loadReportData } from '../utils/data.js';

/**
 * Map format names to their rendering functions
 */
const formatMap: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Main CLI function - entry point for the report builder
 */
async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const { dataFile, options, outputFile }: CLIArguments = parseArguments(process.argv);

    // Load and validate the report data
    const reportData = await loadReportData(dataFile);

    // Get the appropriate formatter
    const formatter = formatMap[options.format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${options.format}`);
    }

    // Generate the report
    const report = formatter(reportData, options);

    // Output to file or stdout
    if (outputFile) {
      await fs.writeFile(outputFile, report);
      console.error(`Report written to ${outputFile}`);
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

// Run the CLI
main();