/**
 * Report data structure for JSON input
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Single report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Options that control report formatting
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  includeTotals: boolean;
}

/**
 * Report formatting function interface
 */
export interface ReportFormatter {
  (data: ReportData, options: ReportOptions): string;
}