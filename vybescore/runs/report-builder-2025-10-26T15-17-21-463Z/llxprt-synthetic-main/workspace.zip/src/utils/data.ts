import { readFile } from 'fs/promises';
import type { ReportData } from '../types.js';

/**
 * Validates report data has the required structure
 */
export function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "title" field (expected string)');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: Missing or invalid "entries" field (expected array)');
  }

  for (const entry of report.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: Each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: Each entry must have a "label" string field');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: Each entry must have an "amount" number field');
    }
  }
}

/**
 * Load and validate report data from a JSON file
 */
export async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    // TypeScript doesn't know about the code property on Error objects
    // So we need to cast it to a more specific type
    const nodeError = error as Error & { code?: string };
    if (nodeError.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}