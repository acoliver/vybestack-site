import type { ReportOptions } from '../types.js';

/**
 * Parsed CLI arguments
 */
export interface CLIArguments {
  dataFile: string;
  options: ReportOptions;
  outputFile?: string;
}

/**
 * Parse command line arguments using Node's standard library
 */
export function parseArguments(argv: string[]): CLIArguments {
  if (argv.length < 4) {
    throw new Error('Usage: node <script> <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = argv[2];
  const options: ReportOptions = {
    format: 'markdown', // default
    includeTotals: false, // default
  };
  let outputFile: string | undefined;

  // Parse arguments
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];

    if (arg === '--format' && i + 1 < argv.length) {
      const format = argv[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error('Unsupported format: ' + format + '. Supported formats are: markdown, text');
      }
      options.format = format as 'markdown' | 'text';
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output' && i + 1 < argv.length) {
      outputFile = argv[i + 1];
      i++; // Skip next argument as it's the output path
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return { dataFile, options, outputFile };
}