/**
 * Find words starting with the prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // Word boundary at start, then prefix, then more word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of token that appear after a digit and not at the start of the string.
 * Uses lookbehind to check for preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, with word boundary after token
  // Ensure it's not at the start of the string by requiring something before it
  const pattern = new RegExp(`(?:\\d${escapedToken})(?=\\b|$)`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 1212, abcabc)
  // This looks for patterns of length 2-6 that repeat immediately
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check if the string contains an IPv6 address pattern
  // First, let's look for the :: shorthand pattern
  const shorthandPattern = /(?:^|\s)([0-9a-fA-F:]*(?:::)[0-9a-fA-F:]*)(?:\s|$|[,\])])/;
  if (shorthandPattern.test(value)) return true;

  // Check for full IPv6 pattern (7 colons for 8 groups of hex)
  const fullPattern = /(?:^|\s)(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:\s|$|[,\])])/;
  if (fullPattern.test(value)) return true;

  // Check for compressed IPv6 patterns (fewer than 8 groups but still has colons)
  const compressedPattern = /(?:^|\s)(?:[0-9a-fA-F]{1,4}:){1,6}:(?::[0-9a-fA-F]{1,4}){1,6}(?:\s|$|[,\])])/;
  if (compressedPattern.test(value)) return true;

  // Check for IPv6 with embedded IPv4
  const embeddedPattern = /(?:^|\s)(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}(?:\s|$|[,\])])/;
  if (embeddedPattern.test(value)) return true;

  return false;
}
