/**
 * Capitalize the first character of each sentence.
 * After .?!, insert exactly one space and collapse extra spaces.
 * Tries to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();

  // Capitalize first character of text
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Split on sentence boundaries and process each
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punctuation, nextChar) => {
    return punctuation + ' ' + nextChar.toUpperCase();
  });

  // Handle cases where there's no space after punctuation
  result = result.replace(/([.!?])([a-z])/g, (match, punctuation, nextChar) => {
    return punctuation + ' ' + nextChar.toUpperCase();
  });

  return result;
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www.
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-._~:/?#[@!$&'()*+,;=%]+[a-zA-Z0-9-_~:/?#[@!$&'()*+,;=%]/g;

  const matches = text.match(urlPattern) || [];

  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation marks
    return url.replace(/[.,;:!?(){}[\]"'']+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Convert all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://docs.example.com/... when path starts with /docs/
 * Always upgrades scheme to https://.
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Group 1: full URL
  // Group 2: scheme (http)
  // Group 3: domain (example.com)
  // Group 4: path and query
  
  return text.replace(/(https?:\/\/)(example\.com)(\/[^\s]*)?/gi, (match, scheme, domain, path = '') => {
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // If no path or path doesn't start with /docs/, just upgrade scheme
    if (!path || !path.startsWith('/docs/')) {
      return newScheme + domain + path;
    }
    
    // Check for dynamic content indicators
    const dynamicPatterns = [
      /cgi-bin/,
      /[?&=]/,  // Query string parameters
      /\.jsp$/,
      /\.php$/,
      /\.asp$/,
      /\.aspx$/,
      /\.do$/,
      /\.cgi$/,
      /\.pl$/,
      /\.py$/
    ];
    
    // Check if path contains any dynamic indicators
    const hasDynamicContent = dynamicPatterns.some(pattern => pattern.test(path));
    
    if (hasDynamicContent) {
      // Only upgrade scheme, don't rewrite host
      return newScheme + domain + path;
    }
    
    // Rewrite to docs.example.com for /docs/ paths without dynamic content
    return newScheme + 'docs.' + domain + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assume leap year for simplicity
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
