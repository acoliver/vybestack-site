export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (/\.\.|^\.|\.$/.test(value)) return false;
  
  // Check for underscores in domain part (split by @ and check domain)
  const atPos = value.indexOf('@');
  if (atPos === -1) return false;
  const domain = value.slice(atPos + 1);
  if (/_/.test(domain)) return false;
  
  // Email regex pattern
  // Local part: alphanumeric + special chars like . _ % + - but not consecutive dots
  // Domain: alphanumeric with hyphens, dots as separators, no trailing/leading dots
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?!-)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for no double dots in local or domain part
  if (/\.\./.test(value)) return false;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Check minimum length (10 digits for US number, optionally 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;

  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') return false;

  // Extract the actual 10-digit number (remove leading 1 if present)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;

  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Check exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;

  // Validate format with optional +1, area code in parentheses or not, various separators
  const phoneRegex = /^\+?1?\s*\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;

  return phoneRegex.test(value);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  void options;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, parentheses)
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Argentine phone regex pattern
  // Optional +54 country code
  // Optional trunk prefix 0 (required if country code is omitted)
  // Optional mobile indicator 9
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54|54)?(?:0)?[1-9]\d{1,2}(9)?\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) return false;
  
  // Parse components
  let remaining = cleaned;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  } else if (remaining.startsWith('54')) {
    remaining = remaining.slice(2);
  }
  
  // Check trunk prefix rule: if no country code, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  if (!hasCountryCode && !remaining.startsWith('0')) return false;
  
  // Remove trunk prefix if present
  if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
  }
  
  // Remove mobile indicator 9 if present
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Now remaining should be: area code (2-4 digits, starts with 1-9) + subscriber (6-8 digits)
  // Total length should be 8-12 digits
  if (remaining.length < 8 || remaining.length > 12) return false;
  
  // Area code validation (first 2-4 digits, starts with 1-9)
  const areaCodeLength = remaining.length >= 10 ? 4 : (remaining.length >= 9 ? 3 : 2);
  const areaCode = remaining.slice(0, areaCodeLength);
  
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number validation (6-8 digits)
  const subscriberNumber = remaining.slice(areaCodeLength);
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and strange patterns
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) return false;

  // Check for digits in the name
  if (/\d/.test(value)) return false;

  // Check for invalid symbols (anything other than letters, spaces, hyphens, apostrophes)
  // This catches things like "X Æ A-12" which has the Æ symbol
  const validCharsRegex = /^[\p{L}\p{M}\s'-]+$/u;
  if (!validCharsRegex.test(value)) return false;

  // Name must have at least one letter
  if (!/\p{L}/u.test(value)) return false;

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * Checks prefix, length, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Check card type and length
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15

  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  const mastercardRegex = /^(5[1-5]\d{14}|(222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)\d{12})$/;
  const amexRegex = /^3[47]\d{13}$/;

  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }

  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}
