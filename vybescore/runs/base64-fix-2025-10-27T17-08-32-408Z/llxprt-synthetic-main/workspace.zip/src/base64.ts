/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string contains only valid Base64 characters (A-Z, a-z, 0-9, +, /, =).
 * @param input - The string to validate.
 * @returns True if valid Base64 characters only.
 */
function isValidBase64(input: string): boolean {
  // Empty input is not valid
  if (input.length === 0) return false;
  
  // Check for valid Base64 characters using regex
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) return false;
  
  // Validate padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must appear at the end
    const paddingStr = input.substring(paddingIndex);
    // Only up to 2 '=' characters allowed
    if (!/^={1,2}$/.test(paddingStr)) return false;
    
    // Length must be a multiple of 4
    if (input.length % 4 !== 0) return false;
  } else {
    // Without padding, length should be a multiple of 4
    if (input.length % 4 !== 0) {
      try {
        // Try to decode without validation (Buffer.from accepts length % 4 !== 0)
        Buffer.from(input, 'base64');
      } catch {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses the canonical Base64 alphabet and validates input.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate the input has only valid Base64 characters
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters or incorrect padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
