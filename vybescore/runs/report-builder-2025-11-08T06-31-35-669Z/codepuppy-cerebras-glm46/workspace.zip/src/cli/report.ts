#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportRenderer, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): { dataPath: string; options: CliOptions } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Parse options
  const options: CliOptions = {
    format: '',
    includeTotals: false
  };
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
    i++;
  }
  
  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataPath, options };
}

function validateFormat(format: string): ReportRenderer {
  const formatters: Record<string, ReportRenderer> = {
    markdown: renderMarkdown,
    text: renderText
  };
  
  const formatter = formatters[format];
  if (!formatter) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }
  
  return formatter;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "amount" field (expected number)`);
    }
  }
  
  return data as ReportData;
}

function loadReportData(path: string): ReportData {
  try {
    const fileContent = readFileSync(path, 'utf-8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${path}": ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Unable to read file "${path}"`);
    }
    process.exit(1);
  }
}

function main(): void {
  const { dataPath, options } = parseArguments();
  
  const formatter = validateFormat(options.format);
  const data = loadReportData(dataPath);
  
  const formatOptions: FormatOptions = {
    includeTotals: options.includeTotals
  };
  
  const output = formatter.render(data, formatOptions);
  
  if (options.outputPath) {
    try {
      writeFileSync(options.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to write to file "${options.outputPath}"`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();