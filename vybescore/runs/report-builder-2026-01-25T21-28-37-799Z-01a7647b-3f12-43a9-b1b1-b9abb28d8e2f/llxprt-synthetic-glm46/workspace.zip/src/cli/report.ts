#!/usr/bin/env node

import fs from 'fs';
import type { ReportData, ReportFormat, ExtendedCliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): ExtendedCliOptions | null {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    return null;
  }
  
  const options: ExtendedCliOptions = {
    format: 'markdown',
    includeTotals: false,
    inputFile: ''
  };
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (++i >= args.length) {
        console.error('Error: --format requires a value');
        return null;
      }
      const format = args[i] as ReportFormat;
      if (format !== 'markdown' && format !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        return null;
      }
      options.format = format;
    } else if (arg === '--output') {
      if (++i >= args.length) {
        console.error('Error: --output requires a path');
        return null;
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (!arg.startsWith('-') && i === 0) {
      // This is the data file path
      options.inputFile = arg;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      return null;
    }
    
    i++;
  }
  
  if (!options.inputFile) {
    console.error('Error: Input file is required');
    return null;
  }
  
  return options;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON data: Expected an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string' || !reportData.title.trim()) {
    throw new Error('Invalid report data: Missing or invalid title');
  }
  
  if (typeof reportData.summary !== 'string' || !reportData.summary.trim()) {
    throw new Error('Invalid report data: Missing or invalid summary');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: Missing or invalid entries array');
  }
  
  const entries = reportData.entries as Array<unknown>;
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid report data: Entry must be an object');
    }
    
    const entryRecord = entry as Record<string, unknown>;
    if (typeof entryRecord.label !== 'string' || !entryRecord.label.trim()) {
      throw new Error('Invalid report data: Entry missing or invalid label');
    }
    
    if (typeof entryRecord.amount !== 'number' || isNaN(entryRecord.amount)) {
      throw new Error('Invalid report data: Entry missing or invalid amount');
    }
  }
  
  return data as ReportData;
}

function generateReport(data: ReportData, format: ReportFormat, includeTotals?: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, { includeTotals });
    case 'text':
      return renderText(data, { includeTotals });
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  const options = parseArgs();
  if (!options) {
    process.exit(1);
  }
  
  try {
    // Read and parse the input file
    const fileContent = fs.readFileSync(options.inputFile!, 'utf8');
    let data;
    try {
      data = JSON.parse(fileContent);
    } catch (parseError) {
      throw new Error(`Invalid JSON in file: ${options.inputFile}`);
    }
    
    // Validate the data
    const reportData = validateReportData(data);
    
    // Generate the report
    const report = generateReport(reportData, options.format, options.includeTotals);
    
    // Output the report
    if (options.output) {
      fs.writeFileSync(options.output, report);
      console.log(`Report written to ${options.output}`);
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
