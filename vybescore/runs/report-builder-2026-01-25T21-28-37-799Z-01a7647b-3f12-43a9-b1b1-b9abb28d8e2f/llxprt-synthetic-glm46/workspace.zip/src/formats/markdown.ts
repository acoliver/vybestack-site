import type { ReportData, RenderOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export function renderMarkdown(
  data: ReportData,
  options?: RenderOptions
): string {
  const lines: string[] = [];
  
  // Add title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries heading
  lines.push('## Entries');
  
  // Add entries as bullet list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Add total if requested
  if (options?.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}