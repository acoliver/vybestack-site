import { describe, expect, it } from 'vitest';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

describe('report CLI (public smoke)', () => {
  const testFixtures = path.join(process.cwd(), 'fixtures');
  const dataPath = path.join(testFixtures, 'data.json');
  const distPath = path.join(process.cwd(), 'dist', 'cli', 'report.js');
  const nodeCmd = `node ${distPath}`;

  it('should render markdown format to stdout', () => {
    const output = execSync(`${nodeCmd} ${dataPath} --format markdown`, { encoding: 'utf8' });
    expect(output).toContain('# Quarterly Financial Summary');
    expect(output).toContain('Highlights include record revenue');
    expect(output).toContain('## Entries');
    expect(output).toContain('- **North Region** — $12345.67');
    expect(output).toContain('- **South Region** — $23456.78');
    expect(output).toContain('- **West Region** — $34567.89');
  });

  it('should render text format to stdout', () => {
    const output = execSync(`${nodeCmd} ${dataPath} --format text`, { encoding: 'utf8' });
    expect(output).toContain('Quarterly Financial Summary');
    expect(output).toContain('Highlights include record revenue');
    expect(output).toContain('Entries:');
    expect(output).toContain('- North Region: $12345.67');
    expect(output).toContain('- South Region: $23456.78');
    expect(output).toContain('- West Region: $34567.89');
  });

  it('should include totals when requested in markdown format', () => {
    const output = execSync(`${nodeCmd} ${dataPath} --format markdown --includeTotals`, { encoding: 'utf8' });
    expect(output).toContain('**Total:** $70370.34');
  });

  it('should include totals when requested in text format', () => {
    const output = execSync(`${nodeCmd} ${dataPath} --format text --includeTotals`, { encoding: 'utf8' });
    expect(output).toContain('Total: $70370.34');
  });

  it('should save to file when output path is specified', () => {
    const outputPath = path.join(testFixtures, 'output.md');
    const output = execSync(`${nodeCmd} ${dataPath} --format markdown --output ${outputPath}`, { encoding: 'utf8' });
    expect(output).toContain(`Report written to ${outputPath}`);
    expect(fs.existsSync(outputPath)).toBe(true);
    
    const fileContent = fs.readFileSync(outputPath, 'utf8');
    expect(fileContent).toContain('# Quarterly Financial Summary');
    
    // Clean up
    fs.unlinkSync(outputPath);
  });

  it('should error with unsupported format', () => {
    expect(() => {
      execSync(`${nodeCmd} ${dataPath} --format unsupported`, { encoding: 'utf8' });
    }).toThrow('Unsupported format');
  });

  it('should error with malformed JSON file', () => {
    const invalidPath = path.join(testFixtures, 'invalid.json');
    fs.writeFileSync(invalidPath, '{ invalid json');
    
    expect(() => {
      execSync(`${nodeCmd} ${invalidPath} --format markdown`, { encoding: 'utf8' });
    }).toThrow('Invalid JSON');
    
    // Clean up
    fs.unlinkSync(invalidPath);
  });

  it('should error with missing fields', () => {
    const invalidPath = path.join(testFixtures, 'incomplete.json');
    fs.writeFileSync(invalidPath, JSON.stringify({
      title: 'Test Report'
      // Missing summary and entries
    }));
    
    expect(() => {
      execSync(`${nodeCmd} ${invalidPath} --format markdown`, { encoding: 'utf8' });
    }).toThrow('Missing or invalid summary');
    
    // Clean up
    fs.unlinkSync(invalidPath);
  });
});
