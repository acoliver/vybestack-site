/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape any special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find words with the prefix
  // Using word boundaries \b to match whole words
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches in the text
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(word => !exceptions.includes(word));
  
  // Return unique matches
  return [...new Set(filteredMatches)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token with a digit before it, but not at the start of the string
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab")
  // Look for any 2-character pattern repeated immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches various IPv6 formats
  // Including compressed forms with :: and embedded IPv4 addresses
  
  // First check for IPv4 addresses to exclude them
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // If the entire string is just an IPv4 address, return false
    // But if there are other characters, it might contain an IPv6 address
    if (ipv4Pattern.test(value.trim()) && value.trim().match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/)?.[0] === value.trim()) {
      return false;
    }
  }
  
  // IPv6 pattern matching various formats:
  // 1. Standard format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. Compressed format with :: (one or more groups of zeros)
  // 3. IPv6 with embedded IPv4: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:d.d.d.d
  const ipv6Patterns = [
    // Standard format (8 groups of 1-4 hex digits)
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Compressed format with :: at various positions
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    /\b::1\b/,
    /\b::\b/,
    /\b[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/,
    // IPv6 with embedded IPv4
    // (6 groups of hex):d.d.d.d
    /\b(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/,
    // Compressed IPv6 with embedded IPv4
    /\b(?:[0-9a-fA-F]{1,4}:){0,5}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  // Check if any IPv6 pattern matches, but ensure it's not part of an IPv4 address
  for (const pattern of ipv6Patterns) {
    const matches = value.match(pattern);
    if (matches) {
      // Make sure the match isn't actually an IPv4 address
      for (const match of matches) {
        if (!ipv4Pattern.test(match)) {
          return true;
        }
      }
    }
  }
  
  return false;
}
