export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with typical patterns.
 * Accepts formats like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Local part: alphanumerics, dots, hyphens, plus, apostrophes
  // But no consecutive dots, no starting/ending dots
  // Domain part: alphanumerics, hyphens, but no underscores
  // TLD: at least 2 characters
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick check against basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // No consecutive dots in local part
  if (/\.\./.test(value)) {
    return false;
  }
  
  // No domain with underscores
  if (/_/.test(value.split('@')[1])) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats and optional +1 prefix.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be 10 or 11 digits (11 digits only if starting with 1 for country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false; // If 11 digits, must start with 1
  }
  
  if (digitsOnly.length === 10) {
    // 10 digits format
  } else if (digitsOnly.length === 11 && digitsOnly[0] === '1') {
    // 11 digits format with country code
  } else {
    return false; // Invalid length
  }
  
  // Extract the actual 10-digit phone number (excluding country code if present)
  const phoneNumber = digitsOnly.length === 10 ? digitsOnly : digitsOnly.substring(1);
  
  // Area code cannot start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Check if the format matches common US phone patterns
  const phonePatterns = [
    /^\+?1?\s*\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})$/, // (123) 456-7890 or 123-456-7890
    /^\+?1?(\d{10})$/, // 1234567890
    /^\+?1?\s*(\d{3})\s*(\d{3})\s*(\d{4})$/ // 123 456 7890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation, but keep structure
  const cleanForValidation = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers:
  // Optional +54 country code
  // If no country code, must start with 0 (trunk prefix)
  // Optional 9 for mobile after country code or trunk prefix
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0)?([1-9]\d{0,3})?(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanForValidation)) {
    return false;
  }
  
  // Parse components
  const hasCountryCode = cleanForValidation.startsWith('+54');
  
  // Remove country code if present
  const withoutCountryCode = hasCountryCode ? cleanForValidation.substring(3) : cleanForValidation;
  
  // Check trunk prefix logic
  // If no country code, must start with 0 (trunk prefix)
  if (!hasCountryCode && !withoutCountryCode.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  const withoutTrunkPrefix = withoutCountryCode.startsWith('0') ? 
    withoutCountryCode.substring(1) : withoutCountryCode;
  
  // Check for mobile indicator (9) - can be present or absent
  const hasMobileIndicator = withoutTrunkPrefix.startsWith('9');
  const afterMobileIndicator = hasMobileIndicator ? 
    withoutTrunkPrefix.substring(1) : withoutTrunkPrefix;
  
  // Extract and validate area code (2-4 digits, first digit 1-9)
  let areaCodeLength;
  let subscriberNumber;
  
  // Try 4-digit area code first
  if (afterMobileIndicator.length >= 8) {
    areaCodeLength = 4;
    subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
    if (subscriberNumber.length < 4 || subscriberNumber.length > 8) {
      // Try 3-digit area code
      areaCodeLength = 3;
      subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
      if (subscriberNumber.length < 5 || subscriberNumber.length > 8) {
        // Try 2-digit area code
        areaCodeLength = 2;
        subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
        if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
          return false;
        }
      }
    }
  } else if (afterMobileIndicator.length >= 7) {
    // Try 3-digit area code
    areaCodeLength = 3;
    subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
    if (subscriberNumber.length < 4 || subscriberNumber.length > 8) {
      // Try 2-digit area code
      areaCodeLength = 2;
      subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
      if (subscriberNumber.length < 5 || subscriberNumber.length > 8) {
        return false;
      }
    }
  } else {
    // Try 2-digit area code
    areaCodeLength = 2;
    subscriberNumber = afterMobileIndicator.substring(areaCodeLength);
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
  }
  
  const areaCode = afterMobileIndicator.substring(0, areaCodeLength);
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, including accented characters
  // Allow apostrophes, hyphens, and spaces
  // Must contain at least one letter
  // No digits or special symbols
  // Define a regex that only allows valid name characters
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\u0400-\u04FF]+(['\-\s][a-zA-Z\u00C0-\u024F\u0400-\u04FF]+)*$/;
  
  // Check if the value matches the name pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Ensure at least one letter character
  if (!/[a-zA-Z\u00C0-\u024F\u0400-\u04FF]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx formats with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if the cleaned number contains only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Check length based on card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{11})))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Luhn checksum algorithm
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
