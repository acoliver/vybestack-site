/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Capitalizes after .?! punctuation, inserts exactly one space between sentences,
 * and collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces to single space
  let processedText = text.replace(/\s+/g, ' ');
  
  // Add space after punctuation if missing (before capital letters)
  processedText = processedText.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Split into sentences using punctuation that ends sentences
  const sentences = processedText.split(/(?<=[.!?])\s+/);
  
  // Capitalize the first letter of each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    
    // Find the first letter character and capitalize it
    return sentence.replace(/^[a-z]/, char => char.toUpperCase());
  });
  
  // Join sentences back with single spaces
  return capitalizedSentences.join(' ');
}

/**
 * Find URLs in the text and return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches most common URL formats
  // http/https scheme, www. domains, with optional ports, paths, query strings, and fragments
  const urlRegex = /(?:(?:https?|ftp):\/\/|www\.)[^<>\s"'`]+/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each match
  const cleanedUrls = matches.map(match => {
    // Remove trailing punctuation like .,;:!?)]}"' but not from the URL itself
    return match.replace(/[.,;:!?)\]}'"\s]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using regex with word boundary to avoid false positives
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http URLs according to specific rules:
 * - Always upgrade scheme to https://
 * - For docs paths ( beginning with /docs/), rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs
  const urlPattern = /(http:\/\/[^<>\s]+)/g;
  
  return text.replace(urlPattern, (match) => {
    // Parse the URL
    let url = match;
    
    // Always upgrade to https first
    url = url.replace(/^http:\/\//, 'https://');
    
    // Extract the path part for analysis
    const urlParts = url.match(/^https:\/\/([^/]+)(.*)/);
    if (!urlParts) return url;
    
    const [, domain, path] = urlParts;
    
    // Check for dynamic content indicators that should prevent host rewrite
    const dynamicIndicators = [
      '/cgi-bin',
      '?',
      '&',
      '=',
      '.jsp',
      '.php',
      '.asp',
      '.aspx',
      '.do',
      '.cgi',
      '.pl',
      '.py'
    ];
    
    const shouldSkipHostRewrite = dynamicIndicators.some(indicator => path.includes(indicator));
    
    // If path starts with /docs/ and doesn't have dynamic indicators, rewrite the host
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      // For docs.example.com format
      url = `https://docs.${domain}${path}`;
    }
    
    return url;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  // Try to match the pattern
  const match = value.match(dateRegex);
  
  // If no match, return 'N/A'
  if (!match) {
    return 'N/A';
  }
  
  // Extract month, day, and year
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Check for basic date validity (considering different month lengths)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check if day is valid for the month
  if (day > daysInMonth[month - 1]) {
    // Check for leap year if February and day is 29
    if (month === 2 && day === 29) {
      // Simple leap year check (divisible by 4, but not by 100 unless divisible by 400)
      const yearNum = parseInt(year, 10);
      const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
      if (!isLeapYear) {
        return 'N/A';
      }
    } else {
      return 'N/A';
    }
  }
  
  // Return the year if everything is valid
  return year;
}
