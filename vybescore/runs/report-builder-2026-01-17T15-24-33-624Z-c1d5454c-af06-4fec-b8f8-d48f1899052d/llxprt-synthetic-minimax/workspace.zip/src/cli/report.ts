#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { createWriteStream } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../types/interfaces.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script name
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (arg === '--format' && argv[i + 1]) {
      args.format = argv[i + 1];
      i++; // Skip next since it's the value
    } else if (arg === '--output' && argv[i + 1]) {
      args.outputPath = argv[i + 1];
      i++; // Skip next since it's the value
    } else if (!arg.startsWith('--')) {
      // This should be the data file
      if (!args.dataFile) {
        args.dataFile = arg;
      }
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Missing data file argument');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing --format argument');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format: ${args.format}`);
    process.exit(1);
  }
}

function readAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${i + 1} missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry ${i + 1} missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON in data file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to read or parse data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      // This should never happen due to validation
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      const stream = createWriteStream(outputPath);
      stream.write(content);
      stream.end();
    } catch (error) {
      console.error(`Error: Failed to write output to file: ${outputPath}`);
      process.exit(1);
    }
  } else {
    // Write to stdout
    process.stdout.write(content);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const data = readAndValidateData(args.dataFile);
  const report = renderReport(data, args.format, args.includeTotals);
  
  writeOutput(report, args.outputPath);
}

// Run the CLI
main();
