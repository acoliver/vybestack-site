/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'function') return equal
  return (lhs: T, rhs: T) => lhs === rhs
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Track observers of this computed value internally
  const observers = new Set<Observer<T>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // When this computed value is being updated, we need to:
      // 1. Make ourselves the active observer so accessed inputs register us as dependent
      // 2. Re-run the computation to establish new dependencies
      // 3. Update our value if it changed
      // 4. Notify our own observers if we changed
      
      const newValue = updateFn(prevValue)
      
      // Check if value actually changed using equality function
      if (equalFn && o.value !== undefined && equalFn(o.value, newValue)) {
        return o.value
      }
      
      o.value = newValue
      
      // Notify all observers of this computed value
      if (observers.size > 0) {
        const observersToNotify = Array.from(observers)
        for (const observer of observersToNotify) {
          updateObserver(observer)
        }
      }
      
      return o.value
    },
  }

  // Compute initial value by running the update function with this observer as active
  // This will track dependencies accessed during computation
  updateObserver(o)

  // Return a getter that returns the cached value and establishes dependency tracking
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    // If we're being accessed by another observer (computed or callback),
    // we need to establish the dependency relationship by tracking that observer
    if (currentObserver) {
      observers.add(currentObserver as Observer<T>)
    }
    
    return o.value!
  }

  return getter
}