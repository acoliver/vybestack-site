import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvinceRegion: string;
    postalCode: string;
    country: string;
    email: string;
    phoneNumber: string;
}

interface ValidationError {
    field: string;
    message: string;
}

let db: Database | null = null;

async function initDatabase(): Promise<Database> {
    const SQL = await initSqlJs({
        locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const fs = await import('fs');
    
    let database;
    if (fs.existsSync(dbPath)) {
        const dbBuffer = fs.readFileSync(dbPath);
        database = new SQL.Database(dbBuffer);
    } else {
        database = new SQL.Database();
        const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
        database.exec(schema);
    }

    return database;
}

function validateFormData(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
        'firstName', 'lastName', 'streetAddress', 'city', 
        'stateProvinceRegion', 'postalCode', 'country', 'email', 'phoneNumber'
    ];

    requiredFields.forEach(field => {
        if (!data[field]?.trim()) {
            errors.push({
                field,
                message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
            });
        }
    });

    // Email validation
    if (data.email && data.email.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            errors.push({ field: 'email', message: 'Please enter a valid email address' });
        }
    }

    // Phone validation (international format)
    if (data.phoneNumber && data.phoneNumber.trim()) {
        const phoneRegex = /^\+?[\d\s()-]+$/;
        if (!phoneRegex.test(data.phoneNumber)) {
            errors.push({ field: 'phoneNumber', message: 'Please enter a valid phone number' });
        }
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && data.postalCode.trim()) {
        const postalRegex = /^[a-zA-Z0-9\s-]+$/;
        if (!postalRegex.test(data.postalCode)) {
            errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
        }
    }

    return errors;
}

async function saveDatabase(): Promise<void> {
    if (!db) return;
    
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const fs = await import('fs');
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    const dbBuffer = db.export();
    fs.writeFileSync(dbPath, Buffer.from(dbBuffer));
}

function setupGracefulShutdown() {
    process.on('SIGTERM', async () => {
        console.log('Received SIGTERM, shutting down gracefully...');
        if (db) {
            db.close();
        }
        process.exit(0);
    });

    process.on('SIGINT', async () => {
        console.log('Received SIGINT, shutting down gracefully...');
        if (db) {
            db.close();
        }
        process.exit(0);
    });
}

async function startServer() {
    try {
        // Initialize database
        db = await initDatabase();
        console.log('Database initialized successfully');

        const app = express();
        const PORT = process.env.PORT || 3535;

        // Middleware
        app.use(express.urlencoded({ extended: true }));
        app.use(express.json());
        app.use('/public', express.static(path.join(__dirname, '..', 'public')));
        app.set('view engine', 'ejs');
        app.set('views', path.join(__dirname, '..', 'views'));

        // Routes
        app.get('/', (req: Request, res: Response) => {
            res.render('form', { 
                errors: [], 
                formData: {} as Partial<FormData>,
                title: 'Contact Us'
            });
        });

        app.post('/submit', async (req: Request, res: Response) => {
            const formData: FormData = {
                firstName: req.body.firstName || '',
                lastName: req.body.lastName || '',
                streetAddress: req.body.streetAddress || '',
                city: req.body.city || '',
                stateProvinceRegion: req.body.stateProvinceRegion || '',
                postalCode: req.body.postalCode || '',
                country: req.body.country || '',
                email: req.body.email || '',
                phoneNumber: req.body.phoneNumber || ''
            };

            const errors = validateFormData(formData);

            if (errors.length > 0) {
                return res.status(400).render('form', {
                    errors,
                    formData,
                    title: 'Contact Us'
                });
            }

            try {
                if (!db) throw new Error('Database not initialized');

                const stmt = db.prepare(`
                    INSERT INTO submissions (
                        first_name, last_name, street_address, city, 
                        state_province_region, postal_code, country, 
                        email, phone_number
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `);

                stmt.run([
                    formData.firstName,
                    formData.lastName,
                    formData.streetAddress,
                    formData.city,
                    formData.stateProvinceRegion,
                    formData.postalCode,
                    formData.country,
                    formData.email,
                    formData.phoneNumber
                ]);

                stmt.free();
                await saveDatabase();

                res.redirect(302, '/thank-you');
            } catch (error) {
                console.error('Database error:', error);
                res.status(500).render('form', {
                    errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
                    formData,
                    title: 'Contact Us'
                });
            }
        });

        app.get('/thank-you', (req: Request, res: Response) => {
            res.render('thank-you', { title: 'Thank You!' });
        });

        // Error handler
        app.use((err: Error, req: Request, res: Response) => {
            console.error('Unhandled error:', err);
            res.status(500).render('form', {
                errors: [{ field: 'general', message: 'An unexpected error occurred.' }],
                formData: {} as Partial<FormData>,
                title: 'Contact Us'
            });
        });

        setupGracefulShutdown();

        app.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
        });

    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

startServer();