import initSqlJs, { SqlJsStatic, Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

class DatabaseManager {
  private sql: SqlJsStatic | null = null;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    if (this.sql && this.db) {
      return; // Already initialized
    }

    this.sql = await initSqlJs();
    await this.loadOrCreateDatabase();
  }

  private async loadOrCreateDatabase(): Promise<void> {
    try {
      // Try to load existing database
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sql!.Database(dbBuffer);
    } catch (error) {
      // Create new database if file doesn't exist
      this.db = new this.sql!.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = fs.readFileSync(
      path.join(process.cwd(), 'db', 'schema.sql'),
      'utf8'
    );
    
    this.db.exec(schema);
  }

  async saveSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0].values[0][0] as number;

    stmt.free();
    await this.saveToDisk();
    return id;
  }

  private async saveToDisk(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const binaryDb = this.db.export();
    fs.writeFileSync(this.dbPath, binaryDb);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();