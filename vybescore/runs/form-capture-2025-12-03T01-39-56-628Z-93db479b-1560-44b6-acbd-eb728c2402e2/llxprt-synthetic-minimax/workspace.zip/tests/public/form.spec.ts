import { describe, expect, it, afterAll } from 'vitest';

let server: unknown;

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server) {
    (server as { close: () => void }).close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    expect(true).toBe(true);
  });
});
