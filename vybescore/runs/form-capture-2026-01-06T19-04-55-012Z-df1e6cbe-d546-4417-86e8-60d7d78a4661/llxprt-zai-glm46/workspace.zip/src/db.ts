import fs from 'node:fs';
import path from 'node:path';
import initSqlJs, { Database } from 'sql.js';

let db: Database | null = null;
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

export async function initDb(): Promise<void> {
  const SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
    console.log('Loaded existing database from', DB_PATH);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    await saveDb();
    console.log('Created new database at', DB_PATH);
  }
}

export async function saveDb(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function closeDb(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}

export interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export async function insertSubmission(data: SubmissionData): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province_region,
      postal_zip_code, country, email, phone_number
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.bind([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvinceRegion,
    data.postalZipCode,
    data.country,
    data.email,
    data.phoneNumber,
  ]);

  stmt.step();
  stmt.free();

  await saveDb();
}

export function getDb(): Database | null {
  return db;
}
