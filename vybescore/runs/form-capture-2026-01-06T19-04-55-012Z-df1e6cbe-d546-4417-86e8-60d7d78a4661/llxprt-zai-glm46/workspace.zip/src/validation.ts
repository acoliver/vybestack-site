export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

export interface FormInput {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhoneNumber(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[\d\s\-()+]+$/;
  return phone.length > 0 && phoneRegex.test(phone);
}

export function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric strings with spaces and dashes
  const postalRegex = /^[\w\s-]+$/;
  return postal.trim().length > 0 && postalRegex.test(postal);
}

export function validateForm(input: FormInput): ValidationResult {
  const errors: Record<string, string> = {};

  // Check required fields
  if (!input.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  if (!input.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  if (!input.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  if (!input.city.trim()) {
    errors.city = 'City is required';
  }
  if (!input.stateProvinceRegion.trim()) {
    errors.stateProvinceRegion = 'State / Province / Region is required';
  }
  if (!input.postalZipCode.trim()) {
    errors.postalZipCode = 'Postal / Zip code is required';
  } else if (!validatePostalCode(input.postalZipCode)) {
    errors.postalZipCode = 'Postal / Zip code must be alphanumeric';
  }
  if (!input.country.trim()) {
    errors.country = 'Country is required';
  }
  if (!input.email.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(input.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (!input.phoneNumber.trim()) {
    errors.phoneNumber = 'Phone number is required';
  } else if (!validatePhoneNumber(input.phoneNumber)) {
    errors.phoneNumber = 'Phone number can only contain digits, spaces, parentheses, dashes, and +';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}
