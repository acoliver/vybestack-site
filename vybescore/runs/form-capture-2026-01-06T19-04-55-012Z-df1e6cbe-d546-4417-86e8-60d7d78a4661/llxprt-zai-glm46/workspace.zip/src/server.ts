import express from 'express';
import { createServer } from 'http';
import { initDb, closeDb } from './db.js';
import { indexRouter } from './routes/index.js';
import { submitRouter } from './routes/submit.js';
import { thankYouRouter } from './routes/thank-you.js';

const app = express();
const server = createServer(app);
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', 'src/views');

// Routes
app.use('/', indexRouter);
app.use('/submit', submitRouter);
app.use('/thank-you', thankYouRouter);

// Graceful shutdown handler
async function shutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}, closing server gracefully...`);
  server.close(() => {
    console.log('HTTP server closed');
  });

  try {
    await closeDb();
    console.log('Database closed');
    process.exit(0);
  } catch (error) {
    console.error('Error closing database:', error);
    process.exit(1);
  }
}

// Handle shutdown signals
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Start server
async function start(): Promise<void> {
  try {
    await initDb();
    console.log('Database initialized');

    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

export { app, server };
