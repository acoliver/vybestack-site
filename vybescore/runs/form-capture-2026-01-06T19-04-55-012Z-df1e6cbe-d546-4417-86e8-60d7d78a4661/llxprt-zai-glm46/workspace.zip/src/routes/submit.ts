import { Router, Request, Response } from 'express';
import { FormInput, validateForm } from '../validation.js';
import { insertSubmission } from '../db.js';

const router = Router();

interface SubmittedForm extends FormInput {
  'first-name': string;
  'last-name': string;
  'street-address': string;
  'state-province-region': string;
  'postal-zip-code': string;
  'phone-number': string;
}

router.post('/', async (req: Request, res: Response): Promise<void> => {
  const body = req.body as SubmittedForm;

  const formData: FormInput = {
    firstName: body['first-name'] || '',
    lastName: body['last-name'] || '',
    streetAddress: body['street-address'] || '',
    city: body.city || '',
    stateProvinceRegion: body['state-province-region'] || '',
    postalZipCode: body['postal-zip-code'] || '',
    country: body.country || '',
    email: body.email || '',
    phoneNumber: body['phone-number'] || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    res.status(400).render('index', {
      errors: validation.errors,
      formData,
    });
    return;
  }

  try {
    await insertSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('index', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      formData,
    });
  }
});

export { router as submitRouter };
