/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a Set for faster lookup of exceptions
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Split text into words and filter manually
  const words = text.split(/\s+/);
  const result: string[] = [];
  
  words.forEach(word => {
    const cleanWord = word.toLowerCase();
    if (cleanWord.startsWith(prefix.toLowerCase()) && !exceptionSet.has(cleanWord)) {
      result.push(word);
    }
  });
  
  // Remove duplicates
  return [...new Set(result)];
}



/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const result: string[] = [];
  
  // Split text into words
  const words = text.split(/\s+/);
  
  words.forEach(word => {
    // Look for token preceded by digit within the word
    const tokenIndex = word.indexOf(token);
    if (tokenIndex > 0) {
      const charBefore = word[tokenIndex - 1];
      if (/\d/.test(charBefore)) {
        result.push(word);
      }
    }
  });
  
  return result;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase, one lowercase, one digit, one symbol
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/\d/.test(value)) return false;
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences (like 'abab', '1212', etc.)
  // Check for patterns of length 2-4 that repeat consecutively
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const pattern = value.substr(i, len);
      const nextPattern = value.substr(i + len, len);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that includes shorthand formats but excludes IPv4
  const IPV6_REGEX = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|(?:\b[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b|(?:\b[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b|(?:\b[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b|(?:\b[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b|\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\b/;
  
  return IPV6_REGEX.test(value);
}
