export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const EMAIL_REGEX = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Quick pre-check for common invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  if (value.includes('_@') || value.includes('@_')) {
    return false;
  }
  
  return EMAIL_REGEX.test(value);
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Remove leading +1 if present
  let phoneNumber = digits;
  if (phoneNumber.startsWith('11')) {
    phoneNumber = phoneNumber.slice(2);
  } else if (phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Should be exactly 10 digits for US numbers
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Final validation with regex for formatting
  const US_PHONE_REGEX = /^(?:\+1[\s.-]?)?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  return US_PHONE_REGEX.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading 1-9
 * - Subscriber: 6-8 digits after area code
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation.
  const normalized = value.replace(/[\s-]/g, '');
  
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  let remaining = normalized;
  
  // Check and strip country code +54
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check trunk prefix 0 (required if no country code)
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }
  
  // If there is no country code, trunk prefix is required.
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Extract area code (2-4 digits, must not start with 0)
  // Use regex to find area code and subscriber.
  const regex = /^([1-9]\d{1,3})(\d{6,8})$/;
  const match = remaining.match(regex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code must be 2-4 digits and not start with 0.
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber must be 6-8 digits.
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Simple validation based on the parsed components
  return true;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and 'X Æ A-12' style names.
 */
export function isValidName(value: string): boolean {
  // Names should be at least 2 characters and contain only allowed characters
  if (!value || value.trim().length < 2) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols  
  // eslint-disable-next-line no-misleading-character-class
  const NAME_REGEX = /^[A-Za-zÀ-ÿ\u0300-\u036f\-'\s]+$/;
  
  if (!NAME_REGEX.test(value)) {
    return false;
  }
  
  // Additional checks for obviously invalid patterns
  // Reject names that look like technical identifiers (too many special chars)
  const specialCharCount = (value.match(/['-]/g) || []).length;
  if (specialCharCount > 2) {
    return false;
  }
  
  // Reject names with consecutive apostrophes or hyphens
  if (value.includes("'") && value.includes("''")) {
    return false;
  }
  if (value.includes('-') && value.includes('--')) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[A-Za-zÀ-ž]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const sanitized = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(sanitized)) {
    return false;
  }
  
  // Check prefix and length for major card types
  const visa = /^4(\d{12}|\d{15})$/;
  const mastercard = /^5[1-5]\d{14}$/;
  const amex = /^3[47]\d{13}$/;
  
  if (!visa.test(sanitized) && !mastercard.test(sanitized) && !amex.test(sanitized)) {
    return false;
  }
  
  // Luhn checksum algorithm
  return runLuhnCheck(sanitized);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
