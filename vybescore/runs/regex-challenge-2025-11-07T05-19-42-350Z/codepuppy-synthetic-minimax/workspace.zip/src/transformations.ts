/**
 * Capitalizes the first character of each sentence.
 * After .?! punctuation, ensures exactly one space between sentences,
 * collapses extra spaces, and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Then, ensure proper spacing after sentence endings
  normalized = normalized.replace(/([.?!])\s*([A-Za-z])/g, '$1 $2');
  
  // Capitalize first character after sentence boundaries
  normalized = normalized.replace(/(^|[.?!]\s+)([a-z])/g, (match, boundary, char) => {
    return boundary + char.toUpperCase();
  });
  
  // Handle the very first character if the text starts with a letter
  if (normalized.length > 0 && /^[a-z]/.test(normalized[0])) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Special handling for common abbreviations to prevent over-capitalization
  const abbreviations = /\b(mr|ms|mrs|dr|prof|sr|jr|st|ave|blvd|rd|etc|e\.g|i\.e|vs|etc)\./gi;
  normalized = normalized.replace(abbreviations, (match) => match.toLowerCase());
  
  return normalized.trim();
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https and common domain patterns
  const URL_REGEX = /\bhttps?:\/\/[^\s<>"'(){}[\]]+(?![.,;:!?)])(?!\w)/gi;
  
  const matches = text.match(URL_REGEX) || [];
  
  // Trim trailing punctuation if present (more aggressive cleanup)
  return matches.map(url => url.replace(/[.,;:!?()[\]{}"']+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to complex rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    // Match http://example.com/... patterns
    /\bhttp:\/\/([^\/]+)(\/[^\s]*)?/gi,
    (match, host, path) => {
      const fullPath = path || '';
      
      // Check if we should skip host rewrite
      const shouldSkipHostRewrite = 
        fullPath.includes('/cgi-bin') ||
        fullPath.includes('?') ||
        fullPath.includes('&') ||
        fullPath.includes('=') ||
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(fullPath);
      
      // Always upgrade to https
      let result = 'https://' + host;
      
      // Determine if we need to rewrite the host
      if (!shouldSkipHostRewrite && fullPath.startsWith('/docs/')) {
        // Rewrite host to docs.example.com
        result = 'https://docs.' + host;
        // Keep the path as is (starting with /docs/)
        result += fullPath;
      } else {
        // Just upgrade scheme and preserve path
        result += fullPath;
      }
      
      return result;
    }
  );
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const DATE_REGEX = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(DATE_REGEX);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day against month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  let maxDay = daysInMonth[month - 1];
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    maxDay = isLeapYear ? 29 : 28;
  }
  
  if (day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
