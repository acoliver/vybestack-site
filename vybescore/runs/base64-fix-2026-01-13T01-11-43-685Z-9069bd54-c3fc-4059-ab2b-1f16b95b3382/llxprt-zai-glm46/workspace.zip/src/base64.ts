const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!trimmed) {
    throw new Error('Input is empty');
  }

  // Validate Base64 format - only allow valid characters and proper padding
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for proper padding placement (padding can only appear at the end)
  const nonPaddingLength = trimmed.replace(/=+$/, '').length;
  if (nonPaddingLength < trimmed.length - 2) {
    throw new Error('Invalid Base64 input: padding can only appear at the end');
  }

  // Check for invalid padding (more than 2 padding chars)
  const paddingMatch = trimmed.match(/=+$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');

    // Check if the buffer is all zeros for non-empty input, which indicates likely invalid input
    // (except for inputs that legitimately decode to zeros, which is rare for UTF-8 text)
    if (buffer.length > 0 && buffer.every(byte => byte === 0)) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
