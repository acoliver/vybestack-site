/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Store all callbacks to ensure they're notified when dependencies change
const allCallbacks = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies and run initial callback
  updateObserver(observer)
  allCallbacks.add(observer as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from global callbacks
    allCallbacks.delete(observer as Observer<unknown>)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}

// Function to notify all callbacks (called by subjects when they change)
export function notifyAllCallbacks(): void {
  for (const callback of allCallbacks) {
    updateObserver(callback)
  }
}