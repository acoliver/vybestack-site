/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

function getEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (equal === false) return undefined
  if (equal === true) return defaultEqual
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const _equalFn = getEqualFn(equal)
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  return (): T => {
    // Always re-run computation when called
    updateObserver(o)
    return o.value!
  }
}