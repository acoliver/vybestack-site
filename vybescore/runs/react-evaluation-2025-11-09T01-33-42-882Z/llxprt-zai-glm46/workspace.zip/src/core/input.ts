/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { notifyAllCallbacks } from './callback.js'

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

function getEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (equal === false) return undefined
  if (equal === true) return defaultEqual
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: getEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.equalFn ? !s.equalFn(s.value, nextValue) : s.value !== nextValue
    if (shouldUpdate) {
      s.value = nextValue
      notifyObservers(s)
      notifyAllCallbacks()
    }
    return s.value
  }

  return [read, write]
}