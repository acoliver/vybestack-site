import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse and validate numeric parameters
    let page: number | undefined;
    let limit: number | undefined;
    
    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || !Number.isInteger(parsedPage)) {
        return res.status(400).json({ error: 'Page parameter must be a valid integer' });
      }
      page = parsedPage;
    }
    
    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || !Number.isInteger(parsedLimit)) {
        return res.status(400).json({ error: 'Limit parameter must be a valid integer' });
      }
      limit = parsedLimit;
    }

    const validation = validatePaginationParams(page, limit);
    
    if (validation.errors.length > 0) {
      return res.status(400).json({ error: validation.errors.join(', ') });
    }
    
    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
