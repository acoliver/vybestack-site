import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });
});

describe('pagination functionality', () => {
  async function setupApp() {
    const db = await createDatabase();
    const app = await createApp(db);
    return { db, app };
  }

  describe('basic pagination', () => {
    it('returns default page 1 with limit 5', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(5);
      expect(response.body.items).toHaveLength(5);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
    });

    it('returns page 2 correctly', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?page=2&limit=5');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(2);
      expect(response.body.limit).toBe(5);
      expect(response.body.items).toHaveLength(5);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
      
      // Verify items are different from page 1
      const page1Response = await request(app).get('/inventory?page=1&limit=5');
      const page1Ids = page1Response.body.items.map((item: { id: number }) => item.id);
      const page2Ids = response.body.items.map((item: { id: number }) => item.id);
      expect(page1Ids).not.toEqual(page2Ids);
    });

    it('returns last page correctly', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?page=3&limit=5');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(3);
      expect(response.body.limit).toBe(5);
      expect(response.body.items).toHaveLength(5); // 15 total items, 3 pages of 5 each
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(false);
    });

    it('returns empty page when requesting beyond available data', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?page=4&limit=5');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(4);
      expect(response.body.limit).toBe(5);
      expect(response.body.items).toHaveLength(0);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(false);
    });
  });

  describe('input validation', () => {
    it('rejects non-numeric page parameter', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?page=abc');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Page parameter must be a valid integer');
    });

    it('rejects non-numeric limit parameter', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?limit=xyz');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Limit parameter must be a valid integer');
    });

    it('rejects zero or negative page parameter', async () => {
      const { app } = await setupApp();
      
      const negativeResponse = await request(app).get('/inventory?page=-1');
      expect(negativeResponse.status).toBe(400);
      expect(negativeResponse.body.error).toContain('Page must be a positive integer');
      
      const zeroResponse = await request(app).get('/inventory?page=0');
      expect(zeroResponse.status).toBe(400);
      expect(zeroResponse.body.error).toContain('Page must be a positive integer');
    });

    it('rejects zero or negative limit parameter', async () => {
      const { app } = await setupApp();
      
      const negativeResponse = await request(app).get('/inventory?limit=-5');
      expect(negativeResponse.status).toBe(400);
      expect(negativeResponse.body.error).toContain('Limit must be a positive integer');
      
      const zeroResponse = await request(app).get('/inventory?limit=0');
      expect(zeroResponse.status).toBe(400);
      expect(zeroResponse.body.error).toContain('Limit must be a positive integer');
    });

    it('rejects excessive page parameter', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?page=1001');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Page cannot exceed 1000');
    });

    it('rejects excessive limit parameter', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?limit=101');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Limit cannot exceed 100');
    });

    it('handles decimal parameters correctly', async () => {
      const { app } = await setupApp();
      
      const pageResponse = await request(app).get('/inventory?page=1.5');
      expect(pageResponse.status).toBe(400);
      expect(pageResponse.body.error).toContain('Page parameter must be a valid integer');
      
      const limitResponse = await request(app).get('/inventory?limit=3.7');
      expect(limitResponse.status).toBe(400);
      expect(limitResponse.body.error).toContain('Limit parameter must be a valid integer');
    });
  });

  describe('pagination edge cases', () => {
    it('handles custom limit correctly', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?limit=3');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(3);
      expect(response.body.items).toHaveLength(3);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
    });

    it('handles limit greater than total items', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?limit=20');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(20);
      expect(response.body.items).toHaveLength(15); // All items
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(false);
    });

    it('handles page and limit combinations correctly', async () => {
      const { app } = await setupApp();
      const response = await request(app).get('/inventory?page=2&limit=3');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(2);
      expect(response.body.limit).toBe(3);
      expect(response.body.items).toHaveLength(3);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
      
      // Verify correct items (should be items 4, 5, 6)
      const itemIds = response.body.items.map((item: { id: number }) => item.id);
      expect(itemIds).toEqual([4, 5, 6]);
    });
  });
});
