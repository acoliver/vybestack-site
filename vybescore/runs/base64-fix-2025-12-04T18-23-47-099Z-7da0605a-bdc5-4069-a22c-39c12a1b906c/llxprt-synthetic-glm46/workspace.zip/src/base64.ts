/**
 * Encode plain text to standard Base64 with proper padding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

// Constants to avoid string duplication
const PADDING_REGEX = /=+$/;
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Decode Base64 text to plain text.
 * Accepts valid Base64 input with or without padding.
 */
export function decode(input: string): string {
  try {
    const buffer = Buffer.from(input, 'base64');
    const decoded = buffer.toString('utf8');
    
    // Check if the decoded result contains any invalid UTF-8 sequences
    // Buffer.toString() will replace invalid sequences with replacement characters,
    // so we check for those as well
    if (decoded.includes('\uFFFD')) {
      throw new Error('Invalid UTF-8 sequence in Base64 input');
    }
    
    // Now validate that the input was actually valid Base64
    // We need to re-encode and compare to detect invalid padding or characters
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64');
    
    // Normalize padding for comparison
    const normalizePadding = (str: string): string => {
      return str.replace(PADDING_REGEX, '');
    };
    
    if (normalizePadding(input) !== normalizePadding(reencoded)) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes(INVALID_BASE64_ERROR)) {
      throw error;
    }
    if (error instanceof Error && error.message.includes('Invalid UTF-8 sequence in Base64 input')) {
      throw error;
    }
    throw new Error(INVALID_BASE64_ERROR);
  }
}