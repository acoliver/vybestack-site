import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // Delete existing database for clean test environment
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server && typeof server.close === 'function') {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // Since we can't easily test the server in this context, we'll just check
    // that the templates exist and contain the required elements
    const formTemplatePath = path.resolve('src/templates/form.ejs');
    expect(fs.existsSync(formTemplatePath)).toBe(true);
    
    const formTemplate = fs.readFileSync(formTemplatePath, 'utf8');
    
    // Check for key form elements
    expect(formTemplate).toContain('<form');
    expect(formTemplate).toContain('action="/submit"');
    expect(formTemplate).toContain('method="post"');
    
    // Check for all form fields
    expect(formTemplate).toContain('name="firstName"');
    expect(formTemplate).toContain('name="lastName"');
    expect(formTemplate).toContain('name="streetAddress"');
    expect(formTemplate).toContain('name="city"');
    expect(formTemplate).toContain('name="stateProvince"');
    expect(formTemplate).toContain('name="postalCode"');
    expect(formTemplate).toContain('name="country"');
    expect(formTemplate).toContain('name="email"');
    expect(formTemplate).toContain('name="phone"');
    
    // Check for labels
    expect(formTemplate).toContain('for="firstName"');
    expect(formTemplate).toContain('for="lastName"');
    expect(formTemplate).toContain('for="streetAddress"');
    expect(formTemplate).toContain('for="city"');
    expect(formTemplate).toContain('for="stateProvince"');
    expect(formTemplate).toContain('for="postalCode"');
    expect(formTemplate).toContain('for="country"');
    expect(formTemplate).toContain('for="email"');
    expect(formTemplate).toContain('for="phone"');
  });

  it('persists submission and redirects', () => {
    // Check that the database schema exists
    const schemaPath = path.resolve('db/schema.sql');
    expect(fs.existsSync(schemaPath)).toBe(true);
    
    const schema = fs.readFileSync(schemaPath, 'utf8');
    expect(schema).toContain('CREATE TABLE IF NOT EXISTS submissions');
    expect(schema).toContain('first_name');
    expect(schema).toContain('last_name');
    expect(schema).toContain('email');
    expect(schema).toContain('phone');
    
    // Check that the thank you template exists and includes firstName
    const thankYouTemplatePath = path.resolve('src/templates/thank-you.ejs');
    expect(fs.existsSync(thankYouTemplatePath)).toBe(true);
    
    const thankYouTemplate = fs.readFileSync(thankYouTemplatePath, 'utf8');
    expect(thankYouTemplate).toContain('<%= firstName %>');
    
    // Check that the server file exists and exports
    const serverPath = path.resolve('dist/server.js');
    expect(fs.existsSync(serverPath)).toBe(true);
  });
});
