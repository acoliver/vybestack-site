import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// @ts-expect-error - sql.js doesn't have proper TypeScript declarations
import initSqlJs from 'sql.js';

// Define Database interface for sql.js
interface Database {
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string): unknown[];
  export(): Uint8Array;
  close(): void;
}

// Define initSqlJs interface
declare function initSqlJs(): Promise<{ Database: new (data?: Uint8Array) => Database }>

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
const port = process.env.PORT || 3000;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Initialize SQLite database
let db: Database | null = null;
async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database if it exists
    let databaseBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const data = fs.readFileSync(dbPath);
      databaseBuffer = new Uint8Array(data);
    }
    
    db = new SQL.Database(databaseBuffer || undefined);
    
    // Read and execute schema
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes with spaces
  const postalCodeRegex = /^[\dA-Za-z\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Validate form data
function validateForm(data: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!data[field] || data[field]?.trim() === '') {
      switch (field) {
        case 'firstName': errors.push('First name is required'); break;
        case 'lastName': errors.push('Last name is required'); break;
        case 'streetAddress': errors.push('Street address is required'); break;
        case 'city': errors.push('City is required'); break;
        case 'stateProvince': errors.push('State / Province / Region is required'); break;
        case 'postalCode': errors.push('Postal / Zip code is required'); break;
        case 'country': errors.push('Country is required'); break;
        case 'email': errors.push('Email is required'); break;
        case 'phone': errors.push('Phone number is required'); break;
      }
    }
  });
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = req.body;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const submission: Submission = {
      first_name: formData.firstName!,
      last_name: formData.lastName!,
      street_address: formData.streetAddress!,
      city: formData.city!,
      state_province: formData.stateProvince!,
      postal_code: formData.postalCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!
    };
    
    db.run(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    // Save database after insert
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to display the first name
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    const result = db.exec('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
    // @ts-expect-error - sql.js exec doesn't have proper type definitions
    const firstName = result[0]?.values[0]?.[0] || 'Friend';
    res.render('thank-you', { firstName });
  } catch (error) {
    console.error('Error fetching submission:', error);
    res.render('thank-you', { firstName: 'Friend' });
  }
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Export server and app for testing
  // @ts-expect-error - Setting global variables for testing
  global.server = server;
  // @ts-expect-error - Setting global variables for testing
  global.app = app;
  
  // Handle graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    
    server.close(() => {
      console.log('Express server closed');
      
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
    
    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
