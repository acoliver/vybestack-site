import express, { Request, Response, Application } from 'express';
import * as path from 'path';
import { DatabaseManager } from './database';
import { validateFormData, renderFormWithErrors, FormData } from './validation';

const app: Application = express();
const PORT: number = parseInt(process.env.PORT || '3535', 10);

let dbManager: DatabaseManager;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    formData: {},
    errors: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateFormData(formData);

    if (Object.keys(errors).length > 0) {
      renderFormWithErrors(res, formData, errors);
      return;
    }

    // Transform form data to database submission format
    const submission = {
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province_region: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone_number: formData.phone
    };

    await dbManager.insertSubmission(submission);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown handling
const gracefulShutdown = async (): Promise<void> => {
  console.log('Shutting down gracefully...');
  if (dbManager) {
    await dbManager.close();
  }
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Server startup
async function startServer(): Promise<void> {
  try {
    dbManager = new DatabaseManager();
    await dbManager.initialize();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', async () => {
      console.log('Received SIGTERM, shutting down gracefully...');
      server.close(async () => {
        await dbManager.close();
        process.exit(0);
      });
    });

    process.on('SIGINT', async () => {
      console.log('Received SIGINT, shutting down gracefully...');
      server.close(async () => {
        await dbManager.close();
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
