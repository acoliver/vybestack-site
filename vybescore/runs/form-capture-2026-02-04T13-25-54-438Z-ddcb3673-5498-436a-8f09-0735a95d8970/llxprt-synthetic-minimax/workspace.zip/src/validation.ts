export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationErrors {
  [key: string]: string;
}

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePhoneNumber = (phone: string): boolean => {
  // Accept digits, spaces, parentheses, dashes, and a leading @
  const phoneRegex = /^@?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
};

export const validatePostalCode = (postalCode: string): boolean => {
  // Accept alphanumeric strings for international formats
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
};

export const validateFormData = (data: FormData): ValidationErrors => {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) errors.firstName = 'First name is required';
  if (!data.lastName.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city.trim()) errors.city = 'City is required';
  if (!data.stateProvince.trim()) errors.stateProvince = 'State/Province/Region is required';
  if (!data.postalCode.trim()) errors.postalCode = 'Postal code is required';
  if (!data.country.trim()) errors.country = 'Country is required';
  if (!data.email.trim()) errors.email = 'Email is required';
  if (!data.phone.trim()) errors.phone = 'Phone number is required';

  // Format validation (only if field has content)
  if (data.email.trim() && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (data.phone.trim() && !validatePhoneNumber(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  if (data.postalCode.trim() && !validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
};

import { Response } from 'express';

export const renderFormWithErrors = (
  res: Response,
  data: Partial<FormData>,
  errors: ValidationErrors
): void => {
  res.status(400).render('form', {
    formData: data,
    errors: errors,
    title: 'Contact Form - Please Fix Errors'
  });
};