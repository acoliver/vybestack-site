import initSqlJs, { Database as SqlJsDatabase } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
}

interface SqlJsModule {
  Database: new (buffer?: Buffer) => SqlJsDatabase;
}

export class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private dbPath: string;
  private schemaPath: string;
  private sqlJs: SqlJsModule | null = null;

  constructor(dbPath: string = 'data/submissions.sqlite', schemaPath: string = 'db/schema.sql') {
    this.dbPath = dbPath;
    this.schemaPath = schemaPath;
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sqlJs = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load or create database
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        this.db = new this.sqlJs.Database(fileBuffer);
      } else {
        this.db = new this.sqlJs.Database();
        await this.createSchema();
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: Submission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region,
        postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province_region,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone_number
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}