#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';

function parseArgs(): { dataFile: string; format: string; output?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  let dataFile = '';
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    switch (arg) {
      case '--format':
        format = args[++i];
        break;
      case '--output':
        output = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (!arg.startsWith('--') && !dataFile) {
          dataFile = arg;
        }
        break;
    }
  }

  if (!dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, output, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (
    !data ||
    typeof data !== 'object' ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    return false;
  }

  const reportData = data as Record<string, unknown>;
  
  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string' ||
    !Array.isArray(reportData.entries)
  ) {
    return false;
  }

  for (const entry of reportData.entries) {
    if (
      !entry ||
      typeof entry !== 'object' ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      return false;
    }

    const entryData = entry as Record<string, unknown>;
    if (
      typeof entryData.label !== 'string' ||
      typeof entryData.amount !== 'number'
    ) {
      return false;
    }
  }

  return true;
}

function getRenderer(format: string): ReportRenderer {
  switch (format.toLowerCase()) {
    case 'markdown':
      return new MarkdownRenderer();
    case 'text':
      return new TextRenderer();
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

async function main(): Promise<void> {
  try {
    const { dataFile, format, output, includeTotals } = parseArgs();
    
    const filePath = path.resolve(dataFile);
    let data: unknown;
    
    try {
      const fileContent = fs.readFileSync(filePath, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing file "${dataFile}":`, (error as Error).message);
      process.exit(1);
    }

    if (!validateReportData(data)) {
      console.error('Error: Invalid report data format');
      process.exit(1);
    }

    const renderer = getRenderer(format);
    const options: RenderOptions = { includeTotals };
    const result = renderer.render(data, options);

    if (output) {
      fs.writeFileSync(output, result, 'utf-8');
      console.log(`Report written to ${output}`);
    } else {
      process.stdout.write(result);
    }
  } catch (error) {
    console.error('Error:', (error as Error).message);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});
