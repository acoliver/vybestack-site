/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - collapse multiple spaces while preserving single spaces within sentences
  let result = text.replace(/[ \t]+/g, ' ').trim();
  
  // Handle first sentence if it starts with lowercase
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Handle subsequent sentences after punctuation
  // Pattern explanation: ([.?!]) captures sentence ending, followed by lowercase letter
  const sentencePattern = /([.?!])\s*([a-z])/g;
  
  return result.replace(sentencePattern, (match, punctuation, letter) => {
    // Capitalize the first letter after sentence punctuation
    return punctuation + ' ' + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs - http(s):// followed by domain and optional path
  // Capture URLs while removing trailing punctuation
  
  const urlPattern = /(https?:\/\/[^\s<>"'()[\]{}|\\`~;,.!?]+(?:\.[^\s<>"'()[\]{}|\\`~;,.!?]*[a-zA-Z0-9])*)/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation but preserve the URL structure
    url = url.replace(/[.,!?;:"'[\]{}|\\`~]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern explanation:
  // (?!https:) - negative lookahead to avoid matching if already https
  // http:// - match http protocol
  const httpUrlPattern = /(?!https:)http:\/\/[^\s"']+/gi;
  
  return text.replace(httpUrlPattern, (match) => {
    return match.replace(/^http:\/\//, 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern explanation:
  // (?:(?:http:\/\/)|(?:https:\/\/)) - match either http:// or https://
  // ([^\/\s"']+) - capture the host domain
  // ([\/]?) - optional forward slash for root path
  // (.*) - capture the entire path
  
  const urlPattern = /(?:(?:http:\/\/)|(?:https:\/\/))([^/\s"']+)([/]?)(.*)/gi;
  
  return text.replace(urlPattern, (match, host, slash, path) => {
    // Always upgrade to https
    let resultUrl = `https://${host}`;
    
    // Check for dynamic extensions or query indicators in path
    const dynamicExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const combinedPath = slash + path;
    const hasDynamicIndicators = /[?&]/.test(path) || 
                                dynamicExtensions.some(ext => path.includes(ext)) ||
                                path.includes('cgi-bin');
    
    // Check if path begins with /docs/
    const isDocsPath = combinedPath.startsWith('/docs/');
    
    if (isDocsPath && !hasDynamicIndicators) {
      // Rewrite host to docs.example.com
      resultUrl = `https://docs.example.com${slash}${path}`;
    } else {
      // Keep original host, just upgrade scheme
      resultUrl = `https://${host}${slash}${path}`;
    }
    
    return resultUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern explanation:
  // (\d{1,2})\/(\d{1,2})\/(\d{4}) - capture mm, dd, yyyy
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Validate month (1-12)
  const monthNum = parseInt(month, 10);
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  const dayNum = parseInt(day, 10);
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) {
    return 'N/A';
  }
  
  return year;
}
