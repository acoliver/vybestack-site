export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern explanation:
  // Local part: [a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*
  // - Alphanumeric start, followed by optional segments with . _ + -
  // Domain: [a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)* 
  // - Alphanumeric start and end, hyphens allowed but not underscores or dots in domain parts
  const emailPattern = /^[a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional checks for specific validation requirements
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in domain
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domainParts = parts[1].split('.');
  for (const part of domainParts) {
    if (part.length === 0) {
      return false;
    }
    // Check domain parts don't contain underscores
    if (part.includes('_')) {
      return false;
    }
    // Check domain parts don't start or end with hyphen
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to validate length and area codes
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have exactly 10 digits for US numbers (without country code)
  // or 11 digits (with +1 prefix)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Handle country code +1
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
  }
  
  // Pattern for US phone numbers:
  // - Optional country code: \+?1?
  // - Area code: 3 digits, first digit 2-9 (can't be 0 or 1)
  // - Exchange code: 3 digits, first digit 2-9
  // - Line number: 4 digits
  // - Optional separators: space, dash, or parentheses
  const phonePattern = /^\+?1?[\s.-]?\(?([2-9][0-9]{2})\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  
  return phonePattern.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except leading + and spaces/hyphens for analysis
  // But we need to preserve structure for validation
  
  // Strip common formatting characters
  const cleaned = value.replace(/[\s.-]/g, '');
  
  // Pattern breakdown:
  // Option 1: +54 followed by optional 9 (mobile), area code (2-4 digits starting 1-9), subscriber (6-8 digits total after area code)
  // Option 2: 0 (trunk prefix) followed by area code (2-4 digits), subscriber (6-8 digits total after area code)
  
  // Use flexible spacing approach - match patterns with or without spaces
  let isValid = false;
  
  // Pattern that handles flexible spacing
  const patterns = [
    // With country code +54, flexible spacing including subscriber spacing
    /^(?:\+54)\s*([1-9][0-9]{1,2})\s*([0-9]{3}\s*[0-9]{3,5})$/,
    // Without country code but with trunk prefix 0
    /^0\s*([1-9][0-9]{1,2})\s*([0-9]{3}\s*[0-9]{3,5})$/
  ];
  
  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match) {
      const [, areaCode, subscriber] = match;
      
      // Validate area code and subscriber length
      if (areaCode.length >= 2 && areaCode.length <= 4 && 
          subscriber.replace(/\s/g, '').length >= 6 && subscriber.replace(/\s/g, '').length <= 8) {
        isValid = true;
        break;
      }
    }
  }
  
  if (isValid) {
    // Additional check: total digits (excluding + and formatting)
    const totalDigits = cleaned.replace(/^\+/, '');
    if (totalDigits.length < 8 || totalDigits.length > 13) {
      return false;
    }
  }
  
  return isValid;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern breakdown:
  // - Unicode letters (including accents and extended chars) using \p{L}
  // - Allow apostrophes (') and hyphens (-)
  // - Allow spaces for multi-word names
  // - Start and end with unicode letter
  // - Must have at least 2 characters
  
  if (value.length < 2) {
    return false;
  }
  
  // Pattern explanation:
  // ^[p{L}] - starts with unicode letter
  // (?:[\p{L}' -]*[p{L}])* - followed by any combination of letters, apostrophes, hyphens, spaces, ending with letter
  // [p{L}]$ - ends with unicode letter
  const namePattern = /^[\p{L}](?:[\p{L}' -]*[\p{L}])*$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional validation: no consecutive spaces, apostrophes, or hyphens
  if (value.includes('  ')) { // double spaces
    return false;
  }
  
  // Check for consecutive apostrophes or hyphens
  if (value.includes("''") || value.includes('--')) {
    return false;
  }
  
  // Reject obviously non-name patterns
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  if (/[<>"@#$%^&*()[\]{}|\\/`~]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 13 digits (AmEx can be 15, Visa/MasterCard 16)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check card type prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  let isValidCardType = false;
  
  if (digitsOnly.startsWith('4') && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19)) {
    // Visa card
    isValidCardType = true;
  } else if ((digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || digitsOnly.startsWith('53') || 
              digitsOnly.startsWith('54') || digitsOnly.startsWith('55') ||
              (digitsOnly.startsWith('222') && parseInt(digitsOnly.slice(3, 6)) >= 1 && parseInt(digitsOnly.slice(3, 6)) <= 720) ||
              digitsOnly.startsWith('2221') || digitsOnly.startsWith('2222') || digitsOnly.startsWith('2720')) &&
              digitsOnly.length === 16) {
    // MasterCard
    isValidCardType = true;
  } else if ((digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) && digitsOnly.length === 15) {
    // American Express
    isValidCardType = true;
  }
  
  if (!isValidCardType) {
    return false;
  }
  
  // Apply Luhn algorithm
  return runLuhnCheck(digitsOnly);
}
