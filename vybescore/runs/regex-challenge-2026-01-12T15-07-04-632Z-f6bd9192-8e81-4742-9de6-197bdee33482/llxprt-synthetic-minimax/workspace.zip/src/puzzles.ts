/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern explanation:
  // \b - word boundary to match complete words
  // (?!(?:prefix|word)) - negative lookahead to exclude exceptions from matches
  // However, for simplicity, we'll match all words with prefix, then filter exceptions
  
  const wordPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(wordPattern) || [];
  
  // Filter out exception words
  const filteredMatches = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern explanation:
  // (?<!^) - negative lookbehind to exclude beginning of string
  // (?=\d) - positive lookahead to find next digit before token
  // However, we need token to come after digit, so use simpler approach
  
  // Find all positions where token appears
  const results: string[] = [];
  
  // Use regex to find token occurrences
  const tokenRegex = new RegExp(token, 'gi');
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    const matchStart = match.index;
    
    // Check if this is at the beginning of string
    if (matchStart === 0) {
      continue; // Skip matches at string start
    }
    
    // Check character before token
    const prevChar = text[matchStart - 1];
    
    // Check if previous character is a digit
    if (prevChar && /\d/.test(prevChar)) {
      results.push(prevChar + token);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Requirements:
  // - At least 10 characters
  // - One uppercase letter
  // - One lowercase letter
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., 'abab' should fail)
  
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check character requirements
  if (!/[A-Z]/.test(value)) { // one uppercase
    return false;
  }
  
  if (!/[a-z]/.test(value)) { // one lowercase
    return false;
  }
  
  if (!/[0-9]/.test(value)) { // one digit
    return false;
  }
  
  if (!/[!@#$%^&*()[\]{}|\\/`~;,.?<>]/.test(value)) { // one symbol
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., 'abab', 'cdcd', etc.)
  // Pattern explanation: (.)(?:\1){2,} - captures any character followed by same character at least 2 more times
  // This would catch 'abab' patterns where alternating chars repeat
  const alternatingRepeatPattern = /(..)\1/g;
  if (alternatingRepeatPattern.test(value)) {
    return false;
  }
  
  // Also check for simple immediate repetition (e.g., 'aaabbb')
  const simpleRepeatPattern = /(.)\1{2,}/g;
  if (simpleRepeatPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern explanation for IPv6:
  // IPv6 addresses contain hex digits (0-9, a-f, A-F) and colons
  // Shorthand notation uses :: to represent multiple zero groups
  // Must exclude pure IPv4 addresses (which would be caught by simpler patterns)
  
  // First, quickly reject pure IPv4 addresses (if the entire string is IPv4)
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 detection patterns (removed ^ and $ anchors to search within text):
  // 1. Standard IPv6 with colons: groups of hex digits separated by colons
  // 2. Shorthand notation with ::
  // 3. IPv4-mapped IPv6
  
  // Pattern 1: Standard IPv6 with full groups
  const fullIpv6Pattern = /(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{1,4}/;
  
  // Pattern 2: Shorthand IPv6 with ::
  // This matches patterns like ::1, 2001:db8::, ::, etc.
  const shorthandIpv6Pattern = /(?:[a-fA-F0-9]{1,4}:){0,6}::(?:[a-fA-F0-9]{1,4}:){0,6}/;
  
  // Pattern 3: Mixed shorthand with hex groups
  const mixedIpv6Pattern = /(?:[a-fA-F0-9]{1,4}:){0,6}::(?:[a-fA-F0-9]{1,4}:){1,7}/;
  
  // Pattern 4: IPv4-mapped IPv6 (ends with IPv4-style decimal notation)
  const ipv4MappedPattern = /::(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}/i;
  
  // Pattern 5: Single group shorthand (::)
  const singleGroupPattern = /::/;
  
  // Check various IPv6 patterns within the text
  if (fullIpv6Pattern.test(value) || 
      shorthandIpv6Pattern.test(value) || 
      mixedIpv6Pattern.test(value) ||
      ipv4MappedPattern.test(value) ||
      singleGroupPattern.test(value)) {
    
    // Additional validation: ensure this isn't just a URL or domain with colons
    // Look for typical IPv6 characteristics
    
    // Must contain valid hex groups with colons
    const colonCount = (value.match(/:/g) || []).length;
    
    // IPv6 should have at least 2 colons for any meaningful address
    if (colonCount >= 2) {
      // Additional check: reject obvious non-IPv6 patterns
      // Check if it looks like a URL protocol (http://, https://)
      if (value.match(/https?:\/\//)) {
        return false;
      }
      
      // Check if it matches IPv4 format specifically
      if (value.match(/\d+\.\d+\.\d+\.\d+/)) {
        // If it's purely IPv4 (no hex chars), reject
        if (!value.match(/[a-fA-F]/)) {
          return false;
        }
      }
      
      return true;
    }
  }
  
  return false;
}
