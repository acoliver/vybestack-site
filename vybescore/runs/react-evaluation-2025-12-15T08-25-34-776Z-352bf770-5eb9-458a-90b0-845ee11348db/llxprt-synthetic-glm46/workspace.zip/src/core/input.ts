/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  cascadeUpdate,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function isFunction<T>(value: boolean | EqualFn<T>): value is EqualFn<T> {
  return typeof value === 'function'
}

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> = equal === undefined 
    ? defaultEqual 
    : isFunction(equal) 
      ? equal 
      : defaultEqual

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer as Observer<unknown>
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const isEqual = s.equalFn ? s.equalFn(s.value, nextValue) : s.value === nextValue
    if (!isEqual) {
      s.value = nextValue
      cascadeUpdate(s)
    }
    return s.value
  }

  return [read, write]
}
