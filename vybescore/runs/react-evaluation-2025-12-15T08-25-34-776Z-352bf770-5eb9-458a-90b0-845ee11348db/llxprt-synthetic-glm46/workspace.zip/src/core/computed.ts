/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const currentValue = value
  
  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn,
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Cast to Observer<unknown> to avoid using any
      o.observer = observer as Observer<unknown>
    }
    
    // Use updateObserver for reactive tracking
    updateObserver(o)
    return o.value as T
  }
  
  // Initialize if needed
  if (currentValue === undefined) {
    // Check if the update function is a regular function with parameters
    const funcStr = updateFn.toString()
    const hasParameters = funcStr.includes('(') && !funcStr.includes('()')
    
    if (hasParameters) {
      // For functions with parameters, don't initialize them upfront
      // Let them use their default parameters when first accessed
    } else {
      // For functions without parameters, initialize them right away
      try {
        // Prevent tracking during initialization
        const prev = getActiveObserver()
        setActiveObserver(undefined)
        
        o.value = updateFn(undefined)
        
        setActiveObserver(prev)
      } catch (e) {
        // If initialization fails, keep undefined
      }
    }
  }
  
  return getter
}