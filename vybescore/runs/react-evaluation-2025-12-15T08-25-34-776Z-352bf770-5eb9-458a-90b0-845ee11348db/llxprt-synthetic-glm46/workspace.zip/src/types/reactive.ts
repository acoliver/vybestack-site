/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observer?: Observer<unknown>
}

export type SubjectR = {
  name?: string
  observer?: Observer<unknown>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & {
  observer?: Observer<unknown>
}

export let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    // Cascade update to parent observer
    cascadeUpdate(observer)
  } finally {
    activeObserver = previous
  }
}

const updating = new Set<Observer<unknown>>()

export function cascadeUpdate<T>(source: Subject<T> | Observer<T>): void {
  let observer: Observer<unknown> | undefined
  
  // Use type guards to distinguish between Subject and Observer
  if ('equalFn' in source) {
    // It's a Subject
    observer = source.observer
  } else {
    // It's an Observer
    observer = source.observer
  }
  
  if (observer && !updating.has(observer)) {
    updating.add(observer)
    try {
      const prev = activeObserver
      setActiveObserver(undefined)
      const value = observer.updateFn(observer.value)
      if (value !== undefined) {
        observer.value = value
      }
      setActiveObserver(prev)
      cascadeUpdate(observer)
    } finally {
      updating.delete(observer)
    }
  }
}
