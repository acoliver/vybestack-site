import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { app, initializeServer, shutdown } from '../../src/server.js';

describe('Form Capture Application', () => {
  beforeEach(async () => {
    process.env.NODE_ENV = 'test';
    await initializeServer();
  });

  afterEach(async () => {
    await shutdown('SIGTERM');
  });

  describe('GET /', () => {
    it('should render the form page', async () => {
      const response = await request(app).get('/');
      
      expect(response.status).toBe(200);
      expect(response.text).toContain('Friendly Contact Form');
      expect(response.text).toContain('First Name');
      expect(response.text).toContain('Last Name');
      expect(response.text).toContain('Email');
      expect(response.text).toContain('Phone Number');
    });

    it('should include form with correct attributes', async () => {
      const response = await request(app).get('/');
      
      expect(response.text).toMatch(/action="\/submit"/);
      expect(response.text).toMatch(/method="POST"/);
    });

    it('should have properly labeled inputs', async () => {
      const response = await request(app).get('/');
      
      // Check for label/input associations using for and id attributes
      expect(response.text).toMatch(/for="firstName"/);
      expect(response.text).toMatch(/id="firstName"/);
      expect(response.text).toMatch(/name="firstName"/);
      
      expect(response.text).toMatch(/for="lastName"/);
      expect(response.text).toMatch(/id="lastName"/);
      expect(response.text).toMatch(/name="lastName"/);
      
      expect(response.text).toMatch(/for="email"/);
      expect(response.text).toMatch(/id="email"/);
      expect(response.text).toMatch(/name="email"/);
    });
  });

  describe('POST /submit', () => {
    const validFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    it('should redirect to thank-you page on valid submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send(validFormData);
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should accept international phone formats', async () => {
      const testCases = [
        { ...validFormData, phone: '+44 20 7946 0958' },
        { ...validFormData, phone: '+54 9 11 1234-5678' },
        { ...validFormData, phone: '+1 (555) 123-4567' },
        { ...validFormData, phone: '+358 40 123 4567' }
      ];

      for (const testCase of testCases) {
        const response = await request(app)
          .post('/submit')
          .send(testCase);
        
        expect(response.status).toBe(302);
        expect(response.headers.location).toBe('/thank-you');
      }
    });

    it('should accept various postal code formats', async () => {
      const testCases = [
        { ...validFormData, postalCode: 'SW1A 1AA' },
        { ...validFormData, postalCode: 'C1000' },
        { ...validFormData, postalCode: 'B1675' },
        { ...validFormData, postalCode: '12345' },
        { ...validFormData, postalCode: 'A1B 2C3' }
      ];

      for (const testCase of testCases) {
        const response = await request(app)
          .post('/submit')
          .send(testCase);
        
        expect(response.status).toBe(302);
        expect(response.headers.location).toBe('/thank-you');
      }
    });

    describe('Validation - Required Fields', () => {
      it('should return error when firstName is missing', async () => {
        const invalidData = { ...validFormData, firstName: '' };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('First name is required');
      });

      it('should return error when lastName is missing', async () => {
        const invalidData = { ...validFormData, lastName: '' };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('Last name is required');
      });

      it('should return error when email is missing', async () => {
        const invalidData = { ...validFormData, email: '' };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('Email is required');
      });

      it('should return error when email format is invalid', async () => {
        const invalidData = { ...validFormData, email: 'not-an-email' };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('valid email');
      });

      it('should return error when phone number format is invalid', async () => {
        const invalidData = { ...validFormData, phone: 'abc123' };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('valid phone number');
      });

      it('should return error when postal code format is invalid', async () => {
        const invalidData = { ...validFormData, postalCode: '!!!@@@' };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('Postal/Zip code');
      });

      it('should return multiple errors at once', async () => {
        const invalidData = {
          firstName: '',
          lastName: '',
          email: 'invalid-email',
          phone: 'bad-phone',
          streetAddress: '123 Main Street',
          city: 'London',
          stateProvince: 'England',
          postalCode: 'SW1A 1AA',
          country: 'UK'
        };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('First name is required');
        expect(response.text).toContain('Last name is required');
        expect(response.text).toContain('valid email');
      });

      it('should preserve entered values when validation fails', async () => {
        const invalidData = {
          firstName: 'John',
          lastName: '',
          email: 'invalid-email',
          phone: '+1 555-123-4567',
          streetAddress: '123 Main Street',
          city: 'London',
          stateProvince: 'England',
          postalCode: 'SW1A 1AA',
          country: 'UK'
        };
        
        const response = await request(app)
          .post('/submit')
          .send(invalidData);
        
        expect(response.status).toBe(400);
        expect(response.text).toContain('value="John"');
        expect(response.text).toContain('value="+1 555-123-4567"');
      });
    });
  });

  describe('GET /thank-you', () => {
    it('should render thank you page', async () => {
      const response = await request(app).get('/thank-you');
      
      expect(response.status).toBe(200);
      expect(response.text).toContain('Thank You');
      expect(response.text.toLowerCase()).toContain('scam');
      expect(response.text.toLowerCase()).toContain('spam');
    });

    it('should contain humorous text about data usage', async () => {
      const response = await request(app).get('/thank-you');
      
      // Check for mentions of spam/identity theft in a humorous way
      const text = response.text.toLowerCase();
      expect(text).toMatch(/(spam|identity|thief|stranger)/);
    });

    it('should include link back to form', async () => {
      const response = await request(app).get('/thank-you');
      
      expect(response.text).toMatch(/href="\/"/);
    });
  });

  describe('Static Assets', () => {
    it('should serve the styles.css file', async () => {
      const response = await request(app).get('/styles.css');
      
      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toContain('text/css');
      expect(response.text).not.toBe('');
      expect(response.text.length).toBeGreaterThan(100);
    });
  });

  describe('404 Handling', () => {
    it('should return 404 for non-existent routes', async () => {
      const response = await request(app).get('/this-route-does-not-exist');
      
      expect(response.status).toBe(404);
    });
  });
});
