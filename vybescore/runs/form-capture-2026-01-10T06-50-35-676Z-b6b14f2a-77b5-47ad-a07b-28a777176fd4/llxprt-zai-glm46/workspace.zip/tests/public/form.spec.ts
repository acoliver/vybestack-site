import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

import { app, initializeServer, shutdown } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  process.env.NODE_ENV = 'test';
  await initializeServer();
});

afterAll(async () => {
  await shutdown('SIGTERM');
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    expect(app).toBeDefined();
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
