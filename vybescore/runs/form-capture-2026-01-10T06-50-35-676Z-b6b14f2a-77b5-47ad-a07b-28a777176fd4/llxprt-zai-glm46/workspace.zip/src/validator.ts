import type { FormData, FormErrors } from './types.js';

/**
 * Email validation regex (simple but effective)
 */
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Phone validation regex - allows international formats
 * Accepts: digits, spaces, parentheses, dashes, and leading +
 */
const PHONE_REGEX = /^\+?[\d\s()-]+$/;

/**
 * Postal code validation - alphanumeric strings with optional spaces
 * Handles UK formats like "SW1A 1AA" and Argentine formats like "C1000" or "B1675"
 */
const POSTAL_CODE_REGEX = /^[\dA-Za-z]+(?:[\s-][\dA-Za-z]+)*$/;

/**
 * Validates form data and returns errors object (empty if valid)
 */
export function validateForm(data: Partial<FormData>): FormErrors {
  const errors: FormErrors = {};

  // First name - required
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  // Last name - required
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  // Street address - required
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  // City - required
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  // State/Province/Region - required
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  // Postal code - required, alphanumeric
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!POSTAL_CODE_REGEX.test(data.postalCode.trim())) {
    errors.postalCode = 'Postal/Zip code must contain only letters, digits, spaces, and hyphens';
  }

  // Country - required
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  // Email - required, must be valid format
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!EMAIL_REGEX.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone - required, must be valid international format
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!PHONE_REGEX.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading +)';
  }

  return errors;
}

/**
 * Returns true if the form has no validation errors
 */
export function isFormValid(errors: FormErrors): boolean {
  return Object.keys(errors).length === 0;
}
