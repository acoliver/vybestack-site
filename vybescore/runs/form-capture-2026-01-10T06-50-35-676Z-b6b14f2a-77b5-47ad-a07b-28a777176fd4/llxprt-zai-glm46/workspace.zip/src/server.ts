import express, { Request, Response } from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import type { FormData } from './types.js';
import { validateForm, isFormValid } from './validator.js';
import { SubmissionDatabase } from './database.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Initialize Express app
const app = express();
let db: SubmissionDatabase | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(join(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, '..', 'views'));

/**
 * Initialize database on startup
 */
async function initializeServer(): Promise<void> {
  db = new SubmissionDatabase();
  await db.initialize();
}

/**
 * Graceful shutdown handler
 */
export async function shutdown(signal: string): Promise<void> {
  console.log(`\nReceived ${signal}, closing server gracefully...`);
  if (db) {
    db.close();
  }
}

// Handle shutdown signals only when not in test mode
if (process.env.NODE_ENV !== 'test') {
  process.on('SIGTERM', () => shutdown('SIGTERM').then(() => process.exit(0)));
  process.on('SIGINT', () => shutdown('SIGINT').then(() => process.exit(0)));
}

/**
 * GET / - Render the contact form
 */
app.get('/', (req: Request, res: Response): void => {
  // Render form with no initial data or errors
  res.render('index', {
    formData: {},
    errors: {},
    success: false
  });
});

/**
 * POST /submit - Handle form submission
 */
app.post('/submit', (req: Request, res: Response): void => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim() ?? '',
    lastName: req.body.lastName?.trim() ?? '',
    streetAddress: req.body.streetAddress?.trim() ?? '',
    city: req.body.city?.trim() ?? '',
    stateProvince: req.body.stateProvince?.trim() ?? '',
    postalCode: req.body.postalCode?.trim() ?? '',
    country: req.body.country?.trim() ?? '',
    email: req.body.email?.trim() ?? '',
    phone: req.body.phone?.trim() ?? ''
  };

  // Validate form data
  const errors = validateForm(formData);

  // If validation fails, re-render form with errors
  if (!isFormValid(errors)) {
    res.status(400).render('index', {
      formData,
      errors,
      success: false
    });
    return;
  }

  // Valid data - save to database
  if (db) {
    try {
      db.insertSubmission(formData as FormData);
    } catch (err) {
      console.error('Failed to save submission:', err);
      res.status(500).render('index', {
        formData,
        errors: { email: 'Failed to save submission. Please try again.' },
        success: false
      });
      return;
    }
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

/**
 * GET /thank-you - Render thank you page
 */
app.get('/thank-you', (req: Request, res: Response): void => {
  res.render('thank-you');
});

/**
 * 404 handler
 */
app.use((req: Request, res: Response): void => {
  res.status(404).render('404');
});

/**
 * Error handler
 */
app.use((err: Error, req: Request, res: Response): void => {
  console.error('Server error:', err);
  res.status(500).render('error', { error: err.message });
});

/**
 * Start the server
 */
async function start(): Promise<void> {
  await initializeServer();

  app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
}

// Start the server only when not in test mode
if (process.env.NODE_ENV !== 'test') {
  start().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

// Export for testing
export { app, initializeServer };
