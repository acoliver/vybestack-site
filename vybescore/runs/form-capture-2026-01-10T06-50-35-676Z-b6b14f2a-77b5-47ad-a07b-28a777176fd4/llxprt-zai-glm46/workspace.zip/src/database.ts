import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_DIR = join(__dirname, '..', 'data');
const DB_PATH = join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = join(__dirname, '..', 'db', 'schema.sql');

/**
 * Database wrapper class for sql.js
 */
export class SubmissionDatabase {
  private SQL: SqlJsStatic | null = null;
  private db: Database | null = null;
  private dbPath: string;

  constructor(dbPath: string = DB_PATH) {
    this.dbPath = dbPath;
  }

  /**
   * Initialize the database - load existing or create new
   */
  async initialize(): Promise<void> {
    // Initialize sql.js
    this.SQL = await initSqlJs({
      // Locate WASM file - it will be loaded from node_modules
      locateFile: (file) => {
        return join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });

    // Ensure data directory exists
    if (!existsSync(DB_DIR)) {
      mkdirSync(DB_DIR, { recursive: true });
    }

    // Load existing database or create new one
    if (existsSync(this.dbPath)) {
      const buffer = readFileSync(this.dbPath);
      this.db = new this.SQL.Database(buffer);
    } else {
      this.db = new this.SQL.Database();
      await this.runSchema();
    }
  }

  /**
   * Run the schema SQL to create tables
   */
  private async runSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = readFileSync(SCHEMA_PATH, 'utf-8');
    this.db.run(schema);
    this.save();
  }

  /**
   * Save the database to disk
   */
  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    const buffer = Buffer.from(data);
    writeFileSync(this.dbPath, buffer);
  }

  /**
   * Insert a form submission into the database
   */
  insertSubmission(data: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
  }): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.step();
    stmt.free();

    // Save to disk after insert
    this.save();
  }

  /**
   * Close the database connection
   */
  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  /**
   * Get the raw database instance (for testing)
   */
  getDatabase(): Database | null {
    return this.db;
  }
}
