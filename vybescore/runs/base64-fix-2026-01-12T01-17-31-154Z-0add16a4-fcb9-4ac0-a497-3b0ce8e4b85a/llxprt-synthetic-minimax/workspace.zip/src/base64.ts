/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace that might have been added
  const normalized = input.trim();

  validateBase64Input(normalized);
  
  return decodeAndValidate(normalized);
}

function validatePadding(input: string): void {
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    // With padding, the total length should be multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length with padding');
    }
  }
  // No padding is perfectly valid - unpadded base64 is allowed
}

function validateBase64Input(input: string): void {
  // Validate that input only contains valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Check for minimum length requirement
  if (input.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  validatePadding(input);
}

function decodeAndValidate(input: string): string {
  try {
    // Validate that we got a reasonable result
    const result = Buffer.from(input, 'base64').toString('utf8');
    if (result.length === 0 && input.length > 0) {
      throw new Error('Invalid Base64 input: empty decoded result');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid string')) {
      throw new Error('Invalid Base64 input: malformed base64 data');
    }
    throw new Error('Failed to decode Base64 input');
  }
}
