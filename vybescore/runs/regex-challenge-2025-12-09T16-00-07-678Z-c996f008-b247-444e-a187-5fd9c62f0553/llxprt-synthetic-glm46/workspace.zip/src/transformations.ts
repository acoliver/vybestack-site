/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces between sentences
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure single space after sentence endings when missing
  result = result.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Identify sentence boundaries and capitalize the first letter after them
  // Handle the start of string as well
  return result.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches most common URL formats
  // Includes protocols (http/https), domains with optional subdomains
  // Accepts various TLDs, ports, and paths with query strings
  const urlRegex = /(https?:\/\/)?([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+([a-zA-Z]{2,})(:[0-9]{1,5})?(\/[^\s]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// URLs with https://, but leave existing https:// unchanged
  // Using a negative lookahead to ensure we don't match https://
  return text.replace(/http:\/\/(?!\/\/)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, convert all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then handle docs.example.com rewrite for /docs/ paths
  // Pattern: https://example.com/docs/...
  // Skip if URL contains dynamic hints (cgi-bin, query strings, certain extensions)
  
  // For URLs that don't have dynamic hints and are in /docs/ path
  result = result.replace(
    /(https:\/\/(example\.com)(\/docs\/[^\s?.]*?))(?=\?|$|[.,;:!?]|\s)/g, 
    (match, fullUrl, domain, path) => {
      // Check if the path contains dynamic hints (not checking query since it's excluded in pattern)
      if (!/cgi-bin|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/.test(path)) {
        return `https://docs.${domain}${path}`;
      }
      return fullUrl;
    }
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and extract the year
  // Validate month (1-12) and day (1-31)
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (match) {
    return match[3]; // Return the year (3rd capture group)
  }
  
  return 'N/A'; // Return 'N/A' if format is invalid
}
