export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex that:
  // - Allows unicode characters in local part
  // - Allows + tags
  // - Rejects double dots
  // - Rejects trailing dots
  // - Doesn't allow underscores in domain
  // - Allows typical domain formats

  // First check for basic email structure
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) {
    return false;
  }

  // More detailed validation
  // Local part: allows unicode letters, numbers, dots, hyphens, plus, apostrophes
  // Domain: allows letters, numbers, hyphens, but no underscores
  // No consecutive dots and no leading/trailing dots in local or domain
  const detailedRegex = /^(?!.*\.\.)[a-zA-Z0-9\u00C0-\u024F!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9\u00C0-\u024F!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  return detailedRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Normalize the phone number by removing all whitespace
  const normalizedValue = value.replace(/\s+/g, '');

  // US phone number regex that accepts:
  // - Optional +1 country code
  // - Common formats: (212) 555-7890, 212-555-7890, 2125557890
  // - Area code cannot start with 0 or 1
  // - Minimum 10 digits (excluding country code)
  const usPhoneRegex = /^(?:\+1)?(?:\(?([2-9]\d{2})\)?[-.\s]?|\b([2-9]\d{2})[-.\s]?)([2-9]\d{2})[-.\s]?(\d{4})\b$/;

  if (!usPhoneRegex.test(normalizedValue)) {
    return false;
  }

  // Extract digits and check length
  const digitsOnly = normalizedValue.replace(/[^\d]/g, '');

  // If country code is present, remove it for length check
  const digitsWithoutCountry = digitsOnly.startsWith('+1')
    ? digitsOnly.substring(2)
    : digitsOnly.startsWith('1')
      ? digitsOnly.substring(1)
      : digitsOnly;

  // Must have exactly 10 digits (area code + prefix + line number)
  return digitsWithoutCountry.length === 10;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // If starts with 54 (without +), treat it as with country code
  const normalizedDigits = digitsOnly.startsWith('54') ? '+' + digitsOnly : digitsOnly;

  // Argentine phone validation regex:
  // Optional +54 country code
  // Optional 0 trunk prefix (immediately before area code)
  // Optional 9 mobile indicator (between country/trunk and area code)
  // Area code: 2-4 digits (first digit cannot be 0)
  // Subscriber number: 6-8 digits
  // Allow spaces or hyphens as separators

  // Pattern breakdown:
  // ^(?:(?:\+54)|(?=\d))? - Optional country code with lookbehind for digits-only
  // (?:0)? - Optional trunk prefix
  // (?:9)? - Optional mobile indicator
  // ([1-9]\d{1,3}) - Area code (2-4 digits, first digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)

  const pattern1 = /^\+54(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/; // With country code
  const pattern2 = /^0([1-9]\d{1,3})(\d{6,8})$/; // Without country code but with trunk prefix

  // First try with the +54 pattern
  if (normalizedDigits.startsWith('+')) {
    const match = pattern1.exec(normalizedDigits);
    if (match) {
      // Length check for sanity
      const totalDigits = normalizedDigits.length - 1; // minus +
      return totalDigits >= 9 && totalDigits <= 16; // Reasonable range for Argentine numbers
    }
    return false;
  }

  // Then try with pattern without country code
  const match2 = pattern2.exec(normalizedDigits);
  if (match2) {
    // Length check
    return normalizedDigits.length >= 8 && normalizedDigits.length <= 12;
  }

  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex:
  // - Allow unicode letters (including accented characters)
  // - Allow apostrophes, hyphens, and spaces
  // - Reject digits and symbols
  // - Reject "X Æ A-12" style names (containing numbers or special symbols)

  // This regex allows:
  // ^[A-Za-z\u00C0-\u024F] - Starts with a unicode character (including accented letters)
  // (?:['\- ]?[A-Za-z\u00C0-\u024F]+)*$ - Zero or more groups of optional apostrophe, hyphen, or space
  // followed by one or more unicode characters

  const nameRegex = /^[A-Za-z\u00C0-\u024F](?:['\- ]?[A-Za-z\u00C0-\u024F]+)*$/;

  // Also verify it doesn't contain numbers or excessive punctuation
  const containsInvalidChars = /[0-9]|[!@#$%^&*()_+=\{\}[\]|\\:;"<>\?,\.~`]/.test(value);

  return nameRegex.test(value.trim()) && !containsInvalidChars;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // First, validate the format using regex for major credit card brands
  // Remove spaces and hyphens from the input
  const digitsOnly = value.replace(/[\s-]/g, '');

  // Check if the input contains only digits after cleaning
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;

  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  // Test against credit card patterns
  if (!visaRegex.test(digitsOnly) && !mastercardRegex.test(digitsOnly) && !amexRegex.test(digitsOnly)) {
    return false;
  }

  // Perform Luhn algorithm check
  return luhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn algorithm check for credit card validation.
 */
function luhnCheck(value: string): boolean {
  const digits = value.split('').map(Number);
  let sum = 0;
  let isEvenPositioned = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEvenPositioned) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEvenPositioned = !isEvenPositioned;
  }

  // Valid if sum modulo 10 is 0
  return sum % 10 === 0;
}