/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary regex to find words that start with the prefix
  // \b matches word boundary, \w+ matches word characters
  const wordPattern = new RegExp('\\b(' + prefix + '\\w+)', 'g');
  
  const matches = [];
  let match;
  
  // Find all words that start with the prefix
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    
    // Only include words that are not in the exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  // Remove duplicates and return
  return [...new Set(matches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Simple approach: find token preceded by digit, include the digit
  const pattern = new RegExp('(\\d' + escapedToken + ')', 'g');
  
  const matches = [];
  let match;
  
  // Find all matches
  while ((match = pattern.exec(text)) !== null) {
    // Make sure it doesn't match at the beginning of the string
    const index = text.indexOf(match[0]);
    if (index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check basic requirements
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like abab, 1212
  // This pattern matches repeated characters and repeated groups of 2+ characters
  if (/(.{1,4})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude pure IPv4 addresses (basic format)
  const ipv4Regex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Use a simpler regex for detecting IPv6 in text context (not requiring exact match of entire string)
  // Match common IPv6 patterns in text
  
  // Look for IPv6 patterns in the text
  const ipv6Patterns = [
    // Full IPv6 notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    // Shorthand with :: abbreviation: 2001::1
    // Match 8 groups of 1-4 hex digits separated by colons or with :: abbreviation
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/g,
    // Match with :: (shorthand)
    /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}/g,
    // Match at the beginning with ::
    /^::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}/g,
    // Match at the end with ::
    /(?:[0-9a-fA-F]{1,4}:){0,7}::$/g,
    // IPv6 with embedded IPv4
    /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/g
  ];
  
  // Check if any of the patterns match
  for (const pattern of ipv6Patterns) {
    pattern.lastIndex = 0; // Reset pattern
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}