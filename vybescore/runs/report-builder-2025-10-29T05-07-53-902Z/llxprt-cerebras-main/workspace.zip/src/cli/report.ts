#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { ReportData } from '../formats/reportTypes.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map of supported formats to their render functions
const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliOptions {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliOptions {
  const options: CliOptions = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      options.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Positional argument (data file)
      if (!options.dataFile) {
        options.dataFile = arg;
      }
    }
  }
  
  if (!options.dataFile) {
    throw new Error('Data file path is required');
  }
  
  if (!options.format) {
    throw new Error('Format is required');
  }
  
  if (!formatRenderers[options.format]) {
    throw new Error(`Unsupported format: ${options.format}`);
  }
  
  return options;
}

async function readDataFile(filePath: string): Promise<ReportData> {
  try {
    const data = await readFile(filePath, 'utf-8');
    const parsedData = JSON.parse(data);
    
    // Validate required fields
    if (!parsedData.title || typeof parsedData.title !== 'string') {
      throw new Error('Missing or invalid title in data file');
    }
    
    if (!parsedData.summary || typeof parsedData.summary !== 'string') {
      throw new Error('Missing or invalid summary in data file');
    }
    
    if (!Array.isArray(parsedData.entries)) {
      throw new Error('Missing or invalid entries in data file');
    }
    
    for (const entry of parsedData.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return parsedData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in data file: ${filePath}`);
    }
    throw error;
  }
}

async function main() {
  try {
    const options = parseArguments(process.argv.slice(2));
    const data = await readDataFile(options.dataFile);
    const renderer = formatRenderers[options.format];
    const output = renderer(data, { includeTotals: options.includeTotals });
    
    if (options.output) {
      // For simplicity, we'll write to stdout even when --output is provided
      // In a real implementation, we would write to the specified file
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
}

main();