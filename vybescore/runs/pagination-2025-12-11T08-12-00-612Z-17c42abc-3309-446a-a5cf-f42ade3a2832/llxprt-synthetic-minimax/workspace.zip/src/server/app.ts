import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Input validation
    const parsePositiveInteger = (value: string, name: string): number => {
      const num = Number(value);
      
      if (Number.isNaN(num)) {
        throw new Error(`${name} must be a valid number`);
      }
      
      if (!Number.isInteger(num)) {
        throw new Error(`${name} must be an integer`);
      }
      
      if (num <= 0) {
        throw new Error(`${name} must be greater than 0`);
      }
      
      if (num > 1000) {
        throw new Error(`${name} is too large (maximum: 1000)`);
      }
      
      return num;
    };

    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;

    try {
      if (pageParam) {
        page = parsePositiveInteger(pageParam, 'page');
      }
      if (limitParam) {
        limit = parsePositiveInteger(limitParam, 'limit');
      }
    } catch (error) {
      return res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid parameters' });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
