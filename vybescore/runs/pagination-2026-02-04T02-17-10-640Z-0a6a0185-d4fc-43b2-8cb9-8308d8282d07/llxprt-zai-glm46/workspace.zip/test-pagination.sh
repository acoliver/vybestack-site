#!/bin/bash
# Comprehensive pagination test script

echo "=== Starting Pagination Service Tests ==="
echo ""

# Start server in background
npm run dev:server &
SERVER_PID=$!
echo "Started server (PID: $SERVER_PID)"
sleep 3

echo "=== Test 1: Default request (no params) ==="
curl -s "http://localhost:3333/inventory" | jq '.'
echo -e "\n"

echo "=== Test 2: Page 1 with limit 5 ==="
curl -s "http://localhost:3333/inventory?page=1&limit=5" | jq '.items | length'
echo -e "\n"

echo "=== Test 3: Page 2 with limit 5 ==="
curl -s "http://localhost:3333/inventory?page=2&limit=5" | jq '.items[0].name'
echo -e "\n"

echo "=== Test 4: Page 3 (last page) ==="
curl -s "http://localhost:3333/inventory?page=3&limit=5" | jq '{items: .items | length, hasNext}'
echo -e "\n"

echo "=== Test 5: Page 4 (beyond last page) ==="
curl -s "http://localhost:3333/inventory?page=4&limit=5" | jq '{items: .items | length, hasNext}'
echo -e "\n"

echo "=== Test 6: Invalid page (non-numeric) ==="
curl -s "http://localhost:3333/inventory?page=abc" | jq '.'
echo -e "\n"

echo "=== Test 7: Invalid page (negative) ==="
curl -s "http://localhost:3333/inventory?page=-1" | jq '.'
echo -e "\n"

echo "=== Test 8: Invalid page (zero) ==="
curl -s "http://localhost:3333/inventory?page=0" | jq '.'
echo -e "\n"

echo "=== Test 9: Invalid page (decimal) ==="
curl -s "http://localhost:3333/inventory?page=1.5" | jq '.'
echo -e "\n"

echo "=== Test 10: Invalid limit (non-numeric) ==="
curl -s "http://localhost:3333/inventory?limit=xyz" | jq '.'
echo -e "\n"

echo "=== Test 11: Invalid limit (negative) ==="
curl -s "http://localhost:3333/inventory?limit=-5" | jq '.'
echo -e "\n"

echo "=== Test 12: Invalid limit (zero) ==="
curl -s "http://localhost:3333/inventory?limit=0" | jq '.'
echo -e "\n"

echo "=== Test 13: Excessive limit (101) ==="
curl -s "http://localhost:3333/inventory?limit=101" | jq '.'
echo -e "\n"

echo "=== Test 14: Custom page size (limit 10) ==="
curl -s "http://localhost:3333/inventory?page=1&limit=10" | jq '{page, limit, total, hasNext}'
echo -e "\n"

echo "=== Test 15: Verify no duplicate items across pages ==="
PAGE1=$(curl -s "http://localhost:3333/inventory?page=1&limit=5" | jq -r '.items[-1].id')
PAGE2=$(curl -s "http://localhost:3333/inventory?page=2&limit=5" | jq -r '.items[0].id')
echo "Last item of page 1: $PAGE1"
echo "First item of page 2: $PAGE2"
echo "No duplicates: $([ "$PAGE1" != "$PAGE2" ] && echo "PASS" || echo "FAIL")"
echo ""

# Kill server
kill $SERVER_PID 2>/dev/null
echo "=== Tests Complete ==="
