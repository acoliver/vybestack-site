declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    step(): boolean;
    get(params?: unknown[]): unknown[] | null;
    getAll(params?: unknown[]): unknown[][];
    getAsObject(params?: unknown[]): Record<string, unknown>;
    bind(params?: unknown[]): boolean;
    free(): boolean;
  }

  export interface RunResult {
    columns: string[];
    values: unknown[][];
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export default function initSqlJs(config?: Record<string, unknown>): Promise<SqlJsStatic>;
}
