import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(process.cwd(), 'public')));

const templatesDir = path.resolve(process.cwd(), 'src', 'templates');
app.set('views', templatesDir);
app.set('view engine', 'ejs');

async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  let dbInstance: Database;
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }
  
  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  const dataDir = path.dirname(DB_PATH);
  
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()+]+$/;
  return phoneRegex.test(phone) && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length > 0;
}

function validateFormData(data: Partial<FormData>): { errors: string[]; valid: boolean } {
  const errors: string[] = [];
  
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];
  
  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim().length === 0) {
      const label = field
        .replace(/([A-Z])/g, ' $1')
        .toLowerCase()
        .trim();
      errors.push(`${label} is required`);
    }
  }
  
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading @');
  }
  
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Postal code can only contain letters, digits, spaces, and dashes');
  }
  
  return { errors, valid: errors.length === 0 };
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.valid) {
    res.status(400);
    return res.render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName.trim(),
    formData.lastName.trim(),
    formData.streetAddress.trim(),
    formData.city.trim(),
    formData.stateProvince.trim(),
    formData.postalCode.trim(),
    formData.country.trim(),
    formData.email.trim(),
    formData.phone.trim()
  ]);
  
  stmt.free();
  
  saveDatabase(db);
  
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', {
    firstName: 'Friend'
  });
});

interface Server {
  close: () => void;
  listen: (port: string | number, cb?: () => void) => void;
  app?: unknown;
}

async function startServer(): Promise<Server> {
  db = await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  }) as unknown as Server;
  
  server.app = app;
  
  return server;
}

function shutdown(): void {
  if (db) {
    db.close();
    db = null;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  shutdown();
  process.exit(0);
});

export { startServer, shutdown, app };
export type { Server };
