/**
 * Encode plain text to canonical Base64.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

// Base64 validation regex - matches valid Base64 strings with or without padding
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate the input format first - only check for valid Base64 characters
  if (!BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input format');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
