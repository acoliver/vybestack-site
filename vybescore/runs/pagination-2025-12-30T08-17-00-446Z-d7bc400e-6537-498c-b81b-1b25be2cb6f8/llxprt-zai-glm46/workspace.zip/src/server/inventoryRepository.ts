import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export interface ValidationError {
  field: string;
  message: string;
}

export function validatePaginationParams(
  page: unknown,
  limit: unknown
): ValidationError[] {
  const errors: ValidationError[] = [];

  if (page !== undefined && page !== null) {
    const pageNum = Number(page);
    if (isNaN(pageNum) || !Number.isInteger(pageNum)) {
      errors.push({ field: 'page', message: 'page must be an integer' });
    } else if (pageNum < 1) {
      errors.push({ field: 'page', message: 'page must be greater than 0' });
    }
  }

  if (limit !== undefined && limit !== null) {
    const limitNum = Number(limit);
    if (isNaN(limitNum) || !Number.isInteger(limitNum)) {
      errors.push({ field: 'limit', message: 'limit must be an integer' });
    } else if (limitNum < 1) {
      errors.push({ field: 'limit', message: 'limit must be greater than 0' });
    } else if (limitNum > MAX_LIMIT) {
      errors.push({ field: 'limit', message: `limit must not exceed ${MAX_LIMIT}` });
    }
  }

  return errors;
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.min(Math.floor(options.limit), MAX_LIMIT) : DEFAULT_LIMIT;

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
