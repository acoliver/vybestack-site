/**
 * Finds words in the text that start with the given prefix but are not in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a regex pattern to match words beginning with the prefix
  // Use word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds for matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create a regex pattern using lookbehind to ensure the token appears after a digit
  // and includes the digit in the match
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  return text.match(regex) || [];
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any sequence of 2 or more characters that repeats immediately
  if (/(\w{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand "::") and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // Simple pattern for IPv4 to ensure we exclude them
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

  // If IPv4 is detected, return false
  if (ipv4Regex.test(value)) {
    return false;
  }

  // Regex pattern to match IPv6 addresses including shorthand "::"
  // This pattern checks for valid IPv6 format with or without :: shorthand
  // It matches full IPv6 addresses and compressed formats
  const ipv6Regex = /(?:^|\s)(?:::(?:ffff(?::0{1,4})?:)?(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?::[0-9a-fA-F]{1,4}){1,7}|(?:[0-9a-fA-F]{1,4}:){1,6}:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,5}(?::(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])){1,5}|[0-9a-fA-F]{1,4}:(?::(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])){1,6}|:(?::(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])){1,7}|::)(?:$|\s)/g;

  // Check for IPv6
  return ipv6Regex.test(value);
}