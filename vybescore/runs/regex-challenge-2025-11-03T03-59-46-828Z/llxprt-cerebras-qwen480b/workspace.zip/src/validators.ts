export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern that validates standard email formats
  // Rejects double dots, trailing dots in local part or domain
  // Rejects domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific invalid cases
  if (!value || value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Check if domain contains underscore
  if (!domain || domain.includes('_')) {
    return false;
  }
  
  // Check if local part ends with dot
  if (localPart.endsWith('.')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length and pattern checking
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +1 but has incorrect length
  if (value.startsWith('+1') && digitsOnly.length !== 11) {
    return false;
  }
  
  // Check if it doesn't start with +1 but has incorrect length
  if (!value.startsWith('+1') && digitsOnly.length !== 10) {
    return false;
  }
  
  // Extract the area code (first 3 digits after optional +1)
  const areaCode = value.startsWith('+1') ? digitsOnly.substring(1, 4) : digitsOnly.substring(0, 3);
  
  // Validate area code (should not start with 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Regex pattern to validate phone number format
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers in various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number (after the area code) must contain 6-8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 or 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Extract components based on format
  let startIndex = 0;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  // Check for country code
  if (cleanValue.startsWith('+54')) {
    hasCountryCode = true;
    startIndex = 3;
  }
  
  // Check for trunk prefix (0)
  if (cleanValue.charAt(startIndex) === '0') {
    hasTrunkPrefix = true;
    startIndex++;
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator (9) and skip it - it's optional
  if (cleanValue.charAt(startIndex) === '9') {
    startIndex++;
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  let areaCodeEndIndex = startIndex + 1;
  while (areaCodeEndIndex < startIndex + 4 && 
         areaCodeEndIndex < cleanValue.length && 
         /\d/.test(cleanValue.charAt(areaCodeEndIndex))) {
    areaCodeEndIndex++;
  }
  
  const areaCode = cleanValue.substring(startIndex, areaCodeEndIndex);
  
  // Validate area code length and first digit
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode.charAt(0) === '0') {
    return false;
  }
  
  // Extract subscriber number (6-8 digits)
  const subscriberNumber = cleanValue.substring(areaCodeEndIndex);
  
  // Validate subscriber number length and that it contains only digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;
  
  // Regex pattern for valid names
  // Allows unicode letters, spaces, hyphens, and apostrophes
  // Rejects digits and most symbols (allows only spaces, hyphens, and apostrophes)
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check if the name contains any digits or invalid symbols
  if (/\d/.test(value) || !nameRegex.test(value)) {
    return false;
  }
  
  // Reject names like "X Æ A-12" that contain both letters and numbers in unconventional ways
  // This pattern ensures we don't have numbers mixed with letters
  if (/[A-Za-z]+[0-9]+|[0-9]+[A-Za-z]+/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa, Mastercard, and AmEx card numbers.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check basic format with regex
  const cardRegex = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})$/;
  if (!cardRegex.test(cleanValue)) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanValue);
}

/**
 * Implements the Luhn algorithm for Credit Card validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}