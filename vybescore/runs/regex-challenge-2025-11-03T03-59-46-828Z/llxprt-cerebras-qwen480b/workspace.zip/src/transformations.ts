/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences and collapses extra spaces sensibly.
 * Leaves abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Split text by sentence-ending punctuation followed by whitespace
  // Use a regex that captures the punctuation and any following whitespace
  const sentences = text.split(/([.?!]+)(\s*)/);
  
  // Process each sentence
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // If this part is punctuation, add it and set flag to capitalize next
    if (/[.?!]+/.test(part)) {
      result += part;
      capitalizeNext = true;
      continue;
    }
    
    // If this part is whitespace after punctuation, replace with single space if needed
    if (i > 0 && /[.?!]+/.test(sentences[i-1])) {
      if (part.length > 0) {
        result += ' ' + part.trimStart();
      } else {
        result += ' ';
      }
      continue;
    }
    
    // Regular text part
    if (capitalizeNext && part.length > 0) {
      // Capitalize the first character
      result += part.charAt(0).toUpperCase() + part.slice(1);
      capitalizeNext = false;
    } else {
      result += part;
    }
  }
  
  // Handle the case where the text doesn't start with a capital letter
  if (result.length > 0 && result.charAt(0) >= 'a' && result.charAt(0) <= 'z') {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Remove trailing space if present
  return result.trimEnd();
}

/**
 * Extracts URLs from text and returns them as an array.
 * URLs are detected without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regex pattern to match URLs
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  // Extract all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.?!;,+)]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https://, but not if it's already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When the path begins with /docs/, rewrites the host to docs.example.com
 * Skips host rewrite when path contains dynamic hints or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // Regex to match URLs with http scheme
  const urlRegex = /http:\/\/([\w.-]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, host, path = '/') => {
    // Upgrade scheme to https
    let newUrl = `https://${host}${path}`;
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // If path starts with /docs/ and doesn't contain dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      newUrl = `https://docs.${host}${path}`;
    }
    
    // Remove trailing punctuation
    return newUrl.replace(/[.?!;,+)]+$/, '');
  });
}

/**
 * Extracts the year from mm/dd/yyyy date strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format with regex
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month and day ranges
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}
