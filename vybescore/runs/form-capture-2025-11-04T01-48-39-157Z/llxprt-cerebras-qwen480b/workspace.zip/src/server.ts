import express, { Application, Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app: Application = express();
const port: number = parseInt(process.env.PORT || '3000', 10);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
const dbPath = path.resolve(__dirname, '../data/submissions.sqlite');
let db: Database;

// Helper to initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({ locateFile: (file: string) => `node_modules/sql.js/dist/${file}` });
  
  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    db.run(fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8'));
    writeDatabaseToDisk();
  }
}

// Helper to persist database to disk
function writeDatabaseToDisk() {
  const data = db.export();
  fs.writeFileSync(dbPath, data);
}

// Helper to validate form data
function validateForm(data: {[key: string]: string}): string[] {
  const errors: string[] = [];
  
  // Required fields check
  const requiredFields = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];
  
  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
    }
  }
  
  // Email validation (simple regex)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Email is invalid');
  }
  
  // Phone validation (digits, spaces, parentheses, dashes, and leading +)
  if (data.phone && !/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  // Postal code validation (alphanumeric with spaces and dashes)
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  return errors;
}

// Route to render the form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

// Route to handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  const formData = req.body;
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: formData });
  }
  
  // Insert data into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  writeDatabaseToDisk();
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(formData.firstName));
});

// Route to render thank-you page
app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
initDatabase().then(() => {
  // Only start server if this file is run directly
  if (import.meta.url === `file://${process.argv[1]}`) {
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown on SIGTERM
    process.on('SIGTERM', () => {
      console.log('SIGTERM signal received: closing HTTP server and database');
      server.close(() => {
        console.log('HTTP server closed');
      });
      writeDatabaseToDisk();
      db.close();
    });
  }
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

// Export app for testing
export { app, initDatabase, writeDatabaseToDisk, dbPath };
export default app;