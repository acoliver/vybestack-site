declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  interface InitSqlJsStatic {
    (config?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
  }

  const initSqlJs: InitSqlJsStatic;
  export default initSqlJs;
}