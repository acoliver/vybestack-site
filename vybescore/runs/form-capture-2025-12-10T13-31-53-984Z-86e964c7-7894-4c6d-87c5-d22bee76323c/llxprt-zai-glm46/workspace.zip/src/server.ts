import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { Database } from 'sql.js';
import fs from 'fs/promises';
import { createServer } from 'http';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

class FormCaptureApp {
  private app: express.Application;
  private server: import('http').Server | null = null;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'views'));
  }

  private setupRoutes(): void {
    this.app.get('/', this.handleFormGet.bind(this));
    this.app.post('/submit', this.handleFormSubmit.bind(this));
    this.app.get('/thank-you', this.handleThankYou.bind(this));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await import('sql.js');
      const initSqlJs = SQL.default;
      
      let dbBuffer: Uint8Array | null = null;
      
      try {
        const existingDb = await fs.readFile(this.dbPath);
        dbBuffer = new Uint8Array(existingDb);
      } catch (error) {
        console.log('No existing database found, creating new one');
      }

      const SQLLib = await initSqlJs();
      this.db = new SQLLib.Database(dbBuffer || undefined);

      if (!dbBuffer) {
        const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
        const schema = await fs.readFile(schemaPath, 'utf-8');
        this.db.exec(schema);
        await this.saveDatabase();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      const data = this.db.export();
      await fs.writeFile(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
    const errors: FormErrors = {};

    if (!data.firstName || data.firstName.trim() === '') {
      errors.firstName = 'First name is required';
    }

    if (!data.lastName || data.lastName.trim() === '') {
      errors.lastName = 'Last name is required';
    }

    if (!data.streetAddress || data.streetAddress.trim() === '') {
      errors.streetAddress = 'Street address is required';
    }

    if (!data.city || data.city.trim() === '') {
      errors.city = 'City is required';
    }

    if (!data.stateProvince || data.stateProvince.trim() === '') {
      errors.stateProvince = 'State/Province/Region is required';
    }

    if (!data.postalCode || data.postalCode.trim() === '') {
      errors.postalCode = 'Postal/Zip code is required';
    }

    if (!data.country || data.country.trim() === '') {
      errors.country = 'Country is required';
    }

    if (!data.email || data.email.trim() === '') {
      errors.email = 'Email is required';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.email = 'Please enter a valid email address';
      }
    }

    if (!data.phone || data.phone.trim() === '') {
      errors.phone = 'Phone number is required';
    } else {
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.phone = 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading +)';
      }
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private async handleFormGet(req: express.Request, res: express.Response): Promise<void> {
    const formData: FormData = {};
    const errors: FormErrors = {};
    
    res.render('form', { 
      formData, 
      errors, 
      hasErrors: false 
    });
  }

  private async handleFormSubmit(req: express.Request, res: express.Response): Promise<void> {
    const formData: FormData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };

    const validation = this.validateForm(formData);

    if (!validation.isValid) {
      res.status(400).render('form', {
        formData,
        errors: validation.errors,
        hasErrors: true
      });
      return;
    }

    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }

      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName?.trim(),
        formData.lastName?.trim(),
        formData.streetAddress?.trim(),
        formData.city?.trim(),
        formData.stateProvince?.trim(),
        formData.postalCode?.trim(),
        formData.country?.trim(),
        formData.email?.trim(),
        formData.phone?.trim()
      ]);

      stmt.free();
      await this.saveDatabase();

      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        formData,
        errors: { email: 'An error occurred while saving your submission. Please try again.' },
        hasErrors: true
      });
    }
  }

  private async handleThankYou(req: express.Request, res: express.Response): Promise<void> {
    res.render('thank-you');
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT || 3535;
    this.server = createServer(this.app);
    
    return new Promise((resolve, reject) => {
      if (!this.server) {
        resolve();
        return;
      }
      
      this.server.listen(port, (err?: Error) => {
        if (err) {
          reject(err);
        } else {
          console.log(`Server running on port ${port}`);
          resolve();
        }
      });
    });
  }

  public async stop(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }

    if (this.server) {
      return new Promise((resolve, reject) => {
        if (!this.server) {
          resolve();
          return;
        }
        
        this.server.close((err?: Error) => {
          if (err) {
            reject(err);
          } else {
            console.log('Server stopped');
            resolve();
          }
        });
      });
    }
  }
}

async function main(): Promise<void> {
  const app = new FormCaptureApp();

  process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    await app.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully...');
    await app.stop();
    process.exit(0);
  });

  try {
    await app.start();
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export default FormCaptureApp;