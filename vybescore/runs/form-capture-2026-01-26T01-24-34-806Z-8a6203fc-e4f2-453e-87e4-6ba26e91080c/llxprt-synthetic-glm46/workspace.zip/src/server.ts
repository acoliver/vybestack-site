import express, { Request, Response } from 'express';
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Buffer } from 'node:buffer';

// Get the directory name of current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js
import initSqlJs, { Database as SqlJsDatabase } from 'sql.js';

// Type for form submission data
interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Helper function to validate form inputs
function validateForm(data: FormSubmission): string[] {
  const errors: string[] = [];
  
  // First name
  if (!data.firstName.trim()) {
    errors.push('First name is required');
  }
  
  // Last name
  if (!data.lastName.trim()) {
    errors.push('Last name is required');
  }
  
  // Street address
  if (!data.streetAddress.trim()) {
    errors.push('Street address is required');
  }
  
  // City
  if (!data.city.trim()) {
    errors.push('City is required');
  }
  
  // State/Province
  if (!data.stateProvince.trim()) {
    errors.push('State/Province is required');
  }
  
  // Postal code (accept alphanumeric)
  if (!data.postalCode.trim()) {
    errors.push('Postal code is required');
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push('Postal code contains invalid characters');
  }
  
  // Country
  if (!data.country.trim()) {
    errors.push('Country is required');
  }
  
  // Email validation
  if (!data.email.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Email format is invalid');
  }
  
  // Phone validation (accept digits, spaces, parentheses, dashes, and leading @)
  if (!data.phone.trim()) {
    errors.push('Phone number is required');
  } else if (!/^@?[0-9\s-()]+$/.test(data.phone)) {
    errors.push('Phone number contains invalid characters');
  }
  
  return errors;
}

// Main server function
async function createServer() {
  // Initialize express app
  const app = express();
  // Use port 0 for testing to get any available port, but keep default for normal operation
  const port = process.env.NODE_ENV === 'test' ? 0 : (process.env.PORT || 3535);
  
  // Setup body parser
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Serve static files
  app.use('/public', express.static(path.join(__dirname, 'public')));
  
  // Set up EJS
  app.set('views', path.join(__dirname, 'templates'));
  app.set('view engine', 'ejs');
  
  // Initialize database
  const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
  let db: SqlJsDatabase;
  
  try {
    // Check if database file exists
    const dbExists = await fs.access(dbPath).then(() => true).catch(() => false);
    
    // Read or create database
    const dataBuffer = dbExists ? await fs.readFile(dbPath) : new Uint8Array(0);
    
    // Initialize SQL.js
    const SQL = await initSqlJs();
    db = new SQL.Database(dataBuffer);
    
    // If database is new, create schema
    if (!dbExists) {
      const schema = await fs.readFile(
        path.resolve(__dirname, '..', 'db', 'schema.sql'),
        'utf8'
      );
      db.run(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
  
  // Helper to save database
  const saveDatabase = async () => {
    try {
      const data = Buffer.from(db.export() as Uint8Array);
      await fs.writeFile(dbPath, data);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  };
  
  // GET route for the form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      }
    });
  });
  
  // POST route for form submission
  app.post('/submit', async (req: Request, res: Response) => {
    const formData: FormSubmission = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    // Validate form
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      // If validation fails, re-render form with errors
      return res.render('form', {
        errors,
        values: formData
      });
    }
    
    try {
      // Insert into database
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database
      await saveDatabase();
      
      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error saving to database:', error);
      res.status(500).render('form', {
        errors: ['An unexpected error occurred. Please try again.'],
        values: formData
      });
    }
  });
  
  // GET route for thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    // Get first name from recent submission if available
    let firstName = 'friend';
    
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const result = stmt.getAsObject([]);
      stmt.free();
      
      if (result.first_name as string) {
        firstName = result.first_name as string;
      }
    } catch (error) {
      console.error('Error fetching recent submission:', error);
    }
    
    res.render('thank-you', { firstName });
  });
  
  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('Received termination signal, shutting down gracefully...');
    if (db) {
      try {
        db.close();
        console.log('Database connection closed.');
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
    process.exit(0);
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  // Start server
  let actualPort = port;
  const server = app.listen(port, () => {
    const address = server.address();
    if (typeof address === 'object' && address !== null) {
      actualPort = address.port;
    }
    console.log(`Server running on port ${actualPort}`);
  });
  
  // If port was 0 (any available port), update it for tests
  if (port === 0) {
    const address = server.address();
    if (typeof address === 'object' && address !== null) {
      actualPort = address.port;
    }
  }
  
  // Store the server address for testing
  const originalAddress = server.address.bind(server);
  server.address = () => {
    // Try to get the real address first
    const realAddress = originalAddress();
    // If realAddress is null (e.g., server not yet listening), return a mock address
    if (realAddress === null) {
      return { port: actualPort as number, family: 'IPv4', address: '127.0.0.1' };
    }
    return realAddress;
  };
  
  return server;
}

// Export the createServer function for testing
export {
  createServer
};

// Create and start the server
createServer().catch(console.error);
