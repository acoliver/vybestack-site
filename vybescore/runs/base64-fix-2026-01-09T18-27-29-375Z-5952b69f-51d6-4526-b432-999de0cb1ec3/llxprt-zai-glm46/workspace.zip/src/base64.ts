/**
 * Validate Base64 input string.
 * Returns true if the string appears to be valid Base64 (with or without padding).
 */
function isValidBase64(input: string): boolean {
  // Empty string is technically valid but will decode to empty
  if (input.length === 0) {
    return true;
  }

  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /) and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check that padding (if present) is only at the end and valid
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    // Padding can only be 0, 1, or 2 characters
    if (paddingLength > 2) {
      return false;
    }
    // Total length (including padding) must be multiple of 4 for standard Base64
    if (input.length % 4 !== 0) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet or has invalid padding');
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Verify that the input was actually valid Base64
    // Buffer.from will decode invalid base64 but may produce unexpected results
    // We need to check if the round-trip produces the same encoding
    const reEncoded = buffer.toString('base64');
    
    // Remove padding for comparison (padding is optional)
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    
    // If the normalized forms don't match, the input was invalid
    if (normalizedInput !== normalizedReEncoded) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
