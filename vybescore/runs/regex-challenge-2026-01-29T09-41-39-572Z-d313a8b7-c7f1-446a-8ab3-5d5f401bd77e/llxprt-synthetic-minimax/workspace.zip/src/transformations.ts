/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle basic sentence capitalization
  // Pattern to find sentence endings followed by optional whitespace
  const sentences = text.split(/([.!?]+)/);
  let result = '';
  let shouldCapitalize = true; // Start with true for first sentence
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (/^[.!?]+$/.test(segment)) {
      // This is punctuation - add it and next segment will be capitalized
      result += segment;
      shouldCapitalize = true;
    } else if (segment.trim() !== '') {
      // This is text content
      if (shouldCapitalize && segment.trim().length > 0) {
        result += segment.replace(/^(\s*)([a-zA-Z])/, (match, whitespace, letter) => {
          return whitespace + letter.toUpperCase();
        });
        shouldCapitalize = false;
      } else {
        result += segment;
      }
    } else {
      result += segment;
    }
  }
  
  // Normalize extra spaces between sentences
  return result.replace(/([.!?]+)\s+/g, '$1 ').replace(/([.!?])\s{2,}/g, '$1 ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Find URLs using regex
  // URLs typically start with http://, https://, www., etc.
  const urlRegex = /(https?:\/\/[^\s<>"'{}|\\^`[\]]*)/gi;
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  // Use negative lookahead to avoid replacing https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with comprehensive path capture
  return text.replace(/http:\/\/([^/\s]+)(\/.*?)(?=[\s]|$)/gi, (match, host, path = '') => {
    const scheme = 'https://';
    let newHost = host;
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    // If path begins with /docs/ and no dynamic hints, rewrite host
    if (path && path.startsWith('/docs/') && !hasDynamicHints) {
      newHost = `docs.${host}`;
    }
    
    return scheme + newHost + (path || '');
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return match[3]; // Return the year part
}
