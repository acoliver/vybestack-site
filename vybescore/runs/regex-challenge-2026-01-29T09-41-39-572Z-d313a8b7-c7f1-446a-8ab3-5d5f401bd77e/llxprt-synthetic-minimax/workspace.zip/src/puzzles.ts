/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words starting with the prefix
  // Use word boundaries to match whole words
  const wordRegex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at the start
  // Pattern: digit (not at string start) immediately followed by the token
  const embeddedRegex = new RegExp(`(?<!^)\\d(${token})`, 'g');
  const matches = text.match(embeddedRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // At least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{}|;':"|,.<>?]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., "abab")
  // Check for any 2-character sequence that repeats immediately
  const patterns = [
    /(.{2})\1/, // 2-char repeat like "abab"
    /(.{3})\1/, // 3-char repeat like "abcabc"  
    /(.{4})\1/, // 4-char repeat like "abcdabcd"
  ];
  
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if IPv4 is present - if so, return false
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 addresses can be in various formats:
  // Standard: 2001:0db8:0000:0000:0000:ff00:0042:0329
  // Compressed: 2001:db8::ff00:42:329
  // Mixed IPv4/IPv6: ::ffff:192.0.2.1
  
  // Simplified but comprehensive IPv6 detection
  const ipv6Patterns = [
    // Standard full format: 2001:0db8:0000:0000:0000:ff00:0042:0329
    /\b[0-9A-Fa-f]{1,4}:(?:[0-9A-Fa-f]{1,4}:){6}[0-9A-Fa-f]{1,4}\b/,
    
    // Compressed with :: (multiple patterns to handle different positions)
    /\b[0-9A-Fa-f]{1,4}::(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4}\b/,
    /\b::[0-9A-Fa-f]{1,4}:(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4}\b/,
    /\b[0-9A-Fa-f]{1,4}:(?:[0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4}::\b/,
    /\b::(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4}\b/,
    
    // Shorter forms
    /\b[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}\b/,
    /\b[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}\b/,
    /\b[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}\b/,
    /\b[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}\b/,
    /\b[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}\b/,
    /\b[0-9A-Fa-f]{1,4}:[0-9A-Fa-f]{1,4}\b/,
  ];
  
  // Test against all IPv6 patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
