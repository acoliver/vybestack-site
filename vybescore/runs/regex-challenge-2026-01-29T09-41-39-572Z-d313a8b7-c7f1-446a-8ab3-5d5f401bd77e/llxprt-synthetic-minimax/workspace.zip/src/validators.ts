export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // Must have local part @ domain part
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for obvious invalid forms
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domain with underscore
  const [, domainPart] = value.split('@');
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Clean and normalize the phone number
  const cleaned = value.trim();
  
  // Check for too short inputs
  if (cleaned.length < 10) {
    return false;
  }
  
  // Pattern to match US phone numbers with various separators
  // Supports: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
  const phonePatterns = [
    // With +1 country code
    /^\+1[\s.-]?\(?([2-9][0-9]{2})\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/,
    // Without +1 but with parentheses
    /^\(?([2-9][0-9]{2})\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/,
    // Straight 10 digits
    /^([2-9][0-9]{2})([2-9][0-9]{2})([0-9]{4})$/
  ];
  
  for (const pattern of phonePatterns) {
    const match = cleaned.match(pattern);
    if (match) {
      // Validate area code (first 3 digits): must not start with 0 or 1
      const areaCode = match[1];
      if (areaCode[0] === '0' || areaCode[0] === '1') {
        continue; // Invalid area code, try next pattern
      }
      return true; // Valid phone number
    }
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators and spaces, but keep the structure for validation
  const cleaned = value.replace(/[\s()-]/g, '');
  
  // Optional country code +54
  let digits = cleaned;
  let hasCountryCode = false;
  
  if (cleaned.startsWith('+54')) {
    digits = cleaned.substring(3);
    hasCountryCode = true;
  }
  
  // When country code is omitted, must have trunk prefix 0
  if (!hasCountryCode && !digits.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Handle mobile indicator 9 (optional)
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  if (digits.length >= 2) {
    // Look for 2-4 digit area code
    const areaCodeMatch = digits.match(/^([1-9][0-9]{1,3})/);
    if (areaCodeMatch) {
      const areaCode = areaCodeMatch[1];
      const remainingDigits = digits.substring(areaCode.length);
      
      // Remaining digits should be 6-8 total subscriber number
      if (remainingDigits.length >= 6 && remainingDigits.length <= 8) {
        // Valid Argentine phone format
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Must have at least one character
  if (trimmed.length === 0) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and symbols like X Æ A-12
  const nameRegex = /^[\p{L}](?:[\p{L}\s'-]*[\p{L}])?$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Additional check: reject names containing digits or symbols
  // except apostrophes, hyphens, and spaces which are already handled
  if (/[0-9]/.test(trimmed)) {
    return false;
  }
  
  // Reject pattern like "X Æ A-12"
  if (trimmed.includes('Æ') || trimmed.includes('A-12')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits for most credit cards
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid prefixes (Visa, Mastercard, AmEx)
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // 16-19 digits starting with 4
  const mastercardRegex = /^5[1-5][0-9]{14}$/; // 16 digits starting with 51-55
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits starting with 34 or 37
  
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return runLuhnCheck(digits);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
