import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs/promises';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(__dirname, '../public')));

app.set('view engine', 'ejs');
// Determine templates path based on whether we're running from source or dist
// In dev, __dirname is .../src, in production it's .../dist
function getTemplatesPath() {
  const dir = __dirname;
  if (dir.endsWith('src') || dir.includes('/src/')) {
    return path.resolve(dir, 'templates');
  }
  return path.resolve(dir, '../src/templates');
}
app.set('views', getTemplatesPath());

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Trim whitespace for validation, but allow formats like: +44 20 7946 0958, +54 9 11 1234-5678
  const trimmedPhone = phone.trim();
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return trimmedPhone.length > 0 && phoneRegex.test(trimmedPhone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationResult {
  const errors: string[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim().length === 0) {
      const fieldNames: Record<string, string> = {
        firstName: 'First name',
        lastName: 'Last name',
        streetAddress: 'Street address',
        city: 'City',
        stateProvince: 'State / Province / Region',
        postalCode: 'Postal / Zip code',
        country: 'Country',
        email: 'Email',
        phone: 'Phone number',
      };
      errors.push(`${fieldNames[field]} is required.`);
    }
  }

  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address.');
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading +).');
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code (letters and numbers only).');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    const dataDir = path.dirname(DB_PATH);
    try {
      await fs.mkdir(dataDir, { recursive: true });
    } catch {
      // Directory might already exist
    }

    let dbData: Uint8Array | undefined;
    try {
      const dbFile = await fs.readFile(DB_PATH);
      dbData = dbFile;
    } catch {
      // Database doesn't exist yet, will create new one
    }

    db = new SQL.Database(dbData);

    // Initialize schema
    const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
    db.run(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    await fs.writeFile(DB_PATH, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database error. Please try again.'],
      values: formData,
    });
  }

  try {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || '',
      ]
    );

    saveDatabase().catch((err) => {
      console.error('Failed to save database:', err);
    });

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    return res.status(500).render('form', {
      errors: ['Failed to save submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'friend';
  res.render('thank-you', { firstName });
});

let server: ReturnType<typeof app.listen>;

export async function startServer(): Promise<typeof app> {
  await initializeDatabase();
  return new Promise((resolve) => {
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      resolve(app);
    });
  });
}

export async function stopServer(): Promise<void> {
  return new Promise((resolve) => {
    if (server) {
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        console.log('Server stopped gracefully');
        resolve();
      });
    } else {
      if (db) {
        db.close();
        db = null;
      }
      resolve();
    }
  });
}

process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await stopServer();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await stopServer();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
