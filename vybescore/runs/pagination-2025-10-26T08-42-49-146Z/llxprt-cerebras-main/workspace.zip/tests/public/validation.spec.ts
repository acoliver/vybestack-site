import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API validation', () => {
  it('rejects non-numeric page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid page parameter. Must be a positive integer.');
  });

  it('rejects negative page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid page parameter. Must be a positive integer.');
  });

  it('rejects zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid page parameter. Must be a positive integer.');
  });

  it('rejects non-numeric limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=def');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid limit parameter. Must be a positive integer.');
  });

  it('rejects negative limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid limit parameter. Must be a positive integer.');
  });

  it('rejects zero limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid limit parameter. Must be a positive integer.');
  });

  it('handles valid parameters correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.hasNext).toBe(true);
  });
});