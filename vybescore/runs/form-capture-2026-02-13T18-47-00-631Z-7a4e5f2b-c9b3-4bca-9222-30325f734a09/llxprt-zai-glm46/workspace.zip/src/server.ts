import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

// Middleware
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(express.json());

// Database setup
let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const dbBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } else {
    db = new SQL.Database();
  }

  // Run schema to ensure table exists
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);

  // Save to disk
  saveDatabase();
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Type for form submission
interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation functions
function isNotEmpty(value: string): boolean {
  return value.trim().length > 0;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function isValidPhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?\d[\d\s()-]*$/;
  return phoneRegex.test(phone.trim());
}

function isValidPostalCode(code: string): boolean {
  // Allow alphanumeric characters and spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(code.trim());
}

function validateSubmission(data: FormSubmission): string[] {
  const errors: string[] = [];

  if (!isNotEmpty(data.firstName)) {
    errors.push('First name is required');
  }
  if (!isNotEmpty(data.lastName)) {
    errors.push('Last name is required');
  }
  if (!isNotEmpty(data.streetAddress)) {
    errors.push('Street address is required');
  }
  if (!isNotEmpty(data.city)) {
    errors.push('City is required');
  }
  if (!isNotEmpty(data.stateProvince)) {
    errors.push('State / Province / Region is required');
  }
  if (!isNotEmpty(data.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!isValidPostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters and numbers');
  }
  if (!isNotEmpty(data.country)) {
    errors.push('Country is required');
  }
  if (!isNotEmpty(data.email)) {
    errors.push('Email is required');
  } else if (!isValidEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!isNotEmpty(data.phone)) {
    errors.push('Phone number is required');
  } else if (!isValidPhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const submission: FormSubmission = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateSubmission(submission);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', {
      errors,
      values: submission,
    });
    return;
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        submission.firstName.trim(),
        submission.lastName.trim(),
        submission.streetAddress.trim(),
        submission.city.trim(),
        submission.stateProvince.trim(),
        submission.postalCode.trim(),
        submission.country.trim(),
        submission.email.trim(),
        submission.phone.trim(),
      ]
    );

    // Save database after insert
    saveDatabase();
  }

  // Redirect to thank you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(submission.firstName.trim())}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Serve static files
app.use('/public', express.static(path.resolve('public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Server setup
let server: ReturnType<typeof app.listen> | null = null;

async function startServer(): Promise<void> {
  await initializeDatabase();

  server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });

  // Graceful shutdown
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
  if (server) {
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Start server only when run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, server, shutdown, startServer };
