/**
 * Encode plain text to Base64 using the canonical Base64 alphabet
 * (A-Z, a-z, 0-9, +, /) with padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function validateBase64Chars(input: string): void {
  const validPattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validPattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
}

function validatePadding(input: string): void {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return;
  }
  if (paddingIndex < input.length - 2) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
}

function validateDecodingResult(trimmed: string, buffer: Buffer): void {
  if (buffer.length === 0 && trimmed.length > 0 && trimmed !== '' && 
      trimmed.replace(/=+$/, '') !== '' && !trimmed.match(/^[A-Za-z0-9+/]{2}$/)) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding).
 * Rejects invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (trimmed.length === 0) {
    throw new Error('Base64 input cannot be empty');
  }

  validateBase64Chars(trimmed);
  validatePadding(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    validateDecodingResult(trimmed, buffer);
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
