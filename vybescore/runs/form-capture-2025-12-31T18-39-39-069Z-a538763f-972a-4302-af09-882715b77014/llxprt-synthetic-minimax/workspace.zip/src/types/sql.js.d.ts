declare module 'sql.js' {
  const initSqlJs: () => Promise<{
    Database: new(buffer?: Uint8Array) => any;
  }>;
  export default initSqlJs;
  export { Database };
}