import express, { Request, Response } from 'express';
import path from 'path';
import initSqlJs from 'sql.js';
import fs from 'fs';

type DatabaseType = any;

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

interface SubmissionErrors {
  [key: string]: string;
}

// Database setup
let db: DatabaseType | null = null;

async function initializeDatabase(): Promise<void> {
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  const schemaPath = path.join(__dirname, '../db/schema.sql');
  
  try {
    const SQL = await initSqlJs();
    
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      
      // Load and execute schema
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db?.exec(schema);
      }
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Write initial database file
      if (db) {
        const dbBuffer = db.export();
        fs.writeFileSync(dbPath, dbBuffer);
      }
    }
  } catch (error) {
    console.error('Database initialization error:', error);
    process.exit(1);
  }
}

// Validation functions
function validateFormData(data: FormData): SubmissionErrors {
  const errors: SubmissionErrors = {};
  
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvinceRegion?.trim()) {
    errors.stateProvinceRegion = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!/^[A-Za-z0-9\s-]{3,15}$/.test(data.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phoneNumber?.trim()) {
    errors.phoneNumber = 'Phone number is required';
  } else if (!/^\+?[0-9\s\-()]{7,20}$/.test(data.phoneNumber.trim())) {
    errors.phoneNumber = 'Please enter a valid phone number';
  }
  
  return errors;
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {} as FormData,
    title: 'Contact Us - Definitely Not A Scam'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phoneNumber: req.body.phoneNumber || ''
  };
  
  const errors = validateFormData(formData);
  
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData,
      title: 'Contact Us - Fix Errors'
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    // Insert submission
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvinceRegion.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phoneNumber.trim()
    ]);
    
    stmt.free();
    
    // Save database to file
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    if (db) {
      const dbBuffer = db.export();
      fs.writeFileSync(dbPath, dbBuffer);
    }
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Submission error:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred. Please try again.' },
      formData,
      title: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You! (For Falling For It)'
  });
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Initialize database and start server
let serverInstance: import('http').Server | null = null;

function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Closing server gracefully...`);
  
  if (db) {
    try {
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  if (serverInstance) {
    serverInstance.close(() => {
      console.log('Server closed.');
      process.exit(0);
    });
  }
}

(async () => {
  try {
    await initializeDatabase();
    
    serverInstance = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see our definitely-not-a-scam contact form`);
    });
    
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Server startup error:', error);
    process.exit(1);
  }
})();
