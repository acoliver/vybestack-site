import { spawn } from 'child_process';

describe('Form Capture Public Tests', () => {
  let serverProcess: NodeJS.ChildProcess;
  const PORT = 3536;

  beforeAll(async () => {
    // Start the server
    serverProcess = spawn('npm', ['run', 'build'], {
      stdio: 'pipe'
    });

    await new Promise((resolve) => {
      setTimeout(resolve, 2000);
    });

    // Start the built server
    serverProcess = spawn('node', ['dist/server.js'], {
      env: { ...process.env, PORT: PORT.toString() },
      stdio: 'pipe'
    });

    // Wait for server to start
    await new Promise((resolve) => {
      setTimeout(resolve, 3000);
    });
  });

  afterAll(() => {
    if (serverProcess) {
      serverProcess.kill();
    }
  });

  describe('Server Endpoints', () => {
    test('should respond on GET /', async () => {
      const response = await fetch(`http://localhost:${PORT}/`);
      expect(response.status).toBe(200);
      
      const html = await response.text();
      expect(html).toContain('Definitely Not A Scam Contact Form');
      expect(html).toContain('firstName');
      expect(html).toContain('lastName');
    });

    test('should serve CSS file', async () => {
      const response = await fetch(`http://localhost:${PORT}/styles.css`);
      expect(response.status).toBe(200);
      
      const css = await response.text();
      expect(css).toContain('body');
      expect(css).toContain('container');
    });
  });

  describe('Form Validation', () => {
    test('should handle empty submission', async () => {
      const formData = new URLSearchParams();
      
      const response = await fetch(`http://localhost:${PORT}/submit`, {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      expect(response.status).toBe(400);
      
      const html = await response.text();
      expect(html).toContain('Please fix the following errors');
    });

    test('should handle invalid email', async () => {
      const formData = new URLSearchParams();
      formData.append('firstName', 'John');
      formData.append('lastName', 'Doe');
      formData.append('streetAddress', '123 Main St');
      formData.append('city', 'Anytown');
      formData.append('stateProvinceRegion', 'State');
      formData.append('postalCode', '12345');
      formData.append('country', 'USA');
      formData.append('email', 'not-an-email');
      formData.append('phoneNumber', '123-456-7890');

      const response = await fetch(`http://localhost:${PORT}/submit`, {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      expect(response.status).toBe(400);
      
      const html = await response.text();
      expect(html).toContain('valid email address');
    });
  });

  describe('Thank You Page', () => {
    test('should respond on GET /thank-you', async () => {
      const response = await fetch(`http://localhost:${PORT}/thank-you`);
      expect(response.status).toBe(200);
      
      const html = await response.text();
      expect(html).toContain('Thank You');
      expect(html).toContain('Falling For It');
    });
  });
});
