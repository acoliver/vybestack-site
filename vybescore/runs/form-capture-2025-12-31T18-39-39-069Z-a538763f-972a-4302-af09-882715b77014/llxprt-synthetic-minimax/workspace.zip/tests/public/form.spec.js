const http = require('http');

console.log('Starting Form Capture Public Tests...');

const PORT = 3537;
let serverProcess;

// Helper function to make HTTP requests
function makeRequest(path, method = 'GET', data = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: PORT,
      path: path,
      method: method,
      headers: data ? {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(data)
      } : {}
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        resolve({
          status: res.statusCode,
          body: body
        });
      });
    });

    req.on('error', reject);
    
    if (data) {
      req.write(data);
    }
    
    req.end();
  });
}

// Test suite
async function runTests() {
  try {
    console.log('Test 1: GET / should return 200');
    const homeResponse = await makeRequest('/');
    if (homeResponse.status !== 200) {
      throw new Error(`Expected 200, got ${homeResponse.status}`);
    }
    if (!homeResponse.body.includes('Definitely Not A Scam Contact Form')) {
      throw new Error('Home page missing expected content');
    }
    if (!homeResponse.body.includes('firstName') || !homeResponse.body.includes('lastName')) {
      throw new Error('Form missing expected fields');
    }
    console.log('[OK] Test 1 passed');

    console.log('Test 2: GET /styles.css should return 200');
    const cssResponse = await makeRequest('/styles.css');
    if (cssResponse.status !== 200) {
      throw new Error(`Expected 200, got ${cssResponse.status}`);
    }
    if (!cssResponse.body.includes('body') || !cssResponse.body.includes('container')) {
      throw new Error('CSS missing expected content');
    }
    console.log('[OK] Test 2 passed');

    console.log('Test 3: POST /submit with empty data should return 400');
    const emptyResponse = await makeRequest('/submit', 'POST', '');
    if (emptyResponse.status !== 400) {
      throw new Error(`Expected 400, got ${emptyResponse.status}`);
    }
    if (!emptyResponse.body.includes('Please fix the following errors')) {
      throw new Error('Validation errors missing');
    }
    console.log('[OK] Test 3 passed');

    console.log('Test 4: POST /submit with invalid email should return 400');
    const formData = 'firstName=John&lastName=Doe&streetAddress=123 Main St&city=Anytown&stateProvinceRegion=State&postalCode=12345&country=USA&email=not-an-email&phoneNumber=123-456-7890';
    const invalidEmailResponse = await makeRequest('/submit', 'POST', formData);
    if (invalidEmailResponse.status !== 400) {
      throw new Error(`Expected 400, got ${invalidEmailResponse.status}`);
    }
    if (!invalidEmailResponse.body.includes('valid email address')) {
      throw new Error('Email validation error missing');
    }
    console.log('[OK] Test 4 passed');

    console.log('Test 5: GET /thank-you should return 200');
    const thankYouResponse = await makeRequest('/thank-you');
    if (thankYouResponse.status !== 200) {
      throw new Error(`Expected 200, got ${thankYouResponse.status}`);
    }
    if (!thankYouResponse.body.includes('Thank You') || !thankYouResponse.body.includes('Falling For It')) {
      throw new Error('Thank you page missing expected content');
    }
    console.log('[OK] Test 5 passed');

    console.log('\n All tests passed!');
    
  } catch (error) {
    console.error('\n[ERROR] Test failed:', error.message);
    process.exit(1);
  }
}

// Start server and run tests
(async () => {
  try {
    const { spawn } = require('child_process');
    
    console.log('Building project...');
    const buildProcess = spawn('npm', ['run', 'build'], {
      stdio: 'inherit'
    });

    await new Promise((resolve) => {
      buildProcess.on('exit', (code) => {
        if (code !== 0) {
          throw new Error('Build failed');
        }
        resolve();
      });
    });

    console.log('Starting server...');
    serverProcess = spawn('node', ['dist/server.js'], {
      env: { ...process.env, PORT: PORT.toString() },
      stdio: 'inherit'
    });

    // Wait for server to start
    await new Promise((resolve) => setTimeout(resolve, 3000));

    await runTests();

    if (serverProcess) {
      serverProcess.kill();
    }
    
    console.log('All tests completed successfully!');

  } catch (error) {
    console.error('Test suite error:', error);
    if (serverProcess) {
      serverProcess.kill();
    }
    process.exit(1);
  }
})();