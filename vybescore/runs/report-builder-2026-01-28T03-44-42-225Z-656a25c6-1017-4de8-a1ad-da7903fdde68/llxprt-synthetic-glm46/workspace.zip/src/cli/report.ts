#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  output?: string;
  includeTotals?: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: CliArgs = {
    inputFile: '',
    format: '',
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
    } else if (result.inputFile === '') {
      result.inputFile = arg;
      i += 1;
    } else {
      console.error(`Error: Unexpected argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!result.inputFile) {
    console.error('Error: Input file is required');
    process.exit(1);
  }

  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (string expected)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (string expected)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (array expected)');
  }

  const entries = obj.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid "label" field (string expected)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid "amount" field (number expected)`);
    }
  }

  return data as ReportData;
}

function loadJsonFile(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArguments();

    // Validate format
    const supportedFormats = ['markdown', 'text'];
    if (!supportedFormats.includes(args.format)) {
      console.error(`Unsupported format: ${args.format}`);
      console.error(`Supported formats: ${supportedFormats.join(', ')}`);
      process.exit(1);
    }

    // Load and validate data
    const reportData = loadJsonFile(args.inputFile);

    // Select renderer
    const renderer = args.format === 'markdown' ? markdownRenderer : textRenderer;

    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals || false,
    };
    const output = renderer.render(reportData, options);

    // Write output
    if (args.output) {
      writeFileSync(args.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }

  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unexpected error:', error);
    }
    process.exit(1);
  }
}

main();
