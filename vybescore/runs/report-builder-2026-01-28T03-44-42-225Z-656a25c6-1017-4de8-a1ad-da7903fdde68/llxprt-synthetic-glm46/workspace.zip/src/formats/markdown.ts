import { ReportData, RenderOptions, ReportRenderer } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries
  lines.push('## Entries');
  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- **${entry.label}** — ${formattedAmount}`);
  }

  // Totals
  if (options.includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    lines.push(`**Total:** ${formattedTotal}`);
  }

  return lines.join('\n');
}

export const markdownRenderer: ReportRenderer = {
  render: renderMarkdown,
};