import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam === undefined) {
      page = 1; // Default page is 1
    } else {
      const numPage = Number(pageParam);
      if (isNaN(numPage) || !Number.isInteger(numPage) || numPage <= 0 || numPage > 1000) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
      page = numPage;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam === undefined) {
      limit = 5; // Default limit is 5
    } else {
      const numLimit = Number(limitParam);
      if (isNaN(numLimit) || !Number.isInteger(numLimit) || numLimit <= 0 || numLimit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      limit = numLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
