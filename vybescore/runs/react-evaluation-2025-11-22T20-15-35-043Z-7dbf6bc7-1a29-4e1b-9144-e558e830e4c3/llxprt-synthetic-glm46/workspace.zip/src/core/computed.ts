/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    _subjects: new Set(),
    _observers: new Set(),
  }
  
  // Initialize the computed value by running the update function
  // This will track all dependencies during the first run
  try {
    updateObserver(o)
  } catch (e) {
    console.warn('Error initializing computed observer:', e)
  }
  
  // Return a getter function that re-evaluates when its dependencies change
  const getter: GetterFn<T> = (): T => {
    const currentObserver = getActiveObserver()
    try {
      // If this getter is being called from another observer,
      // track the dependency relationship
      if (currentObserver && 'updateFn' in currentObserver && currentObserver.updateFn) {
        if (!currentObserver._subjects) {
          currentObserver._subjects = new Set()
        }
        currentObserver._subjects.add(o as unknown as Subject<unknown>)
        
        // Track this computed as a dependency of the current observer
        // and the current observer as dependent on this computed
        if (!o._observers) {
          o._observers = new Set()
        }
        o._observers.add(currentObserver as Observer<unknown>)
      }
    } catch (e) {
      console.warn('Error tracking dependencies in computed getter:', e)
    }
    
    return o.value as T
  }
  
  // Store a reference to the observer for direct updates
  ;(getter as unknown as { __observer: Observer<T> }).__observer = o
  
  return getter
}