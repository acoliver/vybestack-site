/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    _subjects: new Set(),
    _observers: new Set(),
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  // Add cleanup function to properly manage memory
  const unsubscribe = (): void => {
    if (disposed) return
    disposed = true
    
    // Clear all subscriptions to subjects
    if (observer._subjects) {
      observer._subjects.forEach(subject => {
        if (subject._observers) {
          subject._observers.delete(observer as unknown as Observer<unknown>)
        }
      })
      observer._subjects.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value as T
  }
  
  return unsubscribe
}