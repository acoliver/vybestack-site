/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    _observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && 'updateFn' in observer && observer.updateFn) {
      // Track the subject this observer depends on
      if (!observer._subjects) {
        observer._subjects = new Set()
      }
      observer._subjects.add(s as Subject<unknown>)
      
      // Track the observer that depends on this subject
      s._observers!.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Always update the value to trigger notifications
    s.value = nextValue
    // Notify all observers that depend on this subject
    
    if (s._observers) {
      // Copy to avoid issues with set modification during iteration
      const observers = Array.from(s._observers)
      observers.forEach(observer => {
        // Notify each observer of the change
        notifyObservers(observer as Observer<unknown>)
      })
    }
    
    return s.value
  }

  return [read, write]
}