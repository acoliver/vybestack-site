/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _subjects?: Set<Subject<unknown>>
  _observers?: Set<Observer<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  _observers?: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export { activeObserver }

export function updateObserver<T>(observer: Observer<T>): void {
  // Clear existing subscriptions to track new ones, but keep the set reference
  if (!observer._subjects) {
    observer._subjects = new Set()
  }
  if (!observer._observers) {
    observer._observers = new Set()
  }
  
  // Clear dependencies on subjects so we can track the current ones
  const oldSubjects = Array.from(observer._subjects)
  observer._subjects.clear()
  
  // Remove this observer from old subjects (cleanup)
  oldSubjects.forEach(subject => {
    if (subject._observers) {
      subject._observers.delete(observer as Observer<unknown>)
    }
  })
  
  const previous = activeObserver
  activeObserver = observer
  try {
    // Update the value which will trigger dependency tracking
    // This will repopulate observer._subjects with current dependencies
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Function to trigger updates to all dependent observers
export function notifyObservers(observer: Observer<unknown>, visited = new Set<Observer<unknown>>()): void {
  if (visited.has(observer)) return
  visited.add(observer)
  
  // Skip observers without update functions
  if (!observer.updateFn) return
  
  // Re-run the observer's update function with dependency clearing
  // This will recalculate dependencies and notify them
  updateObserver(observer)
  
  // Get direct observers of this computed observer (if applicable)
  if (observer._observers) {
    // Copy to avoid issues with set modification during iteration
    const observers = Array.from(observer._observers)
    // Filter out the current observer to avoid infinite recursion
observers.filter(obs => obs !== observer && 'updateFn' in obs && typeof obs.updateFn === 'function').forEach(obs => {
      notifyObservers(obs as Observer<unknown>, new Set(visited)) // Pass a new set to avoid contamination
    })
  }
}
