import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

const INVALID_BASE64_MSG = 'Invalid Base64 format';

describe('Base64 helpers (hidden)', () => {
  describe('encode', () => {
    it('encodes empty string', () => {
      expect(encode('')).toBe('');
    });

    it('encodes ASCII text', () => {
      expect(encode('hello')).toBe('aGVsbG8=');
    });

    it('encodes Unicode text', () => {
      // Use escape sequence for emoji to avoid potential compilation issues
      const emoji = '\ud83d\udc4b'; // 
      const expectedResult = '8J+Riw==';
      expect(encode(emoji)).toBe(expectedResult);
    });

    it('produces correct padding', () => {
      expect(encode('A')).toBe('QQ==');
      expect(encode('AB')).toBe('QUI=');
      expect(encode('ABC')).toBe('QUJD');
      expect(encode('ABCD')).toBe('QUJDRA==');
    });
  });

  describe('decode', () => {
    it('decodes empty string', () => {
      expect(decode('')).toBe('');
    });

    it('decodes standard Base64 with padding', () => {
      expect(decode('aGVsbG8=')).toBe('hello');
    });

    it('decodes Base64 without padding', () => {
      expect(decode('aGVsbG8')).toBe('hello');
    });

    it('decodes Unicode content', () => {
      const expectedEmoji = '\ud83d\udc4b'; // 
      expect(decode('8J+Riw==')).toBe(expectedEmoji);
    });

    it('decodes real-world example without padding', () => {
      expect(decode('Zm9vL2Jhcg==')).toBe('foo/bar');
      expect(decode('Zm9vL2Jhcg')).toBe('foo/bar');
    });

    it('rejects invalid Base64 characters', () => {
      expect(() => decode('!!!')).toThrow(INVALID_BASE64_MSG);
    });

    it('rejects invalid padding in middle', () => {
      expect(() => decode('a=GVsbG8=')).toThrow(INVALID_BASE64_MSG);
    });

    it('rejects wrong number of padding characters', () => {
      const inputWithMultiplePadding = 'aGVsbG8===';
      expect(() => decode(inputWithMultiplePadding)).toThrow(INVALID_BASE64_MSG);
    });

    it('rejects padding not at end', () => {
      const inputWithMorePadding = 'aGVsbG8====';
      expect(() => decode(inputWithMorePadding)).toThrow(INVALID_BASE64_MSG);
    });

    it('rejects invalid non-base64 strings', () => {
      expect(() => decode('not-base64')).toThrow(INVALID_BASE64_MSG);
    });

    it('rejects strings with whitespace', () => {
      expect(() => decode('aGVsbG8= ')).toThrow(INVALID_BASE64_MSG);
    });
  });
});