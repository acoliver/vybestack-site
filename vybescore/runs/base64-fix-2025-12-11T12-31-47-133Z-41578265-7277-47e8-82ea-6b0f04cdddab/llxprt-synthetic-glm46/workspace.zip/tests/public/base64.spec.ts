import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

const TEST_STRING = 'hello';
const TEST_ENCODED = 'aGVsbG8=';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode(TEST_STRING);
    expect(result).toBe(TEST_ENCODED);
  });

  it('decodes standard Base64 text', () => {
    const result = decode(TEST_ENCODED);
    expect(result).toBe(TEST_STRING);
  });
});
