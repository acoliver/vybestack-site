const INVALID_BASE64_FORMAT = 'Invalid Base64 format';
const INVALID_BASE64_PADDING = 'Invalid Base64 padding';
const INVALID_BASE64_LENGTH = 'Invalid Base64 length';

/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function validateBase64Format(input: string): boolean {
  // Only allow characters from the standard Base64 alphabet
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

function validateBase64Padding(input: string): { valid: boolean; error?: string } {
  const paddingIndex = input.indexOf('=');
  
  if (paddingIndex === -1) {
    return { valid: true };
  }
  
  // Padding can only appear at the end
  const paddingPart = input.substring(paddingIndex);
  if (!/^(={1,2})$/.test(paddingPart)) {
    return { valid: false, error: INVALID_BASE64_PADDING };
  }
  
  // When padding is present, total length must be a multiple of 4
  if (input.length % 4 !== 0) {
    return { valid: false, error: INVALID_BASE64_PADDING };
  }
  
  // Padding rules:
  if (paddingPart === '=' && input.length > 1 && input[input.length - 2] === '=') {
    return { valid: false, error: INVALID_BASE64_PADDING };
  }
  
  return { valid: true };
}

function validateBase64Length(input: string): boolean {
  // Empty string is valid and allow any other valid length 
  // Let Buffer handle the actual decoding to determine if it's valid
  return input === '' || true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input follows standard Base64 format and rejects invalid inputs.
 */
export function decode(input: string): string {
  // Special case: empty string is valid and decodes to empty string
  if (input === '') {
    return '';
  }

  if (!validateBase64Format(input)) {
    throw new Error(INVALID_BASE64_FORMAT);
  }

  const paddingValidation = validateBase64Padding(input);
  if (!paddingValidation.valid) {
    throw new Error(paddingValidation.error);
  }

  if (!validateBase64Length(input)) {
    throw new Error(INVALID_BASE64_LENGTH);
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}