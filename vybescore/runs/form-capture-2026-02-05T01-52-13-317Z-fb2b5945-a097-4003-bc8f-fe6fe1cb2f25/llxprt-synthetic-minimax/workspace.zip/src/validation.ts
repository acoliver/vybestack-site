export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data: FormData;
}

/**
 * Validate email format using a simple regex
 */
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate phone number format
 * Accepts international formats with digits, spaces, parentheses, dashes, and leading @
 */
function isValidPhoneNumber(phone: string): boolean {
  // Remove leading @ if present
  const cleanPhone = phone.trim().replace(/^@/, '');
  
  // Check if it contains only allowed characters: digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(cleanPhone) && cleanPhone.length > 0;
}

/**
 * Validate postal code format
 * Accepts alphanumeric strings (handles UK "SW1A 1AA" and Argentine formats)
 */
function isValidPostalCode(postalCode: string): boolean {
  // Remove spaces and check if alphanumeric
  const cleanCode = postalCode.replace(/\s/g, '');
  const postalRegex = /^[A-Za-z0-9]+$/;
  return postalRegex.test(cleanCode) && cleanCode.length > 0;
}

/**
 * Validate required field is not empty
 */
function isRequired(value: string): boolean {
  return value.trim().length > 0;
}

/**
 * Main validation function
 */
export function validateFormData(formData: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Check required fields
  const requiredFields: Array<keyof FormData> = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvinceRegion',
    'postalCode',
    'country',
    'email',
    'phoneNumber'
  ];

  requiredFields.forEach(field => {
    const value = formData[field];
    if (!isRequired(value)) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  });

  // Validate email format
  if (formData.email && !isValidEmail(formData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Validate phone number format
  if (formData.phoneNumber && !isValidPhoneNumber(formData.phoneNumber)) {
    errors.push({
      field: 'phoneNumber',
      message: 'Please enter a valid phone number'
    });
  }

  // Validate postal code format
  if (formData.postalCode && !isValidPostalCode(formData.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: formData
  };
}