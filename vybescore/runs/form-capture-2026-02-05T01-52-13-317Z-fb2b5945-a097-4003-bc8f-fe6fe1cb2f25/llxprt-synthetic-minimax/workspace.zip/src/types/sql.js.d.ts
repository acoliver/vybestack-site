declare module 'sql.js' {
  interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    bind(values: unknown[]): void;
    step(): boolean;
    get(): unknown[] | null;
    getColumnNames(): string[];
    free(): void;
    run(values: unknown[]): void;
  }

  interface SqlJsModule {
    Database: {
      new (buffer?: Uint8Array): Database;
    };
  }

  interface InitFunction {
    (buffer?: Uint8Array): Promise<SqlJsModule>;
  }

  const SqlJs: InitFunction;
  export = SqlJs;
}