import express from 'express';
import * as path from 'path';
import { databaseManager } from './database';
import { validateFormData, FormData, ValidationError } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Set up view engine
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// GET / - Display the contact form
app.get('/', (req: express.Request, res: express.Response) => {
  const errors: ValidationError[] = (req.query.errors ? JSON.parse(req.query.errors as string) : []) || [];
  const formData: FormData = (req.query.formData ? JSON.parse(req.query.formData as string) : {}) || {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvinceRegion: '',
    postalCode: '',
    country: '',
    email: '',
    phoneNumber: ''
  };

  res.render('contact', {
    title: 'Friendly Contact Form',
    errors,
    formData
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phoneNumber: req.body.phoneNumber || ''
  };

  // Validate the form data
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    // Redirect back to form with errors and original data
    const errorsParam = encodeURIComponent(JSON.stringify(validation.errors));
    const formDataParam = encodeURIComponent(JSON.stringify(validation.data));
    return res.redirect(`/?errors=${errorsParam}&formData=${formDataParam}`);
  }

  try {
    // Insert into database
    databaseManager.insertSubmission(formData);
    databaseManager.saveToDisk();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    // Redirect back to form with error message
    const errorsParam = encodeURIComponent(JSON.stringify([{ field: 'general', message: 'Failed to save your submission. Please try again.' }]));
    const formDataParam = encodeURIComponent(JSON.stringify(formData));
    return res.redirect(`/?errors=${errorsParam}&formData=${formDataParam}`);
  }
});

// GET /thank-you - Display thank you page
app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  databaseManager.close();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully...');
  databaseManager.close();
  process.exit(0);
});

// Start server after database initialization
async function startServer(): Promise<void> {
  try {
    await databaseManager.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
