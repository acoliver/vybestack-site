import * as sql from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

interface DatabaseState {
  db: any | null;
  dbPath: string;
  schemaPath: string;
}

class DatabaseManager {
  private state: DatabaseState = {
    db: null,
    dbPath: path.join(process.cwd(), 'data', 'submissions.sqlite'),
    schemaPath: path.join(process.cwd(), 'db', 'schema.sql')
  };

  /**
   * Initialize the database, creating it if it doesn't exist
   */
  async initialize(): Promise<void> {
    try {
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.state.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Initialize sql.js and get the database constructor
      const SqlJsModule = await sql.default();
      const DatabaseClass = (SqlJsModule as any).Database;
      
      // Load existing database or create new one
      let sqlBuffer: Uint8Array | undefined = undefined;
      if (fs.existsSync(this.state.dbPath)) {
        const dbFile = fs.readFileSync(this.state.dbPath);
        sqlBuffer = new Uint8Array(dbFile);
      }

      this.state.db = new DatabaseClass(sqlBuffer);

      // Run schema initialization if needed
      await this.initializeSchema();
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw error;
    }
  }

  /**
   * Initialize the database schema if the table doesn't exist
   */
  private async initializeSchema(): Promise<void> {
    if (!this.state.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Read schema file
      const schemaSql = fs.readFileSync(this.state.schemaPath, 'utf-8');
      
      // Execute schema creation
      this.state.db.exec(schemaSql);
    } catch (error) {
      console.error('Schema initialization failed:', error);
      throw error;
    }
  }

  /**
   * Insert a new submission into the database
   */
  insertSubmission(data: SubmissionData): void {
    if (!this.state.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.state.db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province_region, postal_code, country, email, phone_number)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvinceRegion,
        data.postalCode,
        data.country,
        data.email,
        data.phoneNumber
      ]);

      stmt.free();
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  /**
   * Save the database to disk
   */
  saveToDisk(): void {
    if (!this.state.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data = this.state.db.export();
      fs.writeFileSync(this.state.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database to disk:', error);
      throw error;
    }
  }

  /**
   * Close the database connection
   */
  close(): void {
    if (this.state.db) {
      this.state.db.close();
      this.state.db = null;
    }
  }
}

// Export singleton instance
export const databaseManager = new DatabaseManager();