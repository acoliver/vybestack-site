import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const goToPage = (page: number): void => {
    setCurrentPage(page);
  };

  const goToNextPage = (): void => {
    goToPage(currentPage + 1);
  };

  const goToPreviousPage = (): void => {
    goToPage(currentPage - 1);
  };

  const hasPreviousPage = currentPage > 1;
  const hasNextPage = data.hasNext;

  const renderEmptyState = (): JSX.Element => {
    return <p>No items found.</p>;
  };

  return (
    <section>
      <h1>Inventory</h1>
      
      {data.items.length === 0 ? (
        renderEmptyState()
      ) : (
        <>
          <InventoryList items={data.items} />
          
          <nav aria-label="Pagination">
            <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', marginTop: '1rem' }}>
              <button
                onClick={goToPreviousPage}
                disabled={!hasPreviousPage}
                aria-label="Previous page"
              >
                Previous
              </button>
              
              <span>Page {currentPage}</span>
              
              <button
                onClick={goToNextPage}
                disabled={!hasNextPage}
                aria-label="Next page"
              >
                Next
              </button>
            </div>
            
            {error && (
              <div role="alert" style={{ color: 'red', marginTop: '0.5rem' }}>
                {error}
              </div>
            )}
            
            <div style={{ fontSize: '0.875rem', color: '#666', marginTop: '0.5rem' }}>
              Showing {data.items.length} of {data.total} items
            </div>
          </nav>
        </>
      )}
    </section>
  );
}
