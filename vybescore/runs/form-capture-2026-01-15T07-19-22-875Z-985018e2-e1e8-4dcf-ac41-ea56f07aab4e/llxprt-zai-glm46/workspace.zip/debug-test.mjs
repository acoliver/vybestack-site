import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

// Import after vitest is loaded
let app, startServer, stopServer;
beforeAll(async () => {
  const server = await import('./dist/server.js');
  app = server.app;
  startServer = server.startServer;
  stopServer = server.stopServer;
  await startServer();
});

afterAll(() => {
  stopServer();
});

describe('debug test', () => {
  it('checks cheerio import', () => {
    console.log('cheerio in test:', cheerio);
    console.log('cheerio.load:', typeof cheerio.load);
    console.log('cheerio keys:', Object.keys(cheerio));
    expect(typeof cheerio.load).toBe('function');
  });

  it('renders the form', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').length).toBe(1);
  });
});
