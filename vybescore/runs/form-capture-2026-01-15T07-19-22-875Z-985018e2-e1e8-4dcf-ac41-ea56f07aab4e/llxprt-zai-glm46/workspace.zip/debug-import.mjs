import request from 'supertest';
import * as cheerio from 'cheerio';
import { app, startServer, stopServer } from './dist/server.js';

async function test() {
  await startServer();
  try {
    const response = await request(app).get('/');
    console.log('Status:', response.status);
    console.log('Has text:', !!response.text);
    console.log('cheerio:', typeof cheerio);
    console.log('cheerio.load:', typeof cheerio.load);
    console.log('cheerio.default:', typeof cheerio.default);
    console.log('cheerio.default.load:', typeof cheerio.default?.load);
    
    const $ = cheerio.load(response.text);
    console.log('firstName inputs:', $('input[name="firstName"]').length);
    console.log('SUCCESS!');
  } finally {
    stopServer();
  }
}

test();
