import { fileURLToPath } from 'node:url';
import path from 'node:path';

export const getViewsPath = (): string => {
  // When running from source (src/), templates are in src/templates/
  // When running compiled (dist/), templates should be in dist/templates/
  const distPath = path.join(path.dirname(fileURLToPath(import.meta.url)), 'templates');
  return distPath;
};
