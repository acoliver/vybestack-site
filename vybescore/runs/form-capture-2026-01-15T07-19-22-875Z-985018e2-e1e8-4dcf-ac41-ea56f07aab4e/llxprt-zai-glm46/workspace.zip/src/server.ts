import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const __filename = fileURLToPath(import.meta.url);
const TEMPLATE_DIR = path.join(path.dirname(__filename), 'templates');

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and hyphens' });
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Email must be valid' });
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +' });
  }

  return errors;
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  const dir = path.dirname(DB_PATH);
  
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

app.set('views', TEMPLATE_DIR);
app.set('view engine', 'ejs');

app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('form.ejs', {
      errors: errors.map((e) => e.message),
      values: formData
    });
  }

  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || ''
      ]
    );

    saveDatabase(db);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500);
    res.render('form.ejs', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you.ejs', {
    firstName: 'Friend'
  });
});

app.use((err: Error, _req: Request, res: Response) => {
  console.error('Error:', err);
  res.status(500).send('Internal Server Error');
});

let server: ReturnType<typeof app.listen> | null = null;

async function startServer(): Promise<void> {
  db = await initializeDatabase();
  console.log('Database initialized');

  return new Promise<void>((resolve) => {
    server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
      resolve();
    });
  });
}

function stopServer(): void {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }

  if (server) {
    server.close(() => {
      console.log('Server closed');
    });
  }
}

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  stopServer();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  stopServer();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, startServer, stopServer };
export default app;
