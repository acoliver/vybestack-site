import { describe, expect, it } from 'vitest';
import { execSync } from 'child_process';
import { readFileSync, unlinkSync, writeFileSync } from 'fs';
import { join } from 'path';

// Helper function to normalize whitespace for consistent test comparison
function normalize(str: string): string {
  return str.trim().replace(/\s+/g, ' ');
}

// Helper function to execute the CLI
function runCLI(args: string[]): { stdout: string; stderr: string } {
  try {
    const result = execSync(`node dist/cli/report.js ${args.join(' ')}`, {
      encoding: 'utf8',
      cwd: process.cwd(),
    });
    return { stdout: result, stderr: '' };
  } catch (error: any) {
    return { stdout: error.stdout, stderr: error.stderr };
  }
}

describe('report CLI (public smoke)', () => {
  // Expected test data values
  const title = 'Quarterly Financial Summary';
  const summary = 'Highlights include record revenue across regions and a healthy outlook for the next quarter.';
  const entries = [
    { label: 'North Region', amount: 12345.67 },
    { label: 'South Region', amount: 23456.78 },
    { label: 'West Region', amount: 34567.89 }
  ];
  const total = 70370.34;

  it('renders markdown format to stdout', () => {
    const result = runCLI(['fixtures/data.json', '--format', 'markdown']);
    expect(result.stderr).toBe('');
    
    const expectedMarkdown = `# ${title}

${summary}

## Entries

- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;
    
    expect(normalize(result.stdout)).toBe(normalize(expectedMarkdown));
  });

  it('renders text format to stdout', () => {
    const result = runCLI(['fixtures/data.json', '--format', 'text']);
    expect(result.stderr).toBe('');
    
    const expectedText = `${title}

${summary}

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;
    
    expect(normalize(result.stdout)).toBe(normalize(expectedText));
  });

  it('renders markdown format with totals', () => {
    const result = runCLI(['fixtures/data.json', '--format', 'markdown', '--includeTotals']);
    expect(result.stderr).toBe('');
    
    const expectedMarkdown = `# ${title}

${summary}

## Entries

- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $${total.toFixed(2)}`;
    
    expect(normalize(result.stdout)).toBe(normalize(expectedMarkdown));
  });

  it('renders text format with totals', () => {
    const result = runCLI(['fixtures/data.json', '--format', 'text', '--includeTotals']);
    expect(result.stderr).toBe('');
    
    const expectedText = `${title}

${summary}

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89
Total: $${total.toFixed(2)}`;
    
    expect(normalize(result.stdout)).toBe(normalize(expectedText));
  });

  it('writes output to file when --output is specified', () => {
    const outputPath = 'test-output.md';
    const result = runCLI(['fixtures/data.json', '--format', 'markdown', '--output', outputPath]);
    expect(result.stderr).toBe('');
    expect(result.stdout).toBe('');
    
    const outputFile = readFileSync(outputPath, 'utf8');
    const expectedMarkdown = `# ${title}

${summary}

## Entries

- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;
    
    expect(normalize(outputFile)).toBe(normalize(expectedMarkdown));
    
    // Clean up
    unlinkSync(outputPath);
  });

  it('rejects unsupported format', () => {
    const result = runCLI(['fixtures/data.json', '--format', 'xml']);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('Unsupported format');
  });

  it('provides helpful error for missing data file', () => {
    const result = runCLI(['missing.json', '--format', 'markdown']);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('ENOENT');
  });

  it('provides helpful error for malformed JSON', () => {
    const malformedPath = 'test-malformed.json';
    writeFileSync(malformedPath, '{ invalid json }');
    
    const result = runCLI([malformedPath, '--format', 'markdown']);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('Invalid JSON');
    
    // Clean up
    unlinkSync(malformedPath);
  });

  it('provides helpful error for missing required fields', () => {
    const incompletePath = 'test-incomplete.json';
    writeFileSync(incompletePath, '{"title": "Missing fields"}');
    
    const result = runCLI([incompletePath, '--format', 'markdown']);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('Error loading file');
    
    // Clean up
    unlinkSync(incompletePath);
  });
});