#!/usr/bin/env node

import fs from 'fs';
import { join } from 'path';
import type { ReportData, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): { dataFile: string; options: CliOptions } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false
  };
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      i++;
      if (!args[i] || !['markdown', 'text'].includes(args[i])) {
        console.error('Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      options.format = args[i] as 'markdown' | 'text';
    } else if (args[i] === '--output') {
      i++;
      if (!args[i]) {
        console.error('--output requires a file path');
        process.exit(1);
      }
      options.output = args[i];
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  if (!options.format) {
    console.error('--format is required');
    process.exit(1);
  }
  
  return { dataFile, options };
}

function loadDataFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid "label" field in entry');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid "amount" field in entry');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Invalid JSON in file ${filePath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error loading file ${filePath}: ${error.message}`);
    } else {
      console.error(`Unknown error loading file ${filePath}`);
    }
    process.exit(1);
  }
}

function getRenderer(format: string): ReportRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
      throw new Error('Unreachable'); // TypeScript doesn't know process.exit exits
  }
}

function main() {
  const { dataFile, options } = parseArguments();
  
  // Resolve relative paths from the CLI working directory, not from the script directory
  const dataPath = join(process.cwd(), dataFile);
  const data = loadDataFile(dataPath);
  
  const renderer = getRenderer(options.format);
  const output = renderer(data, { includeTotals: options.includeTotals });
  
  if (options.output) {
    // For output to file, treat the path as relative to the current working directory
    fs.writeFileSync(options.output, output);
  } else {
    console.log(output);
  }
}

main();
