#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): CLIOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1] as 'markdown' | 'text';
      i++; // Skip the value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = args[i + 1];
      i++; // Skip the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return {
    dataFile,
    format,
    output,
    includeTotals
  };
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate each entry
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid data: entry label must be a string');
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error('Invalid data: entry amount must be a number');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading file: ${error.message}`);
    } else {
      console.error('Error reading file: Invalid JSON');
    }
    process.exit(1);
  }
}

function formatAndOutput(data: ReportData, options: CLIOptions): void {
  let output: string;
  
  switch (options.format) {
    case 'markdown':
      output = renderMarkdown(data, options.includeTotals);
      break;
    case 'text':
      output = renderText(data, options.includeTotals);
      break;
    default:
      console.error(`Unsupported format '${options.format}'`);
      process.exit(1);
  }

  if (options.output) {
    // Write to file
    try {
      writeFileSync(options.output, output);
      console.error(`Report written to ${options.output}`);
    } catch (error) {
      console.error(`Error writing to file: ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    // Write to stdout
    process.stdout.write(output);
  }
}

function main(): void {
  const options = parseArguments();
  const data = loadAndValidateData(options.dataFile);
  formatAndOutput(data, options);
}

main();
