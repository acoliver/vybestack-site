import { ReportData } from '../types.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  const amountFormat = (amount: number): string => `$${amount.toFixed(2)}`;

  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;

  for (const entry of data.entries) {
    output += `- **${entry.label}** — ${amountFormat(entry.amount)}\n`;
  }

  if (includeTotals) {
    output += `\n**Total:** ${amountFormat(total)}\n`;
  }

  return output;
}