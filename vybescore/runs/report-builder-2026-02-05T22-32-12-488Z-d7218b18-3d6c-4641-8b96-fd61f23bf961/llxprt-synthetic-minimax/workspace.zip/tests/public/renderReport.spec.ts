import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';
import type { ReportData } from '../../src/types.js';

const sampleData: ReportData = {
  title: "Quarterly Financial Summary",
  summary: "Highlights include record revenue across regions and a healthy outlook for the next quarter.",
  entries: [
    { label: "North Region", amount: 12345.67 },
    { label: "South Region", amount: 23456.78 },
    { label: "West Region", amount: 34567.89 }
  ]
};

describe('report formatters', () => {
  describe('renderMarkdown', () => {
    it('should render markdown with totals', () => {
      const output = renderMarkdown(sampleData, true);
      
      expect(output).toContain('# Quarterly Financial Summary');
      expect(output).toContain('Highlights include record revenue');
      expect(output).toContain('## Entries');
      expect(output).toContain('- **North Region** — $12345.67');
      expect(output).toContain('- **South Region** — $23456.78');
      expect(output).toContain('- **West Region** — $34567.89');
      expect(output).toContain('**Total:** $70370.34');
    });

    it('should render markdown without totals', () => {
      const output = renderMarkdown(sampleData, false);
      
      expect(output).toContain('# Quarterly Financial Summary');
      expect(output).toContain('Highlights include record revenue');
      expect(output).toContain('## Entries');
      expect(output).toContain('- **North Region** — $12345.67');
      expect(output).toContain('- **West Region** — $34567.89');
      expect(output).not.toContain('**Total:**');
    });
  });

  describe('renderText', () => {
    it('should render text with totals', () => {
      const output = renderText(sampleData, true);
      
      expect(output).toContain('Quarterly Financial Summary');
      expect(output).toContain('Highlights include record revenue');
      expect(output).toContain('Entries:');
      expect(output).toContain('- North Region: $12345.67');
      expect(output).toContain('- South Region: $23456.78');
      expect(output).toContain('- West Region: $34567.89');
      expect(output).toContain('Total: $70370.34');
    });

    it('should render text without totals', () => {
      const output = renderText(sampleData, false);
      
      expect(output).toContain('Quarterly Financial Summary');
      expect(output).toContain('Highlights include record revenue');
      expect(output).toContain('Entries:');
      expect(output).toContain('- North Region: $12345.67');
      expect(output).toContain('- West Region: $34567.89');
      expect(output).not.toContain('Total:');
    });
  });
});

describe('report CLI (public smoke)', () => {
  it('placeholder test (implementations should add real coverage)', () => {
    expect(true).toBe(true);
  });
});
