/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      if (disposed) return prevValue || value!
      // Re-run the original function to access updated dependencies
      observer.value = updateFn(prevValue)
      return observer.value!
    },
  }
  
  // Add disposed flag for cleanup tracking
  observer._disposed = false
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  return () => {
    disposed = true
    observer._disposed = true
    
    // Execute cleanup functions to remove this observer from all dependencies
    if (observer._cleanup) {
      for (const cleanup of observer._cleanup) {
        cleanup()
      }
      observer._cleanup.clear()
    }
  }
}