/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> {
  if (equal === true) return Object.is
  if (equal === false || equal === undefined) return () => false
  if (typeof equal === 'function') return equal
  return () => false
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Store multiple observers with proper cleanup tracking
  const observers = new Set<Observer<unknown>>()
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const typedObserver = observer as Observer<unknown>
      observers.add(typedObserver)
      
      // Add cleanup method to observer for proper memory management
      if (!typedObserver._cleanup) {
        typedObserver._cleanup = new Set<() => void>()
      }
      typedObserver._cleanup.add(() => observers.delete(typedObserver))
    }
    return value
  }

  const equalFn = createEqualFn(equal)
  
  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(value, nextValue)) {
      return value
    }
    
    value = nextValue
    
    // Notify all observers, creating a copy to avoid issues if observers are modified during iteration
    const observersToNotify = Array.from(observers)
    for (const observer of observersToNotify) {
      // Skip disposed observers
      if (!observer._disposed) {
        updateObserver(observer as Observer<T>)
      }
    }
    
    return value
  }

  return [read, write]
}
