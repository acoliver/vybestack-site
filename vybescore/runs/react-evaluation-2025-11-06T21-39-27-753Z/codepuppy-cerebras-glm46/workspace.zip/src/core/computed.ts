/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((x: T, y: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  // Store observers for this computed value (similar to input)
  const observers = new Set<Observer<T>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // First update this computed value
      const result = updateFn(prevValue)
      o.value = result
      
      // Then notify all observers that depend on this computed value
      const observersToNotify = Array.from(observers)
      for (const observer of observersToNotify) {
        // Skip disposed observers
        if (!observer._disposed) {
          updateObserver(observer)
        }
      }
      
      return result
    },
  }
  
  // Initialize the value and track dependencies
  updateObserver(o)
  
  const compute = (): T => {
    // When this computed value is accessed, register any active observer
    const observer = getActiveObserver()
    if (observer) {
      const typedObserver = observer as Observer<T>
      observers.add(typedObserver)
      
      // Add cleanup method to observer for proper memory management
      if (!typedObserver._cleanup) {
        typedObserver._cleanup = new Set<() => void>()
      }
      typedObserver._cleanup.add(() => observers.delete(typedObserver))
    }
    return o.value!
  }
  
  return compute
}
