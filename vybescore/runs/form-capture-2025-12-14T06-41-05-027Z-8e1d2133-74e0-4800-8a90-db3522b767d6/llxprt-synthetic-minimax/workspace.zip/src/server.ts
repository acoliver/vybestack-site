import express, { Request, Response } from 'express';
import path from 'path';
import { getDatabase, closeDatabase, Submission } from './database.js';
import { validateForm, formatPhoneNumber, formatPostalCode, ValidationResult } from './validation.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Configure Express
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Store server instance for graceful shutdown
let serverInstance: ReturnType<typeof app.listen> | null = null;

// Routes
app.get('/', async (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    // Validate form data
    const validation: ValidationResult = validateForm(req.body);
    
    if (!validation.isValid) {
      // Re-render form with errors
      return res.status(400).render('form', {
        errors: validation.errors.map(error => error.message),
        values: validation.values
      });
    }

    // Format phone and postal code
    const formattedData: Omit<Submission, 'id' | 'createdAt'> = {
      firstName: validation.values.firstName || '',
      lastName: validation.values.lastName || '',
      streetAddress: validation.values.streetAddress || '',
      city: validation.values.city || '',
      stateProvince: validation.values.stateProvince || '',
      country: validation.values.country || '',
      email: validation.values.email || '',
      phone: formatPhoneNumber(validation.values.phone || ''),
      postalCode: formatPostalCode(validation.values.postalCode || '')
    };

    // Insert into database
    const db = await getDatabase();
    await db.insertSubmission(formattedData);

    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formattedData.firstName)}`);
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown handler
function gracefulShutdown(signal: string) {
  console.log(`
Received ${signal}. Starting graceful shutdown...`);
  
  if (serverInstance) {
    serverInstance.close(async () => {
      console.log('HTTP server closed.');
      await closeDatabase();
      console.log('Database closed.');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Handle shutdown signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer() {
  try {
    // Initialize database
    await getDatabase();
    
    serverInstance = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      console.log('Press Ctrl+C to stop the server');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
