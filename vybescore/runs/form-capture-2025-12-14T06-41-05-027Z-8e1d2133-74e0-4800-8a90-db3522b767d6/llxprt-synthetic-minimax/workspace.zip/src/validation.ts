export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  values: Record<string, string>;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: ValidationError[] = [];
  const values: Record<string, string> = {};

  // Helper function to validate required fields
  function validateRequired(field: keyof FormData, label: string): void {
    const value = (data[field] || '').trim();
    values[field] = value;
    
    if (!value) {
      errors.push({
        field,
        message: `${label} is required`
      });
    }
  }

  // Validate required fields
  validateRequired('firstName', 'First name');
  validateRequired('lastName', 'Last name');
  validateRequired('streetAddress', 'Street address');
  validateRequired('city', 'City');
  validateRequired('stateProvince', 'State / Province / Region');
  validateRequired('postalCode', 'Postal / Zip code');
  validateRequired('country', 'Country');
  validateRequired('email', 'Email');
  validateRequired('phone', 'Phone number');

  // Validate email format
  if (values.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(values.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Validate phone number format
  if (values.phone) {
    // Allow digits, spaces, parentheses, dashes, and a leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(values.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Validate postal code (alphanumeric only)
  if (values.postalCode) {
    // Allow alphanumeric strings, spaces, and dashes
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(values.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    values
  };
}

export function sanitizeInput(input: string): string {
  return input.trim().replace(/\s+/g, ' ');
}

export function formatPhoneNumber(phone: string): string {
  // Basic phone number formatting - remove extra spaces
  return sanitizeInput(phone);
}

export function formatPostalCode(postalCode: string): string {
  // Uppercase and remove extra spaces
  return sanitizeInput(postalCode).toUpperCase();
}