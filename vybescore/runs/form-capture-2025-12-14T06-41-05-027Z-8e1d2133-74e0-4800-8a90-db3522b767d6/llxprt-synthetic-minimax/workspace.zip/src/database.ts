import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';

const require = createRequire(import.meta.url);
const initSqlJs = require('sql.js');

// Type definitions for sql.js
interface DatabaseInstance {
  exec(sql: string): { values: unknown[][]; columns: string[] }[];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  bind(params: Record<string, unknown>): void;
  run(params?: unknown[]): void;
  free(): void;
  get(params?: unknown[]): unknown[];
}

interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => DatabaseInstance;
}

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  createdAt?: string;
}

export class Database {
  private sql!: SqlJsModule;
  private db!: DatabaseInstance;
  private dbPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    this.sql = await initSqlJs({
      locateFile: (file: string) => {
        // Use the correct path for sql.js WASM file
        return require.resolve(`sql.js/dist/${file}`);
      }
    });

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    let dbBuffer: Uint8Array | undefined = undefined;
    if (fs.existsSync(this.dbPath)) {
      const buffer = fs.readFileSync(this.dbPath);
      dbBuffer = new Uint8Array(buffer);
    }

    this.db = new this.sql.Database(dbBuffer);
    
    // Initialize schema if needed
    this.initializeSchema();
  }

  private initializeSchema(): void {
    // Read and execute schema.sql
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      this.db.exec(schema);
    } else {
      // Fallback schema
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `);
    }
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();

    // Get the inserted ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    if (result.length > 0 && result[0].values.length > 0) {
      const id = result[0].values[0][0] as number;
      
      // Save to disk
      await this.save();
      
      return id;
    }
    
    throw new Error('Failed to get inserted ID');
  }

  async save(): Promise<void> {
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
    }
  }

  // For testing purposes
  getDatabase(): DatabaseInstance | null {
    return this.db ?? null;
  }
}

// Singleton instance
let dbInstance: Database | null = null;

export async function getDatabase(): Promise<Database> {
  if (!dbInstance) {
    dbInstance = new Database();
    await dbInstance.initialize();
  }
  return dbInstance;
}

export async function closeDatabase(): Promise<void> {
  if (dbInstance) {
    await dbInstance.close();
    dbInstance = null;
  }
}