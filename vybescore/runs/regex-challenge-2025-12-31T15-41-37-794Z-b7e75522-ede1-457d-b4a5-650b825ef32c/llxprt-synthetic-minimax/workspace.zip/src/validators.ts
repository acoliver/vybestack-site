/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic structure check: local@domain.tld
  // Local part: letters, numbers, dots, underscores, plus, hyphens
  // But reject double dots and trailing dots
  const emailRegex = /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9._+-]+(?<!\.)@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // Check for double dots in local part
  if (email.split('@')[0].includes('..')) {
    return false;
  }
  
  // Check for domains with underscores
  const domain = email.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Check for trailing dots in domain
  if (domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Must have 10 or 11 digits (for +1 prefix)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, first should be 1 (for +1)
  if (digits.length === 11 && digits[0] !== '1') {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.length === 11 ? digits.slice(1, 4) : digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Additional check: ensure it's a proper US phone format
  // This regex matches: +1 (212) 555-7890, (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^(?:\+?1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)\d{3}[\s.-]?\d{4}$/;
  
  if (!phoneRegex.test(value.replace(/\s+/g, ' ').trim())) {
    return false;
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const clean = value.replace(/[^\d+]/g, '');
  
  // Parse the number structure
  let pos = 0;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  let hasMobileIndicator = false;
  
  // Check for country code +54
  if (clean.startsWith('+54')) {
    hasCountryCode = true;
    pos = 3;
  }
  
  // Check for mobile indicator 9 (only valid when we have a country code)
  const remainingAfterCountry = clean.slice(pos);
  if (remainingAfterCountry.match(/^9/)) {
    hasMobileIndicator = true;
    pos += 1;
  }
  
  // Check for trunk prefix 0 (can appear before or after mobile indicator)
  if (clean[pos] === '0') {
    hasTrunkPrefix = true;
    pos += 1;
  }
  
  // Must have area code (2-4 digits, first digit 1-9)
  if (pos >= clean.length || !clean.slice(pos).match(/^[1-9]\d{1,3}/)) {
    return false;
  }
  
  // Extract area code (2-4 digits)
  const areaMatch = clean.slice(pos).match(/^([1-9]\d{1,3})/);
  if (!areaMatch) {
    return false;
  }
  const areaCode = areaMatch[1];
  pos += areaCode.length;
  
  // Remaining digits are subscriber number
  const subscriber = clean.slice(pos);
  
  // Validate components
  // Area code: 2-4 digits (already validated), first digit already 1-9
  // Subscriber: 6-8 digits total
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Validation rules:
  // 1. When country code is omitted, must have trunk prefix
  // 2. When country code is present, trunk prefix is optional
  // 3. When mobile indicator is present, trunk prefix should NOT be present
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Mobile numbers should NOT have trunk prefix
  if (hasMobileIndicator && hasTrunkPrefix) {
    return false;
  }
  
  // Additional validation: ensure we have proper digit counts
  const digitsOnly = value.replace(/[^\d]/g, '');
  
  // Check total digit count (should be 10-12 for Argentine numbers)
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for digits anywhere - names shouldn't contain numbers
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for forbidden special symbols (basic ASCII symbols that aren't apostrophes or hyphens)
  const forbiddenPattern = /[#$!@%^&*()+=[\\]{}|;:,.<>?~"_\/]/;
  if (forbiddenPattern.test(value.replace(/['-]/g, ''))) {
    return false;
  }
  
  // Must start with a letter (basic check)
  if (!/^[a-zA-Z]/.test(value)) {
    return false;
  }
  
  // Allow letters, unicode characters, spaces, hyphens, and apostrophes
  // Basic pattern check - name should contain reasonable characters
  const validNamePattern = /^[a-zA-Z\s'-]+$/;
  
  if (!validNamePattern.test(value)) {
    return false;
  }
  
  // Check for unreasonable patterns like "X Æ A-12"
  if (value.includes('Æ')) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check card type and validate prefix/length
  let validFormat = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.match(/^4\d{12}(\d{3})?$/)) {
    validFormat = digits.length === 13 || digits.length === 16 || digits.length === 19;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (digits.match(/^(5[1-5]\d{2}|2[2-7]\d{2})\d{12}$/)) {
    validFormat = digits.length === 16;
  }
  // American Express: starts with 34 or 37, length 15
  else if (digits.match(/^(34|37)\d{13}$/)) {
    validFormat = digits.length === 15;
  }
  
  if (!validFormat) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return runLuhnCheck(digits);
}

// Helper function for Luhn checksum algorithm
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
