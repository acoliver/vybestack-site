/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  return text
    // Handle sentence endings followed by spaces and new sentences
    .replace(/([.!?]+)(\s*)([a-z])/gi, (match, sentenceEnd, spaces, sentenceStart) => {
      return sentenceEnd + spaces + sentenceStart.toUpperCase();
    })
    // Handle the first sentence (beginning of text)
    .replace(/^(\s*)([a-z])/g, (match, spaces, sentenceStart) => {
      return spaces + sentenceStart.toUpperCase();
    })
    // Collapse multiple spaces but preserve intentional spacing
    .replace(/(\s{2,})/g, ' ')
    // Ensure exactly one space after sentence endings
    .replace(/([.!?]+)\s*/g, (match, sentenceEnd) => {
      return sentenceEnd + ' ';
    })
    // Trim any extra spaces at the end but preserve original structure
    .trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || text.trim().length === 0) {
    return [];
  }
  
  // URL regex pattern matching common URL formats
  const urlRegex = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>[{}|\\^`"]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation while preserving URLs
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,;:!?}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // Only replace http:// (case insensitive) with https://, leaving https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // Pattern to match URLs with the following groups:
  // 1. Protocol (http:// or https://)
  // 2. Domain (everything before the first / after protocol)
  // 3. Path (starting with /, but we'll validate if it's /docs/)
  // 4. Query and fragment (everything after first ? or #, if any)
  const urlPattern = /\b(https?):\/\/([^/\s]+)([^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade http:// to https://
    const newProtocol = 'https://';
    let newDomain = domain;
    
    // Check for legacy extensions and dynamic hints
    const hasLegacyExtension = path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|#|$)/i);
    const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
    const hasDynamicHint = path.match(/cgi-bin/i);
    
    // Only rewrite domain if path starts with /docs/ and no legacy/query/dynamic patterns
    if (path.startsWith('/docs/') && !hasLegacyExtension && !hasQueryString && !hasDynamicHint) {
      newDomain = `docs.${domain}`;
    }
    
    return newProtocol + newDomain + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || value.trim().length === 0) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy pattern
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if month is February (2)
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear && day > 28) {
      return 'N/A';
    }
    if (isLeapYear && day > 29) {
      return 'N/A';
    }
  }
  
  // Validate day for other months
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year.toString();
}
