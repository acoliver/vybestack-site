/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || text.trim().length === 0) {
    return [];
  }
  
  // Create regex pattern to match words starting with prefix
  // Use word boundaries to match complete words
  const pattern = new RegExp(`\\b${escapeRegex(prefix)}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    const normalizedWord = word.toLowerCase();
    return !exceptions.some(exc => exc.toLowerCase() === normalizedWord);
  });
}

// Helper function to escape special regex characters
function escapeRegex(pattern: string): string {
  return pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || text.trim().length === 0) {
    return [];
  }
  
  // Match token only when preceded by a digit and not at string start
  // We capture the digit and token together to return the full match
  const pattern = new RegExp(`(?<!^)(\\d)${escapeRegex(token)}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Each match will be in format "digittoken" which is what the test expects
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This pattern looks for the same character repeated 4+ times
  if (/(.)\1{3}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // First, check if this looks like an IPv4 address to exclude it
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address patterns:
  // 1. Full IPv6: eight groups of four hex digits separated by colons
  //    Example: 2001:0db8:0000:0000:0000:ff00:0042:7879
  // 2. Shorthand: uses :: to represent multiple groups of zeros
  //    Example: 2001:db8::1, ::1, fe80::1%lo0
  // 3. IPv6-mapped IPv4: ::ffff:192.0.2.1
  // 4. Mixed notation with IPv4 at the end
  
  // Pattern for full IPv6 addresses
  const fullIPv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // Pattern for IPv6 with shorthand notation (::)
  // This handles various shorthand cases
  const shorthandIPv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){0,7}[a-fA-F0-9]{0,4}::(?:[a-fA-F0-9]{1,4}:){0,7}[a-fA-F0-9]{0,4}\b/;
  
  // Pattern for IPv6 with zone identifiers (e.g., %lo0)
  const zoneIPv6Pattern = /\b[a-fA-F0-9:]+%[a-zA-Z0-9]+\b/;
  
  // Pattern for IPv6-mapped IPv4 addresses
  const mappedIPv4Pattern = /\b::ffff:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  return fullIPv6Pattern.test(value) || 
         shorthandIPv6Pattern.test(value) || 
         zoneIPv6Pattern.test(value) || 
         mappedIPv4Pattern.test(value);
}
