export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // - Allow letters, digits, and certain special characters before @
  // - Allow domain names with subdomains
  // - Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for trailing dot in domain
  if (value.endsWith('.')) return false;
  
  // Check for underscore in domain
  const domainWithUnderscore = /@.*_/.test(value);
  if (domainWithUnderscore) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for too short inputs
  if (digitsOnly.length < 10) return false;
  
  // Check for optional +1 prefix
  let phoneNumber = value;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  }
  
  // Remove all separators (spaces, hyphens, parentheses)
  const cleanNumber = phoneNumber.replace(/[\s\-\(\)]/g, '');
  
  // Check length (should be 10 digits for US numbers)
  if (cleanNumber.length !== 10) return false;
  
  // Extract area code
  const areaCode = cleanNumber.substring(0, 3);
  
  // Disallow impossible area codes (leading 0/1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate the format with regex
  return /^(?:\+1[\s\-]?)?(\(?[2-9]\d{2}\)?[\s\-]?)[2-9]\d{2}[\s\-]?\d{4}$/.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleanNumber = value.replace(/[\s\-]/g, '');
  
  // Extract country code if present
  let hasCountryCode = false;
  let processedNumber = cleanNumber;
  
  if (cleanNumber.startsWith('+54')) {
    hasCountryCode = true;
    processedNumber = cleanNumber.substring(3);
  }
  
  // Extract trunk prefix if present
  let hasTrunkPrefix = false;
  if (processedNumber.startsWith('0')) {
    hasTrunkPrefix = true;
    processedNumber = processedNumber.substring(1);
  }
  
  // Extract mobile indicator if present
  if (processedNumber.startsWith('9')) {
    processedNumber = processedNumber.substring(1);
  }
  
  // At this point, processedNumber should start with area code
  // Area code must be 2-4 digits, leading digit 1-9
  const areaCodeMatch = processedNumber.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = areaCodeMatch[2];
  
  // Area code validation
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must contain 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // When country code is omitted, the number must begin with trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if the value contains only allowed characters
  if (!nameRegex.test(value)) return false;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Reject names with consecutive symbols (like X Æ A-12)
  if (/[^\p{L}\p{M}\s][^\p{L}\p{M}\s]/u.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers using Luhn checksum and pattern checks.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanedCard = value.replace(/\D/g, '');
  
  // Check for valid length (13-19 digits for most credit cards)
  if (cleanedCard.length < 13 || cleanedCard.length > 19) return false;
  
  // Check for valid prefixes
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const visaRegex = /^4\d{12,18}$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidPrefix = visaRegex.test(cleanedCard) || 
                      mastercardRegex.test(cleanedCard) || 
                      amexRegex.test(cleanedCard);
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanedCard);
}
