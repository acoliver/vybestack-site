/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  // Create a regex pattern to find words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string
  // Use lookaheads/lookbehinds
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find tokens that are:
  // - Not at the start of the string
  // - Preceded by a digit
  const tokenPattern = new RegExp(`\\d(${escapedToken})`, 'g');
  
  // Find all matches and capture only the full match
  const matches = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol
  // No whitespace, no immediate repeated sequences (e.g., abab should fail)
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  // This pattern finds any 2-character sequence that appears adjacent to itself
  if (/(..)\1/.test(value)) return false;
  
  // Additional check for patterns like abab where a and b are repeated with the same pattern
  // Look for patterns like abab, cdcd, etc.
  if (/(.)(.)\1\2/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand) and ensure IPv4 addresses do not trigger a positive result
  
  // IPv6 regex (supports full notation, shorthand with ::, and embedded IPv4)
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:|(?:[0-9a-fA-F]{1,4}:){1,5}:(?:[0-9a-fA-F]{1,4}:){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:[0-9a-fA-F]{1,4}:){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}:(?:[0-9a-fA-F]{1,4}:){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}:(?:[0-9a-fA-F]{1,4}:){1,5}|[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:){1,6}|:(?:(?:[0-9a-fA-F]{1,4}:){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])/;
  
  // IPv4 regex (to ensure we don't incorrectly identify IPv4 as IPv6)
  const ipv4Regex = /(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // First check if there's an IPv6 pattern
  const hasIPv6 = ipv6Regex.test(value);
  
  // If no IPv6 found, return false
  if (!hasIPv6) return false;
  
  // If IPv6 found, make sure it's not just an IPv4 address
  return !ipv4Regex.test(value);
}