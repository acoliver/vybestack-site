/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!)
  // Insert exactly one space between sentences even if the input omitted it
  // Collapse extra spaces sensibly while leaving abbreviations intact when possible
  
  if (!text) return text;
  
  // Use a regex to capitalize the first letter of each sentence
  return text.replace(/(?:^|([.!?])\s+)([a-z])/g, (match, punc, letter) => {
    return (punc ? punc + ' ' : '') + letter.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matches various protocols and domains
  // Returns all URLs detected in the text without trailing punctuation
  const urlRegex = /https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?(?:\b|$)/g;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    // Extract the URL
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?")]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://
  // - When the path begins with /docs/, rewrite the host to docs.example.com
  // - Skip the host rewrite when the path contains dynamic hints
  // - Preserve nested paths
  
  return text.replace(/http:\/\/example\.com\/([^ \s"')\]]+)/g, (match, path) => {
    // Check if the path contains dynamic hints that should prevent host rewrite
    const shouldSkipHostRewrite = /\/(cgi-bin|\?|&|=)|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/.test(path);
    
    // Always upgrade to https://
    let newUrl = 'https://example.com/' + path;
    
    // If path begins with /docs/ and we should not skip host rewrite, change to docs.example.com
    if (path.startsWith('docs/') && !shouldSkipHostRewrite) {
      newUrl = 'https://docs.example.com/' + path;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // If the string doesn't match that format or month/day are invalid, return "N/A"
  
  // Validate mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  let febMaxDays = 28;
  const yearNum = parseInt(year, 10);
  if (yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0)) {
    febMaxDays = 29;
  }
  
  const monthMaxDays = month === 2 ? febMaxDays : maxDays[month - 1];
  
  if (day < 1 || day > monthMaxDays) return 'N/A';
  
  return year;
}