/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  getActiveObserver,
  Subject,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create subject with special update function to handle computed values
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn: typeof equal === 'function' ? equal : undefined
  }

  // Create observer that computes the value based on dependencies
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Temporarily set the global activeObserver to "this"
      const previousObserver = (globalThis as any).activeObserver
      ;(globalThis as any).activeObserver = o
      try {
        const newValue = updateFn(prevValue)
        return newValue
      } finally {
        (globalThis as any).activeObserver = previousObserver
      }
    }
  }

  // Compute initial value
  updateObserver(o)
  s.value = o.value!

  // Return getter that tracks subscribers
  return () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      s.observer = activeObserver
    }
    return s.value
  }
}