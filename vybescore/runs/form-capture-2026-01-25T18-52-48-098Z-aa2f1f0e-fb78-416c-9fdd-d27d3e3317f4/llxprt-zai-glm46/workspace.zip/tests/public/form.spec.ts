import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type express from 'express';
import { startServer } from '../../src/server.js';

let server: Awaited<ReturnType<typeof startServer>> | undefined;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = await startServer(0);
  app = server.app;
});

afterAll(async () => {
  if (server && server.close) {
    await server.close();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app as unknown as Express).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);
    expect($('form[method="post"][action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app as unknown as express.Application).post('/submit').type('form').send(formData);
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');

    expect(fs.existsSync(dbPath)).toBe(true);

    const redirectResponse = await request(app as unknown as express.Application).get(response.headers.location);
    expect(redirectResponse.status).toBe(200);
    expect(redirectResponse.text).toContain('Thank you');
    expect(redirectResponse.text).toContain(formData.firstName);
  });

  it('shows validation errors for invalid data', async () => {
    const response = await request(app as unknown as express.Application).post('/submit').type('form').send({
      firstName: '',
      lastName: '',
      email: 'not-an-email',
      phone: 'invalid-phone!',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('accepts international phone and postal formats', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Maria',
      lastName: 'González',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app as unknown as express.Application).post('/submit').type('form').send(formData);
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
  });
});
