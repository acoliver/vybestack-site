// @ts-expect-error - sql.js doesn't have built-in TypeScript definitions
import initSqlJsWasm from 'sql.js';

export interface SqlJsStatic {
  Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
}

export interface Database {
  run(sql: string, params?: unknown[]): void;
  exec(sql: string): unknown[];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
  execute(sql: string): unknown;
}

export interface Statement {
  run(values?: unknown[]): unknown;
  step(): unknown | undefined;
  getAsObject(params?: unknown): unknown;
  bind(values?: unknown[]): boolean;
  free(): void;
  getColumnNames(): string[];
}

export async function initSqlJs(): Promise<SqlJsStatic> {
  return initSqlJsWasm() as Promise<SqlJsStatic>;
}
