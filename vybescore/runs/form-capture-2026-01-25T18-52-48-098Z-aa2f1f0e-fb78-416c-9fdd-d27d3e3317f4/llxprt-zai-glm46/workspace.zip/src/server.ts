import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import { initSqlJs, Database, SqlJsStatic } from './sqljs-wrapper.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

let SQL: SqlJsStatic;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const staticDir = path.resolve(__dirname, '../public');
app.use('/public', express.static(staticDir));

app.set('view engine', 'ejs');
const templatesDir = path.resolve(__dirname, 'templates');
app.set('views', templatesDir);

function validatePhoneNumber(phone: string): boolean {
  const trimmed = phone.trim();
  return /^[+@]?[\d\s-()]+$/.test(trimmed);
}

function validateEmail(email: string): boolean {
  const trimmed = email.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(trimmed);
}

function validatePostalCode(postal: string): boolean {
  const trimmed = postal.trim();
  return /^[A-Za-z0-9\s-]+$/.test(trimmed) && trimmed.length > 0;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || !validateRequired(data.firstName)) {
    errors.push('First name is required.');
  }

  if (!data.lastName || !validateRequired(data.lastName)) {
    errors.push('Last name is required.');
  }

  if (!data.streetAddress || !validateRequired(data.streetAddress)) {
    errors.push('Street address is required.');
  }

  if (!data.city || !validateRequired(data.city)) {
    errors.push('City is required.');
  }

  if (!data.stateProvince || !validateRequired(data.stateProvince)) {
    errors.push('State / Province / Region is required.');
  }

  if (!data.postalCode || !validateRequired(data.postalCode)) {
    errors.push('Postal / Zip code is required.');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens.');
  }

  if (!data.country || !validateRequired(data.country)) {
    errors.push('Country is required.');
  }

  if (!data.email || !validateRequired(data.email)) {
    errors.push('Email is required.');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address.');
  }

  if (!data.phone || !validateRequired(data.phone)) {
    errors.push('Phone number is required.');
  } else if (!validatePhoneNumber(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading @ or +.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database not available. Please try again later.'],
      values: formData,
    });
  }

  try {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName!,
      formData.lastName!,
      formData.streetAddress!,
      formData.city!,
      formData.stateProvince!,
      formData.postalCode!,
      formData.country!,
      formData.email!,
      formData.phone!,
    ]);
    stmt.free();

    const data = db.export();
    const dbDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, data);

    return res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = typeof req.query.firstName === 'string' ? req.query.firstName : 'friend';
  res.render('thank-you', { firstName });
});

app.use((_req: Request, res: Response) => {
  res.status(404).send('Not Found');
});

function setupDatabase(): Database {
  let database: Database;

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);

    const dbDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    const data = database.export();
    fs.writeFileSync(DB_PATH, data);
  }

  return database;
}

export async function startServer(port: number = 3535): Promise<{ app: express.Express; server: ReturnType<typeof app.listen>; close: () => Promise<void> }> {
  SQL = await initSqlJs();
  db = setupDatabase();

  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  const close = async (): Promise<void> => {
    return new Promise<void>((resolve) => {
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        resolve();
      });
    });
  };

  return { app, server, close };
}

const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

if (import.meta.url === `file://${process.argv[1]}`) {
  (async () => {
    try {
      await startServer(port);
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  })();

  process.on('SIGTERM', async () => {
    console.log('SIGTERM received, shutting down gracefully...');
    if (db) {
      db.close();
      db = null;
    }
    process.exit(0);
  });
}
