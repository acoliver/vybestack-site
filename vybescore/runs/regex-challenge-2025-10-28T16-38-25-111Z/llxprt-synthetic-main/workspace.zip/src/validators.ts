export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regex.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for consecutive dots
  if (value.includes('..')) return false;
  
  // Check for dot at beginning or end of local part
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Check for underscore in domain
  if (domain.includes('_')) return false;
  
  // Check if domain starts or ends with dot
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone number formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for standard US number)
  if (digits.length < 10) return false;
  
  // If it's longer than 11 digits, it's not valid
  if (digits.length > 11) return false;
  
  // Extract country code if present (should be 1 for US)
  let areaCode: string;
  if (digits.length === 11) {
    // First digit should be 1 for US country code
    if (digits[0] !== '1') return false;
    areaCode = digits.substring(1, 4);
  } else {
    areaCode = digits.substring(0, 3);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if the number matches a valid format
  const usPhoneRegex = /^(?:\+1[\s-]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Remove all separators (spaces, hyphens, dots, parentheses)
  const cleanedValue = value.replace(/[\s\-.\(\)]/g, '');
  
  // Argentine phone regex with all requirements
  // ^(\+54)? - Optional country code
  // (0? - Optional trunk prefix
  // 9?) - Optional mobile indicator
  // ([2-9]\d{1,3}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([2-9]\d{1,3})(\d{6,8})$/;
  
  const match = argentinePhoneRegex.exec(cleanedValue);
  if (!match) return false;
  
  const hasCountryCode = !!match[1];
  const hasTrunkPrefix = !!match[2];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (!/^[2-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Name validation regex:
  // ^[\p{L}'-]+$ - Allows Unicode letters, apostrophes, hyphens
  // We'll use a more specific pattern for better compatibility
  const nameRegex = /^[A-Za-z\u00C0-\u024F\u0400-\u04FF\u0370-\u03FF\u0590-\u05FF\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\s\'\-]+$/;
  
  // Reject digits
  if (/\d/.test(value)) return false;
  
  // Reject common symbols that aren't allowed in names
  if (/[!@#$%^&*()_+=\[\]{};:"\\|,.<>\/?]/.test(value)) return false;
  
  // Reject names that start with special characters
  if (/^[\s\'\-]/.test(value)) return false;
  
  // Should contain at least one letter
  if (!/[A-Za-z\u00C0-\u024F\u0400-\u04FF\u0370-\u03FF\u0590-\u05FF\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF]/.test(value)) return false;
  
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // Remove non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits is the typical range)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check for Visa (4), Mastercard (51-55, 2221-2720), or Amex (34, 37)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d{1}|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Validate prefix and length
  const isValidPrefix = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(value);
}
