/**
 * Capitalizes the first character of each sentence.
 * Handles spacing correctly, preserving sentences while abbreviations are left intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string' || !text.length) return text;
  
  // First normalize spaces - replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Identify sentence boundaries and capitalize the first letter of each sentence
  // Look for punctuation followed by possible quotes/brackets and then whitespace
  const sentenceBoundaryRegex = /([.?!]\s*)(['"(]*)/g;
  
  result = result.replace(sentenceBoundaryRegex, (match, punctuation, openingChars) => {
    return punctuation + openingChars;
  });
  
  // Now capitalize first character of each sentence
  // This regex finds the start of the string or after sentence boundary punctuation
  result = result.replace(/(^|[.?!]\s+)(['"(]*)([a-z])/g, (match, boundary, opening, firstChar) => {
    return boundary + opening + firstChar.toUpperCase();
  });
  
  // Capitalize the very first character if it's a letter
  result = result.replace(/^([a-z])/, (match, firstChar) => {
    return firstChar.toUpperCase();
  });
  
  // Ensure exactly one space after punctuation (if not end of string)
  result = result.replace(/([.?!])(\s+)/g, (match, punctuation, spaces) => {
    // If there's a quote or parenthesis after the punctuation, keep no space
    if (spaces && /^\s*['")]/.test(spaces)) {
      return punctuation + ' ' + spaces.replace(/^\s+/, '');
    }
    return punctuation + ' ';
  });
  
  return result;
}

/**
 * Extracts URLs from the given text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string' || !text.length) return [];
  
  // URL regex that captures URLs with various protocols and domains
  const urlRegex = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>'"]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  // Common punctuation to trim: . , ; : ? ! ) ] } "
  return matches.map(url => url.replace(/[.,;:?!)\]}"']+$/g, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string' || !text.length) return text;
  
  // Replace http:// with https://, but not if it's already https://
  // Use negative lookahead to avoid matching https://
  return text.replace(/\bhttp:\/\/(?!https?:\/\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string' || !text.length) return text;
  
  // First, handle http://example.com URLs with docs path
  // This captures the full URL and checks if it has /docs/ path without dynamic elements
  return text.replace(
    /\bhttp:\/\/([^\/\s]+)(\/docs\/[^\s?]*)(?![?&=#]|\.(jsp|php|asp|aspx|do|cgi|pl|py))/gi,
    (match, hostname, path) => {
      // If the hostname already contains docs, just upgrade the scheme
      if (hostname.includes('docs.')) {
        return `https://${hostname}${path}`;
      }
      
      // Otherwise replace with docs subdomain
      return `https://docs.${hostname}${path}`;
    }
  ).replace(
    // Second, handle all remaining http:// URLs (including those with dynamic elements)
    /\bhttp:\/\/([^\/\s]+)(\/|[^\s]*)/gi,
    'https://$1$2'
  );
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string' || !value.length) return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];  // Keep as string for return
  
  // Validate month
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (day < 1 || day > (isLeapYear ? 29 : 28)) return 'N/A';
  } else {
    // For other months
    if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  }
  
  return year;
}
