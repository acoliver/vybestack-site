/**
 * Matches words starting with the specified prefix, excluding any listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || !text.length) return [];
  if (typeof prefix !== 'string' || !prefix.length) return [];
  if (!Array.isArray(exceptions)) return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary regex with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9]+\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(match => {
    return !exceptionsLower.includes(match.toLowerCase());
  });
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || !text.length) return [];
  if (typeof token !== 'string' || !token.length) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex that matches the token preceded by a digit
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return matches;
}

/**
 * Validates passwords according to the specified strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // We'll check for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substr(i, len);
      const nextSegment = value.substr(i + len, len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while ensuring IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string' || !value.length) return false;
  
  // First, check if the text contains an IPv4 address
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // IPv6 address patterns (excluding IPv4)
  // Use a simpler regex that distinguishes IPv6 from IPv4
  
  // Check for shorthand notation (contains ::)
  if (/::/.test(value) && !ipv4Pattern.test(value)) {
    return true;
  }
  
  // Check for colons that would indicate IPv6 format
  // Count the number of colons in each word
  const words = value.split(/\s+/);
  
  for (const word of words) {
    // Skip if it looks like an IPv4 address
    if (ipv4Pattern.test(word)) continue;
    
    // Check for IPv6 format indicators
    // Has colons and hex characters (a-f, 0-9) but doesn't have dots (like IPv4)
    const hasColons = word.includes(':');
    const hasHexPattern = /[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4})+/;
    
    if (hasColons && hasHexPattern.test(word)) {
      return true;
    }
  }
  
  return false;
}