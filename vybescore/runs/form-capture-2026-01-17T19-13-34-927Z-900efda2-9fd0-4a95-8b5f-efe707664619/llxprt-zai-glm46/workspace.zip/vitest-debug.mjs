import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { startServer, stopServer } from './dist/server.js';

let app;

beforeAll(async () => {
  const serverModule = await import('./dist/server.js');
  app = serverModule.default;
  await startServer();
});

afterAll(async () => {
  await stopServer();
});

describe('debug phone test', () => {
  it('handles international phone numbers correctly', async () => {
    const phone = '+44 20 7946 0958';
    const email = `test-${Math.random().toString(36).substring(7)}@example.com`;
    
    const response = await request(app).post('/submit').send({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 St',
      city: 'City',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'Country',
      email: email,
      phone: phone,
    });

    console.log('Response status:', response.status);
    console.log('Response location:', response.headers.location);
    if (response.status !== 302 && response.text) {
      console.log('Response body preview:', response.text.substring(0, 500));
    }

    expect(response.status).toBe(302);
  });
});
