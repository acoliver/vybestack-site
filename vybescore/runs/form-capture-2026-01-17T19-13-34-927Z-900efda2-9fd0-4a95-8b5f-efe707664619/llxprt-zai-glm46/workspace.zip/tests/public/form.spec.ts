import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, stopServer } from '../../src/server.js';

let app: Parameters<typeof request>[0];

beforeAll(async () => {
  // Import and start the server
  const serverModule = await import('../../src/server.js');
  app = serverModule.default;
  await startServer();
});

afterAll(async () => {
  await stopServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);

    // Check for all form fields with proper labels
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check for label associations
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);

    // Check form submission method
    expect($('form[method="post"]')).toHaveLength(1);
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');

    // Clean up existing database if present
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958',
      });

    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');

    // Follow redirect to check thank you page
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('John');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid submission', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'invalid-email',
      phone: 'invalid-phone',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('is required');
    expect(response.text).toContain('valid email');
  });

  it('renders thank you page with humorous content', async () => {
    const response = await request(app).get('/thank-you?firstName=Test');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('Test');
    expect(response.text).toMatch(/stranger|internet|spam|identity/i);
  });

  it('handles international phone numbers correctly', async () => {
    const internationalNumbers = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
    ];

    for (const phone of internationalNumbers) {
      const response = await request(app).post('/submit').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 St',
        city: 'City',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: `test${phone.replace(/\D/g, '')}@example.com`,
        phone,
      });

      expect(response.status).toBe(302);
    }
  });

  it('handles international postal codes correctly', async () => {
    const postalCodes = [
      { code: 'SW1A 1AA', country: 'UK' },
      { code: 'C1000', country: 'Argentina' },
      { code: 'B1675', country: 'Argentina' },
      { code: '12345', country: 'USA' },
    ];

    for (const { code, country } of postalCodes) {
      const response = await request(app).post('/submit').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 St',
        city: 'City',
        stateProvince: 'State',
        postalCode: code,
        country: country,
        email: `test${code.replace(/\s/g, '')}@example.com`,
        phone: '+1 555 123 4567',
      });

      expect(response.status).toBe(302);
    }
  });
});
