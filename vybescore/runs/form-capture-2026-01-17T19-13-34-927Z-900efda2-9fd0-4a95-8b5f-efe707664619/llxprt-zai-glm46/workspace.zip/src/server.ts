/**
 * Express server for the Friendly Form Capture application
 */

import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { dbManager, Submission } from './database.js';
import { validateForm, FormValues } from './validator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use('/public', express.static(path.join(__dirname, '../public')));

// View engine setup
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

/**
 * GET / - Render the contact form
 */
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    },
  });
});

/**
 * POST /submit - Process form submission
 */
app.post('/submit', async (req: Request, res: Response) => {
  const formValues: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  // Validate form
  const validation = validateForm(formValues);

  if (!validation.valid) {
    // Re-render form with errors and entered values
    res.status(400).render('form', {
      errors: validation.errors,
      values: formValues,
    });
    return;
  }

  // Insert into database
  const submission: Submission = {
    firstName: formValues.firstName,
    lastName: formValues.lastName,
    streetAddress: formValues.streetAddress,
    city: formValues.city,
    stateProvince: formValues.stateProvince,
    postalCode: formValues.postalCode,
    country: formValues.country,
    email: formValues.email,
    phone: formValues.phone,
  };

  await dbManager.insertSubmission(submission);

  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formValues.firstName)}`);
});

/**
 * GET /thank-you - Render thank you page
 */
app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

/**
 * Error handling middleware
 */
app.use((err: Error, _req: Request, res: Response) => {
  console.error(err);
  res.status(500).send('Internal Server Error');
});

/**
 * Start the server
 */
let server: ReturnType<typeof app.listen>;

export async function startServer(): Promise<void> {
  // Initialize database
  await dbManager.initialize();

  return new Promise<void>((resolve) => {
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      resolve();
    });
  });
}

/**
 * Stop the server gracefully
 */
export async function stopServer(): Promise<void> {
  return new Promise<void>((resolve) => {
    if (server) {
      server.close(() => {
        console.log('Server closed');
        dbManager.close();
        resolve();
      });
    } else {
      dbManager.close();
      resolve();
    }
  });
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await stopServer();
  process.exit(0);
});

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export default app;
