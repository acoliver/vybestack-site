/**
 * Validation utilities for form inputs
 */

export interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Phone number validation
 * Allows: digits, spaces, parentheses, dashes, and leading +
 */
const PHONE_REGEX = /^\+?[\d\s\-()]+$/;

/**
 * Postal code validation
 * Allows alphanumeric characters with spaces
 * Supports UK format (SW1A 1AA), Argentine format (C1000, B1675), US format (12345)
 */
const POSTAL_CODE_REGEX = /^[A-Za-z0-9\s-]+$/;

/**
 * Email validation regex
 * Allows standard email format but rejects emails with spaces
 * The local part can contain letters, digits, and special characters like +, -, _, .
 */
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

/**
 * Validates required fields are not empty
 */
function validateRequired(value: string, fieldName: string): string | null {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return null;
}

/**
 * Validates email format
 */
function validateEmail(email: string): string | null {
  if (!email || email.trim() === '') {
    return 'Email is required';
  }
  if (!EMAIL_REGEX.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
}

/**
 * Validates phone number format
 */
function validatePhone(phone: string): string | null {
  if (!phone || phone.trim() === '') {
    return 'Phone number is required';
  }
  if (!PHONE_REGEX.test(phone)) {
    return 'Please enter a valid phone number';
  }
  return null;
}

/**
 * Validates postal code format
 */
function validatePostalCode(postalCode: string): string | null {
  if (!postalCode || postalCode.trim() === '') {
    return 'Postal code is required';
  }
  if (!POSTAL_CODE_REGEX.test(postalCode)) {
    return 'Please enter a valid postal code';
  }
  return null;
}

/**
 * Validates all form fields
 */
export function validateForm(values: FormValues): ValidationResult {
  const errors: string[] = [];

  // Required fields
  const firstNameError = validateRequired(values.firstName, 'First name');
  if (firstNameError) errors.push(firstNameError);

  const lastNameError = validateRequired(values.lastName, 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const streetAddressError = validateRequired(values.streetAddress, 'Street address');
  if (streetAddressError) errors.push(streetAddressError);

  const cityError = validateRequired(values.city, 'City');
  if (cityError) errors.push(cityError);

  const stateProvinceError = validateRequired(values.stateProvince, 'State / Province / Region');
  if (stateProvinceError) errors.push(stateProvinceError);

  const countryError = validateRequired(values.country, 'Country');
  if (countryError) errors.push(countryError);

  // Email validation
  const emailError = validateEmail(values.email);
  if (emailError) errors.push(emailError);

  // Phone validation
  const phoneError = validatePhone(values.phone);
  if (phoneError) errors.push(phoneError);

  // Postal code validation
  const postalCodeError = validatePostalCode(values.postalCode);
  if (postalCodeError) errors.push(postalCodeError);

  return {
    valid: errors.length === 0,
    errors,
  };
}
