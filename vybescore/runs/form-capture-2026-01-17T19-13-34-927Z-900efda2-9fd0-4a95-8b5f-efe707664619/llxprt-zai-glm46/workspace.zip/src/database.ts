/**
 * Database module for SQLite operations using sql.js
 */

import initSqlJs, { Database, type SqlJsStatic } from 'sql.js';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

export interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private SQL: SqlJsStatic | null = null;

  /**
   * Initialize the database
   * Loads sql.js WASM, creates/opens the database file, and runs schema
   */
  async initialize(): Promise<void> {
    // Initialize sql.js
    this.SQL = await initSqlJs();

    // Check if database file exists
    let dbBuffer: Uint8Array | null = null;
    if (fs.existsSync(DB_PATH)) {
      const fileContent = fs.readFileSync(DB_PATH);
      dbBuffer = new Uint8Array(fileContent);
    }

    // Create database instance
    this.db = new this.SQL.Database(dbBuffer);

    // If database is new, run schema
    if (!dbBuffer) {
      await this.runSchema();
    }
  }

  /**
   * Run the schema SQL to create tables
   */
  private async runSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    this.db.run(schema);
  }

  /**
   * Insert a submission into the database
   */
  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone,
    ]);

    stmt.step();
    stmt.free();

    // Get the last inserted row ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    const lastId = result[0].values[0][0] as number;

    // Save database to disk
    await this.save();

    return lastId;
  }

  /**
   * Save the database to disk
   */
  private async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Export database and write to file
    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  /**
   * Close the database
   */
  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Export singleton instance
export const dbManager = new DatabaseManager();
