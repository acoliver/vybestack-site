import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import initDatabase from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: initSqlJs.Database;
try {
  db = await initDatabase();
  console.log('Database initialized successfully');
} catch (error) {
  console.error('Failed to initialize database:', error);
  process.exit(1);
}

// Validation middleware
const validateForm = (req: Request, res: Response, next: NextFunction) => {
  const {
    first_name,
    last_name,
    street_address,
    city,
    state_province,
    postal_code,
    country,
    email,
    phone
  } = req.body;

  const errors: Record<string, string> = {};

  // Required fields validation
  if (!first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }
  
  if (!country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email validation
    const emailRegex = new RegExp('^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$');
    if (!emailRegex.test(email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = new RegExp('^\\+?[0-9\\s\\-()]+$');
    if (!phoneRegex.test(phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation - allow alphanumeric
  const postalRegex = new RegExp('^[A-Za-z0-9 ]+$');
  if (postal_code && !postalRegex.test(postal_code)) {
    errors.postal_code = 'Postal code can only contain letters, numbers, and spaces';
  }

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData: req.body,
      title: 'Friendly Contact Form'
    });
  }

  next();
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', validateForm, async (req: Request, res: Response) => {
  try {
    const {
      first_name,
      last_name,
      street_address,
      city,
      state_province,
      postal_code,
      country,
      email,
      phone
    } = req.body;

    // Insert into database
    await new Promise<void>((resolve, reject) => {
      const database = db as unknown;
      if (typeof database === 'object' && database !== null && 'prepare' in database) {
        const dbObj = database as { prepare: (sql: string) => initSqlJs.Statement };
        const stmt = dbObj.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province,
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        try {
          stmt.run([
            first_name,
            last_name,
            street_address,
            city,
            state_province,
            postal_code,
            country,
            email,
            phone
          ]);
          resolve();
        } catch (err) {
          reject(err);
        } finally {
          stmt.free();
        }
      }
    });

    // Save database to file
    const database = db as unknown;
    if (typeof database === 'object' && database !== null && 'export' in database) {
      const dbObj = database as { export: () => Uint8Array };
      const data = dbObj.export();
      const dbPath = path.join(__dirname, '../data/submissions.sqlite');
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(dbPath, Buffer.from(data));
    }

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      formData: req.body,
      title: 'Friendly Contact Form'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close();
  }
  const database = db as unknown;
  if (typeof database === 'object' && database !== null && 'close' in database) {
    const dbObj = database as { close: () => void };
    dbObj.close();
  }
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const server = app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Visit http://localhost:${PORT} to see the form`);
});

export default app;