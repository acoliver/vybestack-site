import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const initDatabase = async () => {
  try {
    // Load sql.js WASM module
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '../node_modules/sql.js/dist/', file)
    });

    // Check if database file exists
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    let db: initSqlJs.Database;

    if (fs.existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database from file');
    } else {
      // Create new database
      db = new SQL.Database();
      console.log('Created new database');
    }

    // Read schema and create tables
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    try {
      const database = db as { run: (sql: string) => void };
      database.run(schema);
      console.log('Database schema initialized');
    } catch (error) {
      console.log('Schema may already exist or other schema issue:', error);
    }

    return db;
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
};

export default initDatabase;