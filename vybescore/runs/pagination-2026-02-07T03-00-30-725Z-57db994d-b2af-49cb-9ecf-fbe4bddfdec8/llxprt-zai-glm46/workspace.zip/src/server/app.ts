import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate pagination parameters
    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (isNaN(page) || !Number.isInteger(page) || page < 1) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
    }

    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (isNaN(limit) || !Number.isInteger(limit) || limit < 1) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }

      // Reject excessive limit values to prevent performance issues
      if (limit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: maximum value is 100' });
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
