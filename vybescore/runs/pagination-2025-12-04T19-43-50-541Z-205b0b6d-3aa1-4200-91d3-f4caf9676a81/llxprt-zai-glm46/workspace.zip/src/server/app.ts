import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response): void => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Input validation
    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      if (isNaN(page!) || !Number.isInteger(page!) || page! < 1) {
        res.status(400).json({ 
          error: 'Invalid page parameter. Must be a positive integer (>= 1).' 
        });
        return;
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      if (isNaN(limit!) || !Number.isInteger(limit!) || limit! < 1 || limit! > 100) {
        res.status(400).json({ 
          error: 'Invalid limit parameter. Must be a positive integer (>= 1) and <= 100.' 
        });
        return;
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
