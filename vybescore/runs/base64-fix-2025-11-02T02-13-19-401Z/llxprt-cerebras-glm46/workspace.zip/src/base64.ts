

/**
 * Encode plain text to Base64 using RFC 4648 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 alphabet.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove whitespace and check for valid Base64 characters
  const sanitized = input.replace(/\s/g, '');
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!validBase64Pattern.test(sanitized)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check proper padding
  const paddingIndex = sanitized.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = sanitized.substring(paddingIndex);
    // Padding can only be '=', '==', or '===' and must appear at the end
    if (!/^={1,2}$/.test(padding) || paddingIndex < sanitized.length - 3) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(sanitized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
