import { readFileSync, writeFileSync } from 'fs';
import { ReportData, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = argv[2];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse flags starting from index 3
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format' && i + 1 < argv.length) {
      format = argv[++i];
    } else if (arg === '--output' && i + 1 < argv.length) {
      outputPath = argv[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: "title" field is required and must be a string');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field is required and must be a string');
  }

  if (!obj.entries || !Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: "entries" field is required and must be an array');
  }

  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label is required and must be a string`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount as number)) {
      throw new Error(`Invalid JSON: entries[${index}].amount is required and must be a number`);
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
      process.exit(1);
    }
    if (error instanceof Error && error.message.startsWith('ENOENT')) {
      console.error(`Error: File not found: ${filePath}`);
      process.exit(1);
    }
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

function getFormatter(format: string) {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
      process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content);
    } catch (error) {
      if (error instanceof Error && error.message.startsWith('ENOENT')) {
        console.error(`Error: Cannot write to file - directory does not exist: ${outputPath}`);
        process.exit(1);
      }
      throw error;
    }
  } else {
    process.stdout.write(content);
  }
}

// Main execution
function main(): void {
  const args = parseArgs(process.argv);
  const reportData = loadReportData(args.inputFile);
  const formatter = getFormatter(args.format);
  const options: FormatOptions = { includeTotals: args.includeTotals };

  const output = formatter.format(reportData, options);
  writeOutput(output, args.outputPath);
}

main();