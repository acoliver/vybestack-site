/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    subscribers: new Set(),
    updateFn: (prev?: T) => {
      if (disposed) return prev!
      const result = updateFn(prev)
      return result
    },
  }
  
  const executeCallback = () => {
    if (!disposed) {
      const previousActive = getActiveObserver()
      try {
        setActiveObserver(observer)
        observer.value = observer.updateFn(observer.value)
      } finally {
        setActiveObserver(previousActive)
      }
    }
  }
  
  // Execute callback to establish dependencies and trigger initial run
  executeCallback()
  
  return () => {
    disposed = true
  }
}
