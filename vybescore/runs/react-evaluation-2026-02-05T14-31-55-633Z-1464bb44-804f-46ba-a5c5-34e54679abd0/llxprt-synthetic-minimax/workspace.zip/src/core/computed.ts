/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let currentValue = value

  const observer: Observer<T> = {
    name: options?.name,
    value: currentValue,
    subscribers: new Set(),
    updateFn: (prev?: T) => {
      // Execute the update function to compute new value
      const result = updateFn(prev)
      currentValue = result
      return result
    },
  }
  
  const getter = (): T => {
    const previousActive = getActiveObserver()
    try {
      setActiveObserver(observer)
      currentValue = observer.updateFn(currentValue)
    } finally {
      setActiveObserver(previousActive)
    }
    
    return currentValue!
  }
  
  return getter
}
