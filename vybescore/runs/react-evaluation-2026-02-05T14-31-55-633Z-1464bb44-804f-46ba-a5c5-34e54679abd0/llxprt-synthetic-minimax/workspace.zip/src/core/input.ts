/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  GetterFn as Getter
} from '../types/reactive.js'

type Listener = {
  getter: Getter<unknown>
  notify: () => void
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  const listeners: Set<Listener> = new Set()

  const read: GetterFn<T> = () => {
    // Register active observer for dependency tracking
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      listeners.add({
        getter: read as Getter<unknown>,
        notify: () => {
          if (activeObserver.updateFn) {
            activeObserver.updateFn(activeObserver.value)
          }
        }
      })
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = typeof equal === 'function' ? equal : 
                    equal === true ? ((a: T, b: T) => a === b) : undefined
    
    const shouldNotify = !equalFn || !equalFn(currentValue, nextValue)
    if (shouldNotify) {
      currentValue = nextValue
      
      // Notify all registered listeners
      const currentListeners = Array.from(listeners)
      for (const listener of currentListeners) {
        listener.notify()
      }
    }
    return currentValue
  }

  return [read, write]
}
