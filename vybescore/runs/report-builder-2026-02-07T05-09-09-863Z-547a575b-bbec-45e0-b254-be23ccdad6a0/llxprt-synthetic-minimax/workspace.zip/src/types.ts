// Shared types and interfaces for the Report Builder CLI

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CliOptions {
  dataPath: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

export interface Formatter {
  (data: ReportData, includeTotals: boolean): string;
}