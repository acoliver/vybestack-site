import { ReportData } from '../types.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const parts: string[] = [];
  
  // Title (simple text, no markdown formatting)
  parts.push(data.title);
  parts.push('');
  
  // Summary
  parts.push(data.summary);
  parts.push('');
  
  // Entries section heading
  parts.push('Entries:');
  
  // Bullet list entries
  for (const entry of data.entries) {
    const amountFormatted = `$${entry.amount.toFixed(2)}`;
    parts.push(`- ${entry.label}: ${amountFormatted}`);
  }
  
  // Optional total
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = `$${total.toFixed(2)}`;
    parts.push(`Total: ${totalFormatted}`);
  }
  
  return parts.join('\n');
}