import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): CliOptions {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataPath = resolve(args[0]);
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    throw new Error('Missing required --format option');
  }
  
  const format = args[formatIndex + 1];
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format '${format}'. Supported formats: markdown, text`);
  }
  
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse remaining options
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = resolve(args[i + 1]);
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  return {
    dataPath,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals
  };
}

function parseJsonFile(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing summary field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid or missing entries field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  if (format === 'markdown') {
    return renderMarkdown(data, includeTotals);
  } else {
    return renderText(data, includeTotals);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    console.log(content);
  }
}

// Main execution
try {
  const options = parseArguments(process.argv);
  const data = parseJsonFile(options.dataPath);
  const report = renderReport(data, options.format, options.includeTotals);
  writeOutput(report, options.outputPath);
} catch (error) {
  console.error(`Error: ${error instanceof Error ? error.message : error}`);
  process.exit(1);
}
