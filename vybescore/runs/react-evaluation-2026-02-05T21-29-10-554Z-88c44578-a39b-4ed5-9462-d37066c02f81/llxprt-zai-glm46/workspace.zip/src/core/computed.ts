/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed
  const dependentObservers = new Set<Observer<T>>()
  let isUpdating = false

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && !isUpdating) {
      // Track dependency: register current observer as dependent on this computed
      o.observer = observer
      dependentObservers.add(observer as Observer<T>)
      
      // Re-compute to establish dependency chain
      isUpdating = true
      try {
        updateObserver(o)
      } finally {
        isUpdating = false
      }
    }
    return o.value!
  }

  // Compute initial value
  updateObserver(o)

  // Override updateFn to notify dependents when this computed updates
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    // Notify all dependent observers
    const dependentsCopy = Array.from(dependentObservers)
    for (const depObserver of dependentsCopy) {
      updateObserver(depObserver as Observer<unknown>)
    }
    return newValue
  }

  return getter
}
