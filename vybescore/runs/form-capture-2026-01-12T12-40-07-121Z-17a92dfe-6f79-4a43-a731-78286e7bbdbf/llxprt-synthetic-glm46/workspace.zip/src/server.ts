import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - sql.js doesn't provide typings
import initSqlJs from "sql.js";

// Import database schema
const schemaSql = fs.readFileSync(path.join(process.cwd(), "db", "schema.sql"), "utf8");

// Environment configuration
const PORT = process.env.PORT || 3535;

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field?: string;
  message: string;
}

// Initialize Express app
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use("/public", express.static(path.join(process.cwd(), "public")));

// Set EJS as view engine
app.set("view engine", "ejs");
app.set("views", path.join(process.cwd(), "src", "templates"));

// Database initialization
let db: unknown = null;

async function initializeDatabase(): Promise<void> {
  try {
    // Initialize sql.js
    const SQL = await initSqlJs();
    
    // Check if database file exists
    const dbPath = path.join(process.cwd(), "data", "submissions.sqlite");
    
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer) as unknown;
    } else {
      // Create new database
      db = new SQL.Database() as unknown;
      
      // Execute schema to create tables
      (db as { exec(sql: string): void }).exec(schemaSql);
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Save database to file
      const data = (db as { export(): Uint8Array }).export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    }
    
    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Failed to initialize database:", error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const dbPath = path.join(process.cwd(), "data", "submissions.sqlite");
    const data = (db as { export(): Uint8Array }).export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Form validation
function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields validation
  if (!formData.firstName?.trim()) {
    errors.push({ field: "firstName", message: "First name is required" });
  }
  
  if (!formData.lastName?.trim()) {
    errors.push({ field: "lastName", message: "Last name is required" });
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: "streetAddress", message: "Street address is required" });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: "city", message: "City is required" });
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: "stateProvince", message: "State/Province/Region is required" });
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push({ field: "postalCode", message: "Postal/Zip code is required" });
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: "country", message: "Country is required" });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: "email", message: "Email is required" });
  } else {
    // Email validation (simple regex)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push({ field: "email", message: "Email is not valid" });
    }
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: "phone", message: "Phone number is required" });
  } else {
    // Phone validation (international format)
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push({ field: "phone", message: "Phone number is not valid" });
    }
  }
  
  return errors;
}

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("form", { 
    errors: [], 
    values: {} 
  });
});

app.post("/submit", (req: Request, res: Response) => {
  const formData = req.body as FormData;
  
  // Validate input
  const validationErrors = validateFormData(formData);
  
  if (validationErrors.length > 0) {
    // Re-render form with errors and submitted values
    const errorMessages = validationErrors.map(error => error.message);
    return res.status(400).render("form", { 
      errors: errorMessages, 
      values: formData 
    });
  }
  
  try {
    // Insert into database
    const dbTyped = db as {
      prepare(sql: string): { run(params: unknown[]): void; free(): void }
    };
    const stmt = dbTyped.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to file
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error("Database insertion error:", error);
    return res.status(500).render("form", { 
      errors: ["An error occurred while saving your submission. Please try again."], 
      values: formData 
    });
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || "friend";
  res.render("thank-you", { firstName });
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = (signal: string) => {
      console.log(`Received ${signal}, shutting down gracefully`);
      
      server.close(() => {
        console.log("HTTP server closed");
        
        // Close database connection
        if (db) {
          (db as { close(): void }).close();
          console.log("Database connection closed");
        }
        
        process.exit(0);
      });
    };
    
    process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
    process.on("SIGINT", () => gracefulShutdown("SIGINT"));
    
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();
