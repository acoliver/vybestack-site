// Import Express dynamically to avoid TS errors
import path from 'node:path';

// Create a simple Express app for testing
export async function createTestApp() {
  const { default: express } = await import('express');
  
  const app = express();
  
  // Configure middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Serve static files
  app.use('/public', express.static(path.resolve('public')));
  
  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve('src', 'templates'));
  
  return app;
}