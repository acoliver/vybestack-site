export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface FormErrors {
  [key: string]: string;
}

export function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State / Province / Region is required';
  }
  
  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal / Zip code is required';
  }
  
  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation (allow alphanumeric)
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal/zip code';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow international format: +44 20 7946 0958, +54 9 11 1234-5678
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes for international support
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}