// Import Database type via dynamic import to avoid TS errors
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

let db: any = null;

export async function initDatabase(): Promise<any> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load SQL.js library
  // @ts-expect-error - sql.js types aren't available at compile time
  const SQL = await import('sql.js');
  
  // Initialize SQL.js module
  const SQLModule = await SQL.default();

  // Load existing database or create new one
  let dbData: Uint8Array;
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    dbData = new Uint8Array(fileBuffer);
  } else {
    // Create empty database if it doesn't exist
    dbData = new Uint8Array(0);
  }

  db = new SQLModule.Database(dbData);

  // Initialize schema
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.run(schema);

  return db;
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  // Export database to binary data
  const data = db.export();
  
  // Write to disk
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

export function getDatabase(): any {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}