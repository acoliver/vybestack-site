import path from 'node:path';
import { initDatabase, saveDatabase, closeDatabase } from './database.js';
import { FormData, validateForm } from './validation.js';

interface Server {
  close: () => void;
}

let server: any = null;

async function createServer(): Promise<Server> {
  // Initialize database
  const db = await initDatabase();
  
  // Dynamically import Express to avoid TypeScript errors
  const { default: express } = await import('express');
  
  // Create Express app
  const app = express();
  
  // Configure middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Serve static files
  app.use('/public', express.static(path.resolve('public')));
  
  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve('src', 'templates'));
  
  // Routes
  app.get('/', (req, res) => {
    res.render('form', {
      values: {},
      errors: null
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    // Validate form
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        values: formData,
        errors: Object.values(validation.errors)
      });
    }
    
    // Insert into database
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database to disk
      saveDatabase();
      
      // Redirect to thank you page
      return res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      return res.status(500).render('form', {
        values: formData,
        errors: ['Server error. Please try again.']
      });
    }
  });
  
  app.get('/thank-you', (req, res) => {
    // Get the most recent submission to display first name
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const result = stmt.get() as { first_name: string } | undefined;
      stmt.free();
      
      const firstName = result?.first_name || 'Friend';
      
      res.render('thank-you', { firstName });
    } catch (error) {
      console.error('Database error:', error);
      const firstName = 'Friend';
      res.render('thank-you', { firstName });
    }
  });
  
  // Start server
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const serverInstance = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Return server instance
  return {
    close: () => {
      serverInstance.close(() => {
        closeDatabase();
      });
    }
  };
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
  if (server && server.close) {
    server.close();
  }
});

// Start server if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  createServer().then((serverInstance) => {
    server = serverInstance;
  }).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export for testing
export { createServer };
