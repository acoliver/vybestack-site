import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_PAGE = 1000000;
const MAX_LIMIT = 100;

function validatePaginationParams(pageParam: string | undefined, limitParam: string | undefined): { page: number; limit: number } {
  let page: number;
  let limit: number;

  // Validate page parameter
  if (pageParam === undefined) {
    page = 1;
  } else {
    const pageNum = Number(pageParam);
    if (isNaN(pageNum) || !isFinite(pageNum)) {
      throw new Error('Page must be a valid number');
    }
    if (pageNum <= 0) {
      throw new Error('Page must be greater than 0');
    }
    if (pageNum > MAX_PAGE) {
      throw new Error();
    }
    page = Math.floor(pageNum);
  }

  // Validate limit parameter
  if (limitParam === undefined) {
    limit = 5;
  } else {
    const limitNum = Number(limitParam);
    if (isNaN(limitNum) || !isFinite(limitNum)) {
      throw new Error('Limit must be a valid number');
    }
    if (limitNum <= 0) {
      throw new Error('Limit must be greater than 0');
    }
    if (limitNum > MAX_LIMIT) {
      throw new Error();
    }
    limit = Math.floor(limitNum);
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const { page, limit } = validatePaginationParams(pageParam, limitParam);
      
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
