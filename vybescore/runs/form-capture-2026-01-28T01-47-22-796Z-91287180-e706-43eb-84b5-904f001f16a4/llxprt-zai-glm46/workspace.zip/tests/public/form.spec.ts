import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer } from '../../src/server.js';

let server: Awaited<ReturnType<typeof startServer>>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Start server in background
  server = await startServer();
  // Give it a moment to start
  await new Promise(resolve => setTimeout(resolve, 500));
});

afterAll(async () => {
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    
    // Check all required fields exist
    expect(response.text).toContain('name="firstName"');
    expect(response.text).toContain('name="lastName"');
    expect(response.text).toContain('name="streetAddress"');
    expect(response.text).toContain('name="city"');
    expect(response.text).toContain('name="stateProvince"');
    expect(response.text).toContain('name="postalCode"');
    expect(response.text).toContain('name="country"');
    expect(response.text).toContain('name="email"');
    expect(response.text).toContain('name="phone"');
    
    // Check form submission endpoint
    expect(response.text).toContain('action="/submit"');
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'not-an-email',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: 'invalid-phone!@#',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number can only contain');
  });

  it('persists valid submission and redirects', async () => {
    // Clear database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Maria',
      lastName: 'González',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.gonzalez@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles international postal codes', async () => {
    const formData = {
      firstName: 'James',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'james@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
  });

  it('renders thank you page', async () => {
    const response = await request(app).get('/thank-you?name=John');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you, John!');
    expect(response.text).toContain('stranger on the internet');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Doe',
        email: 'invalid-email',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Jane');
    expect(response.text).toContain('Doe');
    expect(response.text).toContain('invalid-email');
  });
});
