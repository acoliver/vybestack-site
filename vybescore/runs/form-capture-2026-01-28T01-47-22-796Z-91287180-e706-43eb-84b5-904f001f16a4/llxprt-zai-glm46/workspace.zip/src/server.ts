import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs/promises';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
// When running from source, use src/templates; when running compiled, use dist/templates
const isDevelopment = process.argv[1].includes('src/server.ts');
const viewsPath = isDevelopment 
  ? path.join(__dirname, 'templates')
  : path.join(__dirname, '../src/templates');
app.set('views', viewsPath);

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and optional leading +
  const phoneRegex = /^[\d\s\-()+]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric strings with spaces (UK, Argentine, etc.)
  const postalRegex = /^[A-Za-z0-9\s]*$/;
  return postalRegex.test(postal);
}

function validateForm(values: FormValues): string[] {
  const errors: string[] = [];

  // Required fields
  if (!values.firstName?.trim()) errors.push('First name is required');
  if (!values.lastName?.trim()) errors.push('Last name is required');
  if (!values.streetAddress?.trim()) errors.push('Street address is required');
  if (!values.city?.trim()) errors.push('City is required');
  if (!values.stateProvince?.trim()) errors.push('State / Province / Region is required');
  if (!values.postalCode?.trim()) errors.push('Postal / Zip code is required');
  if (!values.country?.trim()) errors.push('Country is required');
  if (!values.email?.trim()) errors.push('Email is required');
  if (!values.phone?.trim()) errors.push('Phone number is required');

  // Email format
  if (values.email?.trim() && !validateEmail(values.email.trim())) {
    errors.push('Please enter a valid email address');
  }

  // Phone format
  if (values.phone?.trim() && !validatePhone(values.phone.trim())) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  // Postal code format
  if (values.postalCode?.trim() && !validatePostalCode(values.postalCode.trim())) {
    errors.push('Postal code can only contain letters, digits, and spaces');
  }

  return errors;
}

// Initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  try {
    await fs.mkdir(dataDir, { recursive: true });
  } catch (err) {
    // Directory might already exist
  }

  // Load existing database or create new one
  let dbData: Uint8Array | null = null;
  try {
    const dbFile = await fs.readFile(DB_PATH);
    dbData = new Uint8Array(dbFile);
  } catch (err) {
    // File doesn't exist yet, will create new database
  }

  db = new SQL.Database(dbData);

  // Check if we need to initialize schema
  const tables = db.exec('SELECT name FROM sqlite_master WHERE type="table"');
  if (tables.length === 0 || tables[0].values.length === 0) {
    const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
    db.run(schema);
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const data = db.export();
  const buffer = Buffer.from(data);
  await fs.writeFile(DB_PATH, buffer);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    values: {},
    errors: [],
  });
});

app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const values: FormValues = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const errors = validateForm(values);

    if (errors.length > 0) {
      res.status(400);
      return res.render('form', { values, errors });
    }

    // Insert into database
    if (!db) throw new Error('Database not initialized');
    
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        values.firstName.trim(),
        values.lastName.trim(),
        values.streetAddress.trim(),
        values.city.trim(),
        values.stateProvince.trim(),
        values.postalCode.trim(),
        values.country.trim(),
        values.email.trim(),
        values.phone.trim(),
      ]
    );

    // Save database to disk
    await saveDatabase();

    // Redirect to thank you page
    res.redirect(302, `/thank-you?name=${encodeURIComponent(values.firstName.trim())}`);
  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.name?.toString() || 'friend';
  res.render('thank-you', { firstName });
});

// Error handling
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).render('form', {
    values: {},
    errors: ['An unexpected error occurred. Please try again.'],
  });
});

// Start server and initialize database
async function startServer(): Promise<void> {
  await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('HTTP server closed');
    });

    if (db) {
      db.close();
      console.log('Database closed');
    }

    process.exit(0);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Export app for testing
export { app, startServer };

// Start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
