/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn, Effect, runEffect } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const effect: Effect = {
    fn: () => {
      updateFn(value)
    },
    deps: new Set(),
    disposed: false
  }
  
  // Execute to establish dependencies
  runEffect(effect)
  
  return () => {
    effect.disposed = true
    effect.deps.forEach(cell => {
      cell.dependents.delete(effect)
    })
    effect.deps.clear()
  }
}