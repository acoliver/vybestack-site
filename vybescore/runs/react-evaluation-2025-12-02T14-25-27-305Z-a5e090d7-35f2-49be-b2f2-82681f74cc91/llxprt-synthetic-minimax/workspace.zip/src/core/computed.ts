/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  readCell,
  createComputedCell,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === false ? ((a: T, b: T) => a !== b) : 
                  undefined

  const cell = createComputedCell<T>(updateFn, equalFn)

  const getter: GetterFn<T> = () => {
    return readCell(cell)
  }

  return getter
}