/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  readCell,
  writeCell,
  createCell,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === false ? ((a: T, b: T) => a !== b) : 
                  undefined

  const cell = createCell<T>(value, equalFn)

  const read: GetterFn<T> = () => {
    return readCell(cell)
  }

  const write: SetterFn<T> = (nextValue) => {
    writeCell(cell, nextValue)
    return cell.value
  }

  return [read, write]
}