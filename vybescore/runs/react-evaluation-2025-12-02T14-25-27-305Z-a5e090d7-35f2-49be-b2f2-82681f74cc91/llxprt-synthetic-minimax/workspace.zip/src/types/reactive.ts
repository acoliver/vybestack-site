/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string
}

// Simple cell-based reactive system
export interface Cell<T> {
  value: T
  dependents: Set<Effect>
  fn?: () => T
  equalFn?: EqualFn<unknown>
}

export interface Effect {
  fn: UpdateFn<unknown>
  deps: Set<Cell<unknown>>
  disposed: boolean
}

let activeEffect: Effect | null = null

export function getActiveEffect(): Effect | null {
  return activeEffect
}

export function setActiveEffect(effect: Effect | null): void {
  activeEffect = effect
}

export function readCell<T>(cell: Cell<T>): T {
  if (activeEffect) {
    activeEffect.deps.add(cell)
    cell.dependents.add(activeEffect)
  }
  return cell.value
}

export function writeCell<T>(cell: Cell<T>, value: T): void {
  const shouldNotify = !cell.equalFn || !cell.equalFn(cell.value, value)
  if (shouldNotify) {
    cell.value = value
    notifyCell(cell)
  }
}

export function notifyCell<T>(cell: Cell<T>): void {
  const dependents = Array.from(cell.dependents)
  dependents.forEach(effect => {
    if (!effect.disposed) {
      runEffect(effect)
    }
  })
}

export function runEffect(effect: Effect): void {
  if (effect.disposed) return
  
  // Clear old dependencies
  effect.deps.forEach(cell => {
    cell.dependents.delete(effect)
  })
  effect.deps.clear()
  
  // Execute function to establish new dependencies
  const previous = activeEffect
  activeEffect = effect
  
  try {
    effect.fn()
  } finally {
    activeEffect = previous
  }
}

export function createCell<T>(value: T, equalFn?: EqualFn<T>): Cell<T> {
  return {
    value,
    dependents: new Set(),
    equalFn: equalFn as EqualFn<unknown>
  }
}

export function createComputedCell<T>(fn: () => T, equalFn?: EqualFn<T>): Cell<T> {
  const cell: Cell<T> = {
    value: undefined as T,
    fn,
    dependents: new Set(),
    equalFn: equalFn as EqualFn<unknown>
  }
  
  // Initial computation
  const effect: Effect = {
    fn: () => {
      const newValue = fn()
      const shouldNotify = !cell.equalFn || !cell.equalFn(cell.value, newValue)
      if (shouldNotify) {
        cell.value = newValue
        notifyCell(cell)
      }
    },
    deps: new Set(),
    disposed: false
  }
  
  runEffect(effect)
  
  return cell
}

export function createEffect(fn: UpdateFn<unknown>): UnsubscribeFn {
  const effect: Effect = {
    fn,
    deps: new Set(),
    disposed: false
  }
  
  runEffect(effect)
  
  return () => {
    effect.disposed = true
    effect.deps.forEach(cell => {
      cell.dependents.delete(effect)
    })
    effect.deps.clear()
  }
}