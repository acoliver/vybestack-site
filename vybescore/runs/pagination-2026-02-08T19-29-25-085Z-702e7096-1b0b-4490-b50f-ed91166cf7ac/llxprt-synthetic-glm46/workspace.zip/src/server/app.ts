import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function parsePositiveInteger(value: string | undefined, defaultValue: number): number | null {
  if (value === undefined) return defaultValue;
  
  const num = Number(value);
  if (!Number.isInteger(num) || num <= 0) return null;
  return num;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = parsePositiveInteger(pageParam, 1);
    const limit = parsePositiveInteger(limitParam, 5);

    if (page === null || limit === null) {
      res.status(400).json({ error: 'Invalid pagination parameters. Page and limit must be positive integers.' });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
