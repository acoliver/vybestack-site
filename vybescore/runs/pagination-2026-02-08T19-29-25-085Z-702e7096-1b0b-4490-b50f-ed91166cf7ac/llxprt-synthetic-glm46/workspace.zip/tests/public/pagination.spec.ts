import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('pagination API', () => {
  it('handles invalid page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
    expect(response.body.error.toLowerCase()).toContain('page');
  });

  it('handles invalid limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=xyz');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
    expect(response.body.error.toLowerCase()).toContain('page');
  });

  it('handles zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
    expect(response.body.error.toLowerCase()).toContain('page');
  });

  it('handles negative limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=-5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
    expect(response.body.error.toLowerCase()).toContain('page');
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBeGreaterThan(0);
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('paginates correctly between pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response1 = await request(app).get('/inventory?page=1&limit=3');
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    
    expect(response1.status).toBe(200);
    expect(response2.status).toBe(200);
    
    // Pages should have different items
    const page1ItemIds = response1.body.items.map((item: any) => item.id);
    const page2ItemIds = response2.body.items.map((item: any) => item.id);
    
    expect(page1ItemIds).not.toEqual(page2ItemIds);
  });
});