import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { Format } from '../types.js';

export const renderers = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export type Renderer = typeof renderers[Format];

export function getRenderer(format: Format) {
  return renderers[format];
}