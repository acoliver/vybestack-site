#!/usr/bin/env node

import fs from 'node:fs';
import { getRenderer } from '../formats/index.js';
import type { ReportData, RenderOptions, Format } from '../types.js';

interface CliOptions {
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): { inputFile: string; options: CliOptions } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const inputFile = args[0];
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false,
  };
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error('Unsupported format');
      }
      options.format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
    
    i++;
  }
  
  if (!options.format) {
    throw new Error('--format is required');
  }
  
  return { inputFile, options };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries field');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid report data: entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: entry missing or invalid label field');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: entry missing or invalid amount field');
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { inputFile, options } = parseArguments();
    
    let fileContent: string;
    try {
      fileContent = fs.readFileSync(inputFile, 'utf-8');
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${inputFile}`);
      }
      throw error;
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error('Invalid JSON format');
    }
    
    const reportData = validateReportData(jsonData);
    const renderer = getRenderer(options.format);
    const renderOptions: RenderOptions = { includeTotals: options.includeTotals };
    const output = renderer(reportData, renderOptions);
    
    if (options.output) {
      fs.writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();