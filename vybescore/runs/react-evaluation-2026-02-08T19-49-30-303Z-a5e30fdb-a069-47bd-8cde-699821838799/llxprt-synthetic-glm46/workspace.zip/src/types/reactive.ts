/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: ObserverR[] | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  const observers = [...subject.observers]
  for (const observer of observers) {
    updateObserver(observer as Observer<unknown>)
  }
}

declare global {
  const __subjectStack: Subject<unknown>[]
}

export const subjectStack: Subject<unknown>[] = []

export function recordSubjectAccess<T>(subject: Subject<T>): void {
  if (activeObserver && !(subjectStack.some(s => s.name === subject.name && s.value === subject.value))) {
    subjectStack.push(subject as Subject<unknown>)
  }
}

export function getRecordedSubjects(): Subject<unknown>[] {
  return subjectStack
}

export function clearRecordedSubjects(): void {
  subjectStack.length = 0
}
