/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  recordSubjectAccess,
  Subject,
  clearRecordedSubjects,
  getRecordedSubjects,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject that represents this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: [],
    value: value as T,
    equalFn: undefined
  }
  
  // Don't initialize yet - wait for first call
  
  const computed: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Record this computed value as a dependency
      recordSubjectAccess(computedSubject)
    }
    
    // When this computed is called, re-evaluate if dependencies changed
    clearRecordedSubjects()
    const oldValue = o.value
    updateObserver(o)
    
    // Get the new dependencies during this execution
    const newDependencies = getRecordedSubjects()
    
    // Update observer registrations
    newDependencies.forEach(dep => {
      if (!dep.observers) dep.observers = []
      if (!dep.observers.includes(o)) {
        dep.observers.push(o)
      }
    })
    
    // Update the computed subject and notify its observers if value changed
    if (oldValue !== o.value) {
      computedSubject.value = o.value as T
      notifyObservers(computedSubject)
    }
    
    return o.value!
  }
  
  return computed
}
