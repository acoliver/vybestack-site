/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getRecordedSubjects, clearRecordedSubjects } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  const dependencies = getRecordedSubjects()
  clearRecordedSubjects()
  
  let disposed = false
  
  // Register this callback with all dependencies
  dependencies.forEach(dep => {
    if (!dep.observers) dep.observers = []
    if (!dep.observers.includes(observer)) {
      dep.observers.push(observer)
    }
  })
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all dependencies
    dependencies.forEach(dep => {
      if (dep.observers) {
        const index = dep.observers.indexOf(observer)
        if (index > -1) {
          dep.observers.splice(index, 1)
        }
      }
    })
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
