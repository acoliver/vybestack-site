/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equal parameter to function if needed
  const equalFn: EqualFn<T> | undefined = typeof equal === 'function'
    ? equal
    : equal === true
      ? (lhs: T, rhs: T) => lhs === rhs
      : undefined;

  // Define subject with proper typing
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  };

  // Track observers that depend on this input
  const observers: Set<Observer<T>> = new Set();

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver();
    if (activeObserver) {
      // Add the active observer to the set of observers
      observers.add(activeObserver as Observer<T>);
    }
    return s.value;
  };

  const write: SetterFn<T> = (nextValue: T) => {
    // Only update if values are different according to equalFn
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue;
      // Update all registered observers
      observers.forEach(observer => {
        updateObserver(observer);
      });
    }
    return s.value;
  };

  return [read, write];
}