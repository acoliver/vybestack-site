/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equal parameter to function if needed
  const equalFn: EqualFn<T> | undefined = typeof equal === 'function' 
    ? equal 
    : equal === true 
      ? (lhs: T, rhs: T) => lhs === rhs 
      : undefined

  let currentValue: T | undefined = value
  const disposed = false
  
  // Track observers that depend on this computed value
  const observers: Set<Observer<T>> = new Set()
  
  const observer: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (_prevValue?: T) => {
      if (disposed) {
        throw new Error("Computed has been disposed")
      }
      
      const newValue = updateFn()
      if (!equalFn || currentValue === undefined || !equalFn(currentValue, newValue)) {
        currentValue = newValue
        // Notify dependent observers of the change
        observers.forEach(obs => updateObserver(obs))
      }
      return currentValue
    }
  }
  
  // Compute initial value
  updateObserver(observer)
  currentValue = observer.value
  
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this computed value as a dependency of the active observer
      observers.add(activeObserver as Observer<T>)
    }
    return currentValue as T
  }
  
  return read
}