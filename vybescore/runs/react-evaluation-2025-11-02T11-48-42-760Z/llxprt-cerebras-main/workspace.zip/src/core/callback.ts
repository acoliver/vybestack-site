/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create an observer that will call our updateFn when dependencies change
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // When dependencies change, execute the callback
      return updateFn(prevValue)
    }
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let unsubscribed = false
  
  // Return unsubscribe function
  return () => {
    if (unsubscribed) return
    unsubscribed = true
    
    // For a real implementation, we would remove this observer from all dependency tracking
    // In this simplified version, we just change the update function to prevent further execution
    observer.updateFn = (_prevValue?: T) => {
      if (unsubscribed) {
        // Don't throw error, just return current value
        return observer.value as T
      }
      return updateFn(observer.value)
    }
  }
}