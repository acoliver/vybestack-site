// Type declaration for sql.js module
export interface InitSqlJsStatic {
  Database: typeof Database;
  Statement: unknown;
  initSqlJs(config?: { locateFile?: (file: string) => string }): Promise<InitSqlJsStatic>;
}

declare module 'sql.js' {
  export class Database {
    constructor(data?: ArrayBuffer);
    exec(sql: string): unknown[];
    run(sql: string): unknown;
    prepare(sql: string): Statement;
    export(): ArrayBuffer;
    close(): void;
  }

  export class Statement {
    run(...params: unknown[]): unknown;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    step(): boolean;
    getAsObject(): unknown;
    bind(...params: unknown[]): void;
    free(): void;
  }

  export const initSqlJs: (config?: { locateFile?: (file: string) => string }) => Promise<InitSqlJsStatic>;
}