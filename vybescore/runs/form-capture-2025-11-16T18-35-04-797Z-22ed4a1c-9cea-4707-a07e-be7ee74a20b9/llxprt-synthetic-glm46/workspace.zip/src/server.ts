import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Form data types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Set up directory constants for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Global database reference
let db: Database | null = null;

/**
 * Initialize or load the SQLite database
 */
async function initializeDatabase(): Promise<Database> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const dbPath = path.join(dataDir, 'submissions.sqlite');
    
    // Initialize sql.js
    const SQLModule = await initSqlJs();
    let dbInstance: Database;
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbPath);
      const arrayBuffer = fileBuffer.buffer.slice(
        fileBuffer.byteOffset, 
        fileBuffer.byteOffset + fileBuffer.byteLength
      );
      const buffer = new Uint8Array(arrayBuffer);
      dbInstance = new SQLModule.Database(buffer);
      console.log('Database loaded from', dbPath);
    } else {
      // Create new database
      dbInstance = new SQLModule.Database();
      console.log('New database created');
    }
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf-8');
    dbInstance.run(schema);
    
    return dbInstance;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

/**
 * Save database to disk
 */
function saveDatabase(db: Database): void {
  try {
    const dataPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dataPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

/**
 * Validate form data
 */
function validateForm(formData: FormData): { isValid: boolean; errors: ValidationErrors } {
  const errors: ValidationErrors = {};
  
  // First name validation
  if (!formData.firstName || formData.firstName.trim().length === 0) {
    errors.firstName = 'First name is required';
  }
  
  // Last name validation
  if (!formData.lastName || formData.lastName.trim().length === 0) {
    errors.lastName = 'Last name is required';
  }
  
  // Street address validation
  if (!formData.streetAddress || formData.streetAddress.trim().length === 0) {
    errors.streetAddress = 'Street address is required';
  }
  
  // City validation
  if (!formData.city || formData.city.trim().length === 0) {
    errors.city = 'City is required';
  }
  
  // State/province validation
  if (!formData.stateProvince || formData.stateProvince.trim().length === 0) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  // Postal code validation (allow alphanumeric)
  if (!formData.postalCode || formData.postalCode.trim().length === 0) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
    errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and hyphens';
  }
  
  // Country validation
  if (!formData.country || formData.country.trim().length === 0) {
    errors.country = 'Country is required';
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email || formData.email.trim().length === 0) {
    errors.email = 'Email is required';
  } else if (!emailRegex.test(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation (allow international formats)
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (!formData.phone || formData.phone.trim().length === 0) {
    errors.phone = 'Phone number is required';
  } else if (!phoneRegex.test(formData.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

/**
 * Extract form data from request
 */
function extractFormData(req: express.Request): FormData {
  return {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
}

/**
 * Insert form submission into database
 */
function insertSubmission(db: Database, formData: FormData): void {
  const stmt = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
  } finally {
    stmt.free();
  }
}

// Create Express app
const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS templating
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: null, 
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', (req, res) => {
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  const formData = extractFormData(req);
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    // Return the form with errors
    const errorMessages = Object.values(validation.errors);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  try {
    // Insert into database
    insertSubmission(db, formData);
    
    // Save database to disk
    saveDatabase(db);
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while submitting the form. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown function
function gracefulShutdown(): void {
  console.log('Received termination signal. Shutting down gracefully...');
  
  if (db) {
    try {
      // Save database before closing
      saveDatabase(db);
      db.close();
      console.log('Database saved and closed.');
    } catch (error) {
      console.error('Error during database shutdown:', error);
    }
  }
  
  process.exit(0);
}

// Register shutdown handlers
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize and start server
async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    
    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();