import { createApp } from './src/server/app.ts';

// Test the pagination functionality
async function testPagination() {
  console.log('Testing pagination functionality...');
  
  const app = await createApp();
  
  // Test default page and limit
  console.log('\n1. Testing default page and limit:');
  const defaultRequest = { method: 'GET', url: '/inventory' };
  const defaultResponse = {
    status: null,
    json: function(data) {
      console.log('Status:', this.status);
      console.log('Response:', JSON.stringify(data, null, 2));
      return this;
    }
  };
  
  await new Promise((resolve, reject) => {
    const { req, res } = createMockReqRes(defaultRequest, defaultResponse);
    app.handle(req, res);
    res.on('finish', resolve);
    res.on('error', reject);
  });
  
  // Test specific page and limit
  console.log('\n2. Testing page=2&limit=3:');
  const page2Request = { method: 'GET', url: '/inventory?page=2&limit=3' };
  const page2Response = {
    status: null,
    json: function(data) {
      console.log('Status:', this.status);
      console.log('Response:', JSON.stringify(data, null, 2));
      return this;
    }
  };
  
  await new Promise((resolve, reject) => {
    const { req, res } = createMockReqRes(page2Request, page2Response);
    app.handle(req, res);
    res.on('finish', resolve);
    res.on('error', reject);
  });
  
  // Test invalid parameters
  console.log('\n3. Testing invalid page parameter:');
  const invalidRequest = { method: 'GET', url: '/inventory?page=invalid&limit=5' };
  const invalidResponse = {
    status: null,
    json: function(data) {
      console.log('Status:', this.status);
      console.log('Response:', JSON.stringify(data, null, 2));
      return this;
    }
  };
  
  await new Promise((resolve, reject) => {
    const { req, res } = createMockReqRes(invalidRequest, invalidResponse);
    app.handle(req, res);
    res.on('finish', resolve);
    res.on('error', reject);
  });
  
  console.log('\n4. Testing page=0 (should be invalid):');
  const zeroRequest = { method: 'GET', url: '/inventory?page=0&limit=5' };
  const zeroResponse = {
    status: null,
    json: function(data) {
      console.log('Status:', this.status);
      console.log('Response:', JSON.stringify(data, null, 2));
      return this;
    }
  };
  
  await new Promise((resolve, reject) => {
    const { req, res } = createMockReqRes(zeroRequest, zeroResponse);
    app.handle(req, res);
    res.on('finish', resolve);
    res.on('error', reject);
  });
}

function createMockReqRes(req, res) {
  return {
    req: {
      ...req,
      query: {},
      get: () => 'localhost'
    },
    res: {
      status: function(status) { 
        this.status = status; 
        return this; 
      },
      json: res.json.bind(res),
      send: function(data) { console.log('Send:', data); return this; },
      end: function() { return this; }
    }
  };
}

// Run the test
testPagination().catch(console.error);