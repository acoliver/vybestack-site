import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs: reject non-numeric, negative, zero, or excessive values with HTTP 400
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (!Number.isFinite(parsedPage) || parsedPage <= 0 || parsedPage > 10000) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive number <= 10000' });
      }
      page = Math.floor(parsedPage);
    }

    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (!Number.isFinite(parsedLimit) || parsedLimit <= 0 || parsedLimit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive number <= 100' });
      }
      limit = Math.floor(parsedLimit);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
