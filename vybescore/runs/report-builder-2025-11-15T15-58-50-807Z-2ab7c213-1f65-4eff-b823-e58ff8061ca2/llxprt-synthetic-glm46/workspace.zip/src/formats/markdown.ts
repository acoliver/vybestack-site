import type { ReportData, ReportRenderer } from '../types.js';

export const renderMarkdown: ReportRenderer = (data: ReportData, { includeTotals }) => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  const lines: string[] = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries',
  ];
  
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }
  
  if (includeTotals) {
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
};