# Report Formatters

This directory contains the formatter implementations for different output formats.

## Interface

All formatters must implement the `ReportRenderer` interface from `../types.js`:

```typescript
export type ReportRenderer = (data: ReportData, options: { includeTotals: boolean }) => string;
```

## Adding New Formatters

To add a new format:

1. Create a new file in this directory (e.g., `html.ts`)
2. Implement the `ReportRenderer` interface and export it
3. Add the renderer to the `rendererMap` in `src/cli/report.ts`

Example:

```typescript
import type { ReportData, ReportRenderer } from '../types.js';

export const renderHtml: ReportRenderer = (data: ReportData, { includeTotals }) => {
  // Implementation here
  return htmlString;
};
```

## Available Formatters

- **markdown.ts**: Formats report as Markdown with headings and bullet points
- **text.ts**: Formats report as plain text with simple formatting