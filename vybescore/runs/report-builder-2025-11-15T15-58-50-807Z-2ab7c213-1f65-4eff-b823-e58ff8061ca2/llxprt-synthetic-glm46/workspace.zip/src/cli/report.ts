#!/usr/bin/env node

import { promises as fs } from 'fs';
import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const rendererMap: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(): ReportOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const formatFlag = args[1];
  const format = args[2];
  
  if (formatFlag !== '--format') {
    console.error('Missing --format flag');
    process.exit(1);
  }
  
  if (!rendererMap[format]) {
    console.error('Unsupported format: Must be one of "markdown" or "text"');
    process.exit(1);
  }
  
  const options: ReportOptions = {
    format: format as 'markdown' | 'text',
    includeTotals: false,
  };
  
  let i = 3;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('--output requires a path');
        process.exit(1);
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
    i++;
  }
  
  return options;
}

async function readReportData(jsonPath: string): Promise<ReportData> {
  try {
    const content = await fs.readFile(jsonPath, 'utf8');
    const data = JSON.parse(content);
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Entry missing "label" field');
        
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry missing "amount" field');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Invalid JSON in ${jsonPath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error reading or validating ${jsonPath}: ${error.message}`);
    } else {
      console.error(`Unknown error reading ${jsonPath}`);
    }
    process.exit(1);
  }
}

async function main(): Promise<void> {
  const options = parseArguments();
  const jsonPath = process.argv[2];
  
  const data = await readReportData(jsonPath);
  const renderer = rendererMap[options.format];
  const output = renderer(data, { includeTotals: options.includeTotals });
  
  if (options.output) {
    try {
      await fs.writeFile(options.output, output, 'utf8');
      console.log(`Report written to ${options.output}`);
    } catch (error) {
      console.error(`Error writing to ${options.output}:`, error);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});