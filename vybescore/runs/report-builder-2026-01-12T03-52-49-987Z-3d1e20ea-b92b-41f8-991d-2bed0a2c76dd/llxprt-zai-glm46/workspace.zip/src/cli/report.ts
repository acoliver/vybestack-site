#!/usr/bin/env node

import * as fs from 'node:fs';
import { validateReportData } from '../utils.js';
import { getFormatter } from '../formats/index.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  let jsonContent: string;
  try {
    jsonContent = fs.readFileSync(args.dataFile, 'utf-8');
  } catch (err) {
    console.error(`Error: Unable to read file "${args.dataFile}"`);
    process.exit(1);
  }

  let parsedData: unknown;
  try {
    parsedData = JSON.parse(jsonContent);
  } catch (err) {
    console.error(`Error: Invalid JSON in file "${args.dataFile}"`);
    process.exit(1);
  }

  let reportData;
  try {
    reportData = validateReportData(parsedData);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`Error: ${message}`);
    process.exit(1);
  }

  const options: RenderOptions = { includeTotals: args.includeTotals };

  let output: string;
  try {
    const formatter = getFormatter(args.format);
    output = formatter(reportData, options);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`Error: ${message}`);
    process.exit(1);
  }

  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (err) {
      console.error(`Error: Unable to write to file "${args.outputPath}"`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
