import type { ReportData, RenderOptions } from '../types.js';
import { formatAmount, computeTotal } from '../utils.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(computeTotal(data.entries))}`);
  }

  return lines.join('\n');
}
