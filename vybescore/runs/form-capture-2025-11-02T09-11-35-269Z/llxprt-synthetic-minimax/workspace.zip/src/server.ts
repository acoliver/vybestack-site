import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Database setup
let db: Database | null = null;

interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateField(fieldName: string, value: string): string | null {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return null;
}

function validateForm(data: SubmissionData): { errors: ValidationErrors; isValid: boolean } {
  const errors: ValidationErrors = {};

  // Required field validation
  const firstNameError = validateField('First name', data.firstName);
  if (firstNameError) errors.firstName = firstNameError;

  const lastNameError = validateField('Last name', data.lastName);
  if (lastNameError) errors.lastName = lastNameError;

  const streetError = validateField('Street address', data.streetAddress);
  if (streetError) errors.streetAddress = streetError;

  const cityError = validateField('City', data.city);
  if (cityError) errors.city = cityError;

  const stateError = validateField('State / Province / Region', data.stateProvince);
  if (stateError) errors.stateProvince = stateError;

  const postalError = validateField('Postal / Zip code', data.postalCode);
  if (postalError) errors.postalCode = postalError;
  else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  const countryError = validateField('Country', data.country);
  if (countryError) errors.country = countryError;

  const emailError = validateField('Email', data.email);
  if (emailError) errors.email = emailError;
  else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  const phoneError = validateField('Phone number', data.phone);
  if (phoneError) errors.phone = phoneError;
  else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    errors,
    isValid: Object.keys(errors).length === 0,
  };
}

// Initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file),
  });

  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const dbDir = path.dirname(dbPath);

  // Create data directory if it doesn't exist
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    // Create table using schema
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    db.exec(schema);
  }
}

// Routes

// GET / - Render form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    data: {},
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const data: SubmissionData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(data);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      data,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone,
    ]);

    stmt.free();

    // Save database to file
    const dataDir = path.join(__dirname, '..', 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const binary = db.export();
    fs.writeFileSync(dbPath, binary);
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`\nReceived ${signal}. Starting graceful shutdown...`);
  
  if (db) {
    const dataDir = path.join(__dirname, '..', 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const binary = db.export();
    fs.writeFileSync(dbPath, binary);
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<import('http').Server> {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server reference for tests
    const globalRef = globalThis as typeof globalThis & { __server__?: import('http').Server };
    globalRef.__server__ = server;
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
    throw error;
  }
}

// Auto-start server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;
export { startServer };