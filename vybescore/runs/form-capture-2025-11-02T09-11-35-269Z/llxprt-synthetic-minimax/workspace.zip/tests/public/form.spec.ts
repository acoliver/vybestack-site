import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';

let server: import('http').Server | undefined;
let app: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  beforeAll(async () => {
    // Import and start the server
    const serverModule = await import('../../dist/server.js');
    app = serverModule.default;
    
    // Give the server a moment to start
    await new Promise(resolve => setTimeout(resolve, 100));
  });

  afterAll(() => {
    // Clean up the database file
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    if (server && server.close) {
      server.close();
    }
  });

  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('form').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check that all labels are associated with inputs
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="stateProvince"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567',
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(submissionData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main Street',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'United States',
        email: 'invalid-email',
        phone: '+1 555 123 4567',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
  });

  it('accepts international postal codes', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Juan',
        lastName: 'Pérez',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1043AAZ',
        country: 'Argentina',
        email: 'juan.perez@example.com',
        phone: '+54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts international phone numbers', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 2AA',
        country: 'United Kingdom',
        email: 'jane.smith@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('renders thank you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('.thank-you-content').length).toBe(1);
    expect($('.humor-text').length).toBeGreaterThan(0);
    
    // Check for humorous text about data usage
    const pageText = $.text().toLowerCase();
    expect(pageText).toMatch(/spam|identity|data/);
  });
});