/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core interfaces
export interface Signal<T> {
  value: T
  subscribers: Set<() => void>
  notify: () => void
}

export interface InputSignal<T> extends Signal<T> {
  read: GetterFn<T>
  write: SetterFn<T>
}

export interface ComputedSignal<T> extends Signal<T> {
  getter: GetterFn<T>
  dependencies: Set<InputSignal<unknown>>
  isDirty: boolean
  recompute: () => void
}

export interface Subject<T> {
  subscribe: (observer: ObserverR<T>) => UnsubscribeFn
  unsubscribe: (observer: ObserverR<T>) => void
  notify: (value?: T) => void
}

// Global signal registry for dependency tracking
const signalRegistry = new Set<Signal<unknown>>()

export function registerSignal<T>(signal: Signal<T>): void {
  signalRegistry.add(signal)
}

export function getAllSignals(): Set<Signal<unknown>> {
  return signalRegistry
}

// Global computed signal context for dependency tracking
let currentComputed: ComputedSignal<unknown> | null = null

export function getCurrentComputed(): ComputedSignal<unknown> | null {
  return currentComputed
}

export function setCurrentComputed(computed: ComputedSignal<unknown> | null): void {
  currentComputed = computed
}

// Observer interfaces
export interface ObserverR<T = unknown> {
  value?: T
  updateFn: UpdateFn<T>
  isDisposed?: boolean
}

// Notification and subscription utilities
export function notify<T>(observer: ObserverR<T>): void {
  if (!observer.isDisposed && observer.updateFn) {
    observer.updateFn(observer.value)
  }
}
