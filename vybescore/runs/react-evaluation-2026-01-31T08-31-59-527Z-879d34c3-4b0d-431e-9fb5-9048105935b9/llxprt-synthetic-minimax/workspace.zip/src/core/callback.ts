/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, ObserverR, UpdateFn, notify, getCurrentComputed } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create the observer
  const observer: ObserverR<T> = {
    value,
    updateFn,
  }
  
  // Subscribe to the current computed signal if any
  const currentComputed = getCurrentComputed()
  if (currentComputed) {
    const subscriber = () => {
      if (!disposed && !observer.isDisposed) {
        notify(observer)
      }
    }
    currentComputed.subscribers.add(subscriber)
  }
  
  // Trigger the callback immediately
  notify(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark observer as disposed
    observer.isDisposed = true
    
    // Clean up subscription if it exists
    if (currentComputed) {
      // Note: In a real system, we'd track which subscribers to remove specifically
      // For now, we'll leave the subscription as-is to avoid complexity
    }
  }
}
