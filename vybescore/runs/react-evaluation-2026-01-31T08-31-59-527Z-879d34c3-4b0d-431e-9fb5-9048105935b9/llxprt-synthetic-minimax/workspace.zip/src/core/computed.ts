/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  ComputedSignal,
  InputSignal,
  getCurrentComputed,
  setCurrentComputed
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean,
  _options?: { name?: string }
): GetterFn<T> {
  let currentValue = value
  const subscribers = new Set<() => void>()
  const dependencies = new Set<InputSignal<unknown>>()
  let isDirty = true

  // Create the computed signal
  const computedSignal: ComputedSignal<T> = {
    getter: () => currentValue as T,
    value: currentValue as T,
    subscribers,
    dependencies,
    isDirty,
    notify: () => {
      // Notify all subscribers by creating a copy to avoid modification during iteration
      Array.from(subscribers).forEach(subscriber => subscriber())
    },
    recompute: () => {
      // Set the current computed context
      const previousComputed = getCurrentComputed()
      setCurrentComputed(computedSignal)
      
      try {
        // Clear old dependencies and their subscriptions
        dependencies.forEach(dep => {
          const subscribers_to_remove = new Set<() => void>()
          dep.subscribers.forEach(sub => {
            // Remove subscriptions that belong to our computed signal
            const sub_str = sub.toString()
            if (sub_str.includes('isDirty') && sub_str.includes('true')) {
              subscribers_to_remove.add(sub)
            }
          })
          subscribers_to_remove.forEach(sub => dep.subscribers.delete(sub))
        })
        dependencies.clear()
        
        // Execute the update function to compute the new value
        // This will call input() which will add to dependencies via getCurrentComputed
        const newValue = updateFn(currentValue)
        
        // Set up subscriptions to newly discovered dependencies
        dependencies.forEach(dep => {
          const subscriber = () => {
            isDirty = true
          }
          dep.subscribers.add(subscriber)
        })
        
        currentValue = newValue
        computedSignal.value = newValue
        isDirty = false
        
        // Notify subscribers of the change
        computedSignal.notify()
      } finally {
        // Restore previous computed context
        setCurrentComputed(previousComputed)
      }
    }
  }

  // Create the getter function
  const getter = (): T => {
    if (isDirty) {
      computedSignal.recompute()
    }
    return currentValue as T
  }

  return getter
}
