/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  InputSignal,
  getCurrentComputed
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  const subscribers = new Set<() => void>()

  const signal: InputSignal<T> = {
    value: currentValue,
    subscribers,
    notify: () => {
      // Notify all subscribers by creating a copy to avoid modification during iteration
      Array.from(subscribers).forEach(subscriber => subscriber())
    },
    read: () => currentValue,
    write: (nextValue: T) => {
      if (currentValue !== nextValue) {
        currentValue = nextValue
        signal.value = nextValue
        // Notify all subscribers (computed signals that depend on this input)
        signal.notify()
      }
      return currentValue
    }
  }

  const read: GetterFn<T> = () => {
    // Track dependency for computed signals
    const currentComputed = getCurrentComputed()
    if (currentComputed) {
      currentComputed.dependencies.add(signal as InputSignal<unknown>)
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    if (currentValue !== nextValue) {
      currentValue = nextValue
      signal.value = nextValue
      // Notify all subscribers (computed signals that depend on this input)
      signal.notify()
    }
    return currentValue
  }

  return [read, write]
}
