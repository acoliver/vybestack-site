import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import fs from 'fs';

const initSqlJs = createRequire('sql.js');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// View engine setup
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Database setup
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../db/schema.sql');

// TypeScript type for sql.js Database
type SqlJsParams = (string | number | null | undefined)[];

interface SqlJsStatement {
  run(params: SqlJsParams): void;
  free(): void;
}

interface SqlJsDatabase {
  exec(sql: string): void;
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => SqlJsDatabase;
}

let sqlDb: SqlJsDatabase | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

async function initDatabase() {
  const sqlJsModule = await (initSqlJs as any)({
    locateFile: (file: string) => `https://sql.js.org/dist/${file}`
  });
  
  let dbBuffer: Uint8Array;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbBuffer = new Uint8Array(buffer);
  } else {
    dbBuffer = new Uint8Array();
  }

  if (dbBuffer.length > 0) {
    sqlDb = new sqlJsModule.Database(dbBuffer);
  } else {
    sqlDb = new sqlJsModule.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    if (sqlDb) {
      sqlDb.exec(schema);
    }
  }

  console.log('Database initialized');
}

async function saveDatabase() {
  if (!sqlDb) {
    return;
  }
  const data = sqlDb.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  if (!data.city.trim()) {
    errors.city = 'City is required';
  }
  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal code is required';
  }
  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else {
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Email must be valid';
    }
  }
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Phone number format is invalid';
    }
  }

  // Postal code validation - alphanumeric
  if (data.postalCode.trim()) {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.postalCode = 'Postal code must contain only letters, numbers, and spaces';
    }
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    data: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    res.status(400).render('form', { 
      errors, 
      data: formData,
      title: 'Contact Form'
    });
    return;
  }

  try {
    if (!sqlDb) {
      throw new Error('Database not initialized');
    }
    
    const stmt = sqlDb.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    await saveDatabase();
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred. Please try again.' },
      data: formData,
      title: 'Contact Form'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You' });
});

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  if (sqlDb) {
    sqlDb.close();
  }
  if (server) {
    server.close();
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
let server: import('http').Server | null = null;

async function start() {
  await initDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

// Export app for testing
export default app;
export { start, shutdown };

if (import.meta.url === `file://${process.argv[1]}`) {
  start().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}