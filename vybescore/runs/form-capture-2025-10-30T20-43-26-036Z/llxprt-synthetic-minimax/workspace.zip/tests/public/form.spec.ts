import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  beforeAll(async () => {
    // Clean up database before tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    await import('../../src/server.js');
    
    // Give the server a moment to start
    await new Promise(resolve => setTimeout(resolve, 500));
  });

  afterAll(async () => {
    const { shutdown } = await import('../../src/server.js');
    await shutdown();
  });

  it('renders the form with all fields', async () => {
    const { default: app } = await import('../../src/server.js');
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Contact Information Form');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const { default: app } = await import('../../src/server.js');
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify the thank you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank You!');
  });
});
