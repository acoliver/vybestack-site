import initSqlJs from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => SqlJsDatabase;
}

interface SqlJsDatabase {
  run(sql: string): void;
  exec(sql: string): void;
  prepare(sql: string): SqlJsStatement;
  close(): void;
  export(): Uint8Array;
}

interface SqlJsStatement {
  bind(params: (string | number | null)[] | Record<string, string | number | null>): boolean;
  step(): boolean;
  free(): void;
  run(params?: (string | number | null)[] | Record<string, string | number | null>): void;
}

export class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private sqlJs: SqlJsModule | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite', schemaPath: string = 'db/schema.sql') {
    this.dbPath = dbPath;
    this.schemaPath = schemaPath;
  }

  async initialize(): Promise<void> {
    // Initialize sql.js
    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => require.resolve(`sql.js/dist/${file}`)
    });

    // Check if database file exists
    if (fs.existsSync(this.dbPath)) {
      // Load existing database
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      // Create new database
      this.db = new this.sqlJs.Database();
      
      // Load and execute schema
      if (fs.existsSync(this.schemaPath) && this.db !== null) {
        const schema = fs.readFileSync(this.schemaPath, 'utf8');
        this.db.exec(schema);
      } else {
        throw new Error(`Schema file not found: ${this.schemaPath}`);
      }
    }
  }

  saveSubmission(submission: FormSubmission): void {
    if (this.db === null) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    this.saveToDisk();
  }

  private saveToDisk(): void {
    if (this.db === null) {
      throw new Error('Database not initialized');
    }

    // Create directory if it doesn't exist
    const dbDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    const dbBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbBuffer));
  }

  close(): void {
    if (this.db !== null) {
      this.db.close();
      this.db = null;
    }
  }

  isInitialized(): boolean {
    return this.db !== null;
  }
}