export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export class Validator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and a leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  static validatePostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings, handle international formats
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.length >= 3;
  }

  static validateSubmission(data: Record<string, string>): ValidationResult {
    const errors: ValidationError[] = [];

    // Required fields validation
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      if (!data[field] || typeof data[field] !== 'string' || data[field].trim() === '') {
        errors.push({
          field,
          message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
        });
      }
    });

    // Email validation
    if (data.email && !this.validateEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation
    if (data.phone && !this.validatePhone(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }

    // Postal code validation
    if (data.postalCode && !this.validatePostalCode(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}