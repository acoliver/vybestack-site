import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseManager } from './database';
import { Validator } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database manager
const dbManager = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Routes

// GET / - Serve contact form
app.get('/', (req: Request, res: Response) => {
  res.render('contact', {
    title: 'Contact Us',
    errors: [],
    formData: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData = {
    firstName: req.body.firstName?.trim(),
    lastName: req.body.lastName?.trim(),
    streetAddress: req.body.streetAddress?.trim(),
    city: req.body.city?.trim(),
    stateProvinceRegion: req.body.stateProvinceRegion?.trim(),
    postalCode: req.body.postalCode?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim()
  };

  // Validate submission
  const validation = Validator.validateSubmission(formData);

  if (!validation.isValid) {
    // Return form with errors
    return res.status(400).render('contact', {
      title: 'Contact Us - Please Fix Errors',
      errors: validation.errors,
      formData
    });
  }

  try {
    // Save to database
    dbManager.saveSubmission(formData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('contact', {
      title: 'Contact Us - Error',
      errors: [{ field: 'general', message: 'Sorry, there was an error saving your submission. Please try again.' }],
      formData
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal Server Error');
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('Received SIGTERM, shutting down gracefully...');
      dbManager.close();
      process.exit(0);
    });

    process.on('SIGINT', () => {
      console.log('Received SIGINT, shutting down gracefully...');
      dbManager.close();
      process.exit(0);
    });

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to access the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
