/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  notifyObservers,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  updateObserver(o)
  s.value = o.value as T
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) s.observers.add(observer)
    return s.value as T
  }
  
  // Wrap updateObserver to notify our observers when we're updated
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    s.value = result
    notifyObservers(s)
    return result
  }
  
  return getter
}
