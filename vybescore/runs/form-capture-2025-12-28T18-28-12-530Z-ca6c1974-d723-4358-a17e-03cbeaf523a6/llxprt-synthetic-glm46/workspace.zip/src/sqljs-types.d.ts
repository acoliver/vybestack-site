declare module 'sql.js' {
  interface SqlJsStatic {
    // Database constructor
    Database(data?: ArrayBuffer): {
      // Methods for running SQL statements
      run(sql: string, ...params: unknown[]): void;
      exec(sql: string, ...params: unknown[]): Array<{ columns: string[], values: unknown[] }>;
      // Prepare statement
      prepare(sql: string): {
        run(...params: unknown[]): void;
        get(...params: unknown[]): unknown;
        all(...params: unknown[]): unknown[];
        free(): void;
      };
      // Export database
      export(): ArrayBuffer;
      // Close database
      close(): void;
    };
  }

  function initSqlJs(config?: unknown): Promise<SqlJsStatic>;
  
  export = initSqlJs;
}