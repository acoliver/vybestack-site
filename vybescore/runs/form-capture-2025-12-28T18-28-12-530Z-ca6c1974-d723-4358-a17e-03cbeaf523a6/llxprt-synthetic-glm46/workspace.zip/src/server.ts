import express, { Express } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const port = process.env.PORT || 3535;

// SQL.js types
interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  export(): ArrayBuffer;
  prepare(sql: string): SqlJsStatement;
  close(): void;
}

interface SqlJsStatement {
  run(...params: unknown[]): void;
  free(): void;
}



// Database setup
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const schemaPath = path.join(__dirname, '../db/schema.sql');

/**
 * Initialize SQLite database with sql.js
 */
async function initializeDatabase(): Promise<SqlJsDatabase> {
  try {
    // Use simple pattern without explicit wasm location
    const SQL = await initSqlJs();
    
    // Use SQL.Database directly with type assertion
    const Database = SQL.Database as unknown as { new(data?: ArrayBuffer): SqlJsDatabase };

    let db: SqlJsDatabase;

    // Check if database file exists, if not create it
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      // Create a proper ArrayBuffer from the buffer
      const arrayBuffer = new ArrayBuffer(fileBuffer.length);
      const uint8Array = new Uint8Array(arrayBuffer);
      for (let i = 0; i < fileBuffer.length; i++) {
        uint8Array[i] = fileBuffer[i];
      }
      db = new Database(arrayBuffer);
    } else {
      db = new Database();
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }

    return db;
  } catch (error: unknown) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

/**
 * Save database to disk
 */
function saveDatabase(db: SqlJsDatabase): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error: unknown) {
    console.error('Failed to save database:', error);
  }
}

/**
 * Validate form data
 */
function validateForm(formData: Record<string, unknown>): string[] {
  const errors: string[] = [];

  // Helper function to safely get string value
  const getStringValue = (value: unknown): string => {
    if (typeof value === 'string') {
      return value;
    }
    return '';
  };

  // Required fields validation
  if (!formData.firstName || getStringValue(formData.firstName).trim() === '') {
    errors.push('First name is required');
  }
  if (!formData.lastName || getStringValue(formData.lastName).trim() === '') {
    errors.push('Last name is required');
  }
  if (!formData.streetAddress || getStringValue(formData.streetAddress).trim() === '') {
    errors.push('Street address is required');
  }
  if (!formData.city || getStringValue(formData.city).trim() === '') {
    errors.push('City is required');
  }
  if (!formData.stateProvince || getStringValue(formData.stateProvince).trim() === '') {
    errors.push('State/Province/Region is required');
  }
  if (!formData.postalCode || getStringValue(formData.postalCode).trim() === '') {
    errors.push('Postal/Zip code is required');
  }
  if (!formData.country || getStringValue(formData.country).trim() === '') {
    errors.push('Country is required');
  }
  if (!formData.email || getStringValue(formData.email).trim() === '') {
    errors.push('Email is required');
  }
  if (!formData.phone || getStringValue(formData.phone).trim() === '') {
    errors.push('Phone number is required');
  }

  // Email validation (basic regex)
  if (formData.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(getStringValue(formData.email))) {
      errors.push('Please enter a valid email address');
    }
  }

  // Phone validation (international format)
  if (formData.phone) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(getStringValue(formData.phone))) {
      errors.push('Please enter a valid phone number');
    }
  }

  // Postal code validation (alphanumeric)
  if (formData.postalCode) {
    const postalCodeRegex = /^[\d\sA-Za-z]+$/;
    if (!postalCodeRegex.test(getStringValue(formData.postalCode))) {
      errors.push('Please enter a valid postal/zip code');
    }
  }

  return errors;
}
const app: Express = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));



// Initialize database and start server
let db: SqlJsDatabase;
initializeDatabase()
  .then((database) => {
    db = database;
    
    // GET / - Render the contact form
    app.get('/', (req: express.Request, res: express.Response) => {
      res.render('form', {
        values: {},
        errors: []
      });
    });

    // GET /thank-you - Thank you page
    app.get('/thank-you', (req: express.Request, res: express.Response) => {
      res.render('thank-you', {
        firstName: req.query.firstName || 'friend'
      });
    });

    // POST /submit - Handle form submission
    app.post('/submit', (req: express.Request, res: express.Response) => {
      const formData = req.body;
      const errors = validateForm(formData);

      if (errors.length > 0) {
        // Validation failed, re-render form with errors
        return res.render('form', {
          values: formData,
          errors: errors
        });
      }

      try {
        // Insert into database
        const stmt = db.prepare(
          'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
stmt.run(
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        );
        
        stmt.free();
        
        // Save database to disk
        saveDatabase(db);

        // Redirect to thank you page
        res.redirect('/thank-you?firstName=' + encodeURIComponent(formData.firstName as string));
      } catch (error: unknown) {
        console.error('Database error:', error);
        errors.push('An error occurred while saving your data. Please try again.');
        return res.render('form', {
          values: formData,
          errors: errors
        });
      }
    });

    const server = app.listen(port, () => {
      console.log('Server running at http://localhost:' + port);
    });

    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      saveDatabase(db);
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });

    return server;
  })
  .catch((error: unknown) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
