export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper format restrictions.
 * Accepts typical addresses like name@domain.example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || !value.includes('@')) {
    return false;
  }
  
  // Email validation regex with comprehensive format checking
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain starting or ending with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats and optional +1 prefix.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (starting with 0 or 1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if we have 10 digits (standard) or 11 digits (with country code)
  if (digits.length !== 10 && !(digits.length === 11 && digits.startsWith('1'))) {
    return false;
  }
  
  // Extract area code (last 10 digits or last 10 of 11)
  const areaCode = digits.length === 11 ? digits.substring(1, 4) : digits.substring(0, 4);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Full validation regex for US phone numbers
  const phoneRegex = /^(\+?1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with all components
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(\d{2,4})(\d{6,8})$/;
  const match = cleanValue.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Full validation with mobile indicator (9) check
  const fullRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(?:9)?(\d{6,8})$/;
  return fullRegex.test(cleanValue);
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Additional check to reject invalid patterns
  // Disallow names with just symbols or invalid combinations
  const invalidPatterns = [
    /^\d+/, // Cannot start with digits
    /^[^\p{L}]+$/u, // Cannot contain only non-letter characters
    /[\p{S}]/u, // Reject symbols
    /[\p{N}]/u, // Reject numbers
  ];
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  // Ensure at least one letter character
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx using Luhn checksum.
 * Also checks valid prefixes and lengths for each card type.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check if it's a valid length for common credit cards
  if (!/^\d{13,19}$/.test(cleanValue)) {
    return false;
  }
  
  // Check card type and length
  let validCard = false;
  
  // Visa: starts with 4, length 13 or 16
  if (/^4\d{12}(?:\d{3})?$/.test(cleanValue)) {
    validCard = cleanValue.length === 13 || cleanValue.length === 16;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (/^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/.test(cleanValue)) {
    validCard = cleanValue.length === 16;
  }
  // Amex: starts with 34 or 37, length 15
  else if (/^3[47]\d{13}$/.test(cleanValue)) {
    validCard = cleanValue.length === 15;
  }
  
  if (!validCard) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Run Luhn checksum algorithm on a digit string.
 */
function runLuhnCheck(value: string): boolean {
  if (!/^\d+$/.test(value)) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value[i], 10);
    
    if (shouldDouble) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled = doubled - 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
