/**
 * Capitalize the first character of each sentence after punctuation marks.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible by requiring a period to be followed by a space and lowercase letter.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }
  
  // First, normalize spaces: replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence-ending punctuation
  normalized = normalized.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Then capitalize the first letter of each sentence
  return normalized.replace(/(?:^|[.!?]\s+)([a-z])/g, (match, firstLetter) => {
    return match.slice(0, -1) + firstLetter.toUpperCase();
  });
}

/**
 * Extract URLs from text, returning them without trailing punctuation.
 * Uses comprehensive regex to match HTTP/HTTPS, FTP, and protocol-agnostic URLs.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string') {
    return [];
  }
  
  // URL regex pattern that captures URLs including those with trailing punctuation
  const urlRegex = /(https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+|www\.[^\s<>"']+/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,!?"' etc.
    return url.replace(/[.,!?;:'")\]}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }
  
  // Look for http:// URLs and replace with https://
  // Use word boundary to avoid affecting parts of words
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite example.com URLs with specific rules:
 * 1. Always upgrade scheme to https://
 * 2. For paths starting with /docs/, rewrite host to docs.example.com
 * 3. Skip host rewrite for paths containing dynamic hints like cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }
  
  return text.replace(/\bhttps?:\/\/(example\.com)(\/[^\s]*)/gi, (match, host, path) => {
    // First upgrade to https regardless
    const newScheme = 'https://';
    
    // Check for special cases where we should NOT rewrite the host
    const skipHostRewrite = path.search(/\/cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i) >= 0;
    
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Rewrite the host to docs.example.com
      return `${newScheme}docs.example.com${path}`;
    } else {
      // Only upgrade the scheme
      return `${newScheme}${host}${path}`;
    }
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' if the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  // (We don't need full date validation since the problem asks for mm/dd/yyyy format)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Using 29 for February to be safe
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
