/**
 * Find words starting with the prefix but excluding the exceptional cases.
 * Uses regex with word boundaries and negative lookahead for exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex for words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => exception.toLowerCase() === lowerWord);
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses regex patterns to match the required context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // We need to find the digit+token pattern and return the full match (digit+token)
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  // Find all matches that satisfy the condition
  const matches = [...text.matchAll(pattern)];
  
  // Convert MatchIterator to array of strings
  return matches.map(match => match[0]);
}

/**
 * Validate password strength policy.
 * Requirements: At least 10 characters, one uppercase, one lowercase, one digit, 
 * one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character classes
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[{};':"|,<>.?]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like AAA, not AAA in valid passwords)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand notation) and ensure IPv4 addresses don't trigger positives.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }
  
  // First, exclude IPv4 addresses
  const ipv4Pattern = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?:\/[0-9]+)?(?!\]$)/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 regex patterns (comprehensive)
  // Standard IPv6 with 8 groups of 4 hex digits
  const ipv6Pattern1 = /(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}/i;
  
  // Compressed IPv6 with :: (single or multiple zero groups)
  const ipv6Pattern2 = /(?:[0-9a-f]{1,4}:){0,7}:(?:[0-9a-f]{1,4}:){0,7}[0-9a-f]{1,4}/i;
  
  // IPv6 with :: at the end or beginning
  const ipv6Pattern3 = /::(?:[0-9a-f]{1,4}:){0,7}[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){0,7}[0-9a-f]{1,4}::/i;
  
  // Just :: (all zeros)
  const ipv6Pattern4 = /::/;
  
  // IPv6 with port and optional bracket notation
  const ipv6Pattern5 = /\[[0-9a-f:]+\](:[0-9]+)?/i;
  
  // IPv6 with embedded IPv4
  const ipv6Pattern6 = /(?:[0-9a-f]{1,4}:){1,6}:(?:[0-9]{1,3}\.){3}[0-9]{1,3}/i;
  
  // Check if any IPv6 pattern matches
  return ipv6Pattern1.test(value) || 
         ipv6Pattern2.test(value) || 
         ipv6Pattern3.test(value) || 
         ipv6Pattern4.test(value) ||
         ipv6Pattern5.test(value) ||
         ipv6Pattern6.test(value);
}
