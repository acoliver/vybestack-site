/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  registerObserver
} from '../types/reactive.js'

interface ComputedObserver<T> extends Observer<T> {
  subjects: Set<Subject<unknown>>
  isDirty: boolean
}

interface ComputedSubject<T> extends Subject<T> {
  computed: boolean
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set(),
    isDirty: true,
  }

  const subject: ComputedSubject<T> = {
    name: options?.name,
    observer: undefined,
    value: undefined as T,
    equalFn: undefined,
    observers: new Set(),
    computed: true,
  }

  const compute = () => {
    // Clear previous dependencies
    observer.subjects.clear()
    
    // Set this observer as active and compute
    updateObserver(observer)
    
    // Update the subject value - observer.value is now guaranteed to be set
    if (observer.value !== undefined) {
      subject.value = observer.value
    }
    
    observer.isDirty = false
  }

  const read: GetterFn<T> = () => {
    // Register this computed as a dependency of any active observer
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      if ('subjects' in activeObserver && activeObserver.subjects instanceof Set) {
        const computedObserver = activeObserver as ComputedObserver<unknown>
        computedObserver.subjects.add(subject)
      }
      registerObserver(subject, activeObserver)
    }

    // Recompute if dirty
    if (observer.isDirty) {
      compute()
    }
    
    return subject.value as T
  }

  // Initial computation
  compute()

  return read
}
