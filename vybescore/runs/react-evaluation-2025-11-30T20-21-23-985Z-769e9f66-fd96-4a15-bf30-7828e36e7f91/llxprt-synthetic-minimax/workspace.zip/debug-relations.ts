import { createInput, createComputed } from './src/index.js'

// Test to see observer relationships
console.log('=== Observer Relationship Debug ===')

const [input, setInput] = createInput(1)
console.log('1. Created input')

const timesTwo = createComputed(() => {
  const val = input()
  return val * 2
})

console.log('2. Created timesTwo')

const sum = createComputed(() => {
  const two = timesTwo()
  return two + 30
})

console.log('3. Created sum')

// Check the relationships
console.log('4. Checking relationships...')
console.log('   Input observers:', input.observers.size)
console.log('   TimesTwo observers:', (timesTwo as any).observers?.size || 'not a subject')

const initial = sum()
console.log('5. Initial sum:', initial)

console.log('6. About to set input to 3...')
setInput(3)

console.log('7. About to access sum...')
const final = sum()
console.log('8. Final sum:', final)