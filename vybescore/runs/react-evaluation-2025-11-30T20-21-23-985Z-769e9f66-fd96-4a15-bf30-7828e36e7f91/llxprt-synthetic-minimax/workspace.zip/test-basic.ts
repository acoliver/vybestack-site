import { createInput } from './src/index.js'

// Simple test to verify basic input reactivity
console.log('=== Testing Basic Input Reactivity ===')

const [get, set] = createInput(1)
console.log('Initial value:', get())

console.log('Setting to 5...')
set(5)
console.log('After setting, value:', get())

console.log('Setting to 10...')  
set(10)
console.log('After setting, value:', get())