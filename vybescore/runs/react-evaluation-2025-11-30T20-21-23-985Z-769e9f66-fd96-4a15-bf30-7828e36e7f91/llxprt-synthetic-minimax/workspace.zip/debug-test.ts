import { createInput, createComputed, createCallback } from './src/index.js'

// Debug the reactive system
console.log('=== Testing Reactive System ===')

const [input, setInput] = createInput(1)
console.log('Created input with value 1')

const timesTwo = createComputed(() => {
  const result = input() * 2
  console.log(`timesTwo computed: ${result}`)
  return result
})
console.log('Created timesTwo computed')

const timesThirty = createComputed(() => {
  const result = input() * 30
  console.log(`timesThirty computed: ${result}`)
  return result
})
console.log('Created timesThirty computed')

const sum = createComputed(() => {
  const two = timesTwo()
  const thirty = timesThirty()
  const result = two + thirty
  console.log(`sum computed: ${two} + ${thirty} = ${result}`)
  return result
})
console.log('Created sum computed')

console.log('Initial sum value:', sum())
console.log('=== Setting input to 3 ===')
setInput(3)
console.log('After setting input, sum value:', sum())