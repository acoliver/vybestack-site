import { createInput, createComputed, getActiveObserver, updateObserver, registerObserver, notifyObservers } from './src/index.js'

// Test with detailed tracking
console.log('=== Detailed Dependency Tracking Test ===')

const [input, setInput] = createInput(1)
console.log('Input created')

const timesTwo = createComputed(() => {
  console.log('timesTwo: Starting computation')
  const activeObs = getActiveObserver()
  console.log('timesTwo: Active observer:', activeObs?.name || 'unnamed')
  
  const val = input()
  console.log(`timesTwo: Got input value ${val}, computing ${val} * 2`)
  const result = val * 2
  console.log(`timesTwo: Computed result: ${result}`)
  return result
}, undefined, undefined, { name: 'timesTwo' })

console.log('timesTwo created')

const sum = createComputed(() => {
  console.log('sum: Starting computation')
  const activeObs = getActiveObserver()
  console.log('sum: Active observer:', activeObs?.name || 'unnamed')
  
  const two = timesTwo()
  console.log(`sum: Got timesTwo value ${two}, computing ${two} + 5`)
  const result = two + 5
  console.log(`sum: Computed result: ${result}`)
  return result
}, undefined, undefined, { name: 'sum' })

console.log('sum created')
console.log('Initial sum:', sum())

console.log('=== Setting input to 3 ===')
setInput(3)
console.log('Input set to 3')

console.log('=== Getting sum again ===')
const finalSum = sum()
console.log('Final sum:', finalSum)