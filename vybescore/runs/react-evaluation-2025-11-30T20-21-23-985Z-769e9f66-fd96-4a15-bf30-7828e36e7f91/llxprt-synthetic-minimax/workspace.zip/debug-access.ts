import { createInput, createComputed } from './src/index.js'

// Test observer access
console.log('=== Observer Access Debug ===')

const [input, setInput] = createInput(1)
console.log('1. Created input')

// Try to access through different methods
console.log('2. Trying to access input structure...')
console.log('   input[0] (getter):', typeof input[0])
console.log('   input[1] (setter):', typeof input[1])

const timesTwo = createComputed(() => {
  const val = input[0]()  // Use indexed access
  return val * 2
})

console.log('3. Created timesTwo using indexed access')

const sum = createComputed(() => {
  const two = timesTwo()
  return two + 30
})

console.log('4. Created sum')

const initial = sum()
console.log('5. Initial sum:', initial)

setInput(3)
const final = sum()
console.log('6. Final sum after setInput(3):', final)