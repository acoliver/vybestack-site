import { createInput, createComputed, createCallback } from './src/index.js'

// More detailed debug to understand dependency tracking
console.log('=== Testing Dependency Tracking ===')

const [input, setInput] = createInput(1)
console.log('Created input with value 1')

const timesTwo = createComputed(() => {
  const inputValue = input()
  const result = inputValue * 2
  console.log(`timesTwo: ${inputValue} * 2 = ${result}`)
  return result
})
console.log('Created timesTwo computed')

const timesThirty = createComputed(() => {
  const inputValue = input()
  const result = inputValue * 30
  console.log(`timesThirty: ${inputValue} * 30 = ${result}`)
  return result
})
console.log('Created timesThirty computed')

console.log('=== Creating sum ===')
const sum = createComputed(() => {
  const two = timesTwo()
  const thirty = timesThirty()
  const result = two + thirty
  console.log(`sum: ${two} + ${thirty} = ${result}`)
  return result
})

console.log('Initial sum value:', sum())
console.log('=== Setting input to 3 ===')
setInput(3)
console.log('Input set to 3, now getting sum...')
const finalSum = sum()
console.log('Final sum value:', finalSum)