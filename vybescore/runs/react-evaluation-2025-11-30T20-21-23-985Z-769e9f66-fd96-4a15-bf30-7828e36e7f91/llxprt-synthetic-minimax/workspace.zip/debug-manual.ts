import { createInput, createComputed } from './src/index.js'

// Test with manual tracking of observer registration
console.log('=== Manual Observer Registration Test ===')

const [input, setInput] = createInput(1)
console.log('Input created')

console.log('Input observers before creating timesTwo:', input.observers)

const timesTwo = createComputed(() => {
  console.log('timesTwo: About to read input')
  const val = input()
  console.log(`timesTwo: Got input value ${val}`)
  return val * 2
}, undefined, undefined, { name: 'timesTwo' })

console.log('timesTwo created')
console.log('Input observers after creating timesTwo:', input.observers)

console.log('=== Creating sum ===')
const sum = createComputed(() => {
  console.log('sum: About to read timesTwo')
  const two = timesTwo()
  console.log(`sum: Got timesTwo value ${two}`)
  return two + 5
}, undefined, undefined, { name: 'sum' })

console.log('sum created')
console.log('timesTwo observers:', (timesTwo as any).observers || 'not a subject')

console.log('Initial sum:', sum())
console.log('=== Setting input to 3 ===')
setInput(3)
console.log('Input set to 3')
console.log('Final sum:', sum())