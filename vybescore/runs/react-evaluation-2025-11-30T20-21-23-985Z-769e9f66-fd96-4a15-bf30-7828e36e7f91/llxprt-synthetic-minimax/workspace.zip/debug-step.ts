import { createInput, createComputed } from './src/index.js'

// Test to see what happens step by step
console.log('=== Step by Step Debug ===')

const [input, setInput] = createInput(1)
console.log('1. Created input with value 1')

const timesTwo = createComputed(() => {
  console.log('2. timesTwo computing...')
  const val = input()
  const result = val * 2
  console.log(`   timesTwo: ${val} * 2 = ${result}`)
  return result
})

console.log('3. timesTwo created')

const sum = createComputed(() => {
  console.log('4. sum computing...')
  const two = timesTwo()
  const result = two + 30
  console.log(`   sum: ${two} + 30 = ${result}`)
  return result
})

console.log('5. sum created')
const initialSum = sum()
console.log('6. Initial sum:', initialSum)

console.log('7. Setting input to 3...')
setInput(3)

console.log('8. Getting sum again...')
const finalSum = sum()
console.log('9. Final sum:', finalSum)