import { createInput, createComputed, getActiveObserver } from './src/index.js'

// Test to trace active observer during computation
console.log('=== Testing Active Observer Tracking ===')

const [input, setInput] = createInput(1)
console.log('Input created')

const timesTwo = createComputed(() => {
  console.log('timesTwo: Active observer =', getActiveObserver())
  const value = input()
  console.log(`timesTwo: input value = ${value}`)
  return value * 2
})

console.log('timesTwo created, now accessing...')
const result = timesTwo()
console.log('timesTwo result:', result)

console.log('=== Setting input to 5 ===')
setInput(5)
console.log('Input set, now accessing timesTwo again...')
const result2 = timesTwo()
console.log('timesTwo new result:', result2)