import { createInput, createComputed } from './src/index.js'

// Test to see what's happening with dependency registration
console.log('=== Testing Dependency Registration ===')

const [input, setInput] = createInput(1)
console.log('Input created, checking observers...')

const timesTwo = createComputed(() => {
  const value = input()
  console.log(`timesTwo reading input: ${value}`)
  return value * 2
})
console.log('timesTwo created')

console.log('=== Accessing input directly ===')
const directValue = input()
console.log('Direct input value:', directValue)

console.log('=== Accessing timesTwo ===')  
const timesTwoValue = timesTwo()
console.log('timesTwo value:', timesTwoValue)