import { createInput } from './src/index.js'

// Test subject structure directly
console.log('=== Testing Subject Structure ===')

const [get, set] = createInput(1)
console.log('Input created')

// Try to access the subject through different means
console.log('Testing different ways to access observers:')

// Direct property access
try {
  const observers = (get as any).observers
  console.log('Direct observers access:', observers)
} catch (e) {
  console.log('Direct access failed:', e)
}

// Check if get function has any properties
const getProps = Object.getOwnPropertyNames(get)
console.log('Getter properties:', getProps)

const setProps = Object.getOwnPropertyNames(set)
console.log('Setter properties:', setProps)

console.log('Setting value...')
set(5)
console.log('Value set, getting...')
console.log('Current value:', get())