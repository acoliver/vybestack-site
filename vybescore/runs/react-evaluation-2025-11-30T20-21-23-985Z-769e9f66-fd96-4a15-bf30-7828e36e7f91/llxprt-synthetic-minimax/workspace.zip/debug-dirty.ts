import { createInput, createComputed } from './src/index.js'

// Test to see if dirty marking is working correctly
console.log('=== Testing Dirty Marking ===')

const [input, setInput] = createInput(1)
console.log('Input created with value 1')

const timesTwo = createComputed(() => {
  const val = input()
  console.log(`timesTwo computing: ${val} * 2 = ${val * 2}`)
  return val * 2
}, undefined, undefined, { name: 'timesTwo' })

console.log('timesTwo created')

const sum = createComputed(() => {
  const two = timesTwo()
  console.log(`sum computing: ${two} + 5 = ${two + 5}`)
  return two + 5
}, undefined, undefined, { name: 'sum' })

console.log('Initial sum:', sum())
console.log('=== Setting input to 3 ===')
setInput(3)
console.log('Input set to 3')
console.log('=== Getting sum ===')
const finalSum = sum()
console.log('Final sum:', finalSum)