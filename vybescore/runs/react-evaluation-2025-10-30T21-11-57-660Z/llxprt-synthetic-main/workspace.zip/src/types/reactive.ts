/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global tracking system for dependencies
const dependencyMap = new Map<ObserverR, Set<Subject<any>>>()
const dependentMap = new Map<Subject<any>, Set<ObserverR>>()

export function addDependency(observer: ObserverR, subject: Subject<any>): void {
  if (!dependencyMap.has(observer)) {
    dependencyMap.set(observer, new Set())
  }
  dependencyMap.get(observer)!.add(subject)
  
  if (!dependentMap.has(subject)) {
    dependentMap.set(subject, new Set())
  }
  dependentMap.get(subject)!.add(observer)
}

export function clearDependencies(observer: ObserverR): void {
  const subjectSet = dependencyMap.get(observer)
  if (subjectSet) {
    for (const subject of subjectSet) {
      const dependentSet = dependentMap.get(subject)
      if (dependentSet) {
        dependentSet.delete(observer)
        if (dependentSet.size === 0) {
          dependentMap.delete(subject)
        }
      }
    }
    dependencyMap.delete(observer)
  }
}

export function notifyDependents(subject: Subject<any>): void {
  const dependentSet = dependentMap.get(subject)
  if (dependentSet && dependentSet.size > 0) {
    // Create a copy to avoid issues with modification during iteration
    const dependents = Array.from(dependentSet)
    
    for (const dependent of dependents) {
      // Only notify if the dependent has an updateFn
      if ( dependent && 'updateFn' in dependent && typeof dependent.updateFn === 'function') {
        updateObserver(dependent as any)
      }
    }
  }
}

export function registerSubject<T>(_subject: Subject<T>): void {
  // Register subject for dependency tracking
}

export function getSubjects(): Set<Subject<any>> {
  return new Set()
}

// Special tracking for computed values to ensure proper notification
const computedRegistration = new Map<any, Subject<any>>()

export function registerComputedObserver(observer: any, subject: Subject<any>): void {
  computedRegistration.set(observer, subject)
}

export function getComputedSubject(observer: any): Subject<any> | undefined {
  return computedRegistration.get(observer)
}