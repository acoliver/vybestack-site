/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, clearDependencies } from '../types/reactive.js'

// Registry of callback observers for debugging/cleanup
const callbackRegistry = new Set<Observer<any>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Add to registry
  callbackRegistry.add(observer)
  
  // Register observer to track dependencies and execute the side effect
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Remove from registry
    callbackRegistry.delete(observer)
    
    // Clear all dependencies to prevent memory leaks
    clearDependencies(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }

  return unsubscribe
}