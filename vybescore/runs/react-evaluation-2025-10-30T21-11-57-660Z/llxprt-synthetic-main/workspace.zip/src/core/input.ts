/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  SetterFn, 
  InputPair, 
  Subject, 
  getActiveObserver, 
  EqualFn,
  registerSubject,
  addDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates an input closure with the supplied initial value.
 * Returns [getter, setter] pair.
 */
export function createInput<T>(
  value: T,
  _equal?: false | EqualFn<T>,
  options?: { name?: string }
): InputPair<T> {
  const equalFn = _equal === false ? undefined : (_equal || ((a, b) => a === b))
  
  const subject: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
    observer: undefined
  }

  registerSubject(subject)

  const getter: GetterFn<T> = () => {
    // Track dependency if there's an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addDependency(activeObserver, subject)
      subject.observer = activeObserver
    }
    return subject.value
  }

  const setter: SetterFn<T> = (newValue: T): T => {
    // Check if value has changed using equality function
    if (equalFn && equalFn(subject.value, newValue)) {
      return subject.value
    }

    subject.value = newValue

    // Notify all dependents of this subject
    notifyDependents(subject)

    return subject.value
  }

  return [getter, setter]
}