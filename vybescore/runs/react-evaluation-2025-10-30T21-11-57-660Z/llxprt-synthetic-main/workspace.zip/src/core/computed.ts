/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  addDependency,
  clearDependencies,
  registerSubject,
  notifyDependents,
  registerComputedObserver
} from '../types/reactive.js'

// Registry of computed observers for tracking and cleanup
const computedRegistry = new Set<Observer<any>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine equality function
  const equalFn: EqualFn<T> | undefined = _equal === false 
    ? undefined 
    : (_equal instanceof Function ? _equal : (a, b) => a === b)

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Register the computed value as both an observer and a subject
  computedRegistry.add(observer)
  
  // Create a subject interface for this computed value so other observers can depend on it
  const computedSubject: Subject<T> = {
    name: options?.name,
    value: value as T,
    equalFn,
    observer: undefined
  }

  // Register as a subject in the system
  registerSubject(computedSubject)
  
  // Track the relationship between observer and subject for notifications
  registerComputedObserver(observer, computedSubject)

  // Function to recompute the value and update dependencies
  const recompute = () => {
    // Clear old dependencies before re-computing
    clearDependencies(observer)
    
    // Recompute the value using the update function
    updateObserver(observer)
    
    // Update the subject's value
    computedSubject.value = observer.value!
  }

  const getter: GetterFn<T> = () => {
    // If called from within another observer, establish dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // The active observer depends on this computed value
      addDependency(activeObserver, computedSubject)
      computedSubject.observer = activeObserver
    }
    
    return observer.value!
  }

  // Initial computation
  recompute()
  
  // Hook into the observer's update mechanism to also notify dependents
  const originalUpdateFn = observer.updateFn
  
  // Create a wrapper function for the observer's updateFn
  observer.updateFn = (currentValue?: T) => {
    // Execute the original updateFn to get the new value
    const newValue = originalUpdateFn(currentValue)
    
    // Update the internal observer value
    observer.value = newValue
    
    // Update the subject's value
    computedSubject.value = newValue!
    
    // Notify dependents of this computed value that it has changed
    notifyDependents(computedSubject)
    
    return newValue
  }
  
  return getter
}