// Simple debug script for callback behavior
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing callback behavior:');

const [input3, setInput3] = createInput(1);
const output = createComputed(() => input3() + 1);
let value = 0;
const unsubscribe = createCallback(() => {
  console.log('Callback triggered with output() =', output());
  value = output();
});

console.log('----- Callback test -----');
console.log('Initial input3:', input3());
console.log('Initial output:', output());
console.log('Initial value set by callback:', value);

setInput3(2);
console.log('After setting input3 to 2:');
console.log('input3:', input3());
console.log('output:', output());
console.log('value:', value);

setInput3(3);
console.log('After setting input3 to 3:');
console.log('input3:', input3());
console.log('output:', output());
console.log('value:', value);