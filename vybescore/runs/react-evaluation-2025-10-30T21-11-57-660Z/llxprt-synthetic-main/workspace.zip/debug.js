// Simple debug script to test reactive behavior
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing reactive system:');

// Test 1: Basic input/setter
const [input, setInput] = createInput(1);
console.log('Initial input value:', input());

// Test 2: Basic computed
const computed = createComputed(() => input() * 2);
console.log('Initial computed value:', computed());

setInput(3);
console.log('Updated input value:', input());
console.log('Updated computed value:', computed());

// Test 3: Computed dependencies
const [input2, setInput2] = createInput(1);
const timesTwo = createComputed(() => input2() * 2);
const timesThirty = createComputed(() => input2() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());

console.log('--- Dependency test ---');
console.log('input2:', input2());
console.log('timesTwo:', timesTwo());
console.log('timesThirty:', timesThirty());
console.log('sum:', sum());

setInput2(3);
console.log('After setting input2 to 3:');
console.log('input2:', input2());
console.log('timesTwo:', timesTwo());
console.log('timesThirty:', timesThirty());
console.log('sum:', sum());

// Test 4: Callback
const [input3, setInput3] = createInput(1);
const output = createComputed(() => input3() + 1);
let value = 0;
createCallback(() => (value = output()));

console.log('--- Callback test ---');
console.log('Initial value set by callback:', value);
setInput3(3);
console.log('After setting input3 to 3, value:', value);