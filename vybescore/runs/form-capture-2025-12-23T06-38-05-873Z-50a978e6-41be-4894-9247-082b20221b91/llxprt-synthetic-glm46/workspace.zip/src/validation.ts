// Define types inline to avoid module import issues
export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};

  // Required field validation
  if (!data.firstName?.trim()) {
    errors.firstName = "First name is required";
  }
  if (!data.lastName?.trim()) {
    errors.lastName = "Last name is required";
  }
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = "Street address is required";
  }
  if (!data.city?.trim()) {
    errors.city = "City is required";
  }
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = "State / Province / Region is required";
  }
  if (!data.postalCode?.trim()) {
    errors.postalCode = "Postal / Zip code is required";
  }
  if (!data.country?.trim()) {
    errors.country = "Country is required";
  }
  if (!data.email?.trim()) {
    errors.email = "Email is required";
  }
  if (!data.phone?.trim()) {
    errors.phone = "Phone number is required";
  }

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.email = "Please enter a valid email address";
  }

  // Phone validation
  if (data.phone && !isValidPhone(data.phone)) {
    errors.phone = "Please enter a valid phone number";
  }

  // Postal code validation
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = "Please enter a valid postal/zip code";
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function isValidPostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

export function hasErrors(errors: FormErrors): boolean {
  return Object.keys(errors).length > 0;
}