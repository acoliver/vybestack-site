declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): QueryResult[];
    prepare(sql: string): Statement;
    export(): ArrayBuffer;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    step(): boolean;
    free(): void;
  }

  export interface QueryResult {
    columns: string[];
    values: unknown[][];
  }

  export interface Static {
    new(data?: ArrayBuffer): Database;
  }

  export default function DatabaseFactory(): Static;
}