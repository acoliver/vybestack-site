import express, { Request, Response } from "express";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

import { FormData, validateForm, hasErrors } from "./validation.js";
import { initializeDatabase, saveDatabase, insertSubmission, Database } from "./database.js";

const __dirname = fileURLToPath(new URL(".", import.meta.url));

const app = express();
const port = process.env.PORT || 3535;

// Set up EJS as the view engine
app.set("view engine", "ejs");
app.set("views", join(__dirname, "templates"));

// Serve static files
app.use("/public", express.static(join(__dirname, "..", "public")));

// Parse request body
app.use(express.urlencoded({ extended: true }));

let db: Database | null = null;

// Initialize database
async function initDatabase() {
  try {
    db = await initializeDatabase();
    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Failed to initialize database:", error);
    process.exit(1);
  }
}

// GET / - Render the contact form
app.get("/", (req: Request, res: Response) => {
  res.render("form", {
    errors: [],
    values: {} as Partial<FormData>
  });
});

// POST /submit - Handle form submission
app.post("/submit", async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || "",
      lastName: req.body.lastName || "",
      streetAddress: req.body.streetAddress || "",
      city: req.body.city || "",
      stateProvince: req.body.stateProvince || "",
      postalCode: req.body.postalCode || "",
      country: req.body.country || "",
      email: req.body.email || "",
      phone: req.body.phone || ""
    };

    const errors = validateForm(formData);

    if (hasErrors(errors)) {
      return res.status(400).render("form", {
        errors: Object.values(errors),
        values: formData
      });
    }

    // Insert into database
    await insertSubmission(db!, formData);
    await saveDatabase(db!);

    // Redirect with first name query parameter
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error("Error submitting form:", error);
    res.status(500).render("form", {
      errors: ["An unexpected error occurred. Please try again."],
      values: req.body as Partial<FormData>
    });
  }
});

// GET /thank-you - Thank you page
app.get("/thank-you", (req: Request, res: Response) => {
  const firstName = req.query.firstName || "friend";
  res.render("thank-you", { firstName });
});

// Graceful shutdown
async function shutdown() {
  console.log("Shutting down gracefully...");
  if (db) {
    try {
      await saveDatabase(db);
      console.log("Database saved");
      db.close();
    } catch (error) {
      console.error("Error saving database during shutdown:", error);
    }
  }
  process.exit(0);
}

// Handle SIGTERM
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

// Start server
export async function startServer(portOverride?: number) {
  await initDatabase();
  
  const serverPort = portOverride || port;
  const numericPort = typeof serverPort === 'string' ? parseInt(serverPort, 10) : serverPort;
  const server = app.listen(numericPort, '127.0.0.1', () => {
    console.log(`Server running at http://127.0.0.1:${numericPort}`);
  });

  // Export the server for testing purposes
  if (process.env.NODE_ENV !== "production") {
    (global as Record<string, unknown>).__SERVER__ = server;
  }

  return server;
}

// Only start server if this file is run directly (not when imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error("Failed to start server:", error);
    process.exit(1);
  });
}
