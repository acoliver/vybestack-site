import fs from "node:fs";
import path from "node:path";

export interface Database {
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string): { columns: string[]; values: unknown[][] }[];
  prepare(sql: string): Statement;
  export(): ArrayBuffer;
  close(): void;
}

export interface Statement {
  run(...params: unknown[]): void;
  step(): boolean;
  free(): void;
}

// Declare sql.js module type to fix declaration issues
declare module "sql.js" {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): { columns: string[]; values: unknown[][] }[];
    prepare(sql: string): Statement;
    export(): ArrayBuffer;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    step(): boolean;
    free(): void;
  }

  export default function(): Promise<{ Database: new(data?: ArrayBuffer) => Database }>;
}

let SQL: { Database: new(data?: ArrayBuffer) => Database } | null = null;

// Use dynamic import for sql.js to support ES modules
async function getSqlJs(): Promise<{ Database: new(data?: ArrayBuffer) => Database }> {
  if (!SQL) {
    const sqljs = await import("sql.js");
    SQL = await sqljs.default();
  }
  return SQL;
}

export async function initializeDatabase(dbPath: string = "data/submissions.sqlite"): Promise<Database> {
  const SQL = await getSqlJs();
  
  // Ensure data directory exists
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  let dbBuffer: ArrayBuffer | null = null;
  
  // If database file exists, load it
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    dbBuffer = fileBuffer.buffer.slice(fileBuffer.byteOffset, fileBuffer.byteOffset + fileBuffer.byteLength) as ArrayBuffer;
  }

  const db = new SQL.Database(dbBuffer || undefined);

  // Initialize schema if needed
  if (!fs.existsSync(dbPath)) {
    const schema = fs.readFileSync(path.resolve(process.cwd(), "db/schema.sql"), "utf8");
    db.run(schema);
  }

  return db;
}

export async function saveDatabase(db: Database, dbPath: string = "data/submissions.sqlite"): Promise<void> {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

export async function insertSubmission(
  db: Database,
  submission: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
  }
): Promise<number> {
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run(
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone
  );
  
  stmt.free();
  
  // Get the last insert rowid
  const result = db.exec("SELECT last_insert_rowid() as id")[0];
  return result.values[0][0] as number;
}