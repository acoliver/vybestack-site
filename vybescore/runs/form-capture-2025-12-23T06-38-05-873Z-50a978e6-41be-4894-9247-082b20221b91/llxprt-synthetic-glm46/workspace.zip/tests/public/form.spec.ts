import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  // Start server with a random available port
  const { startServer } = await import('../../dist/server.js');
  server = await startServer(0); // Use port 0 to get a random available port
});

afterAll(async () => {
  if (server) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // Simple smoke test to ensure server is running
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    // Ensure database file can be created
    expect(fs.existsSync(path.dirname(dbPath))).toBe(true);
    expect(true).toBe(true);
  });
});
