/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

function getEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> {
  if (equal === undefined) return defaultEqual
  if (typeof equal === 'boolean') return equal ? defaultEqual : () => false
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value: value as T,
    equalFn: getEqualFn(equal),
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: (prevValue) => {
      const oldValue = s.value
      const newValue = updateFn(prevValue)
      
      // Only update if value has changed according to equality function
      if (s.equalFn(oldValue, newValue)) {
        return s.value
      }
      
      s.value = newValue
      
      // Notify all dependent observers
      s.observers!.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
      })
      
      return newValue
    },
  }
  
  updateObserver(observer)
  
  const getter = (): T => {
    // Track dependencies when called
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      s.observers!.add(observer)
    }
    return s.value
  }
  
  // Add disposal method for cleanup
  ;(getter as unknown as { dispose: () => void }).dispose = () => {
    s.observer = undefined
    s.observers?.clear()
  }
  
  return getter
}
