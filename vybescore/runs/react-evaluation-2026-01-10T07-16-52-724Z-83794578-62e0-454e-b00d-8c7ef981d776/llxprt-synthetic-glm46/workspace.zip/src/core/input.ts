/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

function getEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> {
  if (equal === undefined) return defaultEqual
  if (typeof equal === 'boolean') return equal ? defaultEqual : () => false
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value,
    equalFn: getEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      s.observers!.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed according to equality function
    if (s.equalFn(nextValue, s.value)) {
      return s.value
    }
    s.value = nextValue
    
    // Notify all dependent observers
    s.observers!.forEach(observer => {
      updateObserver(observer as Observer<unknown>)
    })
    
    return s.value
  }
  
  // Add disposal method for cleanup
  ;(read as unknown as { dispose: () => void }).dispose = () => {
    s.observer = undefined
    s.observers?.clear()
  }
  
  ;(write as unknown as { dispose: () => void }).dispose = () => {
    s.observer = undefined
    s.observers?.clear()
  }

  return [read, write]
}
