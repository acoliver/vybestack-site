/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      if (disposed) return value as T
      
      // Track dependencies by executing the callback as current observer
      const currentValue = updateFn(prevValue || value)
      observer.value = currentValue
      
      return currentValue
    },
  }
  
  // Register the observer to track dependencies
  updateObserver(observer)
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  // Add disposal method to unsubscribe function as backup
  ;(unsubscribe as unknown as { dispose: () => void }).dispose = unsubscribe
  
  return unsubscribe
}
