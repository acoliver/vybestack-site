import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  // Handle empty state
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  totalItems, 
  limit, 
  onPageChange 
}: {
  currentPage: number;
  hasNext: boolean;
  totalItems: number;
  limit: number;
  onPageChange: (newPage: number) => void;
}) {
  const hasPrevious = currentPage > 1;
  
  return (
    <div>
      <p>
        Showing {Math.min((currentPage - 1) * limit + 1, totalItems)}-{' '}
        {Math.min(currentPage * limit, totalItems)} of {totalItems} items
      </p>
      <div>
        <button
          disabled={!hasPrevious}
          onClick={() => onPageChange(currentPage - 1)}
          aria-label="Previous page"
        >
          Previous
        </button>
        <span> Page {currentPage} </span>
        <button
          disabled={!hasNext}
          onClick={() => onPageChange(currentPage + 1)}
          aria-label="Next page"
        >
          Next
        </button>
      </div>
    </div>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={data.page}
        hasNext={data.hasNext}
        totalItems={data.total}
        limit={data.limit}
        onPageChange={setCurrentPage}
      />
    </section>
  );
}
