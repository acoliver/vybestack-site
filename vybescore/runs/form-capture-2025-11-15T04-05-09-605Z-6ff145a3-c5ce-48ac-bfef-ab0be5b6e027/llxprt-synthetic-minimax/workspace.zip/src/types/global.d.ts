import { Server as HttpServer } from 'http';

declare global {
  let serverInstance: HttpServer | undefined;
}

export {};