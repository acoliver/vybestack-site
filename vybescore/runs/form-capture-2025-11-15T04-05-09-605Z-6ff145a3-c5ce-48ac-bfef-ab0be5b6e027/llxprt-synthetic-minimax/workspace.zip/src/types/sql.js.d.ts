// TypeScript type declarations for sql.js
declare module 'sql.js' {
  interface SqlJsStatic {
    Database?: typeof Database;
    new(buffer?: Uint8Array): Database;
    locateFile: (filename: string) => string;
  }

  interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
    run(sql: string): void;
    getRowsModified(): number;
  }

  interface Statement {
    bind(params: Record<string, unknown> | unknown[]): void;
    step(): boolean;
    getColumnNames(): string[];
    get(params: Record<string, unknown>): Record<string, unknown>;
    free(): void;
    run(params: Record<string, unknown> | unknown[]): void;
  }

  export = SqlJsStatic;
}

declare global {
  let sql: unknown;
}

export {};