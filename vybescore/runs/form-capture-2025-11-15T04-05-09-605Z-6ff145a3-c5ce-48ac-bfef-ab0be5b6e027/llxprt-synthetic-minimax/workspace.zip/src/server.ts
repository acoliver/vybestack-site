import express from 'express';
import path from 'path';
import initSqlJs from 'sql.js';
import fs from 'fs';
import type { Server as HttpServer } from 'http';

// TypeScript type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: FormErrors;
  data: Partial<FormData>;
}

// Extend global interface for server instance
declare global {
  let serverInstance: HttpServer | undefined;
}

async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });

    let buffer: Uint8Array | null = null;
    
    // Try to load existing database
    if (fs.existsSync(DB_FILE_PATH)) {
      const dbBuffer = fs.readFileSync(DB_FILE_PATH);
      buffer = new Uint8Array(dbBuffer);
    }

    db = new SQL.Database(buffer);
    
    // Initialize schema
    const schemaSql = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.exec(schemaSql);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(DB_FILE_PATH, Buffer.from(data));
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings, allow spaces
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateFormData(data: Record<string, string>): ValidationResult {
  const errors: FormErrors = {};
  const cleanedData: Partial<FormData> = {};

  // Helper function to clean and validate required fields
  function validateRequired(field: keyof FormData, label: string): void {
    const value = (data[field] || '').trim();
    if (!value) {
      errors[field] = `${label} is required`;
    } else {
      cleanedData[field] = value;
    }
  }

  // Validate required fields
  validateRequired('firstName', 'First name');
  validateRequired('lastName', 'Last name');
  validateRequired('streetAddress', 'Street address');
  validateRequired('city', 'City');
  validateRequired('stateProvince', 'State/Province/Region');
  validateRequired('postalCode', 'Postal/Zip code');
  validateRequired('country', 'Country');
  validateRequired('email', 'Email');
  validateRequired('phone', 'Phone number');

  // Additional validations
  if (cleanedData.email && !validateEmail(cleanedData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (cleanedData.phone && !validatePhone(cleanedData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  if (cleanedData.postalCode && !validatePostalCode(cleanedData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    data: cleanedData
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: {}, 
    errors: {},
    submitted: false 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  try {
    const validation = validateFormData(req.body);
    
    if (!validation.isValid) {
      return res.status(400).render('form', { 
        data: req.body, 
        errors: validation.errors,
        submitted: false 
      });
    }

    if (!db) {
      throw new Error('Database not initialized');
    }

    const formData = validation.data as FormData;
    
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((error: Error, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    db.close();
    db = null;
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Export app and start function for testing
export default app;
export { startServer };

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    const serverInstance = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
    
    // Store server instance for graceful shutdown
    const globalObj = globalThis as any;
    globalObj.serverInstance = serverInstance;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}
// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}