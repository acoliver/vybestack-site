import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess } from 'child_process';

let server: request.SuperTest<request.Test> | null = null;
let serverProcess: ChildProcess | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server process
  serverProcess = spawn('node', [path.resolve(__dirname, '../../dist/server.js')], {
    stdio: 'pipe',
    env: { ...process.env, PORT: '3535' },
    cwd: path.resolve(__dirname, '../..')
  });
  
  // Wait for server to start
  await new Promise((resolve) => {
    serverProcess.stdout.on('data', (data: Buffer) => {
      if (data.toString().includes('Server is running')) {
        resolve(void 0);
      }
    });
  });
  
  // Give it a moment to fully initialize
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Create supertest instance by starting server and connecting to it
  server = request('http://localhost:3535');
});

afterAll(() => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Kill server process
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const response = await server
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
    
    // Check form action and method
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('validates and shows errors for missing required fields', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const response = await server
      .post('/submit')
      .send({})
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check that form is re-rendered with errors
    expect($('.error').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const invalidFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'invalid-email',
      phone: '555-1234'
    };
    
    const response = await server
      .post('/submit')
      .send(invalidFormData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check for email validation error
    expect($('#email-error').text()).toContain('valid email');
  });

  it('validates phone format', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const invalidFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: 'abc' // Invalid phone
    };
    
    const response = await server
      .post('/submit')
      .send(invalidFormData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check for phone validation error
    expect($('#phone-error').text()).toContain('valid phone');
  });

  it('persists valid submission and redirects', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const validFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-1234'
    };
    
    const response = await server
      .post('/submit')
      .send(validFormData)
      .expect(302);
    
    // Check redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow redirect
    const thankYouResponse = await server
      .get('/thank-you')
      .expect(200);
    
    // Check that thank you page contains expected content
    expect(thankYouResponse.text).toContain('Thank you for your submission');
  });

  it('handles international phone numbers', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const internationalFormData = {
      firstName: 'Jean',
      lastName: 'Dupont',
      streetAddress: '123 Rue de la Paix',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75001',
      country: 'France',
      email: 'jean@example.fr',
      phone: '+33 1 42 86 83 53'
    };
    
    const response = await server
      .post('/submit')
      .send(internationalFormData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });

  it('handles international postal codes', async () => {
    if (!server) throw new Error('Server not initialized');
    
    const internationalFormData = {
      firstName: 'Marie',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 2AA',
      country: 'UK',
      email: 'marie@example.co.uk',
      phone: '+44 20 7946 0958'
    };
    
    const response = await server
      .post('/submit')
      .send(internationalFormData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });
});

afterAll(() => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close server if started
  const globalAny = global as NodeJS.Global;
  if (globalAny.serverInstance) {
    globalAny.serverInstance.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(server)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
    
    // Check form action and method
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('validates and shows errors for missing required fields', async () => {
    const response = await request(server)
      .post('/submit')
      .send({})
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check that form is re-rendered with errors
    expect($('.error').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const invalidFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'invalid-email',
      phone: '555-1234'
    };
    
    const response = await request(server)
      .post('/submit')
      .send(invalidFormData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check for email validation error
    expect($('#email-error').text()).toContain('valid email');
  });

  it('validates phone format', async () => {
    const invalidFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: 'abc' // Invalid phone
    };
    
    const response = await request(server)
      .post('/submit')
      .send(invalidFormData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check for phone validation error
    expect($('#phone-error').text()).toContain('valid phone');
  });

  it('persists valid submission and redirects', async () => {
    const validFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-1234'
    };
    
    const response = await request(server)
      .post('/submit')
      .send(validFormData)
      .expect(302);
    
    // Check redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow redirect
    const thankYouResponse = await request(server)
      .get('/thank-you')
      .expect(200);
    
    // Check that thank you page contains expected content
    expect(thankYouResponse.text).toContain('Thank you for your submission');
  });

  it('handles international phone numbers', async () => {
    const internationalFormData = {
      firstName: 'Jean',
      lastName: 'Dupont',
      streetAddress: '123 Rue de la Paix',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75001',
      country: 'France',
      email: 'jean@example.fr',
      phone: '+33 1 42 86 83 53'
    };
    
    const response = await request(server)
      .post('/submit')
      .send(internationalFormData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });

  it('handles international postal codes', async () => {
    const internationalFormData = {
      firstName: 'Marie',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 2AA',
      country: 'UK',
      email: 'marie@example.co.uk',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(server)
      .post('/submit')
      .send(internationalFormData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });
});
