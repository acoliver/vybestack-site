/**
 * Find words starting with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words with the given prefix
  const prefixRegex = new RegExp(`\\b(${prefix}[a-zA-Z]+)\\b`, 'g');
  const matches = [];
  let match;
  
  while ((match = prefixRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if word is in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Split text by whitespace to check each token
  const words = text.split(/\s+/);
  const results = [];
  
  for (const word of words) {
    // Check if word starts with digit followed by token
    if (word.match(/^\d/)) {
      const tokenMatch = word.match(new RegExp(`\\d${escapedToken}$`));
      if (tokenMatch) {
        results.push(tokenMatch[0]);
      }
    }
  }
  
  return results;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // At least one uppercase
  if (!/[a-z]/.test(value)) return false; // At least one lowercase
  if (!/\d/.test(value)) return false;   // At least one digit
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) return false; // At least one symbol
  
  // Check for immediate repeated sequences
  // Pattern like ababab where a 2-char sequence repeats immediately
  if (/(.{2,})\1{2,}/.test(value)) {
    return false;
  }
  
  // Check for simple repeated character sequences like aaaaa or abcabcabc
  if (/(.{3,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses
 * Returns true if IPv6 detected, false otherwise
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns covering standard and shorthand forms
  const ipv6Patterns = [
    // Full IPv6 with all 8 groups
    /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
    // Shorthand with :: (compressed zeros)
    /^([0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}$/,
    // IPv6 with IPv4 embedded (last two parts)
    /^([0-9a-fA-F]{1,4}:){1,6}:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/,
    // IPv6 with leading :: and IPv4
    /^::[fF]{4}:(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
  ];
  
  // Split by whitespace and check each potential address
  const parts = value.split(/\s+/);
  for (const part of parts) {
    // First, validate it's not just an IPv4 address
    const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (ipv4Regex.test(part)) {
      continue; // Skip IPv4 addresses
    }
    
    // Check if any IPv6 pattern matches
    for (const pattern of ipv6Patterns) {
      if (pattern.test(part)) {
        return true;
      }
    }
  }
  
  return false;
}
