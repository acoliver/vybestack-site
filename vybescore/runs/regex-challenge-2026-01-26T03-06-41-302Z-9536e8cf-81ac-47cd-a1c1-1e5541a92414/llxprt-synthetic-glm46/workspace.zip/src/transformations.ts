/**
 * Capitalize the first character of each sentence
 * Capitalizes after sentence-ending punctuation (.?!)
 * Ensures exactly one space between sentences
 */
export function capitalizeSentences(text: string): string {
  // Process character by character, capitalizing after sentence-ending punctuation
  const chars = text.split('');
  let capitalizeNext = true;
  let result = '';
  
  for (let i = 0; i < chars.length; i++) {
    const char = chars[i];
    
    // Don't capitalize within abbreviations or after certain sequences
    if (capitalizeNext && char.match(/[a-z]/)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      result += char;
    }
    
    // Reset flag after sentence-ending punctuation with space
    if (char === '.' || char === '!' || char === '?') {
      // Check if next char is a space, set flag for following char
      const nextChar = chars[i + 1];
      if (nextChar === ' ') {
        capitalizeNext = true;
      }
    }
  }
  
  // Normalize spacing - ensure single space after sentences
  result = result.replace(/([.!?])\s+/g, '$1 ');
  result = result.replace(/\s{2,}/g, ' ');
  
  return result.trim();
}

/**
 * Extract URLs from text
 * Returns URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http(s):// and www. patterns
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>(){}[\]"',;!?]*[^\s<>(){}[\]"',;:!?.,]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each match
  return matches.map(url => url.replace(/[.,;:!?]+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://docs.example.com/... for docs paths
 * - Always upgrade scheme to https
 * - For docs paths (/docs/), rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlRegex = /(https?:\/\/example\.com(\/[^\s]*?))(?=[\s.,;:!?]|$)/g;
  
  return text.replace(urlRegex, (match, fullUrl, path) => {
    // Always upgrade to https
    const secureUrl = match.replace(/^http:/, 'https:');
    
    // Check if path should be rewritten to docs subdomain
    if (path.startsWith('/docs/')) {
      // Skip rewrite if path contains dynamic hints
      const hasDynamicHints = /\/cgi-bin\/|[?&=]|[.](jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/.test(path);
      
      if (!hasDynamicHints) {
        return secureUrl.replace('https://example.com', 'https://docs.example.com');
      }
    }
    
    return secureUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings
 * Returns 'N/A' if format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combinations
  // Check February (leap year handling)
  if (month === 2) {
    const isLeapYear = (year: string) => {
      const yr = parseInt(year, 10);
      return (yr % 4 === 0 && yr % 100 !== 0) || yr % 400 === 0;
    };
    
    if (day > 29 || (day === 29 && !isLeapYear(year))) {
      return 'N/A';
    }
  }
  // Check other months
  else if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    // April, June, September, November have 30 days
    return 'N/A';
  }
  else if ([1, 3, 5, 7, 8, 10, 12].includes(month) && day > 31) {
    // These months have 31 days
    return 'N/A';
  }
  
  return year;
}
