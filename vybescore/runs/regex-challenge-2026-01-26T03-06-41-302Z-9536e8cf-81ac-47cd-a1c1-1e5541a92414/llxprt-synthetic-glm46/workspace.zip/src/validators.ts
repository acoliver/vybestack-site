export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation with strict regex
 * Handles typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]+([._%+-][a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+$/;
  
  // Basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  if (/\.\./.test(value) || value.includes('._') || value.includes('-.') || value.includes('._')) {
    return false;
  }
  
  // Domain should not contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Local part should not end or start with dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890
 * Allows optional +1 prefix
 * Disallows impossible area codes (leading 0/1)
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const cleanNumber = value.replace(/\D/g, '');
  
  // Must be at least 10 digits (standard format) or 11 with country code
  if (cleanNumber.length < 10 || cleanNumber.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (US country code)
  if (cleanNumber.length === 11 && !cleanNumber.startsWith('1')) {
    return false;
  }
  
  // Extract the last 10 digits for validation
  const digits = cleanNumber.length === 11 ? cleanNumber.substring(1) : cleanNumber;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate format with regex for common patterns
  const usPhoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * Argentine phone number validation
 * Handles landlines and mobiles formats like:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
 * Area code: 2-4 digits (leading digit 1-9)
 * Subscriber number: 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces, hyphens) for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Remove optional country code +54
  const digitsWithoutCountry = cleanNumber.startsWith('+54') 
    ? cleanNumber.substring(3) 
    : cleanNumber;
  
  // Always need trunk prefix when country code is omitted
  if (!cleanNumber.startsWith('+54') && !digitsWithoutCountry.startsWith('0')) {
    return false;
  }
  
  // Remove optional mobile indicator 9 after country code
  let remainingDigits = digitsWithoutCountry;
  if (remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Remove trunk prefix 0 if present
  if (remainingDigits.startsWith('0')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Now we should have area code + subscriber number
  // Try different area code lengths (2-4 digits)
  for (let areaLen = 2; areaLen <= 4; areaLen++) {
    if (remainingDigits.length < areaLen + 6) continue;
    
    const areaCode = remainingDigits.substring(0, areaLen);
    const subscriberNumber = remainingDigits.substring(areaLen);
    
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      // Area code must start with 1-9
      if (!areaCode.startsWith('0') && /^[1-9]\d*$/.test(areaCode)) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Name validation
 * Permits unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u024F]/.test(value)) {
    return false;
  }
  
  // Only allow letters (including unicode), spaces, apostrophes, and hyphens
  const nameRegex = /^[\p{L}\s'‘’-]+$/u;
  return nameRegex.test(value) && !/[0-9]/.test(value);
}

/**
 * Credit card validation with Luhn checksum
 * Accepts Visa, Mastercard, AmEx formats based on prefix and length
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEvenDigit = false;

  // Iterate from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEvenDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEvenDigit = !isEvenDigit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Check if only digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Validate length and prefix for major card types
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex1 = /^5[1-5]\d{14}$/; // 51-55 prefix
  const mastercardRegex2 = /^2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720)\d{12}$/; // 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, 34 or 37 prefix
  
  const isValidFormat = (
    visaRegex.test(cardNumber) ||
    mastercardRegex1.test(cardNumber) ||
    mastercardRegex2.test(cardNumber) ||
    amexRegex.test(cardNumber)
  );
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cardNumber);
}
