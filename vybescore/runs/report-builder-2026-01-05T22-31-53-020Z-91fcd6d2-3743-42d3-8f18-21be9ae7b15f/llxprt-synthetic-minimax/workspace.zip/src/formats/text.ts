import { ReportData, ReportEntry } from '../types/interfaces.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];

  // Title
  lines.push(data.title);

  // Summary
  lines.push(data.summary);

  // Entries heading
  lines.push('Entries:');

  // Entry bullets
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (includeTotals) {
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
}