#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Import interfaces from relative path with .js extension
type ReportEntry = {
  label: string;
  amount: number;
};

type ReportData = {
  title: string;
  summary: string;
  entries: ReportEntry[];
};

type CLIOptions = {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
};

function parseArguments(argv: string[]): CLIOptions & { filePath: string } {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = argv[2];
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  // Parse flags starting from index 3
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = argv[++i] as 'markdown' | 'text';
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = argv[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return { filePath, format, output, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${i} missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry ${i} missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found '${filePath}'`);
      } else if (error.message.includes('JSON')) {
        console.error('Error: Invalid JSON syntax');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load data file');
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${outputPath}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(content + '\n');
  }
}

function main(): void {
  const args = parseArguments(process.argv);
  const data = loadReportData(args.filePath);
  
  let renderedContent: string;
  
  if (args.format === 'markdown') {
    renderedContent = renderMarkdown(data, args.includeTotals);
  } else {
    renderedContent = renderText(data, args.includeTotals);
  }
  
  writeOutput(renderedContent, args.output);
}

// Run main function
main();
