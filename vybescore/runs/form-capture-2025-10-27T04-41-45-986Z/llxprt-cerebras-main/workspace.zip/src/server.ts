import express, { Request, Response } from 'express';
import path from 'path';
import { existsSync, mkdirSync } from 'fs';
import { FormDatabase } from './database.js';

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Initialize database
const db = new FormDatabase();

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));
app.use(express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

// Ensure data directory exists
const dataDir = path.join(process.cwd(), 'data');
if (!existsSync(dataDir)) {
  mkdirSync(dataDir);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  // Form data
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  // Validation errors
  const errors: { [key: string]: string } = {};

  // Required field validation
  if (!formData.firstName.trim()) errors.firstName = 'First name is required';
  if (!formData.lastName.trim()) errors.lastName = 'Last name is required';
  if (!formData.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!formData.city.trim()) errors.city = 'City is required';
  if (!formData.stateProvince.trim()) errors.stateProvince = 'State/Province is required';
  if (!formData.postalCode.trim()) errors.postalCode = 'Postal code is required';
  if (!formData.country.trim()) errors.country = 'Country is required';
  if (!formData.email.trim()) errors.email = 'Email is required';
  if (!formData.phone.trim()) errors.phone = 'Phone number is required';

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (formData.email && !emailRegex.test(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (allow international formats with +, digits, spaces, parentheses, dashes)
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  if (formData.phone && !phoneRegex.test(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (accept alphanumeric strings)
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (formData.postalCode && !postalCodeRegex.test(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  // If there are validation errors, re-render the form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }

  // Insert submission into database
  db.insertSubmission({
    firstName: formData.firstName,
    lastName: formData.lastName,
    streetAddress: formData.streetAddress,
    city: formData.city,
    stateProvince: formData.stateProvince,
    postalCode: formData.postalCode,
    country: formData.country,
    email: formData.email,
    phone: formData.phone
  });

  // Save database to file
  db.saveToFile();

  // Redirect to thank you page
  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // For now, just render the thank you page without specific name
  // We could enhance this to show the user's first name if we stored it in session
  res.render('thank-you');
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;

async function startServer() {
  try {
    await db.initialize();
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server?.close(() => {
    console.log('Express server closed');
    db.close();
    console.log('Database closed');
    process.exit(0);
  });
});

// Start the server
startServer();