import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

export class FormDatabase {
  private db: initSqlJs.Database | null = null;
  private SQL: initSqlJs.SqlJsStatic | null = null;

  async initialize() {
    // Initialize SQL.js
    this.SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Load existing database or create new one
    let buffer: Buffer | undefined;
    try {
      buffer = fs.readFileSync(DB_PATH);
    } catch (error) {
      // File doesn't exist, will create new database
    }

    if (buffer) {
      this.db = new this.SQL.Database(buffer);
    } else {
      this.db = new this.SQL.Database();
      // Create table if it doesn't exist
      const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);
    }
  }

  insertSubmission(data: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
  }) {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const query = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    this.db.run(query, [
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
  }

  getAllSubmissions() {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const result = this.db.exec('SELECT * FROM submissions');
    return result[0] ? result[0].values : [];
  }

  saveToFile() {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Ensure data directory exists
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir);
    }

    // Write database to file
    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  close() {
    if (this.db) {
      this.saveToFile();
      this.db.close();
      this.db = null;
    }
  }
}