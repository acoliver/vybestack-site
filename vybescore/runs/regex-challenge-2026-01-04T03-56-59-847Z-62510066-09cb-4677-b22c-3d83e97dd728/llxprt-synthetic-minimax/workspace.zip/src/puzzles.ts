/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words that start with the prefix
  // Using word boundaries to ensure we match whole words only
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out the exceptions
  const results = matches.filter(word => {
    return !exceptions.some(exception => {
      // Case-insensitive comparison for exceptions
      return word.toLowerCase() === exception.toLowerCase();
    });
  });
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Use regex to find tokens that come after digits
  const pattern = new RegExp(`(\\d)${token}`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Convert matches to the expected format (digit + token)
  return matches.map(match => {
    return match; // The full match already includes the digit and token
  });
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  const symbolsPattern = /[^a-zA-Z0-9]/;
  if (!symbolsPattern.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (e.g., abab)
  // This checks for patterns of 2 characters repeating
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.slice(i, i + 2);
    if (pattern.length === 2) {
      const nextTwo = value.slice(i + 2, i + 4);
      if (nextTwo.length === 2 && nextTwo === pattern) {
        return false;
      }
    }
  }
  
  // Check for more obvious repeated sequences
  if (/(.)\\1\\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First check if it's IPv4 (contains dots and no colons) - should return false
  const hasDots = value.includes('.');
  const hasColons = value.includes(':');
  
  // If it has dots but no colons, it's IPv4, not IPv6
  if (hasDots && !hasColons) {
    return false;
  }
  
  // If it has neither dots nor colons, it's not an IP address
  if (!hasDots && !hasColons) {
    return false;
  }
  
  // IPv6 addresses should have colons
  if (!hasColons) {
    return false;
  }
  
  // Pattern that catches IPv6 formats
  const ipv6Regex = /\\b(?:(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{1,4}|::(?:[a-fA-F0-9]{1,4}:){0,7}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){1,7}:|:$)\\b/;

  // Check for IPv6 patterns
  if (ipv6Regex.test(value)) {
    // Double-check it's not IPv4 by ensuring it doesn't match IPv4 pattern
    const ipv4Pattern = /^(?:\\d{1,3}\\.){3}\\d{1,3}$/;
    if (!ipv4Pattern.test(value)) {
      // Additional validation: check for invalid hex characters
      if (/[^a-fA-F0-9:]/.test(value)) {
        return false;
      }
      return true;
    }
  }
  
  // Check for shorthand :: specifically
  if (value.includes('::')) {
    // Make sure it doesn't also have dots (which would indicate embedded IPv4)
    if (!hasDots) {
      return true;
    }
  }
  
  return false;
}