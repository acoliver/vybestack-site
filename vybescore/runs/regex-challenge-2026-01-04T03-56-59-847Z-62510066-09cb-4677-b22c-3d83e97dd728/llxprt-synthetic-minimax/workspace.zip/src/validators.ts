export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern - updated to reject underscores in both local and domain
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9.+]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  // Check basic format first
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Reject trailing dot in domain
  if (domain && domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // TODO: Support future options if needed
  void _options;
  // Remove all non-digit characters temporarily for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Too short (need at least 10 digits)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Too long (allow up to 11 digits with country code)
  if (digitsOnly.length > 11) {
    return false;
  }
  
  // Check if we have a country code, remove it for main validation
  const phoneDigits = digitsOnly.length === 11 && digitsOnly.startsWith('1') 
    ? digitsOnly.slice(1) 
    : digitsOnly;
  
  if (phoneDigits.length !== 10) {
    return false;
  }
  
  // Area code and central office code cannot start with 0 or 1
  const areaCode = phoneDigits.slice(0, 3);
  const centralOffice = phoneDigits.slice(3, 6);
  
  if (areaCode[0] === '0' || areaCode[0] === '1' || 
      centralOffice[0] === '0' || centralOffice[0] === '1') {
    return false;
  }
  
  // Main regex pattern for format validation - handles mixed separators
  const phonePattern = /^(\+?1?\s*)?(\([2-9]\d{2}\)|[2-9]\d{2})([-.s]?)(\([2-9]\d{2}\)|[2-9]\d{2})([-.s]?)\d{4}$/;

  // Try the main pattern first
  if (phonePattern.test(value)) {
    return true;
  }
  
  // Additional patterns to handle edge cases with mixed formats
  // Pattern for formats like "(212) 555-7890" where separators are mixed
  const mixedPattern = /^(\+?1?\s*)?\(?([2-9]\d{2})\)?([-.s]?)\(?([2-9]\d{2})\)?([-.s]?)\d{4}$/;
  
  if (mixedPattern.test(value)) {
    // Extract digits to verify the pattern is correct
    const match = value.match(mixedPattern);
    if (match) {
      const digits = match[0].replace(/\D/g, '');
      const phoneDigits = digits.length === 11 && digits.startsWith('1') 
        ? digits.slice(1) 
        : digits;
      return phoneDigits.length === 10;
    }
  }

  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Need at least 8 digits and at most 13 digits (country code + mobile indicator + area + subscriber)
  if (digitsOnly.length < 8 || digitsOnly.length > 13) {
    return false;
  }
  
  // Argentine numbers don't start with 0 when country code is present
  if (digitsOnly.startsWith('54')) {
    // Format: +54 [9] [0] area_code subscriber
    const withoutCountry = digitsOnly.slice(2);
    
    if (withoutCountry.length < 6 || withoutCountry.length > 10) {
      return false;
    }
    
    // Check for mobile indicator
    let remaining = withoutCountry;
    let hasMobile = false;
    
    if (remaining.startsWith('9')) {
      hasMobile = true;
      remaining = remaining.slice(1);
    }
    
    // Check trunk prefix (optional)
    if (remaining.startsWith('0')) {
      remaining = remaining.slice(1);
    }
    
    if (hasMobile) {
      // Mobile: area code 2-4 digits, subscriber 6-8 digits total
      // Try different area code lengths for mobile
      const lengths = [2, 3, 4];
      let valid = false;
      
      for (const len of lengths) {
        if (remaining.length >= len + 6) {
          const areaDigits = remaining.slice(0, len);
          const subscriberLength = remaining.length - len;
          
          if (subscriberLength >= 6 && subscriberLength <= 8) {
            // Validate area code format for mobile
            const areaPattern = /^[1-9]\d{0,len-1}$/;
            if (areaPattern.test(areaDigits)) {
              valid = true;
              break;
            }
          }
        }
      }
      
      if (!valid) {
        return false;
      }
    } else {
      // Landline: area code 2-4 digits, subscriber 6-8 digits total
      if (remaining.length < 2) {
        return false;
      }
      
      // Try different area code lengths
      const lengths = [2, 3, 4];
      let valid = false;
      
      for (const len of lengths) {
        if (remaining.length >= len + 6) {
          const area = remaining.slice(0, len);
          const subscriberLength = remaining.length - len;
          
          if (subscriberLength >= 6 && subscriberLength <= 8) {
            // Validate area code
            const areaPattern = /^[1-9]\d{0,3}$/;
            if (areaPattern.test(area)) {
              valid = true;
              break;
            }
          }
        }
      }
      
      if (!valid) {
        return false;
      }
    }
    
    return true;
  } else {
    // Format: [0] area_code subscriber (no country code)
    let remaining = digitsOnly;
    
    // Must start with trunk prefix 0
    if (!remaining.startsWith('0')) {
      return false;
    }
    
    remaining = remaining.slice(1); // Remove trunk prefix
    
    if (remaining.length < 7 || remaining.length > 9) {
      return false;
    }
    
    // Extract area code (2-4 digits, first digit 1-9)
    let valid = false;
    
    // Try different area code lengths
    for (let len = 2; len <= 4; len++) {
      if (remaining.length >= len + 6) {
        const area = remaining.slice(0, len);
        const subscriberLength = remaining.length - len;
        
        if (subscriberLength >= 6 && subscriberLength <= 8) {
          // Check area code format
          const areaPattern = /^[1-9]\d{0,3}$/;
          if (areaPattern.test(area)) {
            valid = true;
            break;
          }
        }
      }
    }
    
    return valid;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check for digits in the name
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols like X Æ A-12 style names - simplified pattern
  if (/[^a-zA-Z\s'-]/u.test(value)) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, and hyphens
  // The pattern checks for valid name characters only
  const namePattern = /^[a-zA-ZÀ-ÿ\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must contain at least letters (not just symbols)
  const lettersOnly = value.replace(/[^a-zA-ZÀ-ÿ]/gu, '');
  if (lettersOnly.length === 0) {
    return false;
  }
  
  // Should not be too short (less than 2 letters)
  if (lettersOnly.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Credit card numbers should be 13-19 digits
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check prefixes and lengths for major card types
  const cardType = getCardType(digitsOnly);
  if (!cardType) {
    return false;
  }
  
  // Validate the prefix and length according to card type
  if (!isValidPrefixAndLength(digitsOnly, cardType)) {
    return false;
  }
  
  // Apply Luhn checksum
  return luhnCheck(digitsOnly);
}

function getCardType(digits: string): string | null {
  // Visa: starts with 4, 13-19 digits
  if (digits.startsWith('4') && digits.length >= 13 && digits.length <= 19) {
    return 'visa';
  }
  
  // MasterCard: starts with 51-55, 16 digits (simplified)
  if (/^(5[1-5]\d{2}|\d{4})$/.test(digits) && digits.length === 16) {
    return 'mastercard';
  }
  
  // American Express: starts with 34 or 37, 15 digits
  if (/^(34|37)\d+$/.test(digits) && digits.length === 15) {
    return 'amex';
  }
  
  // Discover: starts with 6011 or 65, 16-19 digits
  if ((digits.startsWith('6011') || digits.startsWith('65')) && 
      digits.length >= 16 && digits.length <= 19) {
    return 'discover';
  }
  
  // JCB: starts with 35, 16-19 digits
  if (digits.startsWith('35') && digits.length >= 16 && digits.length <= 19) {
    return 'jcb';
  }
  
  return null;
}

function isValidPrefixAndLength(digits: string, cardType: string): boolean {
  switch (cardType) {
    case 'visa':
      return digits.startsWith('4') && digits.length >= 13 && digits.length <= 19;
    case 'mastercard':
      return /^(5[1-5]\d{2}|\d{4})$/.test(digits) && digits.length === 16;
    case 'amex':
      return /^(34|37)$/.test(digits.slice(0, 2)) && digits.length === 15;
    case 'discover':
      return (digits.startsWith('6011') || digits.startsWith('65')) && 
             digits.length >= 16 && digits.length <= 19;
    case 'jcb':
      return digits.startsWith('35') && digits.length >= 16 && digits.length <= 19;
    default:
      return false;
  }
}

function luhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
