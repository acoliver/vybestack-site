/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Pattern to find sentence endings followed by what should be capitalized
  const result = text.replace(/([.?!])(\s*)([a-z])/gi, (match, punctuation, spaces, letter) => {
    return punctuation + spaces + letter.toUpperCase();
  });
  
  // Capitalize the first character of the text if it's a letter
  const finalResult = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return finalResult;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Comprehensive URL pattern
  const urlPattern = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?:;]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs (not https://)
  const httpPattern = /\bhttp:\/\/[^\s<>"{}|\\^`[\]]+/gi;
  
  return text.replace(httpPattern, (match) => {
    // Replace http:// with https://
    return match.replace('http://', 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match URLs starting with http:// including the full path
  const urlPattern = /\b(http:\/\/[^\s<>"{}|\\^`[\]]+)/gi;
  
  return text.replace(urlPattern, (match) => {
    let newUrl = match;
    
    // Always upgrade the scheme to https://
    newUrl = newUrl.replace(/^http:\/\//, 'https://');
    
    // Check if this is a docs URL by looking for /docs/ in the path
    const docsMatch = newUrl.match(/^https?:\/\/([^\/\s]+)(\/docs\/.+)$/i);
    
    if (docsMatch) {
      const path = docsMatch[2];
      
      // Check for dynamic hints and legacy extensions in the path
      const hasDynamicHints = /(\?|&|=)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))(\?|$)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com and preserve the path
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 2024 is leap year
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Handle February 29th for non-leap years
  if (month === 2 && day === 29) {
    // Check if it's a leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return year.toString();
}