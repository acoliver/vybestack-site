import { RenderOptions } from '../types/index.js';

export function renderText(options: RenderOptions): string {
  const { data, includeTotals } = options;
  const { title, summary, entries } = data;
  
  let output = `${title}
`;
  output += `${summary}
`;
  output += `Entries:
`;
  
  for (const entry of entries) {
    const amount = entry.amount.toFixed(2);
    output += `- ${entry.label}: $${amount}
`;
  }
  
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = total.toFixed(2);
    output += `
Total: $${totalFormatted}`;
  }
  
  return output;
}