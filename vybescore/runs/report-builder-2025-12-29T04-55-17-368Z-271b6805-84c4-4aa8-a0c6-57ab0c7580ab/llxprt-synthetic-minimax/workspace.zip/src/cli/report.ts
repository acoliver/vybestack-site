#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown, renderText } from '../formats/index.js';
import type { ReportData, CLIOptions } from '../types/index.js';

function parseArgs(argv: string[]): CLIOptions {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (!dataFile.endsWith('.json')) {
    console.error('Error: Input file must be a JSON file');
    process.exit(1);
  }
  
  const options: CLIOptions = {
    format: 'markdown', // default
    includeTotals: false
  };
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    switch (arg) {
      case '--format': {
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        const format = args[i];
        if (format !== 'markdown' && format !== 'text') {
          console.error('Error: Unsupported format. Supported formats: markdown, text');
          process.exit(1);
        }
        options.format = format;
        break;
      }
        
      case '--output': {
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        options.output = args[i];
        break;
      }
        
      case '--includeTotals':
        options.includeTotals = true;
        break;
        
      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown option ${arg}`);
          process.exit(1);
        }
        break;
    }
    
    i++;
  }
  
  return options;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const report = data as Record<string, unknown>;
  
  // Check required fields
  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" field is required and must be a string');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field is required and must be a string');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" field is required and must be an array');
  }
  
  // Validate entries
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const options = parseArgs(process.argv);
    
    // Get the data file path (first argument)
    const dataFile = process.argv[2];
    
    if (!dataFile) {
      console.error('Error: Data file path is required');
      process.exit(1);
    }
    
    // Read and parse the JSON file
    let rawData: string;
    try {
      rawData = readFileSync(dataFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Cannot read file ${dataFile}`);
      process.exit(1);
    }
    
    let data: unknown;
    try {
      data = JSON.parse(rawData);
    } catch (error) {
      console.error('Error: Invalid JSON syntax in input file');
      process.exit(1);
    }
    
    // Validate the data structure
    const reportData = validateReportData(data);
    
    // Render the report
    let output: string;
    const renderOptions = {
      data: reportData,
      format: options.format,
      output: options.output,
      includeTotals: options.includeTotals
    };
    
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(renderOptions);
        break;
      case 'text':
        output = renderText(renderOptions);
        break;
      default:
        console.error('Error: Unsupported format');
        process.exit(1);
    }
    
    // Write output
    if (options.output) {
      try {
        writeFileSync(options.output, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Cannot write to file ${options.output}`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
