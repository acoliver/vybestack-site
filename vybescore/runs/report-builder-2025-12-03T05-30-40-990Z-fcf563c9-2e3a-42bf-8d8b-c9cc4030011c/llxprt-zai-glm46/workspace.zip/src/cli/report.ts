#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import type { ReportData, FormatType, RenderOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliOptions {
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

interface ParseResult {
  filePath: string;
  options: CliOptions;
}

function parseArguments(): ParseResult {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false,
  };
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i] as FormatType;
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      options.format = formatValue;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
    
    i++;
  }
  
  return { filePath, options };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    return false;
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      return false;
    }
    
    if (typeof entryObj.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const absolutePath = path.resolve(filePath);
    const fileContent = fs.readFileSync(absolutePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      console.error('Error: Invalid JSON structure. Expected format: { title: string, summary: string, entries: Array<{ label: string, amount: number }> }');
      process.exit(1);
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in file: ${filePath}`);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${filePath}`);
    } else {
      console.error(`Error: Failed to read file: ${filePath}`);
    }
    process.exit(1);
  }
}

function getRenderer(format: FormatType) {
  switch (format) {
    case 'markdown':
      return markdownRenderer;
    case 'text':
      return textRenderer;
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
}

function main(): void {
  const { filePath, options } = parseArguments();
  
  const reportData = loadReportData(filePath);
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };
  
  const renderer = getRenderer(options.format);
  const output = renderer.render(reportData, renderOptions);
  
  if (options.output) {
    try {
      fs.writeFileSync(path.resolve(options.output), output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to output file: ${options.output}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
