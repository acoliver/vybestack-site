/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries after .?! with smart spacing.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that shouldn't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'St', 'etc', 'e\.g', 'i\.e'];
  const abbrevPattern = new RegExp(`\b(?:${abbreviations.join('|')})\.$`);
  
  // Split into sentences while preserving punctuation
  const sentences = text.split(/([.?!]+)/);
  
  let result = '';
  let i = 0;
  
  while (i < sentences.length) {
    const currentSentence = sentences[i]?.trim();
    const punctuation = sentences[i + 1] || '';
    
    if (currentSentence) {
      // Check if the current text might be an abbreviation
      const isAbbreviation = abbrevPattern.test(currentSentence + punctuation);
      
      if (!isAbbreviation && currentSentence.length > 0) {
        // Capitalize first letter
        const capitalized = currentSentence.charAt(0).toUpperCase() + currentSentence.slice(1);
        result += capitalized;
      } else {
        result += currentSentence;
      }
      
      // Add punctuation and proper spacing
      if (punctuation) {
        result += punctuation;
        
        // Look ahead to see if there's more content
        if (i + 2 < sentences.length) {
          result += ' ';
        }
      }
    }
    
    i += 2; // Move to next sentence part (skip punctuation)
  }
  
  // Clean up extra spaces
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches URLs starting with http/https or www
  // Allow dots, slashes, and common URL characters
  const urlPattern = /https?:\/\/[^\s]+|www\.[^\s]+/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,!?;:"'()\[\]{}<>]+$/g, ''));
}

/**
 * Replace all http:// URLs with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Find http:// URLs and replace with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to HTTPS and docs.example.com for /docs/ paths.
 * Skips host rewrite for dynamic content but still upgrades to HTTPS.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/(http:\/\/example\.com)(\/[^\s]*)?/g, (match, protocol, path = '') => {
    // Always upgrade to HTTPS first
    let newUrl = 'https://example.com' + path;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Skip host rewrite for dynamic content
      const dynamicPatterns = [
        /\/(cgi-bin|api|rest|v1|v2|v3)\//,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/,
      ];
      
      const isDynamic = dynamicPatterns.some(pattern => pattern.test(path));
      
      if (!isDynamic) {
        // Rewrite domain to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' for invalid formats or impossible dates.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Basic date validation (check for invalid dates like Feb 30)
  const daysInMonth = {
    1: 31, 2: (yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0)) ? 29 : 28,
    3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > daysInMonth[monthNum as keyof typeof daysInMonth]) {
    return 'N/A';
  }
  
  return year;
}
