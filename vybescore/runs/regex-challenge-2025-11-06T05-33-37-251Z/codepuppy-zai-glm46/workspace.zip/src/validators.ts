export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using strict patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Local part: letters, digits, +, -, . (no consecutive dots, no leading/trailing dots)
  // Domain: letters, digits, - (no underscores, no consecutive dots, no leading/trailing dots)
  // TLD: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9+._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  // Check basic format first
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  const hasConsecutiveDots = /\.\./.test(value);
  const hasUnderscoreInDomain = /@.*_/.test(value);
  const hasTrailingDot = value.endsWith('.');
  const hasLeadingDot = value.startsWith('.');
  
  return !hasConsecutiveDots && !hasUnderscoreInDomain && !hasTrailingDot && !hasLeadingDot;
}

/**
 * Validate US phone numbers with common separators and optional +1 prefix.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 2125557890
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Minimum length for US phone (without country code) is 10 digits
  // Maximum length is 11 digits (with +1 prefix)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) return false;
    phoneNumber = digitsOnly.substring(1); // Remove country code
  }
  
  // Now we should have exactly 10 digits
  if (phoneNumber.length !== 10) return false;
  
  // Area code is first 3 digits, cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check the overall pattern matches accepted formats
  const patterns = [
    /^\+?1?\s*\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/, // (212) 555-7890, 212-555-7890, +1 2125557890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers (both landlines and mobiles).
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Optional +54 prefix, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits total after area code
  const argentinePhoneRegex = /^(\+54)?(?:0?9?)([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, areaCode] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // If no country code, must have trunk prefix (0)
  if (!countryCode && !cleanValue.startsWith('0')) return false;
  
  // Check total structure is reasonable
  // Buenos Aires area codes start with 11, other provinces start with 2xx-3xx etc.
  // For simplicity, we just check the digit counts
  const totalDigits = cleanValue.replace(/\D/g, '').length;
  return totalDigits >= 10 && totalDigits <= 15;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like 'X Æ A-12'
 */
export function isValidName(value: string): boolean {
  // Unicode letters (including accented), apostrophes, hyphens, spaces
  // Must have at least 2 letters, reject digits and most symbols
  const nameRegex = /^[\p{L}][\p{L}'\- ]*[\p{L}]$/u;
  
  // Check basic format first
  if (!nameRegex.test(value)) return false;
  
  // Additional validations
  const hasDigits = /\d/.test(value);
  const hasInvalidChars = /[^\p{L}'\- \s]/u.test(value);
  const hasMultipleConsecutiveSpaces = /\s{2,}/.test(value);
  const hasMultipleConsecutiveApostrophes = /'{2,}/.test(value);
  const hasMultipleConsecutiveHyphens = /-{2,}/.test(value);
  
  // Must contain at least 2 letters (not just symbols)
  const letterCount = (value.match(/[\p{L}]/gu) || []).length;
  
  return !hasDigits && 
         !hasInvalidChars && 
         !hasMultipleConsecutiveSpaces && 
         !hasMultipleConsecutiveApostrophes && 
         !hasMultipleConsecutiveHyphens && 
         letterCount >= 2;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx using prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check basic length requirements
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Check prefixes and lengths for major card types
  const cardPatterns = [
    { regex: /^4/, lengths: [13, 16, 19] }, // Visa
    { regex: /^5[1-5]/, lengths: [16] }, // Mastercard
    { regex: /^3[47]/, lengths: [15] }, // American Express
    { regex: /^6(?:011|5)/, lengths: [16] }, // Discover (bonus)
  ];
  
  const isValidCardType = cardPatterns.some(pattern => {
    if (!pattern.regex.test(digitsOnly)) return false;
    return pattern.lengths.includes(digitsOnly.length);
  });
  
  if (!isValidCardType) return false;
  
  // Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
