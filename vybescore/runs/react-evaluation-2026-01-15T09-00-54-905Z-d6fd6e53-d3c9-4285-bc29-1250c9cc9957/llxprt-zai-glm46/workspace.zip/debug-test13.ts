// Test with detailed logging
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Test: compute cells fire callbacks (detailed) ===')
const [input, setInput] = createInput(1)

console.log('1. Creating computed...')
const output = createComputed(() => input() + 1)
console.log('   output() =', output())

console.log('2. Creating callback...')
let value = 0
let callbackExecutions = 0
const unsub = createCallback(() => {
  callbackExecutions++
  console.log(`   Callback execution #${callbackExecutions}`)
  console.log(`     Reading output()...`)
  const val = output()
  console.log(`     output() = ${val}`)
  value = val
  console.log(`     value = ${value}`)
})

console.log('3. After callback creation:')
console.log('   value =', value)
console.log('   callbackExecutions =', callbackExecutions)

console.log('4. Calling setInput(3)...')
setInput(3)

console.log('5. After setInput(3):')
console.log('   value =', value)
console.log('   callbackExecutions =', callbackExecutions)
console.log('   Expected: value = 4, callbackExecutions = 2')
console.log('   PASS:', value === 4 && callbackExecutions === 2)

unsub()
