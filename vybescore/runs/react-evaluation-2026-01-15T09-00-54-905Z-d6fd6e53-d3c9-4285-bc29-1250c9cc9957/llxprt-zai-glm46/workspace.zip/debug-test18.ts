// Test to see what computed getter adds to tracking
import { createInput, createComputed } from './src/index.js'

console.log('=== Testing what gets tracked ===')

const [input, setInput] = createInput(1)

// Monkey-patch the tracking to see what gets added
const OriginalComputed = createComputed

let trackedItems: any[] = []

// We can't easily monkey-patch, so let's trace through the logic manually

const output = createComputed(() => input() + 1)

console.log('Created computed')
console.log('output is a function:', typeof output === 'function')

// The issue is that the getter returns o.value, but o is not exposed
// When a callback calls output(), it gets the value, but doesn't register
// that it depends on the computed observer 'o'

console.log('\nThe problem:')
console.log('1. Callback calls output()')
console.log('2. output() getter runs')
console.log('3. getter checks if there is an active observer (the callback)')
console.log('4. If yes, it adds O (the computed observer) to callback._tracking')
console.log('5. But the getter just returns o.value, it does NOT expose o')
console.log('\nSo when input changes:')
console.log('1. Input marks computed as dirty')
console.log('2. Input notifies observers... but which observers?')
console.log('3. The computed is registered as an observer of input')
console.log('4. But is the CALLBACK registered as an observer of the COMPUTED?')
console.log('\nLet me check the computed getter logic more carefully...')

// The getter needs to register the CALLER as an observer of THIS computed
// But it also needs to track THIS computed in the caller's tracking set
// The current code does: tracking.add(o)
// This adds the observer 'o' to the tracking set
// But does 'o' have an observers set that the callback gets added to?

// Looking at the code, 'o' is an Observer, but it doesn't expose an 'observers' property
// The 'observers' set is a local variable in the closure, not a property of 'o'
// So when the getter adds 'o' to tracking, the callback can't later register itself with 'o'

console.log('\nFIX NEEDED:')
console.log('The computed observer needs to expose its observers set')
console.log('OR the getter needs to handle registration differently')
