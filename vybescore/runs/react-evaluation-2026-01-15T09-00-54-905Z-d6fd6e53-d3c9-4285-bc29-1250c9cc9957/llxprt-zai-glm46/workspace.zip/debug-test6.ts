import { createInput, createComputed } from './src/index.js'

console.log('=== Test: Simple input and computed ===')
const [input] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})

console.log('timesTwo() =', timesTwo())

console.log('\n=== Test: Mutating input ===')
console.log('Setting input to 3')
const setter = (() => {  // We need the actual setter
  // This is just to demonstrate - in real code we'd use the setter from createInput
})()

// Actually, let me test with real setter
const [input2, setInput2] = createInput(10)
let timesTwoCount = 0
const timesTwo2 = createComputed(() => {
  timesTwoCount++
  console.log(`  Computing timesTwo2 (call #${timesTwoCount}), input2 =`, input2())
  return input2() * 2
})

console.log('timesTwo2() =', timesTwo2())
console.log('timesTwo2() =', timesTwo2())
console.log('Calling setInput2(20)')
setInput2(20)
console.log('After setInput2, timesTwo2() =', timesTwo2())
console.log('timesTwo2() =', timesTwo2())
console.log('Total timesTwo2 calls:', timesTwoCount)
