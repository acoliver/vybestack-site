// Test to see if computed values expose an observer interface
import { createInput, createComputed } from './src/index.js'

console.log('=== Testing computed observer registration ===')

const [input, setInput] = createInput(1)

// Create computed
const output = createComputed(() => input() + 1)
console.log('Created computed: output() =', output())

// Try to access the internal observer object
const getterFn = output as any
console.log('\nInspecting getter function:')
console.log('  type:', typeof getterFn)
console.log('  name:', getterFn.name)

// The getter is a closure, so the observer 'o' is not directly accessible
// But we can check if the computed has been set up properly
console.log('\nCalling output() again to trigger compute if needed...')
const val = output()
console.log('  output() =', val)

// Try to see what happens when we access it during an active observer
console.log('\nManually calling updateObserver on computed...')
// We can't do this easily without accessing internals

// Instead, let's verify the behavior by checking the input's observers
const inputFn = input as any
console.log('\nInspecting input function...')
// Can't access internals directly either

console.log('\nChanging input and seeing if computed updates...')
setInput(2)
console.log('  After setInput(2), output() =', output())
setInput(3)
console.log('  After setInput(3), output() =', output())
