// Direct test of computed registration
import { createInput, createComputed } from './src/index.js'

console.log('=== Direct test of computed observers ===')

const [input, setInput] = createInput(1)

const output = createComputed(() => input() + 1)

// Access the computed observer
const getter = output as any
console.log('getter:', getter)
console.log('getter observers:', getter.observers)

// The getter function doesn't expose the observer
// But the observer 'o' has an observers property
// Let's try to access it through closure

// Actually, let me check if O.observers is being populated
console.log('\nCreating a callback manually...')

// Create a mock observer
type Dep = { observers: Set<any> }
const mockObserver = {
  name: 'mock',
  value: undefined,
  updateFn: (v?: any) => v,
  _tracking: new Set<Dep>(),
  execute: () => console.log('Mock execute called')
}

// Simulate what happens when callback calls output()
console.log('\nSimulating callback reading output()...')
const { getActiveObserver, updateObserver } = await import('./src/types/reactive.js')

// Set mock as active
let activeObs = mockObserver as any
// Monkey-patch getActiveObserver (not possible in this context)

// Instead, let's just check if output.observers works
console.log('\nChecking if computed exposes observers...')
// Can't do this without accessing internals

// Let me try a different approach - modify computed.ts to log
console.log('\n=== Need to add logging to computed.ts ===')
