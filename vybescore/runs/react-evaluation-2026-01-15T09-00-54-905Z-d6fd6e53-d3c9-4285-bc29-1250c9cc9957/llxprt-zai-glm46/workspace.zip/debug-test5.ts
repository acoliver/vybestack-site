import { createInput, createComputed } from './src/index.js'

console.log('=== Test: Simple dependency chain ===')
const [input] = createInput(1)

const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})

console.log('timesTwo() =', timesTwo())
console.log('timesTwo() =', timesTwo())  // Should not recompute

console.log('\n=== Test: Does input change trigger recomputation? ===')
const [input2] = createInput(10)
let computedCallCount = 0
const plusFive = createComputed(() => {
  computedCallCount++
  console.log(`  Computing plusFive (call #${computedCallCount}), input2 =`, input2())
  return input2() + 5
})

console.log('plusFive() =', plusFive())
console.log('plusFive() =', plusFive())
console.log('Total calls:', computedCallCount)

console.log('\n=== Test: Direct chained computed ===')
const [input3] = createInput(2)
const double = createComputed(() => {
  console.log('  Computing double, input3 =', input3())
  return input3() * 2
})

const quadruple = createComputed(() => {
  console.log('  Computing quadruple, double() =', double())
  return double() * 2
})

console.log('quadruple() =', quadruple())
