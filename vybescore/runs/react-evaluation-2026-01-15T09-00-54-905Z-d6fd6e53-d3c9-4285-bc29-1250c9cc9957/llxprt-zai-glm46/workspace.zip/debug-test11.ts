import { createInput, createComputed, createCallback } from './src/index.js'

// Test: compute cells fire callbacks - detailed tracing
const [input, setInput] = createInput(1)

console.log('=== Step 1: Create computed ===')
const output = createComputed(() => input() + 1)
console.log('output() =', output())

console.log('\n=== Step 2: Create callback ===')
let value = 0
let callCount = 0
const unsub = createCallback(() => {
  callCount++
  console.log(`  Callback #${callCount} executing`)
  console.log(`    input() = ${input()}`)
  console.log(`    output() = ${output()}`)
  value = output()
  console.log(`    value set to ${value}`)
})

console.log('\nAfter callback creation:')
console.log('value:', value, '(expected: 2)')
console.log('callCount:', callCount, '(expected: 1)')

console.log('\n=== Step 3: Set input to 3 ===')
console.log('Calling setInput(3)...')
setInput(3)

console.log('\nAfter setInput(3):')
console.log('input():', input(), '(expected: 3)')
console.log('output():', output(), '(expected: 4)')
console.log('value:', value, '(expected: 4)')
console.log('callCount:', callCount, '(expected: 2)')

if (value !== 4) {
  console.log('\n[ERROR] FAIL: Callback was not triggered when input changed!')
  console.log('The callback should have executed when input changed from 1 to 3')
} else {
  console.log('\n[OK] PASS: Callback was triggered correctly')
}

unsub()
