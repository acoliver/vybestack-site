import { createInput, createComputed, createCallback } from './src/index.js'

// Test: compute cells fire callbacks
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log('Initial state:')
console.log('input:', input())
console.log('output:', output())

let value = 0
let callCount = 0
const unsub = createCallback(() => {
  callCount++
  console.log(`Callback execution #${callCount}, output is:`, output())
  value = output()
})

console.log('\nAfter callback creation:')
console.log('value:', value)
console.log('callCount:', callCount)

console.log('\nSetting input to 3:')
setInput(3)

console.log('After setInput(3):')
console.log('input:', input())
console.log('output:', output())
console.log('value:', value)
console.log('callCount:', callCount)
console.log('Expected value: 4')
console.log('Expected callCount: 2')

unsub()
