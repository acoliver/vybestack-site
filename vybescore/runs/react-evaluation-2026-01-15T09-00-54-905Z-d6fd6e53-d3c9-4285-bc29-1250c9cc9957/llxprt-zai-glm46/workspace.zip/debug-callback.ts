import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Test: Callbacks fire on update')
const [input, setInput] = createInput(1, undefined, { name: 'testInput' })
const output = createComputed(() => {
  const val = input()
  console.log('  output computing: input() =', val, 'result:', val + 1)
  return val + 1
}, undefined, undefined, { name: 'testOutput' })

let value = 0
console.log('\nCreating callback...')
createCallback(() => {
  console.log('  callback executing, output() =', output())
  value = output()
})

console.log('\nAfter callback creation:')
console.log('  value =', value)
console.log('  Expected: 2')

console.log('\nCalling setInput(3)...')
setInput(3)
console.log('\nAfter setInput(3):')
console.log('  value =', value)
console.log('  Expected: 4')
