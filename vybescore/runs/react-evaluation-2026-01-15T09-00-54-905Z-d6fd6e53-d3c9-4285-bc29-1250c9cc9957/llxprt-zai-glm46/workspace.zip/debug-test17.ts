// Test to understand the tracking issue
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Understanding the tracking issue ===')

const [input, setInput] = createInput(1)
console.log('1. Created input with value 1')

const output = createComputed(() => input() + 1)
console.log('2. Created computed that depends on input')
console.log('   output() =', output())

console.log('\n3. Creating callback that reads output()...')
let callbackCount = 0
createCallback(() => {
  callbackCount++
  console.log(`   Callback #${callbackCount} executing`)
  console.log(`     About to call output()...`)
  const val = output()
  console.log(`     output() returned ${val}`)
})
console.log('   Callback created. Total executions:', callbackCount)

console.log('\n4. Calling setInput(2)...')
setInput(2)
console.log('   After setInput(2), total callback executions:', callbackCount)

console.log('\n=== Expected behavior ===')
console.log('Callback should execute when:')
console.log('  - Initially (executed once, callbackCount = 1)')
console.log('  - When input changes (should execute again, callbackCount = 2)')
console.log('\nBut callback is not executing when input changes!')
console.log('This suggests the callback is not tracking the computed value.')
