// Replicate the exact test case from reactive-comprehensive.spec.ts
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Test: compute cells fire callbacks ===')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
createCallback(() => (value = output()))
console.log('After callback creation, value =', value, '(should be 2)')
setInput(3)
console.log('After setInput(3), value =', value, '(should be 4)')
console.log('PASS:', value === 4)

console.log('\n=== Test: callbacks can be added and removed ===')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output2()))
const values2: number[] = []
createCallback(() => values2.push(output2()))

console.log('After creation, values1.length =', values1.length, '(should be 1)')
console.log('After creation, values2.length =', values2.length, '(should be 1)')

setInput2(31)
console.log('After setInput2(31), values1.length =', values1.length, '(should be 2)')
console.log('After setInput2(31), values2.length =', values2.length, '(should be 2)')

unsubscribe1()
setInput2(41)
console.log('After unsubscribe and setInput2(41), values1.length =', values1.length, '(should be 2)')
console.log('After unsubscribe and setInput2(41), values2.length =', values2.length, '(should be 3)')
console.log('values2.length > values1.length:', values2.length > values1.length, '(should be true)')
