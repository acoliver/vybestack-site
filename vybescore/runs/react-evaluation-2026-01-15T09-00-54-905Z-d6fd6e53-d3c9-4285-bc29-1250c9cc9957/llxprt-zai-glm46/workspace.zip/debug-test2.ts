import { createInput, createComputed } from './src/index.js'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input =', input())
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input =', input())
  return input() * 30
})
const sum = createComputed(() => {
  console.log('Computing sum, timesTwo =', timesTwo(), 'timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum())
console.log('Calling setInput(3)')
setInput(3)
console.log('After setInput(3), sum:', sum())
console.log('Expected: 96')
