import { createInput, createComputed, createCallback } from './src/index.js'

// Test: Direct input changes should trigger callbacks
const [input, setInput] = createInput(1)

console.log('=== Creating callback that reads input directly ===')
let value = 0
let callCount = 0

const unsub = createCallback(() => {
  callCount++
  console.log(`Callback execution #${callCount}, input() =`, input())
  value = input()
})

console.log('\nAfter callback creation:')
console.log('value:', value)
console.log('callCount:', callCount)

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\nAfter setInput(3):')
console.log('input:', input())
console.log('value:', value)
console.log('callCount:', callCount)
console.log('Expected value: 3')
console.log('Expected callCount: 2')

unsub()
