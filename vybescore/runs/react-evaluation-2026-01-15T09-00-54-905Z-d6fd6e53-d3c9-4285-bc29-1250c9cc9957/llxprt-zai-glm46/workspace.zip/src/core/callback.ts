/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const dependencies: Subject<unknown>[] = []
  
  const observer: Observer<T> & ObserverR & { _tracking?: Set<Subject<unknown>>; execute: () => void } = {
    value,
    updateFn,
    _tracking: new Set(),
    execute: () => {
      // Re-run the callback to update dependencies and execute the effect
      // First, unregister from old dependencies
      dependencies.forEach(dep => {
        dep.observers.delete(observer)
      })
      dependencies.length = 0
      
      // Set up tracking for new dependencies
      observer._tracking = new Set()
      
      // Execute the user's callback (which will track dependencies via input/computed reads)
      updateObserver(observer)
      
      // Store the new dependencies and register with them
      const tracked = observer._tracking
      if (tracked) {
        tracked.forEach(dep => {
          if (dep && dep.observers) {
            dependencies.push(dep)
            dep.observers.add(observer)
          }
        })
      }
      delete observer._tracking
    }
  }
  
  // Register observer to track dependencies and run the effect initially
  observer.execute()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unregister from all dependencies
    dependencies.forEach(dep => {
      if (dep && dep.observers) {
        dep.observers.delete(observer)
      }
    })
  }
}
