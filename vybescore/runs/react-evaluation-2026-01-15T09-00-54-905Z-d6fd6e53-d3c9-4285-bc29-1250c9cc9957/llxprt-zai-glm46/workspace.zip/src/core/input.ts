/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Track that this observer reads from this subject
      const tracking = (observer as { _tracking?: Set<unknown> })._tracking
      if (tracking) {
        tracking.add(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const old = s.value
    s.value = nextValue
    if (old !== nextValue) {
      // Create a copy of observers to avoid issues if the set is modified during iteration
      const observersCopy = Array.from(s.observers)
      
      // First, execute callbacks (they run immediately)
      const callbackObservers: Array<{ execute?: () => void }> = []
      const computedObservers: Array<{ markDirty?: () => void; compute?: () => void }> = []
      
      observersCopy.forEach((observer) => {
        const obs = observer as { markDirty?: () => void; execute?: () => void; compute?: () => void }
        if (typeof obs.execute === 'function') {
          callbackObservers.push(obs)
        } else if (typeof obs.markDirty === 'function') {
          obs.markDirty()
          if (typeof obs.compute === 'function') {
            computedObservers.push(obs)
          }
        }
      })
      
      // Execute callbacks first
      callbackObservers.forEach((obs) => {
        obs.execute!()
      })
      
      // Then trigger recomputation for computed values (which may trigger more callbacks)
      computedObservers.forEach((obs) => {
        obs.compute!()
      })
    }
    return s.value
  }

  return [read, write]
}
