/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  updateObserver,
  Options,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  type Dep = { observers: Set<ObserverR> }
  const state = { dirty: true, computing: false }
  const dependencies: Dep[] = []
  const observers: Set<ObserverR> = new Set()
  
  const o: Observer<T> & { markDirty: () => void; compute: () => void; observers: Set<ObserverR> } = {
    name: options?.name,
    value,
    updateFn,
    observers,
    markDirty: () => { 
      state.dirty = true 
    },
    compute: () => {
      if (state.dirty && !state.computing) {
        state.computing = true
        try {
          // Unregister from old dependencies
          dependencies.forEach(dep => {
            dep.observers.delete(o)
          })
          dependencies.length = 0
          
          // Set up tracking for new dependencies
          ;(o as { _tracking?: Set<Dep> })._tracking = new Set()
          
          // Use updateObserver to ensure this observer is active during computation
          updateObserver(o)
          
          // Notify our observers that we've updated (they should recompute too)
          observers.forEach(obs => {
            const obsWithMethods = obs as { markDirty?: () => void; compute?: () => void; execute?: () => void }
            if (typeof obsWithMethods.execute === 'function') {
              // This is a callback, execute it
              obsWithMethods.execute()
            } else if (typeof obsWithMethods.markDirty === 'function') {
              // This is another computed, mark it dirty
              obsWithMethods.markDirty()
              if (typeof obsWithMethods.compute === 'function') {
                obsWithMethods.compute()
              }
            }
          })
          
          // Register with new dependencies
          const tracked = (o as { _tracking?: Set<Dep> })._tracking
          if (tracked) {
            tracked.forEach(dep => {
              if (dep && dep.observers) {
                dependencies.push(dep)
                dep.observers.add(o)
              }
            })
          }
          
          delete (o as { _tracking?: Set<Dep> })._tracking
          state.dirty = false
        } finally {
          state.computing = false
        }
      }
    }
  }
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // This getter is being accessed by another observer
      // Register this computed as an observer of the requesting observer
      observers.add(observer)
      // Track this computed value (not the getter function, but the observer 'o')
      // in the parent observer's tracking set
      const tracking = (observer as { _tracking?: Set<ObserverR | Dep> })._tracking
      if (tracking) {
        tracking.add(o)
      }
    }
    
    if (state.dirty) {
      o.compute()
    }
    return o.value!
  }
  
  // Initialize value and dependencies
  o.compute()
  
  return getter
}
