// Test computed getter behavior
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Inspecting computed value structure ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log('output:', output)
console.log('output type:', typeof output)
console.log('output():', output())

// Try to access internal properties
const outputAny = output as any
console.log('output.name:', outputAny.name)
console.log('output.value:', outputAny.value)
console.log('output.observers:', outputAny.observers)
console.log('output.markDirty:', outputAny.markDirty)
console.log('output.compute:', outputAny.compute)

// Create callback and see if it registers with computed
let callbackCount = 0
const unsub = createCallback(() => {
  callbackCount++
  console.log(`Callback #${callbackCount}, output() = ${output()}`)
})

console.log('\nAfter callback creation:')
console.log('output.observers.size:', outputAny.observers?.size)

console.log('\nChanging input to 2...')
setInput(2)

console.log('\nAfter setInput(2):')
console.log('callbackCount:', callbackCount)

unsub()
