// Test to inspect what the callback is tracking
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Inspecting callback tracking ===')

const [input, setInput] = createInput(1)

console.log('Creating computed...')
const output = createComputed(() => input() + 1)
console.log('output():', output())

console.log('\nCreating callback...')
let callbackCount = 0
const unsub = createCallback(() => {
  callbackCount++
  console.log(`Callback #${callbackCount}`)
  const val = output()
  console.log(`  output() = ${val}`)
})

// Try to inspect what the callback registered with
console.log('\nInspecting input observers...')
// Can't access internals directly

console.log('\nChanging input...')
setInput(2)
console.log('Callback executions:', callbackCount)

unsub()

// Now let's trace through what SHOULD happen
console.log('\n\n=== Expected flow ===')
console.log('1. createComputed creates observer O with observers set')
console.log('2. createCallback creates observer C with _tracking set')
console.log('3. Callback function runs:')
console.log('   - updateObserver(C) sets C as active')
console.log('   - output() getter is called')
console.log('   - getter sees C is active')
console.log('   - getter adds C to O.observers')
console.log('   - getter adds O to C._tracking')
console.log('4. After callback init, C._tracking contains O')
console.log('5. C is registered with all dependencies in C._tracking')
console.log('\n6. When input changes:')
console.log('   - input notifies all observers including O')
console.log('   - O marks itself dirty')
console.log('   - O.compute() runs and notifies O.observers')
console.log('   - C is in O.observers, so C gets notified')
console.log('   - C.execute() runs the callback again')
