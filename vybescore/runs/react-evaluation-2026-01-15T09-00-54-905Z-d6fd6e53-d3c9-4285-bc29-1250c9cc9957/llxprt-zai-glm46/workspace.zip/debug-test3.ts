import { createInput, createComputed, createCallback } from './src/index.js'

const [input, setInput] = createInput(1)
let timesTwoCallCount = 0
const timesTwo = createComputed(() => {
  timesTwoCallCount++
  console.log(`timesTwo call #${timesTwoCallCount}, input =`, input())
  return input() * 2
})

let timesThirtyCallCount = 0
const timesThirty = createComputed(() => {
  timesThirtyCallCount++
  console.log(`timesThirty call #${timesThirtyCallCount}, input =`, input())
  return input() * 30
})

let sumCallCount = 0
const sum = createComputed(() => {
  sumCallCount++
  console.log(`sum call #${sumCallCount}, timesTwo =`, timesTwo(), 'timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum())
console.log('Calling setInput(3)')
setInput(3)
console.log('After setInput(3), sum:', sum())
console.log('Expected: 96')
console.log('Total calls - timesTwo:', timesTwoCallCount, 'timesThirty:', timesThirtyCallCount, 'sum:', sumCallCount)
