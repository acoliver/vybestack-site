// Test to see if callback tracks computed dependencies
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Test: Does callback track computed values? ===')

// Add logging to track what gets registered
const [input, setInput] = createInput(1)
console.log('Created input')

const output = createComputed(() => input() + 1)
console.log('Created computed')

let callbackCallCount = 0
createCallback(() => {
  callbackCallCount++
  console.log(`Callback execution #${callbackCallCount}`)
  const val = output()
  console.log(`  output() = ${val}`)
})
console.log('Created callback')
console.log('Total callback executions:', callbackCallCount)

console.log('\nChanging input from 1 to 2...')
setInput(2)
console.log('Total callback executions:', callbackCallCount)

console.log('\nChanging input from 2 to 3...')
setInput(3)
console.log('Total callback executions:', callbackCallCount)

console.log('\nExpected: 3 (initial + 2 changes)')
console.log('Actual:', callbackCallCount)
