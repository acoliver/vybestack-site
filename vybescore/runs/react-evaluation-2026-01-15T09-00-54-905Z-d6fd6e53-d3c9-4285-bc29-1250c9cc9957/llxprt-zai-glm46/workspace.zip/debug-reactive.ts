import { createInput, createComputed, createCallback } from './src/index.js'

// Test 1: compute cells can depend on other compute cells
console.log('Test 1: Compute cells dependency')
const [input, setInput] = createInput(1, undefined, { name: 'mainInput' })
const timesTwo = createComputed(() => {
  const val = input()
  console.log('  timesTwo computing with input:', val, 'result:', val * 2)
  return val * 2
}, undefined, undefined, { name: 'timesTwo' })
const timesThirty = createComputed(() => {
  const val = input()
  console.log('  timesThirty computing with input:', val, 'result:', val * 30)
  return val * 30
}, undefined, undefined, { name: 'timesThirty' })
const sum = createComputed(() => {
  const two = timesTwo()
  const thirty = timesThirty()
  console.log('  sum computing: timesTwo=', two, 'timesThirty=', thirty, 'sum=', two + thirty)
  return two + thirty
}, undefined, undefined, { name: 'sum' })

console.log('Initial state:')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 32')

console.log('\nAfter setInput(3):')
setInput(3)
console.log('  input:', input())
console.log('  Calling timesTwo() to see if it updates...')
console.log('  timesTwo:', timesTwo())
console.log('  Calling timesThirty() to see if it updates...')
console.log('  timesThirty:', timesThirty())
console.log('  Calling sum() to see if it updates...')
console.log('  sum:', sum())
console.log('  Expected sum: 96')

console.log('\n\nTest 2: Callbacks fire on update')
const [input2, setInput2] = createInput(1, undefined, { name: 'input2' })
const output = createComputed(() => {
  const val = input2()
  console.log('  output computing with input2:', val, 'result:', val + 1)
  return val + 1
}, undefined, undefined, { name: 'output' })

let value = 0
createCallback(() => {
  console.log('  callback executing, output() =', output())
  value = output()
})

console.log('After callback creation:')
console.log('  value =', value)
console.log('  Expected: 2')

setInput2(3)
console.log('\nAfter setInput2(3):')
console.log('  value =', value)
console.log('  Expected: 4')
