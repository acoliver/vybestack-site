import { createInput, createComputed } from './src/index.js'

console.log('=== Test 1: Simple computed ===')
const [input1] = createInput(5)
const double = createComputed(() => input1() * 2)
console.log('double() =', double())  // Should be 10

console.log('\n=== Test 2: Calling computed multiple times ===')
const [input2] = createInput(3)
const triple = createComputed(() => {
  console.log('  Computing triple, input =', input2())
  return input2() * 3
})
console.log('First call: triple() =', triple())
console.log('Second call: triple() =', triple())
console.log('Third call: triple() =', triple())

console.log('\n=== Test 3: Chained computed ===')
const [input3] = createInput(2)
const double3 = createComputed(() => {
  console.log('  Computing double3, input =', input3())
  return input3() * 2
})
const quadruple = createComputed(() => {
  console.log('  Computing quadruple, double3 =', double3())
  return double3() * 2
})
console.log('quadruple() =', quadruple())
