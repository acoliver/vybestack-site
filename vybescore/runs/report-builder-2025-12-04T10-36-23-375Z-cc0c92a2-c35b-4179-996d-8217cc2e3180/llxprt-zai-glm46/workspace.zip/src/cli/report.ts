#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { exit } from 'node:process';
import type { ReportData, RenderOptions, Format, RenderFunction } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): { inputFile: string; options: CliOptions } {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const inputFile = args[0];
  
  let format: Format | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        exit(1);
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format. Supported formats are: markdown, text');
        exit(1);
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        exit(1);
      }
      output = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    exit(1);
  }

  return { inputFile, options: { format, output, includeTotals } };
}

async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    // Validate the structure
    if (
      typeof data !== 'object' ||
      data === null ||
      !('title' in data) ||
      !('summary' in data) ||
      !('entries' in data)
    ) {
      throw new Error('Invalid JSON structure: missing required fields (title, summary, entries)');
    }

    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid JSON structure: title must be a string');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid JSON structure: summary must be a string');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid JSON structure: entries must be an array');
    }
    
    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (
        typeof entry !== 'object' ||
        entry === null ||
        !('label' in entry) ||
        !('amount' in entry)
      ) {
        throw new Error(`Invalid JSON structure: entry at index ${i} must have label and amount`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid JSON structure: entry.label at index ${i} must be a string`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid JSON structure: entry.amount at index ${i} must be a number`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Unknown error loading file ${filePath}`);
    }
    exit(1);
  }
}

function getRenderer(format: Format): RenderFunction {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error('Error: Unsupported format');
      exit(1);
      // This line will never be reached due to exit(1)
      throw new Error('Unsupported format');
  }
}

async function main(): Promise<void> {
  const { inputFile, options } = parseArguments();
  
  const data = await loadReportData(inputFile);
  
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };
  
  const renderer = getRenderer(options.format);
  const output = renderer(data, renderOptions);
  
  if (options.output) {
    try {
      await writeFile(options.output, output, 'utf-8');
      console.log(`Report written to ${options.output}`);
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing to file ${options.output}: ${error.message}`);
      } else {
        console.error(`Error writing to file ${options.output}`);
      }
      exit(1);
    }
  } else {
    console.log(output);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  exit(1);
});