import type { ReportData, RenderOptions, RenderFunction } from '../types.js';

export const renderText: RenderFunction = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Add title
  lines.push(data.title);

  // Add blank line
  lines.push('');

  // Add summary
  lines.push(data.summary);

  // Add blank line
  lines.push('');

  // Add entries heading
  lines.push('Entries:');

  // Add entries
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }

  // Add totals if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
};