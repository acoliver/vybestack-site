import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('limit');
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // default limit
    expect(response.body.total).toBe(15); // total items in seed
    expect(response.body.hasNext).toBe(true);
  });

  it('handles custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBe(3);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns correct items for page 2', async () => {
    // First get page 1 to see first items
    const page1Response = await request(app).get('/inventory?page=1&limit=5');
    expect(page1Response.status).toBe(200);
    const firstIds = page1Response.body.items.map((item: { id: number }) => item.id);
    
    // Then get page 2
    const page2Response = await request(app).get('/inventory?page=2&limit=5');
    expect(page2Response.status).toBe(200);
    const secondIds = page2Response.body.items.map((item: { id: number }) => item.id);
    
    // Ensure no duplicates
    const allIds = [...firstIds, ...secondIds];
    const uniqueIds = new Set(allIds);
    expect(uniqueIds.size).toBe(allIds.length);
    
    // Ensure page 2 starts with item id 6
    expect(secondIds[0]).toBe(6);
  });

  it('handles last page correctly', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5); // remaining 5 items
    expect(response.body.hasNext).toBe(false);
  });

  it('returns empty items for page beyond last', async () => {
    const response = await request(app).get('/inventory?page=4&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(4);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });

  it('rejects invalid page parameters', async () => {
    // Non-numeric page
    let response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');

    // Negative page
    response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);

    // Zero page
    response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);

    // Page too large
    response = await request(app).get('/inventory?page=1001');
    expect(response.status).toBe(400);
  });

  it('rejects invalid limit parameters', async () => {
    // Non-numeric limit
    let response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');

    // Negative limit
    response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);

    // Zero limit
    response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);

    // Limit too large
    response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
  });

  it('accepts valid boundary values', async () => {
    // Minimum valid values
    let response = await request(app).get('/inventory?page=1&limit=1');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(1);

    // Maximum valid values
    response = await request(app).get('/inventory?page=1000&limit=100');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1000);
    expect(response.body.limit).toBe(100);
  });
});
