/**
 * Base64 implementation compliant with RFC 4648.
 * Uses the standard Base64 alphabet: A-Z, a-z, 0-9, +, /
 * Includes required padding with = characters.
 */

/**
 * Validate that input is valid Base64 format.
 * Contains only Base64 characters and has valid padding.
 */
function isValidBase64(input: string): boolean {
  // Empty string is considered invalid
  if (!input) {
    return false;
  }
  
  // Base64 regex: only A-Z, a-z, 0-9, +, /, and = for padding
  // = only allowed at the end and max 2 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Total length including padding must be divisible by 4
  if (input.length % 4 !== 0) {
    return false;
  }
  
  // Check padding validity
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    // No padding and length is divisible by 4 - valid
    return true;
  }
  
  // Padding exists: must be at the end
  const padding = input.substring(paddingIndex);
  // Can only have 1 or 2 = chars at the end
  // And no non-padding characters should appear after the first =
  return padding.length <= 2 && padding.length > 0;
}

/**
 * Encode plain text to Base64.
 * Uses standard RFC 4648 Base64 with proper padding.
 */
export function encode(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('Input must be a string');
  }
  
  try {
    // Use standard 'base64' encoding, not 'base64url'
    const base64 = Buffer.from(input, 'utf8').toString('base64');
    return base64;
  } catch (error) {
    throw new Error('Failed to encode input to Base64');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input and validates format.
 */
export function decode(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('Input must be a string');
  }
  
  // Validate the Base64 input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input format');
  }
  
  try {
    // Use standard 'base64' decoding
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
