// Test for callback dependency tracking
const { createInput, createComputed, createCallback } = require('./src/index.ts');

console.log('=== Simple test of callback dependency tracking ===');

const [input, setInput] = createInput(1);
const output = createComputed(() => {
  console.log('Computing output with input:', input());
  return input() + 1;
});
let value = 0;

console.log(`Initial input: ${input()}`);
console.log(`Initial output: ${output()}, output.observers.size=${output._observers ? output._observers.size : 'undefined'}`);

const unsubscribe = createCallback(() => {
  console.log('Callback executed');
  value = output();
});

console.log(`After callback creation, value: ${value}`);

setInput(3);

console.log(`After setInput(3), value: ${value}, expected: 4`);
console.log(`Current input: ${input()}, current output: ${output()}`);