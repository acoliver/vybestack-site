// Simplified reactive implementation to test callback scenario

// Global state to track the current observer
let activeObserver = null;

function getActiveObserver() {
  return activeObserver;
}

function setActiveObserver(observer) {
  activeObserver = observer;
}

function updateObserver(observer) {
  const prev = activeObserver;
  activeObserver = observer;
  try {
    // In test files, the callback function doesn't expect any arguments and returns nothing
    observer.updateFn();
  } finally {
    activeObserver = prev;
  }
}

// Input
function createInput(initialValue) {
  const observers = new Set();
  let value = initialValue;
  
  const getter = () => {
    const observer = getActiveObserver();
    if (observer) {
      observers.add(observer);
      
      // Register ourselves with the observer for cleanup
      if (!observer.observers) observer.observers = new Set();
      observer.observers.add({ observers });
    }
    return value;
  };
  
  const setter = (newValue) => {
    if (value !== newValue) {
      value = newValue;
      
      const observersToNotify = Array.from(observers);
      for (const observer of observersToNotify) {
        updateObserver(observer);
      }
    }
    return value;
  };
  
  return [getter, setter];
}

// Computed
function createComputed(computeFn) {
  let cachedValue;
  
  const observer = {
    updateFn: () => {
      const result = computeFn();
      cachedValue = result;
    },
    observers: new Set()
  };
  
  const getter = () => {
    const active = getActiveObserver();
    if (active) {
      // When this computed is accessed by another observer, register the dependency
      active.observers.add(observer);
      observer.observers.add(active);
    }
    
    // Recompute value
    updateObserver(observer);
    
    return cachedValue;
  };
  
  return getter;
}

// Callback
function createCallback(callbackFn) {
  const observer = {
    updateFn: () => {
      // Just execute the callback function
      callbackFn();
    },
    observers: new Set()
  };
  
  // Set this observer as active to track dependencies
  setActiveObserver(observer);
  
  // Execute the callback to track dependencies but modify the function
  // so nothing actually happens during tracking
  const originalFn = observer.updateFn;
  observer.updateFn = () => {}; // No-op for dependency tracking
  
  try {
    // To track dependencies, we need to access the reactive values this callback depends on
    // Since we don't know them beforehand, we'll do it differently
  } finally {
    // Restore the real function
    observer.updateFn = originalFn;
    setActiveObserver(null);
  }
  
  const unsubscribe = () => {
    // Cleanup logic
  };
  
  return unsubscribe;
}

// Test
console.log("=== Testing compute cells fire callbacks ===");

const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;

console.log(`Initial input: ${input()}`);
console.log(`Initial output: ${output()}`);

// Need to establish the dependency manually
setActiveObserver({ observers: new Set() });
const callbackObserver = getActiveObserver();
output(); // This will register output as a dependency of callbackObserver
callbackObserver.observers.add(output);

const unsubscribe = createCallback(() => {
  console.log(`Callback executed, output() = ${output()}`);
  value = output();
});

console.log(`After callback creation, value: ${value}`);

setInput(3);

console.log(`After setInput(3), value: ${value}, expected: 4`);
console.log(`Current input: ${input()}, current output: ${output()}`);