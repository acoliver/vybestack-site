import { createInput, createComputed, createCallback } from './src/index.js';

console.log('=== Testing compute cells fire callbacks ===');

// Test case: compute cells fire callbacks
const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;

console.log(`Initial input: ${input()}`);
console.log(`Initial output: ${output()}`);

const unsubscribe = createCallback(() => {
  console.log(`Callback called, setting value to ${output()}`);
  value = output();
});

console.log(`After callback creation, value: ${value}`);

setInput(3);

console.log(`After setInput(3), value: ${value}, expected: 4`);
console.log(`Current input: ${input()}, current output: ${output()}`);

unsubscribe();