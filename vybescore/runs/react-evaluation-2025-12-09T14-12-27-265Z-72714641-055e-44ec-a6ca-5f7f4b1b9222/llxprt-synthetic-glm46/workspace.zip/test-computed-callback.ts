// Test file to debug computed-callback interaction
import { createInput, createComputed, createCallback } from './src/index.js'

// Test 1: compute cells fire callbacks
console.log('Test 1: compute cells fire callbacks')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0

console.log('Initial value:', value)
createCallback(() => {
  console.log('Callback triggered with output:', output())
  value = output()
})
console.log('After callback creation, value:', value)

console.log('Setting input to 3...')
setInput(3)

console.log('Final value:', value)
console.log('Expected: 4')
console.log('Actual:', value)
console.log('Pass?', value === 4)

console.log('\n' + '='.repeat(20) + '\n')

// Test 2: callbacks can be added and removed
console.log('Test 2: callbacks can be added and removed')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

    const values1: number[] = []
    const unsubscribe1 = createCallback(() => values1.push(output()))
    const values2: number[] = []
createCallback(() => values2.push(output2()))

console.log('Setting input2 to 31...')
setInput2(31)
console.log('Before unsubscribe - values1:', values1, 'values2:', values2)

console.log('Unsubscribing callback 1...')
unsubscribe1()

console.log('Setting input2 to 41...')
setInput2(41)
console.log('After unsubscribe - values1:', values1, 'values2:', values2)

console.log('values1.length > 0 ?', values1.length > 0)
console.log('values2.length > values1.length ?', values2.length > values1.length)
console.log('Pass?', values1.length > 0 && values2.length > values1.length)