// Super simple test to understand the issue
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Creating input with value 1 ===')
const [input, setInput] = createInput(1)
console.log('input() =', input())

console.log('\n=== Creating computed output = input() + 1 ===')
const output = createComputed(() => {
  console.log('  Computed function running, input() =', input())
  return input() + 1
})
console.log('output() =', output())

console.log('\n=== Creating callback that sets value = output() ===')
let value = 0
createCallback(() => {
  console.log('  Callback running, output() =', output())
  value = output()
})

console.log('\nAfter creating callback, value =', value)

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\nAfter setting input, value =', value)
console.log('Expected 4, got', value)