/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (_prevValue?: T) => {
      // Clear previous dependencies
      if (o.dependencies) {
        o.dependencies.clear()
      } else {
        o.dependencies = new Set()
      }
      
      // Set this computed as the active observer to track our dependencies
      setActiveObserver(o)
      
      try {
        // Compute the new value
        const newValue = updateFn(o.value)
        o.value = newValue
        
        // Notify all dependent observers
        if (o.observers && o.observers.size > 0) {
          const observersToNotify = Array.from(o.observers)
          for (const dependentObserver of observersToNotify) {
            if (dependentObserver.updateFn && typeof dependentObserver.updateFn === 'function') {
              updateObserver(dependentObserver)
            }
          }
        }
        
        return newValue
      } finally {
        // Reset active observer
        setActiveObserver(undefined)
      }
    }
  }
  
  // Initialize the value and track dependencies
  if (value !== undefined) {
    o.value = value
  } else {
    // Track dependencies during initialization
    setActiveObserver(o)
    try {
      if (o.dependencies) {
        o.dependencies.clear()
      } else {
        o.dependencies = new Set()
      }
      o.value = updateFn()
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add the active observer as a subscriber to this computed
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(observer)
      
      // Track this computed as a dependency of the observer
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(o)
    }
    
    return o.value as T
  }
  
  return getter
}