/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Store the real update function
  const realUpdateFn = updateFn
  
  // Track whether this is the first execution (dependency tracking) or subsequent execution
  let isFirstExecution = true
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevVal?: T) => {
      // On first execution, skip the actual callback to only track dependencies
      if (isFirstExecution) {
        isFirstExecution = false
        
        // Set this callback as the active observer to track dependencies
        setActiveObserver(observer)
        
        try {
          // Clear previous dependencies
          if (observer.dependencies) {
            observer.dependencies.clear()
          } else {
            observer.dependencies = new Set()
          }
          
          // Execute the function to track dependencies but ignore its result
          realUpdateFn(prevVal)
        } finally {
          // Reset active observer
          setActiveObserver(undefined)
        }
        
        return value as T
      } else {
        // On subsequent executions, actually execute the callback
        try {
          // Clear previous dependencies
          if (observer.dependencies) {
            observer.dependencies.clear()
          } else {
            observer.dependencies = new Set()
          }
          
          // Set this callback as active observer to track dependencies
          setActiveObserver(observer)
          
          // Execute the function
          return realUpdateFn(prevVal)
        } finally {
          // Reset active observer
          setActiveObserver(undefined)
        }
      }
    }
  }
  
  // Initialize the observer to track dependencies
  updateObserver(observer)
  
  // Return an unsubscribe function
  const unsubscribe: UnsubscribeFn = () => {
    // Remove this observer from all its dependencies
    if (observer.dependencies) {
      for (const dependency of observer.dependencies) {
        // Cast to Subject type to access observers set
        const subject = dependency as { observers?: Set<Observer<unknown>> }
        if (subject.observers) {
          subject.observers.delete(observer as Observer<unknown>)
        }
      }
      observer.dependencies.clear()
    }
    
    // Remove any observers that depend on this callback
    if (observer.observers) {
      observer.observers.clear()
    }
  }
  
  return unsubscribe
}