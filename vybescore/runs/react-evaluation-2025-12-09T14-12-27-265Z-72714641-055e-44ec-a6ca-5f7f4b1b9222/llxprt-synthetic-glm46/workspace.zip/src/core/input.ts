/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer as a subscriber to this input
      if (!s.observers) {
        s.observers = new Set()
      }
      s.observers.add(observer)
      
      // Track this input as a dependency of the observer
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (newValue) => {
    // Default equality is strict === unless custom function provided
    const isEqual = typeof equal === 'function'
      ? equal
      : equal === false
        ? () => false
        : (a: T, b: T) => a === b
    
    if (!isEqual(s.value, newValue)) {
      s.value = newValue
      
      // Create a snapshot of current observers to avoid issues with concurrent modifications
      const observersToNotify = Array.from(s.observers || [])
      
      // Notify all registered observers
      for (const observer of observersToNotify) {
        // Check if the observer has a valid updateFn before calling updateObserver
        if (observer.updateFn && typeof observer.updateFn === 'function') {
          updateObserver(observer)
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}