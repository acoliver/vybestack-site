// Reactive programming system - proper implementation

// Global state to track the current observer
let currentObserver = null;

// Input function - creates a reactive state
function createInput(initialValue) {
  let value = initialValue;
  const observers = new Set();
  
  const getter = () => {
    // Track this input as a dependency of the current observer
    if (currentObserver) {
      observers.add(currentObserver);
    }
    return value;
  };
  
  const setter = (newValue) => {
    if (value !== newValue) {
      value = newValue;
      
      // Copy observers to a new array to prevent modification during iteration
      const observersToNotify = Array.from(observers);
      
      // Notify all observers that this value changed
      observersToNotify.forEach(observer => {
        const prevObserver = currentObserver;
        currentObserver = observer;
        try {
          observer();
        } finally {
          currentObserver = prevObserver;
        }
      });
    }
    return value;
  };
  
  return [getter, setter];
}

// Computed function - creates a derived value
function createComputed(computeFn) {
  let cachedValue;
  let hasValue = false;
  const dependencies = new Set();
  
  // Create an observer function
  const observer = () => {
    // Clear old dependencies
    dependencies.clear();
    
    // Set ourselves as the current observer to track dependencies
    const prevObserver = currentObserver;
    currentObserver = observer;
    
    try {
      // Run computation to collect dependencies and get result
      cachedValue = computeFn();
      hasValue = true;
      return cachedValue;
    } finally {
      currentObserver = prevObserver;
    }
  };
  
  // Return a getter that recomputes when dependencies change
  return () => {
    if (!hasValue) {
      // First access - compute and establish dependencies
      const prevObserver = currentObserver;
      currentObserver = observer;
      
      try {
        cachedValue = computeFn();
        hasValue = true;
      } finally {
        currentObserver = prevObserver;
      }
    }
    
    return cachedValue;
  };
}

// Callback function - runs side effects when dependencies change
function createCallback(callbackFn) {
  let dependencies = new Set();
  let hasInitialized = false;
  
  // Create observer function
  const observer = () => {
    if (!hasInitialized) {
      // First call: establish dependencies without running the effect
      hasInitialized = true;
      
      // Override callback temporarily to just track dependencies
      const originalCallback = callbackFn;
      callbackFn = () => {
        // Just track dependencies but don't do anything
      };
      
      try {
        // Run the overridden callback to establish dependencies
        const prevObserver = currentObserver;
        currentObserver = observer;
        
        try {
          originalCallback();
        } finally {
          currentObserver = prevObserver;
        }
      } finally {
        // Restore the original callback
        callbackFn = originalCallback;
      }
      return;
    }
    
    // After initialization, run the actual callback
    callbackFn();
  };
  
  // Initialize the observer and establish dependencies
  observer();
  
  return () => {
    // Unsubscribe - remove observer from dependencies
    dependencies.clear();
  };
}

// Test
const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;

const callback = createCallback(() => {
  console.log("Callback executed, output() =", output());
  value = output();
});

console.log("Initial value:", value); // Should be 0
console.log("Initial input:", input()); // Should be 1
console.log("Initial output:", output()); // Should be 2

setInput(3);
console.log("After setInput(3), value:", value); // Should be 4
console.log("After setInput(3), input:", input()); // Should be 3
console.log("After setInput(3), output:", output()); // Should be 4