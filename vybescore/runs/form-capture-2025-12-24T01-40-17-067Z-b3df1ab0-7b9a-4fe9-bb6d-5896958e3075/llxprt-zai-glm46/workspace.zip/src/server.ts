import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initDatabase, closeDatabase, insertSubmission, type FormData } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(process.cwd(), 'data/submissions.sqlite');

// Initialize database
import type { Database } from './sql-types.js';
let db: Database;

const app = express();
const PORT = process.env.PORT ?? 3535;

// Middleware
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

async function startServer() {
  try {
    db = await initDatabase(DB_PATH);
    console.log('Database initialized successfully');

    app.get('/', (req, res) => {
      res.render('index', {
        errors: {},
        data: {},
        success: false
      });
    });

    app.post('/submit', async (req, res) => {
      const formData: FormData = req.body;
      const errors = validateFormData(formData);

      if (Object.keys(errors).length > 0) {
        return res.status(400).render('index', {
          errors,
          data: formData,
          success: false
        });
      }

      try {
        await insertSubmission(db, formData);
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Failed to insert submission:', error);
        res.status(500).render('index', {
          errors: { _general: 'Failed to save your information. Please try again.' },
          data: formData,
          success: false
        });
      }
    });

    app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });

    const server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });

    // Graceful shutdown
    const shutdown = async () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        console.log('HTTP server closed');
        closeDatabase();
        process.exit(0);
      });
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

function validateFormData(data: FormData | Record<string, unknown>): Record<string, string> {
  const errors: Record<string, string> = {};

  // Helper to safely get string value - handle both FormData and raw parsed objects
  const getVal = (val: unknown): string => {
    if (val === null || val === undefined) return '';
    return String(val);
  };

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    const val = getVal(data[field]);
    if (!val || val.trim() === '') {
      errors[field] = `${formatFieldName(field)} is required`;
    }
  }

  // Only do format validation if value exists
  const email = getVal(data.email);
  if (email && email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      errors.email = 'Please enter a valid email';
    }
  }

  const phone = getVal(data.phone);
  if (phone && phone.trim()) {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (!phoneRegex.test(phone.trim()) || phone.trim().replace(/[^\d]/g, '').length < 7) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  const postalCode = getVal(data.postalCode);
  if (postalCode && postalCode.trim()) {
    const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalCodeRegex.test(postalCode.trim())) {
      errors.postalCode = 'Please enter a valid postal/zip code';
    }
  }

  return errors;
}

function formatFieldName(field: string): string {
  // Convert camelCase to readable format
  return field
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, (str) => str.toUpperCase())
    .trim();
}

startServer();
