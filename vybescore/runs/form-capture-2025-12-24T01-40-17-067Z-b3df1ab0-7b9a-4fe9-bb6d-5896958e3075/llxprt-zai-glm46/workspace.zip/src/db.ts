import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Database } from './sql-types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Use dynamic import for sql.js to avoid issues
let dbInstance: Database | null = null;

export async function initDatabase(dbPath: string): Promise<Database> {
  const SQL = await import('sql.js');
  const SqlJs = await SQL.default();

  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  let db: Database;
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SqlJs.Database(buffer);
    console.log(`Loaded existing database from ${dbPath}`);
  } else {
    db = new SqlJs.Database();
    console.log(`Created new database at ${dbPath}`);
    // Write new database to disk immediately
    const buffer = db.export();
    fs.writeFileSync(dbPath, Buffer.from(buffer));
  }

  // Initialize schema
  const schemaPath = path.join(__dirname, '../db/schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf-8');
  db.run(schema);
  console.log('Database schema initialized');

  // Write to disk after schema initialization
  const buffer = db.export();
  fs.writeFileSync(dbPath, Buffer.from(buffer));

  dbInstance = db;
  return db;
}

export async function insertSubmission(db: Database, data: FormData): Promise<void> {
  const stmt = db.prepare(
    `INSERT INTO submissions (
      first_name, last_name, street_address, city,
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );

  stmt.run([
    data.firstName.trim(),
    data.lastName.trim(),
    data.streetAddress.trim(),
    data.city.trim(),
    data.stateProvince.trim(),
    data.postalCode.trim(),
    data.country.trim(),
    data.email.trim(),
    data.phone.trim()
  ]);

  stmt.free();

  // Export database to disk
  if (dbInstance) {
    const dataPath = path.join(__dirname, '../data/submissions.sqlite');
    const buffer = dbInstance.export();
    fs.writeFileSync(dataPath, Buffer.from(buffer));
  }
}

export function closeDatabase(): void {
  if (dbInstance) {
    try {
      dbInstance.close();
      dbInstance = null;
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
}
