declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  type SqlValue = string | number | null | Uint8Array;

  export class Database {
    constructor(data?: ArrayLike<number> | Buffer | null);

    run(sql: string, params?: SqlValue[]): RunResult;
    exec(sql: string): ExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;

    each(sql: string, callback: (row: Record<string, SqlValue>) => void, done?: () => void): void;
  }

  export interface RunResult {
    columns: string[];
  }

  export interface ExecResult {
    columns: string[];
    values: SqlValue[][];
  }

  export class Statement {
    run(params?: SqlValue[]): RunResult;
    get(params?: SqlValue[]): Record<string, SqlValue> | undefined;
    all(params?: SqlValue[]): Record<string, SqlValue>[];
    bind(values?: SqlValue[]): boolean;
    free(): void;
  }

  // The default export is a function that returns a promise
  export default function initSqlJs(config?: Record<string, unknown>): Promise<SqlJsStatic>;
}
