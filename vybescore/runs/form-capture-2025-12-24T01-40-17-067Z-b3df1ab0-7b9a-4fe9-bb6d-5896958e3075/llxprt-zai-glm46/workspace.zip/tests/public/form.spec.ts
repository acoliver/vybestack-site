import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { spawn } from 'node:child_process';
import { readFileSync, unlinkSync, existsSync } from 'node:fs';
import path from 'node:path';

const SERVER_PATH = path.join(process.cwd(), 'dist/server.js');
const DB_PATH = path.join(process.cwd(), 'data/submissions.sqlite');
let server: ReturnType<typeof spawn>;

describe('Form Capture App', () => {
  beforeAll(async () => {
    // Clean up any existing database
    if (existsSync(DB_PATH)) {
      unlinkSync(DB_PATH);
    }

    // Start the server
    server = spawn('node', [SERVER_PATH], {
      env: { ...process.env, PORT: '3535' },
      stdio: 'pipe'
    });

    // Wait for server to start
    await new Promise<void>((resolve) => {
      server.stdout?.on('data', (data) => {
        if (data.toString().includes('Server listening')) {
          resolve();
        }
      });
      // Timeout fallback
      setTimeout(() => resolve(), 3000);
    });
  });

  afterAll(() => {
    if (server) {
      server.kill('SIGTERM');
    }
  });

  describe('GET /', () => {
    it('should render the form page', async () => {
      const response = await request('http://localhost:3535')
        .get('/')
        .expect(200);

      expect(response.text).toContain('International Contact Form');
      expect(response.text).toContain('firstName');
      expect(response.text).toContain('lastName');
      expect(response.text).toContain('email');
      expect(response.text).toContain('phone');
    });

    it('should have a form with POST method to /submit', async () => {
      const response = await request('http://localhost:3535')
        .get('/')
        .expect(200);

      expect(response.text).toContain('method="POST"');
      expect(response.text).toContain('action="/submit"');
    });

    it('should include styles.css', async () => {
      const response = await request('http://localhost:3535')
        .get('/')
        .expect(200);

      expect(response.text).toContain('/styles.css');
    });
  });

  describe('POST /submit', () => {
    const validFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    it('should accept valid form data and redirect to thank-you', async () => {
      const response = await request('http://localhost:3535')
        .post('/submit')
        .send(validFormData)
        .expect(302);

      expect(response.headers.location).toBe('/thank-you');
    });

    it('should reject empty required fields', async () => {
      const response = await request('http://localhost:3535')
        .post('/submit')
        .send({
          firstName: '',
          lastName: '',
          streetAddress: '',
          city: '',
          stateProvince: '',
          postalCode: '',
          country: '',
          email: '',
          phone: ''
        })
        .expect(400);

      expect(response.text).toContain('is required');
    });

    it('should reject invalid email format', async () => {
      const response = await request('http://localhost:3535')
        .post('/submit')
        .send({
          ...validFormData,
          email: 'invalid-email'
        })
        .expect(400);

      expect(response.text).toContain('valid email');
    });

    it('should accept international phone formats', async () => {
      // Test UK format
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          ...validFormData,
          phone: '+44 20 7946 0958'
        })
        .expect(302);

      // Test Argentine format
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          ...validFormData,
          firstName: 'Jane',
          email: 'jane@example.com',
          phone: '+54 9 11 1234-5678'
        })
        .expect(302);
    });

    it('should accept various postal code formats', async () => {
      // UK format
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          ...validFormData,
          firstName: 'Alice',
          email: 'alice@example.com',
          postalCode: 'SW1A 1AA'
        })
        .expect(302);

      // Argentine format
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          ...validFormData,
          firstName: 'Bob',
          email: 'bob@example.com',
          postalCode: 'C1000'
        })
        .expect(302);

      // US format
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          ...validFormData,
          firstName: 'Charlie',
          email: 'charlie@example.com',
          postalCode: '12345'
        })
        .expect(302);
    });

    it('should preserve entered values on validation error', async () => {
      const response = await request('http://localhost:3535')
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          email: 'invalid',
          // Missing other required fields
        })
        .expect(400);

      expect(response.text).toContain('Test');
      expect(response.text).toContain('User');
    });
  });

  describe('GET /thank-you', () => {
    it('should render the thank you page', async () => {
      const response = await request('http://localhost:3535')
        .get('/thank-you')
        .expect(200);

      expect(response.text).toContain('Thank You');
      expect(response.text).toContain('stranger on the internet');
      expect(response.text).toContain('spam');
    });

    it('should include a link back to the form', async () => {
      const response = await request('http://localhost:3535')
        .get('/thank-you')
        .expect(200);

      expect(response.text).toContain('href="/"');
    });
  });

  describe('GET /styles.css', () => {
    it('should serve the stylesheet', async () => {
      const response = await request('http://localhost:3535')
        .get('/styles.css')
        .expect('Content-Type', /css/)
        .expect(200);

      expect(response.text.length).toBeGreaterThan(0);
    });
  });

  describe('Database persistence', () => {
    it('should create the database file', () => {
      expect(existsSync(DB_PATH)).toBe(true);
    });

    it('should persist submissions across requests', async () => {
      const uniqueEmail = `test-${Date.now()}@example.com`;
      
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          firstName: 'Persistence',
          lastName: 'Test',
          streetAddress: '456 Data Street',
          city: 'Database City',
          stateProvince: 'Persistence State',
          postalCode: 'DB123',
          country: 'Data Land',
          email: uniqueEmail,
          phone: '+1 555-0123'
        })
        .expect(302);

      // File should exist and have content
      expect(existsSync(DB_PATH)).toBe(true);
      const dbContent = readFileSync(DB_PATH);
      expect(dbContent.length).toBeGreaterThan(0);
    });
  });
});
