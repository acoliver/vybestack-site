/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  // Use word boundary to ensure we match whole words, not substrings
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefixPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const results = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerPrefix = prefix.toLowerCase();
    
    // Check if the word (without the prefix) is in exceptions
    const wordWithoutPrefix = lowerWord.startsWith(lowerPrefix) ? 
      lowerWord.substring(lowerPrefix.length) : lowerWord;
    
    return !exceptions.some(exception => 
      exception.toLowerCase() === wordWithoutPrefix || exception.toLowerCase() === lowerWord
    );
  });
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences of a token only when it appears after a digit and not at the beginning of the string
  // Use lookaheads/lookbehinds as required
  
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern explanation:
  // (?<!^) - negative lookbehind to ensure we're not at the very start
  // (?<=\d) - positive lookbehind to ensure preceded by a digit
  // This finds the token portion, but we need to return digit+token
  
  // Find all matches using our pattern
  const matches = [];
  let match;
  
  const regex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'gi');
  
  // Use exec to get match positions
  while ((match = regex.exec(text)) !== null) {
    const startPos = match.index;
    
    // The position before should be a digit (from our lookbehind)
    if (startPos > 0 && /\d/.test(text[startPos - 1])) {
      const digitPos = startPos - 1;
      // Extract the complete match: digit + token
      const completeMatch = text.substring(digitPos, digitPos + 1 + token.length);
      matches.push(completeMatch);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password strength validation
  // Requirements:
  // - At least 10 characters
  // - One uppercase letter
  // - One lowercase letter
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., "abab" should fail)
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This pattern looks for any character followed by the same character
  // repeated at least 3 times total (e.g., "aaa", "111", "bbb")
  if (/(.)\1\1/.test(value)) {
    return false;
  }
  
  // Check for alternating repeated patterns like "abab", "1212", etc.
  // Look for 2-character sequences that repeat immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  // Additional check for longer repeated patterns
  // Pattern like "abcabc" should also fail
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger
  // Requirements:
  // - Detect IPv6 addresses (including shorthand ::)
  // - Ensure IPv4 addresses do not trigger a positive result
  
  // First, check if this looks like an IPv4 address to quickly exclude it
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern breakdown:
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  // e.g., 2001:0db8:0000:0000:0000:ff00:0042:8329
  // Shorthand: :: for consecutive zero groups
  // e.g., 2001:db8::8a2e:370:7334
  
  // Pattern for standard IPv6 format
  const standardIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Additional patterns for various IPv6 representations
  // Pattern with port: [2001:db8::1]:80
  const portIPv6 = /^\[[0-9a-fA-F:]+\]:\d{1,5}$/;
  
  // Check if this could be IPv6 by looking for colons and hex digits
  if (!/:/.test(value) || !/[0-9a-fA-F]/.test(value)) {
    return false;
  }
  
  // Exclude if it looks too much like IPv4 (contains dots with digits)
  if (/\d+\.\d+\.\d+\.\d+/.test(value)) {
    return false;
  }
  
  // Test against various IPv6 patterns
  if (standardIPv6.test(value)) {
    return true;
  }
  
  // Check for shorthand notation (::)
  if (value.includes('::')) {
    // Count the number of colon-separated groups
    const parts = value.split('::');
    if (parts.length === 2) {
      // Valid shorthand: should have at least one part and the total groups should be 8 or less
      const leftPart = parts[0].length > 0 ? parts[0].split(':').filter(p => p.length > 0) : [];
      const rightPart = parts[1].length > 0 ? parts[1].split(':').filter(p => p.length > 0) : [];
      
      // Total groups should be <= 8 (each :: represents missing groups)
      const totalGroups = leftPart.length + rightPart.length;
      if (totalGroups <= 8) {
        return true;
      }
    }
  }
  
  // Check for bracketed IPv6 [::1] or [2001:db8::1]
  if (portIPv6.test(value)) {
    return true;
  }
  
  // Additional check for percent-encoded IPv6
  const percentIPv6 = /%[0-9a-fA-F]{2}/;
  if (percentIPv6.test(value) && /:/.test(value)) {
    return true;
  }
  
  return false;
}
