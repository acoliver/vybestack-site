/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first character of each sentence
  // Requirements:
  // - Capitalize first character after .?! 
  // - Insert exactly one space between sentences
  // - Collapse extra spaces sensibly
  // - Leave abbreviations intact when possible
  
  // First, normalize spacing by removing extra spaces between words
  let normalized = text.replace(/\s+/g, ' ');
  
  // Capitalize the first character of the entire text
  normalized = normalized.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Find sentence boundaries and capitalize first letters after them
  // This pattern looks for sentence ending punctuation followed by spaces, then a lowercase letter
  normalized = normalized.replace(/([.!?])\s+([a-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Extract URLs from text
  // Return URLs without trailing punctuation
  
  // Simple but comprehensive URL pattern
  const urlPattern = /\b(?:https?|ftp):\/\/[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  const cleanUrls = matches.map(url => {
    return url.replace(/[.,!?;:'"`)]+$/g, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  
  // Use global replacement to change http:// to https://
  // The regex specifically matches http:// (not https://) to avoid double upgrading
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Rewrite http://example.com/... URLs
  // Requirements:
  // - Always upgrade http:// to https://
  // - When path begins with /docs/, rewrite host to docs.example.com
  // - Skip host rewrite for dynamic paths or legacy extensions
  // - Preserve nested paths
  
  // Pattern to match http:// URLs with their components
  // Captures: protocol (http), domain (example.com), and path
  const httpUrlPattern = /\b(http):\/\/([^/s]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    let newUrl = 'https://';
    newUrl += domain;
    
    // Check if path exists and begins with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|&|=)|(cgi-bin)/i.test(path);
      const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      // Only rewrite host if no dynamic hints and no legacy extensions
      if (!hasDynamicHints && !hasLegacyExtensions) {
        newUrl = 'https://docs.' + domain;
      }
    }
    
    // Preserve the path as-is (including nested paths like /docs/api/v1)
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Extract year from mm/dd/yyyy strings
  // Return 'N/A' for invalid format or invalid month/day
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 2024 is leap year
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Additional check for February 29 (leap year validation)
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Leap year validation: divisible by 4, but not by 100 unless also divisible by 400
    if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
