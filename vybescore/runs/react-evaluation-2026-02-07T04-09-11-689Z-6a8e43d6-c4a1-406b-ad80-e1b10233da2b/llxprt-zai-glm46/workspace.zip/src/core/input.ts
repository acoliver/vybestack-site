/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prev = s.value
    s.value = nextValue
    if (s.observer && prev !== nextValue) {
      const obs = s.observer as Observer<unknown>
      updateObserver(obs)
      
      // Propagate to nested observers
      if ('observers' in obs && obs.observers) {
        for (const subObs of obs.observers) {
          const nestedObs = subObs as Observer<unknown>
          updateObserver(nestedObs)
        }
      }
    }
    return s.value
  }

  return [read, write]
}


