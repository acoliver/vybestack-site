/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: [],
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register the current observer as dependent on this computed
      if (!o.observers) o.observers = []
      if (!o.observers.includes(observer)) {
        o.observers.push(observer)
      }
    }
    
    // Compute the value
    updateObserver(o)
    return o.value!
  }
  
  return read
}
