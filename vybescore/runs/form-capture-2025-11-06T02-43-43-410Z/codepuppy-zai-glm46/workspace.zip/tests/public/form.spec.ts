import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, gracefulShutdown } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Wait a bit for server to initialize
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(async () => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Gracefully shutdown server
  gracefulShutdown();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check that all required fields are present
    const expectedFields = [
      'firstName', 'lastName', 'streetAddress', 'city',
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];
    
    for (const field of expectedFields) {
      expect($(`input[name="${field}"]`)).toHaveLength(1);
    }
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    // Submit form
    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302);
    
    // Should redirect to thank-you page
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=John/);
    
    // Check that database file was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Optional: Read and verify database content (simple check)
    if (fs.existsSync(dbPath)) {
      const dbStats = fs.statSync(dbPath);
      expect(dbStats.size).toBeGreaterThan(0);
    }
  });

  it('shows thank-you page with name', async () => {
    const response = await request(app)
      .get('/thank-you?firstName=Jane')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Jane');
    expect($('body').text()).toContain('stranger on the internet');
  });
});
