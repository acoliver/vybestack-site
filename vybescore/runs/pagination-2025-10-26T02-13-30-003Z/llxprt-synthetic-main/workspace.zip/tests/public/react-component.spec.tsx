import { render, screen, fireEvent } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import { InventoryView } from '../../src/client/InventoryView';
import * as UseInventory from '../../src/client/useInventory';

// Mock fetch for API calls
global.fetch = vi.fn();

// Create test app and database to get accurate mock data
async function getTestServerData(page: number, limit: number) {
  const db = await createDatabase();
  await createApp(db);
  
  // Simulate the same API endpoint logic for testing
  return {
    page,
    limit,
    total: 15, // We know from seed.sql
    items: Array.from({ length: Math.min(limit, 15 - (page - 1) * limit) }, (_, i) => ({
      id: (page - 1) * limit + i + 1,
      name: `Item ${(page - 1) * limit + i + 1}`,
      sku: `SKU-${(page - 1) * limit + i + 1}`,
      priceCents: ((page - 1) * limit + i + 1) * 100,
      createdAt: new Date().toISOString()
    })),
    hasNext: (page * limit) < 15
  };
}

// Mock the useInventory hook
vi.mock('../../src/client/useInventory', () => ({
  useInventory: vi.fn()
}));

const mockUseInventory = vi.mocked(UseInventory.useInventory);

describe('InventoryView React Component', () => {
  it('displays loading state', () => {
    mockUseInventory.mockReturnValue({
      status: 'loading',
      data: null,
      error: null
    });

    render(<InventoryView />);
    expect(screen.getByText('Loading inventory…')).toBeInTheDocument();
  });

  it('displays error state', () => {
    mockUseInventory.mockReturnValue({
      status: 'error',
      data: null,
      error: 'Server error'
    });

    render(<InventoryView />);
    expect(screen.getByRole('alert')).toHaveTextContent('Server error');
  });

  it('displays inventory items and pagination controls', async () => {
    const mockData = {
      page: 1,
      limit: 5,
      total: 15,
      items: [
        { id: 1, name: 'Notebook', sku: 'NB-001', priceCents: 799, createdAt: '2024-01-01T09:00:00.000Z' },
        { id: 2, name: 'Mechanical Keyboard', sku: 'KB-235', priceCents: 12999, createdAt: '2024-01-02T12:30:00.000Z' },
        { id: 3, name: 'Wireless Mouse', sku: 'MS-984', priceCents: 4999, createdAt: '2024-01-03T08:15:00.000Z' },
        { id: 4, name: 'Laptop Stand', sku: 'LP-742', priceCents: 3599, createdAt: '2024-01-04T10:05:00.000Z' },
        { id: 5, name: 'Monitor 24"', sku: 'MN-240', priceCents: 18999, createdAt: '2024-01-04T15:45:00.000Z' }
      ],
      hasNext: true
    };

    mockUseInventory.mockReturnValue({
      status: 'ready',
      data: mockData,
      error: null
    });

    render(<InventoryView />);
    
    // Check header
    expect(screen.getByText('Inventory')).toBeInTheDocument();
    
    // Check items range
    expect(screen.getByText('Showing 1-5 of 15 items')).toBeInTheDocument();
    
    // Check items
    mockData.items.forEach(item => {
      expect(screen.getByText(`${item.name} (${item.sku}) – ${(item.priceCents / 100).toFixed(2)}`)).toBeInTheDocument();
    });
    
    // Check pagination controls
    expect(screen.getByText('Previous')).toBeDisabled();
    expect(screen.getByText('Next')).toBeEnabled();
    expect(screen.getByText('Page 1 of 3')).toBeInTheDocument();
  });

  it('correctly enables/disables pagination buttons', async () => {
    // First page (Next enabled, Previous disabled)
    const firstPageData = await getTestServerData(1, 5);
    mockUseInventory.mockReturnValue({
      status: 'ready',
      data: firstPageData,
      error: null
    });

    const { rerender } = render(<InventoryView />);
    
    expect(screen.getByText('Previous')).toBeDisabled();
    expect(screen.getByText('Next')).toBeEnabled();
    
    // Last page (Previous enabled, Next disabled)
    const lastPageData = await getTestServerData(3, 5);
    mockUseInventory.mockReturnValue({
      status: 'ready',
      data: lastPageData,
      error: null
    });
    
    rerender(<InventoryView />);
    
    expect(screen.getByText('Previous')).toBeEnabled();
    expect(screen.getByText('Next')).toBeDisabled();
  });

  it('navigates between pages correctly', async () => {
    // Mock for the first page
    const firstPageData = await getTestServerData(1, 5);
    mockUseInventory.mockReturnValue({
      status: 'ready',
      data: firstPageData,
      error: null
    });

    render(<InventoryView />);
    
    // Navigate to next page
    const nextButton = screen.getByText('Next');
    expect(nextButton).toBeEnabled();
    
    // Click Next
    await fireEvent.click(nextButton);
    
    // The useInventory hook should be called with the new page
    expect(mockUseInventory).toHaveBeenCalledWith(2, 5);
    
    // Mock for the second page
    const secondPageData = await getTestServerData(2, 5);
    mockUseInventory.mockReturnValue({
      status: 'ready',
      data: secondPageData,
      error: null
    });
    
    // Should update with new data
    expect(screen.getByText('Showing 6-10 of 15 items')).toBeInTheDocument();
    expect(screen.getByText('Page 2 of 3')).toBeInTheDocument();
    
    // Navigate back
    const prevButton = screen.getByText('Previous');
    await fireEvent.click(prevButton);
    
    // The useInventory hook should be called with the previous page
    expect(mockUseInventory).toHaveBeenCalledWith(1, 5);
  });

  it('displays empty state when no items', () => {
    mockUseInventory.mockReturnValue({
      status: 'ready',
      data: {
        page: 1,
        limit: 5,
        total: 15,
        items: [],
        hasNext: true
      },
      error: null
    });

    render(<InventoryView />);
    
    expect(screen.getByText('No inventory items found.')).toBeInTheDocument();
  });

  it('displays error message from server', () => {
    mockUseInventory.mockReturnValue({
      status: 'error',
      data: null,
      error: 'Page must be a positive integer'
    });

    render(<InventoryView />);
    
    expect(screen.getByRole('alert')).toHaveTextContent('Page must be a positive integer');
  });
});