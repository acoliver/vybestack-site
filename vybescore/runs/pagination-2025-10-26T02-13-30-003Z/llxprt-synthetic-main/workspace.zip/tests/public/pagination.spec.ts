import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('Inventory Pagination API', () => {
  it('returns default pagination (page 1, limit 5)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.hasNext).toBe(true);
    
    // Check first page items are correct
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[4].id).toBe(5);
  });

  it('validates page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test non-numeric page
    const nonNumericResponse = await request(app).get('/inventory?page=abc');
    expect(nonNumericResponse.status).toBe(400);
    expect(nonNumericResponse.body.error).toContain('Page must be a positive integer');

    // Test negative page
    const negativeResponse = await request(app).get('/inventory?page=-1');
    expect(negativeResponse.status).toBe(400);
    expect(negativeResponse.body.error).toContain('Page must be a positive integer');

    // Test zero page
    const zeroResponse = await request(app).get('/inventory?page=0');
    expect(zeroResponse.status).toBe(400);
    expect(zeroResponse.body.error).toContain('Page must be a positive integer');
  });

  it('validates limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test non-numeric limit
    const nonNumericResponse = await request(app).get('/inventory?limit=abc');
    expect(nonNumericResponse.status).toBe(400);
    expect(nonNumericResponse.body.error).toContain('Limit must be a positive integer');

    // Test negative limit
    const negativeResponse = await request(app).get('/inventory?limit=-1');
    expect(negativeResponse.status).toBe(400);
    expect(negativeResponse.body.error).toContain('Limit must be a positive integer');

    // Test zero limit
    const zeroResponse = await request(app).get('/inventory?limit=0');
    expect(zeroResponse.status).toBe(400);
    expect(zeroResponse.body.error).toContain('Limit must be a positive integer');

    // Test excessive limit
    const excessiveResponse = await request(app).get('/inventory?limit=101');
    expect(excessiveResponse.status).toBe(400);
    expect(excessiveResponse.body.error).toContain('Limit must not exceed 100');
  });

  it('correctly paginates through pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // First page
    const firstPage = await request(app).get('/inventory?page=1&limit=3');
    expect(firstPage.status).toBe(200);
    expect(firstPage.body.page).toBe(1);
    expect(firstPage.body.items).toHaveLength(3);
    expect(firstPage.body.items[0].id).toBe(1);
    expect(firstPage.body.items[2].id).toBe(3);
    expect(firstPage.body.hasNext).toBe(true);

    // Second page
    const secondPage = await request(app).get('/inventory?page=2&limit=3');
    expect(secondPage.status).toBe(200);
    expect(secondPage.body.page).toBe(2);
    expect(secondPage.body.items).toHaveLength(3);
    expect(secondPage.body.items[0].id).toBe(4);
    expect(secondPage.body.items[2].id).toBe(6);
    expect(secondPage.body.hasNext).toBe(true);

    // Last page with full set
    const fourthPage = await request(app).get('/inventory?page=4&limit=3');
    expect(fourthPage.status).toBe(200);
    expect(fourthPage.body.page).toBe(4);
    expect(fourthPage.body.items).toHaveLength(3);
    expect(fourthPage.body.items[0].id).toBe(10);
    expect(fourthPage.body.items[2].id).toBe(12);
    expect(fourthPage.body.hasNext).toBe(true);

    // Last page with partial set
    const fifthPage = await request(app).get('/inventory?page=5&limit=3');
    expect(fifthPage.status).toBe(200);
    expect(fifthPage.body.page).toBe(5);
    expect(fifthPage.body.items).toHaveLength(3);
    expect(fifthPage.body.items[0].id).toBe(13);
    expect(fifthPage.body.items[2].id).toBe(15);
    expect(fifthPage.body.hasNext).toBe(false);

    // Page beyond available data
    const beyondPage = await request(app).get('/inventory?page=6&limit=3');
    expect(beyondPage.status).toBe(200);
    expect(beyondPage.body.page).toBe(6);
    expect(beyondPage.body.items).toHaveLength(0);
    expect(beyondPage.body.hasNext).toBe(false);
  });

  it('returns correct hasNext information', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // hasNext should be true when there are more items
    const page1 = await request(app).get('/inventory?page=1&limit=7');
    expect(page1.status).toBe(200);
    expect(page1.body.hasNext).toBe(true);

    // hasNext should be false when on the last page
    const page3 = await request(app).get('/inventory?page=3&limit=7');
    expect(page3.status).toBe(200);
    expect(page3.body.hasNext).toBe(false);

    // hasNext should be false when asking for a page beyond available data
    const beyondPage = await request(app).get('/inventory?page=4&limit=7');
    expect(beyondPage.status).toBe(200);
    expect(beyondPage.body.hasNext).toBe(false);
  });
});