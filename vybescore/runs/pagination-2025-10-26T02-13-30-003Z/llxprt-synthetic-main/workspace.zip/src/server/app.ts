import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam === undefined) {
      page = undefined; // Will use default in repository
    } else {
      page = Number(pageParam);
      if (isNaN(page) || page <= 0 || !Number.isInteger(page)) {
        return res.status(400).json({
          error: 'Page must be a positive integer'
        });
      }
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam === undefined) {
      limit = undefined; // Will use default in repository
    } else {
      limit = Number(limitParam);
      if (isNaN(limit) || limit <= 0 || !Number.isInteger(limit)) {
        return res.status(400).json({
          error: 'Limit must be a positive integer'
        });
      }
      // Cap at reasonable maximum to prevent performance issues
      if (limit > 100) {
        return res.status(400).json({
          error: 'Limit must not exceed 100'
        });
      }
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      res.status(500).json({
        error: 'Internal server error'
      });
    }
  });

  return app;
}
