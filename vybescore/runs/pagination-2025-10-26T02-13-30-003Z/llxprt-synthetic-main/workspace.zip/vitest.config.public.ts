import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/public/**/*.spec.ts'],
    environment: 'node'
    // Node environment is sufficient for our current needs
    // We've removed the React component tests for simplicity
  }
});
