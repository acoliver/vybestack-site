/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
// Type declarations for sql.js
declare module 'sql.js' {
  interface InitSqlJsStatic {
    new(options?: any): any;
  }

  const initSqlJs: () => Promise<InitSqlJsStatic>;
  export default initSqlJs;
}