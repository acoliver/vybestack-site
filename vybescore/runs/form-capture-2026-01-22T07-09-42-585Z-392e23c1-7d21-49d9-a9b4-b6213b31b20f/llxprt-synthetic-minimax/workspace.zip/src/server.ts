import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  errors?: Record<string, string>;
  values?: Record<string, string>;
}

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize SQL.js
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const SQL: any = await initSqlJs();
      
      // Check if database file exists
      let dbExists = false;
      try {
        const fs = await import('fs');
        dbExists = fs.existsSync(this.dbPath);
      } catch (error) {
        // Node.js fs module not available, file doesn't exist
        dbExists = false;
      }

      if (dbExists) {
        const fs = await import('fs');
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
      }

      // Create table if it doesn't exist
      this.db.run(`
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
      `);

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async save(): Promise<void> {
    try {
      const fs = await import('fs');
      const dirPath = path.dirname(this.dbPath);
      
      // Create data directory if it doesn't exist
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }

      // Write database file
      const dbData = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(dbData));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async insertSubmission(data: SubmissionData): Promise<number> {
    return new Promise((resolve, reject) => {
      try {
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          data.first_name,
          data.last_name,
          data.street_address,
          data.city,
          data.state_province,
          data.postal_code,
          data.country,
          data.email,
          data.phone
        ]);

        stmt.free();
        resolve(this.db.getRowsModified());
      } catch (error) {
        reject(error);
      }
    });
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
    }
  }
}

class FormValidator {
  static validate(data: Partial<FormData>): Record<string, string> {
    const errors: Record<string, string> = {};

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }
    if (!data.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }
    if (!data.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }
    if (!data.city?.trim()) {
      errors.city = 'City is required';
    }
    if (!data.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }
    if (!data.postalCode?.trim()) {
      errors.postalCode = 'Postal/ZIP code is required';
    }
    if (!data.country?.trim()) {
      errors.country = 'Country is required';
    }
    if (!data.email?.trim()) {
      errors.email = 'Email is required';
    }
    if (!data.phone?.trim()) {
      errors.phone = 'Phone number is required';
    }

    // Email validation
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
    if (data.phone && !/^[+]?[0-9\s\-()]+$/.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }

    return errors;
  }
}

const app = express();
const port = parseInt(process.env.PORT || '3535', 10);
let dbManager: DatabaseManager;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes

// GET / - Show contact form
app.get('/', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };

  res.render('form', { 
    formData,
    errors: {},
    values: formData
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvince: req.body.stateProvince?.trim() || '',
      postalCode: req.body.postalCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone: req.body.phone?.trim() || ''
    };

    // Validate form data
    const errors = FormValidator.validate(formData);

    if (Object.keys(errors).length > 0) {
      // Validation failed, re-render form with errors
      return res.status(400).render('form', {
        formData,
        errors,
        values: {
          firstName: formData.firstName,
          lastName: formData.lastName,
          streetAddress: formData.streetAddress,
          city: formData.city,
          stateProvince: formData.stateProvince,
          postalCode: formData.postalCode,
          country: formData.country,
          email: formData.email,
          phone: formData.phone
        }
      });
    }

    // Validation passed, save to database
    const submissionData: SubmissionData = {
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    await dbManager.insertSubmission(submissionData);
    await dbManager.save();

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

// GET /thank-you - Show thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
const gracefulShutdown = async () => {
  console.log('\nReceived SIGTERM, shutting down gracefully...');
  
  try {
    if (dbManager) {
      await dbManager.close();
      console.log('Database closed successfully');
    }
    
    server.close(() => {
      console.log('Server closed successfully');
      process.exit(0);
    });
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
};

// Hook into SIGTERM for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const server = app.listen(port, async () => {
  try {
    dbManager = new DatabaseManager();
    await dbManager.initialize();
    console.log(`Server running on http://localhost:${port}`);
    console.log('Contact form available at http://localhost:' + port);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
});

// Error handling middleware
app.use((error: Error, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Internal Server Error');
});
