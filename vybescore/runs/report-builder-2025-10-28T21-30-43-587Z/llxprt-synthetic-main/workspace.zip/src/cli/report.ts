#!/usr/bin/env node

import fs from 'fs';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): { dataPath: string; options: ReportOptions } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Find format argument
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  // Check for supported formats
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  // Find output argument (optional)
  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataPath,
    options: {
      format,
      outputPath,
      includeTotals
    }
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON data: expected an object');
  }

  const dataObj = data as Record<string, unknown>;
  
  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid JSON data: title must be a string');
  }
  
  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid JSON data: summary must be a string');
  }
  
  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid JSON data: entries must be an array');
  }
  
  for (let i = 0; i < dataObj.entries.length; i++) {
    const entry = dataObj.entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON data: entry ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON data: entry ${i} label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON data: entry ${i} amount must be a number`);
    }
    
    if (isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON data: entry ${i} amount must be a valid number`);
    }
  }
  
  return {
    title: dataObj.title,
    summary: dataObj.summary,
    entries: dataObj.entries.map(entry => {
      const entryObj = entry as Record<string, unknown>;
      return {
        label: entryObj.label as string,
        amount: entryObj.amount as number
      };
    })
  };
}

function renderReport(data: ReportData, options: ReportOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

async function main() {
  try {
    const { dataPath, options } = parseArguments();
    
    // Read the JSON file
    let fileContent;
    try {
      fileContent = fs.readFileSync(dataPath, 'utf8');
    } catch (error) {
      console.error(`Error: Could not read file ${dataPath}`);
      process.exit(1);
    }
    
    // Parse the JSON
    let jsonData;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in ${dataPath}`);
      process.exit(1);
    }
    
    // Validate the data
    const reportData = validateReportData(jsonData);
    
    // Render the report
    const reportContent = renderReport(reportData, options);
    
    // Output the report
    if (options.outputPath) {
      try {
        fs.writeFileSync(options.outputPath, reportContent, 'utf8');
      } catch (error) {
        console.error(`Error: Could not write to file ${options.outputPath}`);
        process.exit(1);
      }
    } else {
      console.log(reportContent);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();