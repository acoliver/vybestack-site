import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3535');

// Initialize sql.js
const SQL = await initSqlJs({
  locateFile: (file) => {
    // Use absolute path from current working directory since we'll run dist/server.js
    const wasmPath = path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
    return wasmPath;
  }
});

let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// Type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  values: Partial<FormData>;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and optionally a leading @ or +
  // Remove all non-digit characters and check if we have at least 10 digits
  const digitsOnly = phone.replace(/[^\d]/g, '');
  return digitsOnly.length >= 10;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handle UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const values: Partial<FormData> = {};
  
  // Validate each field
  const fields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of fields) {
    const value = data[field] || '';
    values[field] = value;

    if (!validateRequired(value)) {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`);
      continue;
    }

    // Specific validations
    switch (field) {
      case 'email':
        if (!validateEmail(value)) {
          errors.push('please enter a valid email address');
        }
        break;
      case 'phone':
        if (!validatePhone(value)) {
          errors.push('please enter a valid phone number');
        }
        break;
      case 'postalCode':
        if (!validatePostalCode(value)) {
          errors.push('please enter a valid postal/zip code');
        }
        break;
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    values
  };
}

// Database functions
async function initDatabase(): Promise<void> {
  try {
    // __dirname is src/ when running dev, so rootDir is parent of src/
    const rootDir = path.join(__dirname, '..');
    const dbFilePath = path.join(rootDir, 'data/submissions.sqlite');
    
    try {
      const dbData = await fs.readFile(dbFilePath);
      db = new SQL.Database(new Uint8Array(dbData));
    } catch (error) {
      // File doesn't exist, create new database
      db = new SQL.Database();
      
      // Load schema
      const schemaPath = path.join(rootDir, 'db/schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf-8');
      
      // Execute schema
      db.exec(schema);
      
      // Save initial database
      await saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    // __dirname is src/ when running dev, so rootDir is parent of src/
    const rootDir = path.join(__dirname, '..');
    const dbFilePath = path.join(rootDir, 'data/submissions.sqlite');
    const dbData = db.export();
    await fs.writeFile(dbFilePath, Buffer.from(dbData));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

async function insertSubmission(data: FormData): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      data.firstName.trim(),
      data.lastName.trim(), 
      data.streetAddress.trim(),
      data.city.trim(),
      data.stateProvince.trim(),
      data.postalCode.trim(),
      data.country.trim(),
      data.email.trim(),
      data.phone.trim()
    ]);
  } finally {
    stmt.free();
  }
  
  await saveDatabase();
}

// Routes
app.get('/', (req, res) => {
  res.render(path.join(__dirname, 'templates/form.ejs'), {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    // Render form with errors and values
    res.status(400).render(path.join(__dirname, 'templates/form.ejs'), {
      errors: validation.errors,
      values: validation.values
    });
    return;
  }

  try {
    // Insert validated data
    await insertSubmission(formData as FormData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    res.status(500).render(path.join(__dirname, 'templates/form.ejs'), {
      errors: ['Internal server error. Please try again.'],
      values: validation.values
    });
  }
});

app.get('/thank-you', (req, res) => {
  // Get first name from last submission for personalization
  let firstName = 'friend';
  
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const hasRow = stmt.step();
      if (hasRow) {
        const values = Object.values(stmt.getAsObject());
        if (values && values.length > 0) {
          firstName = String(values[0]);
        }
      }
      stmt.free();
    } catch (error) {
      console.error('Failed to fetch first name:', error);
    }
  }

  res.render(path.join(__dirname, 'templates/thank-you.ejs'), {
    firstName
  });
});

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  if (db) {
    await saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

// Handle shutdown signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize and start server
initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}).catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
