import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dbManager, Submission } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
interface ValidationError {
  field: string;
  message: string;
}

interface CleanedFormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data: CleanedFormData;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s\-()]{7,20}$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handles UK "SW1A 1AA" and formats like "C1000")
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: Record<string, string>): ValidationResult {
  const errors: ValidationError[] = [];
  const cleanedData: CleanedFormData = {};

  // Required fields validation
  const requiredFields: (keyof Submission)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const value = (data[field] || '').trim();
    
    if (!value) {
      errors.push({
        field,
        message: `${field.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} is required`
      });
    } else {
      (cleanedData as Record<string, string>)[field] = value;
    }
  }

  // Email validation
  if (cleanedData.email && !validateEmail(cleanedData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (cleanedData.phone && !validatePhone(cleanedData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  if (cleanedData.postal_code && !validatePostalCode(cleanedData.postal_code)) {
    errors.push({
      field: 'postal_code',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: cleanedData
  };
}

// Routes

// GET / - Display contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    data: {},
    pageTitle: 'Contact Us - Friendly Form Capture'
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const validation = validateFormData(req.body);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      data: validation.data || {},
      pageTitle: 'Contact Us - Please Fix Errors'
    });
  }

  // Save to database
  try {
    dbManager.saveSubmission(validation.data as Submission);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: [{ field: 'general', message: 'Something went wrong. Please try again.' }],
      data: validation.data || {},
      pageTitle: 'Contact Us - Error'
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    pageTitle: 'Thank You - We Will Be In Touch',
    formData: req.query
  });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown handling
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  dbManager.close();
  
  setTimeout(() => {
    console.log('Graceful shutdown complete.');
    process.exit(0);
  }, 1000);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    
    app.listen(PORT, () => {
      console.log(` Server running on port ${PORT}`);
      console.log(` Form available at http://localhost:${PORT}/`);
      console.log(` Database will be stored in data/submissions.sqlite`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;