import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';

const DB_FILE_PATH = join(process.cwd(), 'data', 'submissions.sqlite');

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private SQL: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    this.SQL = await initSqlJs();
    
    let dbBuffer: Uint8Array | null = null;
    
    if (existsSync(DB_FILE_PATH)) {
      try {
        const buffer = readFileSync(DB_FILE_PATH);
        dbBuffer = new Uint8Array(buffer);
      } catch (error) {
        console.warn('Failed to read existing database, creating new one:', error);
      }
    }

    this.db = new this.SQL!.Database(dbBuffer);
    
    // Initialize schema if not exists
    this.createSchema();
  }

  private createSchema(): void {
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    this.db!.exec(schema);
  }

  saveSubmission(submission: Submission): void {
    const stmt = this.db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    this.persist();
  }

  private persist(): void {
    if (!this.db) return;
    
    const data = this.db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dataDir = dirname(DB_FILE_PATH);
    
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }
    
    writeFileSync(DB_FILE_PATH, buffer);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  getAllSubmissions(): Submission[] {
    const stmt = this.db!.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
    const submissions: Submission[] = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject() as unknown;
      submissions.push(row as Submission);
    }
    
    stmt.free();
    return submissions;
  }
}

// Global database instance
export const dbManager = new DatabaseManager();