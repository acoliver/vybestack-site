/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing between sentences
  let result = text;
  
  // Add exactly one space after sentence-ending punctuation if missing
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Collapse multiple spaces into single space
  result = result.replace(/[ \t]+/g, ' ');
  
  // Capitalize first letter of each sentence
  // Handle the start of the string
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Handle letters after sentence-ending punctuation followed by optional whitespace
  result = result.replace(/([.?!]\s*)([a-z])/g, (_, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Handle cases where there might be quotes or parentheses after punctuation
  result = result.replace(/([.?!]\s*["'([{]*)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Try to preserve abbreviations like "e.g.", "i.e.", "Mr.", "Dr.", "St.", etc.
  const abbreviations = ['e.g', 'i.e', 'mr', 'dr', 'st', 'ms', 'mrs', 'prof', 'sr', 'jr', 'etc', 'vol', 'no', 'p', 'pp'];
  
  result = result.replace(/\b([a-z]\.?)\s+([a-z])/gi, (match, abbr, nextLetter) => {
    const lowercaseAbbr = abbr.toLowerCase().replace('.', '');
    if (abbreviations.includes(lowercaseAbbr)) {
      return abbr + ' ' + nextLetter.toLowerCase();
    }
    return match;
  });
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches:
  // - http:// or https:// protocols (optional)
  // - www. prefix (optional)
  // - Domain names with subdomains
  // - Paths, query parameters, fragments
  // - Various TLDs including country codes
  
  // More comprehensive regex that explicitly handles protocols
  const protocolRegex = /https?:\/\/(?:[-a-zA-Z0-9@:%._+~=]{1,256}\.)?[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)/g;
  
  // www-only regex
  const wwwRegex = /www\.(?:[-a-zA-Z0-9@:%._+~=]{1,256}\.)?[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)/g;
  
  const urls: string[] = [];
  const found = new Set<string>();
  
  // Find URLs with explicit protocols
  let match;
  while ((match = protocolRegex.exec(text)) !== null) {
    let url = match[0];
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?]+$/, '');
    if (!found.has(url)) {
      urls.push(url);
      found.add(url);
    }
  }
  
  // Find www URLs that don't have protocols
  while ((match = wwwRegex.exec(text)) !== null) {
    let url = match[0];
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?]+$/, '');
    // Add http:// prefix for consistency
    if (!url.startsWith('http')) {
      url = 'http://' + url;
    }
    if (!found.has(url)) {
      urls.push(url);
      found.add(url);
    }
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but don't touch https://
  // Use word boundary to avoid matching within other text
  const result = text.replace(/\bhttp:\/\//g, 'https://');
  
  return result;
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // URL regex to match http://example.com/... patterns
  const urlRegex = /(http:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Check if path contains dynamic hints that should prevent host rewrite
    const skipHostRewrite = /\/(cgi-bin|.*\?.*|.*&.*|.*=.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // If path starts with /docs/ and doesn't contain skip patterns, rewrite host
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Extract subdomain if any (e.g., api.example.com -> docs.example.com)
      const parts = domain.split('.');
      if (parts.length >= 2) {
        // Special case for example.com -> docs.example.com
        if (domain === 'example.com') {
          return newProtocol + 'docs.example.com' + path;
        }
        // For other domains like api.example.com, replace first part with 'docs'
        parts[0] = 'docs';
        const newDomain = parts.join('.');
        return newProtocol + newDomain + path;
      }
    }
    
    // Just upgrade the scheme
    return newProtocol + domain + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (February)
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
