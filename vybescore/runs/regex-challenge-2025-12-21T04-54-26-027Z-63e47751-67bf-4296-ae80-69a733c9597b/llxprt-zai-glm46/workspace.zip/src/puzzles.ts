/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary regex to find words starting with prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  // Filter out exceptions and duplicates
  const filteredWords: string[] = [];
  const seen = new Set<string>();
  
  for (const word of matches) {
    const lowerWord = word.toLowerCase();
    if (!exceptionSet.has(lowerWord) && !seen.has(lowerWord)) {
      filteredWords.push(word);
      seen.add(lowerWord);
    }
  }
  
  return filteredWords;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to match token only when preceded by a digit
  // and use negative lookbehind to ensure we're not at the start of the string
  // Return the full match including the digit and token
  const tokenRegex = new RegExp(`(?<!^)(\\d${escapedToken})`, 'g');
  
  const matches: string[] = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[1]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab, abcabc, 1212)
  // Check for repeated patterns of length 2 or more
  for (let patternLength = 2; patternLength <= value.length / 2; patternLength++) {
    for (let i = 0; i <= value.length - 2 * patternLength; i++) {
      const pattern = value.substring(i, i + patternLength);
      const nextPattern = value.substring(i + patternLength, i + 2 * patternLength);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address regex that matches various formats including shorthand
  // Includes:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8:85a3::8a2e:370:7334
  // - Loopback: ::1
  // - Unspecified: ::
  // - Embedded IPv4: ::ffff:192.0.2.128
  
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // Check if the text contains an IPv6 address
  const hasIPv6 = ipv6Regex.test(value);
  
  // If we find IPv6, verify it's not just an embedded IPv4 pattern that could be confused
  if (hasIPv6) {
    // Look for colons which are characteristic of IPv6
    const hasColons = /:/.test(value);
    return hasColons;
  }
  
  return false;
}
