export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that supports common email formats
  // Accepts typical addresses such as name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  
  // Basic format check - must have exactly one @
  const atIndex = value.indexOf('@');
  if (atIndex === -1 || atIndex !== value.lastIndexOf('@')) {
    return false;
  }
  
  // Cannot start or end with @
  if (value.startsWith('@') || value.endsWith('@')) {
    return false;
  }
  
  const localPart = value.substring(0, atIndex);
  const domain = value.substring(atIndex + 1);
  
  // Local part validation
  // Valid characters: letters, digits, and !#$%&'*+/=?^_`{|}~-
  // Can contain dots but not consecutive, not at start/end
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  
  if (!localRegex.test(localPart)) {
    return false;
  }
  
  // Reject consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Reject local part starting or ending with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain validation
  // Cannot contain underscores (per requirements)
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Reject domain starting or ending with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Domain must have at least one dot for proper structure
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  // Each domain part must be valid (no empty parts, no invalid characters)
  const domainPartRegex = /^[a-zA-Z0-9-]+$/;
  for (const part of domainParts) {
    if (!part || !domainPartRegex.test(part)) {
      return false;
    }
    
    // Domain parts cannot start or end with hyphen
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  // TLD must be at least 2 characters and only letters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2 || !/^[a-zA-Z]+$/.test(tld)) {
    return false;
  }
  
  // Reject invalid domains like localhost, IP addresses
  const invalidDomains = ['localhost', '127.0.0.1', '0.0.0.0', '255.255.255.255'];
  if (invalidDomains.includes(domain.toLowerCase())) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Numbers starting with 0 are not valid US numbers (they're typically international)
  if (value.replace(/\D/g, '').startsWith('0')) {
    return false;
  }
  
  // Reject dot separators explicitly
  if (value.includes('.')) {
    return false;
  }
  
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for standard US number)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Remove optional +1 country code if present
  let digits = cleaned;
  if (digits.startsWith('1') && digits.length > 10) {
    digits = digits.substring(1);
  }
  
  // Should have exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits) and exchange code (next 3 digits)
  const areaCode = digits.substring(0, 3);
  const exchangeCode = digits.substring(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex to ensure proper structure
  // Supports (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890, etc.
  // But NOT 212.555.7890
  const phoneRegex = /^(?:\+?1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check for basic digit requirements
  if (!/^\+?0?9?\d+$/.test(normalized)) {
    return false;
  }
  
  // Handle different formats
  let areaCode = '';
  let subscriberNumber = '';
  
  if (normalized.startsWith('+54')) {
    const rest = normalized.substring(3);
    if (rest.startsWith('9')) {
      areaCode = rest.substring(1, 1 + 2); // First 2 digits after 9
      subscriberNumber = rest.substring(1 + 2);
    } else {
      areaCode = rest.substring(0, 3); // First 3 digits
      subscriberNumber = rest.substring(3);
    }
  } else {
    // No country code
    if (normalized.startsWith('0')) {
      const rest = normalized.substring(1);
      if (rest.startsWith('9')) {
        areaCode = rest.substring(1, 1 + 2); // First 2 digits after 9
        subscriberNumber = rest.substring(1 + 2);
      } else {
        areaCode = rest.substring(0, 3); // First 3 digits
        subscriberNumber = rest.substring(3);
      }
    } else {
      return false; // Must have trunk prefix if no country code
    }
  }
  
  // Area code must be 2-4 digits and cannot start with 0
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate that all remaining characters are digits
  if (!/^\d+$/.test(areaCode + subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex that allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes (for names like O'Connor)
  // - Hyphens (for hyphenated names)
  // - Spaces (for multiple words)
  // - Rejects digits, symbols, and invalid formats like X Æ A-12
  
  // Allow unicode letters, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Ensure name contains at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names that are too short (less than 1 character after trimming)
  const trimmed = value.trim();
  if (trimmed.length < 1) {
    return false;
  }
  
  // Reject names with only special characters (like just apostrophes or hyphens)
  const lettersOnly = trimmed.replace(/['\-\s]/g, '');
  if (lettersOnly.length === 0) {
    return false;
  }
  
  // Reject names with consecutive special characters that look invalid
  if (/''|---|\s{2,}/.test(trimmed)) {
    return false;
  }
  
  // Reject names that start or end with apostrophe, hyphen, or space
  if (/^['\-\s]|['\-\s]$/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits and have reasonable length
  if (!/^\d+$/.test(cleaned) || cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const isVisa = /^4\d{12}(?:\d{3})?$/.test(cleaned);
  const isMastercard = /^(5[1-5]\d{14}|2[2-7]\d{14})$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
