import * as cheerio from 'cheerio';
console.log('Cheerio loaded:', typeof cheerio.load);
