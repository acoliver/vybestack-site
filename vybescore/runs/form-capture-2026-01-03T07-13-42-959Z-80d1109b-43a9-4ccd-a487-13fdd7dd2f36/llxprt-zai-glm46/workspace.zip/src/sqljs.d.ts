declare module 'sql.js' {
  interface SqlJsStatic {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    Database: new (data?: ArrayLike<number> | Buffer | null) => any;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  interface Database {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    run(sql: string, params?: any[]): RunResult;
    exec(sql: string): ExecResult[];
    export(): Uint8Array;
    close(): void;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  interface RunResult {
    columns: string[];
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  interface ExecResult {
    columns: string[];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    values: any[][];
  }

  interface InitSqlJsStatic {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (config?: any): Promise<SqlJsStatic>;
  }

  const initSqlJs: InitSqlJsStatic;
  export default initSqlJs;
}
