import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s+()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric strings with spaces, dashes
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateSubmission(data: Partial<Submission>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and dashes' });
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }

  return errors;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function initializeDatabase(): Promise<any> {
  const SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let database: any;
  if (fs.existsSync(dbPath)) {
    const dbBuffer = fs.readFileSync(dbPath);
    database = new SQL.Database(dbBuffer);
  } else {
    database = new SQL.Database();
    // Run schema
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    database.run(schema);
    saveDatabase(database);
  }

  return database;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function saveDatabase(database: any): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

function createApp(): express.Application {
  const app = express();

  app.use(express.static(path.resolve(__dirname, '..', 'public')));
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, '..', 'views'));

  app.get('/', (req, res) => {
    res.render('index', { 
      errors: [], 
      values: {},
      hasErrors: false
    });
  });

  app.post('/submit', (req, res) => {
    const submission: Submission = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateSubmission(submission);

    if (errors.length > 0) {
      res.status(400);
      const errorMap: Record<string, string> = {};
      errors.forEach(err => {
        errorMap[err.field] = err.message;
      });
      res.render('index', {
        errors: errorMap,
        values: submission,
        hasErrors: true
      });
      return;
    }

    // Insert into database
    if (db) {
      db.run(
        `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          submission.firstName,
          submission.lastName,
          submission.streetAddress,
          submission.city,
          submission.stateProvince,
          submission.postalCode,
          submission.country,
          submission.email,
          submission.phone
        ]
      );
      saveDatabase(db);
    }

    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req, res) => {
    res.render('thank-you');
  });

  return app;
}

let serverInstance: ReturnType<express.Application['listen']> | null = null;

export async function startServer(): Promise<{ app: express.Application; server: ReturnType<express.Application['listen']> }> {
  db = await initializeDatabase();
  const app = createApp();
  const port = process.env.PORT || '3535';
  
  serverInstance = app.listen(port, () => {
    // Server started
  });

  // Handle graceful shutdown
  process.on('SIGTERM', () => {
    if (serverInstance) {
      serverInstance.close(() => {
        if (db) {
          db.close();
        }
        process.exit(0);
      });
    }
  });

  return { app, server: serverInstance };
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
