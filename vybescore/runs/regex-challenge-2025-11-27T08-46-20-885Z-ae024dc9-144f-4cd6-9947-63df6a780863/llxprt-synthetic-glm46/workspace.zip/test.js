// Simple test for isStrongPassword
const value = 'Abcdef!234';

console.log('Value:', value);
console.log('Length:', value.length);
console.log('Has uppercase:', /[A-Z]/.test(value));
console.log('Has lowercase:', /[a-z]/.test(value));
console.log('Has digit:', /\d/.test(value));
console.log('Has symbol:', /[!@#$%^&*()_+=\[\\]{};':"\\|,.<>\/?]/.test(value));
console.log('Has repeated:', /(.{2,4})\1/.test(value));