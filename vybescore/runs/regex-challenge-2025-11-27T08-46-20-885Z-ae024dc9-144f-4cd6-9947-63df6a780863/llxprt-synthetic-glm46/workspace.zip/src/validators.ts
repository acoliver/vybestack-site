/**
 * Validates email addresses using regex
 *
 * @param value - Email address string to validate
 * @returns boolean indicating if the email is valid
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Email validation regex
  // Local part: letters, digits, +, ., -, _ (but not consecutive dots, not starting/ending with dot)
  // Domain part: letters, digits, hyphens, dots (not starting/ending with dot, no underscores)
  // TLD: at least 2 characters
  const emailRegex = /^[a-zA-Z0-9.+_%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  // Quick format check
  if (!emailRegex.test(value)) return false;

  // More specific validation rules
  // No double dots in local part or domain
  if (value.includes('..')) return false;

  // No trailing dots
  if (value.endsWith('.')) return false;

  // No underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;

  // Local part shouldn't start or end with a dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;

  return true;
}

/**
 * Validates US phone numbers using regex
 *
 * @param value - Phone number string to validate
 * @param options - Optional validation configuration
 * @returns boolean indicating if the phone number is valid
 */
export function isValidUSPhone(value: string, options?: { requireCountryCode?: boolean }): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Optional +1 country code
  const hasCountryCode = digitsOnly.startsWith('1');
  const phoneNumber = hasCountryCode ? digitsOnly.slice(1) : digitsOnly;

  // Check length (10 digits for US phone numbers)
  if (phoneNumber.length !== 10) return false;

  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);

  // Disallow area codes starting with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Check if country code is required but not present
  if (options?.requireCountryCode && !hasCountryCode) return false;

  // Validate common US phone formats
  const phoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers using regex
 *
 * @param value - Phone number string to validate
 * @returns boolean indicating if the phone number is valid
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Regex for Argentine phone numbers
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code omitted)
  // Optional 9 mobile prefix
  // 2-4 digit area code (can't start with 0)
  // 6-8 digit subscriber number
  const argPhoneRegex = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;

  if (!argPhoneRegex.test(cleaned)) return false;

  // If no country code, must start with 0 trunk prefix
  if (!cleaned.startsWith('+54') && !value.startsWith('0')) return false;

  // Extract area code (after optional country code, mobile prefix, and trunk prefix)
  let areaCode: string;
  if (cleaned.startsWith('+54')) {
    const afterCountryCode = cleaned.slice(3); // Remove +54
    const afterMobilePrefix = afterCountryCode.startsWith('9')
      ? afterCountryCode.slice(1)
      : afterCountryCode;
    areaCode = afterMobilePrefix.slice(0, afterMobilePrefix.length - 6);
  } else {
    // Starts with 0 trunk prefix
    const afterTrunkPrefix = cleaned.slice(1);
    const afterMobilePrefix = afterTrunkPrefix.startsWith('9')
      ? afterTrunkPrefix.slice(1)
      : afterTrunkPrefix;
    areaCode = afterMobilePrefix.slice(0, afterMobilePrefix.length - 6);
  }

  // Area code must be 2-4 digits and can't start with 0
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;

  return true;
}

/**
 * Validates names using regex
 *
 * @param value - Name string to validate
 * @returns boolean indicating if the name is valid
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Name validation regex
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and strange combinations
  const nameRegex = /^[\p{L}\p{M}'][\p{L}\p{M}'\-\s]*$/u;

  if (!nameRegex.test(value)) return false;

  // Reject names with digits or special symbols
  const containsDigits = /\d/.test(value);
  const containsInvalidSymbols = /[^\p{L}\p{M}'\-\s]/u.test(value);

  return !containsDigits && !containsInvalidSymbols;
}

/**
 * Helper function to perform Luhn checksum for credit card validation
 *
 * @param value - Credit card number string
 * @returns boolean indicating if the card passes Luhn check
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\s/g, '');
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using regex and Luhn checksum
 *
 * @param value - Credit card number string to validate
 * @returns boolean indicating if the credit card is valid
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and dashes
  const cleanNumber = value.replace(/[\s-]/g, '');

  // Must be 13-19 digits (typical credit card lengths)
  if (!/^\d{13,19}$/.test(cleanNumber)) return false;

  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12}$/;
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat = visaRegex.test(cleanNumber) ||
                        mastercardRegex.test(cleanNumber) ||
                        amexRegex.test(cleanNumber);

  if (!isValidFormat) return false;

  // Perform Luhn checksum
  return runLuhnCheck(cleanNumber);
}