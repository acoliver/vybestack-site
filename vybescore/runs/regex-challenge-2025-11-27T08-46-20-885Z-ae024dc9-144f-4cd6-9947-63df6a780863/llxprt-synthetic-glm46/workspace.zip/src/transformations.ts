/**
 * Capitalizes the first character of each sentence
 *
 * @param text - Text to transform
 * @returns Text with properly capitalized sentences
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Split text by sentence delimiters (. ? !) and keep the delimiters
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let expectSentenceStart = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // Skip empty parts
    if (!part) continue;
    
    // If it's a sentence delimiter, add it and a space
    if (part === '.' || part === '?' || part === '!') {
      result += part + ' ';
      expectSentenceStart = true;
      continue;
    }
    
    // Process sentence content
    if (expectSentenceStart && part.length > 0) {
      // Find the first letter character
      const firstCharIndex = part.search(/[a-zA-Z]/);
      if (firstCharIndex !== -1) {
        const before = part.substring(0, firstCharIndex);
        const firstChar = part[firstCharIndex].toUpperCase();
        const after = part.substring(firstCharIndex + 1);
        result += before + firstChar + after;
        expectSentenceStart = false;
      } else {
        // No letter found, just add the part as is
        result += part;
      }
    } else {
      // In the middle of a sentence, collapse whitespace and add as is
      result += part.replace(/\s+/g, ' ');
    }
  }
  
  // Clean up extra spaces and trim
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extracts all URLs from the given text
 *
 * @param text - Text to search for URLs
 * @returns Array of URLs found in the text
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL regex pattern
  const regexPattern = '(?:https?://)(?:[-\\w.])+(?:[:\\d]+)?(?:/(?:[\\w/_.])*(?:\\?(?:[\\w&=%.])*)?(?:#(?:[\\w.])*)?)?';
  const urlRegex = new RegExp(regexPattern, 'g');

  // Find all matches
  const matches = text.match(urlRegex);
  if (!matches) return [];

  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,;:!?)]+$/, '');
  });
}

/**
 * Replaces all http:// schemes with https://
 *
 * @param text - Text to transform
 * @returns Text with enforced HTTPS
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Replace http:// with https://
  const regexPattern = 'http://';
  const httpsRegex = new RegExp(regexPattern, 'g');
  
  return text.replace(httpsRegex, 'https://');
}

/**
 * Rewrites documentation URLs according to the rules
 *
 * @param text - Text to transform
 * @returns Text with rewritten documentation URLs
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // First enforce HTTPS on all URLs
  const result = enforceHttps(text);

  // Pattern to match URLs
  const urlPattern = '(https://(?:[a-zA-Z0-9.-]+))(/[a-zA-Z0-9./_-]*(?:\\?[a-zA-Z0-9=&_-]*)?(?:#[a-zA-Z0-9._-]*)?)';
  const urlRegex = new RegExp(urlPattern, 'g');

  return result.replace(urlRegex, (match, host, path) => {
    // Check if the path contains any dynamic hints that should prevent host rewriting
    const dynamicPattern = '/(?:cgi-bin|\\?|&|=|\\.jsp|\\.php|\\.asp|\\.aspx|\\.do|\\.cgi|\\.pl|\\.py)';
    const dynamicRegex = new RegExp(dynamicPattern);
    
    // If we should rewrite the host and the path starts with /docs/
    if (!dynamicRegex.test(path) && path.startsWith('/docs/')) {
      // Change host to docs.{original domain without subdomains}
      const domain = host.replace(/^https:\/\//, '').replace(/^www\./, '');
      return 'https://docs.' + domain + path;
    }

    // Otherwise, just return the original URL (which is already HTTPS)
    return match;
  });
}

/**
 * Extracts the year from a date string in mm/dd/yyyy format
 *
 * @param value - Date string to parse
 * @returns Four-digit year or "N/A" if invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format
  const datePattern = '^(0[1-9]|1[0-2])/(0[1-9]|[12]\\d|3[01])/(\\d{4})$';
  const dateRegex = new RegExp(datePattern);
  const match = value.match(dateRegex);

  if (!match) return 'N/A';

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Basic validation for day/month combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  // Check for leap year
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  const febDays = isLeapYear ? 29 : 28;

  if (month === 2 && day > febDays) return 'N/A';
  if (month !== 2 && day > daysInMonth[month - 1]) return 'N/A';

  return year;
}