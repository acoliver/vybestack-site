/**
 * Finds words beginning with a prefix, excluding exceptions
 *
 * @param text - Text to search
 * @param prefix - Prefix to match
 * @param exceptions - Words to exclude from results
 * @returns Array of matching words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];

  // Create regex to find words starting with the prefix
  // Word boundary at start, then prefix, then word characters
  const pattern = '\\b' + prefix + '\\w*';
  const prefixedWordRegex = new RegExp(pattern, 'gi');
  
  // Find all matches
  const matches = text.match(prefixedWordRegex);
  if (!matches) return [];

  // Filter out any empty strings and handle exceptions
  const result = matches
    .map(match => match.trim())
    .filter(word => word.length > 0);

  // Filter out exceptions (case-insensitive)
  const filteredResult = result.filter(word => {
    return !exceptions.some(exception => 
      word.localeCompare(exception, undefined, { sensitivity: 'accent' }) === 0
    );
  });

  // Return unique elements
  return [...new Set(filteredResult)];
}

/**
 * Finds occurrences of a token after a digit but not at string start
 *
 * @param text - Text to search
 * @param token - Token to find
 * @returns Array of matched tokens including the digit
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use lookahead to find token after a digit
  // Since negative lookbehind is not supported everywhere, we'll use a workaround
  const pattern = '\\d' + escapedToken;
  const tokenRegex = new RegExp(pattern, 'g');
  
  // This should match "1foo" not just the token
  // Let's try a more direct approach
  const startIndexRegex = new RegExp('.*(?=\\d' + escapedToken + ')');
  const startIndex = text.search(startIndexRegex) + 1;
  
  // Use a simpler approach
  let result: string[] = [];
  let offset = 0;
  
  while (offset < text.length - token.length - 1) {
    // Find next occurrence of token
    const tokenIndex = text.indexOf(token, offset);
    if (tokenIndex === -1) break;
    
    // Check if it's preceded by a digit
    const charBefore = text.charAt(tokenIndex - 1);
    if (charBefore >= '0' && charBefore <= '9') {
      result.push(charBefore + token);
    }
    
    offset = tokenIndex + token.length;
  }
  
  return result;
}

/**
 * Validates if a password meets strong password criteria
 *
 * @param value - Password to validate
 * @returns boolean indicating if password is strong
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Password must be at least 10 characters
  if (value.length < 10) return false;

  // No whitespace characters
  if (value.match(/\s/)) return false;

  // Must contain at least one uppercase letter
  if (!value.match(/[A-Z]/)) return false;

  // Must contain at least one lowercase letter
  if (!value.match(/[a-z]/)) return false;

  // Must contain at least one digit
  if (!value.match(/[0-9]/)) return false;

  // Must contain at least one symbol (non-alphanumeric)
  if (!value.match(/[^a-zA-Z0-9]/)) return false;

  // Check for immediate repeated sequences (like abab)
  // Use a simpler approach to check for repeated sequences
  for (let i = 2; i < value.length / 2; i++) {
    const pattern = value.substring(0, i);
    if (value.substring(i, i * 2) === pattern) {
      return false;
    }
  }

  return true;
}

/**
 * Detects if a string contains an IPv6 address but not an IPv4 address
 *
 * @param value - Text to search
 * @returns boolean indicating presence of IPv6
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // First check for IPv4 addresses to ensure we don't mistakenly identify them
  const ipv4Pattern = '\\b(?:[0-9]{1,3}\\.){3}[0-9]{1,3}\\b';
  const ipv4Regex = new RegExp(ipv4Pattern);
  if (ipv4Regex.test(value)) return false;

  // IPv6 pattern
  // Can include:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Double colon :: for consecutive zero groups
  
  // Basic IPv6 pattern
  const ipv6Pattern = '(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}';
  const ipv6Regex = new RegExp(ipv6Pattern);
  
  if (ipv6Regex.test(value)) return true;

  // Check for :: notation
  const ipv6CompressedPattern = '(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*';
  const ipv6CompressedRegex = new RegExp(ipv6CompressedPattern);
  
  return ipv6CompressedRegex.test(value);
}