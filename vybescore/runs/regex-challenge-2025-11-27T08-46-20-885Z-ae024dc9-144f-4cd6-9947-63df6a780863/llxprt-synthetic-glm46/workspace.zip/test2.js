// Test symbol matching in regex
const value = 'Abcdef!234';
const test1 = /[!@#$%^&*()_+=\[\\]{};':"\\|,.<>\/?]/;
const test2 = /[!@#$%^&*()_+=\\[\\]{};':"\\|,.<>\/?]/;
const test3 = /[!@#$%^&*()_+=\\[\\]{};':"\\|,.<>\/?]/;
const test4 = /[!@#$%^&*()_+=\\[\\]{};':"\\|,.<>\/?]/;
const fixed = /[!@#$%^&*()_+=\\[\\]{};':"\\|,.<>\/?]/;

console.log('Value:', value);
console.log('Test 1 double escaped:', test1.test(value));
console.log('Test 2 double escaped:', test2.test(value));
console.log('Test 3 double escaped:', test3.test(value));
console.log('Test 4 double escaped:', test4.test(value));
console.log('Fixed symbol regex:', fixed.test(value));
console.log('Symbol in value:', value.includes('!'));