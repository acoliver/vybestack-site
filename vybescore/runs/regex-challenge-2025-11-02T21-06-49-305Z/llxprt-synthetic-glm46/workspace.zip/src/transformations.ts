/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Insert a space after sentence-ending punctuation if there isn't one already
  // But be careful not to add space after abbreviations like Mr. Dr. etc.
  result = result.replace(/([.!?])(?=[A-Z])/g, '$1 ');
  
  // Capitalize the first character of each sentence
  result = result.replace(/(?:^|[.!?]\s+)([a-z])/g, (match) => match.toUpperCase());
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Match http:// or https:// protocols
  // Followed by domain name and optional path
  // Exclude trailing punctuation like .,!?,;:
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?:;]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/docs\/[^\s]*)/, `https://docs.example.com$1`)
            .replace(/http:\/\/example\.com(\/[^\s]*)?/, `https://example.com$1`);
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // mm/dd/yyyy format validation
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day based on month (simple validation, not considering leap years)
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
