export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: letters, digits, + tag, dots (but not consecutive or at ends)
  // Domain: letters, digits, hyphens, subdomains, TLD 2-63 chars
  const emailRegex = /^[a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  // Reject emails with consecutive dots or dots at start/end of local part
  if (value.includes('..') || value.startsWith('.') || value.endsWith('@.') || /@.*\.$/.test(value)) {
    return false;
  }
  
  // Reject emails with underscores in domain
  if (/@.*_/.test(value)) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  const hasCountryCode = cleaned.startsWith('+1');
  const phoneNumber = hasCountryCode ? cleaned.substring(2) : cleaned;
  
  // Check minimum length (10 digits for US numbers)
  if (phoneNumber.length < 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the phone number format
  // Support: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(\+1)?\s*\(?(2[0-9]{2}|[3-9][0-9]{2})\)?[\s.-]?([0-9]{3})[\s.-]?([0-9]{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // When no country code, must start with 0 trunk prefix
  // Optional mobile indicator 9
  // Area code 2-4 digits (not starting with 0)
  // Subscriber number 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, trunkPrefix, areaCode, subscriberNumber] = match;
  
  // Check if the number begins correctly
  // If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Check mobile indicator (9) placement
  // If country code is present, mobile indicator can be after it
  // If trunk prefix is present, mobile indicator can be after it
  if (countryCode && trunkPrefix && cleaned.indexOf('+54') === 0 && cleaned.indexOf('0') === 3) {
    // This would be invalid format like +540...
    return false;
  }
  
  // Validate area code format
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Handle mobile indicator (9) special case
  // When country code is present, mobile indicator can be after it
  // When country code is absent, mobile indicator can be after trunk prefix
  if (cleaned.includes('9')) {
    if (countryCode && cleaned.indexOf('9') !== 3) {
      return false;
    }
    if (!countryCode && trunkPrefix && cleaned.indexOf('9') !== 1) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and "X Æ A-12" style names
  const nameRegex = /^[\p{L}\p{M}'’-]+(?:\s[\p{L}\p{M}'’-]+)*$/u;
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive special characters
  if (/['’-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with special characters
  if (/^['’\s-]|['’\s-]$/.test(value)) {
    return false;
  }
  
  // Reject X Æ A-12 style names (contain digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{12}))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the format matches any card type
  const isValidFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Luhn algorithm
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run the Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process each digit from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
