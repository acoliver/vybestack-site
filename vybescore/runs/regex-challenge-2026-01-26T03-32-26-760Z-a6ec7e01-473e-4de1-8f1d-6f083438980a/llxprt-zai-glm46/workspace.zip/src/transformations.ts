/**
 * Capitalizes the first character of each sentence.
 * - Sentences end with . ! or ?
 * - Inserts exactly one space between sentences if missing
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible (e.g., "e.g." at end of a clause)
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // First, normalize multiple spaces to single space
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Ensure space after sentence-ending punctuation if followed by a letter
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');

  // Common abbreviations that shouldn't trigger sentence breaks
  // These are checked when they appear before a period
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'e\\.g', 'i\\.e', 'vs', 'etc', 'avg', 'approx'];

  // Build regex for abbreviations (word boundary before, period after, followed by space or end)
  const abbrPattern = abbreviations.join('|');
  const abbrRegex = new RegExp(`\\b(${abbrPattern})\\.(?=\\s|$)`, 'gi');

  // Mark abbreviation positions to preserve them
  const markers: number[] = [];
  let match;
  while ((match = abbrRegex.exec(normalized)) !== null) {
    markers.push(match.index + match[0].length - 1); // Position of the period
  }

  // Capitalize first letter of text
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }

  // Now capitalize after sentence boundaries that are NOT abbreviations
  let result = '';
  let capitalizeNext = false;

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];

    if (capitalizeNext && char.match(/[a-z]/i)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      result += char;
    }

    // Check if this is a sentence boundary
    if (char === '.' || char === '!' || char === '?') {
      // Check if this position is NOT in our abbreviations list
      if (!markers.includes(i)) {
        // Look ahead - if next non-space is a letter, capitalize it
        let nextIdx = i + 1;
        while (nextIdx < normalized.length && normalized[nextIdx] === ' ') {
          nextIdx++;
        }
        if (nextIdx < normalized.length && normalized[nextIdx].match(/[a-z]/i)) {
          capitalizeNext = true;
        }
      }
    }
  }

  return result;
}

/**
 * Extracts URLs from text.
 * - Returns array of URL strings
 * - Removes trailing punctuation (.,!?;:)
 * - Handles http, https, and www-prefixed URLs
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL pattern: scheme://domain/path or www.domain/path
  // Captures trailing punctuation separately to exclude it
  const urlRegex = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*(\.[a-zA-Z0-9-]+)+[^\s.,!?;:]*/gi;

  const matches = text.match(urlRegex) || [];

  // Strip trailing punctuation more carefully
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Converts http:// URLs to https://.
 * - Leaves already-secure URLs untouched
 * - Handles multiple URLs in text
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:)/gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs.
 * - Always upgrades to https://
 * - For paths starting with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Pattern to match http://example.com/... URLs
  // We need to capture: scheme, domain, and the rest of the URL
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, scheme, domain, path) => {
    // Always upgrade to https
    const newScheme = 'https://';

    // Check if we should rewrite the host to docs.example.com
    // Conditions: path starts with /docs/, AND no dynamic hints
    const shouldRewriteHost = path.startsWith('/docs/') && !shouldSkipHostRewrite(path);

    const newDomain = shouldRewriteHost ? 'docs.example.com' : domain;

    return newScheme + newDomain + path;
  });
}

/**
 * Helper to check if a path should skip host rewrite.
 * - Returns true if path contains cgi-bin, query strings, or legacy extensions
 */
function shouldSkipHostRewrite(path: string): boolean {
  // Dynamic path indicators
  const skipPatterns = [
    /cgi-bin/i,
    /[?&=]/,  // Query string
    /\.jsp$/i,
    /\.php$/i,
    /\.asp$/i,
    /\.aspx$/i,
    /\.do$/i,
    /\.cgi$/i,
    /\.pl$/i,
    /\.py$/i
  ];

  return skipPatterns.some(pattern => pattern.test(path));
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * - Returns the four-digit year
 * - Returns 'N/A' if format is invalid or month/day are out of range
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Trim and match mm/dd/yyyy format exactly
  const trimmed = value.trim();
  const dateMatch = trimmed.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

  if (!dateMatch) return 'N/A';

  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month and day ranges
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';

  // More specific day validation per month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  if (day > daysInMonth[month]) return 'N/A';

  return yearStr;
}
