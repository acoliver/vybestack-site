export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * - Accepts standard format: local@domain.tld
 * - Allows common TLDs including country codes (e.g., .co.uk)
 * - Rejects double dots, trailing dots, domains with underscores
 * - Rejects obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Trim whitespace
  const email = value.trim();

  // Basic structure: local-part @ domain
  // Local part: letters, digits, dots, hyphens, underscores, plus, percent
  // But no consecutive dots, no leading/trailing dots in local part
  // Domain: letters, digits, hyphens, dots (no underscores)
  // TLD: at least 2 letters, can have multi-part like co.uk

  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9.%+-]*[a-zA-Z0-9]@(?!-)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;

  // Additional checks for invalid patterns
  if (!emailRegex.test(email)) return false;

  // Reject double dots anywhere
  if (/\.\./.test(email)) return false;

  // Reject trailing dot
  if (email.endsWith('.')) return false;

  // Reject underscore in domain
  const domainPart = email.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;

  // Local part validation
  const localPart = email.split('@')[0];
  if (!localPart || localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (/\.\./.test(localPart)) return false;

  return true;
}

/**
 * Validates US phone numbers.
 * - Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 country code
 * - Area code cannot start with 0 or 1
 * - Must have 10 digits total (excluding country code)
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all non-digit characters (except + for country code)
  let cleaned = value.trim().replace(/[^\d+]/g, '');

  // Handle optional +1 prefix
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    // Might be a 1 prefix without +
    cleaned = cleaned.substring(1);
  }

  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(cleaned)) return false;

  const areaCode = cleaned.substring(0, 3);
  const exchangeCode = cleaned.substring(3, 6);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Exchange code cannot start with 0 or 1 (NANP rules)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;

  return true;
}

/**
 * Validates Argentine phone numbers.
 * - Landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens for validation
  const cleaned = value.trim().replace(/[\s-]/g, '');

  // Pattern:
  // Optional +54 (country code)
  // Optional 9 (mobile indicator, only after country code or trunk prefix)
  // Required: either 0 (trunk) if no country code, or area code directly
  // Area code: 2-4 digits, cannot start with 0
  // Subscriber: 6-8 digits

  // Try to match with country code +54
  const withCountryRegex = /^\+54(\d)(\d{2,4})(\d{6,8})$/;
  const withCountryMatch = cleaned.match(withCountryRegex);

  if (withCountryMatch) {
    const [, mobileOrArea, areaPart, subscriber] = withCountryMatch;

    // Check if mobile indicator is present (9)
    if (mobileOrArea === '9') {
      // Next is area code (2-4 digits, starts with 1-9)
      const areaCode = areaPart;
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      if (/^[0]/.test(areaCode)) return false;
      if (subscriber.length < 6 || subscriber.length > 8) return false;
      return true;
    } else {
      // No mobile indicator, mobileOrArea is part of area code
      const areaCode = mobileOrArea + areaPart;
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      if (/^[0]/.test(areaCode)) return false;
      if (subscriber.length < 6 || subscriber.length > 8) return false;
      return true;
    }
  }

  // Try to match without country code (must start with 0)
  const withoutCountryRegex = /^0(\d)(\d{1,3})(\d{6,8})$/;
  const withoutCountryMatch = cleaned.match(withoutCountryRegex);

  if (withoutCountryMatch) {
    const [, firstDigit, areaRest, subscriber] = withoutCountryMatch;

    // Area code is firstDigit + areaRest
    const areaCode = firstDigit + areaRest;
    if (areaCode.length < 2 || areaCode.length > 4) return false;

    // Leading digit of area code cannot be 0
    if (firstDigit === '0') return false;

    if (subscriber.length < 6 || subscriber.length > 8) return false;
    return true;
  }

  return false;
}

/**
 * Validates personal names.
 * - Allows unicode letters, accents, apostrophes, hyphens, spaces
 * - Rejects digits, symbols, and unusual formats like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const trimmed = value.trim();

  if (trimmed.length === 0) return false;

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;

  if (!nameRegex.test(trimmed)) return false;

  // Must contain at least one letter (unicode)
  const hasLetter = /[\p{L}]/u.test(trimmed);
  if (!hasLetter) return false;

  // Reject digits
  if (/\d/.test(trimmed)) return false;

  // Reject certain symbols that shouldn't be in names
  const invalidSymbols = /[@#$%^&*()_+=[\]{}|\\:;"<>,.?/0-9]/;
  if (invalidSymbols.test(trimmed)) return false;

  return true;
}

/**
 * Validates credit card numbers.
 * - Accepts Visa (starts with 4, 13-16 digits)
 * - Accepts Mastercard (starts with 51-55, 16 digits)
 * - Accepts AmEx (starts with 34 or 37, 15 digits)
 * - Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens
  const cleaned = value.trim().replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12,15}$/;
  // Mastercard: 16 digits, starts with 51-55
  const mastercardRegex = /^5[1-5]\d{14}$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validPrefix) return false;

  // Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
