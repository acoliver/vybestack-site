/**
 * Finds words starting with a prefix, excluding listed exceptions.
 * - Returns array of matching words
 * - Words are whitespace-separated tokens
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];

  // Split by whitespace to get words
  const words = text.split(/\s+/).filter(w => w.length > 0);

  // Filter words that start with prefix
  const matches = words.filter(word => {
    if (!word.toLowerCase().startsWith(prefix.toLowerCase())) return false;

    // Check if this word (case-insensitive) is in exceptions
    const wordLower = word.toLowerCase();
    const exceptionsLower = exceptions.map(e => e.toLowerCase());

    if (exceptionsLower.includes(wordLower)) return false;

    return true;
  });

  return matches;
}

/**
 * Finds occurrences of a token that appear after a digit.
 * - Token must not be at the start of the string
 * - Token must be immediately preceded by a digit
 * - Returns array of matching token occurrences (including the digit)
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];

  const results: string[] = [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use lookbehind to ensure token is preceded by a digit
  // (?<!^) ensures not at start of string
  // (?<=\d) ensures preceded by digit
  // Capture the digit along with the token
  const regex = new RegExp(`(?<!^)(?<=(\\d))(${escapedToken})`, 'g');

  const matches = text.matchAll(regex);
  for (const match of matches) {
    // Return digit + token
    results.push(match[1] + match[2]);
  }

  return results;
}

/**
 * Validates password strength.
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab, 1212)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Minimum length
  if (value.length < 10) return false;

  // No whitespace
  if (/\s/.test(value)) return false;

  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // At least one digit
  if (!/\d/.test(value)) return false;

  // At least one symbol (not letter, not digit, not whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{}|;:'",.<>/?\\`~]/.test(value)) return false;

  // No immediate repeated sequences (abab, 1212, xyxy)
  // Check for patterns of length 2-4 that repeat immediately
  if (hasRepeatedSequence(value)) return false;

  return true;
}

/**
 * Helper to detect repeated sequences like abab, 1212, xyxy
 */
function hasRepeatedSequence(value: string): boolean {
  // Check for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + len * 2);

      if (sequence === nextSequence) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Detects IPv6 addresses in text.
 * - Supports full and shorthand notation (::)
 * - Excludes pure IPv4 addresses
 * - Returns true if any IPv6 address is found
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Look for IPv6 patterns in the string
  // Split into potential tokens and check each

  const tokens = value.split(/\s+/);

  for (const token of tokens) {
    // Remove trailing punctuation
    const cleaned = token.replace(/[.,;:]$/, '');

    // Check if it looks like IPv6
    if (cleaned.includes(':') && cleaned !== ':') {
      // Check for various IPv6 patterns

      // Full or partial IPv6 pattern
      // Must have at least 2 colons for IPv6
      const colonCount = (cleaned.match(/:/g) || []).length;

      if (colonCount >= 2) {
        // Check if it's valid IPv6 format

        // Pattern: hex groups separated by colons, possibly with ::
        const ipv6Pattern = /^[0-9a-fA-F:]+$/;

        if (ipv6Pattern.test(cleaned)) {
          // Additional validation
          if (isValidIPv6Format(cleaned)) {
            return true;
          }
        }
      }
    }
  }

  return false;
}

/**
 * Helper to validate IPv6 format more carefully.
 * Distinguishes IPv6 from IPv4.
 */
function isValidIPv6Format(token: string): boolean {
  // Try to match various IPv6 patterns

  // Full IPv6 (8 groups)
  const fullPattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  if (fullPattern.test(token)) return true;

  // Compressed with ::
  if (token.includes('::')) {
    // Can't start or end with single colon (must be ::)
    if (token.startsWith(':') && !token.startsWith('::')) return false;
    if (token.endsWith(':') && !token.endsWith('::')) return false;

    // Can't have more than one ::
    const doubleColonCount = (token.match(/::/g) || []).length;
    if (doubleColonCount > 1) return false;

    // Must be valid hex and colons
    const parts = token.split('::');
    for (const part of parts) {
      if (part === '') continue;
      if (part.includes(':')) {
        const subParts = part.split(':');
        for (const sub of subParts) {
          if (sub === '' || sub.length > 4 || !/^[0-9a-fA-F]+$/.test(sub)) {
            return false;
          }
        }
      } else if (part !== '' && (part.length > 4 || !/^[0-9a-fA-F]+$/.test(part))) {
        return false;
      }
    }

    return true;
  }

  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const embeddedIPv4Pattern = /::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/i;
  if (embeddedIPv4Pattern.test(token)) return true;

  return false;
}
