/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addObserver,
  getActiveObserver,
  addSubjectObserver,
  notifyObservers,
  EqualFn,
  Options,
  Subject
} from '../types/reactive.js'

// WeakMap to track computed-to-subject relationships
const computedSubjects = new WeakMap<Observer<unknown>, Subject<unknown>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Handle equal parameter - if boolean true, use strict equality
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  // Create a subject for the computed value to enable notifications
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }

  let computedValue: T = value as T

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      computedValue = updateFn(currentValue)
      computedSubject.value = computedValue
      
      // Notify all observers of this computed value when it changes
      notifyObservers(computedSubject as Subject<unknown>)
      return computedValue
    },
  }

  // Track the relationship between observer and subject for cleanup
  computedSubjects.set(o as Observer<unknown>, computedSubject as Subject<unknown>)

  // Add observer to global observers set
  addObserver(o)

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed value should notify the active observer when it changes
      addSubjectObserver(computedSubject, observer as unknown as Parameters<typeof addSubjectObserver>[1])
    }
    return computedValue
  }
  
  // Initialize dependencies by executing the update function
  updateObserver(o)
  
  return getter
}