/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addSubjectObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equal parameter - if boolean true, use strict equality
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Type assertion to satisfy the function signature
      addSubjectObserver(s, observer as unknown as Parameters<typeof addSubjectObserver>[1])
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value // No change, return current value
    }
    
    s.value = nextValue
    
    // Trigger synchronous update of all dependent observers
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}