/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverLike = {
  name?: string
  updateFn: (value?: unknown) => unknown
  value?: unknown
}

export type SubjectLike = {
  name?: string
  observer?: ObserverLike
  value: unknown
  equalFn?: EqualFn<unknown>
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Global sets for tracking observers and their relationships
const observers = new Set<ObserverLike>()
const subjectObservers = new WeakMap<SubjectLike, Set<ObserverLike>>()

export function addObserver<T>(observer: Observer<T>): void {
  const obsLike = observer as ObserverLike
  observers.add(obsLike)
}

export function removeObserver<T>(observer: Observer<T>): void {
  const obsLike = observer as ObserverLike
  observers.delete(obsLike)
}

export function addSubjectObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  const subLike = subject as SubjectLike
  const obsLike = observer as ObserverLike
  
  let observers = subjectObservers.get(subLike)
  if (!observers) {
    observers = new Set()
    subjectObservers.set(subLike, observers)
  }
  observers.add(obsLike)
}

export function removeSubjectObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  const subLike = subject as SubjectLike
  const obsLike = observer as ObserverLike
  
  const observers = subjectObservers.get(subLike)
  if (observers) {
    observers.delete(obsLike)
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Use a Set to track updates in progress to prevent infinite loops
const updatesInProgress = new Set<ObserverLike>()

export function notifyObservers<T>(subject: Subject<T>): void {
  // Get all observers that depend on this subject
  const subLike = subject as SubjectLike
  const observers = Array.from(subjectObservers.get(subLike) || [])
  
  for (const observer of observers) {
    // Skip update if we're already updating this observer (prevents infinite loops)
    if (!updatesInProgress.has(observer)) {
      updatesInProgress.add(observer)
      try {
        updateObserver(observer as Observer<unknown>)
      } finally {
        updatesInProgress.delete(observer)
      }
    }
  }
}