import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

// Get the directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Database setup
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
let db: Database;

async function initDB() {
  const SQL = await initSqlJs();
  let data: Buffer | undefined;
  
  try {
    data = fs.readFileSync(DB_PATH);
    db = new SQL.Database(new Uint8Array(data));
  } catch (err) {
    // If file doesn't exist, create a new database
    db = new SQL.Database();
    db.run(fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8'));
    
    // Save the initial database to file
    const initialData = db.export();
    fs.writeFileSync(DB_PATH, initialData);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[\\d\\s\\-\\+\\(\\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric postal codes with spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\\s\\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;

  const errors: string[] = [];

  // Validate required fields
  if (!firstName) errors.push('First name is required');
  if (!lastName) errors.push('Last name is required');
  if (!streetAddress) errors.push('Street address is required');
  if (!city) errors.push('City is required');
  if (!stateProvince) errors.push('State/Province is required');
  if (!postalCode) errors.push('Postal code is required');
  if (!country) errors.push('Country is required');
  if (!email) errors.push('Email is required');
  if (!phone) errors.push('Phone number is required');

  // Validate specific fields
  if (email && !validateEmail(email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (phone && !validatePhone(phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  if (postalCode && !validatePostalCode(postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  // If there are errors, re-render the form with errors and values
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: req.body });
  }

  // Insert into database
  db.run(
    `INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone]
  );

  // Save database to file
  const data = db.export();
  fs.writeFileSync(DB_PATH, data);

  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen>;

function startServer() {
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

function closeServer() {
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
    
    // Close database
    if (db) {
      db.close();
      console.log('Database closed');
    }
  }
}

// Initialize DB and start server
initDB().then(() => {
  startServer();
});

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing server');
  closeServer();
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing server');
  closeServer();
});

export default app;
export { server };