export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation using regex.
 *Accept typical addresses such as name@tag@example.co.uk. Reject double dots, trailing dots, 
 * domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick basic format check
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for specific invalid patterns
  const invalidPatterns = [
    /\.\./,  // double dots
    /^[.]/, // leading dot in local part
    /\.$/,   // trailing dot in local part
    /_$\b/,  // underscore in domain part
    /\.$/,   // trailing dot in domain part
    /^[^@]+@.*_/, // underscore in domain
    /.@/,   // dot before @
    /@.*\.{2,}/, // double dots in domain
  ];
  
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) return false;
  }
  
  // Check if domain has valid structure (no leading or trailing hyphens)
  const domain = value.split('@')[1];
  if (domain && (domain.startsWith('-') || domain.endsWith('-'))) return false;
  
  return true;
}

/**
 * US phone number validation supporting common separators and optional +1.
 * Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallow impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters except + for country code
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check if starting with +1 (optional country code)
  let digits = cleanValue;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // Must be exactly 10 digits after removing country code and separators
  if (digits.length !== 10) return false;
  
  // First digit of area code cannot be 0 or 1
  if (digits[0] === '0' || digits[0] === '1') return false;
  
  // Validate complete format more strictly
  const usPhoneRegex = /^(?:\+?1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * Argentine phone number validation covering mobile/landline formats.
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54.
 * Optional trunk prefix 0 immediately before the area code.
 * Optional mobile indicator 9 between country/trunk and the area code.
 * Area code must be 2–4 digits (leading digit 1–9).
 * Subscriber number must contain 6–8 digits in total.
 * When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * Let single spaces or hyphens as separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Regex for Argentine phone numbers
  // +54 [9] [area code] [subscriber]
  // or
  // 0[area code] [subscriber]
  const argentinePhoneRegex = /^(\+54)?(\s*9\s*)?(0?[1-9]\d{1,3})(\s?\d{2,4}){2,3}$/;
  
  if (!argentinePhoneRegex.test(value)) {
    return false;
  }

  // Extract and validate components
  let trunkPrefix: string | null = null;
  const mobileIndicator = false;
  let areaCode: string | null = null;
  let subscriberNumber: string | null = null;
  
  // Check patterns with regex groups to extract components
  const withCountryCode = /^(\+54)(?:[-\s]+)?(?:9)?(?:[-\s]+)?([0-9]\d{0,3})(?:[-\s]+)?(\d{2,4})(?:[-\s]+)?(\d{4})$/.exec(value);
  const withoutCountryCode = /^(0?)([1-9]\d{0,3})(?:[-\s]+)?(\d{2,4})(?:[-\s]+)?(\d{4})$/.exec(value);
  
  if (withCountryCode) {
    // Pattern: +54 9 11 1234 5678
    areaCode = withCountryCode[2];
    subscriberNumber = ''.concat(withCountryCode[3] || '', withCountryCode[4] || '');
    
    // Area code validation: 2-4 digits, doesn't start with 0
    if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
    
    // Subscriber number validation: 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  } else if (withoutCountryCode) {
    // Pattern: 011 1234 5678 or 0341 4234567
    trunkPrefix = withoutCountryCode[1];
    areaCode = trunkPrefix + withoutCountryCode[2];
    subscriberNumber = ''.concat(withoutCountryCode[3] || '', withoutCountryCode[4] || '');
    
    // When no country code, trunk prefix (0) is required
    if (trunkPrefix !== '0') return false;
    
    // Area code validation: 2-4 digits, doesn't start with 0
    if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
    
    // Subscriber number validation: 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  } else {
    // Try a more flexible pattern for various formats
    const flexibleMatch = /^(\+54)?[-\s]?9?[-\s]?(0?[1-9]\d{1,3})[-\s]?(\d{2,4})[-\s]?(\d{2,4})(?:[-\s]?(\d{4}))?$/.exec(value);
    if (!flexibleMatch) return false;
    
    areaCode = flexibleMatch[3];
    const subscriberParts = [
      flexibleMatch[4] || '',
      flexibleMatch[5] || ''
    ];
    subscriberNumber = subscriberParts.join('');
    
    if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permit unicode letters, accents, apostrophes, hyphens, spaces. Reject digits, symbols,
 * and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Reject empty or whitespace-only strings
  if (value.trim() === '') return false;
  
  // Unicode letters, spaces, apostrophes, hyphens, accents
  // Basic pattern: one or more name components separated by spaces
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF\s'-]+$/;
  
  // More strict validation: cannot start or end with special chars
  // Cannot have consecutive special chars
  const strictValidation = /^((?![.'-]{2})[a-zA-Z\u00C0-\u017F\u0400-\u04FF\s'-])*[a-zA-Z\u00C0-\u017F\u0400-\u04FF]([a-zA-Z\u00C0-\u017F\u0400-\u04FF\s'-])*$/;
  
  if (!nameRegex.test(value)) return false;
  if (!strictValidation.test(value)) return false;
  
  // Check for digits which shouldn't be present in names
  if (/\d/.test(value)) return false;
  
  // Reject names with only special characters
  const onlySpecialChars = /^[^\p{L}\s]*$/u;
  if (onlySpecialChars.test(value)) return false;
  
  // Validate that it contains at least one letter
  const containsLetter = /\p{L}/u;
  if (!containsLetter.test(value)) return false;
  
  // Reject specific invalid patterns like X Æ A-12
  const invalidPatterns = [
    /X\s*Æ\s*A-?\s*12/i,  // X Æ A-12 style names
    /^[^\p{L}]*\d/,       // Names starting with digits
    /\s*$/,                // Names with only whitespace
  ];
  
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) return false;
  }

  // Disallow excessive consecutive special characters
  const excessiveSpecial = /['-]{3,}|[ ]{3,}/;
  if (excessiveSpecial.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  if (!value || typeof value !== 'string' || !/^\d+$/.test(value)) return false;
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled = doubled - 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Credit card patterns for different issuers
  const patterns = [
    // Visa: 13 or 16 digits, starts with 4
    {
      regex: /^4(\d{12}|\d{15})$/,
      length: [13, 16]
    },
    // MasterCard: 16 digits, starts with 51-55 or 2221-2720
    {
      regex: /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720\d{2})\d{10})$/,
      length: [16]
    },
    // American Express: 15 digits, starts with 34 or 37
    {
      regex: /^3[47]\d{13}$/,
      length: [15]
    }
  ];
  
  // Check if it matches any of the patterns
  let isValidPattern = false;
  for (const pattern of patterns) {
    if (pattern.regex.test(cleanValue)) {
      isValidPattern = true;
      break;
    }
  }
  
  if (!isValidPattern) return false;
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
