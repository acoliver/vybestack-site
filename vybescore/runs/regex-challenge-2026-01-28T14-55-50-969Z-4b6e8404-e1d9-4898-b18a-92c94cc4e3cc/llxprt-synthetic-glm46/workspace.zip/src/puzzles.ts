/**
 * Match words starting with the prefix but excluding banned words.
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words starting with the prefix
  const wordRegex = /\b\w+\b/g;
  const prefixRegex = new RegExp(`\b${escapedPrefix}\w*`);
  
  // Find all words in text
  const words = text.match(wordRegex) || [];
  
  // Filter words that start with the prefix and aren't in exceptions
  const prefixedWords = words.filter(word => {
    // Check if word starts with prefix
    if (!prefixRegex.test(word)) return false;
    
    // Ensure word is not in exceptions
    const lowerWord = word.toLowerCase();
    const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
    return !lowerExceptions.includes(lowerWord);
  });
  
  return prefixedWords;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Return occurrences where the token appears after a digit and not at the start of the string (use lookaheads/lookbehinds).
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find token that appears after a digit and not at the start
  // Using lookbehind to ensure the token is preceded by a digit
  const tokenRegex = new RegExp(`(?<=\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = [...text.matchAll(tokenRegex)];
  
  // Return the matched tokens
  return matches.map(match => match[0]);
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Length must be at least 10 characters
  if (value.length < 10) return false;
  
  // Check for whitespace characters
  if (/\s/.test(value)) return false;
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must have at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must have at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  const repeatedSequenceRegex = /([a-zA-Z0-9]{2,})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // More sophisticated check for repeated patterns like "abab"
  // This checks for patterns where a sequence of 2 or more characters
  // immediately repeats themselves
  for (let sequenceLength = 2; sequenceLength <= Math.floor(value.length / 2); sequenceLength++) {
    for (let i = 0; i <= value.length - sequenceLength * 2; i++) {
      const sequence = value.substr(i, sequenceLength);
      const nextSequence = value.substr(i + sequenceLength, sequenceLength);
      if (sequence === nextSequence) return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv4 pattern to exclude valid IPv4 addresses
  // Note: This will exclude IPv4 even if it appears in text with an IPv6 address
  const ipv4Pattern = /(?:^|\s)(?:\d{1,3}\.){3}\d{1,3}(?:$|\s)/;
  
  // IPv6 patterns
  // Full IPv6 with all 8 groups of 4 hex digits
  const fullIPv6Pattern = /(?:^|[\s:])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:$|[\s:]|[^\da-fA-F:])/;
  
  // Compressed IPv6 with :: (can have 0-7 groups before and after ::)
  const compressedIPv6Pattern = /(?:^|[\s:])(?:[0-9a-fA-F]{1,4}:){0,7}:(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}(?:$|[\s:]|[^\da-fA-F:])/;
  
  // Special case for just :: which represents all zeros
  const doubleColonPattern = /(?:^|[\s:])::(?:$|[\s:]|[^\da-fA-F:])/;
  
  // Pattern with IPv4 embedded in IPv6
  const ipv4EmbeddedPattern = /(?:^|[\s:])(?:[0-9a-fA-F]{1,4}:){1,5}:(?:\d{1,3}\.){3}\d{1,3}(?:$|[\s:]|[^.])/;
  
  // Let's first check if the text contains an IPv4 address without IPv6 components
  // If only IPv4 is present, we return false
  if (ipv4Pattern.test(value) && !fullIPv6Pattern.test(value) && !compressedIPv6Pattern.test(value) && !doubleColonPattern.test(value) && !ipv4EmbeddedPattern.test(value)) {
    return false;
  }
  
  // Now check for IPv6 patterns
  return fullIPv6Pattern.test(value) || compressedIPv6Pattern.test(value) || doubleColonPattern.test(value) || ipv4EmbeddedPattern.test(value);
}
