/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalize the first character of each sentence (after .?!), insert exactly one space between sentences 
 * even if the input omitted it, and collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Save the original text for later comparison
  const originalText = text;
  
  // Split text into sentences using . ! ? followed by optional spaces
  const sentenceRegex = /([.!?]+)(\s*)/g;
  let lastIndex = 0;
  const sentences = [];
  let match;
  
  while ((match = sentenceRegex.exec(originalText)) !== null) {
    // Add text before the delimiter
    if (match.index > lastIndex) {
      sentences.push({
        text: originalText.substring(lastIndex, match.index),
        delimiter: match[1],
        spaces: match[2] || ' '
      });
    }
    lastIndex = match.index + match[0].length;
  }
  
  // Add the remaining text
  if (lastIndex < originalText.length) {
    sentences.push({
      text: originalText.substring(lastIndex),
      delimiter: '',
      spaces: ''
    });
  }
  
  // Capitalize the first letter of each sentence
  const resultSentences = [];
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (i === 0) {
      // First sentence - capitalize first character
      if (sentence.text && sentence.text.length > 0) {
        const firstChar = sentence.text[0];
        if (firstChar && firstChar !== firstChar.toUpperCase()) {
          sentence.text = firstChar.toUpperCase() + sentence.text.substring(1);
        }
      }
    }
    
    resultSentences.push(sentence);
    
    // Add delimiter and single space after each sentence (except the last one)
    if (i < sentences.length - 1 && sentence.delimiter) {
      resultSentences.push({
        text: '',
        delimiter: sentence.delimiter,
        spaces: ' '  // Always use exactly one space
      });
    }
  }
  
  // Join all the parts
  let result = '';
  for (const part of resultSentences) {
    result += part.text + part.delimiter + part.spaces;
  }
  
  // Trim trailing space
  result = result.replace(/\s+$/, '');
  
  // Additional special handling for common abbreviations with periods (like e.g., i.e., etc.)
  // Look for patterns where we incorrectly capitalized after a period that's part of an abbreviation
  const abbreviationPatterns = [
    /(\be\.?g\.?\s+)([a-z])/g,  // e.g.
    /(\bi\.?e\.?\s+)([a-z])/g,  // i.e.
    /(\betc\.?\s+)([a-z])/g,    // etc.
    /(\bvs\.?\s+)([a-z])/g,     // vs.
    /(\bmr\.?\s+)([a-z])/g,     // mr.
    /(\bms\.?\s+)([a-z])/g,     // ms.
    /(\bdr\.?\s+)([a-z])/g,     // dr.
    /(\bprof\.?\s+)([a-z])/g,   // prof.
  ];
  
  // Fix incorrect capitalization after abbreviations
  for (const pattern of abbreviationPatterns) {
    result = result.replace(pattern, (match, p1, p2) => p1 + p2.toLowerCase());
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // More precise pattern that captures scheme, domain, and path components
  const preciseUrlRegex = /(?:(?:https?|ftp):\/\/)?(?:www\.)?([a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?)(?:\/([^\s]*))?(?![\w.-])/g;
  
  // Extract URLs from text using the precise pattern
  const urls = [];
  let match;
  
  while ((match = preciseUrlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation that's not part of the URL
    const trailingPunctuationChars = ['.', ',', ';', ':', '!', '?', ')', ']', '}', '"', "'", ')'];
    while (url.length > 0 && trailingPunctuationChars.includes(url[url.length - 1])) {
      url = url.slice(0, -1);
    }
    
    // Add protocol if missing (default to http)
    if (!url.match(/^https?:\/\//) && !url.match(/^ftp:\/\//)) {
      url = 'http://' + url;
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // URL pattern to match http:// URLs
  const httpUrlRegex = /(http:\/\/)([^\s]+)/g;
  
  // Replace all http:// with https://
  return text.replace(httpUrlRegex, (match, protocol, url) => {
    return 'https://' + url;
  });
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/....
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://.
 * - Preserve nested paths (e.g., /docs/api/v1).
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Process all URL patterns in the text
  return text.replace(/(http:\/\/)([^\/\s]+)(\/[^\s]*)?/g, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if the URL should have its host rewritten
    let shouldRewriteHost = false;
    
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints that would prevent host rewrite
      const dynamicHints = [
        /\/cgi-bin/,
        /\?/,
        /&/,
        /=/,
        /\.jsp$/,
        /\.php$/,
        /\.asp$/,
        /\.aspx$/,
        /\.do$/,
        /\.cgi$/,
        /\.pl$/,
        /\.py$/
      ];
      
      shouldRewriteHost = true;
      for (const pattern of dynamicHints) {
        if (pattern.test(path)) {
          shouldRewriteHost = false;
          break;
        }
      }
    }
    
    if (shouldRewriteHost && host && host.startsWith('example.com')) {
      // Rewrite host to docs.example.com
      const newHost = 'docs.example.com';
      return newProtocol + newHost + path;
    }
    
    // Just upgrade to https
    return newProtocol + host + (path || '');
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 * Return the four-digit year for mm/dd/yyyy. If the string doesn't match that format or month/day are invalid, return 'N/A'.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Date format mm/dd/yyyy
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month/day combinations
  // Check for months with 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // Check for February (including leap year logic)
  if (month === 2) {
    if (day > 29) {
      return 'N/A';
    }
    
    // Check for leap year if day is 29
    if (day === 29) {
      const yearNum = parseInt(year, 10);
      // Leap year if divisible by 4, but not by 100 unless also by 400
      if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
        return 'N/A';
      }
    }
  }
  
  // Return the year if all validations passed
  return year;
}
