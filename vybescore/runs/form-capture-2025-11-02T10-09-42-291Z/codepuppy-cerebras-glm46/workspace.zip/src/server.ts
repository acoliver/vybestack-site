import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
// @ts-expect-error - sql.js doesn't have proper type definitions
import sqliteModule from 'sql.js';

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private server: ReturnType<express.Application['listen']> | null = null;
  private db: sqliteModule.Database | null = null;
  private readonly dbPath: string;
  private readonly SQLite: typeof sqliteModule;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve('data', 'submissions.sqlite');
    this.SQLite = sqliteModule;
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve('public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve('src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // sql.js needs to be initialized properly
      const SQL = await this.SQLite();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        const schemaSQL = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
        this.db.run(schemaSQL);
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(formData: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    if (!formData.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!formData.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!formData.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!formData.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!formData.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!formData.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    } else if (!/^[A-Za-z0-9s-]+$/.test(formData.postalCode.trim())) {
      errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and hyphens' });
    }

    if (!formData.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!formData.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    if (!formData.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!/^\+?[\ds()-]+$/.test(formData.phone.trim())) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, hyphens, and optional leading +' });
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - Render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = req.body;
      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        // Render form with errors
        const errorMessages = errors.map(error => error.message);
        return res.status(400).render('form', {
          errors: errorMessages,
          values: formData
        });
      }

      try {
        // Insert into database
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName?.trim(),
          formData.lastName?.trim(),
          formData.streetAddress?.trim(),
          formData.city?.trim(),
          formData.stateProvince?.trim(),
          formData.postalCode?.trim(),
          formData.country?.trim(),
          formData.email?.trim(),
          formData.phone?.trim()
        ]);

        stmt.free();

        // Save database to file
        this.saveDatabase();

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        const errorMessages = ['An error occurred while saving your submission. Please try again.'];
        return res.status(500).render('form', {
          errors: errorMessages,
          values: formData
        });
      }
    });

    // GET /thank-you - Render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // Get the latest submission to show first name
      let firstName = 'friend';
      
      try {
        if (this.db) {
          const stmt = this.db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
          const result = stmt.get();
          stmt.free();
          if (result && result.first_name) {
            firstName = result.first_name;
          }
        }
      } catch (error) {
        console.error('Error fetching latest submission:', error);
      }

      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    // Check if we're in test mode - if so, don't actually start listening
    const isTest = process.env.NODE_ENV === 'test' || process.env.VITEST === 'true';
    
    if (isTest) {
      // In test mode, don't start the server but still set up graceful shutdown
      process.on('SIGTERM', () => this.shutdown());
      process.on('SIGINT', () => this.shutdown());
      return;
    }
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down server...');
    
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    
    if (this.server) {
      return new Promise<void>((resolve) => {
        this.server!.close(() => {
          console.log('Server closed');
          resolve();
        });
      });
    }
  }

  // Expose app for testing
  public get getApp(): express.Application {
    return this.app;
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export { FormServer };