import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { FormServer } from '../../src/server.js';

let server: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Set test environment
  process.env.NODE_ENV = 'test';
  
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server (won't actually listen in test mode)
  server = new FormServer();
  await server.start();
  
  // Get the express app for testing
  app = server.getApp;
});

afterAll(async () => {
  if (server) {
    await server.shutdown();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check form title
    expect($('h1').text()).toContain('Tell us who you are');
    
    // Check all required fields exist with proper labels and inputs
    const fields = [
      { label: 'First name', input: 'firstName' },
      { label: 'Last name', input: 'lastName' },
      { label: 'Street address', input: 'streetAddress' },
      { label: 'City', input: 'city' },
      { label: 'State / Province / Region', input: 'stateProvince' },
      { label: 'Postal / Zip code', input: 'postalCode' },
      { label: 'Country', input: 'country' },
      { label: 'Email', input: 'email' },
      { label: 'Phone number', input: 'phone' }
    ];
    
    fields.forEach(field => {
      const label = $(`label[for="${field.input}"]`);
      expect(label.length).toBe(1);
      expect(label.text()).toContain(field.label);
      
      const input = $(`#${field.input}[name="${field.input}"]`);
      expect(input.length).toBe(1);
    });
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    // Check redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify data was inserted by checking the thank you page
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John!');
  });
});
