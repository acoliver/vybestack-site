/**
 * Validate that a string is valid Base64.
 * Base64 consists of: A-Z, a-z, 0-9, +, /, and optional padding (=).
 */
const INVALID_BASE64 = 'Invalid Base64 input';

function isValidBase64(input: string): boolean {
  // Check for empty string
  if (input.length === 0) {
    return false;
  }

  // Base64 regex: matches valid Base64 characters and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check if string matches the pattern
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check padding rules: padding can only appear at the end
  // and there can be at most 2 padding characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be at the end
    if (paddingIndex < input.length - 2) {
      return false;
    }
    // If there's padding, the total length with padding must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, the length must still be valid for Base64
    // (when adding padding, it would be a multiple of 4)
    if (input.length % 4 === 1) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64 using the standard alphabet.
 * Output includes padding characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Trim whitespace first
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64);
  }

  // Add padding if necessary (Node.js Buffer requires proper padding)
  let normalized = trimmed;
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  if (paddingNeeded > 0) {
    normalized += '='.repeat(paddingNeeded);
  }

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if the decoding was successful by verifying the buffer
    // If the input was invalid, Node.js will still decode it but produce garbage
    // We need to verify by encoding back and comparing (with padding handling)
    const reEncoded = buffer.toString('base64');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    const normalizedInput = trimmed.replace(/=+$/, '');
    
    if (normalizedReEncoded !== normalizedInput) {
      throw new Error(INVALID_BASE64);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64);
  }
}
