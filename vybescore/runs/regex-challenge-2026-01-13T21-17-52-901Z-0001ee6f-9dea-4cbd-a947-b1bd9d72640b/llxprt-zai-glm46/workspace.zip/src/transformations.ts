/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first character after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences if input omitted it
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible (single letter followed by period)
 */
export function capitalizeSentences(text: string): string {
  // First, handle spacing around sentence boundaries
  // If there's no space after punctuation that ends a sentence, add one
  let result = text;

  // Add space after .?! when followed by a lowercase letter (likely next sentence)
  // But be careful with abbreviations like "Mr." or "Dr." - single letter + period
  result = result.replace(/([.!?])([a-z])/g, '$1 $2');

  // Collapse multiple spaces into one (but preserve line breaks)
  result = result.replace(/[^\S\n]+/g, ' ');

  // Now capitalize the first letter of each sentence
  // A sentence starts with the first character or after .!? followed by space(s)
  const capitalizeAfter = (str: string): string => {
    return str.replace(
      /(^|[.!?]\s+)([a-z])/g,
      (match, prefix, letter) => prefix + letter.toUpperCase()
    );
  };

  result = capitalizeAfter(result);

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https URLs
  // Allows domains, IP addresses, ports, paths, query strings, fragments
  // Excludes trailing punctuation like .,;:!?) etc.

  const urlPattern =
    /https?:\/\/(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s\]["'<>]*)?/g;

  const matches = text.match(urlPattern) || [];

  // Strip trailing punctuation from each match
  return matches.map((url) => {
    return url.replace(/[.,;:!?)\]]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  // Use word boundary or start of string to avoid replacing within other text
  return text.replace(/http:\/\/(?!\s)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://..., moving docs paths to docs.example.com.
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // We need to capture: scheme, host, and path
  const pattern = /(http:\/\/example\.com)(\/[^\s]*)?/gi;

  return text.replace(pattern, (match, schemeAndHost, path = '') => {
    // Always upgrade to https
    const secureScheme = 'https://example.com';

    // If there's no path or path doesn't start with /docs/, just upgrade scheme
    if (!path || !path.startsWith('/docs/')) {
      return secureScheme + path;
    }

    // Check if path contains dynamic hints that should prevent host rewrite
    const fullRest = path.toLowerCase();

    // Check for query strings
    if (fullRest.includes('?') || fullRest.includes('&') || fullRest.includes('=')) {
      return secureScheme + path;
    }

    // Check for cgi-bin
    if (/\/cgi-bin\//i.test(path)) {
      return secureScheme + path;
    }

    // Check for legacy extensions
    const legacyExtensions = [
      '.jsp',
      '.php',
      '.asp',
      '.aspx',
      '.do',
      '.cgi',
      '.pl',
      '.py'
    ];
    for (const ext of legacyExtensions) {
      if (fullRest.includes(ext)) {
        return secureScheme + path;
      }
    }

    // Safe to rewrite host to docs.example.com
    return 'https://docs.example.com' + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31,
    2: 29, // Allow leap year for simplicity
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31
  };

  const maxDays = daysInMonth[month];
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }

  return year;
}
