/**
 * Match words starting with the prefix but excluding banned words.
 * Uses word boundaries to find complete words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // Word boundary at start, then prefix, then any word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = new Set(exceptions.map((e) => e.toLowerCase()));

  return matches.filter((word) => !exceptionsLower.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookbehind to ensure the token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Lookbehind for a digit: (?<=\d)
  // This ensures the token is preceded by a digit
  // We want to match the digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (not letter or digit)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, abcabc, 123123)
  // A sequence is repeated if we find a pattern that repeats immediately
  // Use case-insensitive comparison
  const lowerValue = value.toLowerCase();
  for (let i = 0; i < lowerValue.length - 3; i++) {
    for (let len = 2; len <= (lowerValue.length - i) / 2; len++) {
      if (i + len * 2 > lowerValue.length) break;

      const pattern = lowerValue.slice(i, i + len);
      const nextOccurrence = lowerValue.slice(i + len, i + len * 2);

      if (pattern === nextOccurrence) {
        // Found a repeated sequence of length >= 2
        return false;
      }
    }
  }

  // Also check for simpler repetitions like aaaa, 1111, !!!!
  if (/(.)\1{3,}/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true if the value contains an IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Full form: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can appear once to replace consecutive zero groups
  // Can also include IPv4 mapped addresses (e.g., ::ffff:192.168.1.1)

  // First, let's define a comprehensive IPv6 pattern
  // This handles:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8:85a3::8a2e:370:7334
  // - Loopback: ::1
  // - All zeros: ::
  // - With embedded IPv4: ::ffff:192.168.1.1

  // Pattern breakdown:
  // - Hex digits: [0-9a-fA-F]{1,4}
  // - Groups separated by colons:
  // - :: for compression

  // Full pattern without compression (8 groups)

  // Pattern with :: compression (appears once)
  // This is tricky because :: can appear anywhere
  // We'll use a more permissive pattern and verify it's not IPv4

  // Main IPv6 pattern - allows :: compression
  // Matches sequences like:
  // - 2001::1
  // - ::1
  // - fe80::1%lo0
  // - 2001:db8::1:2:3

  // More comprehensive IPv6 regex
  const comprehensiveIpv6 =
    /((?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|((?:[0-9A-Fa-f]{1,4}:){1,7}:)|((?:[0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4})|((?:[0-9A-Fa-f]{1,4}:){1,5}(?::[0-9A-Fa-f]{1,4}){1,2})|((?:[0-9A-Fa-f]{1,4}:){1,4}(?::[0-9A-Fa-f]{1,4}){1,3})|((?:[0-9A-Fa-f]{1,4}:){1,3}(?::[0-9A-Fa-f]{1,4}){1,4})|((?:[0-9A-Fa-f]{1,4}:){1,2}(?::[0-9A-Fa-f]{1,4}){1,5})|(?:[0-9A-Fa-f]{1,4}:(?::[0-9A-Fa-f]{1,4}){1,6})|(?:::(?::[0-9A-Fa-f]{1,4}){1,7})|(?:(?:[0-9A-Fa-f]{1,4}:){1,7}:)|::(?:(?:[0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})?|(?:[0-9A-Fa-f]{1,4}:){1,7}:(?::\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})?|:(?::\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/;

  // Also check for IPv4-mapped IPv6 addresses
  const ipv4MappedPattern = /::[fF]{4}:(?:\d{1,3}\.){3}\d{1,3}/;

  // Make sure we're not matching plain IPv4 addresses
  const ipv4Pattern = /^(?:(?:\d{1,3}\.){3}\d{1,3})(?::\d+)?$/;

  // First check if it's a plain IPv4 address - if so, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Check for IPv6 patterns
  if (
    comprehensiveIpv6.test(value) ||
    ipv4MappedPattern.test(value) ||
    /::1/.test(value) ||
    /^::$/.test(value.trim())
  ) {
    // Additional validation: ensure it contains colons (IPv6 must have colons)
    if (value.includes(':')) {
      return true;
    }
  }

  return false;
}
