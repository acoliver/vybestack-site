export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant-ish pattern that rejects common invalid forms
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for invalid patterns
  const [localPart, domain] = value.split('@');

  // No double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }

  // No trailing dot in local part
  if (localPart.endsWith('.')) {
    return false;
  }

  // No trailing dot in domain
  if (domain.endsWith('.')) {
    return false;
  }

  // No leading dot in local part
  if (localPart.startsWith('.')) {
    return false;
  }

  // No leading dot in domain (after splitting by dots, first label shouldn't be empty)
  if (domain.startsWith('.')) {
    return false;
  }

  // Domain labels should not contain underscores (not valid in domain names)
  if (/_/.test(domain)) {
    return false;
  }

  // Each domain label should be valid
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    // Labels must start and end with alphanumeric
    if (!/^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]$/.test(label) && !/^[a-zA-Z0-9]$/.test(label)) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(_value: string): boolean {
  // Normalize: strip spaces, dashes, dots, parentheses
  const normalized = _value.replace(/[\s.\-()]/g, '');

  // Check for optional +1 country code
  let digits = normalized;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    // Also accept leading 1 without plus
    digits = digits.slice(1);
  }

  // US phone numbers (without country code) are exactly 10 digits
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens)
  const cleaned = value.replace(/[\s-]/g, '');

  // Argentine phone regex breakdown:
  // ^\+?54? - Optional +54 country code
  // (\s*0)? - Optional trunk prefix 0 (must come after country code if both present)
  // (\s*9)? - Optional mobile indicator 9
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits total

  // First, let's try to extract the core digits and validate structure

  // Remove leading + if present
  let workStr = cleaned;
  if (workStr.startsWith('+')) {
    workStr = workStr.slice(1);
  }

  // Extract country code (54) if present
  let hasCountryCode = false;
  if (workStr.startsWith('54')) {
    hasCountryCode = true;
    workStr = workStr.slice(2);
  }

  // Extract trunk prefix (0) if present
  let hasTrunkPrefix = false;
  if (workStr.startsWith('0')) {
    hasTrunkPrefix = true;
    workStr = workStr.slice(1);
  }

  // Extract mobile indicator (9) if present
  if (workStr.startsWith('9')) {
    workStr = workStr.slice(1);
  }

  // What remains should be area code + subscriber number
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  // Total remaining: 8-12 digits

  if (!/^\d{8,12}$/.test(workStr)) {
    return false;
  }

  // Find where area code ends
  // Area code is 2-4 digits, subscriber is 6-8 digits
  // Try to split: area code can be 2, 3, or 4 digits
  const remainingLength = workStr.length;

  // After removing country code (if present), trunk prefix (if present), and mobile indicator (if present),
  // we need 8-12 digits total (area code + subscriber)
  // Subscriber is always 6-8 digits, area code is 2-4 digits

  let areaCode: string;
  let subscriber: string;

  // Try different area code lengths
  if (remainingLength >= 8 && remainingLength <= 12) {
    // If total is 8-9, area code is likely 2-3 digits
    // If total is 10-12, area code is likely 2-4 digits

    // Determine area code length based on remaining
    // subscriber must be 6-8 digits
    const possibleAreaLengths = [2, 3, 4];
    let valid = false;

    for (const areaLen of possibleAreaLengths) {
      if (remainingLength - areaLen >= 6 && remainingLength - areaLen <= 8) {
        areaCode = workStr.slice(0, areaLen);
        subscriber = workStr.slice(areaLen);

        // Validate area code: 2-4 digits, leading digit 1-9
        if (/^[1-9]\d{1,3}$/.test(areaCode) && /^\d{6,8}$/.test(subscriber)) {
          valid = true;
          break;
        }
      }
    }

    if (!valid) {
      return false;
    }
  } else {
    return false;
  }

  // If country code is omitted, trunk prefix must be present
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and "X Æ A-12" style names (with digits).
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and names like "X Æ A-12"

  // Check for any digits first
  if (/\d/.test(value)) {
    return false;
  }

  // Basic pattern: unicode letters, spaces, apostrophes, hyphens
  // Must have at least one letter
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }

  // Check for problematic symbols (anything that's not a letter, space, apostrophe, or hyphen)
  // The regex above already handles this, but let's be extra careful
  // Reject specific problematic characters like @, #, $, %, etc.
  const invalidChars = /[@#$%^&*()_+=\\[\]{}|\\:;"<>?,./0-9]/;
  if (invalidChars.test(value)) {
    return false;
  }

  // Don't allow names that are only spaces, apostrophes, or hyphens
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm for credit card checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa, Mastercard, and AmEx.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check length and prefix for each card type
  // Visa: 13-16 digits, starts with 4
  const visaPattern = /^4\d{12,15}$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^(?:5[1-5]\d{14}|2[2-7][0-9]{13})$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;

  const validLengthAndPrefix =
    visaPattern.test(cleaned) ||
    mastercardPattern.test(cleaned) ||
    amexPattern.test(cleaned);

  if (!validLengthAndPrefix) {
    return false;
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
