/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if a string is valid Base64.
 * Using regex to check for valid Base64 alphabet without whitespace.
 */
function isValidBase64(input: string): boolean {
  // Base64 alphabet: A-Z, a-z, 0-9, +, /, and padding =
  // Also allow optional padding at the end
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8 with proper validation.
 * Accepts valid Base64 input with or without padding.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Check if input is valid Base64
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    // Add padding if needed (should be multiple of 4 characters)
    let normalizedInput = input;
    const paddingLength = (4 - (input.length % 4)) % 4;
    if (paddingLength > 0) {
      normalizedInput = input + '='.repeat(paddingLength);
    }

    // Use regular 'base64' encoding which handles the standard alphabet
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
