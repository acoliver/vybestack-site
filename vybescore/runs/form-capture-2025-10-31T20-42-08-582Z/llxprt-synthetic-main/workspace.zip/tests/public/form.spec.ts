import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
// Import our modules directly without importing the server itself
import { initializeDatabase, validateFormData, saveDatabase } from '../../src/server.js';

// ESM version of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import express from 'express';
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clear the database file for testing
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Initialize database for our tests
  await initializeDatabase();

  // Set up Express app for testing
  app = express();
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json()); // Add JSON middleware
  app.use(express.static(path.join(__dirname, '../../../public')));
  
  // Set up EJS view engine
  app.set('view engine', 'ejs');
  
  // Use a custom template resolution that works with our path structure
  const viewsPath = path.join(__dirname, '../../src/templates');
  app.set('views', viewsPath);
  
  // Print paths for debugging
  console.log('Testing - Views path:', viewsPath);
  console.log('Testing - Form template exists:', fs.existsSync(path.join(viewsPath, 'form.ejs')));
  console.log('Testing - Thank-you template exists:', fs.existsSync(path.join(viewsPath, 'thank-you.ejs')));

  // Set up routes for testing
  app.get('/', (req, res) => {
    const errors = [];
    const formData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    };

    res.render('form', { formData, errors });
  });

  app.post('/submit', (req, res) => {
    console.log('Request body in test:', JSON.stringify(req.body));
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const errors = validateFormData(formData);
    console.log('Validation errors in test:', errors);

    if (errors.length > 0) {
      res.status(400).render('form', { formData, errors });
      return;
    }

    // Save and redirect
    saveDatabase();
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}&lastName=${encodeURIComponent(formData.lastName)}`);
  });

  app.get('/thank-you', (req, res) => {
    res.render('thank-you', { 
      firstName: req.query.firstName || 'there',
      lastName: req.query.lastName || ''
    });
  });
});

afterAll(() => {
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    // For basic checks, we can use regex to verify the HTML structure
    const responseText = response.text;
    
    // Check for all required inputs
    expect(responseText).toContain('name="firstName"');
    expect(responseText).toContain('name="lastName"');
    expect(responseText).toContain('name="streetAddress"');
    expect(responseText).toContain('name="city"');
    expect(responseText).toContain('name="stateProvince"');
    expect(responseText).toContain('name="postalCode"');
    expect(responseText).toContain('name="country"');
    expect(responseText).toContain('name="email"');
    expect(responseText).toContain('name="phone"');
    
    // Check for labels with matching for attributes
    expect(responseText).toContain('for="firstName"');
    expect(responseText).toContain('for="lastName"');
    expect(responseText).toContain('for="streetAddress"');
    expect(responseText).toContain('for="city"');
    expect(responseText).toContain('for="stateProvince"');
    expect(responseText).toContain('for="postalCode"');
    expect(responseText).toContain('for="country"');
    expect(responseText).toContain('for="email"');
    expect(responseText).toContain('for="phone"');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit valid form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // If we got a 400 status, let's check what went wrong
    if (response.status === 400) {
      console.log('Request data was:', JSON.stringify(formData));
      console.log('Response status:', response.status);
      console.log('Response headers:', response.headers);
      console.log('Response text has errors:', response.text.includes('error'));
      
      // Fail with a better error message
      if (response.text) {
        // Extract error messages from response if available
        const errorMatch = response.text.match(/<li>(.*?)<\/li>/g);
        if (errorMatch && errorMatch.length > 0) {
          const errors = errorMatch.map(match => match.replace(/<\/?li>/g, ''));
          console.log('Validation errors:', errors);
        }
      }
    }
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created and data was saved
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check thank you page response
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    // Check that the thank-you page contains the expected content
    expect(thankYouResponse.text).toContain('Thank You');
  });

  it('handles invalid email validation', async () => {
    const invalidFormData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Side St',
      city: 'Otherville',
      stateProvince: 'Florida',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'not-a-valid-email',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(invalidFormData)
      .expect(400);
    
    // Should not redirect but render the form with errors
    expect(response.text).toContain('Please enter a valid email address');
  });
  
  it('handles required field validation', async () => {
    const incompleteFormData = {
      firstName: '',
      lastName: 'Johnson',
      streetAddress: '789 Something Ave',
      city: 'Someplace',
      stateProvince: 'Texas',
      postalCode: 'B1675',
      country: 'Argentina',
      email: 'test@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(incompleteFormData)
      .expect(400);
    
    // Should not redirect but render the form with errors
    expect(response.text).toContain('First Name is required');
  });
});
