// SQL.js wrapper for consistent import
declare const require: (id: string) => unknown;

export default async () => {
  const sqljs = require('sql.js') as unknown;
  return sqljs as () => Promise<{ Database: unknown }>;
};