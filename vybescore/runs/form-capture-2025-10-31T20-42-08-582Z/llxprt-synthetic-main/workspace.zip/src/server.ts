import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// Import sql.js wrapper
import sqljs from './sqljs-wrapper.js';

// ESM version of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Types for sql.js
interface Database {
  run(sql: string, ...params: unknown[]): void;
  export(): Uint8Array;
  close(): void;
  prepare(sql: string): Statement;
}

interface Statement {
  run(params?: unknown[]): void;
  free(): void;
}

// Form data type
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors type
interface ValidationError {
  field: string;
  message: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Export app for testing
export default app;

// Set up middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Global variables
let db: Database | null = null;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load or create database
    let fileBuffer: Uint8Array | null = null;
    if (fs.existsSync(DB_PATH)) {
      fileBuffer = fs.readFileSync(DB_PATH);
    }

    // Initialize SQL.js
    const sqljsInit = await sqljs();
    const SQL = await sqljsInit() as { Database: new (data?: Uint8Array) => Database };
    const { Database } = SQL;
    db = new Database(fileBuffer || undefined);

    // Run schema if database is new
    if (!fileBuffer) {
      const schema = fs.readFileSync(
        path.join(__dirname, '../db/schema.sql'),
        'utf8'
      );
      if (db) {
        db.run(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    if (process.env.NODE_ENV !== 'test') {
      process.exit(1);
    } else {
      // In test environment, don't exit the process, throw the error instead
      throw error;
    }
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;

  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      const fieldName = field
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, (str) => str.toUpperCase());
      errors.push({
        field,
        message: `${fieldName} is required.`,
      });
    }
  }

  // Email validation
  if (
    formData.email &&
    !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(formData.email)
  ) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address.',
    });
  }

  // Phone validation - accept international formats with +, digits, spaces, parentheses, dashes
  if (
    formData.phone &&
    !/^\\+?[0-9\\s()-]+$/.test(formData.phone)
  ) {
    errors.push({
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +.',
    });
  }

  // Postal validation - accept alphanumeric strings
  if (
    formData.postalCode &&
    !/^[a-zA-Z0-9\\s-]+$/.test(formData.postalCode)
  ) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code can only contain letters, digits, spaces, and dashes.',
    });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  const errors: ValidationError[] = [];
  const formData: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: '',
  };

  res.render('form', { formData, errors });
});

app.post('/submit', (req: Request, res: Response) => {
  // Debug print to see what req.body contains
  console.log('Request body received:', JSON.stringify(req.body));
  
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };
  
  // Debug print to see the formData after processing
  console.log('FormData after processing:', JSON.stringify(formData));

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400).render('form', { formData, errors });
    return;
  }

  // Save to database
  if (db) {
    try {
      const stmt = db.prepare(
        `INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]);
      
      stmt.free();
      saveDatabase();
    } catch (error) {
      console.error('Failed to save submission:', error);
      res.status(500).render('form', {
        formData,
        errors: [{ field: 'database', message: 'Failed to save submission. Please try again.' }],
      });
      return;
    }
  }

  // Redirect to thank you page with form data
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}&lastName=${encodeURIComponent(formData.lastName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    firstName: req.query.firstName || 'there',
    lastName: req.query.lastName || ''
  });
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });

  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    if (db) {
      db.close();
      console.log('Database closed');
    }
    server.close();
    console.log('Server closed');
    process.exit(0);
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  // Export for testing
  if (process.env.NODE_ENV === 'test') {
    (global as Record<string, unknown>).__SERVER__ = server;
    (global as Record<string, unknown>).__APP__ = app;
  }
}

// Export functions for testing
export { initializeDatabase, validateFormData, saveDatabase };

// Start the server only if not in test mode
if (!process.env.VITEST) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}