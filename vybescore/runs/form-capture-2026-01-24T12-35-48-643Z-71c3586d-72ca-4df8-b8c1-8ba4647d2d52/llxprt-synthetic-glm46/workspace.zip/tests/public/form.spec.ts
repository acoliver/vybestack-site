import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { createApp } from '../../src/server.js';
import { closeDatabase } from '../../src/database.js';
import type { Express } from 'express';

let server: Express | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Create app with Express for testing
  const app = await createApp();
  
  // Start the server on a random port
  server = app.listen(0);
});

afterAll(() => {
  if (server) {
    server.close();
  }
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
