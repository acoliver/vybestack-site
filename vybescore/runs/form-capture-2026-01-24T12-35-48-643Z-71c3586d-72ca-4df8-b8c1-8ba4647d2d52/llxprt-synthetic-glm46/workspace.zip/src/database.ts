import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import initSqlJs, { Database } from 'sql.js';


let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs();
    
    const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
    
    let dbExists = false;
    try {
      readFileSync(dbPath);
      dbExists = true;
    } catch {
      // Database file doesn't exist yet
    }
    
    let fileBuffer;
    if (dbExists) {
      fileBuffer = readFileSync(dbPath);
    } else {
      fileBuffer = new Uint8Array(0);
    }
    
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    db = new SQL.Database(fileBuffer);
    
    // Create the submissions table if it doesn't exist
    const schemaPath = join(process.cwd(), 'db', 'schema.sql');
    const schema = readFileSync(schemaPath, 'utf-8');
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    db!.exec(schema);
    
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    return db!;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const data = db.export();
    const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
    writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export {
  initializeDatabase,
  saveDatabase,
  getDatabase,
  closeDatabase
};