export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  sanitizedValues: FormSubmission;
}

export function validateForm(input: Record<string, string>): ValidationResult {
  const errors: string[] = [];
  const sanitizedValues: FormSubmission = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };

  // First name validation
  if (!input.firstName || input.firstName.trim().length === 0) {
    errors.push('First name is required');
  } else {
    sanitizedValues.firstName = input.firstName.trim();
  }

  // Last name validation
  if (!input.lastName || input.lastName.trim().length === 0) {
    errors.push('Last name is required');
  } else {
    sanitizedValues.lastName = input.lastName.trim();
  }

  // Street address validation
  if (!input.streetAddress || input.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  } else {
    sanitizedValues.streetAddress = input.streetAddress.trim();
  }

  // City validation
  if (!input.city || input.city.trim().length === 0) {
    errors.push('City is required');
  } else {
    sanitizedValues.city = input.city.trim();
  }

  // State/Province validation
  if (!input.stateProvince || input.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  } else {
    sanitizedValues.stateProvince = input.stateProvince.trim();
  }

  // Postal code validation (allow alphanumeric)
  if (!input.postalCode || input.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else {
    const postalCode = input.postalCode.trim();
    // Allow letters, numbers, spaces, and dashes (international formats)
    if (!/^[A-Za-z0-9\s-]+$/.test(postalCode)) {
      errors.push('Postal / Zip code contains invalid characters');
    } else {
      sanitizedValues.postalCode = postalCode;
    }
  }

  // Country validation
  if (!input.country || input.country.trim().length === 0) {
    errors.push('Country is required');
  } else {
    sanitizedValues.country = input.country.trim();
  }

  // Email validation
  if (!input.email || input.email.trim().length === 0) {
    errors.push('Email is required');
  } else {
    const email = input.email.trim();
    // Simple email regex
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errors.push('Email format is invalid');
    } else {
      sanitizedValues.email = email;
    }
  }

  // Phone validation (allow international formats)
  if (!input.phone || input.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else {
    const phone = input.phone.trim();
    // Allow digits, spaces, parentheses, dashes, and a leading +
    if (!/^[+\d\s\-()]+$/.test(phone)) {
      errors.push('Phone number contains invalid characters');
    } else {
      sanitizedValues.phone = phone;
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitizedValues
  };
}