import { join } from 'path';
import { fileURLToPath } from 'url';
import express, { Express, Request, Response, NextFunction } from 'express';
import { initializeDatabase, saveDatabase, getDatabase, closeDatabase } from './database.js';
import { validateForm } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = join(__filename, '..');

process.env.NODE_ENV = process.env.NODE_ENV || 'development';

let app: Express;

async function createApp(): Promise<Express> {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization failed:', error);
    process.exit(1);
  }

  app = express();
  
  app.use('/public', express.static(join(__dirname, '..', 'public')));
  app.use(express.urlencoded({ extended: true }));
  
  app.set('view engine', 'ejs');
  app.set('views', join(__dirname, 'templates'));

  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      title: 'Friendly Contact Form',
      errors: [],
      values: {}
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const validationResult = validateForm(req.body);
    
    if (!validationResult.isValid) {
      return res.status(400).render('form', {
        title: 'Friendly Contact Form',
        errors: validationResult.errors,
        values: req.body
      });
    }

    try {
      const db = getDatabase();
      
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        validationResult.sanitizedValues.firstName,
        validationResult.sanitizedValues.lastName,
        validationResult.sanitizedValues.streetAddress,
        validationResult.sanitizedValues.city,
        validationResult.sanitizedValues.stateProvince,
        validationResult.sanitizedValues.postalCode,
        validationResult.sanitizedValues.country,
        validationResult.sanitizedValues.email,
        validationResult.sanitizedValues.phone
      ]);
      
      stmt.free();
      saveDatabase();
      
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        title: 'Friendly Contact Form',
        errors: ['An unexpected error occurred. Please try again.'],
        values: req.body
      });
}
});

app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { 
      title: 'Thank You!',
      firstName
    });
  });

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
    console.error('Unhandled error:', err);
    res.status(500).render('form', {
      title: 'Friendly Contact Form',
      errors: ['An unexpected error occurred. Please try again.'],
      values: {}
    });
  });

  return app;
}

export async function startServer(): Promise<void> {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  const app = await createApp();
  
  const server = app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });

  const gracefulShutdown = (signal: string) => {
    console.log(`\nReceived ${signal}. Closing server gracefully...`);
    
    server.close(() => {
      console.log('HTTP server closed');
      closeDatabase();
      console.log('Database connection closed');
      process.exit(0);
    });

    setTimeout(() => {
      console.error('Forced shutdown');
      process.exit(1);
    }, 5000);
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Export the createApp function for tests
export { createApp };

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
