/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Reactive,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const reactive: Reactive<T> = {
    name: options?.name,
    kind: 'input',
    observers: new Set(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) registerDependency(reactive, observer)
    return reactive.value
  }

  const write: SetterFn<T> = (nextValue) => {
    reactive.value = nextValue
    notifyDependents(reactive)
    return reactive.value
  }

  return [read, write]
}
