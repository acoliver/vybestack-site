/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Reactive,
  EqualFn,
  getActiveObserver,
  registerDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const reactive: Reactive<T> = {
    name: options?.name,
    kind: 'computed',
    observers: new Set(),
    value: value!,
    updateFn,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(reactive, observer)
    }
    // Recompute the value and store it
    const newValue = reactive.updateFn!(undefined)
    reactive.value = newValue
    return newValue
  }
}
