/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create a standard Observer
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }

  // Immediately execute the callback to register dependencies and perform initial side effects
  // Set this observer as the active observer so dependencies can register
  updateObserver(observer)

  // Return unsubscribe function that clears the update function
  return () => {
    observer.updateFn = () => value!
    observer.value = value
  }
}
