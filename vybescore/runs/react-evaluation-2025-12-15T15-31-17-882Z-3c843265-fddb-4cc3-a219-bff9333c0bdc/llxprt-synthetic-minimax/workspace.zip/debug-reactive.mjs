import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Debug Reactive System ===')

// Test case from failing test
console.log('\n1. Testing callback fire on dependency change:')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0

console.log('Initial input:', input())
console.log('Initial output:', output())

// Create callback
console.log('\nCreating callback...')
createCallback(() => {
  value = output()
  console.log('Callback fired! value =', value)
  return value
})

console.log('After callback creation, value:', value)

// Change input
console.log('\nChanging input to 3...')
setInput(3)

console.log('After input change:')
console.log('Input value:', input())
console.log('Output value:', output())
console.log('Callback value:', value)

console.log('\nExpected callback value: 4')
console.log('Actual callback value:', value)