import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 1) {
    throw new Error('Missing required argument: <data.json>');
  }
  
  const dataFile = args[0];
  
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i + 1] as 'markdown' | 'text';
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!format) {
    throw new Error('Missing required argument: --format');
  }
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  return { dataFile, format, output, includeTotals };
}

function readAndParseData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}] missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}] missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      }
      throw error;
    }
    throw new Error(`Failed to read data file: ${filePath}`);
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content + '\n', 'utf-8');
  } else {
    process.stdout.write(content + '\n');
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    const data = readAndParseData(args.dataFile);
    const output = renderReport(data, args.format, args.includeTotals);
    writeOutput(output, args.output);
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('An unexpected error occurred');
      process.exit(1);
    }
  }
}

main();
