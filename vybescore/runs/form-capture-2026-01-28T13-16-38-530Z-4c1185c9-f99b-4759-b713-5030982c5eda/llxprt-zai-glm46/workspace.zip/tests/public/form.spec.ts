import { describe, expect, it } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const html = response.text || response.body;
    const $ = cheerio.load(html);
    
    // Check form exists
    expect($('form[action="/submit"]').length).toBe(1);
    
    // Check all input fields exist with proper labels
    const fields = [
      { input: '#firstName', label: 'First name' },
      { input: '#lastName', label: 'Last name' },
      { input: '#streetAddress', label: 'Street address' },
      { input: '#city', label: 'City' },
      { input: '#stateProvince', label: 'State / Province / Region' },
      { input: '#postalCode', label: 'Postal / Zip code' },
      { input: '#country', label: 'Country' },
      { input: '#email', label: 'Email' },
      { input: '#phone', label: 'Phone number' }
    ];
    
    for (const field of fields) {
      expect($(field.input).length).toBe(1);
      expect($(`label[for="${field.input.slice(1)}"]`).text().trim()).toBe(field.label);
    }
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow redirect and check thank-you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
  });

  it('validates required fields and re-renders form with errors', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: 'invalid-email',
        phone: ''
      });
    
    // Should return 400 and re-render form
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email must be valid');
  });

  it('accepts international phone formats', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 High Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts various postal code formats', async () => {
    const testCases = [
      { postalCode: 'SW1A 1AA', country: 'UK' },
      { postalCode: 'C1000', country: 'Argentina' },
      { postalCode: 'B1675', country: 'Argentina' },
      { postalCode: '12345', country: 'US' }
    ];
    
    for (const testCase of testCases) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: testCase.postalCode,
        country: testCase.country,
        email: 'test@example.com',
        phone: '+1 555-123-4567'
      };
      
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);
      
      expect(response.status).toBe(302);
    }
  });
});
