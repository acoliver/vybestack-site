/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws meaningful errors for invalid Base64.
 */
export function decode(input: string): string {
  const normalized = input.trim();
  
  // Basic validation for Base64 format
  if (normalized.length === 0) {
    throw new Error('Input cannot be empty');
  }
  
  // Check for valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Ensure proper padding if not already present
  let padded = normalized;
  const mod = normalized.length % 4;
  if (mod === 2) {
    padded += '==';
  } else if (mod === 3) {
    padded += '=';
  } else if (mod !== 0) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }
  
  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
