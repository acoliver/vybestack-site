import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      if (!/^\d+$/.test(pageParam)) {
        res.status(400).json({ error: 'Page parameter must be a positive integer' });
        return;
      }
      const page = Number(pageParam);
      if (page <= 0) {
        res.status(400).json({ error: 'Page parameter must be greater than 0' });
        return;
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      if (!/^\d+$/.test(limitParam)) {
        res.status(400).json({ error: 'Limit parameter must be a positive integer' });
        return;
      }
      const limit = Number(limitParam);
      if (limit <= 0) {
        res.status(400).json({ error: 'Limit parameter must be greater than 0' });
        return;
      }
      if (limit > MAX_LIMIT) {
        res.status(400).json({ error: `Limit parameter cannot exceed ${MAX_LIMIT}` });
        return;
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
