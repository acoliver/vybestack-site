declare module "sql.js" {
  export interface Database {
    prepare(sql: string): Statement;
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }

  interface DatabaseExports {
    Database: new(data?: ArrayBuffer) => Database;
  }
  
  export default function initSqlJs(options?: Record<string, string>): Promise<typeof DatabaseExports>;
}