import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs/promises";
import initSqlJs from "sql.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, "..", "data", "submissions.sqlite");

const port = process.env.PORT || 3535;

let db: import("sql.js").Database;
let isShuttingDown = false;

// Initialize express app
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use("/public", express.static(path.join(__dirname, "..", "public")));

// Set EJS as the template engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "..", "src", "templates"));

// Initialize database
async function initializeDatabase() {
  try {
    // Ensure data directory exists
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    
    // Load SQLite
    const SQL = await initSqlJs();
    
    // Try to load existing database
    let exists;
    try {
      await fs.access(dbPath);
      exists = true;
    } catch {
      exists = false;
    }
    
    if (exists) {
      const dbFile = await fs.readFile(dbPath);
      db = new SQL.Database(dbFile);
      console.log("Loaded existing database from", dbPath);
    } else {
      db = new SQL.Database();
      const schema = await fs.readFile(
        path.join(__dirname, "..", "db", "schema.sql"),
        "utf8"
      );
      db.run(schema);
      
      // Save the newly created database
      const data = db.export();
      await fs.writeFile(dbPath, Buffer.from(data));
      console.log("Created new database at", dbPath);
    }
  } catch (error) {
    console.error("Failed to initialize database:", error);
    throw error;
  }
}

// Save database to disk
async function saveDatabase() {
  if (db && !isShuttingDown) {
    try {
      const data = db.export();
      await fs.writeFile(dbPath, Buffer.from(data));
    } catch (error) {
      console.error("Failed to save database:", error);
    }
  }
}

// Define form data type
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Validation function
function validateSubmission(formData: FormData): string[] {
  const errors: string[] = [];
  
  // Required fields
  if (!formData.firstName?.trim()) {
    errors.push("First name is required");
  }
  if (!formData.lastName?.trim()) {
    errors.push("Last name is required");
  }
  if (!formData.streetAddress?.trim()) {
    errors.push("Street address is required");
  }
  if (!formData.city?.trim()) {
    errors.push("City is required");
  }
  if (!formData.stateProvince?.trim()) {
    errors.push("State/Province/Region is required");
  }
  if (!formData.postalCode?.trim()) {
    errors.push("Postal/Zip code is required");
  }
  if (!formData.country?.trim()) {
    errors.push("Country is required");
  }
  if (!formData.email?.trim()) {
    errors.push("Email is required");
  }
  if (!formData.phone?.trim()) {
    errors.push("Phone number is required");
  }
  
  // Email validation (simple regex)
  if (
    formData.email &&
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)
  ) {
    errors.push("Please enter a valid email address");
  }
  
  // Phone validation (allows digits, spaces, parentheses, dashes, and leading +)
  if (
    formData.phone &&
    ! /^[+\d\s()-]+$/.test(formData.phone)
  ) {
    errors.push("Phone number format is invalid");
  }
  
  // Postal code validation (alphanumeric)
  if (
    formData.postalCode &&
    !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)
  ) {
    errors.push("Postal code format is invalid");
  }
  
  return errors;
}

// Routes
app.get("/", (req, res) => {
  res.render("form", {
    errors: [],
    values: {},
  });
});

app.post("/submit", async (req, res) => {
  const formData = req.body as FormData;
  const errors = validateSubmission(formData);
  
  if (errors.length > 0) {
    // Validation failed, re-render form with errors
    return res.status(400).render("form", {
      errors,
      values: formData,
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    
    stmt.free();
    
    // Save database to disk
    await saveDatabase();
    
    // Redirect to thank you page
    res.redirect("/thank-you");
  } catch (error) {
    console.error("Error saving submission:", error);
    res.status(500).render("form", {
      errors: ["An unexpected error occurred. Please try again."],
      values: formData,
    });
  }
});

app.get("/thank-you", (req, res) => {
  // For now, we'll just render the thank-you page
  // In a real app, we might retrieve the user's name from session or DB
  res.render("thank-you", {
    firstName: "Friend", // Default name since we're not using sessions
  });
});

// Health check endpoint
app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok" });
});

// Graceful shutdown
async function shutdown() {
  console.log("Shutting down gracefully...");
  isShuttingDown = true;
  
  if (db) {
    await saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

// Start the server
async function startServer() {
  try {
    await initializeDatabase();
    
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Set up graceful shutdown handlers
    process.on("SIGTERM", async () => {
      server.close(() => {
        shutdown();
      });
    });
    
    process.on("SIGINT", async () => {
      server.close(() => {
        shutdown();
      });
    });
    
    return server;
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

// Start_server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
