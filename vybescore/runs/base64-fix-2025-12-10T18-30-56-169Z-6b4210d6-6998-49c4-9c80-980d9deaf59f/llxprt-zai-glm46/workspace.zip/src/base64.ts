/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string.
 * @param input The Base64 string to validate
 * @throws Error if the input contains invalid Base64 characters or has invalid length
 */
function validateBase64Input(input: string): void {
  if (input.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  // Remove padding for validation purposes
  const unpadded = input.replace(/=+$/, '');
  
  // Check if the unpadded string contains only valid Base64 characters
  const base64Pattern = /^[A-Za-z0-9+/]*$/;
  if (!base64Pattern.test(unpadded)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }
  
  // Check if the unpadded length is valid (Base64 without padding must have length % 4 != 1)
  if (unpadded.length % 4 === 1) {
    throw new Error('Invalid Base64 input: incorrect length');
  }
  
  // Ensure padding is correct (can only appear at the end and max 2 characters)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }
}

/**
 * Decode Base64 text back to plain UTF-8 with proper validation.
 * @param input Valid Base64 string (with or without padding)
 * @returns The decoded UTF-8 string
 * @throws Error if the input is invalid Base64
 */
export function decode(input: string): string {
  // Validate input format first
  validateBase64Input(input);
  
  try {
    // Add proper padding if missing
    const padded = input.padEnd(Math.ceil(input.length / 4) * 4, '=');
    const result = Buffer.from(padded, 'base64').toString('utf8');
    
    // Additional validation: if the result contains replacement characters, the input was invalid
    if (result.includes('\uFFFD')) {
      throw new Error('Failed to decode Base64 input: invalid format');
    }
    
    return result;
  } catch (error) {
    // If Buffer.from fails even with proper padding, it's likely invalid Base64
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
