/**
 * Public exports for the reactive programming system.
 */

export { createInput } from './core/input.js'
export { createComputed } from './core/computed.js'
export { createCallback } from './core/callback.js'

export type {
  EqualFn,
  GetterFn,
  SetterFn,
  UnsubscribeFn,
  UpdateFn,
  InputPair,
  Options,
  ObserverR,
  ObserverV,
  Observer,
  SubjectR,
  SubjectV,
  Subject
} from './types/reactive.js'

// Internal functions for dependency tracking
export { 
  updateObserver,
  registerDependency,
  notifySubjectChange,
  clearObserver
} from './types/reactive.js'
