/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Internal tracking types
interface ObserverWithDeps extends ObserverR {
  dependencies?: Set<Subject<unknown>>
  dependents?: Set<ObserverR>
}

interface SubjectWithDeps<T> extends Subject<T> {
  dependents?: Set<ObserverR>
}

// Use a stack instead of single variable to handle nested calls
const observerStack: ObserverR[] = []

export function getActiveObserver(): ObserverR | undefined {
  return observerStack[observerStack.length - 1]
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Push current observer onto stack
  observerStack.push(observer)
  
  try {
    observer.value = observer.updateFn(observer.value)
    
    // Notify dependents that this observer's value has changed
    const dependents = (observer as ObserverWithDeps).dependents
    if (dependents && dependents.size > 0) {
      // Use the existing subject if the observer has one linked to it
      const existingSubject = (observer as any).subject
      if (existingSubject) {
        existingSubject.value = observer.value
        notifySubjectChange(existingSubject)
      } else {
        // Fallback to creating a temporary subject
        const subject = {
          name: observer.name,
          value: observer.value,
          observer: undefined,
          equalFn: undefined
        } as Subject<T>
        notifySubjectChange(subject)
      }
    }
  } finally {
    // Pop current observer from stack
    observerStack.pop()
  }
}

export function registerDependency<T>(subject: Subject<T>, observer: ObserverR): void {
  // Store the subject as the observer's dependency
  const obsWithDeps = observer as ObserverWithDeps
  obsWithDeps.dependencies = obsWithDeps.dependencies || new Set()
  obsWithDeps.dependencies.add(subject as Subject<unknown>)
  
  // Store the observer as a dependent of the subject  
  const subjWithDeps = subject as SubjectWithDeps<T>
  subjWithDeps.dependents = subjWithDeps.dependents || new Set()
  subjWithDeps.dependents.add(observer)
  
  // Also store the observer in the subject's observer field if it's empty
  if (!subject.observer) {
    subject.observer = observer
  }
  
  // If the observer has a subject linked to it, also register the reverse relationship
  const observerSubject = (observer as any).subject
  if (observerSubject) {
    const observerSubjWithDeps = observerSubject as SubjectWithDeps<unknown>
    observerSubjWithDeps.dependents = observerSubjWithDeps.dependents || new Set()
    observerSubjWithDeps.dependents.add(observer)
  }
}

export function notifySubjectChange<T>(subject: Subject<T>): void {
  const subjectDependents = (subject as SubjectWithDeps<T>).dependents
  if (subjectDependents) {
    // Create a copy of the set to avoid modification during iteration
    const observersToUpdate = new Set(subjectDependents)
    for (const observer of observersToUpdate) {
      // Check if observer is still a valid dependent
      if (subjectDependents.has(observer)) {
        // Check if this is a callback observer
        const observerWithCallback = observer as any
        if (observerWithCallback.isCallback && observerWithCallback.originalFn) {
          // For callbacks, execute the original function directly
          // This bypasses dependency tracking during re-execution
          observerWithCallback.originalFn((observer as Observer<unknown>).value)
        } else {
          // For other observers, use normal updateObserver flow
          updateObserver(observer as Observer<unknown>)
        }
      }
    }
  }
}

export function clearObserver(observer: ObserverR): void {
  const obsWithDeps = observer as ObserverWithDeps
  const dependencies = obsWithDeps.dependencies
  if (dependencies) {
    // Remove this observer from all subject's dependent sets
    for (const subject of dependencies) {
      const subjectDependents = (subject as SubjectWithDeps<unknown>).dependents
      if (subjectDependents) {
        subjectDependents.delete(observer)
      }
    }
  }
}
