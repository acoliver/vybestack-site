/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerDependency,
  notifySubjectChange,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  // Handle the equal parameter
  if (equal === true) {
    s.equalFn = (a, b) => a === b
  } else if (typeof equal === 'function') {
    s.equalFn = equal
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as depending on this subject
      registerDependency(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasEqual = s.equalFn && s.equalFn(s.value, nextValue)
    
    if (hasEqual) {
      // Values are equal, no need to update
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers that depend on this subject
    notifySubjectChange(s)
    
    return s.value
  }

  return [read, write]
}
