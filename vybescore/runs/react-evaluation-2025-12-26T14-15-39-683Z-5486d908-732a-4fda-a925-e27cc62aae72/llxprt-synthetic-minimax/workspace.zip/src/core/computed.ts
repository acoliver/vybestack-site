/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  notifySubjectChange,
  registerDependency,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Initialize observer value if not provided
  const initialValue = value !== undefined ? value : undefined
  
  const observer: Observer<T> = {
    name: options?.name,
    value: initialValue,
    updateFn,
  }

  // Create a subject that can be used for dependency tracking
  const subjectValue = value !== undefined ? value : observer.value
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: subjectValue!,
    equalFn: undefined,
  }

  // Link observer and subject together
  ;(observer as any).subject = subject
  subject.observer = observer

  const getter: GetterFn<T> = () => {
    // Check if there's an active observer that depends on this computed value
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register dependency: this computed subject is used by the active observer
      registerDependency(subject, activeObserver)
    }
    
    const previousValue = observer.value
    
    // Update the observer which tracks dependencies
    updateObserver(observer)
    
    // Handle the case where observer.value might be undefined
    const newValue = observer.value as T
    
    // Only notify dependents if the value actually changed
    if (newValue !== previousValue) {
      subject.value = newValue
      notifySubjectChange(subject)
    }
    
    return newValue
  }
  
  // Attach computed-specific properties to the getter
  const computedGetter = getter as GetterFn<T> & {
    isComputed: true
    subject: Subject<T>
    registerDependency: (obs: Observer<unknown>) => void
  }
  
  computedGetter.isComputed = true
  computedGetter.subject = subject
  computedGetter.registerDependency = (obs: Observer<unknown>) => {
    registerDependency(subject, obs)
  }
  
  return computedGetter
}
