/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  clearObserver,
  updateObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Store the original function for re-execution
  const originalFn = updateFn
  
  // Mark this observer as a callback so it can be handled specially
  const callbackObserver = observer as any
  callbackObserver.originalFn = originalFn
  callbackObserver.isCallback = true
  
  // Execute callback to establish dependencies and set initial value
  updateObserver(observer)
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear observer from dependency tracking
    clearObserver(observer)
  }
  
  return unsubscribe
}
