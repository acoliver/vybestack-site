/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine the equality function based on the 'equal' parameter
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'boolean' 
      ? equal 
        ? (lhs: T, rhs: T) => lhs === rhs 
        : undefined
      : equal

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value is the same using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify observer if it exists
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}