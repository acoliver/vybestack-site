/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine the equality function based on the 'equal' parameter
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'boolean' 
      ? equal 
        ? (lhs: T, rhs: T) => lhs === rhs 
        : undefined
      : equal

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Update computed value immediately
  updateObserver(o)

  const read: GetterFn<T> = () => {
    // Track the active observer as a dependency when this computed is read
    const observer = getActiveObserver()
    return o.value!
  }

  return read
}