#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): CliOptions {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  const args = argv.slice(3);
  
  let format: CliOptions['format'] | null = null;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1] as CliOptions['format'];
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++; // Skip next argument as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!dataFile) {
    console.error('Error: data file path is required');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format parameter is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return {
    dataFile,
    format,
    output,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(rawData);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (must be an array)');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'label' field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'amount' field`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${filePath}': ${error.message}`);
    } else if (error instanceof Error && error.message.startsWith('ENOENT')) {
      console.error(`Error: File not found '${filePath}'`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Unknown error occurred while reading '${filePath}'`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: CliOptions['format'], includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown.render(data, includeTotals);
    case 'text':
      return renderText.render(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  const options = parseArguments(process.argv);
  const data = loadReportData(options.dataFile);
  const output = renderReport(data, options.format, options.includeTotals);

  if (options.output) {
    try {
      writeFileSync(options.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${options.output}': ${error}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();