import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, PaginationValidationError } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const page = pageParam ? Number(pageParam) : undefined;
      const limit = limitParam ? Number(limitParam) : undefined;

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof PaginationValidationError) {
        res.status(400).json({ error: error.message });
      } else {
        console.error('Error fetching inventory:', error);
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  });

  return app;
}
