import express, { type Request, type Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

interface Database {
  run(sql: string, params?: (string | number)[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface StatementOptions {
  run(params?: (string | number)[]): void;
  free(): void;
}

type Statement = StatementOptions;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private readonly dbPath: string;

  constructor() {
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const data = fs.readFileSync(this.dbPath);
        const arrayBuffer = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
        this.db = new SQL.Database(arrayBuffer);
      } else {
        this.db = new SQL.Database();
        await this.createTables();
      }

      // Initialize tables if they don't exist
      await this.createTables();
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = fs.readFileSync(
      path.join(__dirname, '..', 'db', 'schema.sql'), 
      'utf8'
    );
    
    // Split and execute schema statements
    const statements = schema
      .split(';')
      .filter(stmt => stmt.trim())
      .map(stmt => stmt.trim());

    for (const statement of statements) {
      try {
        this.db.run(statement);
      } catch (error) {
        console.warn('Schema statement failed (might already exist):', statement, error);
      }
    }
  }

  async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone
      ]);
    } finally {
      stmt.free();
    }

    // Save database back to disk
    await this.saveToDisk();
  }

  private async saveToDisk(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

class FormValidator {
  static validate(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim().length === 0) {
        errors.push({
          field,
          message: `${this.getFieldName(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation - allow international formats
    if (data.phone) {
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading +)'
        });
      }
    }

    // Postal code validation - alphanumeric
    if (data.postalCode) {
      const postalRegex = /^[a-zA-Z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal/zip code (letters, numbers, spaces, and dashes allowed)'
        });
      }
    }

    return errors;
  }

  private static getFieldName(field: keyof FormData): string {
    const names: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return names[field] || field;
  }
}

async function createServer(): Promise<{ app: express.Express; server: import('http').Server }> {
  const app = express();
  const db = new DatabaseManager();

  // Initialize database
  await db.initialize();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));

  // Set up EJS
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  // Routes
  app.get('/', (_req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });

  app.post('/submit', async (req: Request, res: Response) => {
    try {
      const formData: FormData = {
        firstName: req.body.firstName?.trim() || '',
        lastName: req.body.lastName?.trim() || '',
        streetAddress: req.body.streetAddress?.trim() || '',
        city: req.body.city?.trim() || '',
        stateProvince: req.body.stateProvince?.trim() || '',
        postalCode: req.body.postalCode?.trim() || '',
        country: req.body.country?.trim() || '',
        email: req.body.email?.trim() || '',
        phone: req.body.phone?.trim() || ''
      };

      const errors = FormValidator.validate(formData);

      if (errors.length > 0) {
        res.status(400).render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
        return;
      }

      // Save to database
      await db.insertSubmission(formData);

      // Redirect to thank you page
      res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    } catch (error) {
      console.error('Error submitting form:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while processing your submission. Please try again.'],
        values: req.body
      });
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  });

  // Start server
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down server...');
    server.close(() => {
      db.close();
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return { app, server };
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  createServer().catch(console.error);
}

export { createServer };
