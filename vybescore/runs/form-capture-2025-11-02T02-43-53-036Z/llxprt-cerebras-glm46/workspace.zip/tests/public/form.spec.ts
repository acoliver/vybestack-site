import express from 'express';
import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from '../../src/server.js';

let server: import('http').Server;
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await createServer();
  app = result.app;
  server = result.server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check form exists
    expect($('form[method="post"][action="/submit"]').length).toBe(1);
    
    // Check all required fields exist with correct labels and inputs
    const expectedFields = [
      { id: 'firstName', label: 'First name', name: 'firstName' },
      { id: 'lastName', label: 'Last name', name: 'lastName' },
      { id: 'streetAddress', label: 'Street address', name: 'streetAddress' },
      { id: 'city', label: 'City', name: 'city' },
      { id: 'stateProvince', label: 'State / Province / Region', name: 'stateProvince' },
      { id: 'postalCode', label: 'Postal / Zip code', name: 'postalCode' },
      { id: 'country', label: 'Country', name: 'country' },
      { id: 'email', label: 'Email', name: 'email' },
      { id: 'phone', label: 'Phone number', name: 'phone' }
    ];
    
    for (const field of expectedFields) {
      // Check label with for attribute
      expect($(`label[for="${field.id}"]`).text()).toBe(field.label);
      
      // Check input with correct id and name
      const input = $(`#${field.id}`);
      expect(input.length).toBe(1);
      expect(input.attr('name')).toBe(field.name);
      expect(input.attr('required')).toBe('required');
    }
    
    // Check submit button
    expect($('button[type="submit"]').text().trim()).toBe('Submit');
    
    // Check form title
    expect($('h1').text()).toBe('Tell us who you are');
  });

  it('persists submission and redirects to thank-you page', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    // Submit form
    const submitResponse = await request(app)
      .post('/submit')
      .send(formData);
    
    // Check redirect to thank-you page
    expect(submitResponse.status).toBe(302);
    expect(submitResponse.headers.location).toContain('/thank-you');
    expect(submitResponse.headers.location).toContain('firstName=John');

    // Follow redirect to thank-you page
    const thankYouResponse = await request(app)
      .get(submitResponse.headers.location);
    
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    
    // Check thank-you page content
    expect($('h1').text()).toBe('Thank you, John!');
    expect($('body').text()).toContain('stranger on the internet');
    
    // Check link back to form
    expect($('a[href="/"]').length).toBe(1);

    // Verify data was persisted in SQLite
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone-123!',
        postalCode: 'invalid@postal'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    
    // Check error list is present
    expect($('.error-list').length).toBe(1);
    
    // Check specific error messages
    const errorText = $('.error-list').text();
    expect(errorText).toContain('First name is required');
    expect(errorText).toContain('Last name is required');
    expect(errorText).toContain('valid email address');
    expect(errorText).toContain('valid phone number');
    expect(errorText).toContain('valid postal/zip code');
    
    // Check form is re-rendered with submitted values
    expect($('#firstName').val()).toBe('');
    expect($('#email').val()).toBe('invalid-email');
  });

  it('accepts international phone and postal formats', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'María',
      lastName: 'González',
      streetAddress: 'Av. Corrientes 1000',
      city: 'Buenos Aires',
      stateProvince: 'Capital Federal',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.gonzalez@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should successfully redirect (no validation errors)
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
  });
});
