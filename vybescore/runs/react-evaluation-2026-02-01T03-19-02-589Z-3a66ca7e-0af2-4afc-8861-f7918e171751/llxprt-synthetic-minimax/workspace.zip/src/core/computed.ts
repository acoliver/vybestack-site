/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  setActiveObserver
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: any = {
    name: options?.name,
    value,
    updateFn: (value?: T) => updateFn(value),
    subjects: []
  }
  
  const computedGetter: GetterFn<T> = () => {
    // Set this computed observer as active so input getters can register dependencies
    setActiveObserver(o)
    try {
      // Recalculate the computed value each time it's accessed
      const currentValue = o.value
      const newValue = updateFn(currentValue)
      o.value = newValue
      return newValue
    } finally {
      setActiveObserver(undefined)
    }
  }

  return computedGetter
}
