/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create observer that will track dependencies and re-execute when they change
  const observer: any = {
    value,
    updateFn: (value?: T) => {
      if (!disposed) {
        updateFn(value)
      }
      return observer.value
    },
    subjects: [],
    stale: false,
    dirty: false
  }
  
  // Execute callback immediately to establish dependencies
  setActiveObserver(observer)
  try {
    updateFn(value)
  } finally {
    setActiveObserver(undefined)
  }
  
  // Return cleanup function
  return () => {
    if (disposed) return
    disposed = true
    observer.updateFn = () => {
      // Empty update function for disposed observers
    }
  }
}
