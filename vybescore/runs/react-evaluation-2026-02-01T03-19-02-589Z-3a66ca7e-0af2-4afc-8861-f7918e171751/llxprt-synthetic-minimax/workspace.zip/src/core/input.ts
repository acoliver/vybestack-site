/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerDependency,
  Observer
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : undefined
  const equalFlag = typeof equal === 'boolean' ? equal : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && typeof observer.updateFn === 'function') {
      // Register this subject as a dependency of the observer
      registerDependency(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const currentValue = s.value
    
    // Check equality if provided
    let shouldUpdate = true
    if (typeof equalFn === 'function') {
      shouldUpdate = !equalFn(currentValue, nextValue)
    } else if (equalFlag === false) {
      shouldUpdate = true
    } else {
      // Default strict equality or when equalFlag is true
      shouldUpdate = currentValue !== nextValue
    }

    if (shouldUpdate) {
      s.value = nextValue
      // Notify all observers that depend on this subject
      if (s.observers) {
        // Create a copy to avoid issues if observers get modified during iteration
        const observersCopy = [...s.observers]
        for (const observer of observersCopy) {
          if (observer && typeof observer.updateFn === 'function') {
            // Mark observer as dirty and trigger update
            observer.dirty = true
            observer.stale = true
            updateObserver(observer as any)
          }
        }
      }
    }
    return s.value
  }

  return [read, write]
}
