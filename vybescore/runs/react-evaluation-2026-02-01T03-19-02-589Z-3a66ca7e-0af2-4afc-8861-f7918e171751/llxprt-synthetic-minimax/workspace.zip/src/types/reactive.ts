/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  id?: number
  dirty?: boolean
  updateFn?: UpdateFn<unknown>
  subjects?: Subject<unknown>[]
  stale?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Subject<T>[]
  stale?: boolean
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: ObserverR[]
  version?: number
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let observerId = 0

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer?: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const updatedValue = observer.updateFn(observer.value)
    if (observer.value !== undefined || updatedValue !== undefined) {
      (observer as any).value = updatedValue
    }
    // Clear dirty flag after successful update
    observer.dirty = false
    observer.stale = false
  } finally {
    activeObserver = previous
  }
}

export function registerDependency<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.observers) {
    subject.observers = []
  }
  if (!subject.observers.includes(observer as Observer<unknown>)) {
    subject.observers.push(observer as Observer<unknown>)
  }
  
  if (!observer.subjects) {
    observer.subjects = []
  }
  if (!observer.subjects.includes(subject as Subject<unknown>)) {
    (observer.subjects as Subject<unknown>[]).push(subject as Subject<unknown>)
  }
  
  // Assign ID to observer for tracking
  if (!observer.id) {
    observer.id = ++observerId
  }
  
  // Mark observer as dirty to ensure re-evaluation when dependencies change
  observer.dirty = true
  observer.stale = true
}

export function markDirty(observer: Observer<unknown>): void {
  observer.dirty = true
  observer.stale = true
}

export function notifyDependents(subject: Subject<unknown>): void {
  if (subject.observers && subject.observers.length > 0) {
    for (const observer of subject.observers) {
      if (observer && typeof observer.updateFn === 'function') {
        // Mark observer as dirty and trigger update
        observer.dirty = true
        observer.stale = true
        updateObserver(observer as Observer<unknown>)
      }
    }
  }
}

export function disposeObserver(observer: Observer<unknown>): void {
  if (observer.subjects) {
    for (const subject of observer.subjects) {
      if (subject.observers && observer.id) {
        subject.observers = subject.observers.filter((obs: ObserverR) => obs.id !== observer.id)
      }
    }
  }
}
