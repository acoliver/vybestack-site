/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence terminators
  // Replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence terminators (.?!)
  // But be careful with abbreviations
  normalized = normalized.replace(/([.!?])\s*/g, '$1 ');
  
  // Split into sentences while preserving abbreviations
  // Common abbreviations that don't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'i.e', 'e.g', 'approx', 'dept', 'univ'];
  
  // Capitalize first letter of each sentence
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  const capitalized = sentences.map((sentence, index) => {
    if (sentence.length === 0) return '';
    
    // Check if this is actually a sentence ending or an abbreviation
    const trimmed = sentence.trim();
    const lastWord = trimmed.split(/\s+/).pop()?.toLowerCase();
    
    if (index > 0 && lastWord && abbreviations.some(abbr => lastWord.startsWith(abbr))) {
      return sentence;
    }
    
    // Capitalize first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join with single spaces and trim
  let result = capitalized.join(' ').trim();
  
  // Remove any double spaces that might have been introduced
  result = result.replace(/\s+/g, ' ');
  
  // Remove space before punctuation
  result = result.replace(/\s+([.!?])/g, '$1');
  
  return result;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https/ftp protocols
  // Includes domain, optional port, path, query, fragment
  // Excludes trailing punctuation
  const urlRegex = /(https?:\/\/|ftp:\/\/)[^\s<>"'(){}|[\]\\`^]+[^\s<>"'(){}|[\]\\`^.,!?;:]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing dots, commas, etc.
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = new RegExp('(https?://)([^/\\s]+)(/[^\\s]*)?', 'g');
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    let newHost = host;
    const newPath = path;
    
    // Check if this is example.com and path starts with /docs/
    if (host === 'example.com' && path && path.startsWith('/docs/')) {
      // Check for exclusion criteria: cgi-bin, query strings, or legacy extensions
      const exclusionPattern = /(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
      
      if (!exclusionPattern.test(path)) {
        // Rewrite host to docs.example.com
        newHost = 'docs.example.com';
      }
    }
    
    return newScheme + newHost + newPath;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assuming leap year for Feb
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
