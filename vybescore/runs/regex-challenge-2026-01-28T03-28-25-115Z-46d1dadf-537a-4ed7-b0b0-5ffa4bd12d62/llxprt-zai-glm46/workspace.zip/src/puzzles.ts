/**
 * Finds words starting with a prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: word boundary, prefix, word characters, word boundary
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const uniqueMatches = new Set<string>();
  
  for (const match of matches) {
    const matchLower = match.toLowerCase();
    if (!exceptionsLower.includes(matchLower)) {
      uniqueMatches.add(match);
    }
  }
  
  return Array.from(uniqueMatches);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token (capture the digit+token combination)
  // Use word boundary to ensure we match complete tokens
  const tokenRegex = new RegExp(`\\d${escapedToken}\\b`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  // Return unique occurrences
  return Array.from(new Set(matches));
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // Look for patterns of 2-4 characters that repeat immediately
  const repeatedSequenceRegex = /(.{2,4})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (excluding IPv4-mapped addresses)
  // Supports shorthand ::
  // Does NOT match IPv4 addresses
  
  // First, let's define what IPv6 looks like:
  // 8 groups of 1-4 hex digits separated by colons
  // Can use :: to represent consecutive zero groups
  // Can have IPv4 embedded at the end (::ffff:192.168.1.1)
  
  // Pattern for IPv6 without embedded IPv4
  const ipv6Pattern = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::)/;
  
  // Check if value contains IPv6 pattern
  if (!ipv6Pattern.test(value)) {
    return false;
  }
  
  // Make sure it's not just an IPv4 address
  // IPv4: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  return true;
}
