export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email regex (simplified but robust)
  // Local part: letters, digits, dots, hyphens, underscores, plus signs
  // Cannot start/end with dot, cannot have consecutive dots
  // Domain: letters, digits, hyphens, dots (but no underscores)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks: no double dots, no trailing dot, no underscores in domain
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain part
  const atPos = value.indexOf('@');
  if (atPos > 0) {
    const domain = value.substring(atPos + 1);
    if (domain.includes('_')) {
      return false;
    }
  }
  
  // Check that domain has at least one dot and valid TLD
  const domainPart = value.split('@')[1];
  if (!domainPart || !domainPart.includes('.')) {
    return false;
  }
  
  const tld = domainPart.split('.').pop();
  if (!tld || tld.length < 2 || !/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let finalCleaned = cleaned;
  if (finalCleaned.startsWith('+1')) {
    finalCleaned = finalCleaned.substring(2);
  } else if (finalCleaned.startsWith('1') && finalCleaned.length === 11) {
    finalCleaned = finalCleaned.substring(1);
  }
  
  // Must be exactly 10 digits after cleaning
  if (finalCleaned.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = finalCleaned.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = finalCleaned.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Supports landlines and mobiles in formats like:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match pattern with optional country code +54, optional trunk prefix 0, optional mobile indicator 9
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber: 6-8 digits total after area code
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // When country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = value.includes('0') && !value.startsWith('+54');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    // Check if the original started with 0 before area code
    const withoutSeparators = value.replace(/[\s-]/g, '');
    if (!withoutSeparators.startsWith('0')) {
      return false;
    }
  }
  
  // Total length validation
  // Minimum: area code (2) + subscriber (6) = 8
  // Maximum: area code (4) + subscriber (8) = 12
  // Plus optional +54 (3 chars) and optional 0 and 9
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Must have at least 2 characters
  // Must contain at least one letter
  // Cannot contain digits or most symbols (except apostrophe, hyphen, space)
  
  if (value.length < 2) {
    return false;
  }
  
  // Check for invalid characters (digits, symbols except allowed ones)
  if (/[0-9@#$%^&*()_+=[\]{}|\\:";<>?]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (unicode-aware)
  const hasLetter = /\p{L}/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Only allow letters, apostrophes, hyphens, spaces, and periods (for initials like "J.R.R.")
  const validNameRegex = /^[\p{L}\p{M}'\-\s.]+$/u;
  if (!validNameRegex.test(value)) {
    return false;
  }
  
  // Reject names with only special characters
  const lettersOnly = value.replace(/[\p{L}\p{M}]/gu, '');
  if (lettersOnly.length === value.length) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check length: Visa/Mastercard (16 digits), AmEx (15 digits)
  const length = cleaned.length;
  if (length !== 13 && length !== 14 && length !== 15 && length !== 16 && length !== 19) {
    return false;
  }
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type prefixes
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const visaRegex = /^4/;
  const mastercardRegex = /^(5[1-5]|2[2-7][0-9]{2})/;
  const amexRegex = /^3[47]/;
  
  if (!visaRegex.test(cleaned) && 
      !mastercardRegex.test(cleaned) && 
      !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
