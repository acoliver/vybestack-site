import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { initSqlJs, Database } from 'sql.js';

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface FormValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  values: Partial<FormData>;
}

// Global database instance
let db: Database | null = null;
let server: express.Express | null = null;

// Initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file) => `https://sql.js.org/dist/${file}`,
  });

  const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
  const dbDir = path.dirname(dbPath);

  // Ensure data directory exists
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  let buffer: Uint8Array | null = null;

  // Load existing database if it exists
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    buffer = new Uint8Array(fileBuffer);
  }

  db = new SQL.Database(buffer);

  // Create table if it doesn't exist
  const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
  if (fs.existsSync(schemaPath)) {
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    db.exec(schema);
  }

  console.log('Database initialized successfully');
}

// Save database to file
function saveDatabase(): void {
  if (!db) {
    return;
  }

  const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
  console.log('Database saved successfully');
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings (handle UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateForm(data: Partial<FormData>): FormValidationResult {
  const errors: ValidationError[] = [];
  const values: Partial<FormData> = {};

  // Validate firstName
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  } else {
    values.firstName = data.firstName;
  }

  // Validate lastName
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  } else {
    values.lastName = data.lastName;
  }

  // Validate streetAddress
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  } else {
    values.streetAddress = data.streetAddress;
  }

  // Validate city
  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  } else {
    values.city = data.city;
  }

  // Validate stateProvince
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  } else {
    values.stateProvince = data.stateProvince;
  }

  // Validate postalCode
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Invalid postal / zip code format' });
  } else {
    values.postalCode = data.postalCode;
  }

  // Validate country
  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  } else {
    values.country = data.country;
  }

  // Validate email
  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  } else {
    values.email = data.email;
  }

  // Validate phone
  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone number format' });
  } else {
    values.phone = data.phone;
  }

  return {
    isValid: errors.length === 0,
    errors,
    values,
  };
}

// Create Express app
function createApp(): express.Express {
  const app = express();

  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // Serve static files
  app.use('/public', express.static(path.join(process.cwd(), 'public')));

  // Routes

  // GET / - Render form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {},
    });
  });

  // POST /submit - Process form submission
  app.post('/submit', (req: Request, res: Response) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone,
    };

    const validation = validateForm(formData);

    if (!validation.isValid) {
      // Re-render form with errors
      const errorMessages = validation.errors.map((err) => err.message);
      return res.status(400).render('form', {
        errors: errorMessages,
        values: validation.values,
      });
    }

    // Save to database
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName!.trim(),
        formData.lastName!.trim(),
        formData.streetAddress!.trim(),
        formData.city!.trim(),
        formData.stateProvince!.trim(),
        formData.postalCode!.trim(),
        formData.country!.trim(),
        formData.email!.trim(),
        formData.phone!.trim(),
      ]);

      stmt.free();
      saveDatabase();
    }

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  });

  // GET /thank-you - Thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', {
      firstName: req.query.firstName || '',
    });
  });

  return app;
}

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');

  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }

  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }

  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();

    const app = createApp();
    server = app;

    const port = parseInt(process.env.PORT || '3000', 10);

    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle SIGTERM
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();