/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from "../types/reactive.js"

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let initialized = false
  
  const getValue: GetterFn<T> = () => {
    // Always track dependencies - reset initialized if there are other active observers
    const currentActive = getActiveObserver()
    const needsRecompute = !initialized || currentActive !== observer
    
    if (needsRecompute) {
      const previousActive = currentActive
      setActiveObserver(observer)
      
      try {
        observer.value = updateFn(observer.value)
      } finally {
        setActiveObserver(previousActive)
      }
      initialized = true
    }
    
    return observer.value!
  }
  
  return getValue
}
