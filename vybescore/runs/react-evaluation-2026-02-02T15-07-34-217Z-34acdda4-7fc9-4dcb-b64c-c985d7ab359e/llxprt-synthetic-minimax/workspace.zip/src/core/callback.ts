/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver, 
  setActiveObserver,
  subscribeSubject,
  Subject,
  updateObserver,
  notifySubject
} from "../types/reactive.js"

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (disposed) return currentValue
      
      const previousActive = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        return updateFn(currentValue)
      } finally {
        setActiveObserver(previousActive)
      }
    },
  }
  
  // Execute callback initially to establish subscriptions through the observer pattern
  const previousActive = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    observer.value = updateFn(observer.value)
  } finally {
    setActiveObserver(previousActive)
  }
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    observer.disposed = true
  }
}
