import { createInput, createComputed, createCallback } from './src/index.js'

// Test the failing case
console.log('=== Testing callback firing ===')

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const output = createComputed(() => {
  const result = input() + 1
  console.log('Computed called with input:', input(), 'result:', result)
  return result
})

console.log('Initial output:', output())

let value = 0
console.log('Creating callback...')
const unsubscribe = createCallback(() => {
  value = output()
  console.log('Callback triggered, value set to:', value)
})

console.log('Initial callback fired, value:', value)
console.log('Changing input to 3...')
setInput(3)
console.log('After setInput, value:', value)
console.log('Output after change:', output())

console.log('=== Expected: value = 4, Actual: value =', value, '===')