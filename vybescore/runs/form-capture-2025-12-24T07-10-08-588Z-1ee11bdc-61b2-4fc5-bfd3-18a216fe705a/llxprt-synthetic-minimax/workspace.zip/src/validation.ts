export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = "First name is required";
  }

  if (!data.lastName.trim()) {
    errors.lastName = "Last name is required";
  }

  if (!data.streetAddress.trim()) {
    errors.streetAddress = "Street address is required";
  }

  if (!data.city.trim()) {
    errors.city = "City is required";
  }

  if (!data.stateProvinceRegion.trim()) {
    errors.stateProvinceRegion = "State/Province/Region is required";
  }

  if (!data.postalZipCode.trim()) {
    errors.postalZipCode = "Postal/Zip code is required";
  }

  if (!data.country.trim()) {
    errors.country = "Country is required";
  }

  if (!data.email.trim()) {
    errors.email = "Email is required";
  } else if (!isValidEmail(data.email)) {
    errors.email = "Please enter a valid email address";
  }

  if (!data.phone.trim()) {
    errors.phone = "Phone number is required";
  } else if (!isValidPhone(data.phone)) {
    errors.phone = "Please enter a valid phone number";
  }

  // Postal code validation (accepts alphanumeric)
  if (data.postalZipCode.trim() && !isValidPostalCode(data.postalZipCode)) {
    errors.postalZipCode = "Please enter a valid postal/zip code";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone.trim()) && phone.trim().length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings, spaces, and dashes (handles international formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode.trim()) && postalCode.trim().length >= 3;
}
