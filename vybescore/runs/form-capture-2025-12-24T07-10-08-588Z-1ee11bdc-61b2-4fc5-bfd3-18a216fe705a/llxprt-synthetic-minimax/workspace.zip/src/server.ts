import express, { Request, Response } from "express";
import * as path from "path";
import { DatabaseManager } from "./database";
import { validateForm, FormData } from "./validation";

const app = express();
const port = process.env.PORT || 3535;

let dbManager: DatabaseManager;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), "public")));
app.set("view engine", "ejs");
app.set("views", path.join(process.cwd(), "views"));

// GET / - Display the form
app.get("/", (req: Request, res: Response) => {
  res.render("index", {
    errors: {},
    formData: {},
    title: "Contact Us"
  });
});

// POST /submit - Handle form submission
app.post("/submit", (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || "",
    lastName: req.body.lastName || "",
    streetAddress: req.body.streetAddress || "",
    city: req.body.city || "",
    stateProvinceRegion: req.body.stateProvinceRegion || "",
    postalZipCode: req.body.postalZipCode || "",
    country: req.body.country || "",
    email: req.body.email || "",
    phone: req.body.phone || ""
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.status(400).render("index", {
      errors: validation.errors,
      formData,
      title: "Contact Us"
    });
  }

  try {
    dbManager.insertSubmission(formData);
    dbManager.save();
    res.redirect(302, "/thank-you");
  } catch (error) {
    console.error("Error saving submission:", error);
    return res.status(500).render("index", {
      errors: { general: "Failed to save your information. Please try again." },
      formData,
      title: "Contact Us"
    });
  }
});

// GET /thank-you - Thank you page
app.get("/thank-you", (req: Request, res: Response) => {
  res.render("thank-you", {
    title: "Thank You!"
  });
});

// Graceful shutdown
process.on("SIGTERM", () => {
  console.log("Received SIGTERM, shutting down gracefully");
  if (dbManager) {
    dbManager.close();
  }
  process.exit(0);
});

process.on("SIGINT", () => {
  console.log("Received SIGINT, shutting down gracefully");
  if (dbManager) {
    dbManager.close();
  }
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    dbManager = new DatabaseManager();
    await dbManager.initialize();

    app.listen(port, () => {
      console.log("Server running on http://localhost:" + port);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();
