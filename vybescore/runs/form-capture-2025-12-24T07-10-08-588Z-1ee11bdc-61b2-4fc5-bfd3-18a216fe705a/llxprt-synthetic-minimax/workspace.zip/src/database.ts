import initSqlJs, { Database, SqlJsStatic } from "sql.js";
import * as fs from "fs";
import * as path from "path";

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor(dbPath?: string) {
    this.dbPath = dbPath || path.join(process.cwd(), "data", "submissions.sqlite");
  }

  async initialize(): Promise<void> {
    try {
      this.sqlJs = await initSqlJs();
      
      let dbBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(dbFile);
      }
      
      if (!this.sqlJs) {
        throw new Error("Failed to initialize SQL.js");
      }
      
      this.db = new this.sqlJs.Database(dbBuffer);
      
      const schemaPath = path.join(process.cwd(), "db", "schema.sql");
      const schema = fs.readFileSync(schemaPath, "utf8");
      this.db.exec(schema);
      
      console.log("Database initialized successfully");
    } catch (error) {
      console.error("Failed to initialize database:", error);
      throw error;
    }
  }

  insertSubmission(formData: FormData): number {
    if (!this.db) {
      throw new Error("Database not initialized");
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalZipCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.step();
    stmt.free();

    return this.db.getRowsModified();
  }

  save(): void {
    if (!this.db) {
      throw new Error("Database not initialized");
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}
