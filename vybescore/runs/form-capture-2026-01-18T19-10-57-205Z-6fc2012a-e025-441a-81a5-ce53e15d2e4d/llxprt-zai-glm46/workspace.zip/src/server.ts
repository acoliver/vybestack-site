import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

const app = express();
let db: Database | null = null;

app.set('views', path.resolve(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.static(path.resolve(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[@+]?[\d\s()-]+$/;
  const hasDigits = /\d/.test(phone);
  return phoneRegex.test(phone) && phone.trim().length > 0 && hasDigits;
}

function validatePostalCode(postal: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateSubmission(data: Submission): ValidationResult {
  const errors: Record<string, string> = {};

  if (!data.first_name || typeof data.first_name !== 'string' || !data.first_name.trim()) {
    errors.first_name = 'First name is required';
  }

  if (!data.last_name || typeof data.last_name !== 'string' || !data.last_name.trim()) {
    errors.last_name = 'Last name is required';
  }

  if (!data.street_address || typeof data.street_address !== 'string' || !data.street_address.trim()) {
    errors.street_address = 'Street address is required';
  }

  if (!data.city || typeof data.city !== 'string' || !data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.state_province || typeof data.state_province !== 'string' || !data.state_province.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!data.postal_code || typeof data.postal_code !== 'string' || !data.postal_code.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Invalid postal code format';
  }

  if (!data.country || typeof data.country !== 'string' || !data.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email || typeof data.email !== 'string' || !data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Invalid email format';
  }

  if (!data.phone || typeof data.phone !== 'string' || !data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Invalid phone number format';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();
  
  let dbData: Uint8Array | null = null;
  if (fs.existsSync(DB_PATH)) {
    dbData = fs.readFileSync(DB_PATH);
  }

  db = new SQL.Database(dbData);

  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);
}

function saveDatabase(): void {
  if (!db) return;
  
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: {},
    data: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const data: Submission = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateSubmission(data);

  if (!validation.valid) {
    res.status(400);
    return res.render('index', {
      errors: validation.errors,
      data,
    });
  }

  if (!db) {
    throw new Error('Database not initialized');
  }

  db.run(
    `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone,
    ]
  );

  saveDatabase();

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

export async function startServer(port: number = 3535): Promise<{ app: express.Express; server: import('http').Server }> {
  await initDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  return { app, server };
}

export function stopServer(): void {
  if (db) {
    db.close();
    db = null;
  }
}

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer(PORT).then(({ server }) => {
    const shutdown = async () => {
      console.log('Shutting down gracefully...');
      server.close();
      stopServer();
      process.exit(0);
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  }).catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
