import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, stopServer } from '../../src/server';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await startServer(3535);
  server = result.server;
});

afterAll(() => {
  if (server) {
    server.close();
  }
  stopServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535').get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State');
    expect(response.text).toContain('Postal');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send({
        first_name: 'Jane',
        last_name: 'Smith',
        street_address: '123 Main St',
        city: 'London',
        state_province: 'England',
        postal_code: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958',
      });
    
    if (response.status !== 302) {
      console.log('Response status:', response.status);
      console.log('Response text:', response.text);
    }
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    const dbExists = fs.existsSync(dbPath);
    expect(dbExists).toBe(true);
  });
});
