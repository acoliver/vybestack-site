export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Quick format check
  if (!emailRegex.test(value)) {
    return false;
  }

  // Split into local and domain parts
  const [local, domain] = value.split('@');
  if (!local || !domain) {
    return false;
  }

  // Check for invalid patterns in local part
  if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) {
    return false;
  }

  // Check domain for underscores and invalid patterns
  if (domain.includes('_') || domain.startsWith('.') || domain.endsWith('.') || domain.includes('..')) {
    return false;
  }

  // Check that domain has at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }

  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  let cleaned = value.replace(/[^\d+]/g, '');

  // Handle optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }

  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(cleaned)) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = cleaned.substring(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = cleaned.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Match patterns with optional +54, optional trunk prefix 0, optional mobile indicator 9
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?(\d{2,4})(\d{6,8})$/;

  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, areaCode, subscriber] = match;

  // Area code must be 2-4 digits and not start with 0
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }

  // When country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode) {
    if (!value.replace(/[\s-]/g, '').startsWith('0')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // At least one letter required, no digits or special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must have at least one letter (not just spaces/hyphens/apostrophes)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Check for digit-like patterns (reject X Æ A-12 style)
  if (/\d/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number).reverse();
  
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12,15}$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7]\d{14})$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
