/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after .?!
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ').trim();
  
  // Insert space after sentence endings if missing (but not for abbreviations)
  // Add space after sentence endings when missing
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  // Now capitalize first letter after sentence boundaries
  // Capitalize after .!? when followed by a letter
  const result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in text and return them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // eslint-disable-next-line no-control-regex
  const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`[\]]+|www\.[^\s<>"{}|\\^`[\]]+)/gi;
  
  const urls: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    // eslint-disable-next-line no-useless-escape
    url = url.replace(/[.,;:!?)\]\}"']+$/, '');
    
    // Remove trailing parentheses if they weren't part of the URL
    if (url.endsWith(')') && !url.includes('(')) {
      url = url.slice(0, -1);
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlPattern = /(https?:\/\/example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    // Always upgrade to https
    const secureHost = 'https://example.com';
    
    if (!path) {
      return secureHost;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = [
        'cgi-bin',
        '?',
        '&',
        '=',
        '.jsp',
        '.php',
        '.asp',
        '.aspx',
        '.do',
        '.cgi',
        '.pl',
        '.py'
      ];
      
      const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
      
      if (hasDynamicHint) {
        // Only upgrade scheme
        return secureHost + path;
      } else {
        // Upgrade scheme and rewrite host
        return 'https://docs.example.com' + path;
      }
    }
    
    // Not a docs path, just upgrade scheme
    return secureHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days in each month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Validate day
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
