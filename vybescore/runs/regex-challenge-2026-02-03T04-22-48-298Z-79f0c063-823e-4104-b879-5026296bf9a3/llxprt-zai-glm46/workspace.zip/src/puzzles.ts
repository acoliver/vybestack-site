/**
 * Find words starting with the prefix, excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const filtered = matches.filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  );
  
  // Return unique matches
  return [...new Set(filtered)];
}

/**
 * Find occurrences of token only when it appears after a digit and not at string start.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find digit followed by token, but not at start of string
  // (?:^|\s) ensures we don't match at the very start
  const pattern = new RegExp(`(?:^|\\s)\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = pattern.exec(text)) !== null) {
    // Remove leading whitespace from the match
    matches.push(match[0].trim());
  }
  
  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // Look for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (pattern === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Also check for IPv6 in brackets (common in URLs)
  const bracketedIPv6 = /\[[0-9a-fA-F:]+\]/;
  
  // Also check for localhost IPv6
  const localhostIPv6 = /::1|0:0:0:0:0:0:0:1/;
  
  if (bracketedIPv6.test(value) || localhostIPv6.test(value)) {
    // Make sure it's not just IPv4 with dots
    const hasColons = value.includes(':');
    const hasMultipleColons = (value.match(/:/g) || []).length >= 2;
    
    if (hasColons && (hasMultipleColons || value.includes('::'))) {
      return true;
    }
  }
  
  // Check for specific IPv6 patterns more carefully
  // Full IPv6: 8 groups of hex separated by colons
  const fullIPv6 = /^[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}$/;
  
  // IPv6 with ::
  const shorthandIPv6 = /^[0-9a-fA-F:]*::[0-9a-fA-F:]*$/;
  
  // Must not be IPv4 format
  const isIPv4 = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value);
  
  if (isIPv4) {
    return false;
  }
  
  return fullIPv6.test(value) || shorthandIPv6.test(value) || value.includes('::') || (/^[0-9a-fA-F:]+$/.test(value) && value.includes(':') && !value.includes('.'));
}
