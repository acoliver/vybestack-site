import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization
let db: any = null;
let SqlJs: any = null;

const DB_FILE_PATH = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    SqlJs = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, `../node_modules/sql.js/dist/${file}`)
    });

    // Check if database file exists
    if (fs.existsSync(DB_FILE_PATH)) {
      const filebuffer = fs.readFileSync(DB_FILE_PATH);
      db = new SqlJs.Database(filebuffer);
    } else {
      db = new SqlJs.Database();
      
      // Create table from schema
      const schema = `
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `;
      db.run(schema);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (db && SqlJs) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE_PATH, buffer);
  }
}

function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Validation functions
interface ValidationErrors {
  [key: string]: string;
}

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field checks
  const requiredFields = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || (typeof data[field] === 'string' && !data[field].trim())) {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
  if (data.phone) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation - alphanumeric strings
  if (data.postal_code) {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }
  }

  return errors;
}

// Routes

// GET / - Render the contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {},
    pageTitle: 'Contact Us'
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  const formData = req.body;
  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData,
      pageTitle: 'Contact Us'
    });
  }

  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).send('Failed to save submission');
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  // Get the first name from the most recent submission for personalization
  let firstName = '';
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const hasRow = stmt.step();
      if (hasRow) {
        const row = stmt.getAsObject();
        firstName = row.first_name as string;
      }
      stmt.free();
    } catch (error) {
      console.error('Error fetching first name:', error);
    }
  }

  res.render('thank-you', {
    firstName,
    pageTitle: 'Thank You'
  });
});

// Graceful shutdown
function shutdown() {
  console.log('\nShutting down gracefully...');
  closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;