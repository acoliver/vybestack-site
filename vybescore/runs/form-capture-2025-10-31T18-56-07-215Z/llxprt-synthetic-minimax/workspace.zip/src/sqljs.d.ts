declare module 'sql.js' {
  interface Database {
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    exec(sql: string): void;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(params?: unknown[]): void;
    step(): boolean;
    getAsObject(params?: unknown[]): Record<string, unknown>;
    free(): void;
  }

  interface Config {
    locateFile?: (file: string) => string;
  }

  interface SqlJsStatic {
    new (buffer?: Uint8Array): Database;
    Database: typeof Database;
    initSqlJs: (config?: Config) => Promise<SqlJsStatic>;
  }

  const initSqlJs: (config?: Config) => Promise<SqlJsStatic>;
  export default initSqlJs;
  export const Database: SqlJsStatic;
}