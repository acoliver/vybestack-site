import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

import { Database } from 'sql.js';

let db: Database;
let isShuttingDown = false;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?\d[\d\s-()]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[A-Za-z0-9\s-]*$/;
  return postalCodeRegex.test(postalCode);
}

function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};

  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Invalid postal code format';
  }

  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Invalid email format';
  }

  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Invalid phone number format';
  }

  return errors;
}

async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    let dbBuffer: Uint8Array | null = null;
    
    if (fs.existsSync(dbPath)) {
      const fileData = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileData);
    } else {
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schemaSQL = fs.readFileSync(schemaPath, 'utf8');
        db = new SQL.Database();
        db.run(schemaSQL);
        saveDatabase();
        return;
      }
    }

    db = new SQL.Database(dbBuffer);
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase() {
  if (!db || isShuttingDown) return;
  
  try {
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'views'));

app.get('/', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };
  
  res.render('index', { 
    formData, 
    errors: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('index', {
      formData,
      errors,
      title: 'Friendly Contact Form - Please fix the errors'
    });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, 
                              state_province, postal_code, country, email, phone, 
                              created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('index', {
      formData,
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      title: 'Friendly Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

function shutdown() {
  isShuttingDown = true;
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch(console.error);