/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  // Remove padding first for the main pattern check
  const withoutPadding = input.replace(/=+$/, '');
  
  // Base64 pattern: A-Z, a-z, 0-9, +, /
  const base64Pattern = /^[A-Za-z0-9+/]*$/;
  
  return base64Pattern.test(withoutPadding);
}

/**
 * Normalizes Base64 input by adding proper padding if missing.
 */
function normalizeBase64Padding(input: string): string {
  // Remove any existing padding
  const withoutPadding = input.replace(/=+$/, '');
  
  // Calculate required padding
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  
  return withoutPadding + '='.repeat(paddingLength);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for clearly invalid Base64.
 */
export function decode(input: string): string {
  if (!input || input.trim() === '') {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  const trimmedInput = input.trim();
  
  // Validate Base64 characters
  if (!isValidBase64(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check length is valid for Base64 (must be multiple of 4, or be pad-able)
  const withoutPadding = trimmedInput.replace(/=+$/, '');
  if (withoutPadding.length % 4 !== 0 && withoutPadding.length % 4 !== 2 && withoutPadding.length % 4 !== 3) {
    throw new Error('Invalid Base64 input: incorrect length');
  }
  
  try {
    const normalizedInput = normalizeBase64Padding(trimmedInput);
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
