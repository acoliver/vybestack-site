import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // Clean up test database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  // Clean up test database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // Verify that the compiled server exists
    const distPath = path.resolve('dist', 'server.js');
    expect(fs.existsSync(distPath)).toBe(true);
  });

  it('persists submission and redirects', () => {
    // Verify database directory exists
    const dataDir = path.resolve('data');
    expect(fs.existsSync(dataDir)).toBe(true);
  });
});
