import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs/promises';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Validation functions
function isEmpty(value: string): boolean {
  return !value || value.trim().length === 0;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and optional leading @
  const phoneRegex = /^@?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function isValidPostalCode(code: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(code) && code.trim().length > 0;
}

function validateForm(data: FormData): string[] {
  const errors: string[] = [];

  if (isEmpty(data.firstName)) errors.push('First name is required');
  if (isEmpty(data.lastName)) errors.push('Last name is required');
  if (isEmpty(data.streetAddress)) errors.push('Street address is required');
  if (isEmpty(data.city)) errors.push('City is required');
  if (isEmpty(data.stateProvince)) errors.push('State / Province / Region is required');
  if (isEmpty(data.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!isValidPostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and dashes');
  }
  if (isEmpty(data.country)) errors.push('Country is required');
  if (isEmpty(data.email)) {
    errors.push('Email is required');
  } else if (!isValidEmail(data.email)) {
    errors.push('Email must be valid');
  }
  if (isEmpty(data.phone)) {
    errors.push('Phone number is required');
  } else if (!isValidPhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and optional leading @');
  }

  return errors;
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: formData });
  }

  if (!db) {
    errors.push('Database not available');
    return res.status(500).render('form', { errors, values: formData });
  }

  try {
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
        now
      ]
    );

    // Save database to disk
    const data = db.export();
    const buffer = Buffer.from(data);
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    await fs.writeFile(DB_PATH, buffer);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('Failed to save submission');
    res.status(500).render('form', { errors, values: formData });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Use a default name if not provided via session/cookie
  const firstName = 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function shutdown(signal: string): Promise<void> {
  console.log(`\nReceived ${signal}, closing server...`);
  
  if (db) {
    db.close();
    db = null;
  }

  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Initialize and start server
async function start(): Promise<void> {
  try {
    console.log('Initializing SQL.js...');
    const SQL = await initSqlJs();

    // Load or create database
    let dbData: Uint8Array | undefined;
    try {
      const fileBuffer = await fs.readFile(DB_PATH);
      dbData = new Uint8Array(fileBuffer);
      console.log('Loaded existing database from', DB_PATH);
    } catch {
      console.log('No existing database found, creating new one');
    }

    db = new SQL.Database(dbData);

    // Initialize schema
    const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    console.log('Database initialized with schema');

    // Configure Express
    app.set('views', path.join('src', 'templates'));
    app.set('view engine', 'ejs');

    app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();
