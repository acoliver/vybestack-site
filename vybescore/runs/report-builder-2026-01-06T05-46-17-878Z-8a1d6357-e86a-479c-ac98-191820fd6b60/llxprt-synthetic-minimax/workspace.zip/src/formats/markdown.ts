import { ReportData } from '../types.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;

  // Calculate total
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);

  // Add entries
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    output += `- **${entry.label}** — $${amount}\n`;
  }

  // Add total if requested
  if (includeTotals) {
    output += `\n**Total:** $${total.toFixed(2)}\n`;
  }

  return output;
}