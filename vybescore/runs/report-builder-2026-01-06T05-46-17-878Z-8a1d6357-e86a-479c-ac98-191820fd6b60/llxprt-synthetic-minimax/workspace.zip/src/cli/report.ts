#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData } from '../types.js';

function printError(message: string): void {
  console.error(`Error: ${message}`);
}

function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
} {
  const result = {
    dataFile: '',
    format: '',
    output: undefined as string | undefined,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--includeTotals') {
      result.includeTotals = true;
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        printError('--output requires a path argument');
        process.exit(1);
      }
      result.output = args[i + 1];
      i += 2;
    } else if (arg === '--format') {
      if (i + 1 >= args.length) {
        printError('--format requires a format argument');
        process.exit(1);
      }
      result.format = args[i + 1];
      i += 2;
    } else if (!arg.startsWith('--')) {
      if (!result.dataFile) {
        result.dataFile = arg;
      }
      i++;
    } else {
      printError(`Unknown option: ${arg}`);
      process.exit(1);
    }
  }

  if (!result.dataFile) {
    printError('Missing required data file argument');
    process.exit(1);
  }

  if (!result.format) {
    printError('Missing required --format option');
    process.exit(1);
  }

  return result;
}

function loadData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing required field: title (must be string)');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Missing required field: summary (must be string)');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing required field: entries (must be array)');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string') {
        throw new Error(`Entry ${i}: missing required field: label (must be string)`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Entry ${i}: missing required field: amount (must be number)`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      printError('Invalid JSON: malformed input file');
      process.exit(1);
    }
    if (error instanceof Error && error.message.startsWith('ENOENT')) {
      printError('Input file not found');
      process.exit(1);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    printError('Usage: report.ts <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  try {
    const parsed = parseArgs(args);
    const data = loadData(parsed.dataFile);
    const output = renderReport(data, parsed.format, parsed.includeTotals);

    if (parsed.output) {
      writeFileSync(parsed.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      printError(error.message);
    } else {
      printError('Unknown error occurred');
    }
    process.exit(1);
  }
}

main();
