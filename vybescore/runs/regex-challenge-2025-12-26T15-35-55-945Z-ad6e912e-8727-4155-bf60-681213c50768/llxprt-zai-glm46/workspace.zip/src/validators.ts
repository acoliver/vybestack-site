export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (/\.\.|@.*@|^\.|^@|@$|\.$|_/.test(value)) {
    return false;
  }

  // RFC 5322 compliant email regex (simplified but robust)
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;

  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length (10 digits for US number)
  if (cleaned.length < 10) {
    return false;
  }

  // Extract digits only
  const digitsOnly = cleaned.replace(/\D/g, '');

  // Handle optional +1 prefix
  let digits = digitsOnly;
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  } else if (digits.length !== 10) {
    return false;
  }

  // Check area code (first digit cannot be 0 or 1)
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (second digit cannot be 0 or 1)
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if country code is present
  const hasCountryCode = cleaned.startsWith('+54');
  
  // If no country code, must start with 0
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  // If country code is present, extract the rest (without +54)
  let numberPart = cleaned;
  if (hasCountryCode) {
    numberPart = cleaned.slice(3);
  } else {
    // Remove the trunk prefix 0
    numberPart = numberPart.slice(1);
  }
  
  // Now check for optional 9 (mobile indicator)
  if (numberPart.startsWith('9')) {
    numberPart = numberPart.slice(1);
  }
  
  // Now numberPart should be area code + subscriber
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber: remaining 6-8 digits
  const areaAndSubscriberRegex = /^([1-9]\d{1,3})(\d{6,8})$/;
  const match = numberPart.match(areaAndSubscriberRegex);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Name must contain at least one unicode letter
  // Allow: unicode letters, accents, apostrophes, hyphens, spaces
  // Reject: digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter (not just spaces/symbols)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Cannot contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-2]\d)\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check prefix and length
  const validFormat = visaRegex.test(cleaned) || 
                      mastercardRegex.test(cleaned) || 
                      amexRegex.test(cleaned);
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
