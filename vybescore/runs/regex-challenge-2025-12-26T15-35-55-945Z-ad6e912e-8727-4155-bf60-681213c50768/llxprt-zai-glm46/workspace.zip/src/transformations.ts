/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: replace multiple spaces with single space
  let result = text.replace(/[ \t]+/g, ' ');
  
  // Ensure exactly one space after sentence endings (. ! ?) if followed by a letter
  // This handles cases like "hello.how" -> "hello. how"
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first letter of each sentence (after . ! ? or at start)
  // Using a callback to handle the capitalization
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern - matches http://, https://, and www. URLs
  // Negative lookbehind to avoid matching trailing punctuation
  const urlRegex = /https?:\/\/[^\s<>"{}|^`[\]]+[^\s<>"{}|^`[\].,!?;:)]/g;

  // Also match www. URLs without protocol
  const wwwRegex = /www\.[^\s<>"{}|^`[\]]+[^\s<>"{}|^`[\].,!?;:)]/g;
  
  const urls: string[] = [];
  
  let match;
  while ((match = urlRegex.exec(text)) !== null) {
    urls.push(match[0]);
  }
  
  while ((match = wwwRegex.exec(text)) !== null) {
    urls.push(match[0]);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for example.com URLs
  const pattern = /(https?:\/\/)(example\.com)(\/[^\s<>"{}|^`[\]]*)/gi;
  
  return text.replace(pattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if path should skip host rewrite
    // Skip if contains: cgi-bin, ?, &, =, or legacy extensions
    const skipRewrite = /\/cgi-bin\/|[?&=]/.test(path) ||
                        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$|\?)/i.test(path);
    
    // If path starts with /docs/ and no skip conditions, rewrite host
    if (path.startsWith('/docs/') && !skipRewrite) {
      return newScheme + 'docs.example.com' + path;
    }
    
    // Otherwise just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Additional validation for February in non-leap years
  if (month === 2 && day === 29) {
    // A year is leap if divisible by 4, but not by 100, unless also by 400
    const yearNum = parseInt(year, 10);
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeap) {
      return 'N/A';
    }
  }
  
  return year;
}
