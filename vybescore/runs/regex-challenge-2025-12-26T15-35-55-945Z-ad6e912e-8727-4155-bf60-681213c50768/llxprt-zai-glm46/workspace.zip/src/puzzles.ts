/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // \b ensures word boundary at start
  // Match the full word
  const pattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const word = match[1];
    // Only include if not in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit + token when token is preceded by a digit
  // This returns "1foo" not "foo" as required by the test
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 123123, xyxy)
  // This pattern captures any 2-4 character sequence and checks if it repeats immediately
  for (let len = 2; len <= 4; len++) {
    const repeatPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // First, check if it's a pure IPv4 (without any IPv6-like content)
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false;
  }
  
  // IPv6 patterns - simplified approach
  // Check if the value contains colons (characteristic of IPv6)
  if (!value.includes(':')) {
    return false;
  }
  
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons (e.g., 2001:0db8:85a3:0000:0000:8a2e:0370:7334)
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (e.g., 2001:db8::1, ::1, 2001::)
  const ipv6ShorthandPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:?)*/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6EmbeddedIPv4 = /(?:[0-9a-fA-F]{0,4}:)*:(?::[0-9a-fA-F]{0,4}:)*(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check for IPv6 patterns
  return ipv6FullPattern.test(value) || 
         ipv6ShorthandPattern.test(value) || 
         ipv6EmbeddedIPv4.test(value);
}
