import type { EqualFn, GetterFn, UpdateFn, Options, Observer } from '../types/reactive.js'
import { getActiveObserver, updateObserver } from './input.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
  _equal?: EqualFn<T>,
  _options?: Options
): GetterFn<T> {
  // Store current computed value
  let currentValue: T | undefined = _value
  
  // List of observers to notify when computed value changes
  const observers: Set<() => void> = new Set()
  
  // Default equality function uses strict equality
  const defaultEqual: EqualFn<T> = (a, b) => a === b
  const equalFn = _equal || defaultEqual
  
  // Create observer object
  const observer: Observer<T> = {
    name: _options?.name || 'computed',
    updateFn: () => {
      const newValue = updateFn(currentValue)
      
      // Check if value actually changed
      if (currentValue === undefined || !equalFn(currentValue, newValue)) {
        currentValue = newValue
        
        // Notify all observers that depend on this computed value
        const currentObservers = Array.from(observers)
        currentObservers.forEach(notify => {
          try {
            notify()
          } catch (error) {
            console.error('Error notifying computed observer:', error)
          }
        })
      }
      
      return currentValue
    }
  }
  
  const getter: GetterFn<T> = () => {
    // Register this computed value as a dependency for any active observer
    const activeObserver = getActiveObserver()
    
    if (activeObserver) {
      // Create a notification function that will update this observer when this computed value changes
      const observerRef = activeObserver
      const notify = () => {
        // When this computed value changes, trigger the observer's update
        const refObserver: Observer<T> = observerRef as Observer<T>
        updateObserver(refObserver)
      }
      observers.add(notify)
    }
    
    // Compute value if not already computed
    if (currentValue === undefined) {
      updateObserver(observer)
    }
    
    return currentValue as T
  }
  
  // Initial computation
  updateObserver(observer)
  
  return getter
}