import type { EqualFn, GetterFn, InputPair, Options, ObserverR, Observer } from '../types/reactive.js'

// Global active observer for dependency tracking
let activeObserver: ObserverR | undefined = undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Store current value
  let currentValue = value
  
  // List of observers to notify when value changes
  const observers: Set<() => void> = new Set()
  
  // Track if this input is currently notifying observers to prevent recursion
  let isNotifying = false
  
  // Default equality function uses strict equality
  const defaultEqual: EqualFn<T> = (a, b) => a === b
  const equalFn = equal || defaultEqual
  
  // Getter function
  const getter: GetterFn<T> = () => {
    // If there's an active observer, register this input as a dependency
    if (activeObserver && !isNotifying) {
      // Create a notification function that will recompute the observer when this input changes
      // Copy the observer reference to maintain the connection
      const observerRef = activeObserver
      const notify = () => {
        // Set this observer as active, then call its update function
        // This will recompute the computed value or trigger the callback
        if (observerRef) {
          updateObserver(observerRef as Observer<T>)
        }
      }
      observers.add(notify)
    }
    
    return currentValue
  }
  
  // Setter function
  const setter: (newValue: T) => T = (newValue: T) => {
    // Check if value actually changed using equality function
    if (!equalFn(currentValue, newValue) && !isNotifying) {
      currentValue = newValue
      
      // Notify all observers - this triggers recompute of computed values and callbacks
      isNotifying = true
      try {
        const currentObservers = Array.from(observers)
        currentObservers.forEach(notify => {
          try {
            notify()
          } catch (error) {
            console.error('Error in observer:', error)
          }
        })
      } finally {
        isNotifying = false
      }
    }
    
    return currentValue
  }
  
  return [getter, setter]
}