import type { UpdateFn, UnsubscribeFn, Observer } from '../types/reactive.js'
import { updateObserver } from './input.js'

export function createCallback<T>(
  updateFn: UpdateFn<T>,
  _value?: T
): UnsubscribeFn {
  // Track if callback is still active
  let isActive = true
  
  // Create observer object
  const observer: Observer<T> = {
    updateFn: (value?: T) => {
      if (isActive) {
        const result = updateFn(value || _value)
        // For callbacks, we execute the side effect and ignore return value
        return result as T
      }
      return (value || _value) as T
    }
  }
  
  // Execute the callback function immediately to establish dependencies
  if (isActive) {
    updateObserver(observer)
  }
  
  // Return unsubscribe function
  const unsubscribe: UnsubscribeFn = () => {
    isActive = false
    // In a more complete implementation, we would clean up dependencies
    // For now, just mark as inactive
  }
  
  return unsubscribe
}