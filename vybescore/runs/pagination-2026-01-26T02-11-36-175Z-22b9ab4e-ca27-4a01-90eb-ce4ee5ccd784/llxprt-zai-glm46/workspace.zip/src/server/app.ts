import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (isNaN(pageNum) || !Number.isFinite(pageNum) || pageNum <= 0 || pageNum > 1000000) {
        res.status(400).json({ error: 'Invalid page parameter' });
        return;
      }
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (isNaN(limitNum) || !Number.isFinite(limitNum) || limitNum <= 0 || limitNum > 1000) {
        res.status(400).json({ error: 'Invalid limit parameter' });
        return;
      }
    }

    const payload = listInventory(db, {
      page: pageParam !== undefined ? page as number : undefined,
      limit: limitParam !== undefined ? limit as number : undefined
    });
    res.json(payload);
  });

  return app;
}
