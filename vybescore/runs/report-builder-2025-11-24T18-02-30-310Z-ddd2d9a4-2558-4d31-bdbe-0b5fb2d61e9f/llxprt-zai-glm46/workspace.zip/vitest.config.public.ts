import { defineConfig } from 'vitest/config';
import { resolve } from 'path';

export default defineConfig({
  test: {
    include: ['tests/public/**/*.spec.ts'],
    environment: 'node',
    globals: true,
    includeSource: ['src/**/*.ts'],
    alias: {
      '@': resolve(__dirname, './src')
    }
  }
});
