#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, FormatType, RenderOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

function parseArguments(): {
  inputFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  
  // Find --format flag
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1] as FormatType;
  
  // Find --output flag (optional)
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  // Check for --includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  // Validate format
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }
  }
  
  return data as ReportData;
}

function loadJsonFile(filePath: string): unknown {
  try {
    const content = readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Malformed JSON in ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArguments();
    
    // Load and validate JSON data
    const rawData = loadJsonFile(inputFile);
    const reportData = validateReportData(rawData);
    
    // Set up render options
    const options: RenderOptions = {
      includeTotals,
    };
    
    // Choose renderer
    let output: string;
    if (format === 'markdown') {
      output = markdownRenderer.render(reportData, options);
    } else if (format === 'text') {
      output = textRenderer.render(reportData, options);
    } else {
      // This should never happen due to earlier validation
      throw new Error('Unsupported format');
    }
    
    // Output to file or stdout
    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
    
    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

// Always run main() when this file is executed
main();