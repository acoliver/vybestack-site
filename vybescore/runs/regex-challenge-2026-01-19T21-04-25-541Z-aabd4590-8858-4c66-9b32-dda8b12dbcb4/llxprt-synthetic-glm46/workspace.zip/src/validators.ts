export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation with regex
 * Accepts name@tag@example.co.uk format
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles most cases while rejecting obviously invalid forms
  // Note: Using a simplified regex approach for better validation
  
  // More specific regex to reject problematic cases
  // No double dots in local part or domain
  // No leading or trailing dots
  // No underscores in domain
  const validEmailRegex = /^(?!.*\.\.)[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+[a-zA-Z0-9]@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}(?!.*\.\.)$/;
  
  // Check for underscores in domain part after the @ (invalid)
  // The pattern should be username@domain where domain cannot contain underscores
  const underscoreInDomain = /@[a-zA-Z0-9_-]*_[a-zA-Z0-9_-]*(\.[a-zA-Z0-9_-]*)*$/;
  
  return validEmailRegex.test(value) && !underscoreInDomain.test(value);
}

/**
 * US phone number validation
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove any whitespace for validation
  const cleanedValue = value.replace(/\s+/g, '');
  
  // Check for invalid characters at the beginning
  // eslint-disable-next-line no-useless-escape
  if (cleanedValue && !cleanedValue.match(/^[\d()\-\.\+\s]+$/)) {
    return false;
  }
  
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  
  // Regex pattern that matches valid US phone formats:
  // - Optional +1 country code
  // - Optional parentheses around area code
  // - Valid area codes (first digit cannot be 0 or 1)
  // - 7-digit subscriber number
  // - Accepts hyphens, spaces, or no separators
  const usPhoneRegex = /^(?:\+1)?(?:\(?[2-9]\d{2}\)?[-.\s]?|[2-9]\d{2}[-.\s]?)\d{3}[-.\s]?\d{4}$/;
  
  // Check minimum length (at least 10 digits for a valid US number without country code)
  if (cleanedValue.replace(/\D/g, '').length < 10) {
    return false;
  }
  
  // First check with the regex
  if (!usPhoneRegex.test(cleanedValue)) {
    return false;
  }
  
  // Extract digits for validation
  const digits = cleanedValue.replace(/\D/g, '');
  
  // For numbers with country code, remove it for validation
  const digitsWithoutCountry = digits.startsWith('1') && digits.length > 10 ? digits.substring(1) : digits;
  
  // Validate length is exactly 10 digits
  if (digitsWithoutCountry.length !== 10) {
    return false;
  }
  
  // Check area code rules (first digit cannot be 0 or 1)
  const areaCode = digitsWithoutCountry.substring(0, 3);
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  return true;
}

/**
 * Argentine phone number validation
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number (after the area code) must contain 6-8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, etc.) for validation
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Check for valid characters (digits and optional + at the beginning)
  if (!/^[\d+]+$/.test(cleanedValue)) {
    return false;
  }
  
  // Extract digits only for length validation
  const digitsOnly = cleanedValue.replace(/\D/g, '');
  
  // Check minimum length for Argentine numbers (area code 2-4 + subscriber 6-8 = 8-12 digits)
  if (digitsOnly.length < 8 || digitsOnly.length > 12) {
    return false;
  }
  
  // Argentine phone regex with all the specified rules:
  const detailedRegex = /^(\+54)?(?:(9)?(0))?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!detailedRegex.test(cleanedValue)) {
    return false;
  }
  
  // Extract parts for validation
  const match = cleanedValue.match(detailedRegex);
  if (!match) {
    return false;
  }
  
  const countryCode = match[1]; // Optional +54
  // const mobilePrefix = match[2]; // Optional 9 (unused but needed for grouping)
  const trunkPrefix = match[3]; // Optional 0
  const areaCode = match[4]; // 2-4 digits
  const subscriberNumber = match[5]; // 6-8 digits
  
  // Valid area code: 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Valid subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Additional validation: when country code is omitted, must begin with 0
  if (!countryCode) {
    // If no country code, must begin with 0 trunk prefix
    if (!trunkPrefix) {
      return false;
    }
  }
  
  return true;
}

/**
 * Name validation
 * Permits unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Reject empty names or names with only whitespace
  if (!value || !value.trim()) {
    return false;
  }
  
  // Name regex allowing:
  // - Unicode letters
  // - Accents and diacritics
  // - Apostrophes and hyphens
  // - Spaces between words
  // Not allowing:
  // - Digits
  // - Special symbols (except apostrophe and hyphen)
  // - Multiple consecutive spaces or hyphens
  const nameRegex = /^[a-zA-Z\u00C0-\u024FÀ-ÿ\u0100-\u017F\u0400-\u04FF\s'-]+$/;
  
  // Check for basic pattern match
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: no digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Additional validation: no special symbols except ' and -
  const specialSymbols = /[!"#$%&()*+,./:;<=>?@[\\]^_`{|}~]/;
  if (specialSymbols.test(value)) {
    return false;
  }
  
  // Check for non-alphabetic characters that look like X Æ A-12 style names
  // This is a heuristic - if there are non-Latin characters mixed with Latin/numbers/ symbols
  const mixedPattern = /(?:[a-zA-ZÀ-ÿ]+\s+.*\d)|[\u00C0-\u024FÀ-ÿ][0-9]/;
  if (mixedPattern.test(value)) {
    return false;
  }
  
  // Check there's at least one letter character
  const hasLetter = /[a-zA-ZÀ-ÿ\u0100-\u017F\u0400-\u04FF]/.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Credit card validation
 * Accepts Visa/Mastercard/AmEx prefixes and lengths
 * Runs a Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanedValue = value.replace(/[ -]/g, '');
  
  // Check if value contains only digits
  if (!/^\d+$/.test(cleanedValue)) {
    return false;
  }
  
  // Check length and prefix for major credit card types
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the card type patterns
  const isValidCardType = visaRegex.test(cleanedValue) || 
                          mastercardRegex.test(cleanedValue) || 
                          amexRegex.test(cleanedValue);
  
  if (!isValidCardType) {
    return false;
  }
  
  // Perform Luhn algorithm checksum
  return runLuhnCheck(cleanedValue);
}

/**
 * Helper function to perform Luhn algorithm checksum
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      // Double the digit and sum the digits if result is > 9
      const doubled = digit * 2;
      sum += doubled > 9 ? 1 + (doubled % 10) : doubled;
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
