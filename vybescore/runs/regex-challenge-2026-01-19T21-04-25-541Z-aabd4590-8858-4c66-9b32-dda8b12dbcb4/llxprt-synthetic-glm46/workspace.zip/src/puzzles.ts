/**
 * Find prefixed words
 * Returns words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Split the text into words and filter for those starting with the prefix
  const words = text.split(/\s+/);
  
  // Find words that start with the prefix (case insensitive)
  const matchingWords = words.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerPrefix = prefix.toLowerCase();
    return lowerWord.startsWith(lowerPrefix);
  });
  
  // Filter out exceptions (case insensitive) and deduplicate
  const filteredWords = matchingWords.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
    
    // Include only if not in exceptions
    return !lowerExceptions.includes(lowerWord);
  });
  
  // Deduplicate and return
  return [...new Set(filteredWords)];
}

/**
 * Find embedded tokens after digits
 * Returns occurrences where the token appears after a digit and not at the start of the string
 * Uses lookaheads/lookbehinds
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Use a two-step approach to avoid lookbehind issues
  // First, find all occurrences of the token in the text
  const tokenRegex = new RegExp(`\\d${token.replace(/[.*+?^${}()|[\\]/g, '\\$&')}`, 'g');
  const allMatches = text.match(tokenRegex) || [];
  
  // Deduplicate results
  return [...new Set(allMatches)];
}

/**
 * Strong password validation
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  const hasUppercase = /[A-Z]/.test(value);
  if (!hasUppercase) {
    return false;
  }
  
  // Check for at least one lowercase letter
  const hasLowercase = /[a-z]/.test(value);
  if (!hasLowercase) {
    return false;
  }
  
  // Check for at least one digit
  const hasDigit = /\d/.test(value);
  if (!hasDigit) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>]/.test(value);
  if (!hasSymbol) {
    return false;
  }
  
  // Check for whitespace (not allowed)
  const hasWhitespace = /\s/.test(value);
  if (hasWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This is a simplified check that looks for patterns where a character sequence of 
  // 2-4 characters is immediately followed by itself
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + 2 * len);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * IPv6 address detection
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex pattern that matches valid IPv6 addresses
  // Handles various formats including shorthand with ::
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|:(([0-9a-fA-F]{1,4}:){1,4}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,3}|:(?:[0-9a-fA-F]{1,4}:){0,3}(?::[0-9a-fA-F]{1,4}){1,4})))(%[0-9a-zA-Z]{1,})?/;
  
  // Check if the value contains an IPv6 address
  const hasIPv6 = ipv6Regex.test(value);
  
  // If we didn't find an IPv6 address, return false
  if (!hasIPv6) {
    return false;
  }
  
  // Now check if the value might also be an IPv4 address
  // IPv4 pattern: 0-255.0-255.0-255.0-255
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If the value contains IPv4 but not IPv6, return false
  if (ipv4Regex.test(value) && !hasIPv6) {
    return false;
  }
  
  // At this point, we found IPv6 and either didn't find IPv4 or found both
  // So return true (it contains IPv6)
  return true;
}
