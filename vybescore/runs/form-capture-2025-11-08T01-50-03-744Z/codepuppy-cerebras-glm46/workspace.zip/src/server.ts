import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import sqljs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class FormServer {
  public app: express.Application;
  private db: sqljs.Database | null = null;
  public server: any = null;
  public dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Initialize sql.js
      const SQL = await sqljs();
      
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
        this.db.run(schema);
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation
    if (data.email?.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({ field: 'email', message: 'Please enter a valid email address' });
      }
    }

    // Phone validation - allow international formats
    if (data.phone?.trim()) {
      const phoneRegex = /^[\+\d\s\(\)\-]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
      }
    }

    // Postal code validation - alphanumeric allowed
    if (data.postalCode?.trim()) {
      const postalRegex = /^[a-zA-Z0-9\s\-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and dashes' });
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', { 
        errors: [], 
        values: {} as FormData 
      });
    });

    this.app.post('/submit', (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);
      
      if (errors.length > 0) {
        const errorMessages = errors.map(e => e.message);
        res.render('form', {
          errors: errorMessages,
          values: formData
        });
        return;
      }

      // Insert into database
      if (this.db) {
        try {
          const stmt = this.db.prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          stmt.run(
            formData.firstName.trim(),
            formData.lastName.trim(),
            formData.streetAddress.trim(),
            formData.city.trim(),
            formData.stateProvince.trim(),
            formData.postalCode.trim(),
            formData.country.trim(),
            formData.email.trim(),
            formData.phone.trim()
          );
          stmt.free();
          this.saveDatabase();
        } catch (error) {
          console.error('Database insertion error:', error);
          res.status(500).render('form', {
            errors: ['An error occurred while saving your submission. Please try again.'],
            values: formData
          });
          return;
        }
      }

      // Redirect to thank you page
      res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
    });

    this.app.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  private shutdown(): void {
    console.log('Shutting down server...');
    
    if (this.db) {
      try {
        this.db.close();
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    } else {
      process.exit(0);
    }
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default server;