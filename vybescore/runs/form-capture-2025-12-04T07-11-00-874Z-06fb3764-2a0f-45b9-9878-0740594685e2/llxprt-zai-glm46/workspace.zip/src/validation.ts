export interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export function validateForm(values: FormValues): ValidationResult {
  const errors: string[] = [];

  if (!values.firstName || values.firstName.trim().length === 0) {
    errors.push('First name is required');
  }

  if (!values.lastName || values.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }

  if (!values.streetAddress || values.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }

  if (!values.city || values.city.trim().length === 0) {
    errors.push('City is required');
  }

  if (!values.stateProvince || values.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  }

  if (!values.postalCode || values.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else if (!/^[A-Za-z0-9\s-]+$/.test(values.postalCode.trim())) {
    errors.push('Postal code can only contain letters, numbers, spaces, and hyphens');
  }

  if (!values.country || values.country.trim().length === 0) {
    errors.push('Country is required');
  }

  if (!values.email || values.email.trim().length === 0) {
    errors.push('Email is required');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(values.email.trim())) {
      errors.push('Please enter a valid email address');
    }
  }

  if (!values.phone || values.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(values.phone.trim())) {
      errors.push('Phone number can only contain digits, spaces, parentheses, hyphens, and a leading +');
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

export function sanitizeValues(values: FormValues): FormValues {
  const sanitized: FormValues = {};
  
  for (const [key, value] of Object.entries(values)) {
    if (typeof value === 'string') {
      sanitized[key as keyof FormValues] = value.trim();
    } else {
      sanitized[key as keyof FormValues] = value;
    }
  }
  
  return sanitized;
}