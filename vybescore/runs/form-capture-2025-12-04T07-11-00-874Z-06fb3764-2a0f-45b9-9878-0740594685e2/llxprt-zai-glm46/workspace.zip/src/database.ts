import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');

interface DatabaseConnection {
  db: import('sql.js').Database;
}

let dbConnection: DatabaseConnection | null = null;

export async function initializeDatabase(): Promise<DatabaseConnection> {
  if (dbConnection) {
    return dbConnection;
  }

  const SQL = await initSqlJs();
  let db: import('sql.js').Database;

  try {
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      const uint8Array = new Uint8Array(fileBuffer);
      db = new SQL.Database(uint8Array);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
      db.run(schema);
      persistDatabase(db);
    }
  } catch (error) {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
    db.run(schema);
    persistDatabase(db);
  }

  dbConnection = { db };
  return dbConnection;
}

export function getDatabase(): DatabaseConnection {
  if (!dbConnection) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return dbConnection;
}

export function persistDatabase(db: import('sql.js').Database): void {
  try {
    const data = db.export();
    if (!fs.existsSync(path.dirname(DB_PATH))) {
      fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    }
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to persist database:', error);
  }
}

export function closeDatabase(): void {
  if (dbConnection) {
    persistDatabase(dbConnection.db);
    dbConnection.db.close();
    dbConnection = null;
  }
}

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(submission: Submission): number {
  const { db } = getDatabase();
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone
  ]);
  
  stmt.free();
  
  const result = db.exec('SELECT last_insert_rowid() as id');
  const id = result[0].values[0][0] as number;
  
  persistDatabase(db);
  
  return id;
}