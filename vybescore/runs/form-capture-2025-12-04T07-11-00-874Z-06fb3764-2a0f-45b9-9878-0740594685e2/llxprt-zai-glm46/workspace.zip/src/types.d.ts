declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): Array<{
      columns: string[];
      values: unknown[][];
    }>;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export class Statement {
    run(...params: unknown[]): void;
    step(): unknown;
    get(): unknown;
    free(): void;
  }
}

declare module 'sql.js' {
  interface SqlJsStatic {
    Database: typeof Database;
    Statement: typeof Statement;
  }
  
  export default function sqlite3(): Promise<SqlJsStatic>;
}