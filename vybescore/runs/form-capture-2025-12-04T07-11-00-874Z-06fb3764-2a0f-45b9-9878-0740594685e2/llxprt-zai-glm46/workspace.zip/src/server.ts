import express from 'express';
import path from 'node:path';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, sanitizeValues } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const sanitizedValues = sanitizeValues(req.body);
  const validation = validateForm(sanitizedValues);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: sanitizedValues
    });
  }

  try {
    insertSubmission({
      firstName: sanitizedValues.firstName!,
      lastName: sanitizedValues.lastName!,
      streetAddress: sanitizedValues.streetAddress!,
      city: sanitizedValues.city!,
      stateProvince: sanitizedValues.stateProvince!,
      postalCode: sanitizedValues.postalCode!,
      country: sanitizedValues.country!,
      email: sanitizedValues.email!,
      phone: sanitizedValues.phone!
    });

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: sanitizedValues
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');

    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    const gracefulShutdown = (signal: string) => {
      console.log(`Received ${signal}, shutting down gracefully...`);
      server.close(() => {
        console.log('HTTP server closed');
        closeDatabase();
        console.log('Database connection closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
