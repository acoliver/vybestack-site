/**
 * Capitalizes the first character of each sentence.
 * Handles sentence boundaries at .?!, ensures proper spacing, collapses extra spaces.
 * Attempts to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Trim the text first
  let result = text.trim();
  
  // Collapse multiple spaces into single spaces
  result = result.replace(/\s+/g, ' ');
  
  // Capitalize the first letter
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize letters after sentence-ending punctuation
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Finds URLs in text and returns them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches common URL formats
  // Matches http/https/www protocols, domain names, IP addresses, ports, paths
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"']+(?=\b|$)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation that's unlikely to be part of the URL
    return url.replace(/[.,;:!?)\]\}]+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// globally
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites example.com URLs to use HTTPS and moves /docs/ paths to docs.example.com.
 * Skips host rewrite for dynamic hints (cgi-bin, query params, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/(https?:\/\/)(example\.com\/)([^\s]*)/gi, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if we should skip host rewrite
    const skipHostRewrite = /(?:cgi-bin|[?&=]|\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:\?.*)?$)/i.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = /^docs\//i.test(path);
    
    if (isDocsPath && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return newProtocol + 'docs.' + domain.replace('/', '') + '/' + path;
    } else {
      // Just upgrade protocol, keep domain
      return newProtocol + domain + path;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, month, day, year] = dateMatch;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation, not considering leap years fully)
  const daysInMonth = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > daysInMonth[monthNum as keyof typeof daysInMonth]) {
    return 'N/A';
  }
  
  return year;
}
