export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Valid email addresses with typical constraints.
 * Supports name+tag@example.co.uk format, rejects double dots, trailing dots, underscores in domains.
 */
export function isValidEmail(value: string): boolean {
  // Email regex: local part + @ + domain
  // Local part: alphanumeric + .!#$%&'*+/=?^_`{|}~- (no consecutive dots, no leading/trailing dots)
  // Domain: alphanumeric + hyphens, no underscores, at least one dot, no consecutive dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+$/;
  
  // Quick regex check first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // No consecutive dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No leading dot in local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain shouldn't have leading/trailing dots
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Domain shouldn't have consecutive dots
  if (domain.includes('..')) {
    return false;
  }
  
  // Domain shouldn't have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, possibly with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Extract actual phone number (without country code)
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    // Must start with 1 for US country code
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
    phoneNumber = digitsOnly.slice(1);
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) can't start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Format validation using regex
  // Acceptable formats:
  // (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890
  // Optional +1 prefix with or without separators
  const phoneRegex = /^(?:\+1[\s-]?|1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s.-]?)\d{3}[\s.-]?\d{4}$/;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(normalized)) {
    return false;
  }
  
  // Extract components for detailed validation
  let remaining = normalized;
  let hasCountryCode = false;
  
  // Check for country code
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check for trunk prefix
  let hasTrunkPrefix = false;
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = areaCodeMatch[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Can't be empty
  if (trimmed.length === 0) {
    return false;
  }
  
  // Name regex: unicode letters, accents, apostrophes, hyphens, spaces
  // \p{L} matches any unicode letter
  // \p{M} marks for combining characters (accents)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Reject names that are just symbols or contain only special characters
  const letterCount = (trimmed.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letterCount === 0) {
    return false;
  }
  
  // Reject consecutive apostrophes or hyphens
  if (trimmed.includes("''") || trimmed.includes('--')) {
    return false;
  }
  
  // Reject names starting or ending with apostrophe or hyphen
  if (trimmed.startsWith("'") || trimmed.endsWith("'") || 
      trimmed.startsWith('-') || trimmed.endsWith('-')) {
    return false;
  }
  
  // Reject excessive special characters (more than 2 apostrophes or hyphens each)
  const apostropheCount = (trimmed.match(/'/g) || []).length;
  const hyphenCount = (trimmed.match(/-/g) || []).length;
  if (apostropheCount > 2 || hyphenCount > 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) using prefix/length rules and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Check length: Visa (13, 16), Mastercard (16), AmEx (15)
  const length = normalized.length;
  if (length < 13 || length > 16) {
    return false;
  }
  
  // Check prefixes
  let isValidPrefix = false;
  
  // Visa: starts with 4
  if (normalized.startsWith('4') && (length === 13 || length === 16)) {
    isValidPrefix = true;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720
  if (length === 16) {
    const firstTwo = parseInt(normalized.slice(0, 2));
    const firstFour = parseInt(normalized.slice(0, 4));
    
    if ((firstTwo >= 51 && firstTwo <= 55) || 
        (firstFour >= 2221 && firstFour <= 2720)) {
      isValidPrefix = true;
    }
  }
  
  // AmEx: starts with 34 or 37
  if ((normalized.startsWith('34') || normalized.startsWith('37')) && length === 15) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(normalized);
}

/**
 * helper function to run the Luhn checksum algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
