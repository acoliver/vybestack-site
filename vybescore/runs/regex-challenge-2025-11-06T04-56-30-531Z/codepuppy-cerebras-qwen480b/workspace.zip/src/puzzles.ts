/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words
  const words = text.split(/\s+/);
  
  // Filter words that start with the prefix
  const prefixedWords = words.filter(word => 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );
  
  // Filter out exceptions (case-insensitive)
  const filteredWords = prefixedWords.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
  
  // Remove duplicates and return
  return [...new Set(filteredWords)];
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  // Split the text and look for digit followed by token
  const parts = text.split(/\s+/);
  
  for (const part of parts) {
    // Check if this part matches digit + token pattern
    const match = part.match(/^(\d+)(.+)$/);
    if (match) {
      const [, digit, rest] = match;
      if (rest === token) {
        results.push(digit + token);
      }
    }
  }
  
  return results;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like abab, abcabc, etc.
  // Check for patterns of length 2-6 that repeat immediately
  for (let len = 2; len <= 6; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const segment1 = value.substr(i, len);
      const segment2 = value.substr(i + len, len);
      if (segment1 === segment2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches:
  // - Full IPv6 addresses (8 groups of 4 hex digits)
  // - Compressed forms with ::
  // - IPv6 with embedded IPv4 should not match (we want pure IPv6 only)
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b::(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b|\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b|\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b|\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\b|\b:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)\b/;
  
  // First ensure it's not an IPv4 address
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  return ipv6Regex.test(value);
}