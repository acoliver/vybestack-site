/**
 * Entry in a financial report
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering reports
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Report formatter interface
 */
export interface ReportFormatter {
  render(data: ReportData, options: RenderOptions): string;
}