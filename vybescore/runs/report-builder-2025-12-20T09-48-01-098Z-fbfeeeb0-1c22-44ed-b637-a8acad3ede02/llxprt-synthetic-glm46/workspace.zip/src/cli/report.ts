#!/usr/bin/env node

import fs from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * CLI configuration
 */
interface CliConfig {
  dataPath: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments
 */
function parseArgs(): CliConfig {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex !== args.length - 1 
    ? args[outputIndex + 1] 
    : undefined;
    
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Validate and parse JSON data
 */
function parseReportData(dataPath: string): ReportData {
  try {
    if (!fs.existsSync(dataPath)) {
      throw new Error(`File not found: ${dataPath}`);
    }
    
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    const parsedData = JSON.parse(fileContent);
    
    // Validate required fields
    if (typeof parsedData.title !== 'string') {
      throw new Error('Missing or invalid "title" field in JSON data');
    }
    
    if (typeof parsedData.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field in JSON data');
    }
    
    if (!Array.isArray(parsedData.entries)) {
      throw new Error('Missing or invalid "entries" field in JSON data');
    }
    
    // Validate entries
    for (let i = 0; i < parsedData.entries.length; i++) {
      const entry = parsedData.entries[i];
      if (typeof entry.label !== 'string') {
        throw new Error(`Missing or invalid "label" in entry ${i}`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Missing or invalid "amount" in entry ${i}`);
      }
    }
    
    return parsedData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${dataPath}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

/**
 * Render report based on format
 */
function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error('Unsupported format');
  }
}

/**
 * Main CLI execution
 */
function main(): void {
  try {
    const config = parseArgs();
    const data = parseReportData(config.dataPath);
    
    const options: RenderOptions = {
      includeTotals: config.includeTotals,
    };
    
    const output = renderReport(data, config.format, options);
    
    if (config.outputPath) {
      try {
        fs.writeFileSync(config.outputPath, output, 'utf-8');
        console.log(`Report written to ${config.outputPath}`);
      } catch (error) {
        console.error(`Error writing to ${config.outputPath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
