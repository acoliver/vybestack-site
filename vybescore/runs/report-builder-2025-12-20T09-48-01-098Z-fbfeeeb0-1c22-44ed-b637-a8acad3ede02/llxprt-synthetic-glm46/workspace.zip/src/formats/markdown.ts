import { ReportData, RenderOptions, ReportFormatter } from '../types.js';

/**
 * Format an amount as a dollar amount with exactly two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate the total of all entries
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render a report in Markdown format
 */
export const renderMarkdown: ReportFormatter['render'] = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];
  
  // Add title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries section
  lines.push('## Entries');
  
  // Add each entry as a bullet point
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Add total if requested
  if (options.includeTotals && data.entries.length > 0) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};