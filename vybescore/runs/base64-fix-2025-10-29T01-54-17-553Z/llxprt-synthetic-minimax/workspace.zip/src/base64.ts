/**
 * Encode plain text to standard Base64 (RFC 4648).
 * Uses canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid input.
 */
export function decode(input: string): string {
  // Normalize input: accept both standard and URL-safe Base64
  let normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Add padding if missing
  const remainder = normalized.length % 4;
  if (remainder === 2) {
    normalized += '==';
  } else if (remainder === 3) {
    normalized += '=';
  } else if (remainder !== 0) {
    throw new Error('Invalid Base64 input: invalid length');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
