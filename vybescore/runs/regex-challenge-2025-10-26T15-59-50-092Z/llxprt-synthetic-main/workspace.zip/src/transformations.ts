/**
 * Capitalize the first character of each sentence while preserving abbreviations
 * Insert exactly one space between sentences and collapse extra spaces
 */
export function capitalizeSentences(text: string): string {
  // First, trim the text
  let result = text.trim();
  
  // Collapse multiple spaces into a single space
  result = result.replace(/\s+/g, ' ');
  
  // Split into sentences by punctuation followed by any amount of space
  // We use a more precise approach to handle punctuation correctly
  const sentences = result.split(/([.!?])\s*/);
  
  // Rebuild the text with properly capitalized sentences
  result = '';
  let sentenceStart = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (!part) continue;
    
    // If this is punctuation
    if (part.length === 1 && /[.!?]/.test(part)) {
      result += part;
      sentenceStart = true;
    } 
    // If this is regular text following punctuation (a sentence)
    else if (sentenceStart) {
      // Capitalize first letter
      result += part.charAt(0).toUpperCase() + part.slice(1);
      sentenceStart = false;
    } 
    else {
      result += part;
    }
  }
  
  // Ensure proper spacing after punctuation
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  return result;
}

/**
 * Extract all URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with various protocols and domains
  // This regex captures URLs with http, https, ftp protocols and www domains
  const urlRegex = /((?:https?:\/\/|ftp:\/\/|www\.)[^\s/$.?#].[^\s]*)(?=\s|[,.!?;:"')]*(?:\s|$))/gi;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0] || match[1];
    
    // Remove trailing punctuation
    url = url.replace(/[.,!?;:'")\]]+$/g, '');
    
    // Ensure www URLs have http:// prefix for validity
    if (url.startsWith('www.')) {
      url = 'http://' + url;
    }
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Regex to match http URLs, but not https
  const httpUrlRegex = /http:\/\/(?!https:\/\/)/g;
  
  return text.replace(httpUrlRegex, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable
 * Skips host rewrite for dynamic paths or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const exampleUrlRegex = /https?:\/\/example\.com(\/.*)?/gi;
  
  return text.replace(exampleUrlRegex, (match, path) => {
    // First, always upgrade to https
    let result = match.replace(/^http:\/\//, 'https://');
    
    // If there's no path, we're done
    if (!path) return result;
    
    // Skip host rewrite for dynamic paths or legacy extensions
    const dynamicPatterns = [
      /\/(cgi-bin)\//i,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i
    ];
    
    const skipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
    
    // If path begins with /docs/ and we're not skipping, rewrite to docs.example.com
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      result = 'https://docs.example.com' + path;
    }
    
    return result;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string for return
  
  // Validate day based on month (including leap year for February)
  const monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Adjust for leap year
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || 
                     (parseInt(year, 10) % 400 === 0);
  
  if (month === 2 && isLeapYear) {
    if (day > 29) return 'N/A';
  } else {
    if (day > monthDays[month - 1]) return 'N/A';
  }
  
  return year;
}