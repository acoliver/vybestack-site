export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // - Local part: letters, digits, +, -, ., _ but no consecutive dots or starting/ending dots
  // - Domain: letters, digits, hyphen, but no underscores
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for specific requirements
  // No double dots in the entire email
  if (value.includes('..')) return false;
  
  // No trailing dot in domain
  if (value.endsWith('.')) return false;
  
  // No underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  // No consecutive dots in domain part
  if (domain && domain.includes('..')) return false;
  
  // Email must match the basic regex
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers with various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Clean the input to extract only digits and extension if allowed
  const cleanedValue = value.trim();
  
  // Start with basic regex validation
  // Optional +1 country code
  // Area code (3 digits, first digit not 0 or 1)
  // Exchange code (3 digits, first digit not 0 or 1)
  // Subscriber number (4 digits)
  // Allow optional extensions if specified in options
  const phoneRegex = /^\+?1?(?:[\s-]?)\(?([2-9]\d{2})\)?(?:[\s-]?)([2-9]\d{2})(?:[\s-]?)(\d{4})(?:[\s-]?(?:ext\.?|extension|#)?[\s-]?(\d+))?$/i;
  
  const match = cleanedValue.match(phoneRegex);
  if (!match) return false;
  
  // Validate minimum length
  const digitsOnly = cleanedValue.replace(/\D/g, '');
  
  // If there's a +1 prefix, we should have at least 11 digits (including country code)
  // Otherwise, at least 10 digits
  if (cleanedValue.startsWith('+1') && digitsOnly.length < 11) return false;
  if (!cleanedValue.startsWith('+1') && digitsOnly.length < 10) return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input to handle spaces, hyphens, and other separators
  const cleanedValue = value.trim().replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code is omitted)
  // Optional 9 mobile prefix
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Special case for numbers without country code but with trunk prefix
  const argentinePhoneWithTrunkRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  // Test the general pattern first
  let match = cleanedValue.match(argentinePhoneRegex);
  
  // If that doesn't match, try the trunk-only pattern
  if (!match) {
    match = cleanedValue.match(argentinePhoneWithTrunkRegex);
    if (match) {
      // For trunk-only pattern, we need to extract the relevant parts
      // and validate them using the same logic
      const areaCode = match[1];
      const subscriberNumber = match[2];
      
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      // Subscriber number must be 6-8 digits
      if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
      
      return true;
    }
    return false;
  }
  
  // For the general pattern, validate the parts
  const countryCode = match[1]; // +54 or undefined
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // If country code is provided, it must be +54
  if (countryCode && countryCode !== '+54') return false;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens
 * Rejects digits, symbols, and names like X Æ A-12
 */
export function isValidName(value: string): boolean {
  // Name validation using regex
  // Must include at least one letter
  // May include spaces, hyphens, apostrophes
  // May include accented characters (unicode letters)
  // Reject digits and most special symbols
  const nameRegex = /^[\p{L}][\p{L}'\-]*([\s''][\p{L}'\-]*)*$/u;
  
  // Check against the regex
  if (!nameRegex.test(value.trim())) return false;
  
  // Also ensure the name doesn't contain digits or unusual symbols
  if (/\d/.test(value)) return false;
  
  // Reject names with unusual symbols like "X Æ A-12"
  if (/[^a-zA-Z\u00C0-\u017F\s'\-]/.test(value)) return false;
  
  return true;
}

/**
 * Luhn algorithm helper function for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\s/g, ''); // Remove spaces
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx
 * Checks prefixes, lengths, and runs Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces from the input
  const cleanedValue = value.replace(/\s/g, '');
  
  // Check if the input contains only digits
  if (!/^\d+$/.test(cleanedValue)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[0-1]\d|720)\d{12})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card matches any of the supported card types
  const isValidFormat = visaRegex.test(cleanedValue) || 
                        mastercardRegex.test(cleanedValue) || 
                        amexRegex.test(cleanedValue);
  
  // If format is valid, run Luhn check
  if (!isValidFormat) return false;
  
  return runLuhnCheck(cleanedValue);
}
