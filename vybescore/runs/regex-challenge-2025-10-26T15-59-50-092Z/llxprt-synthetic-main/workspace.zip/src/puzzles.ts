/**
 * Find words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match words starting with the prefix
  // \b ensures we match whole words
  // \w+ matches the rest of the word
  // The regex will match words like prefixword, prefixlongerword, etc.
  const wordPattern = new RegExp(`\\b${prefix}\\w+`, 'gi');
  
  const matches: string[] = [];
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  let match;
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0];
    const lowerWord = word.toLowerCase();
    
    // Skip if the word is in the exceptions list
    if (!exceptionSet.has(lowerWord)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex to handle special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find the token after a digit but not at the start of the string
  // We use a workaround for lookbehind since it's not universally supported
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    // Ensure the match is not at the start of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy: at least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one special character (non-alphanumeric)
  if (!/[^\w]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex checks for patterns where a sequence of 2 or more characters is immediately repeated
  const repeatedSequenceRegex = /(..+?)\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and ensure IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address regex patterns
  // A comprehensive IPv6 regex that matches various IPv6 formats
  // Including full, shorthand, IPv4-embedded, and IPv6 addresses with :: notation
  const ipv6Regex = /(?:^|(?<![\d.]))((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:)|(([0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,5}(:[0-9A-Fa-f]{1,4}){1,2})|(([0-9A-Fa-f]{1,4}:){1,4}(:[0-9A-Fa-f]{1,4}){1,3})|(([0-9A-Fa-f]{1,4}:){1,3}(:[0-9A-Fa-f]{1,4}){1,4})|(([0-9A-Fa-f]{1,4}:){1,2}(:[0-9A-Fa-f]{1,4}){1,5})|([0-9A-Fa-f]{1,4}:((:[0-9A-Fa-f]{1,4}){1,6}))|(:((:[0-9A-Fa-f]{1,4}){1,7}|:)))(?:$|(?![\d.]))/g;
  
  // IPv4 address regex to exclude
  const ipv4Regex = /(?<!([\d.]*))(?:\d{1,3}\.){3}\d{1,3}(?![\d.])/g;
  
  // First, check if the text contains IPv6 patterns
  const hasIPv6 = ipv6Regex.test(value);
  
  // Reset regex lastIndex
  ipv6Regex.lastIndex = 0;
  
  if (!hasIPv6) return false;
  
  // Find all potential matches
  const ipv6Matches = value.match(ipv6Regex) || [];
  const ipv4Matches = value.match(ipv4Regex) || [];
  
  // If there are any IPv6 matches that are not IPv4 matches, return true
  return ipv6Matches.length > ipv4Matches.length;
}