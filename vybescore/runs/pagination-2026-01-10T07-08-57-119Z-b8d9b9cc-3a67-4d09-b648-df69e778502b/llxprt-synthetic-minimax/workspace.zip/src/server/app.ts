import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validation for page parameter
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!Number.isFinite(pageNum) || pageNum <= 0 || pageNum > 100) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive number between 1 and 100.' });
      }
    }

    // Validation for limit parameter
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!Number.isFinite(limitNum) || limitNum <= 0 || limitNum > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive number between 1 and 100.' });
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
