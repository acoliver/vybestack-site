import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer } from '../../src/server';

let server: ReturnType<typeof app.listen>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize the database in test environment
  await startServer();
  // We directly use the app for testing
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(async () => {
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => { 
        resolve();
      });
    });
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    
    const $ = cheerio.load(res.text);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const res = await request(app).post('/submit').send(formData);
    
    // Debug response
    console.log('Response status:', res.status);
    console.log('Response location:', res.headers.location);
    console.log('Response body preview:', res.text.substring(0, 200));
    
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/thank-you');
    
    // Verify database was created and data persisted
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check thank you page
    const thankYouRes = await request(app).get('/thank-you');
    expect(thankYouRes.status).toBe(200);
    const $ = cheerio.load(thankYouRes.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('h1:contains("Thank you")').length).toBe(1);
  });

  it('displays validation errors', async () => {
    const formData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: ''
    };
    
    const res = await request(app).post('/submit').send(formData);
    expect(res.status).toBe(400);
    
    const $ = cheerio.load(res.text);
    expect($('.error-list').length).toBe(1);
    expect($('li:contains("First name is required")').length).toBe(1);
    expect($('.error-list').length).toBe(1);
    // Check if error list contains email validation message
    const errorText = $('.error-list').text();
    expect(errorText).toContain('First name is required');
  });
});
