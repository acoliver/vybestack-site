import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// SQL.js import for WASM SQLite
import initSqlJs from 'sql.js';
import { FormData, ValidationError } from './types.js';
import type { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

let db: Database; // SQL.js database

// Initialize database
async function initializeDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    // Load or create database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      // Create tables from schema
      const schema = fs.readFileSync(
        path.resolve(__dirname, '..', 'db', 'schema.sql'),
        'utf8'
      );
      db.run(schema);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Phone can contain digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  return phoneRegex.test(phone);
}

function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}

function convertFormData(formData: Record<string, unknown>): FormData {
  return {
    firstName: String(formData.firstName || ''),
    lastName: String(formData.lastName || ''),
    streetAddress: String(formData.streetAddress || ''),
    city: String(formData.city || ''),
    stateProvince: String(formData.stateProvince || ''),
    postalCode: String(formData.postalCode || ''),
    country: String(formData.country || ''),
    email: String(formData.email || ''),
    phone: String(formData.phone || '')
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: convertFormData({})
  });
});

app.post('/submit', (req, res) => {
  const formData = convertFormData(req.body);
  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('form', { 
      errors: errors.map(e => e.message), 
      values: formData 
    });
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500);
    res.render('form', { 
      errors: ['Database error. Please try again.'], 
      values: formData 
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

// Graceful shutdown
function shutdown(serverInstance: ReturnType<typeof app.listen> | undefined): void {
  console.log('Shutting down gracefully...');
  if (db) {
    try {
      saveDatabase();
      db.close();
      console.log('Database saved and closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  if (serverInstance) {
    serverInstance.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Initialize server

async function startServer() {
  try {
    await initializeDatabase();
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => shutdown(server));
    process.on('SIGINT', () => shutdown(server));
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, startServer, shutdown };
