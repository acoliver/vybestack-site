/**
 * Base64 validation regex that matches valid Base64 strings with optional padding.
 * Only allows characters from the canonical Base64 alphabet: A-Z, a-z, 0-9, +, /
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the canonical alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace for robustness
  const normalized = input.replace(/\s+/g, '');
  
  if (normalized.length === 0) {
    throw new Error('Input is empty');
  }
  
  // Validate the input is proper Base64
  if (!BASE64_REGEX.test(normalized)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
