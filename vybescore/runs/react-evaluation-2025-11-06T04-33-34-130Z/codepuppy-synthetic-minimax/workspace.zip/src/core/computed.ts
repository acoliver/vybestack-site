/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initialize the computed value
  updateObserver(o)

  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    if (currentObserver) {
      // This computed is being accessed as a dependency by another observer
      // Store the current observer so we can notify it when this computed changes
      const computedWithObservers = o as Observer<T> & { observers?: Set<ObserverR> }
      if (!computedWithObservers.observers) {
        computedWithObservers.observers = new Set()
      }
      computedWithObservers.observers.add(currentObserver)
      
      // Recompute when accessed as a dependency to get latest values
      updateObserver(o)
    }
    
    return o.value as T
  }

  return getter
}