/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function defaultEqual<T>(a: T, b: T): boolean {
  return a === b
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = defaultEqual
  } else if (equal !== false && equal !== undefined) {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers with cascade handling
    const queue = Array.from(s.observers)
    const visited = new Set<ObserverR>()
    
    while (queue.length > 0) {
      const observer = queue.shift()!
      if (visited.has(observer)) continue
      visited.add(observer)
      
      const fullObserver = observer as Observer<T>
      const previousValue = fullObserver.value
      updateObserver(fullObserver)
      
      // If this observer has its own observers and actually changed, queue them
      const observerWithObservers = fullObserver as unknown as Observer<T> & { observers?: Set<ObserverR> }
      if (observerWithObservers.observers && previousValue !== fullObserver.value) {
        for (const dependent of observerWithObservers.observers) {
          if (!visited.has(dependent)) {
            queue.push(dependent)
          }
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
