/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it was observing
    // This is a simplified cleanup - in a more complex system we'd track all dependencies
    
    // Clear the observer to stop further updates
    observer.value = undefined
    
    // Replace updateFn with a no-op to prevent further execution
    observer.updateFn = () => value as T
  }
  
  return unsubscribe
}