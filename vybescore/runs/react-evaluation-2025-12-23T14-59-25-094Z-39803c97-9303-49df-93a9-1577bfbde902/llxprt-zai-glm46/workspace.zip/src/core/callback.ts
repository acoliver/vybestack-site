/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set(),
    disposed: false,
  }
  
  // Initial execution
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    observer.disposed = true
    
    // Remove from all tracked subjects
    if (observer.subjects) {
      for (const subject of observer.subjects) {
        subject.observers.delete(observer)
      }
      observer.subjects.clear()
    }
  }
}
