/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject to hold the computed value
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Helper function to update an observer
  const updateObserver = <U>(observer: Observer<U>): void => {
    if (observer.disposed) return
    
    // Clear previous subjects before recomputing
    if (observer.subjects) {
      for (const subj of observer.subjects) {
        subj.observers.delete(observer)
      }
      observer.subjects.clear()
    }
    
    const previous = getActiveObserver()
    setActiveObserver(observer)
    try {
      observer.value = observer.updateFn(observer.value)
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Create an observer that will recompute when dependencies change
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev) => {
      const newVal = updateFn(prev)
      subject.value = newVal
      // Notify all observers of this computed that the value changed
      for (const obs of subject.observers) {
        if (!obs.disposed) {
          updateObserver(obs as Observer<unknown>)
        }
      }
      return newVal
    },
    subjects: new Set(),
    disposed: false,
  }
  
  // Initial computation
  updateObserver(observer)
  
  // When a getter reads this computed value, register the caller as dependent
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && !observer.disposed) {
      subject.observers.add(activeObserver)
      const obs = activeObserver as Observer<T>
      if (obs.subjects) {
        obs.subjects.add(subject as unknown as Subject<unknown>)
      }
    }
    return subject.value
  }
  
  return getter
}
