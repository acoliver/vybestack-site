/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      s.observers.add(observer)
      // Track which subjects this observer depends on
      const obs = observer as Observer<T>
      if (obs.subjects) {
        obs.subjects.add(s as unknown as Subject<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = !s.equalFn || !s.equalFn(s.value, nextValue)
    s.value = nextValue
    if (shouldNotify) {
      // Notify all observers of this subject
      for (const observer of s.observers) {
        if (!observer.disposed) {
          const obs = observer as Observer<unknown>
          // Clear previous subjects before recomputing
          if (obs.subjects) {
            for (const subject of obs.subjects) {
              subject.observers.delete(observer)
            }
            obs.subjects.clear()
          }
          // Recompute the observer
          const previousActive = getActiveObserver()
          setActiveObserver(observer)
          try {
            obs.value = obs.updateFn(obs.value)
          } finally {
            setActiveObserver(previousActive)
          }
        }
      }
    }
    return s.value
  }

  return [read, write]
}
