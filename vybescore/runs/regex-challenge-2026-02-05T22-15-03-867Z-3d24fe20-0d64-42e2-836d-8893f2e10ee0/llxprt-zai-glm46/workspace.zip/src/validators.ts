export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that:
  // - Allows letters, digits, dots, hyphens, underscores, @ in local part
  // - Rejects consecutive dots, leading/trailing dots
  // - Allows quoted local part with @ (like name@tag@example.com)
  // - Domain must have valid TLD (2+ letters)
  // - Rejects underscores in domain
  // - Rejects double dots in domain
  
  // For name@tag@example.co.uk format, we need to handle multiple @ signs
  // This is a quoted-local format where the part before the last @ can contain @
  
  // First, check if there are multiple @ signs (quoted local format)
  const atCount = (value.match(/@/g) || []).length;
  
  if (atCount > 1) {
    // Handle quoted local format like name@tag@example.co.uk
    // Split by @ and validate: everything before last @ is local, last @ separates domain
    const parts = value.split('@');
    if (parts.length < 3) {
      return false;
    }
    
    const domainPart = parts[parts.length - 1]; // Last part is domain
    const localPart = parts.slice(0, parts.length - 1).join('@'); // Everything else is local
    
    // Validate domain part
    if (!/^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/.test(domainPart)) {
      return false;
    }
    
    if (domainPart.includes('_') || domainPart.includes('..')) {
      return false;
    }
    
    // Validate local part (can contain @, dots, etc.)
    if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
      return false;
    }
    
    return /^[a-zA-Z0-9._%+-@]+$/.test(localPart);
  } else if (atCount === 1) {
    // Standard single @ format
    const [local, domain] = value.split('@');
    
    if (!local || !domain) {
      return false;
    }
    
    // Check local part
    if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) {
      return false;
    }
    
    if (!/^[a-zA-Z0-9._%+-]+$/.test(local)) {
      return false;
    }
    
    // Check domain part
    if (!/^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/.test(domain)) {
      return false;
    }
    
    if (domain.includes('_') || domain.includes('..')) {
      return false;
    }
    
    return true;
  } else {
    return false;
  }
}

/**
 * Validates US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix allowed
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Note: options parameter is reserved for future extensions (e.g., allowExtensions)
  void options;
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    // Could be 1 at start without +
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must be 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match pattern: optional +54, optional trunk 0, optional mobile 9, area code, subscriber
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentineRegex = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentineRegex.test(cleaned)) {
    return false;
  }
  
  // Parse components
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check trunk prefix rule: if no country code, must start with 0
  if (!hasCountryCode) {
    if (!remaining.startsWith('0')) {
      return false;
    }
    remaining = remaining.slice(1); // Remove trunk prefix
  } else {
    // Country code present, trunk prefix is optional
    if (remaining.startsWith('0')) {
      remaining = remaining.slice(1);
    }
  }
  
  // Check for mobile indicator
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Now remaining should be area code + subscriber
  // Area code: 2-4 digits starting with 1-9
  // Total minimum: 2 (area) + 6 (subscriber) = 8 digits
  // Total maximum: 4 (area) + 8 (subscriber) = 12 digits
  
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }
  
  // Extract area code (2-4 digits)
  const areaCodeLength = Math.min(4, remaining.length - 6);
  const areaCode = remaining.slice(0, areaCodeLength);
  
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  const subscriber = remaining.slice(areaCodeLength);
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols (except apostrophe and hyphen)
  // Name must have at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (not just spaces/hyphens/apostrophes)
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with digits (should be caught by regex but double-check)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn checksum.
 * Accepts Visa (4), Mastercard (5, 2), AmEx (34, 37)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check length: 13-19 digits
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid prefixes and lengths
  const firstTwo = cleaned.slice(0, 2);
  const firstDigit = cleaned[0];
  
  // Visa: starts with 4, length 13, 16, or 19
  if (firstDigit === '4') {
    if (![13, 16, 19].includes(cleaned.length)) {
      return false;
    }
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (firstDigit === '5') {
    if (cleaned.length !== 16) return false;
    if (firstTwo < '51' || firstTwo > '55') return false;
  } else if (firstTwo >= '22' && firstTwo <= '27') {
    if (cleaned.length !== 16) return false;
    const firstFour = cleaned.slice(0, 4);
    if (firstFour < '2221' || firstFour > '2720') return false;
  }
  // AmEx: starts with 34 or 37, length 15
  else if (firstTwo === '34' || firstTwo === '37') {
    if (cleaned.length !== 15) {
      return false;
    }
  }
  // Invalid prefix
  else {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
