/**
 * Finds words starting with the given prefix, excluding specified exceptions.
 * Uses word boundaries to match complete words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with prefix
  // \b ensures we match whole words
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(wordRegex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));
  
  const uniqueWords = new Set<string>();
  matches.forEach(word => {
    const wordLower = word.toLowerCase();
    if (!exceptionsLower.has(wordLower)) {
      uniqueWords.add(word);
    }
  });
  
  return Array.from(uniqueWords);
}

/**
 * Finds occurrences of a token only when it appears after a digit
 * and not at the start of the string.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, but not at string start
  // (?!\A) ensures we're not at the start (using negative lookbehind equivalent)
  // Actually, we want: digit + token, where the whole thing is not at position 0
  const tokenRegex = new RegExp(`(?:^|\\D)(\\d${escapedToken})`, 'g');
  
  const matches = text.match(tokenRegex);
  
  if (!matches) {
    return [];
  }
  
  // Extract just the digit+token part (without the preceding non-digit or start)
  const results = matches.map(match => {
    const matchData = match.match(/\d\w+/);
    return matchData ? matchData[0] : match;
  });
  
  // Return unique occurrences
  return Array.from(new Set(results));
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" fails)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (pattern like abab, cdcd, 123123, etc.)
  // Look for any 2-4 character pattern that repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const segment = value.slice(i, i + len);
      const nextSegment = value.slice(i + len, i + 2 * len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation)
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses contain colons, IPv4 addresses don't
  if (!value.includes(':')) {
    return false;
  }
  
  // IPv6 pattern: groups of hex digits separated by colons
  // Can use :: shorthand for consecutive zero groups
  
  // Check for standard IPv6 format (at least 2 groups of hex:digits)
  const standardPattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}/;
  
  // Check for shorthand notation with ::
  const shorthandPattern = /::|[0-9a-fA-F]{1,4}::|::[0-9a-fA-F]{1,4}/;
  
  // Check for mixed IPv4/IPv6 notation (e.g., ::ffff:192.168.1.1)
  const mixedPattern = /::(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}/i;
  
  return standardPattern.test(value) || shorthandPattern.test(value) || mixedPattern.test(value);
}
