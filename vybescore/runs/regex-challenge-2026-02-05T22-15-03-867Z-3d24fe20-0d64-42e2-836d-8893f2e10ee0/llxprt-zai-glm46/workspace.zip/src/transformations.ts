/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes first character after .!? sentence terminators
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence terminators
  // Insert space after sentence terminators if missing
  let normalized = text.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Collapse multiple spaces to single space
  normalized = normalized.replace(/ +/g, ' ');
  
  // Capitalize first character of string
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence terminators
  // Look for terminator followed by optional space and lowercase letter
  normalized = normalized.replace(/([.!?]\s*)([a-z])/g, (_match, terminator, letter) => {
    return terminator + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - match http:// or https:// followed by non-space characters
  const simpleUrlRegex = /https?:\/\/[^\s<>"']+/g;
  
  const matches = text.match(simpleUrlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation that might have been included
  return matches.map(url => {
    return url.replace(/[.,;:!?)]+$/, '');
  });
}

/**
 * Forces all http:// URLs to https:// while leaving secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// globally
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... to https://...
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for dynamic hints (cgi-bin, ?, &, =, legacy extensions)
 * Always upgrades scheme to https://
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  // We need to be careful to only match example.com domains
  const urlRegex = /(http:\/\/)(example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    let newHost = host;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exclusions that should prevent host rewrite
      const exclusionPatterns = [
        /cgi-bin/,
        /\?/,
        /&/,
        /=/,
        /\.jsp$/,
        /\.php$/,
        /\.asp$/,
        /\.aspx$/,
        /\.do$/,
        /\.cgi$/,
        /\.pl$/,
        /\.py$/
      ];
      
      const shouldSkipRewrite = exclusionPatterns.some(pattern => pattern.test(path));
      
      if (!shouldSkipRewrite) {
        // Rewrite host to docs.example.com
        newHost = 'docs.example.com';
      }
    }
    
    return newProtocol + newHost + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
