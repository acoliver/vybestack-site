/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes proper padding characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate that input is not empty
  if (input.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Validate Base64 input - should only contain valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Validate padding - if padding exists, it must be 1 or 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding (maximum 2 padding characters)');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
