export interface USPhoneOptions {
  allowExtensions?: boolean;
}

/**
 * Validates email addresses with strict requirements.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (value.includes('_')) {
    return false;
  }
  
  // Split and validate domain parts
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) {
    return false;
  }
  
  // Domain must have at least one dot (for subdomain or TLD)
  if (!domain.includes('.')) {
    return false;
  }
  
  // Check for valid domain segments
  const domainSegments = domain.split('.');
  if (domainSegments.some(segment => segment.length === 0)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with optional country code.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 */
export function isValidUSPhone(value: string, options?: USPhoneOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Remove optional +1 country code
  const withoutCountryCode = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned;
  
  // Check minimum length (10 digits for standard US numbers)
  if (withoutCountryCode.length < 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = withoutCountryCode.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if it matches standard US phone patterns
  const phoneRegex = /^1?(\d{3})(\d{3})(\d{4})$/;
  const match = withoutCountryCode.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  // Optional: Check for extensions if allowed
  if (options?.allowExtensions) {
    const extensionRegex = /^.*x\d+$/i;
    if (extensionRegex.test(value)) {
      return true;
    }
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers including mobile and landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional country code +54
  let remaining = cleaned;
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  }
  
  // Handle optional trunk prefix 0
  if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
  }
  
  // Handle optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Area code must be 2-4 digits (leading digit 1-9)
  if (remaining.length < 8) { // Minimum: 2-digit area code + 6-digit subscriber
    return false;
  }
  
  // Extract area code (2-4 digits)
  let areaCode: string;
  let subscriberNumber: string;
  
  // Try 4-digit area code first
  if (remaining.length >= 10) {
    areaCode = remaining.slice(0, 4);
    subscriberNumber = remaining.slice(4);
  } else if (remaining.length >= 9) {
    // Try 3-digit area code
    areaCode = remaining.slice(0, 3);
    subscriberNumber = remaining.slice(3);
  } else {
    // Try 2-digit area code
    areaCode = remaining.slice(0, 2);
    subscriberNumber = remaining.slice(2);
  }
  
  // Area code must start with 1-9 (not 0)
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number should be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Use a different approach for unicode validation
  // First check for basic invalid characters
  if (/[\d~`!@#$%^&*()+=<>?{}[\]|\\/]/.test(value)) {
    return false;
  }
  
  // Check for multiple consecutive special characters
  if (/['-]{2,}/.test(value)) {
    return false;
  }
  
  // Check that names start and end with letters
  if (!/^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]/.test(value.trim())) {
    return false;
  }
  
  if (!/[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]$/.test(value.trim())) {
    return false;
  }
  
  // Allow unicode letters, apostrophes, hyphens, and spaces
  const validNameRegex = /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF\s'-]+$/;
  
  if (!validNameRegex.test(value.trim())) {
    return false;
  }
  
  // Minimum length check (at least 2 characters)
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        doubledDigit -= 9;
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * Includes Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check basic length requirements
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Check for valid prefixes
  let isValidPrefix = false;
  
  // Visa: starts with 4, length 13 or 16
  if (cardNumber.startsWith('4') && (cardNumber.length === 13 || cardNumber.length === 16)) {
    isValidPrefix = true;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPrefix = cardNumber.match(/^5[1-5]/) || cardNumber.match(/^2(2[2-9]|[3-6]\d|7([01]|20))/);
  if (mastercardPrefix && cardNumber.length === 16) {
    isValidPrefix = true;
  }
  
  // American Express: starts with 34 or 37, length 15
  if ((cardNumber.startsWith('34') || cardNumber.startsWith('37')) && cardNumber.length === 15) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}