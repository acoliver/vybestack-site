/**
 * Text transformation utilities using regular expressions.
 */

/**
 * Capitalizes the first character of each sentence (after .?!), 
 * inserts exactly one space between sentences, and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace by collapsing multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing (but not if it's already there)
  normalized = normalized.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Capitalize first character after sentence endings
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (_, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize first character of the string
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  return normalized;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?(?![\w.])/gi;
  
  return text.match(urlRegex) || [];
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  // Use a simple approach that doesn't require lookbehind
  const httpsRegex = /http:\/\//gi;
  
  return text.replace(httpsRegex, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrade to https
 * - Rewrite docs paths to docs.example.com
 * - Skip host rewrite for dynamic content
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match URLs more comprehensively
  const urlRegex = /(http:\/\/)([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, protocol, host, path) => {
    // Check if path contains dynamic content or legacy extensions
    const dynamicPattern = /(?:cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    const hasDynamicContent = dynamicPattern.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Only rewrite host if it's a docs path AND doesn't have dynamic content
    if (isDocsPath && !hasDynamicContent) {
      return `${secureProtocol}docs.${host}${path}`;
    }
    
    // Otherwise, just upgrade the protocol
    return `${secureProtocol}${host}${path}`;
  });
}

/**
 * Extracts the year from a date string in mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const year = parseInt(yearStr, 10);
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  if (isLeapYear) {
    daysInMonth[1] = 29;
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return yearStr;
}