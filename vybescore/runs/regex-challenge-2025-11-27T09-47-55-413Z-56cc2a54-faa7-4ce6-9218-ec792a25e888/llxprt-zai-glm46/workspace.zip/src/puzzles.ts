/**
 * Regex puzzle utilities using advanced regular expression features.
 */

/**
 * Finds words beginning with a prefix but excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const filteredMatches = matches.filter(match => 
    !exceptions.some(exception => exception.toLowerCase() === match.toLowerCase())
  );
  
  return filteredMatches;
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to match token preceded by a digit, but not at start
  const tokenRegex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  return text.match(tokenRegex) || [];
}

/**
 * Validates password strength according to specific criteria.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  const symbolRegex = /[!@#$%^&*()_+=\[\]{};':"|,.<>\/?-]/;
  if (!symbolRegex.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like "abab", "123123", etc.)
  // This checks for patterns of 2-4 characters that repeat immediately
  const repeatedSequenceRegex = /(.{2,4})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude IPv4 addresses explicitly
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern (including shorthand ::)
  // This matches most valid IPv6 formats including:
  // - Full format: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1
  // - IPv4-mapped: ::ffff:192.0.2.1
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  return ipv6Pattern.test(value.trim());
}