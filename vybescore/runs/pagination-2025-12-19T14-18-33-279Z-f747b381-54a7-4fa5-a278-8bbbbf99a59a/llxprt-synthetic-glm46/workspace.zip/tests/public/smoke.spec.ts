import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (pagination)', () => {
  let db: Awaited<ReturnType<typeof createDatabase>>;
  let app: Awaited<ReturnType<typeof createApp>>;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns first page with default limit', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // Default limit
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15); // Total items in seed data
    expect(response.body.hasNext).toBe(true);
  });

  it('returns second page with default limit', async () => {
    const response = await request(app).get('/inventory?page=2');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns last page', async () => {
    const response = await request(app).get('/inventory?page=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });

  it('returns empty result for page beyond data', async () => {
    const response = await request(app).get('/inventory?page=4');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(4);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(0);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });

  it('validates page parameter - rejects non-numeric', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page must be a positive integer');
  });

  it('validates limit parameter - rejects non-numeric', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit must be a positive integer');
  });

  it('validates page parameter - rejects zero', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page must be a positive integer');
  });

  it('validates limit parameter - rejects zero', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit must be a positive integer');
  });
});
