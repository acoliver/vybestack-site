import express, { Request, Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js - we need to be careful with types here
const initSqlJs = async () => {
  const SQL = await import('sql.js');
  // Access the actual Database function from the imported module
  const dbModule = await (SQL.default as any)();
  return dbModule;
};

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class FormApp {
  private app: express.Application;
  private server: unknown;
  private db: any = null;
  private SQL: any = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  public async initializeDatabase(): Promise<void> {
    const SQL = await initSqlJs();
    this.SQL = SQL;

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(fileBuffer);
    } else {
      this.db = new SQL.Database();
      // Create schema
      const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);
      this.saveDatabase();
    }
    
    // Setup routes after database is initialized
    this.setupRoutes();
  }

  private saveDatabase(): void {
    if (!this.db) return;
    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(this.dbPath, buffer);
  }

  private validateForm(formData: FormData): string[] {
    const errors: string[] = [];

    // Required field validation
    if (!formData.firstName?.trim()) {
      errors.push('First name is required');
    }
    if (!formData.lastName?.trim()) {
      errors.push('Last name is required');
    }
    if (!formData.streetAddress?.trim()) {
      errors.push('Street address is required');
    }
    if (!formData.city?.trim()) {
      errors.push('City is required');
    }
    if (!formData.stateProvince?.trim()) {
      errors.push('State / Province / Region is required');
    }
    if (!formData.postalCode?.trim()) {
      errors.push('Postal / Zip code is required');
    }
    if (!formData.country?.trim()) {
      errors.push('Country is required');
    }
    if (!formData.email?.trim()) {
      errors.push('Email is required');
    }
    if (!formData.phone?.trim()) {
      errors.push('Phone number is required');
    }

    // Email validation
    if (formData.email?.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email.trim())) {
        errors.push('Please enter a valid email address');
      }
    }

    // Phone validation - allow international formats
    if (formData.phone?.trim()) {
      const phoneRegex = /^[+]?[\d\s\-()]+$/;
      if (!phoneRegex.test(formData.phone.trim())) {
        errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
      }
    }

    // Postal code validation - allow alphanumeric
    if (formData.postalCode?.trim()) {
      const postalRegex: RegExp = /^[\w\s-]+$/;
      if (!postalRegex.test(formData.postalCode.trim())) {
        errors.push('Postal code can only contain letters, numbers, spaces, and dashes');
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - render form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {
          firstName: '',
          lastName: '',
          streetAddress: '',
          city: '',
          stateProvince: '',
          postalCode: '',
          country: '',
          email: '',
          phone: ''
        }
      });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      if (!this.db) {
        return res.status(500).send('Database not initialized');
      }

      const formData: FormData = {
        firstName: (req.body.firstName as string)?.trim() || '',
        lastName: (req.body.lastName as string)?.trim() || '',
        streetAddress: (req.body.streetAddress as string)?.trim() || '',
        city: (req.body.city as string)?.trim() || '',
        stateProvince: (req.body.stateProvince as string)?.trim() || '',
        postalCode: (req.body.postalCode as string)?.trim() || '',
        country: (req.body.country as string)?.trim() || '',
        email: (req.body.email as string)?.trim() || '',
        phone: (req.body.phone as string)?.trim() || ''
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        // Validation failed - re-render form with errors and values
        res.status(400).render('form', {
          errors,
          values: formData
        });
        return;
      }

      try {
        // Insert into database using escaped values instead of parameterized queries
        const escapedFirstName = formData.firstName.replace(/'/g, "''");
        const escapedLastName = formData.lastName.replace(/'/g, "''");
        const escapedStreetAddress = formData.streetAddress.replace(/'/g, "''");
        const escapedCity = formData.city.replace(/'/g, "''");
        const escapedStateProvince = formData.stateProvince.replace(/'/g, "''");
        const escapedPostalCode = formData.postalCode.replace(/'/g, "''");
        const escapedCountry = formData.country.replace(/'/g, "''");
        const escapedEmail = formData.email.replace(/'/g, "''");
        const escapedPhone = formData.phone.replace(/'/g, "''");
        
        const insertSql = `
          INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES ('${escapedFirstName}', '${escapedLastName}', '${escapedStreetAddress}', '${escapedCity}', '${escapedStateProvince}', '${escapedPostalCode}', '${escapedCountry}', '${escapedEmail}', '${escapedPhone}')
        `;
        
        this.db.run(insertSql);

        // Save database to disk
        this.saveDatabase();

        // Redirect to thank you page with first name as query parameter
        res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).send('Database error');
      }
    });

    // GET /thank-you - render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // Use query parameter if available, otherwise try database
      const queryFirstName = req.query.firstName as string;
      let firstName = queryFirstName || 'Friend';
      
      // If no query param, try to get from database (fallback)
      if (!queryFirstName && this.db) {
        try {
          const stmt = this.db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
          const result = stmt.get();
          stmt.free();
          
          firstName = result?.first_name || 'Friend';
        } catch (error) {
          console.error('Error querying database:', error);
        }
      }
      
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      if (this.server) {
        (this.server as { close(callback?: () => void): void }).close(() => {
          console.log('Express server closed');
        });
      }
      if (this.db) {
        this.db.close();
        console.log('Database connection closed');
      }
      process.exit(0);
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  }

  public getApp(): express.Application {
    return this.app;
  }

  public close(): void {
    if (this.server) {
      (this.server as { close(): void }).close();
    }
    if (this.db) {
      this.db.close();
    }
  }
}

// Export for testing
export { FormApp };

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const app = new FormApp();
  app.start().catch((error: Error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}