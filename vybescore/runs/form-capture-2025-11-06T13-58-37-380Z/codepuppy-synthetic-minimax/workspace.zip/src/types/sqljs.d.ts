declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    get(): Record<string, unknown> | undefined;
    all(): Record<string, unknown>[];
    free(): void;
  }

  export const Database: {
    new (data?: Uint8Array): Database;
  };
}