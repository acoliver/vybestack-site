import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { FormApp } from '../../src/server.js';

let server: unknown;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Create and initialize the server
  const formApp = new FormApp();
  await formApp.initializeDatabase();
  app = formApp.getApp();
  
  // Start server on a random port for testing
  server = app.listen(0);
});

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server) {
    (server as { close(): void }).close();
  }
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toBeDefined();
    const $ = cheerio.load(response.text);
    
    // Check all required form fields exist
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check form action and method
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check CSS is linked
    expect($('link[href="/public/styles.css"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    // Submit form - check response body for debug info
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    console.log('Response status:', response.status);
    console.log('Response text:', response.text);
    
    // Check redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database was created and has data
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify thank you page shows first name
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain('John');
  });

  it('handles validation errors properly', async () => {
    const invalidData = {
      firstName: '', // Required but empty
      lastName: '',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'invalid-email', // Invalid email
      phone: 'abc123' // Invalid phone
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    expect(response.text).toBeDefined();
    const $ = cheerio.load(response.text);
    
    // Should show error messages
    expect($('.error-list').text()).toContain('First name is required');
    expect($('.error-list').text()).toContain('Last name is required');
    
    // Form should be re-rendered with submitted values
    expect($('#streetAddress').val()).toBe('123 Main St');
    expect($('#city').val()).toBe('Test City');
  });

  it('accepts international postal codes and phone numbers', async () => {
    const internationalData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Calle Florida 123',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000AAA',
      country: 'Argentina',
      email: 'maria@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(internationalData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts UK postal codes and phone numbers', async () => {
    const ukData = {
      firstName: 'James',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'james@example.co.uk',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(ukData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });
});