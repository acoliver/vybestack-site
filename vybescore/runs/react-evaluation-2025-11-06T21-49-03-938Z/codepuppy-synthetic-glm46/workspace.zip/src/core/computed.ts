/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
function shouldUpdate<T>(
  current: T | undefined,
  next: T,
  equal?: boolean | EqualFn<T>
): boolean {
  if (equal === false) return true
  if (equal === true || equal === undefined) return current !== next
  if (current === undefined) return true
  return !equal(current, next)
}

function _createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === true || equal === undefined) {
    return (a: T, b: T) => a === b
  }
  if (equal === false) {
    return undefined
  }
  return equal
}

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let dirty = true
  
  const compute = (): T => {
    const prevObserver = getActiveObserver()
    
    // If we're already being computed (recursive), return cached value
    if (prevObserver === o) {
      return o.value!
    }
    
    // Only recompute if dirty
    if (dirty) {
      // Set this computed as the active observer to track dependencies
      setActiveObserver(o)
      
      try {
        const newValue = updateFn(o.value)
        
        // Update value if it should change
        if (shouldUpdate(o.value, newValue, equal)) {
          o.value = newValue
        }
        
        dirty = false
      } finally {
        setActiveObserver(prevObserver)
      }
    }
    
    return o.value!
  }
  
  // Track observers of this computed value
  const observers = new Set<ObserverR>()
  
  // Override the update function to mark as dirty and notify observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    dirty = true
    const result = originalUpdateFn(prevValue)
    
    // Notify all observers of this computed
    for (const observer of observers) {
      updateObserver(observer as Observer<unknown>)
    }
    
    return result
  }
  
  const getter = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o) {
      observers.add(currentObserver)
    }
    return compute()
  }
  
  // Return the getter function
  return getter
}