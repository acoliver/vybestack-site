/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  trackDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
function shouldUpdate<T>(
  current: T,
  next: T,
  equal?: boolean | EqualFn<T>
): boolean {
  if (equal === false) return true
  if (equal === true || equal === undefined) return current !== next
  return !equal(current, next)
}

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === true || equal === undefined) {
    return (a: T, b: T) => a === b
  }
  if (equal === false) {
    return undefined
  }
  return equal
}

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: createEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      trackDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (shouldUpdate(s.value, nextValue, equal)) {
      s.value = nextValue
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
