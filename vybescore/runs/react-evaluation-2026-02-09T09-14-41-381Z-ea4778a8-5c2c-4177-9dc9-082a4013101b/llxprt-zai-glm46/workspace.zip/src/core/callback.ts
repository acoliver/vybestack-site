/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, Subject, updateObserver, UpdateFn, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create a subject to track dependencies
  const subject: Subject<T> = {
    observers: new Set<ObserverR>(),
    value: value as T,
  }
  
  // Create an observer that runs the callback when dependencies change
  const observer: Observer<T> = {
    value,
    updateFn: (prev?: T) => {
      const newValue = updateFn(prev)
      subject.value = newValue
      return newValue
    },
  }
  
  // Initial execution to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it was observing
    // Note: This is a simplified cleanup. In a full implementation,
    // we'd need to track which subjects this observer is registered with.
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
