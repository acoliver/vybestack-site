/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  getActiveObserver,
  updateObserver,
  notifyObservers,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Create a subject to hold the computed value
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Create an observer that will recompute when dependencies change
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Link them: when the observer updates, it updates the subject's value
  const originalUpdateFn = updateFn
  observer.updateFn = (prev?: T) => {
    const newValue = originalUpdateFn(prev)
    subject.value = newValue
    // Notify any observers that depend on this computed value
    notifyObservers(subject)
    return newValue
  }
  
  // Initial computation
  updateObserver(observer)
  
  // Getter that registers dependencies and returns the current value
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observers.add(activeObserver)
    }
    return subject.value
  }
  
  return getter
}
