/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const trimmedInput = input.trim();
  
  if (trimmedInput.length === 0) {
    return '';
  }
  
  // Validate Base64 input using a comprehensive regex
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for proper padding length and position
  const paddingIndex = trimmedInput.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingLength = trimmedInput.length - paddingIndex;
    // Padding can only be 1 or 2 characters and must be at the end
    if (paddingLength > 2 || trimmedInput.slice(paddingIndex).split('').some(c => c !== '=')) {
      throw new Error('Invalid Base64 input: improper padding');
    }
  }

  try {
    // Try to decode to validate the input
    const decoded = Buffer.from(trimmedInput, 'base64');
    
    // Additional validation: if decoding succeeds but results in empty buffer
    // for non-empty input, the input might be corrupted
    if (trimmedInput.length > 0 && decoded.length === 0) {
      throw new Error('Invalid Base64 input: cannot decode');
    }
    
    return decoded.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error; // Re-throw our custom validation errors
    }
    throw new Error('Failed to decode Base64 input');
  }
}
