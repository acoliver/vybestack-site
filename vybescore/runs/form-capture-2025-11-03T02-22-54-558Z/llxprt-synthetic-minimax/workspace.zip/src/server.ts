import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// SQLite database setup
let db: Database | null = null;

async function initDatabase() {
  const SQL = await initSqlJs({
    locateFile: (file: string) => {
      return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
    }
  });

  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const dataDir = path.dirname(dbPath);

  // Ensure data directory exists
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let dbBuffer: Uint8Array | undefined;

  // Load existing database if it exists
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    dbBuffer = new Uint8Array(buffer);
  }

  db = new SQL.Database(dbBuffer);

  // Initialize schema
  const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schema);

  return db;
}

function saveDatabase() {
  if (!db) return;
  
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const binary = db.export();
  fs.writeFileSync(dbPath, binary);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s()+-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handles UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data: Record<string, string>): { errors: string[], values: Record<string, string> } {
  const errors: string[] = [];
  const values = { ...data };

  // Required field validation
  const requiredFields = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || typeof data[field] !== 'string' || data[field].trim().length === 0) {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`);
    }
  }

  // Email validation
  if (data.email && data.email.trim().length > 0) {
    if (!validateEmail(data.email)) {
      errors.push('email is invalid');
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim().length > 0) {
    if (!validatePhone(data.phone)) {
      errors.push('phone number is invalid');
    }
  }

  // Postal code validation
  if (data.postalCode && data.postalCode.trim().length > 0) {
    if (!validatePostalCode(data.postalCode)) {
      errors.push('postal code is invalid');
    }
  }

  return { errors, values };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const { errors, values } = validateForm(req.body);

  if (errors.length > 0) {
    return res.status(200).render('form', { errors, values });
  }

  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      values.firstName.trim(),
      values.lastName.trim(),
      values.streetAddress.trim(),
      values.city.trim(),
      values.stateProvince.trim(),
      values.postalCode.trim(),
      values.country.trim(),
      values.email.trim(),
      values.phone.trim()
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank-you page with first name as query param
    res.redirect(302, `/thank-you?name=${encodeURIComponent(values.firstName.trim())}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.name as string) || '';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err.stack);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function start() {
  try {
    await initDatabase();
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export app and server for testing
export { app };

if (process.env.NODE_ENV !== 'test') {
  start();
}