/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> & { observer?: ObserverR } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof _equal === 'function' ? _equal as EqualFn<T> : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== s) {
      if (!s.observers) {
        s.observers = new Set()
      }
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Skip update if values are equal and we have an equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    // Trigger update for all observers
    if (s.observer) {
      updateObserver(s.observer as Observer<T>)
    }
    // Notify all dependent observers directly
    if (s.observers) {
      const observerArray = Array.from(s.observers)
      for (const dependentObserver of observerArray) {
        const dependentWithUpdateFn = dependentObserver as Observer<T> & { updateFn?: (value?: T) => T }
        if (typeof dependentWithUpdateFn.updateFn === 'function') {
          updateObserver(dependentObserver as Observer<T>)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
