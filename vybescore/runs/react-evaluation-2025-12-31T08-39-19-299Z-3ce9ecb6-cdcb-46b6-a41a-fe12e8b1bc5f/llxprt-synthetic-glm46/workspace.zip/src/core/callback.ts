/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create the observer without initially calling updateObserver
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false;
  let initialized = false;
  
  // Create unsubscribe function before initializing
  const unsubscribe = () => {
    if (disposed) return;
    disposed = true;
    
    // Mark as disposed to prevent further updates
    (observer as Observer<T> & { disposed?: boolean }).disposed = true;
    
    // Clear the observer's dependencies if initialized
    if (initialized && observer.observers) {
      for (const dependency of observer.observers) {
        if ('observers' in dependency && dependency.observers) {
          (dependency.observers as Set<Observer<T>>).delete(observer);
        }
      }
      observer.observers.clear();
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined;
    // Replace updateFn with no-op to prevent further updates
    observer.updateFn = () => (value ?? undefined) as T;
  }
  
  // Now initialize the observer after unsubscribe is created
  updateObserver(observer);
  initialized = true;
  
  return unsubscribe;
}
