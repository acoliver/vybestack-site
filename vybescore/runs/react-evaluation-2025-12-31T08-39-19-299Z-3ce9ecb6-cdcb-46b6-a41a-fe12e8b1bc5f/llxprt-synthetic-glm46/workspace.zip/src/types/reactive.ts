/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observers?: Set<ObserverR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip if the observer is disposed
  const disposedState = (observer as Observer<T> & { disposed?: boolean }).disposed
  if (disposedState) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // After restoring context, notify all dependent observers
  // Create a copy to avoid issues with observers being removed during iteration
  const observerWithObservers = observer as Observer<T> & { observers?: Set<ObserverR> }
  if (observerWithObservers.observers) {
    const observersCopy = Array.from(observerWithObservers.observers)
    for (const dependentObserver of observersCopy) {
      const dependentWithUpdateFn = dependentObserver as Observer<T> & { updateFn?: (value?: unknown) => unknown }
      const dependentWithDisposed = dependentObserver as Observer<T> & { disposed?: boolean }
      if (dependentObserver !== observer && 
          typeof dependentObserver === 'object' && 
          typeof dependentWithUpdateFn.updateFn === 'function' && 
          !dependentWithDisposed.disposed) {
        updateObserver(dependentObserver as Observer<T>)
      }
    }
  }
}
