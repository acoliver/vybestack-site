export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface FormattingOptions {
  includeTotals: boolean;
}

export interface FormatterFunction {
  (data: ReportData, options: FormattingOptions): string;
}