import type { FormatterFunction } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

type FormatMap = Record<string, FormatterFunction>;

const formatters: FormatMap = {
  markdown: renderMarkdown,
  text: renderText
};

export function getFormatter(format: string): FormatterFunction {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}