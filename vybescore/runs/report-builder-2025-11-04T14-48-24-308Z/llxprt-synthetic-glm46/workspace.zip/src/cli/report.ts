#!/usr/bin/env node

import { parseArguments } from './parsedArgs.js';
import { loadReportData } from './dataLoader.js';
import { getFormatter } from './formatterRegistry.js';
import { writeOutput } from './outputHandler.js';

try {
  const args = parseArguments(process.argv);
  const reportData = await loadReportData(args.jsonFilePath);
  const formatter = getFormatter(args.format);
  const formattedReport = formatter(reportData, { includeTotals: args.includeTotals });
  writeOutput(formattedReport, args.outputPath);
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Unknown error occurred');
  process.exit(1);
}
