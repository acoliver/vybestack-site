export interface ParsedArgs {
  jsonFilePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArguments(args: string[]): ParsedArgs {
  const result: ParsedArgs = {
    jsonFilePath: '',
    format: '',
    includeTotals: false
  };
  
  // Skip the first two args (node and script path)
  const positionalArgs: string[] = [];
  
  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      result.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      result.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      positionalArgs.push(arg);
    }
  }
  
  if (positionalArgs.length !== 1) {
    throw new Error('Exactly one JSON file path is required');
  }
  
  result.jsonFilePath = positionalArgs[0];
  
  if (!result.format) {
    throw new Error('Missing required option: --format');
  }
  
  return result;
}