import { writeFileSync } from 'node:fs';

export function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    // Write to file
    writeFileSync(outputPath, content, { encoding: 'utf8' });
  } else {
    // Write to stdout
    process.stdout.write(content);
  }
}