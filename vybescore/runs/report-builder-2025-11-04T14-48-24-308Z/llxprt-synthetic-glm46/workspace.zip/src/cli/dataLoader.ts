import { readFile } from 'node:fs/promises';
import type { ReportData } from '../types.js';

export async function loadReportData(jsonFilePath: string): Promise<ReportData> {
  let jsonData: string;
  
  try {
    jsonData = await readFile(jsonFilePath, { encoding: 'utf8' });
  } catch (error) {
    throw new Error(`Failed to read file: ${jsonFilePath}`);
  }
  
  let parsed: unknown;
  
  try {
    parsed = JSON.parse(jsonData);
  } catch (error) {
    throw new Error(`Invalid JSON in file: ${jsonFilePath}`);
  }
  
  // Validate the parsed data structure
  if (!isValidReportData(parsed)) {
    throw new Error(`Invalid report data structure in file: ${jsonFilePath}`);
  }
  
  return parsed;
}

function isValidReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    return false;
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      return false;
    }
    
    if (typeof entryObj.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}