// Regex puzzle functions with advanced patterns

export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary pattern for the prefix (including word characters)
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  
  // Find all words starting with the prefix
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at the start
  // Pattern: digit followed by token (capturing the full match)
  const pattern = new RegExp(`\\d${token}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, cdcd, etc.)
  // Pattern to find repeated sequences of 2+ characters
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // More precise IPv6 regex that includes shorthand :: notation
  // IPv6 addresses have specific patterns that distinguish them from IPv4
  
  // IPv4 pattern to exclude - IPv4 has exactly 3 dots and 4 numbers
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns - look for sequences with colons and hex digits
  // IPv6 can have :: (double colon for compression)
  // It must have at least 2 colons to distinguish from protocols like http:
  const ipv6Patterns = [
    // Standard IPv6 with colons
    /(^|[\s"'()[\]{}:,])[0-9a-fA-F]*:[0-9a-fA-F:]*[0-9a-fA-F]*([0-9a-fA-F]*)?:?([0-9a-fA-F]*)?([0-9a-fA-F]*)?([0-9a-fA-F]*)?([0-9a-fA-F]*)?([0-9a-fA-F]*)?/,
    // IPv6 with double colon compression
    /(?:^|[\s"'()[\]{}:,])[0-9a-fA-F:]*::[0-9a-fA-F:]*/,
  ];
  
  // If it matches IPv4 pattern exactly and has no colons beyond the dots, reject
  if (ipv4Pattern.test(value) && (value.match(/:/g) || []).length === 0) {
    return false;
  }
  
  // Check for IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Double check it's not just an IPv4 address
      const matches = value.match(pattern);
      if (matches) {
        const matchedText = matches[0];
        // If the match contains only IPv4 pattern, reject
        if (ipv4Pattern.test(matchedText) && !matchedText.includes(':')) {
          continue; // Try next pattern
        }
        // If it has colons or hex digits beyond IPv4, it's likely IPv6
        if (matchedText.includes(':') || /[a-fA-F]/.test(matchedText)) {
          return true;
        }
      }
    }
  }
  
  // Additional check: IPv6 addresses typically have multiple colons
  const colonCount = (value.match(/:/g) || []).length;
  const hasHexDigits = /[a-fA-F]/.test(value);
  const hasDoubleColon = value.includes('::');
  
  // If it has many colons, hex digits, or double colon, likely IPv6
  if ((colonCount >= 2 && hasHexDigits) || hasDoubleColon) {
    // Make sure it's not just an IPv4 address with colons
    return !ipv4Pattern.test(value) || colonCount > 3;
  }
  
  return false;
}