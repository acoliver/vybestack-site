// Validators for various data types using regex patterns

export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  // Additional checks for common invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@.') || value.includes('.@')) {
    return false;
  }
  
  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check for country code +1 (optional)
  let phoneNumber = cleaned;
  if (cleaned.startsWith('1')) {
    phoneNumber = cleaned.slice(1);
  }
  
  // Check length (should be 10 digits)
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format using regex for original input
  const phoneRegex = /^\+?1?[-.\s]?(\([0-9]{3}\)|[0-9]{3})[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
  return phoneRegex.test(value);
}

export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Clean up the number by removing known prefixes for analysis
  let digits = cleaned;
  
  // Check country code pattern
  if (digits.startsWith('+54')) {
    digits = digits.slice(3);
    
    // Handle mobile indicator
    if (digits.startsWith('9')) {
      digits = digits.slice(1);
    }
    
    // When country code is present, trunk prefix (0) is optional
    // But if present, remove it
    if (digits.startsWith('0')) {
      digits = digits.slice(1); // Remove trunk prefix
    }
    
  } else {
    // No country code - must start with trunk prefix
    if (!digits.startsWith('0')) {
      return false;
    }
    digits = digits.slice(1); // Remove trunk prefix
  }
  
  // Now we have area code + subscriber number
  if (digits.length < 7 || digits.length > 11) {
    return false;
  }
  
  // Split into area code and subscriber number
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const minAreaLength = 2;
  const maxAreaLength = 4;
  const minSubscriberLength = 5;
  const maxSubscriberLength = 8;
  
  for (let areaLength = minAreaLength; areaLength <= Math.min(maxAreaLength, digits.length - minSubscriberLength); areaLength++) {
    const subscriberLength = digits.length - areaLength;
    if (subscriberLength >= minSubscriberLength && subscriberLength <= maxSubscriberLength) {
      const areaCode = digits.slice(0, areaLength);
      const subscriber = digits.slice(areaLength);
      
      // Validate area code
      if (areaCode[0] >= '1' && areaCode[0] <= '9') {
        // Validate subscriber
        if (/^\d+$/.test(subscriber)) {
          return true;
        }
      }
    }
  }
  
  return false;
}

export function isValidName(value: string): boolean {
  // Reject if empty or only whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Reject X Æ A-12 style names
  if (value.includes('Æ') || value.includes('æ')) {
    return false;
  }
  
  // Allow unicode letters (with accents), apostrophes, hyphens, and spaces
  // Pattern: start with unicode letter, allow unicode letters/apostrophes/hyphens/spaces, end with unicode letter
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  return nameRegex.test(value.trim());
}

// Luhn checksum algorithm for credit card validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number).reverse();
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    // Double every second digit (starting from index 1)
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for major cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card type prefixes and validate format
  let isValidFormat = false;
  
  // Visa: starts with 4, 13 or 16 digits
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16)) {
    isValidFormat = true;
  }
  // Mastercard: starts with 51-55, 16 digits
  else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
             cleaned.startsWith('54') || cleaned.startsWith('55')) && cleaned.length === 16) {
    isValidFormat = true;
  }
  // American Express: starts with 34 or 37, 15 digits
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidFormat = true;
  }
  
  // Run Luhn checksum
  return isValidFormat && runLuhnCheck(cleaned);
}