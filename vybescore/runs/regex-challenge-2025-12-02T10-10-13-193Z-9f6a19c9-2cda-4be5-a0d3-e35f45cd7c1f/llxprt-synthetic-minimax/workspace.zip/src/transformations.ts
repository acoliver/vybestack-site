// Text transformation functions using regex patterns

export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper spacing after sentence endings
  let result = text.trim();
  
  // Find sentence boundaries and capitalize first letter of each sentence
  result = result.replace(/([.!?])\s*([A-Za-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Capitalize the first letter of the text if it's not already capitalized
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return result;
}

export function extractUrls(text: string): string[] {
  // URL regex to match http, https, www links - exclude trailing punctuation
  const urlRegex = /(https?:\/\/[^\s"')>\]}]+|www\.[^\s"')>\]}])/gi;
  
  // Find all URLs
  const urls = text.match(urlRegex) || [];
  
  return urls;
}

export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// unchanged
  return text.replace(/http:\/\//gi, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs and capture host and path
  const httpUrlRegex = /http:\/\/([^/]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlRegex, (match, host, path = '') => {
    let newUrl = 'https://' + host + path;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that prevent host rewrite
      const hasDynamicHints = /(\?|=|&|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month and day
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  
  // Special case for February - check for leap year
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > maxDay) {
    return 'N/A';
  }
  
  // If day is valid, return the year
  return year;
}