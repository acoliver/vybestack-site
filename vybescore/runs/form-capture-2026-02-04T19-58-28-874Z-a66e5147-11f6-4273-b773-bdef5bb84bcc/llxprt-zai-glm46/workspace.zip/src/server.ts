import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
let db: Database | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve('public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Validation functions
function validateRequired(value: string, fieldName: string): string | null {
  if (!value || value.trim().length === 0) {
    return `${fieldName} is required`;
  }
  return null;
}

function validateEmail(email: string): string | null {
  const trimmed = email.trim();
  if (!trimmed) {
    return 'Email is required';
  }
  // Simple email regex - accepts most common formats
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return 'Please enter a valid email address';
  }
  return null;
}

function validatePhone(phone: string): string | null {
  const trimmed = phone.trim();
  if (!trimmed) {
    return 'Phone number is required';
  }
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[\d\s\-()+]+$/;
  if (!phoneRegex.test(trimmed)) {
    return 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }
  return null;
}

function validatePostalCode(postalCode: string): string | null {
  const trimmed = postalCode.trim();
  if (!trimmed) {
    return 'Postal code is required';
  }
  // Allow alphanumeric characters and spaces (for UK, Argentina, etc.)
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  if (!postalRegex.test(trimmed)) {
    return 'Postal code can only contain letters, digits, and spaces';
  }
  return null;
}

function validateForm(data: Partial<FormData>): string[] {
  const errors: string[] = [];

  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'country',
  ];

  for (const field of requiredFields) {
    const error = validateRequired(data[field] || '', field.replace(/([A-Z])/g, ' $1').trim());
    if (error) errors.push(error);
  }

  const emailError = validateEmail(data.email || '');
  if (emailError) errors.push(emailError);

  const phoneError = validatePhone(data.phone || '');
  if (phoneError) errors.push(phoneError);

  const postalError = validatePostalCode(data.postalCode || '');
  if (postalError) errors.push(postalError);

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    // Run schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

function getSubmissionCount(): number {
  if (!db) return 0;
  const result = db.exec('SELECT COUNT(*) as count FROM submissions');
  return result[0]?.values[0]?.[0] as number || 0;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName || '',
      formData.lastName || '',
      formData.streetAddress || '',
      formData.city || '',
      formData.stateProvince || '',
      formData.postalCode || '',
      formData.country || '',
      formData.email || '',
      formData.phone || '',
    ]);
    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  // Make server accessible for testing
  (app as { server?: unknown; db?: Database | null }).server = server;
  (app as { server?: unknown; db?: Database | null }).db = db;
}

// Export for testing
export { app, initializeDatabase, saveDatabase, getSubmissionCount };

// Start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
