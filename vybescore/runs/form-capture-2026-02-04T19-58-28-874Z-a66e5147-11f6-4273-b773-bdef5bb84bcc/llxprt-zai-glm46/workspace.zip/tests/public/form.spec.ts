import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  // Initialize database
  await initializeDatabase();
});

afterAll(() => {
  const server = (app as { server?: unknown }).server;
  if (server && typeof server === 'object' && 'close' in server && typeof server.close === 'function') {
    (server as { close: () => void }).close();
  }
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields with proper labels and inputs
    const fields = [
      { id: 'firstName', name: 'firstName', label: 'First name' },
      { id: 'lastName', name: 'lastName', label: 'Last name' },
      { id: 'streetAddress', name: 'streetAddress', label: 'Street address' },
      { id: 'city', name: 'city', label: 'City' },
      { id: 'stateProvince', name: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', name: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', name: 'country', label: 'Country' },
      { id: 'email', name: 'email', label: 'Email' },
      { id: 'phone', name: 'phone', label: 'Phone number' },
    ];

    for (const field of fields) {
      // Check label exists and has correct for attribute
      const label = $(`label[for="${field.id}"]`);
      expect(label.length).toBeGreaterThan(0);
      expect(label.text().trim()).toBe(field.label);

      // Check input exists with correct id and name
      const input = $(`#${field.id}[name="${field.name}"]`);
      expect(input.length).toBeGreaterThan(0);
    }
  });

  it('persists submission and redirects', async () => {
    const submissionData = {
      firstName: 'Juan',
      lastName: 'Pérez',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Ciudad Autónoma de Buenos Aires',
      postalCode: 'C1040',
      country: 'Argentina',
      email: 'juan.perez@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(submissionData);

    // Should redirect with 302
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');

    // Follow redirect
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Juan');
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('stranger on the internet');

    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone-!',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('is required');
    expect(response.text).toContain('valid email');
  });

  it('accepts international phone and postal formats', async () => {
    const testCases = [
      {
        firstName: 'John',
        lastName: 'Smith',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: '+44 20 7946 0958',
      },
      {
        firstName: 'María',
        lastName: 'González',
        streetAddress: 'Calle Mayor 45',
        city: 'Madrid',
        stateProvince: 'Comunidad de Madrid',
        postalCode: '28013',
        country: 'Spain',
        email: 'maria@example.com',
        phone: '+34 91 123 45 67',
      },
    ];

    for (const data of testCases) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(data);

      expect(response.status).toBe(302);
      expect(response.headers.location).toContain('/thank-you');
    }
  });

  it('displays inline errors and preserves values on validation failure', async () => {
    const values = {
      firstName: 'Jane',
      lastName: '',
      city: 'Test City',
      email: 'not-an-email',
      phone: '+1 555-123-4567',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(values);

    expect(response.status).toBe(400);

    const $ = cheerio.load(response.text);
    
    // Check error messages are displayed
    expect($('.error-list').length).toBeGreaterThan(0);
    expect(response.text).toContain('required');

    // Check that valid values are preserved
    expect($('input[name="firstName"]').val()).toBe('Jane');
    expect($('input[name="city"]').val()).toBe('Test City');
  });
});
