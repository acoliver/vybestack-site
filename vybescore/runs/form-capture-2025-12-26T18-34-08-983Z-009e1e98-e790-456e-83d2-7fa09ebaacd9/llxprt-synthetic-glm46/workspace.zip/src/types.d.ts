declare module 'sql.js' {
  export default function initSqlJs(): Promise<SqlJs>;
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  export interface Statement {
    run(...params: unknown[]): void;
    get(): unknown;
    free(): void;
  }
  export interface SqlJs {
    Database: typeof Database;
  }
}