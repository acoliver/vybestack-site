import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs from 'sql.js';
/// <reference path="./types.d.ts" />

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization
let db: import('sql.js').Database;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load sql.js
    const SQL = await initSqlJs();
    
    // Load or create database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(
        path.join(process.cwd(), 'db', 'schema.sql'),
        'utf8'
      );
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation utilities
interface FormData {
  [key: string]: string | undefined;
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function validateForm(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required field validation
  const requiredFields = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      errors.push(`${fieldName} is required`);
    }
  }
  
// Email validation
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
// Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  if (formData.phone && !/^[+]?[\d\s()\-&]+$/.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation (alphanumeric)
  if (formData.postalCode && !/^[a-zA-Z0-9\s-&]+$/.test(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  // Postal code validation (alphanumeric)
  if (formData.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  
  return { isValid: errors.length === 0, errors };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData = req.body;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  // Get the most recent submission to display the first name
  try {
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
    const result = stmt.get() as { first_name: string } | undefined;
    stmt.free();
    
    const firstName = result ? result.first_name : 'Friend';
    res.render('thank-you', { firstName });
  } catch (error) {
    console.error('Database error:', error);
    res.render('thank-you', { firstName: 'Friend' });
  }
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
  // Graceful shutdown
  const gracefulShutdown = (): void => {
    console.log('Received shutdown signal. Closing server...');
    if (db) {
      db.close();
    }
    server.close(() => {
      console.log('Server closed successfully');
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
