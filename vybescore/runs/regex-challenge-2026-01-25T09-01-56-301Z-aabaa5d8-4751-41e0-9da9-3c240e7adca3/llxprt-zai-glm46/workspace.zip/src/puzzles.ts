/**
 * Finds words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const found = matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
  
  // Remove duplicates while preserving order
  return [...new Set(found)];
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Returns the full match including the digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token
  // This ensures we match the digit+token sequence
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(tokenRegex) || [];
  
  return [...new Set(matches)];
}

/**
 * Validates passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences (e.g., abab).
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-word character that's not alphanumeric)
  if (!/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for any 2-4 character sequence that repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + len * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation (::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it looks like an IPv4 address and exclude those
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  const words = value.split(/\s+/);
  
  for (const word of words) {
    // Skip if it's a pure IPv4 address
    if (ipv4Pattern.test(word)) {
      continue;
    }
    
    // Strip zone identifier (e.g., %lo0) for checking
    const cleanWord = word.split('%')[0];
    
    // Check for IPv6 patterns
    // Pattern 1: Full IPv6 (8 groups of hex)
    const fullIpv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    
    // Pattern 2: IPv6 with :: shorthand
    // Contains :: with at least 2 colons total (to handle fe80::1 case)
    const hasDoubleColon = /::/.test(cleanWord);
    const colonCount = (cleanWord.match(/:/g) || []).length;
    const shorthandIpv6 = hasDoubleColon && colonCount >= 2;
    
    // Pattern 3: Embedded IPv4 in IPv6 (e.g., ::ffff:192.168.1.1)
    const embeddedIpv4 = /^(?:[0-9a-fA-F]{0,4}:)*:(?:\d{1,3}\.){3}\d{1,3}$/;
    const embeddedIpv4Shorthand = /::(?:\d{1,3}\.){3}\d{1,3}$/.test(cleanWord);
    
    if (fullIpv6.test(cleanWord) || shorthandIpv6) {
      return true;
    }
    
    if (embeddedIpv4.test(cleanWord) || embeddedIpv4Shorthand) {
      return true;
    }
  }
  
  return false;
}
