export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical formats like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for exactly one @ sign
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }
  
  const parts = value.split('@');
  const localPart = parts[0];
  const domain = parts[1];
  
  // Local part must not be empty
  if (!localPart) {
    return false;
  }
  
  // Domain must not be empty
  if (!domain) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject leading/trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Validate local part: allow alphanumeric, dots, %, +, -, but must start/end with alphanumeric
  const localPartRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]$/;
  if (!localPartRegex.test(localPart)) {
    return false;
  }
  
  // Validate domain: alphanumeric parts separated by dots, can contain hyphens
  // Must end with at least 2-letter TLD
  const domainRegex = /^(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) {
    return false;
  }
  
  // Reject domain parts starting or ending with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle +1 prefix
  let digits = digitsOnly;
  if (digits.startsWith('1')) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with optional country code, trunk prefix, mobile indicator
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Area code leading digit must be 1-9 (already enforced by regex)
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // At least one character is required
  if (value.length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with symbols (other than allowed apostrophe, hyphen, space)
  const symbolPattern = /[^\p{L}\p{M}'\-\s]/u;
  if (symbolPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn checksum.
 * Accepts Visa (13-16 digits, starts with 4), Mastercard (16 digits, starts with 51-55 or 2221-2720), AmEx (15 digits, starts with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  const digitsOnly = value.replace(/\s/g, '');
  
  if (!/^\d{13,19}$/.test(digitsOnly)) {
    return false;
  }
  
  // Check Visa: starts with 4, length 13-16
  const visaRegex = /^4\d{12,15}$/;
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(digitsOnly) && 
      !mastercardRegex.test(digitsOnly) && 
      !amexRegex.test(digitsOnly)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
