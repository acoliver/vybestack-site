/**
 * Capitalizes the first character of each sentence.
 * Ensures exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing: collapse multiple spaces into one
  let normalized = text.replace(/ +/g, ' ');
  
  // Ensure exactly one space after sentence-ending punctuation
  // Look for punctuation followed by optional space then a letter
  normalized = normalized.replace(/([.!?])\s*([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first character of the string
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence-ending punctuation
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (_, punct, letter) => {
    return punct + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extracts all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. URLs
  // Negative lookbehind to avoid matching trailing punctuation
  const urlRegex = /https?:\/\/[^\s<"{}|\\^`[\]]+|www\.[^\s<"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    return url.replace(/[.,;:!?)\]}"'>]+$/, '');
  });
}

/**
 * Converts all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs.
 * Always upgrades scheme to https://.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http?:\/\/)(example\.com)(\/[^\s<"{}|\\^`[\]]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // Check if we should skip host rewrite
    const skipRewrite = /[?&=]|\/cgi-bin\/|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
    
    if (path.startsWith('/docs/') && !skipRewrite) {
      // Rewrite to docs.example.com for docs paths
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade the scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
