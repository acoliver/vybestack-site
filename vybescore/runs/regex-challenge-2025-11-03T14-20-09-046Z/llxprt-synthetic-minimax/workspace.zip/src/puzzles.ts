/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with prefix
  // Word boundaries to ensure we match whole words
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-sensitive matching)
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to ensure token appears after a digit and not at start
  // Match token that is preceded by a digit (not at start)
  const regex2 = new RegExp(`\\d${token}`, 'g');
  const matches2 = text.match(regex2) || [];
  
  // We want to return the token occurrences (with digit), not just token
  return matches2;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (like abab)
  // This means no pattern where 2+ characters repeat immediately
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === pattern) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Match IPv6 addresses including shorthand notation with ::
  // IPv6 format: 8 groups of 4 hexadecimal digits, or shorthand with ::
  // Examples: 2001:0db8:85a3:0000:0000:8a2e:0370:7334, 2001:db8:85a3::8a2e:370:7334
  
  const ipv6Regex = /\b(?:[a-f0-9]{1,4}:){2,7}[a-f0-9]{1,4}\b|\b[a-f0-9]*::[a-f0-9]*\b/gi;
  
  const ipv6Matches = value.match(ipv6Regex) || [];
  
  // Return true if we have IPv6 matches
  return ipv6Matches.length > 0;
}