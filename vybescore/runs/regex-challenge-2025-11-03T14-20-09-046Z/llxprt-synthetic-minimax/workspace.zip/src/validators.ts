export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9.+-]*[a-zA-Z0-9])?@([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Check for obvious invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@.') || value.includes('.@')) {
    return false;
  }
  
  // Check domain doesn't have underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (10 digits for standard US numbers, 11 with country code)
  if (digits.length === 10) {
    // Check area code doesn't start with 0 or 1
    const areaCode = digits.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  } else if (digits.length === 11 && digits.startsWith('1')) {
    // 11 digits with country code 1
    const areaCode = digits.substring(1, 4);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space/hyphen characters for initial validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for valid patterns
  // Pattern 1: +54 9 XX XXXXXXX (mobile with country code)
  // Pattern 2: 0XX XXXXXXX (landline with trunk prefix)
  // Pattern 3: 9 XX XXXXXXX (mobile with trunk prefix)
  
  const regex = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(regex);
  
  if (!match) {
    return false;
  }
  
  const [full, countryCode, , areaCode, subscriberNumber] = match;
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When no country code, must have trunk prefix (0)
  if (!countryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), apostrophes, hyphens, and spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}][\p{L}'\-\s]*[\p{L}]$/u;
  
  // Also reject obvious non-names like X Æ A-12
  if (/\d|X\s*Æ|A-12/i.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  // Check for empty or obviously invalid length
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  let isValidType = false;
  
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidType = true;
  } else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
              digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16) {
    isValidType = true;
  } else if (digits.startsWith('34') || digits.startsWith('37')) {
    isValidType = true;
  } else {
    // Check for Mastercard 2221-2720 range
    const prefix = parseInt(digits.substring(0, 4), 10);
    if (prefix >= 2221 && prefix <= 2720 && digits.length === 16) {
      isValidType = true;
    }
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}