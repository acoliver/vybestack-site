/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper spacing
  // Replace multiple spaces with single spaces
  text = text.replace(/\s+/g, ' ');
  
  // Capitalize first letter of the string
  text = text.replace(/^(\s*)([a-z])/, (match, leading, letter) => {
    return leading + letter.toUpperCase();
  });
  
  // Capitalize first letter after sentence endings (.?!)
  text = text.replace(/([.!?]\s+)([a-z])/g, (match, punct, letter) => {
    return punct + letter.toUpperCase();
  });
  
  return text;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)/g, (match, host, path) => {
    let newUrl = 'https://' + host + path;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|&|=)|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.host
        newUrl = 'https://docs.' + host + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12) and day (1-31)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}