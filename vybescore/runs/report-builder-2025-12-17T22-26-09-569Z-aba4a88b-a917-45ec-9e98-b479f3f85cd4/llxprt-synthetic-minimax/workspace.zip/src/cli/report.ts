#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import { ReportData, RenderOptions } from '../types/report.js';

// Supported formats mapping
const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
} as const;

type SupportedFormat = keyof typeof formatters;

interface ParsedArgs {
  dataFile: string;
  format: SupportedFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    console.error('Error: --format flag is required');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  if (args.length < 3) {
    console.error('Error: format value is required after --format');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const format = args[2] as SupportedFormat;
  
  if (!formatters[format]) {
    console.error(`Error: Unsupported format "${format}". Supported formats: ${Object.keys(formatters).join(', ')}`);
    process.exit(1);
  }
  
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse remaining flags
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown flag "${arg}"`);
      process.exit(1);
    }
  }
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Report data must be a JSON object');
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Report data is missing required field "title" (string)');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Report data is missing required field "summary" (string)');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Report data is missing required field "entries" (array)');
  }
  
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry at index ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry at index ${i} is missing required field "label" (string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Entry at index ${i} is missing required field "amount" (number)`);
    }
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
      process.exit(1);
    }
    
    if (error instanceof Error && error.message.startsWith('Report data')) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    
    console.error(`Error: Failed to read file "${filePath}": ${error}`);
    process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const reportData = loadReportData(args.dataFile);
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };
  
  const formatter = formatters[args.format];
  const output = formatter.render(reportData, options);
  
  if (args.outputPath) {
    // Write to file
    try {
      writeFileSync(args.outputPath, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file "${args.outputPath}": ${error}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();