declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export class Statement {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }

  export function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<typeof SqlJs>;
  
  export const SqlJs: {
    Database: typeof Database;
  };
}