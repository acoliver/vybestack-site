import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import initSqlJs from 'sql.js';


export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface FormErrors {
  [key: string]: string | undefined;
}

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+]?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +';
  }

  const isValid = Object.keys(errors).length === 0;
  return { isValid, errors };
}

async function initializeDatabase() {
  try {
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    
    let dbFileExists = false;
    try {
      await fs.access(DB_PATH);
      dbFileExists = true;
    } catch {
      dbFileExists = false;
    }

    const SQL = await initSqlJs({ locateFile: () => './node_modules/sql.js/dist/sql-wasm.wasm' });
    let db: import('sql.js').Database;

    if (dbFileExists) {
      const fileBuffer = await fs.readFile(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
      const schemaSQL = await fs.readFile(
        path.join(process.cwd(), 'db', 'schema.sql'),
        'utf8'
      );
      db.run(schemaSQL);
      const data = db.export();
      await fs.writeFile(DB_PATH, Buffer.from(data));
    }

    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase(db: import('sql.js').Database): Promise<void> {
  try {
    const data = db.export();
    await fs.writeFile(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

async function submitToDatabase(db: import('sql.js').Database, formData: FormData): Promise<void> {
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();

    await saveDatabase(db);
  } catch (error) {
    console.error('Failed to submit to database:', error);
    throw error;
  }
}

async function createApp(): Promise<express.Application> {
  const app = express();
  const db = await initializeDatabase();

  app.use(express.urlencoded({ extended: true }));
  app.use(express.static('public'));
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));

  app.get('/', (req, res) => {
    res.render('form', { errors: [], values: {} });
  });

  app.get('/thank-you', (req, res) => {
    res.render('thank-you', { firstName: req.query.firstName || 'Friend' });
  });

  app.post('/submit', async (req, res) => {
    try {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const { isValid, errors } = validateForm(formData);

      if (!isValid) {
        return res.status(400).render('form', {
          errors: Object.values(errors),
          values: formData
        });
      }

      await submitToDatabase(db, formData);

      res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    } catch (error) {
      console.error('Error submitting form:', error);
      res.status(500).render('form', {
        errors: ['An unexpected error occurred. Please try again.'],
        values: req.body
      });
    }
  });

  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
  });

  const gracefulShutdown = async (signal: string) => {
    console.log(`Received ${signal}. Starting graceful shutdown...`);
    
    try {
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    } catch (error) {
      console.error('Error during shutdown:', error);
      process.exit(1);
    }
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  return app;
}

async function startServer() {
  try {
    const app = await createApp();
    const server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });

    server.on('close', () => {
      console.log('HTTP server closed');
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default startServer;
