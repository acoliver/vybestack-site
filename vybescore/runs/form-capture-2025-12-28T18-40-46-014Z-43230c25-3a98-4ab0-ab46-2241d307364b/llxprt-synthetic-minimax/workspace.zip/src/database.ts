import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_FILE_PATH = path.join(process.cwd(), 'db', 'schema.sql');

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;

  async initialize(): Promise<void> {
    const SqlJsModule = await initSqlJs();

    // Load existing database or create new one
    if (fs.existsSync(DB_FILE_PATH)) {
      const dbBuffer = fs.readFileSync(DB_FILE_PATH);
      this.db = new SqlJsModule.Database(dbBuffer);
    } else {
      this.db = new SqlJsModule.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = fs.readFileSync(SCHEMA_FILE_PATH, 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    
    // Return the last inserted row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0].values[0][0] as number;
    
    return id;
  }

  async persist(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    // Ensure data directory exists
    const dataDir = path.dirname(DB_FILE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Write database to file
    const dbBuffer = this.db.export();
    fs.writeFileSync(DB_FILE_PATH, Buffer.from(dbBuffer));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  isInitialized(): boolean {
    return this.db !== null;
  }
}

export { DatabaseManager, type Submission };