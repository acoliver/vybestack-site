import express from 'express';
import * as path from 'path';
import { DatabaseManager, Submission } from './database';
import { Validator } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Database manager instance
const dbManager = new DatabaseManager();

// GET / - Show contact form
app.get('/', async (req, res) => {
  res.render('contact', {
    errors: [],
    formData: {},
    title: 'Contact Us - Friendly Form Capture'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req, res) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  // Validate form data
  const errors = Validator.validate(formData);

  if (errors.length > 0) {
    // Return to form with errors and previously entered values
    return res.status(400).render('contact', {
      errors,
      formData,
      title: 'Contact Us - Friendly Form Capture'
    });
  }

  try {
    // Insert submission into database
    const submission: Submission = {
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      streetAddress: formData.streetAddress.trim(),
      city: formData.city.trim(),
      stateProvince: formData.stateProvince.trim(),
      postalCode: formData.postalCode.trim(),
      country: formData.country.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim()
    };

    await dbManager.insertSubmission(submission);
    await dbManager.persist();

    // Redirect to thank-you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('contact', {
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      formData,
      title: 'Contact Us - Friendly Form Capture'
    });
  }
});

// GET /thank-you - Show thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You - Friendly Form Capture'
  });
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    // Graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}. Starting graceful shutdown...`);
      
      await dbManager.close();
      console.log('Database closed');
      
      process.exit(0);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      console.log('Press Ctrl+C to stop the server');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
