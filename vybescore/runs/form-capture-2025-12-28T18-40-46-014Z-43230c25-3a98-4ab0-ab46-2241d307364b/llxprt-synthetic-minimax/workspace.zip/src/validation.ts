interface ValidationError {
  field: string;
  message: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class Validator {
  static validate(formData: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = formData[field as keyof FormData];
      if (!value || value.trim() === '') {
        errors.push({
          field,
          message: `${this.formatFieldName(field)} is required`
        });
      }
    }

    // Email validation
    if (formData.email && formData.email.trim() !== '') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation (international formats)
    if (formData.phone && formData.phone.trim() !== '') {
      const phoneRegex = /^\+?[0-9\s\-()]{7,}$/;
      if (!phoneRegex.test(formData.phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number'
        });
      }
    }

    // Postal code validation (alphanumeric)
    if (formData.postalCode && formData.postalCode.trim() !== '') {
      const postalRegex = /^[a-zA-Z0-9\s-]{3,12}$/;
      if (!postalRegex.test(formData.postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal/zip code'
        });
      }
    }

    return errors;
  }

  private static formatFieldName(field: string): string {
    return field
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim();
  }
}

export { Validator, type ValidationError, type FormData };