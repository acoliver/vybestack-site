/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  defaultEqual,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? defaultEqual 
    : equal === false || equal === undefined 
      ? undefined 
      : equal

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize computed value if no initial value is provided
  // For standalone computed values with initial value, compute the initial value
  updateObserver(o)
  
  // Return getter that recomputes when dependencies change
  return (): T => {
    // Register dependency with current active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      o.observer = activeObserver
    }
    
    // For computed values with dependencies, recompute to get latest values
    // For standalone computed values, just return the stored value
    if (o.observer) {
      const newValue = updateFn(o.value)
      const shouldUpdate = !equalFn || !equalFn(o.value!, newValue)
      if (shouldUpdate) {
        o.value = newValue
      }
    }
    
    return o.value!
  }
}