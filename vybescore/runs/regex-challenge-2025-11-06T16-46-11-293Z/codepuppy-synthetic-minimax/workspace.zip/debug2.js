import { findEmbeddedToken } from './dist/puzzles.js';
console.log('Calling findEmbeddedToken with:', findEmbeddedToken('xfoo 1foo foo', 'foo'));