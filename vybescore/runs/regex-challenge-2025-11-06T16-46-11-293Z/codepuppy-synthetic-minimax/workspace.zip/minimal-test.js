// Test the exact logic from findEmbeddedToken
function findEmbeddedToken(text, token) {
  if (!text || !token) {
    return [];
  }

  // Simple pattern: digit followed by token
  const pattern = new RegExp('\\d' + token, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

console.log('Result:', findEmbeddedToken('xfoo 1foo foo', 'foo'));