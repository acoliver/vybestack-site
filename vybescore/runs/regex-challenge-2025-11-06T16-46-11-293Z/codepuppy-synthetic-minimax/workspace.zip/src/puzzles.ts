/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]]/g, '\$&');
  
  // Create regex to match words starting with the prefix
  const wordRegex = new RegExp('\b' + escapedPrefix + '\w+', 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  // Remove duplicates while preserving order
  const uniqueResults = [...new Set(result)];
  
  return uniqueResults;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Find token after digit, not at start
  // Look for digit followed by token
  const digitTokenPattern = new RegExp('\d' + token, 'g');
  const matches = text.match(digitTokenPattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must have at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters repeated immediately
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }

  // Check for characters repeated 3+ times in a row
  if (/(.)\1\1/.test(value)) {
    return false;
  }

  // Check for common weak patterns
  const weakPatterns = [
    /12345/i,
    /qwerty/i,
    /password/i,
    /admin/i
  ];
  
  if (weakPatterns.some(pattern => pattern.test(value))) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // IPv6 address patterns
  const ipv6Patterns = [
    // Full IPv6 addresses: 8 groups of 4 hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Compressed IPv6 with :: (can replace 1 or more groups)
    /\b(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    // IPv6 starting or ending with ::
    /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1-4}::\b/,
    // IPv6 with embedded IPv4
    /\b(?:[0-9a-fA-F]{1,4}:){6}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];

  // First, explicitly exclude IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // But don't immediately return false - it might be both IPv4 and IPv6 in the text
    // We'll check for IPv6 patterns and make sure we're not just matching IPv4
  }

  // Check for IPv6 patterns
  for (const pattern of ipv6Patterns) {
    const matches = value.match(pattern);
    if (matches) {
      // Verify that the match is not part of an IPv4 address
      for (const match of matches) {
        if (!ipv4Pattern.test(match.trim())) {
          return true;
        }
      }
    }
  }

  return false;
}