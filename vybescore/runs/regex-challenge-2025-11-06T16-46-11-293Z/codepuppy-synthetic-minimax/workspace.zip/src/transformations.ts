/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }

  // Step 1: Normalize spacing
  let normalized = text
    // Ensure space after sentence ending punctuation
    .replace(/([.!?])(?!\s|$)/g, '$1 ')
    // Collapse multiple spaces to single space
    .replace(/\s+/g, ' ')
    // Trim leading/trailing spaces
    .trim();

  // Step 2: Simple sentence capitalization
  // Split on sentence boundaries and capitalize each part
  return normalized.replace(/([.!?]\s+|^)([a-z])/g, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
}

/**
 * Extract URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // Comprehensive URL regex pattern - more permissive to catch basic URLs
  const urlRegex = /http:\/\/[^\s]+/g;

  const matches = text.match(urlRegex) || [];
  
  // Clean each match - remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation but not if it's part of the URL
    return url.replace(/[.,;:!?)\]\}]+$/g, '');
  });
}

/**
 * Convert all http:// URLs to https:// while leaving existing https:// unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https://, but only when it's at the start of a URL
  // Avoid replacing if already https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Pattern to match URLs and capture relevant parts
  const urlPattern = /(https?:\/\/)([^\/]+)(\/[^\s]*)?/g;

  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should rewrite the host
    let shouldRewriteHost = false;
    
    if (path.startsWith('/docs/')) {
      // Check for exceptions - skip if contains dynamic content
      const exceptionPatterns = [
        /\/cgi-bin\//,
        /[?&=]/,  // Query string indicators
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i // Legacy extensions
      ];
      
      shouldRewriteHost = !exceptionPatterns.some(pattern => pattern.test(path));
    }
    
    if (shouldRewriteHost) {
      // Rewrite to docs.subdomain
      const newHost = `docs.${host.replace(/^www\./, '')}`;
      return `${newScheme}${newHost}${path}`;
    } else {
      // Just upgrade the scheme
      return `${newScheme}${host}${path}`;
    }
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day against month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let maxDays = daysInMonth[month - 1];
  
  // Handle leap years for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
      maxDays = 29;
    }
  }
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
