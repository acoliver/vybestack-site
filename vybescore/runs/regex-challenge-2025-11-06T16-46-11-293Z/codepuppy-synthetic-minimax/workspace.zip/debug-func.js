function findEmbeddedToken(text, token) {
  console.log('Input text:', text, 'token:', token);
  
  if (!text || !token) {
    console.log('Returning empty array - missing input');
    return [];
  }

  const digitTokenPattern = /\dfoo/g;
  console.log('Pattern:', digitTokenPattern.toString());
  
  const matches = text.match(digitTokenPattern) || [];
  console.log('Matches found:', matches);
  
  return matches;
}

findEmbeddedToken('xfoo 1foo foo', 'foo');