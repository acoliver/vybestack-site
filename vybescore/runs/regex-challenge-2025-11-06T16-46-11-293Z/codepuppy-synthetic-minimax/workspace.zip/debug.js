// Quick debug script
console.log('findEmbeddedToken test:', 'xfoo 1foo foo'.match(/\dfoo/g));
console.log('extractUrls test:', 'Visit http://example.com today'.match(/http:\/\/[^\s]+/g));