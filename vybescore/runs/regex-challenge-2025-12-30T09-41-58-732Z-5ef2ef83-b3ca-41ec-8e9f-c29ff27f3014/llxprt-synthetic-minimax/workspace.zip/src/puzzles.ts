/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words starting with prefix but exclude exceptions
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (const word of words) {
    // Clean word of punctuation
    const cleanWord = word.replace(/[^\w]/g, '');
    
    // Check if it starts with prefix and not in exceptions
    if (cleanWord.startsWith(prefix) && !exceptions.includes(cleanWord)) {
      results.push(cleanWord);
    }
  }
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences of token that appear after a digit and not at the start
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'g');
  return text.match(pattern) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace
  // No immediate repeated sequences (e.g., 'abab' should fail)
  
  // Check length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[a-z]/.test(value)) return false;
  if (!/[A-Z]/.test(value)) return false;
  if (!/\d/.test(value)) return false;
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., 'abab', '1212', etc.)
  // This regex looks for any 2-character sequence that repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger
  const ipv6Regex = /(^|[^0-9])(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))([^0-9]|$)/;
  
  if (ipv6Regex.test(value)) {
    // Make sure it's not an IPv4 address
    const ipv4Regex = /(^|[^0-9])(([0-9]{1,3}\.){3}[0-9]{1,3})([^0-9]|$)/;
    if (!ipv4Regex.test(value)) {
      return true;
    }
  }
  
  // Also check for shorthand notation like ::
  if (/(^|[^0-9])::/.test(value)) {
    return true;
  }
  
  return false;
}
