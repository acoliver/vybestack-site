/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first character of each sentence after .?! and ensure proper spacing
  return text
    .replace(/(^|[.!?]\s+)(\w)/g, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    })
    .replace(/\s+([.!?])/g, '$1 ') // Fix space before punctuation
    .replace(/([.!?])\s*/g, '$1 ')  // Ensure single space after punctuation
    .replace(/\s+/g, ' ')           // Collapse multiple spaces
    .trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Extract all URLs without trailing punctuation
  const urlRegex = /\bhttps?:\/\/[^\s<>"']*[^\s<>"'.,!?;:)]/g;
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,!?;:)]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs and rewrite according to rules
  const urlPattern = /http:\/\/([^\/]+)(\/[^\s<>"']*)/g;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDynamicHint = /(\?|=|&|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !hasDynamicHint) {
      // Rewrite host to docs.example.com when path is /docs/
      return `https://docs.${host}${path}`;
    } else {
      // Just upgrade scheme, keep original host
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with proper validation
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12) and day (01-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
