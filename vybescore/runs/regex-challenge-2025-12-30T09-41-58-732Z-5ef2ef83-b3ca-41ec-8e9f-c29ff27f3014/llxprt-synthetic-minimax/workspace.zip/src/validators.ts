export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '').split('').reverse();
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = parseInt(digits[i], 10);
    
    // Double every second digit
    if (i % 2 === 1) {
      digit *= 2;
      // If result is two digits, add them together
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for obviously invalid forms
  if (value.includes('..') || value.endsWith('.') || value.includes('@.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and spaces
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Check for optional +1 prefix
  const phoneRegex = /^\+?1?([2-9]\d{2})([2-9]\d{2})\d{4}$/;
  
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  // Validate area code (cannot start with 0 or 1)
  const areaCode = cleaned.startsWith('+') || cleaned.startsWith('1') ? 
    cleaned.substring(cleaned.startsWith('+') ? 2 : 1, 4) : 
    cleaned.substring(0, 3);
  
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Ensure we have exactly 10 digits after country code removal
  const digitsOnly = cleaned.replace(/^\+?1?/, '');
  return digitsOnly.length === 10;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters temporarily for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Argentine phone validation with comprehensive regex
  // Pattern: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const arPhoneRegex = /^(\+?54)?([089])?([01])?(\d{2,4})(\d{6,8})$/;
  
  const match = digitsOnly.match(arPhoneRegex);
  if (!match) {
    return false;
  }
  
  // Validate components
  const countryCode = match[1] || '';
  const trunkPrefix = match[3] || '';
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // When country code is omitted, we must have trunk prefix
  if (!countryCode && trunkPrefix !== '0' && trunkPrefix !== '1') {
    return false;
  }
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Total length validation (country + area + subscriber)
  // Minimum: trunk(0) + area(min2) + subscriber(min6) = 8 digits
  // Maximum: +54(2) + area(max4) + subscriber(max8) = 14 digits
  if (digitsOnly.length < 8 || digitsOnly.length > 14) {
    return false;
  }
  
  // Validate separators - allow only single spaces or hyphens
  const separatorRegex = /^[\+\d\s\-()]+$/;
  if (!separatorRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Validate names allowing unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: no consecutive special characters
  if (/['\-\s]{2,}/.test(value)) {
    return false;
  }
  
  // Must not start or end with special characters (except spaces at end)
  if (/^['\-\s]|['\-\s]$/.test(value.trim())) {
    return false;
  }
  
  // Reject obviously invalid patterns like X Æ A-12
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Visa: 4 followed by 12-18 more digits (total 13, 16, or 19)
  // MasterCard: 51-55 or 2221-2720 followed by 12-15 digits (total 16)
  // AmEx: 34 or 37 followed by 14-15 digits (total 15)
  const cardRegex = /^((4\d{12,18})|(5[1-5]\d{14})|(2(2[2-9]\d{2}|[3-6]\d{3}|7[01]\d{2}|720\d\d?)\d{12})|(34\d{13,14})|(37\d{13,14}))$/;
  
  if (!cardRegex.test(digitsOnly)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
