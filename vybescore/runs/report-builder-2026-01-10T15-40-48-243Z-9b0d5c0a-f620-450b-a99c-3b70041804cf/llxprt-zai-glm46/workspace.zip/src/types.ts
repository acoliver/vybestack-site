/**
 * Report entry data model
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Report data model matching the JSON schema
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Format function signature
 */
export type FormatRenderer = (data: ReportData, options: RenderOptions) => string;
