/**
 * Format an amount as a dollar string with two decimal places
 */
function formatAmount(amount) {
    return `$${amount.toFixed(2)}`;
}
/**
 * Calculate total amount from entries
 */
function calculateTotal(data) {
    return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}
/**
 * Render report in plain text format
 */
export const renderText = (data, options) => {
    const lines = [];
    // Title
    lines.push(data.title);
    lines.push('');
    // Summary
    lines.push(data.summary);
    lines.push('');
    // Entries section
    lines.push('Entries:');
    for (const entry of data.entries) {
        lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }
    // Optional total
    if (options.includeTotals) {
        const total = calculateTotal(data);
        lines.push('');
        lines.push(`Total: ${formatAmount(total)}`);
    }
    return lines.join('\n');
};
