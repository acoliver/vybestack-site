/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: () => T,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue: T | undefined = value
  
  const o: Observer = {
    name: options?.name,
    value: computedValue,
    update: (_currentValue) => {
      // Re-evaluate the computed function
      const previousObserver = getActiveObserver()
      setActiveObserver(o)
      
      try {
        const newValue = updateFn()
        const oldValue = computedValue
        computedValue = newValue
        o.value = newValue
        
        // Notify dependents only if value actually changed to avoid infinite loops
        if (newValue !== oldValue && s.observers.size > 0) {
          // Notify all dependents
          for (const dependent of s.observers) {
            updateObserver(dependent)
          }
        }
      } finally {
        setActiveObserver(previousObserver)
      }
    },
    subscribers: new Set(),
  }
  
  // Create a subject interface for dependency tracking
  const s = {
    name: options?.name,
    observers: new Set<Observer>(),
    value: computedValue,
    equalFn: undefined,
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    // Establish dependency relationship
    if (observer && observer !== o) {
      s.observers.add(observer)
      // Also add to the observer's subjects for proper cleanup
      if (observer.subjects === undefined) {
        observer.subjects = new Set()
      }
      observer.subjects.add(o)
    }
    
    // Evaluate the computed function
    const previousObserver = getActiveObserver()
    setActiveObserver(o)
    
    try {
      const newValue = updateFn()
      computedValue = newValue
      o.value = newValue
      return newValue
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Initial evaluation
  if (computedValue === undefined) {
    updateObserver(o)
  }
  
  return getter
}
