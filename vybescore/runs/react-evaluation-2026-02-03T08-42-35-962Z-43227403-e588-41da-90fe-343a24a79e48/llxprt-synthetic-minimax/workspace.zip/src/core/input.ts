/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  const observers = new Set<Observer>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this input with the active observer
      observers.add(observer)
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    currentValue = nextValue
    
    // Notify all observers that depend on this input
    if (observers.size > 0) {
      const observerList = Array.from(observers)
      observerList.forEach(observer => {
        // Notify the observer that its value should be updated
        updateObserver(observer)
      })
    }
    
    return currentValue
  }

  return [read, write]
}
