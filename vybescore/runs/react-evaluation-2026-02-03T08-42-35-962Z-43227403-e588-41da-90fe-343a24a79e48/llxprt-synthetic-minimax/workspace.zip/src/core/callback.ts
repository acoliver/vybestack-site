/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, updateObserver, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: () => T, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer = {
    name: undefined,
    value,
    update: (_currentValue) => {
      if (disposed) return
      
      // Execute the callback function to establish dependencies
      const previousObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        const result = updateFn()
        observer.value = result
      } finally {
        setActiveObserver(previousObserver)
      }
    },
    subscribers: new Set(),
  }
  
  // Execute the callback to register dependencies and get initial value
  updateObserver(observer)
  
  const unsubscribe = () => {
    disposed = true
  }
  
  return unsubscribe
}
