/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  value?: unknown
  update: (_value?: unknown) => void
  subjects?: Set<Observer>
  subscribers?: Set<() => void>
}

export interface Subject<T> {
  name?: string
  observers: Set<Observer>
  value: T
  equalFn?: EqualFn<T>
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}

export function updateObserver(observer: Observer): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.update(observer.value)
  } finally {
    activeObserver = previous
  }
}
