export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();

  // Basic format check: local-part@domain
  const emailRegex = /^(.+)@(.+)$/;
  const match = trimmed.match(emailRegex);

  if (!match) {
    return false;
  }

  const [, localPart, domain] = match;

  // Check for double dots in local part
  if (localPart.includes('..')) {
    return false;
  }

  // Check for trailing dot in local part
  if (localPart.endsWith('.')) {
    return false;
  }

  // Domain validation
  const domainParts = domain.split('.');

  // Must have at least 2 parts (domain.tld)
  if (domainParts.length < 2) {
    return false;
  }

  // Check each domain part
  for (let i = 0; i < domainParts.length; i++) {
    const part = domainParts[i];

    // No underscores in domain parts
    if (part.includes('_')) {
      return false;
    }

    // No trailing dots
    if (part.endsWith('.')) {
      return false;
    }

    // No double dots
    if (part.includes('..')) {
      return false;
    }

    // Domain parts can't be empty
    if (part.length === 0) {
      return false;
    }
  }

  // Basic local part validation (no spaces, valid characters)
  // Allow letters, numbers, and some special characters: . + - _
  const localRegex = /^[a-zA-Z0-9.+_-]+$/;
  if (!localRegex.test(localPart)) {
    return false;
  }

  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Too short (need at least 10 digits)
  if (digitsOnly.length < 10) {
    return false;
  }

  // Check if it starts with +1
  let normalizedDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    normalizedDigits = digitsOnly.substring(1);
  }

  // Now we should have exactly 10 digits
  if (normalizedDigits.length !== 10) {
    return false;
  }

  // Check area code (first 3 digits)
  const areaCode = normalizedDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // Check if the original format is valid (with separators)
  const phoneRegex = /^\+?1?[-.\s]?(\([0-9]{3}\)|[0-9]{3})[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
  if (!phoneRegex.test(value.trim())) {
    return false;
  }

  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for easier processing
  const cleaned = value.replace(/[\s-]/g, '');

  // Argentine phone number patterns:
  // With country code: +54...
  // Without country code: starts with 0...
  const regex = /^(?:\+54)?(?:9)?0?([1-9]\d{1,3})\d{6,8}$/;
  
  const match = cleaned.match(regex);
  if (!match) {
    return false;
  }

  const [, areaCode] = match;
  
  // Area code should be 2-4 digits (first digit already validated as 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Total subscriber number (area code + remaining digits) should be 6-8 digits
  const subscriberNumber = cleaned.substring(cleaned.indexOf(areaCode) + areaCode.length);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // Check that the original format has valid separators (or none)
  const originalRegex = /^\+?\d?\s?9?\s?0?\d{2,4}[\s-]?\d{6,8}$/;
  if (!originalRegex.test(value)) {
    return false;
  }

  // Ensure at least one digit for area code and subscriber number
  const areaCodeMatch = cleaned.match(/(\d{2,4})\d{6,8}$/);
  if (!areaCodeMatch || areaCodeMatch[1].length < 2) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Remove leading/trailing whitespace
  const trimmed = value.trim();

  // Must not contain digits
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Must not contain special symbols like X Æ A-12 style
  // Allow: letters (including unicode), spaces, hyphens, apostrophes
  // Pattern explanation:
  // ^ start of string
  // [^\d]+$ match one or more chars that are not digits
  // with the condition that only these chars are allowed: letters, spaces, hyphens, apostrophes
  const validCharsRegex = /^[\p{L}\p{M}\s'-]+$/u;
  if (!validCharsRegex.test(trimmed)) {
    return false;
  }

  // Additional check: ensure no consecutive special characters (like Æ which is a single char)
  // But actually Æ is a single letter in some alphabets, so we should allow it
  // The main restriction is no digits and no other symbols

  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Check length (13-19 digits for major credit cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }

  // Check prefixes (Visa, Mastercard, AmEx)
  const isVisa = /^4\d{12,18}$/.test(digitsOnly);
  const isMastercard = /^5[1-5]\d{14}$/.test(digitsOnly) || /^2[2-7]\d{14}$/.test(digitsOnly);
  const isAmEx = /^3[47]\d{13}$/.test(digitsOnly) || /^3[0]\d{13}$/.test(digitsOnly);

  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
