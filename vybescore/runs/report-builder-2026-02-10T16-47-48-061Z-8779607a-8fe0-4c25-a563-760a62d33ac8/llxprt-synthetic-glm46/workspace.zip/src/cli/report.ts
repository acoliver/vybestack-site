#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';

function parseArgs(): { inputFile: string; format: string; outputFile?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  let format = '';
  let outputFile: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputFile = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { inputFile, format, outputFile, includeTotals };
}

function loadData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate data structure
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid data: each entry must have a label string');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid data: each entry must have an amount number');
      }
    }
    
    return data;
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error loading data: ${errorMessage}`);
    process.exit(1);
  }
}

function main(): void {
  const { inputFile, format, outputFile, includeTotals } = parseArgs();
  
  // Load data
  const data = loadData(inputFile);
  const options: RenderOptions = { includeTotals };
  
  // Get formatter
  let formatter;
  switch (format) {
    case 'markdown':
      formatter = new MarkdownFormatter();
      break;
    case 'text':
      formatter = new TextFormatter();
      break;
    default:
      console.error(`Error: Unsupported format "${format}"`);
      process.exit(1);
  }
  
  // Render report
  const output = formatter.render(data, options);
  
// Write output
  if (outputFile) {
    try {
      writeFileSync(outputFile, output, 'utf-8');
      console.log(`Report written to ${outputFile}`);
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Error writing to file: ${errorMessage}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
