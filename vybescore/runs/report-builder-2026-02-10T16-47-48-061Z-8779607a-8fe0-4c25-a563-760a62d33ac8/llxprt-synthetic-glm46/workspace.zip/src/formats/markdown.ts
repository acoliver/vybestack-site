import { ReportData, RenderOptions, Formatter } from '../types.js';

export class MarkdownFormatter implements Formatter {
  render(data: ReportData, options: RenderOptions): string {
    const lines = [];
    
    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    if (data.summary) {
      lines.push(data.summary);
      lines.push('');
    }
    
    // Entries
    lines.push('## Entries');
    lines.push('');
    
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
    }
    
    // Optional total
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push('');
      lines.push(`**Total:** $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
}