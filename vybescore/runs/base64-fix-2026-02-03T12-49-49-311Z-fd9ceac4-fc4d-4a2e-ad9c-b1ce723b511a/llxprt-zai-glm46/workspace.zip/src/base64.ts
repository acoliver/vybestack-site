const DECODE_ERROR = 'Invalid Base64 input';

/**
 * Regular expression matching valid Base64 strings (with or without padding).
 * Standard Base64 alphabet: A-Z, a-z, 0-9, +, /
 * 
 * Pattern explanation:
 * - Groups of 4 valid Base64 chars: (?:[A-Za-z0-9+/]{4})*
 * - Final group can be:
 *   - Exactly 3 Base64 chars (no padding needed): [A-Za-z0-9+/]{3}
 *   - Exactly 2 Base64 chars + padding: [A-Za-z0-9+/]{2}==
 *   - Exactly 3 Base64 chars + single padding: [A-Za-z0-9+/]{3}=
 * - This allows valid Base64 both with and without padding
 */
const VALID_BASE64_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2,3}(?:={0,2})?)?$/;

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * 
 * Accepts valid Base64 input with or without padding and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Trim whitespace from input
  const trimmed = input.trim();

  // Validate the input is valid Base64 before attempting decode
  if (!VALID_BASE64_REGEX.test(trimmed)) {
    throw new Error(DECODE_ERROR);
  }

  try {
    // Buffer.from with 'base64' encoding handles padding correctly
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding resulted in an empty buffer for non-empty input
    // This can happen with invalid but syntactically matching Base64
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error(DECODE_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(DECODE_ERROR);
  }
}
