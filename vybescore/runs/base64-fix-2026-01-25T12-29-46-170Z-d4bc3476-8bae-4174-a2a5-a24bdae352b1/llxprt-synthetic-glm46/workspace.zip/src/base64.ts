/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check if padding is correct (if present)
  const paddingCount = (input.match(/=/g) || []).length;
  const nonPaddingLength = input.length - paddingCount;
  
  // Padding can only be at the end and can be 0, 1, or 2 characters
  if (paddingCount > 0) {
    const paddingIndex = input.indexOf('=');
    if (paddingIndex !== nonPaddingLength) {
      throw new Error('Invalid Base64 input: padding not at the end');
    }
    
    // The total length must be a multiple of 4 when padding is present
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length for padding');
    }
  } else if (nonPaddingLength % 4 === 1) {
    // If no padding, the length must not be 1 mod 4 (which would require padding)
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
