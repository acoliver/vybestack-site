import initSqlJs from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Define sql.js types based on @types/sql.js
interface SqlJsDatabase {
  exec(sql: string): void;
  prepare(sql: string): SqlJsStatement;
  close(): void;
  export(): Uint8Array;
}

interface SqlJsStatement {
  run(params?: (string | number)[] | Record<string, string | number> | null): void;
  free(): void;
}

type SqlJsStatic = {
  Database: new (buffer?: Uint8Array) => SqlJsDatabase;
  Statement: new () => SqlJsStatement;
};

class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private SqlJs: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    // Initialize sql.js
    const SqlJsModule = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file),
    });

    this.SqlJs = SqlJsModule;

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      this.db = new SqlJsModule.Database(dbBuffer);
    } else {
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      this.db = new SqlJsModule.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: Submission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone,
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db || !this.SqlJs) {
      throw new Error('Database not initialized');
    }

    const dbBuffer = this.db.export();
    fs.writeFileSync(DB_PATH, dbBuffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  getDatabase(): SqlJsDatabase | null {
    return this.db;
  }
}

export const dbManager = new DatabaseManager();
export type { Submission };