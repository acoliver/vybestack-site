export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export function validateFormData(data: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: Array<keyof FormData> = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field]?.trim();
    if (!value) {
      errors.push({
        field,
        message: `${formatFieldName(field)} is required`
      });
    }
  });

  // Email validation
  if (data.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation
  if (data.phone) {
    const phoneRegex = /^\+?[0-9\s-()]{7,}$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and leading + are allowed)'
      });
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postal_code) {
    const postalRegex = /^[a-zA-Z0-9\s-]{3,10}$/;
    if (!postalRegex.test(data.postal_code.trim())) {
      errors.push({
        field: 'postal_code',
        message: 'Please enter a valid postal code (letters, numbers, spaces, and dashes are allowed)'
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

function formatFieldName(field: string): string {
  return field
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}