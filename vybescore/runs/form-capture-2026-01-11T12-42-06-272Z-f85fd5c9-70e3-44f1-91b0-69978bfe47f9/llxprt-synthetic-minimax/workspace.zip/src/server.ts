import express from 'express';
import * as path from 'path';
import { dbManager, Submission } from './database.js';
import { validateFormData, ValidationError, FormData } from './validation.js';

interface ServerLike {
  close(callback?: () => void): void;
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));
app.use('/public', express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Interface for template data
interface TemplateData {
  errors?: ValidationError[];
  formData?: Partial<FormData>;
}

// Routes
app.get('/', async (req, res) => {
  res.render('form', {
    errors: [],
    formData: {}
  } as TemplateData);
});

app.post('/submit', async (req, res) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  // Validate form data
  const validation = validateFormData(formData);

  if (!validation.isValid) {
    // Re-render form with errors and previous values
    return res.status(400).render('form', {
      errors: validation.errors,
      formData
    } as TemplateData);
  }

  try {
    // Insert submission into database
    const submission: Submission = {
      first_name: formData.first_name.trim(),
      last_name: formData.last_name.trim(),
      street_address: formData.street_address.trim(),
      city: formData.city.trim(),
      state_province: formData.state_province.trim(),
      postal_code: formData.postal_code.trim(),
      country: formData.country.trim(),
      email: formData.email.trim(),
      phone: formData.phone.trim()
    };

    await dbManager.insertSubmission(submission);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'An error occurred while processing your submission. Please try again.' }],
      formData
    } as TemplateData);
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
function gracefulShutdown(server: ServerLike, signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  server.close(async () => {
    console.log('HTTP server closed.');
    
    try {
      await dbManager.close();
      console.log('Database connection closed.');
    } catch (error) {
      console.error('Error closing database:', error);
    }
    
    console.log('Graceful shutdown completed.');
    process.exit(0);
  });
}

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully.');
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });

    // Handle shutdown signals
    process.on('SIGTERM', () => gracefulShutdown(server, 'SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown(server, 'SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(error => {
  console.error('Unhandled error during startup:', error);
  process.exit(1);
});
