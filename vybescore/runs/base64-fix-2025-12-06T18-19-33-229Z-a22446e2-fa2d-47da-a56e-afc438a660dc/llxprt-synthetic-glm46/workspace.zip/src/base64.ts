/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if a string is a valid Base64 input.
 */
function isValidBase64(input: string): boolean {
  // Base64 regex: matches A-Z, a-z, 0-9, +, /, and optional padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check basic format first
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check for padding placement and count
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    return false;
  }
  
  // Check that padding only appears at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const nonPaddingAfterIndex = input.slice(paddingIndex).replace(/=/g, '');
    if (nonPaddingAfterIndex.length > 0) {
      return false;
    }
  }
  
  // Check length requirements:
  // If there's no padding, accept any valid length
  // If there's padding, must be properly aligned
  const mod4 = input.length % 4;
  if (paddingCount === 0) {
    // Unpadded input can be any length that's valid base64
    // Add padding to check if it can be correctly decoded
    let testInput = input;
    while (testInput.length % 4 !== 0) {
      testInput += '=';
    }
    try {
      Buffer.from(testInput, 'base64');
      return true;
    } catch {
      return false;
    }
  } else {
    // Padded input must be properly aligned
    return mod4 === 0;
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
