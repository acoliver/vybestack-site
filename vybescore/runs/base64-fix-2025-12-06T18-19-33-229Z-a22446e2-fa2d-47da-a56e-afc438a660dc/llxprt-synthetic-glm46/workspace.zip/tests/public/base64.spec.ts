import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('encodes UTF-8 text with special characters', () => {
    const result = encode('héllo wörld');
    expect(result).toBe('aMOpbGxvIHfDtnJsZA==');
  });

  it('decodes UTF-8 text with special characters', () => {
    const result = decode('aMOpbGxvIHfDtnJsZA==');
    expect(result).toBe('héllo wörld');
  });

  it('rejects invalid Base64 input', () => {
    expect(() => decode('!invalid!')).toThrow();
  });

  it('rejects incorrectly padded Base64 input', () => {
    expect(() => decode('aGVsbG8==')).toThrow();
  });
});
