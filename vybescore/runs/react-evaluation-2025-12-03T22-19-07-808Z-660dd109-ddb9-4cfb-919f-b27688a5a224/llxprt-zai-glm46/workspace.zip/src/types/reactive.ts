/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T = unknown> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<T>>
}

export interface Subject<T = unknown> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<T>>
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    if (!subject.observers) {
      subject.observers = new Set()
    }
    subject.observers.add(observer as Observer<T>)
    
    if (!observer.dependencies) {
      observer.dependencies = new Set()
    }
    observer.dependencies.add(subject as Subject<unknown>)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  // Create a copy to avoid issues with observers being added/removed during notification
  const observersToNotify = Array.from(subject.observers)
  
  observersToNotify.forEach(observer => {
    updateObserver(observer)
  })
}