/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, updateObserver, Subject, trackDependency, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  // Track dependencies for the callback
  const callbackSubject: Subject<T> = {
    value: value as T,
    observers: new Set(),
  }
  trackDependency(callbackSubject)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove from all subjects
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        if (subject.observers) {
          subject.observers.delete(observer)
        }
      })
      observer.dependencies.clear()
    }
  }
}
