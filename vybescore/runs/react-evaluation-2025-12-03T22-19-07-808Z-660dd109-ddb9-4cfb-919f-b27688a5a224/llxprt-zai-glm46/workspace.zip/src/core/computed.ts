/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  trackDependency,
  notifyObservers,
  Subject,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject for this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    value: value as T,
    observers: new Set(),
  }
  
  const read: GetterFn<T> = () => {
    // When reading, track this computed as a dependency 
    trackDependency(computedSubject)
    return computedSubject.value
  }
  
  // Override updateFn to update the subject and notify when computed changes
  o.updateFn = (prevValue?: T) => {
    // Clear dependencies before recomputing
    if (o.dependencies) {
      o.dependencies.clear()
    }
    
    const newValue = updateFn(prevValue)
    if (newValue !== prevValue) {
      computedSubject.value = newValue
      // Notify observers of this computed value when it changes
      notifyObservers(computedSubject)
    }
    return newValue
  }
  
  // Initial computation
  updateObserver(o)
  
  return read
}
