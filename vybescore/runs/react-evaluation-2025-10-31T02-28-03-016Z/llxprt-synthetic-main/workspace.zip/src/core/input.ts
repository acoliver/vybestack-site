/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Default equality function if not provided
  const equalFn = _equal === true 
    ? (lhs: T, rhs: T) => lhs === rhs 
    : typeof _equal === 'function' 
    ? _equal 
    : undefined

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subject.observer = observer
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value has changed using equality function
    const hasChanged = !equalFn || !equalFn(subject.value, nextValue)
    if (!hasChanged) {
      return subject.value
    }
    
    subject.value = nextValue
    
    // Notify the observer and then all observers to propagate changes
    if (subject.observer) {
      updateObserver(subject.observer as Observer<T>)
      notifyObservers()
   }
    
    return subject.value
  }

  return [read, write]
}