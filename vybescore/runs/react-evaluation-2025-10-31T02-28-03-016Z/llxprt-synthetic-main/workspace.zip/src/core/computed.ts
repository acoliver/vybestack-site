/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Use default equality function if not provided
  // Note: currently not used in computed values but keeping for API compatibility
  const _equalFn = _equal === true 
    ? (lhs: T, rhs: T) => lhs === rhs 
    : typeof _equal === 'function' 
    ? _equal 
    : undefined

  let computedValue: T
  let isStale = true
  let isComputing = false

  // Observer for this computed value
  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      computedValue = updateFn(prevValue)
      isStale = false
      return computedValue
    },
  }

  const getValue = (): T => {
    // If value is not stale, return cached value
    if (!isStale) {
      return computedValue
    }

    // Prevent circular dependencies
    if (isComputing) {
      // Return cached or initial value during computation
      return computedValue || value as T
    }

    isComputing = true
    
    try {
      // Compute new value by setting this observer as active
      updateObserver(computedObserver)
    } finally {
      isComputing = false
    }
    
    return computedValue
  }

  // Initial computation
  getValue()

  return getValue
}