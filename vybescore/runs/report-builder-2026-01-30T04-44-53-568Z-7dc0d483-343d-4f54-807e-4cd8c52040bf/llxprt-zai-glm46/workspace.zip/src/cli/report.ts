#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions, FormatRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const parsed: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      parsed.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      parsed.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (parsed.inputFile === '') {
      parsed.inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
    i++;
  }

  if (parsed.inputFile === '') {
    throw new Error('Input file path is required');
  }

  if (parsed.format === '') {
    throw new Error('--format is required');
  }

  return parsed;
}

function loadData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }

    const obj = data as Record<string, unknown>;

    if (typeof obj.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field (expected string)');
    }

    if (typeof obj.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field (expected string)');
    }

    if (!Array.isArray(obj.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field (expected array)');
    }

    for (let i = 0; i < obj.entries.length; i++) {
      const entry = obj.entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid data: entry at index ${i} is not an object`);
      }

      const entryObj = entry as Record<string, unknown>;

      if (typeof entryObj.label !== 'string') {
        throw new Error(
          `Invalid data: entry at index ${i} has missing or invalid "label" field (expected string)`
        );
      }

      if (typeof entryObj.amount !== 'number') {
        throw new Error(
          `Invalid data: entry at index ${i} has missing or invalid "amount" field (expected number)`
        );
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${filePath}": ${error.message}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArguments(process.argv.slice(2));

    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Error: Unsupported format "${args.format}"`);
      console.error(`Supported formats: ${Object.keys(formatters).join(', ')}`);
      process.exit(1);
    }

    const data = loadData(args.inputFile);

    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
