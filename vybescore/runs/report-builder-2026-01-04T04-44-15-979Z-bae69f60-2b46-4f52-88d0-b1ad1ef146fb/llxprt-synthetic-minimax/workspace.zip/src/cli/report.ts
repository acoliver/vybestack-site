#!/usr/bin/env node

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CLIOptions } from '../types.js';

function parseArguments(args: string[]): CLIOptions {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: 'markdown' | 'text' | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments starting from index 1 (skip script name)
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue === 'markdown' || formatValue === 'text') {
        format = formatValue;
      } else {
        console.error('Unsupported format');
        process.exit(1);
      }
      i++; // Skip next argument since we consumed it
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument since we consumed it
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Format is required. Use --format markdown or --format text');
    process.exit(1);
  }

  if (!existsSync(dataFile)) {
    console.error(`Error: Data file '${dataFile}' not found`);
    process.exit(1);
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" field must be a string');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field must be a string');
  }

  if (typeof report.entries !== 'object' || report.entries === null || !Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" field must be an array');
  }

  const entries = report.entries as unknown[];
  const validatedEntries = entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${index} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry[${index}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number' || !isFinite(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry[${index}].amount must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries: validatedEntries
  };
}

function loadAndValidateData(dataFile: string): ReportData {
  try {
    const content = readFileSync(dataFile, 'utf8');
    const rawData = JSON.parse(content);
    return validateReportData(rawData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON in data file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to load data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      console.error('Unsupported format');
      process.exit(1);
  }
}

function main(): void {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  // Treat first argument as data file if it doesn't start with --
  const dataFile = args[0];

  if (dataFile.startsWith('--')) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const options = parseArguments(args);
  const reportData = loadAndValidateData(options.dataFile);
  
  const output = renderReport(reportData, options);

  if (options.outputPath) {
    try {
      writeFileSync(options.outputPath, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${options.outputPath}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
