/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: replace multiple spaces with single space
  const result = text.replace(/\s+/g, ' ').trim();

  // Split into sentences using sentence boundaries
  const sentences: string[] = [];
  let current = '';

  for (let i = 0; i < result.length; i++) {
    const char = result[i];
    current += char;

    // Check if we're at a sentence end
    if (char === '.' || char === '?' || char === '!') {
      // Look ahead to see if this might be an abbreviation
      const beforeDelimiter = current.slice(0, -1).trim();
      const nextChars = result.slice(i + 1, i + 3);

      // Common abbreviations that should not trigger capitalization
      const abbreviations = ['mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'vs', 'etc', 'eg', 'ie', 'approx', 'est', 'no', 'dept', 'univ', 'assn', 'ave', 'blvd', 'mt', 'ft', 'rd', 'st'];

      // Check if the word before the delimiter is an abbreviation
      const lastWord = beforeDelimiter.split(/\s+/).pop()?.toLowerCase() || '';
      const isAbbreviation = abbreviations.includes(lastWord);

      // If it's not an abbreviation and we have content after, this is a sentence end
      if (!isAbbreviation && (nextChars[0] === ' ' || nextChars[0] === '')) {
        sentences.push(current.trim());
        current = '';
      }
    }
  }

  if (current.trim()) {
    sentences.push(current.trim());
  }

  // Capitalize each sentence and join with single space
  const capitalized = sentences.map((sentence) => {
    // Find the first letter and capitalize it
    return sentence.replace(/^([.?!]\s*)?([a-z])/, (_, prefix, letter) => {
      if (prefix) {
        return prefix + letter.toUpperCase();
      } else {
        return letter.toUpperCase();
      }
    });
  }).join(' ');

  return capitalized;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http:// or https:// followed by non-space characters
  // We'll clean up trailing punctuation afterwards
  const urlPattern = /https?:\/\/[^\s<>"]+/g;

  const matches = text.match(urlPattern);

  if (!matches) {
    return [];
  }

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters but keep valid URL characters
    return url.replace(/[.,!?;:)\]]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (when it's not already https://)
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://...,
 * moving docs paths to https://docs.example.com/ where applicable.
 *
 * Rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains:
 *   - cgi-bin
 *   - query strings (?, &, =)
 *   - legacy extensions (.jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/g;

  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if this is an example.com URL and has a path
    if (host === 'example.com' && path) {
      // Check for dynamic hints that should prevent host rewrite
      const legacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/;
      const hasQueryString = /[?&=]/.test(path);
      const hasCgiBin = path.includes('/cgi-bin/');

      if (!legacyExtensions.test(path) && !hasQueryString && !hasCgiBin) {
        // Check if path starts with /docs/
        if (path.startsWith('/docs/')) {
          // Rewrite to docs.example.com
          return newProtocol + 'docs.example.com' + path;
        }
      }
    }

    // Just upgrade the scheme
    return newProtocol + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day (1-31, with consideration for month)
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  return yearStr;
}
