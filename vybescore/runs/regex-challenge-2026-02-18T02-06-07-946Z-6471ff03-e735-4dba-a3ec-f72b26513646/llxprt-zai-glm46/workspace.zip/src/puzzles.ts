/**
 * Find words starting with the given prefix, excluding listed exceptions.
 * Uses word boundaries to match complete words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create regex to match words starting with prefix
  // \b ensures we match word boundaries
  const regex = new RegExp(`\\b(${escapedPrefix}\\w*)\\b`, 'gi');
  
  const matches = text.matchAll(regex);
  const results: string[] = [];
  
  for (const match of matches) {
    const word = match[1];
    // Check if this word is in the exceptions list (case-insensitive)
    const isException = exceptions.some(exc => exc.toLowerCase() === word.toLowerCase());
    
    if (!isException) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * Find occurrences of a token only when it appears after a digit
 * and not at the start of the string.
 * Uses lookahead/lookbehind for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, capturing the whole thing
  // Use word boundaries to ensure we're matching complete tokens
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(regex);
  
  if (!matches) {
    return [];
  }
  
  return matches;
}

/**
 * Validate passwords according to strong password policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab", "123123")
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // We look for patterns of 2-4 characters that repeat
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const sequence = value.slice(i, i + len);
      const nextSequence = value.slice(i + len, i + len * 2);
      
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 * Returns true if the value contains an IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles:
  // - Full IPv6 addresses (8 groups of hex digits)
  // - Shorthand with :: (omitting consecutive zero groups)
  // - IPv4-mapped IPv6 addresses (::ffff:192.168.1.1)
  // - Excludes pure IPv4 addresses
  
  // First, check if it's NOT a pure IPv4 address
  // IPv4 pattern: xxx.xxx.xxx.xxx where xxx is 0-255
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // IPv6 pattern (comprehensive)
  // Matches:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1
  // - Loopback: ::1
  // - All interfaces: ::
  // - With embedded IPv4: ::ffff:192.168.1.1
  
  // Pattern breakdown:
  // - Allows 1-8 groups of hex digits (1-4 hex digits per group)
  // - Allows :: shorthand for consecutive zero groups
  // - Can include embedded IPv4 at the end

  // Check if the entire value is just an IPv4 address
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Simpler check for basic IPv6 patterns
  // Look for patterns like xxxx:xxxx:xxxx:xxxx or :: or x:x::x
  const basicIPv6Pattern = /([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4}|::|:[0-9a-fA-F]{1,4}:/;

  // Also check for ::1 (loopback) or :: (all interfaces)
  const specialIPv6 = /^::$|^::1$|s::1s|^::$|s::s/;

  if (basicIPv6Pattern.test(value) || specialIPv6.test(value)) {
    // Make sure it's not just a colon or something that looks like IPv6 but isn't
    // Must have at least one hex digit sequence
    if (/[0-9a-fA-F]+:[0-9a-fA-F]+/.test(value) || /::[0-9a-fA-F]*/.test(value)) {
      return true;
    }
  }

  return false;
}
