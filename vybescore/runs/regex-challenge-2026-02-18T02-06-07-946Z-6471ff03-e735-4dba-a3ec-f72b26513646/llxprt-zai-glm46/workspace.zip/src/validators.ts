export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to typical email format rules.
 * Accepts: standard email formats like user@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Accepts standard local part with letters, digits, dots, hyphens, plus
  // - Allows subdomains and multi-part TLDs
  // - Rejects double dots, trailing/leading dots
  // - Rejects underscores in domain
  // - Requires at least one dot in domain with valid TLD
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for invalid patterns
  const [localPart, domain] = value.split('@');
  
  // Check for consecutive dots
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Check for leading/trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Check for leading/trailing dots in domain parts
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-') || part.startsWith('.') || part.endsWith('.')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    // If no + but 11 digits, assume leading 1 is country code
    digits = digits.slice(1);
  }
  
  // Must have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep + and digits
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex breakdown:
  // ^\+? - Optional + (for country code)
  // (?:54)? - Optional country code 54
  // (?:0)? - Optional trunk prefix 0
  // (?:9)? - Optional mobile indicator 9
  // (\d{2,4}) - Area code: 2-4 digits
  // (\d{6,8})$ - Subscriber number: 6-8 digits
  const argentinaRegex = /^\+?(?:54)?(?:0)?(?:9)?(\d{2,4})(\d{6,8})$/;
  
  const match = cleaned.match(argentinaRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Area code must have leading digit 1-9 (not 0)
  if (areaCode[0] === '0') {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix 0 before area code
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  const hasTrunkPrefix = /(?:\+?54)?0/.test(cleaned);
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Verify subscriber number length
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Regex that allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, spaces
  // - At least 2 characters
  // - Cannot be empty or contain digits/symbols (except apostrophe, hyphen, space)
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value) || value.trim().length < 2) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for obviously invalid patterns like "X Æ A-12" (contains digits)
  // The digit check above catches this
  
  // Check that name contains at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Check for consecutive/leading/trailing invalid separators
  if (/[']{2,}/.test(value) || /-{2,}/.test(value) || /\s{2,}/.test(value)) {
    return false;
  }
  
  if (/^['\-\s]/.test(value) || /['\-\s]$/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to run Luhn checksum for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa (starts with 4, 13-16 digits), Mastercard (starts with 51-55, 16 digits),
 *          AmEx (starts with 34 or 37, 15 digits)
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-16 digits
  if (!/^\d{13,16}$/.test(cleaned)) {
    return false;
  }
  
  // Check card type and length
  const isVisa = /^4\d{12,15}$/.test(cleaned);
  const isMastercard = /^5[1-5]\d{14}$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
