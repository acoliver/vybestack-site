# Quick Reference - Regex Challenge Toolkit

## Validators

### `isValidEmail(value: string): boolean`
Validates email addresses according to standard format rules.

**Accepts:**
- `user@example.com`
- `user.name+tag@sub.example.co.uk`
- `first.last@domain.co.uk`

**Rejects:**
- `user..name@example.com` (double dots)
- `user@example_.com` (underscores in domain)
- `.user@example.com` (leading dot)
- `user@.com` (invalid domain)

### `isValidUSPhone(value: string): boolean`
Validates US phone numbers in various formats.

**Accepts:**
- `(212) 555-7890`
- `212-555-7890`
- `2125557890`
- `+1 212-555-7890`

**Rejects:**
- `012-555-7890` (area code starts with 0)
- `212-055-7890` (exchange starts with 0)
- `212555789` (too short)

### `isValidArgentinePhone(value: string): boolean`
Validates Argentine phone numbers including landlines and mobiles.

**Accepts:**
- `+54 9 11 1234 5678` (mobile with country code)
- `011 1234 5678` (Buenos Aires landline)
- `+54 341 123 4567` (Rosario)
- `0341 4234567` (without country code)

**Rejects:**
- Numbers without trunk prefix when country code omitted
- Invalid area codes starting with 0

### `isValidName(value: string): boolean`
Validates personal names with unicode support.

**Accepts:**
- `Jane Doe`
- `José María`
- `O'Brien`
- `Mary-Jane Smith`

**Rejects:**
- `X Æ A-12` (contains digits)
- `John123` (contains digits)
- `123` (no letters)
- `John--Doe` (consecutive hyphens)

### `isValidCreditCard(value: string): boolean`
Validates credit card numbers with Luhn checksum.

**Accepts:**
- `4111111111111111` (Visa)
- `5500000000000004` (Mastercard)
- `340000000000009` (American Express)

**Rejects:**
- Invalid card numbers (fails Luhn check)
- Wrong length for card type
- Invalid prefixes

## Text Transformations

### `capitalizeSentences(text: string): string`
Capitalizes the first letter of each sentence and normalizes spacing.

**Example:**
```typescript
capitalizeSentences('hello world. how are you?')
// Returns: 'Hello world. How are you?'
```

### `extractUrls(text: string): string[]`
Extracts all URLs from text, removing trailing punctuation.

**Example:**
```typescript
extractUrls('Visit http://example.com and https://test.org/page.')
// Returns: ['http://example.com', 'https://test.org/page']
```

### `enforceHttps(text: string): string`
Converts all HTTP URLs to HTTPS.

**Example:**
```typescript
enforceHttps('Visit http://example.com')
// Returns: 'Visit https://example.com'
```

### `rewriteDocsUrls(text: string): string`
Upgrades HTTP to HTTPS and rewrites docs URLs.

**Example:**
```typescript
rewriteDocsUrls('See http://example.com/docs/guide')
// Returns: 'See https://docs.example.com/docs/guide'

rewriteDocsUrls('See http://example.com/api/test')
// Returns: 'See https://example.com/api/test'

rewriteDocsUrls('See http://example.com/docs/file.php?id=1')
// Returns: 'See https://example.com/docs/file.php?id=1'
```

### `extractYear(value: string): string`
Extracts year from mm/dd/yyyy format.

**Example:**
```typescript
extractYear('01/31/2024')
// Returns: '2024'

extractYear('13/01/2024')
// Returns: 'N/A'

extractYear('not-a-date')
// Returns: 'N/A'
```

## Regex Puzzles

### `findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[]`
Finds words starting with a prefix, excluding exceptions.

**Example:**
```typescript
findPrefixedWords('preview prevent prefix', 'pre', ['prevent'])
// Returns: ['preview', 'prefix']
```

### `findEmbeddedToken(text: string, token: string): string[]`
Finds token occurrences only when preceded by a digit.

**Example:**
```typescript
findEmbeddedToken('xfoo 1foo foo', 'foo')
// Returns: ['1foo']
```

### `isStrongPassword(value: string): boolean`
Validates password strength requirements.

**Requirements:**
- At least 10 characters
- One uppercase letter
- One lowercase letter
- One digit
- One symbol
- No whitespace
- No immediate repeated sequences

**Accepts:**
- `Abcdef!234`
- `StrongPass123!`

**Rejects:**
- `weak` (too short)
- `abababc123!` (repeated sequence)
- `With Space123!` (contains whitespace)

### `containsIPv6(value: string): boolean`
Detects IPv6 addresses while excluding IPv4.

**Accepts:**
- `2001:db8::1`
- `::1` (loopback)
- `fe80::1`
- `2001:0db8:85a3:0000:0000:8a2e:0370:7334`

**Rejects:**
- `192.168.1.1` (IPv4 only)

## Usage

All functions are exported from their respective modules:

```typescript
import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './src/puzzles.js';
```

## Testing

Run the verification commands:

```bash
npm run lint          # ESLint
npm run typecheck     # TypeScript
npm run test:public   # Vitest tests
npm run build         # Compile
```

All commands should pass successfully.
