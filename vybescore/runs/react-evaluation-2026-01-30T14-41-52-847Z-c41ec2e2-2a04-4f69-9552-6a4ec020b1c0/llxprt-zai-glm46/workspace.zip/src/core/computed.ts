/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  // Return getter function
  const getter: GetterFn<T> = () => {
    // When accessed, register ourselves as a dependency if there's an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // This computed is being accessed by another observer
      const parentObserver = activeObserver as Observer<unknown>
      // Ensure the parent gets notified when this computed updates
      if (!o._dependents) {
        o._dependents = new Set<Observer<unknown>>()
      }
      o._dependents.add(parentObserver)
    }
    return o.value!
  }
  
  // Store observer reference on the getter
  ;(getter as GetterFn<T> & { _observer: Observer<T> })._observer = o
  
  return getter
}
