/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find words starting with the prefix
  // \b ensures we match whole words
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out any words that are in the exceptions list
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to find the token when it appears after a digit
  // but not at the start of the string
  // Match the digit with the token to include the digit in the match
  const pattern = new RegExp(`(?<!^)(\\d${escapedToken})`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check for minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (special character)
  // Define symbols as characters that are not alphanumeric
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This uses a backreference to detect repeated patterns
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses can be in various formats:
  // - Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Shortened form with :: (e.g., ::1, 2001:db8::1)
  // - Embedded IPv4: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xx.xx.xx.xx
  
  // First, let's make sure we're not matching an IPv4 address
  // IPv4 pattern: x.x.x.x where each x is 0-255
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false;
  }
  
  // IPv6 patterns
  // Full form: 8 groups of 4 hex digits
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Shortened form with :: (at least 2 groups on one side)
  const ipv6ShortPattern = /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // Embedded IPv4 pattern
  const ipv6EmbeddedPattern = /(?:[0-9a-fA-F]{1,4}:){5,7}(?:\d{1,3}\.){3}\d{1,3}/;
  
  return ipv6FullPattern.test(value) || ipv6ShortPattern.test(value) || ipv6EmbeddedPattern.test(value);
}
