/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces to a single space
  const collapsed = text.replace(/\s+/g, ' ');
  
  // Capitalize the first character of each sentence
  // A sentence ends with ., ?, or !
  // First, handle the beginning of the string
  const withFirstCapital = collapsed.replace(/^([a-z])/, (_, letter) => letter.toUpperCase());
  
  // Then, capitalize the first character of each sentence
  return withFirstCapital.replace(/([.!?]+)([\s]*)([a-z])/g, (match, punctuation, space, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches:
  // - http or https protocol
  // - domain with optional subdomains
  // - optional port
  // - path, query string, and fragment
  // - but not trailing punctuation like ., ), ", etc.
  const urlRegex = /(https?:\/\/[^\s/]+(?:\.[^\s/]+)+(?: \d+)?(?:\/[^\s)]*)?)/gi;
  
  // Find all matches, then clean them by removing trailing punctuation
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  return matches.map(url => {
    // Remove trailing punctuation like ., ), ", ', !, ?, etc.
    return url.replace(/[.,)'"!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Simple regex to replace http:// with https://
  // This will match http:// followed by domain and other parts
  return text.replace(/http:\/\/([^/])/g, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http URLs to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then, rewrite docs URLs for example.com specifically
  // Pattern: https://example.com/docs/... -> https://docs.example.com/...
  result = result.replace(
    /https:\/\/example\.com\/docs(\/.*)?/g,
    'https://docs.example.com/docs$1'
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  // m: 01-12
  // d: 01-31
  // y: 4 digits
  // This is a basic implementation, not handling month-specific day counts
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = dateRegex.exec(value);
  if (!match) {
    return 'N/A';
  }
  
  const month = match[1];
  const day = match[2];
  const year = match[3];
  
  // Validate day based on month (basic validation)
  switch (month) {
    case '02': // February - simplified, not handling leap years
      if (day > '29') return 'N/A';
      break;
    case '04': // April, June, September, November have 30 days
    case '06':
    case '09':
    case '11':
      if (day > '30') return 'N/A';
      break;
    // Other months have 31 days
  }
  
  return year;
}
