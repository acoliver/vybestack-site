export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validator regex that:
  // - Allows standard email format: local@domain.tld
  // - Accepts letters, numbers, dots, hyphens, underscores, plus in local part
  // - Accepts alphanumeric and hyphens in domain
  // - Allows 2-63 character TLD (including country codes like .co.uk)
  // - Rejects double dots, trailing dots, domains with underscores
  // - Requires at least one dot between domain and TLD
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks:
  // 1. No double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // 2. No trailing dot in local part before @
  const [localPart] = value.split('@');
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // 3. Domain part should not have underscores
  const domainPart = value.substring(value.indexOf('@') + 1);
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Clean the input: remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional country code +1
  let withoutCountry = cleaned;
  if (cleaned.startsWith('+1')) {
    withoutCountry = cleaned.substring(2);
  } else if (cleaned.startsWith('1')) {
    withoutCountry = cleaned.substring(1);
  }
  
  // Must be exactly 10 digits (area code + exchange + subscriber number)
  if (withoutCountry.length !== 10) {
    return false;
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = withoutCountry.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check exchange code doesn't start with 0 or 1
  const exchangeCode = withoutCountry.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Handle optional country code +54
  let withoutCountry = cleaned;
  if (cleaned.startsWith('54')) {
    withoutCountry = cleaned.substring(2); // Remove 54
  }
  
  // Handle optional trunk prefix 0
  let withoutTrunkPrefix = withoutCountry;
  if (withoutCountry.startsWith('0')) {
    withoutTrunkPrefix = withoutCountry.substring(1); // Remove 0
  }
  
  // Check if we have a mobile indicator 9
  let phoneNumber = withoutTrunkPrefix;
  if (withoutTrunkPrefix.startsWith('9')) {
    phoneNumber = withoutTrunkPrefix.substring(1); // Remove 9
  }
  
  // Now phoneNumber should have this format: areaCode + subscriberNumber
  // Where areaCode is 2-4 digits (leading digit 1-9)
  // And subscriberNumber is 6-8 digits
  
  // First, validate that we have at least 8 digits total (min 2-digit area code + 6-digit subscriber)
  if (phoneNumber.length < 8) {
    return false;
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCodeLength = 2;
  while (areaCodeLength < 5 && areaCodeLength < phoneNumber.length) {
    const potentialAreaCode = phoneNumber.substring(0, areaCodeLength);
    const firstDigit = potentialAreaCode[0];
    
    // The first digit must be 1-9
    if (firstDigit < '1' || firstDigit > '9') {
      return false;
    }
    
    // Try to detect the area code:
    // Try 4-digit area code first (if it would leave a valid subscriber number)
    if (areaCodeLength === 4 && phoneNumber.length - areaCodeLength >= 6 && phoneNumber.length - areaCodeLength <= 8) {
      break;
    }
    // Try 3-digit area code next (if it would leave a valid subscriber number)
    if (areaCodeLength === 3 && phoneNumber.length - areaCodeLength >= 6 && phoneNumber.length - areaCodeLength <= 8) {
      break;
    }
    // Default to 2-digit area code (if it would leave a valid subscriber number)
    if (areaCodeLength === 2 && phoneNumber.length - areaCodeLength >= 6 && phoneNumber.length - areaCodeLength <= 8) {
      break;
    }
    
    areaCodeLength++;
  }
  
  const areaCode = phoneNumber.substring(0, areaCodeLength);
  const subscriberNumber = phoneNumber.substring(areaCodeLength);
  
  // Validation checks
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Area code's first digit must be 1-9
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If country code was omitted, the number must begin with trunk prefix 0
  if (!cleaned.startsWith('54') && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex that:
  // - Allows unicode letters (including accented characters)
  // - Allows apostrophes and hyphens within names
  // - Allows spaces between name parts
  // - Rejects digits and symbols
  // - Must have at least one letter character
  
  // Use Unicode property escapes for international character support
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must match the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter character
  const containsLetter = /[\p{L}\p{M}]/u.test(value);
  if (!containsLetter) {
    return false;
  }
  
  // Cannot consist only of spaces, hyphens, or apostrophes
  const trimmed = value.replace(/[-'\s]/g, '');
  if (trimmed.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Start from the rightmost digit and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Check valid lengths for different card types:
  // Visa: 13 or 16 digits
  // Mastercard: 16 digits
  // AmEx: 15 digits
  
  // Visa: starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  if (visaRegex.test(cleanNumber)) {
    return runLuhnCheck(cleanNumber);
  }
  
  // Mastercard: starts with 51-55, or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  if (mastercardRegex.test(cleanNumber)) {
    return runLuhnCheck(cleanNumber);
  }
  
  // AmEx: starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleanNumber)) {
    return runLuhnCheck(cleanNumber);
  }
  
  return false;
}
