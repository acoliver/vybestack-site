/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  disposed?: boolean
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Observer<T = unknown> extends ObserverR, ObserverV<T> {
  observer?: ObserverR
}

export interface SubjectR {
  name?: string
  observer: ObserverR | undefined
}

export interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
}

export interface Subject<T> extends SubjectR, SubjectV<T> {}

let activeObserver: ObserverR | undefined

// Global set to track all computed observers
const computedObservers = new Set<Observer<unknown>>()

export function addComputedObserver<T>(observer: Observer<T>): void {
  computedObservers.add(observer)
}

export function removeComputedObserver<T>(observer: Observer<T>): void {
  computedObservers.delete(observer)
}

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Store subjects for global access
const subjects = new Set<Subject<unknown>>()

export function registerSubject<T>(subject: Subject<T>): void {
  subjects.add(subject)
}

export function getAllSubjects(): Subject<unknown>[] {
  return Array.from(subjects)
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip if observer is disposed
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer as ObserverR
  try {
    const oldValue = observer.value
    const result = observer.updateFn(oldValue)
    
    // Always update the value (even if unchanged) to trigger dependency updates
    observer.value = result
    
    // Notify parent observer synchronously
    if (observer.observer && !observer.observer.disposed) {
      updateObserver(observer.observer as Observer<T>)
    }
  } finally {
    activeObserver = previous
  }
}

// Create a function to notify all observers that depend on changed values
export function notifyAllDependentObservers(excludeObserver?: ObserverR): void {
  for (const observer of computedObservers) {
    if (observer !== excludeObserver && !observer.disposed) {
      updateObserver(observer)
    }
  }
}
