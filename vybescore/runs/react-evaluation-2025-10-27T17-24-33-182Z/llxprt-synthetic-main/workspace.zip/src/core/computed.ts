/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  registerSubject,
  addComputedObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
  }
  
  // Register as a computed observer
  addComputedObserver(observer)
  
  // Register as a subject for dependency tracking
  registerSubject(observer as Subject<unknown>)
  
  // Initial computation
  updateObserver(observer)
  
  // Getter function that tracks dependencies
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver && !currentObserver.disposed) {
      // If this computed is being accessed from another observer,
      // establish the dependency relationship
      observer.observer = currentObserver
    }
    return observer.value!
  }
  
  return getter
}