/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerSubject,
  notifyAllDependentObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (a: T, b: T) => a === b : () => false
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }
  
  // Register the subject
  registerSubject(s)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if values are different according to equality function
    if (s.equalFn && !s.equalFn(nextValue, s.value)) {
      s.value = nextValue
      
      // Notify the observer
      if (s.observer && !s.observer.disposed) {
        updateObserver(s.observer as Observer<T>)
      }
      
      // Notify all computed observers that may depend on this input
      notifyAllDependentObservers(s.observer)
    }
    return s.value
  }

  return [read, write]
}
