/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  registerSubject,
  Subject
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false,
  }
  
  // Register as a subject for dependency tracking
  registerSubject(observer as Subject<unknown>)
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}