/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64 strings.
 */
export function decode(input: string): string {
  // Basic validation: Base64 should only contain A-Z, a-z, 0-9, +, /, and optional padding =
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for proper padding if present
  const padLength = (input.match(/=/g) || []).length;
  if (padLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify that encoding the result back gives us the original input (with padding normalized)
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    
    // Remove padding from both to compare - the actual padding can vary
    const normalizedOriginal = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedOriginal !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: failed round-trip validation');
    }
    
    return result;
  } catch (error) {
    // Rethrow our validation errors
    if (error instanceof Error && error.message.startsWith('Invalid Base64 input')) {
      throw error;
    }
    
    // Catch any Buffer errors and provide a clearer message
    throw new Error('Invalid Base64 input: malformed or corrupt data');
  }
}
