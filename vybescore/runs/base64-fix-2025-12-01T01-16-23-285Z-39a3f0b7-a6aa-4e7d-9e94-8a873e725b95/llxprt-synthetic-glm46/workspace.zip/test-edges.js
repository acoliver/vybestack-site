/**
 * Simple edge case test runner
 */

import { decode, encode } from './src/base64.js';

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`[OK] ${name}`);
    passed++;
  } catch (e) {
    console.log(` ${name}`);
    console.error(`  Error: ${e.message}`);
    failed++;
  }
}

function assertEqual(actual, expected) {
  if (actual !== expected) {
    throw new Error(`Expected "${expected}", got "${actual}"`);
  }
}

function assertThrows(fn) {
  try {
    fn();
    throw new Error('Expected function to throw');
  } catch (e) {
    if (e.message === 'Expected function to throw') {
      throw e;
    }
    // Expected behavior
  }
}

console.log('Testing Base64 edge cases...\n');

test('handles empty strings', () => {
  assertEqual(encode(''), '');
  assertEqual(decode(''), '');
});

test('handles strings requiring padding', () => {
  // 1 byte - should end with "=="
  assertEqual(encode('a'), 'YQ==');
  assertEqual(decode('YQ=='), 'a');
  assertEqual(decode('YQ'), 'a'); // Also works without padding

  // 2 bytes - should end with "="
  assertEqual(encode('ab'), 'YWI=');
  assertEqual(decode('YWI='), 'ab');
  assertEqual(decode('YWI'), 'ab'); // Also works without padding

  // 3 bytes - no padding needed
  assertEqual(encode('abc'), 'YWJj');
  assertEqual(decode('YWJj'), 'abc');
});

test('rejects invalid padding', () => {
  // Padding in wrong position
  assertThrows(() => decode('Y=Q'));
  assertThrows(() => decode('YW=Jj'));
  assertThrows(() => decode('YWJ=j'));

  // Too much padding
  assertThrows(() => decode('YQ==='));
  
  // Non-multiple-of-4 padding without content
  assertThrows(() => decode('===='));
});

test('rejects invalid characters', () => {
  assertThrows(() => decode('$invalid!'));
  assertThrows(() => decode('YWJj$'));
  assertThrows(() => decode('YWJj!'));
  assertThrows(() => decode('YWJj@'));
  
  // URL-safe characters should be rejected
  assertThrows(() => decode('abc-xyz'));
  assertThrows(() => decode('abc_xyz'));
});

test('handles Unicode characters', () => {
  const unicode = '¡Hola, 世界! ';
  const encoded = encode(unicode);
  assertEqual(decode(encoded), unicode);
  
  // Test that round-trip preserves the exact content
  assertEqual(encode(decode(encoded)), encoded);
});

test('handles standard ASCII', () => {
  const ascii = 'Hello, World!';
  const encoded = encode(ascii);
  assertEqual(decode(encoded), ascii);
  assertEqual(encode(decode(encoded)), encoded);
});

console.log(`\nTest results: ${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);