import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
      </section>
    );
  }

  const isFirstPage = currentPage === 1;
  const hasNext = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
        <button 
          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
          disabled={isFirstPage}
          type="button"
        >
          Previous
        </button>
        <span>Page {data.page} of {Math.ceil(data.total / PAGE_LIMIT)}</span>
        <button 
          onClick={() => setCurrentPage(prev => prev + 1)}
          disabled={!hasNext}
          type="button"
        >
          Next
        </button>
      </div>
      <p style={{ marginTop: '1rem', color: '#666' }}>
        Showing {data.items.length} of {data.total} items
      </p>
    </section>
  );
}
