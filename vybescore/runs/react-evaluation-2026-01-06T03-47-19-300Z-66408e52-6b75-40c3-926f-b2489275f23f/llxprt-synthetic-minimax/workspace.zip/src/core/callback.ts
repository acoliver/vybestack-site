/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  getActiveObserver,
  trackObserver,
  UpdateFn 
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  const observer: Observer<unknown> = {
    name: undefined,
    disposed: false,
    value: _value,
    updateFn: updateFn as UpdateFn<unknown>,
    subscribers: new Set()
  }
  
  let disposed = false

  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    observer.disposed = true
  }

  // Track this callback as a dependent observer
  const current = getActiveObserver()
  if (current && !current.disposed && current.subscribers) {
    current.subscribers.add(observer)
    trackObserver(observer)
  }
  
  return unsubscribe
}
