/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  EqualFn
} from '../types/reactive.js'

// Import tracking functions from input.ts
import { 
  getCurrentTrackingFn, 
  setCurrentTrackingFn, 
  subscribe, 
  notify 
} from './input.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: () => T,
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let computedValue: T | undefined

  const recompute = () => {
    // Set up tracking during recomputation
    const trackingFn = () => {
      // This function gets called when dependencies change
      recompute()
      notify(getter)
    }
    setCurrentTrackingFn(trackingFn)
    
    try {
      computedValue = updateFn()
    } finally {
      setCurrentTrackingFn(undefined)
    }
  }

  const getter: GetterFn<T> = () => {
    // Track dependencies when getter is called
    const trackingFn = getCurrentTrackingFn()
    if (trackingFn) {
      subscribe(getter, trackingFn)
    }
    
    // Recompute if no cached value
    if (computedValue === undefined) {
      recompute()
    }
    
    return computedValue as T
  }

  return getter
}
