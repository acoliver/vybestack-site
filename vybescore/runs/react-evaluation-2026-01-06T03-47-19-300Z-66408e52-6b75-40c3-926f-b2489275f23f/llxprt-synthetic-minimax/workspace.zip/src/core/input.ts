/**
 * Input closure implementation for reactive primitives.
 */

import type {
  EqualFn,
  GetterFn,
  SetterFn,
  InputPair,
  UnsubscribeFn
} from '../types/reactive.js'

// Global reactive tracking state
let currentTrackingFn: (() => void) | undefined = undefined
const subscribers = new Map<() => unknown, Set<() => void>>()

export function getCurrentTrackingFn(): (() => void) | undefined {
  return currentTrackingFn
}

export function setCurrentTrackingFn(fn: (() => void) | undefined): void {
  currentTrackingFn = fn
}

export function subscribe(getter: () => unknown, callback: () => void): void {
  let subs = subscribers.get(getter)
  if (!subs) {
    subs = new Set()
    subscribers.set(getter, subs)
  }
  subs.add(callback)
}

export function notify(getter: () => unknown): void {
  const subs = subscribers.get(getter)
  if (subs) {
    for (const callback of [...subs]) {
      callback()
    }
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): InputPair<T> {
  let currentValue = value
  
  const read: GetterFn<T> = () => {
    // Track this getter as a dependency when there's an active tracking
    const trackingFn = getCurrentTrackingFn()
    if (trackingFn) {
      subscribe(read, trackingFn)
    }
    return currentValue
  }

  const write: SetterFn<T> = (newValue) => {
    const oldValue = currentValue
    currentValue = newValue
    // Always notify when setter is called to trigger reactive updates
    if (oldValue !== newValue) {
      notify(read)
    }
    return currentValue
  }

  return [read, write]
}

export function createCallback<T>(
  updateFn: () => T,
  _value?: T
): UnsubscribeFn {
  let disposed = false

  // Create a callback that executes the update function and tracks dependencies
  const executeAndTrack = () => {
    if (disposed) return
    
    // Set up tracking during callback execution to establish dependencies
    const trackingFn = () => {
      if (!disposed) {
        updateFn()
      }
    }
    
    setCurrentTrackingFn(trackingFn)
    try {
      updateFn()  // Execute to establish dependencies
    } finally {
      setCurrentTrackingFn(undefined)
    }
  }

  // Execute immediately to establish initial dependencies
  executeAndTrack()

  const unsubscribe = () => {
    if (disposed) return
    disposed = true
  }

  return unsubscribe
}
