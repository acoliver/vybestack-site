/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: updateFn as (value?: T) => T,
    observers: new Set(),
    dependencies: new Set()
  }
  
  // Register observer to track dependencies and run initial effect
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up dependencies
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        if (subject.observers) {
          subject.observers.delete(observer)
        }
      })
      observer.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
