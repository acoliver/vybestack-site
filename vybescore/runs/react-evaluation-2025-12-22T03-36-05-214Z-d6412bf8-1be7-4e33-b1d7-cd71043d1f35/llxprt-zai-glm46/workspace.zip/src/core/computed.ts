/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: updateFn as (value?: T) => T,
    observers: new Set(),
    dependencies: new Set()
  }
  
  // Initial computation only if we don't have a provided initial value
  if (value === undefined) {
    updateObserver(o)
  }
  
  const getter: GetterFn<T> = (): T => {
    const currentActiveObserver = getActiveObserver()
    if (currentActiveObserver === o) {
      // We're already computing this value, avoid infinite recursion
      return o.value!
    }
    
    // Register this computed as a dependency of the current observer
    if (currentActiveObserver) {
      if (!currentActiveObserver.dependencies) {
        currentActiveObserver.dependencies = new Set()
      }
      
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(currentActiveObserver as Observer<unknown>)
      // Type cast to satisfy the type system - computed values act as subjects for their dependencies
      currentActiveObserver.dependencies.add(o as unknown as Subject<unknown>)
    }
    
    // Only recompute when accessed if within another observer
    if (currentActiveObserver) {
      updateObserver(o)
    }
    
    return o.value!
  }
  
  // Make this observable by inputs
  ;(getter as GetterFn<T> & { observer: Observer<T> }).observer = o
  
  return getter
}
