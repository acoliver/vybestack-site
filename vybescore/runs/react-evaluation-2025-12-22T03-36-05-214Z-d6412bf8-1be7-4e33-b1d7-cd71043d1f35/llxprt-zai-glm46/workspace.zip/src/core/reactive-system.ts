/**
 * Reactive system utilities for updating the reactive graph
 */

import { Observer, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Recursively updates observers in the reactive graph
 */
export function updateReactiveGraph(root: Observer<unknown>): void {
  const updated = new Set<Observer<unknown>>()
  const queue: Observer<unknown>[] = [root]
  
  while (queue.length > 0) {
    const observer = queue.shift()!
    if (updated.has(observer)) continue
    
    updated.add(observer)
    
    // Update this observer's value
    if (observer.updateFn) {
      try {
        const previous = getActiveObserver()
        setActiveObserver(observer)
        try {
          const previousValue = observer.value
          // Type cast to allow updateFn with unknown type
          const updateFn = observer.updateFn as (value?: unknown) => unknown
          observer.value = updateFn(previousValue)
        } finally {
          setActiveObserver(previous)
        }
      } catch (e) {
        // Ignore errors during observer updates
      }
    }
    
    // Add all observers of this observer to the queue
    if (observer.observers) {
      observer.observers.forEach(obs => {
        if (!updated.has(obs)) {
          queue.push(obs)
        }
      })
    }
  }
}