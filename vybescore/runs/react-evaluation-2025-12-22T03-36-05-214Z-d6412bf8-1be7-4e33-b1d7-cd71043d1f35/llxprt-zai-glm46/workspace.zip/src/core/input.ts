/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Observer
} from '../types/reactive.js'

import { updateReactiveGraph } from './reactive-system.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Link this observer to this input for automatic updates
      if (!s.observers) {
        s.observers = new Set()
      }
      s.observers.add(observer)
      
      // Track dependencies for the observer
      if (observer.dependencies) {
        observer.dependencies.add(s as Subject<unknown>)
      } else {
        observer.dependencies = new Set([s as Subject<unknown>])
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    const isEqual = typeof _equal === 'function' 
      ? _equal(s.value, nextValue)
      : typeof _equal === 'boolean'
      ? _equal ? s.value === nextValue : false
      : s.value === nextValue
    
    if (!isEqual) {
      s.value = nextValue
      
      // Notify all observers by triggering their update functions
      if (s.observers) {
        const observersCopy = Array.from(s.observers)
        observersCopy.forEach(observer => {
          try {
            // Update the observer using updateObserver
            if ('updateFn' in observer) {
              updateReactiveGraph(observer as Observer<unknown>)
            }
          } catch (e) {
            console.log('Error updating observer:', e)
            // Ignore errors during observer updates
          }
        })
      }
    }
    return s.value
  }

  return [read, write]
}
