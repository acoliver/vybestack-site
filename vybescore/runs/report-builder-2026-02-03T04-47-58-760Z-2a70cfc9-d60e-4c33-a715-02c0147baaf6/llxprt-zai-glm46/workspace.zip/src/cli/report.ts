#!/usr/bin/env node

import * as fs from 'node:fs';
import type { Format, ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<Format, (data: ReportData, options: RenderOptions) => string> = {
  markdown: (data, options) => renderMarkdown.render(data, options),
  text: (data, options) => renderText.render(data, options),
};

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: 'markdown',
    outputPath: null,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      result.format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      if (result.inputFile) {
        throw new Error(`Unexpected argument: ${arg}`);
      }
      result.inputFile = arg;
    }
    i++;
  }

  if (!result.inputFile) {
    throw new Error('Input file is required');
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${i} missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${i} missing or invalid "amount" field (expected number)`
      );
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>,
  };
}

function loadJsonFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(content);
    return validateReportData(parsed);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON: ${error.message}`);
    }
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));
    const data = loadJsonFile(args.inputFile);

    const formatter = formatters[args.format];
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
