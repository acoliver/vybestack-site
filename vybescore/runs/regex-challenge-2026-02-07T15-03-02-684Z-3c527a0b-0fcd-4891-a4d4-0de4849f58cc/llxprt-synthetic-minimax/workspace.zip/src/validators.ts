export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove surrounding whitespace
  const trimmed = value.trim();
  
  // Check for obviously invalid patterns first
  // Reject double dots, trailing dots, domains with underscores
  if (trimmed.includes('..') || 
      trimmed.endsWith('.') || 
      trimmed.includes('_@') ||
      trimmed.startsWith('@') || 
      trimmed.endsWith('@')) {
    return false;
  }
  
  // Pattern to match typical email format:
  // - local part before @ can contain letters, numbers, dots, underscores, plus signs, hyphens
  // - domain part with subdomains allowed (like tag@example.co.uk)
  // - TLD (top-level domain) of 2+ letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*@([a-zA-Z0-9][a-zA-Z0-9-]*\.)*[a-zA-Z0-9]+\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(trimmed);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except the leading +
  const clean = value.trim();
  
  // Pattern for US phone numbers:
  // Optional country code: +1 or 1 (with or without +)
  // Area code (cannot start with 0 or 1): [2-9]xx
  // Central office code (cannot start with 0 or 1): [2-9]xx
  // Line number: xxxx
  // Support various separators: ()- spaces, hyphens, or concatenated
  const phoneRegex = /^(?:\+?1[\s.-]?)?(?:\([2-9][0-9][0-9]\)|[2-9][0-9][0-9])[\s.-]?[2-9][0-9][0-9][\s.-]?[0-9]{4}$/;
  
  const isValid = phoneRegex.test(clean);
  
  // Check allowExtensions option if provided
  if (options?.allowExtensions) {
    // For now, extensions validation is the same as standard validation
    // This could be extended in the future
    return isValid;
  }
  
  return isValid;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens, keep digits and +
  const clean = value.replace(/[\s.-]/g, '');
  
  // Argentine phone patterns:
  // 1. +54 9 11 1234 5678 -> +549112345678 (mobile with country)
  // 2. +54 341 123 4567 -> +543411234567 (landline with country)
  // 3. 011 1234 5678 -> 01112345678 (landline with trunk)
  // 4. 0341 4234567 -> 03414234567 (landline with trunk)
  
  const patterns = [
    // Mobile with country code: +54911... where 911 is area+subscriber
    /^\+54(9[1-9][0-9]{1,3}|[1-9][0-9]{1,3})[0-9]{6,8}$/,
    // Without country code: 011... or 0341... (must start with 0)
    /^0[1-9][0-9]{1,3}[0-9]{6,8}$/
  ];
  
  return patterns.some(pattern => pattern.test(clean));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Check if name is too short (less than 2 characters)
  if (trimmed.length < 2) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  // Pattern explanation:
  // ^(?=.{2,}$) - At least 2 characters total
  // [^\d\s] - First character cannot be digit or space  
  // [^\d]* - Remaining characters cannot be digits
  // Allow letters (including unicode), spaces, apostrophes, hyphens
  // Exclude symbols and numbered names
  const nameRegex = /^(?=.{2,}$)[^\d\s][^\d]*$/;
  
  // Additional check: reject names with patterns like "X Æ A-12"
  const rejectPattern = /[0-9]/;
  
  return nameRegex.test(trimmed) && !rejectPattern.test(trimmed);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have at least some digits
  if (digitsOnly.length < 13) return false;
  
  // Check for valid card types and their lengths
  // Visa: 4 followed by 12-18 more digits (16 total)
  // Mastercard: 51-55 followed by 14 more digits (16 total)  
  // AmEx: 34 or 37 followed by 13 more digits (15 total)
  const visaPattern = /^4[0-9]{12}$|^4[0-9]{15}$|^4[0-9]{18}$/;
  const mastercardPattern = /^5[1-5][0-9]{14}$/;
  const amexPattern = /^3[47][0-9]{13}$|^3[47][0-9]{17}$/;
  
  // Check if it matches any valid card pattern
  if (!visaPattern.test(digitsOnly) && !mastercardPattern.test(digitsOnly) && !amexPattern.test(digitsOnly)) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to run the Luhn checksum algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
