/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Split text into words and filter based on prefix and exceptions
  const words = text.split(/\s+/);
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefixPattern = new RegExp(`^${escapedPrefix}`, 'i');
  
  return words.filter(word => {
    // Check if word starts with prefix (case insensitive)
    if (!prefixPattern.test(word)) return false;
    
    // Check if word is in exceptions (case insensitive)
    const isException = exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
    
    return !isException;
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to find tokens that follow digits
  // The pattern captures tokens that follow digits
  const additionalPattern = new RegExp(`\\d${escapedToken}`, 'gi');
  const directMatches = text.match(additionalPattern) || [];
  
  return directMatches;
}



/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check no whitespace
  if (/\s/.test(value)) return false;
  
  // Check one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab"
  // This pattern looks for repeated 2+ character sequences
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  const trimmed = value.trim();
  
  // Check if value contains pure IPv4 pattern (exclude pure IPv4)
  const ipv4Pattern = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  
  // If it's pure IPv4, return false
  if (ipv4Pattern.test(trimmed)) {
    return false;
  }
  
  // Check for IPv6 address anywhere in the text (not just full matches)
  // IPv6 shorthand patterns including :: compression
  const ipv6Patterns = [
    // Standard full IPv6
    /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/,
    
    // IPv6 with :: shorthand (anywhere)
    /[0-9a-fA-F]{0,4}::[0-9a-fA-F]{0,4}/,
    
    // Shorthand at beginning
    /::[0-9a-fA-F]{1,4}/,
    
    // Shorthand at end
    /[0-9a-fA-F]{1,4}::/,
    
    // General IPv6 with compression
    /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}/,
    
    // IPv6 embedded in text (partial matches)
    /[0-9a-fA-F]{1,4}:/,
    /:[0-9a-fA-F]{1,4}/,
    /::/
  ];
  
  // Test against all patterns
  return ipv6Patterns.some(pattern => pattern.test(trimmed));
}
