/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split into sentences using punctuation followed by space/newline
  // This regex looks for sentence endings followed by whitespace
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  // Capitalize each sentence and collapse extra spaces
  const capitalized = sentences.map(sentence => {
    // Trim extra spaces and capitalize first letter
    const trimmed = sentence.trim();
    if (!trimmed) return '';
    
    // Capitalize first letter and make rest lowercase
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
  });
  
  // Join sentences with exactly one space
  return capitalized.join(' ').replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern matching http/https URLs
  // Match the scheme and domain, but stop at sentence punctuation or space
  const urlRegex = /https?:\/\/[^\s.,;:!?]+(?:\.[^\s.,;:!?]+)*/gi;
  
  const matches = text.match(urlRegex);
  
  // Return array of found URLs (or empty array if none found)
  return matches || [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but don't touch existing https://
  const httpRegex = /http:\/\//gi;
  
  return text.replace(httpRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs and capture the host and path
  const urlPattern = /http:\/\/([^/\s]+)([^?\s]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Check if path begins with /docs/
    const beginsWithDocs = path.startsWith('/docs/');
    
    // Check for dynamic hints or legacy extensions that should skip host rewrite
    const hasDynamicHints = /cgi-bin|[?&]=|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i.test(path);
    
    // If path begins with /docs/ and doesn't have dynamic hints, rewrite host
    let newUrl = 'https://';
    
    if (beginsWithDocs && !hasDynamicHints) {
      // Replace host with docs.hostname format
      newUrl += 'docs.' + host;
    } else {
      // Keep original host but upgrade scheme
      newUrl += host;
    }
    
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.trim().match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, check specific days for each month)
  const daysInMonth = [
    31, // January
    year % 4 === 0 ? 29 : 28, // February (leap year check)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return match[3]; // Return the year as string
}
