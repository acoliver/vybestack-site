/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Create a regex pattern to match words starting with prefix
  // Use word boundaries to match whole words only
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  const result = matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
  
  // Remove duplicates while preserving order
  const seen = new Set<string>();
  const uniqueResult = result.filter(word => {
    const lowerWord = word.toLowerCase();
    if (seen.has(lowerWord)) {
      return false;
    }
    seen.add(lowerWord);
    return true;
  });
  
  return uniqueResult;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences where token appears after a digit
  // Pattern: digit followed immediately by the token
  const fullPattern = new RegExp(`\\d${escapedToken}`, 'gi');
  const fullMatches = text.match(fullPattern) || [];
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // Pattern: any 2-character sequence repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    const twoChars = value.substring(i, i + 2);
    const nextTwoChars = value.substring(i + 2, i + 4);
    if (twoChars === nextTwoChars) {
      return false;
    }
  }
  
  // Check for longer patterns like "abcabc"
  for (let i = 0; i < value.length - 5; i++) {
    const threeChars = value.substring(i, i + 3);
    const nextThreeChars = value.substring(i + 3, i + 6);
    if (threeChars === nextThreeChars) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // First, exclude pure IPv4 addresses to prevent false positives
  // IPv4 pattern: 4 numbers separated by dots, each 0-255
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If the entire string is an IPv4 address, it's not IPv6
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns to match (both full matches and embedded matches)
  const ipv6Patterns = [
    // Standard full IPv6: 8 groups of 4 hex digits
    /^(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}$/,
    
    // IPv6 with :: (compressed notation) - full match
    /^(?:[a-fA-F0-9]{1,4}:)*::(?:[a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{1,4}$/,
    
    // IPv6 starting with :: - full match
    /^::(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}$/,
    
    // IPv6 ending with :: - full match
    /^(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}::$/,
    
    // IPv6 with :: in middle - full match
    /^(?:[a-fA-F0-9]{1,4}:)+::(?:[a-fA-F0-9]{1,4}:)+[a-fA-F0-9]{1,4}$/,
    
    // More flexible IPv6 with varying groups - full match
    /^(?:[a-fA-F0-9]{1,4}:)+(?::[a-fA-F0-9]{1,4})+$/,
    
    // Embedded IPv6 patterns (not anchored to start/end)
    /[a-fA-F0-9]{1,4}::[a-fA-F0-9]{1,4}/, // Basic :: compression
    /::[a-fA-F0-9]{1,4}/, // Starting with ::
    /[a-fA-F0-9]{1,4}::$/, // Ending with ::
    /(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}/ // Multiple groups
  ];
  
  const trimmedValue = value.trim();
  
  // Check if any IPv6 pattern matches (full matches)
  for (const pattern of ipv6Patterns.slice(0, 6)) {
    if (pattern.test(trimmedValue)) {
      return true;
    }
  }
  
  // Check embedded patterns for IPv6 addresses within text
  for (const pattern of ipv6Patterns.slice(6)) {
    if (pattern.test(value)) {
      // Verify it's not just part of a larger invalid pattern
      const match = value.match(pattern);
      if (match) {
        const ipSegment = match[0];
        // Simple validation: must have colons and valid hex chars
        if (ipSegment.includes(':') && /^[a-fA-F0-9:]+$/.test(ipSegment)) {
          return true;
        }
      }
    }
  }
  
  return false;
}