/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Normalize whitespace - collapse multiple spaces to single, handle newlines
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Handle paragraphs by processing each separately if there are double newlines
  if (text.includes('\n\n')) {
    const paragraphs = text.split(/\n\s*\n/);
    const processed = paragraphs.map(p => capitalizeSentences(p.trim())).filter(p => p.length > 0);
    return processed.join('\n\n');
  }
  
  // Split into potential sentences, but preserve the ending punctuation
  // Use regex to find sentence endings and split accordingly
  const sentencePattern = /([.!?]+)(?:\s+|$)/g;
  let match;
  let lastIndex = 0;
  const sentences: string[] = [];
  
  while ((match = sentencePattern.exec(normalized)) !== null) {
    const sentenceEnd = match[0];
    const sentenceStart = lastIndex;
    const sentenceEndIndex = match.index + sentenceEnd.length;
    
    // Extract the sentence including its ending punctuation
    const sentence = normalized.slice(sentenceStart, sentenceEndIndex);
    if (sentence.trim()) {
      sentences.push(sentence);
    }
    
    lastIndex = sentenceEndIndex;
  }
  
  // Handle remaining text after last sentence
  if (lastIndex < normalized.length) {
    const remaining = normalized.slice(lastIndex);
    if (remaining.trim()) {
      sentences.push(remaining);
    }
  }
  
  // If no sentence endings found, treat entire text as one sentence
  if (sentences.length === 0) {
    sentences.push(normalized);
  }
  
  // Capitalize each sentence
  const capitalizedSentences = sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';
    
    // Find the first letter and capitalize it
    const firstLetterMatch = trimmed.match(/[a-zA-Z]/);
    if (!firstLetterMatch) return trimmed; // No letters to capitalize
    
    const firstLetterIndex = firstLetterMatch.index!;
    const before = trimmed.slice(0, firstLetterIndex);
    const letter = trimmed.charAt(firstLetterIndex).toUpperCase();
    const after = trimmed.slice(firstLetterIndex + 1);
    
    return before + letter + after;
  });
  
  // Join sentences with exactly one space
  return capitalizedSentences.filter(s => s.length > 0).join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || text.length === 0) {
    return [];
  }
  
  // Enhanced URL regex that matches http://, https://, and www. URLs
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'(){}[\]\\^`|<>]*[^\s<>"'(){}[\]\\^`|,.!?]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up the matches - remove trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that might be sentence endings
    let cleaned = url.replace(/[.,!?;]+$/g, '');
    
    // If it's a www. URL without protocol, add http://
    if (cleaned.startsWith('www.')) {
      cleaned = 'http://' + cleaned;
    }
    
    return cleaned;
  });
  
  return [...new Set(cleanUrls)]; // Remove duplicates
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Replace http:// with https://, but only when it's actually http://
  // Don't touch https:// or other protocols
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Pattern to match http:// URLs with path
  const httpUrlPattern = /http:\/\/([a-zA-Z0-9.-]+)([^\s]*)/g;
  
  return text.replace(httpUrlPattern, (match, domain, path) => {
    // Always upgrade scheme to https
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints (should skip host rewrite)
    const hasDynamicHints = /[?&]|(?:\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path + match.split('?')[1] || '');
    const hasCgiBin = /\/cgi-bin\//i.test(path);
    
    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasCgiBin) {
      newUrl += 'docs.' + domain + path;
    } else {
      newUrl += domain + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format with valid ranges
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (simple validation)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  // Validate year format (4 digits)
  if (!/^\d{4}$/.test(year)) {
    return 'N/A';
  }
  
  return year;
}