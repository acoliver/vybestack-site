export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with proper constraints
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for double dots in local part
  if (value.includes('..')) {
    return false;
  }

  // Split and validate local and domain parts
  const [local, domain] = value.split('@');
  
  // Local part cannot start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }

  // Domain cannot start or end with dot
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }

  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Check for consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }

  // Domain must have at least one dot
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }

  // Each domain part must have valid characters
  for (const part of domainParts) {
    if (part.length === 0) {
      return false;
    }
    if (!/^[a-zA-Z0-9-]+$/.test(part)) {
      return false;
    }
    // Domain parts cannot start or end with hyphen
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Options parameter reserved for future extensions
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  void _options;
  
  // Remove all non-digit characters except + at the start
  let cleaned = value.trim();
  
  // Check if it starts with +1 and remove it
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2).trim();
  }
  
  // Remove all non-digit characters
  cleaned = cleaned.replace(/\D/g, '');
  
  // Must be exactly 10 digits
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1 (NPA rules)
  const areaCode = cleaned.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Original format validation
  const phoneRegex = /^(?:\+?1[\s.-]?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Check for valid characters (digits, +, spaces, hyphens only)
  if (!/^[+\d\s-]+$/.test(value)) {
    return false;
  }
  
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // If no country code, must start with trunk prefix (0)
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Check for area code and subscriber number pattern
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const phoneRegex = /^(?:\+54)?0?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Total number validation
  // Format: [+54][0][9][area_code][subscriber]
  // Minimum: 8 digits, Maximum: 15 digits
  if (cleaned.length < 8 || cleaned.length > 15) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value.trim()) {
    return false;
  }
  
  // Check for obviously bad patterns
  if (/[0-9]/.test(value)) {
    return false; // No digits allowed
  }
  
  // Reject weird symbols and special characters
  if (/[@#$%^&*()+=[\]{}|\\:";'<>?/~`]/.test(value)) {
    return false; // No typical symbols
  }
  
  // Allow: letters (unicode), accents, apostrophes, hyphens, spaces
  const namePattern = /^[\p{L}\p{M}\s'\-–—]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must have at least one actual letter (not just spaces/symbols)
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Should not start or end with apostrophes or hyphens
  if (/^['\-–—]|[''\-–—]$/.test(value)) {
    return false;
  }
  
  // Check for consecutive special characters (like -- or '' or multiple spaces)
  if (/(['\-–—])\1/.test(value) || /\s{3,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to validate credit card number using Luhn algorithm
 */
function validateLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return (sum % 10) === 0;
}

/**
 * Check if card number matches Visa/Mastercard/AmEx prefixes and lengths
 */
function isValidCardFormat(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\s|-/g, '');
  
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Visa: starts with 4, 13 or 16 digits
  if (/^4\d{12}(\d{3})?(\d{3})?$/.test(digits)) {
    return digits.length === 13 || digits.length === 16;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  if ((/^5[1-5]\d{14}$/.test(digits)) || (/^2[2-7]\d{13}$/.test(digits))) {
    return digits.length === 16;
  }
  
  // American Express: starts with 34 or 37, 15 digits
  if (/^3[47]\d{13}$/.test(digits)) {
    return digits.length === 15;
  }
  
  return false;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check basic format first
  if (!isValidCardFormat(value)) {
    return false;
  }
  
  // Then check Luhn checksum
  return validateLuhnCheck(value);
}