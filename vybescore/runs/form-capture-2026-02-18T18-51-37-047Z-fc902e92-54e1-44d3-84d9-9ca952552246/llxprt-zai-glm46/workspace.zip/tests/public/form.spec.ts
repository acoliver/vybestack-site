import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer, Server } from 'node:http';
import app from '../../src/server.ts';

let server: Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Create a test server
  server = createServer(app);
  
  await new Promise<void>((resolve) => {
    server.listen(0, () => {
      resolve();
    });
  });
});

afterAll(() => {
  if (server) {
    server.close();
  }
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check all form fields exist
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('shows validation errors for empty fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('First name is required');
    expect(errorText).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'not-an-email',
        phone: '+1 555-123-4567',
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('valid email address');
  });

  it('accepts international phone formats', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 High St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
  });

  it('accepts Argentine postal code format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'García',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
  });

  it('persists submission and redirects', async () => {
    // Ensure database doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test Ave',
      city: 'Testville',
      stateProvince: 'TX',
      postalCode: '75001',
      country: 'USA',
      email: 'test@example.com',
      phone: '+1 (555) 987-6543',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    
    // Check database file was created
    // Give it a moment to write to disk
    await new Promise(resolve => setTimeout(resolve, 100));
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank you page', async () => {
    const response = await request(app)
      .get('/thank-you?firstName=Alice');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Alice');
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('stranger on the internet');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Invalid',
        lastName: 'Email',
        streetAddress: '123 St',
        city: 'City',
        stateProvince: 'ST',
        postalCode: '12345',
        country: 'USA',
        email: 'bad-email',
        phone: '+1 555-1234',
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('Invalid');
    expect($('input[name="lastName"]').val()).toBe('Email');
  });
});
