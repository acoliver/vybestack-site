import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;
let dbInitPromise: Promise<void> | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// When compiled, __dirname will be dist/, so we need to look in ../public
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
// When compiled, __dirname will be dist/, so we need to look in ../src/templates
app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

// Ensure database is initialized
function ensureDatabaseInitialized(): Promise<void> {
  if (db) {
    return Promise.resolve();
  }
  if (dbInitPromise) {
    return dbInitPromise;
  }
  dbInitPromise = initializeDatabase();
  return dbInitPromise;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?\d[\d\s()-]*\d$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces and hyphens
  const postalRegex = /^[A-Z0-9][A-Z0-9\s-]*[A-Z0-9]$/i;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateFormData(data: FormData): ValidationResult {
  const errors: string[] = [];

  if (!validateRequired(data.firstName)) {
    errors.push('First name is required');
  }
  if (!validateRequired(data.lastName)) {
    errors.push('Last name is required');
  }
  if (!validateRequired(data.streetAddress)) {
    errors.push('Street address is required');
  }
  if (!validateRequired(data.city)) {
    errors.push('City is required');
  }
  if (!validateRequired(data.stateProvince)) {
    errors.push('State / Province / Region is required');
  }
  if (!validateRequired(data.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain at least 3 characters (letters, numbers, spaces, and hyphens allowed)');
  }
  if (!validateRequired(data.country)) {
    errors.push('Country is required');
  }
  if (!validateRequired(data.email)) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Email must be a valid email address');
  }
  if (!validateRequired(data.phone)) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain at least 7 digits (can include +, spaces, parentheses, and dashes)');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  // Try to load existing database, or create new one
  let dbData: Uint8Array | undefined;
  try {
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      dbData = new Uint8Array(buffer);
    }
  } catch (err) {
    // File doesn't exist yet, will create new database
  }

  db = new SQL.Database(dbData);

  // Check if we need to initialize schema
  const schemaExists = db.exec('SELECT name FROM sqlite_master WHERE type="table" AND name="submissions"');
  
  if (schemaExists.length === 0) {
    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;

  const data = db.export();
  const buffer = Buffer.from(data);
  
  const dir = path.dirname(DB_PATH);
  
  // Ensure directory exists
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

// Routes
app.get('/', async (req: Request, res: Response) => {
  await ensureDatabaseInitialized();
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  await ensureDatabaseInitialized();
  
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );

    // Save database to disk
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', async (req: Request, res: Response) => {
  await ensureDatabaseInitialized();
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Error handler
app.use((err: Error, req: Request, res: Response) => {
  console.error('Error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {},
  });
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  const server = app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down server...');
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server shut down gracefully');
      process.exit(0);
    });

    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

// Export for testing
export default app;
export { startServer };
