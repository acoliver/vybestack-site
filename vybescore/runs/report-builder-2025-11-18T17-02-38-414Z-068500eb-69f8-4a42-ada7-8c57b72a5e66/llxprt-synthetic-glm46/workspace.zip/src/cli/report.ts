#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

function parseArguments(): { dataFile: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('Missing format value after --format');
        }
        format = args[i + 1];
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('Missing output path after --output');
        }
        outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (args[i].startsWith('-')) {
          throw new Error(`Unknown argument: ${args[i]}`);
        }
    }
  }
  
  if (!format) {
    throw new Error('Missing required --format argument');
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }
  
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: expected object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid "label" field');
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error('Invalid entry: missing or invalid "amount" field');
    }
  }
  
  return data as ReportData;
}

function main() {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments();
    
    let dataContent: string;
    try {
      dataContent = readFileSync(dataFile, 'utf-8');
    } catch (error) {
      throw new Error(`Failed to read file: ${dataFile}`);
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(dataContent);
    } catch (error) {
      throw new Error(`Invalid JSON in file: ${dataFile}`);
    }
    
    const reportData = validateReportData(jsonData);
    
    const options = { includeTotals };
    let output: string;
    
    switch (format) {
      case 'markdown':
        output = markdownFormatter.render(reportData, options);
        break;
      case 'text':
        output = textFormatter.render(reportData, options);
        break;
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
    
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf-8');
      } catch (error) {
        throw new Error(`Failed to write to output file: ${outputPath}`);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
