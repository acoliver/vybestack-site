import type { ReportData, RenderOptions, Formatter } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions = {}): string {
  const { includeTotals = false } = options;
  
  const lines = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries',
    ...data.entries.map(entry => `- **${entry.label}** — $${entry.amount.toFixed(2)}`),
  ];
  
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}

export const markdownFormatter: Formatter = {
  render: renderMarkdown,
};