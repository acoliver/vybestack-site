import express, { Request, Response } from 'express';
import * as path from 'path';
import DatabaseManager from './database';
import { FormValidator, ValidationResult } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Database manager instance
let dbManager: DatabaseManager;

// Interface for form data from request
interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}
app.get('/', async (_req: Request, res: Response) => {
  try {
    res.render('index', {
      title: 'Friendly Contact Form',
      errors: {},
      formData: {}
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal server error');
  }
});

app.post('/submit', async (_req: Request, res: Response) => {
  try {
    const formData: ContactFormData = {
      firstName: _req.body.firstName || '',
      lastName: _req.body.lastName || '',
      streetAddress: _req.body.streetAddress || '',
      city: _req.body.city || '',
      stateProvinceRegion: _req.body.stateProvinceRegion || '',
      postalZipCode: _req.body.postalZipCode || '',
      country: _req.body.country || '',
      email: _req.body.email || '',
      phoneNumber: _req.body.phoneNumber || ''
    };

    const validation: ValidationResult = FormValidator.validate(formData);

    if (!validation.isValid) {
      // Validation failed, re-render form with errors
      return res.status(400).render('index', {
        title: 'Friendly Contact Form',
        errors: validation.errors,
        formData: validation.formData
      });
    }

    // Validation passed, insert into database
    const submissionId = await dbManager.insertSubmission(formData);
    console.log(`Submission stored with ID: ${submissionId}`);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  try {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  } catch (error) {
    console.error('Error rendering thank you page:', error);
    res.status(500).send('Internal server error');
  }
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).send('Internal server error');
});

// 404 handler
app.use((_req: Request, res: Response) => {
  res.status(404).send('Page not found');
});

// Graceful shutdown handling
async function gracefulShutdown(signal: NodeJS.Signals) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    if (dbManager) {
      await dbManager.close();
      console.log('Database connection closed');
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

// Initialize database and start server
async function startServer() {
  try {
    dbManager = new DatabaseManager();
    await dbManager.initialize();
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
      console.log('Press Ctrl+C to stop the server');
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
if (require.main === module) {
  startServer().catch(console.error);
}

export default app;
