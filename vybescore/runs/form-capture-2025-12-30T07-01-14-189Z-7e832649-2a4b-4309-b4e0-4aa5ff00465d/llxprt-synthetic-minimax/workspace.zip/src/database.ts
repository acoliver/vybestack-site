import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  private getSqlJs(): SqlJsStatic {
    if (!this.sqlJs) {
      throw new Error('SQL.js not initialized');
    }
    return this.sqlJs;
  }

  async initialize(): Promise<void> {
    try {
      this.sqlJs = await initSqlJs({
        locateFile: (file: string) => {
          return require.resolve(`sql.js/dist/${file}`);
        }
      });

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new (this.getSqlJs().Database)(dbBuffer);
      } else {
        this.db = new (this.getSqlJs().Database)();
        await this.createTables();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      this.db.exec(schema);
    }
  }

  async insertSubmission(submission: ContactSubmission): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalZipCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    // Get the last inserted row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const rowId = result[0]?.values[0][0] as number;

    stmt.free();
    await this.saveDatabase();

    return rowId;
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async getAllSubmissions(): Promise<ContactSubmission[]> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare(`
      SELECT 
        first_name, last_name, street_address, city,
        state_province_region, postal_zip_code, country,
        email, phone_number
      FROM submissions 
      ORDER BY created_at DESC
    `);

    const submissions: ContactSubmission[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject() as Record<string, string>;
      submissions.push({
        firstName: row.first_name,
        lastName: row.last_name,
        streetAddress: row.street_address,
        city: row.city,
        stateProvinceRegion: row.state_province_region,
        postalZipCode: row.postal_zip_code,
        country: row.country,
        email: row.email,
        phoneNumber: row.phone_number
      });
    }
    
    stmt.free();
    return submissions;
  }
}

export default DatabaseManager;