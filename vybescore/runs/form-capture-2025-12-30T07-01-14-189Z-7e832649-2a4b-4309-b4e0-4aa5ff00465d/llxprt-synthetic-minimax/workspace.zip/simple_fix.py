# Read the file
with open('src/server.ts', 'r') as f:
    content = f.read()

# Replace the problematic regex patterns
content = content.replace('if (data.phone && !/^\\+?[\\d\\s\\-\\(\\)]{7,}$/.test(data.phone.trim())) {', 
                        'if (data.phone && !/^\\+?[\\d\\s\\-\\(\\)]{7,}$/.test(data.phone.trim())) {')

content = content.replace('if (data.postal_code && !/^[A-Za-z0-9\\s\\-]{3,10}$/.test(data.postal_code.trim())) {', 
                        'if (data.postal_code && !/^[A-Za-z0-9\\s\\-]{3,10}$/.test(data.postal_code.trim())) {')

# Write back
with open('src/server.ts', 'w') as f:
    f.write(content)

print("Fixed regex patterns")
