const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('Running public smoke tests...');

// Test 1: Check if the server starts
console.log('Test 1: Checking if server can start...');
const serverProcess = spawn('node', ['dist/server.js'], {
  cwd: process.cwd(),
  stdio: ['pipe', 'pipe', 'pipe']
});

let serverStarted = false;

serverProcess.stdout.on('data', (data) => {
  const output = data.toString();
  if (output.includes('Server is running')) {
    serverStarted = true;
    console.log('[OK] Server started successfully');
    
    // Give server a moment to fully initialize
    setTimeout(() => {
      serverProcess.kill('SIGTERM');
      
      // Test 2: Check if database file is created
      console.log('Test 2: Checking database initialization...');
      const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
      if (fs.existsSync(path.dirname(dbPath))) {
        console.log('[OK] Database directory created');
      } else {
        console.log(' Database directory not found');
      }
      
      console.log('\n[OK] All public smoke tests passed!');
      process.exit(0);
    }, 2000);
  }
});

serverProcess.stderr.on('data', (data) => {
  console.error('Server error:', data.toString());
});

serverProcess.on('close', (code) => {
  if (!serverStarted && code !== 0) {
    console.error(' Server failed to start');
    process.exit(1);
  }
});

// Timeout after 10 seconds
setTimeout(() => {
  serverProcess.kill('SIGTERM');
  console.error(' Test timeout - server did not start in time');
  process.exit(1);
}, 10000);