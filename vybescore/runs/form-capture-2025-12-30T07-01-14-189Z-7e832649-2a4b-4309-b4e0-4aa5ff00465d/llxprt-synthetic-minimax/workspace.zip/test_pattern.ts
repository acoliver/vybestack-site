const phoneRegex = /^\+?[\d\s()\-]+$/;
