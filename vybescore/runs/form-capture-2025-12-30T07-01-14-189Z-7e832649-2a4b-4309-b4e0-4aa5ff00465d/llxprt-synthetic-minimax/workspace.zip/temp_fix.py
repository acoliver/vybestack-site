import re

# Read the file
with open('src/server.ts', 'r') as f:
    content = f.read()

# Fix the phone regex - use single backslashes where appropriate
content = re.sub(r'/^\\\\\+?\[\\\\d\\\\s\\\\-\\\\\\(\\\\\)\]{7,}\$/', r'/^\+?[\d\s\-\(\)]{7,}$/', content)

# Fix the postal code regex - use single backslashes where appropriate  
content = re.sub(r'/^\[A-Za-z0-9\\\\s\\\\-\]{3,10}\$/', r'/^[A-Za-z0-9\s\-]{3,10}$/', content)

# Write back
with open('src/server.ts', 'w') as f:
    f.write(content)

print("Fixed regex patterns")
