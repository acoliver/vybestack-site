#!/usr/bin/env python3

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the regex pattern by removing unnecessary escapes for forward slashes
# The issue is in line: /http:\\/\\/([^\\/]+)\\/([^\\s<>"{}|\\^`[]*)/g;
# Should be: /http:\/\/([^/]+)\/([^\\s<>"{}|\\^`[]*)/g;

old_pattern = '/http:\\/\\/([^\\/]+)\\/([^\\s<>"{}|\\^`[]*)/g;'
new_pattern = '/http:\/\/([^/]+)\/([^\\s<>"{}|\\^`[]*)/g;'

content = content.replace(old_pattern, new_pattern)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed the regex pattern!")