#!/usr/bin/env python3

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# The issue is that \/ is unnecessary in regex patterns where forward slash doesn't need escaping
# Replace problematic patterns
content = content.replace('http:\\/\\/', 'http://')
content = content.replace('([^\\/', '([^/')
content = content.replace('([^\\s<>"{}|\\\\^`[]*)', '([^\\s<>"{}|\\^`[]*)')

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed unnecessary escape characters in regex patterns")