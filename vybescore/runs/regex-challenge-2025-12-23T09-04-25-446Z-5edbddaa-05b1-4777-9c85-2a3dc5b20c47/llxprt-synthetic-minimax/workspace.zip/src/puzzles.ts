/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match words starting with prefix
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit (not at string start)
  const regex = new RegExp(`(?<!^)\\d${token}`, 'g');
  return text.match(regex) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  if (!/[a-z]/.test(value)) return false; // lowercase
  if (!/[A-Z]/.test(value)) return false; // uppercase
  if (!/\d/.test(value)) return false;    // digit
  if (!/[^\w\s]/.test(value)) return false; // symbol
  
  // Check for immediate repeated sequences (e.g., "abab")
  const hasRepeatedSequences = /(\w{2,})\1/.test(value);
  if (hasRepeatedSequences) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Simplified IPv6 regex that matches standard and compressed formats
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b::[0-9a-fA-F:]*\b|\b[0-9a-fA-F:]*(?:::)[0-9a-fA-F:]*\b/;
  
  return ipv6Regex.test(value);
}
