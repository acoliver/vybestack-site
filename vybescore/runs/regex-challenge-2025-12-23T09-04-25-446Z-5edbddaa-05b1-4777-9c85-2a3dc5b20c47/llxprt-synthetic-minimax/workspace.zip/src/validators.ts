export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that handles:
  // - Local part: letters, numbers, dots, underscores, plus, hyphens
  // - Domain: letters, numbers, dots, hyphens (no underscores)
  // - Rejects double dots, trailing dots, domain underscores
  const emailRegex = /^[a-zA-Z0-9]+([._+-]?[a-zA-Z0-9]+)*@[a-zA-Z0-9]+([.-]?[a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots in any part
  if (value.includes('..')) return false;
  
  // Check for trailing dots
  if (value.includes('@.')) return false;
  if (value.endsWith('.')) return false;
  
  // Check domain doesn't start with dot
  const domain = value.split('@')[1];
  if (domain.startsWith('.')) return false;
  
  // Check no underscores in domain
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (should be 10 or 11 digits)
  if (digits.length < 10 || digits.length > 11) return false;
  
  // If 11 digits, must start with 1
  if (digits.length === 11 && !digits.startsWith('1')) return false;
  
  // Extract the 10-digit number
  const tenDigitNumber = digits.length === 11 ? digits.slice(1) : digits;
  
  // Check area code (first 3 digits)
  const areaCode = tenDigitNumber.slice(0, 3);
  // Area codes can't start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check total length is exactly 10 digits
  return tenDigitNumber.length === 10;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must start with +54, 0, or a valid area code
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  let digits = cleaned;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  // Handle country code
  if (digits.startsWith('+54')) {
    hasCountryCode = true;
    digits = digits.slice(3); // Remove +54
  }
  
  // Handle trunk prefix
  if (digits.startsWith('0')) {
    hasTrunkPrefix = true;
    digits = digits.slice(1); // Remove 0
  }
  
  // Handle mobile indicator (9) - just skip it
  if (digits.startsWith('9')) {
    digits = digits.slice(1); // Remove 9
  }
  
  // Now we should have the area code + subscriber number
  if (digits.length < 8 || digits.length > 12) return false;
  
  // Extract area code (2-4 digits, first digit 1-9)
  if (digits.length < 2) return false;
  
  // Area code must be 2-4 digits, first digit cannot be 0
  const areaCodeLength = Math.min(4, Math.max(2, Math.floor(digits.length * 0.3)));
  const areaCode = digits.slice(0, areaCodeLength);
  
  // First digit of area code must be 1-9
  if (!/^[1-9]/.test(areaCode)) return false;
  
  // Extract subscriber number
  const subscriberNumber = digits.slice(areaCodeLength);
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // Validation rules:
  // 1. If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must be non-empty
  if (!value || value.length === 0) return false;
  
  // Check for digits or symbols (reject "X Æ A-12" style names)
  if (/\d|Æ|Ø|Å/.test(value)) return false;
  
  // Unicode regex that allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes
  // - Hyphens
  // - Spaces
  // - Periods (for names like "Jr.")
  const nameRegex = /^[\p{L}\s'.-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}]/u.test(value)) return false;
  
  // Should not be just spaces, periods, hyphens, or apostrophes
  if (/^[\s'.-]+$/.test(value)) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove spaces and dashes
  const digits = cardNumber.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(digits)) return false;
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check card type by prefix and length
  let isValidType = false;
  
  // Visa: starts with 4, 13, 16, or 19 digits
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
           cleaned.startsWith('54') || cleaned.startsWith('55') || 
           (cleaned.startsWith('222') && parseInt(cleaned.slice(0, 4)) >= 2221 && parseInt(cleaned.slice(0, 4)) <= 2720)) &&
           cleaned.length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, 15 digits
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
