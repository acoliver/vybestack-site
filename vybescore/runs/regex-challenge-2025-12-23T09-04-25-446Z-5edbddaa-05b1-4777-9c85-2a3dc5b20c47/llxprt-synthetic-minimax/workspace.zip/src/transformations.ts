/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Normalize whitespace and trim
  const normalized = text.trim().replace(/\s+/g, " ");
  
  // Handle capitalization of sentences
  return normalized.replace(/(^|[.?!]\s*)([a-z])/g, (match, sentenceStart, letter) => {
    return sentenceStart + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that captures various protocols and formats
  const urlRegex = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"{}|`[]+/gi;
  
  const urls = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return urls.map(url => {
    // Remove trailing punctuation that should not be part of URL
    return url.replace(/[.,!?;:]+$/, "");
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, "https://");
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://domain.com/... URLs
  const urlPattern = /http:\/\/([^\/]+)\/([^\s<>"{}|`[]*)/g;
  
  return text.replace(urlPattern, (match, domain, path) => {
    // Always upgrade to https
    let result = "https://";
    
    // Check if path should trigger host rewrite (starts with /docs/ and no dynamic content)
    const shouldRewriteHost = path.startsWith("docs/") && 
      !path.includes("cgi-bin") &&
      !path.includes("?") &&
      !path.includes("&") &&
      !path.includes("=") &&
      !path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i);
    
    if (shouldRewriteHost) {
      result += `docs.${domain}/`;
    } else {
      result += `${domain}/`;
    }
    
    result += path;
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return "N/A" when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return "N/A";
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = parseInt(match[3]);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return "N/A";
  
  // Validate day (1-31, adjusting for month)
  const daysInMonth = new Date(year, month, 0).getDate();
  if (day < 1 || day > daysInMonth) return "N/A";
  
  // Return the year
  return year.toString();
}