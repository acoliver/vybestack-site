#!/usr/bin/env python3
import re

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# The issue is with unnecessary escape characters in the regex pattern
# ESLint complains about \/ being unnecessary escape
old_pattern = 'const urlPattern = /http:\\\\/\\\\/([^\\\\/]+)\\\\/([^\\\\s<>"{}|\\\\\\\\^`[]*)/g;'
new_pattern = 'const urlPattern = /http:\\/\\/([^\\\/]+)\\/([^\\s<>"{}|\\\\^`[]*)/g;'

if old_pattern in content:
    content = content.replace(old_pattern, new_pattern)
    with open('src/transformations.ts', 'w') as f:
        f.write(content)
    print("Fixed regex escape characters")
else:
    print("Pattern not found, checking actual content...")
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if 'urlPattern' in line:
            print(f"Line {i+1}: {repr(line)}")
            
    # Try to find and replace with the actual pattern
    actual_pattern = '  const urlPattern = /http:\\\\/\\\\/([^\\\\/]+)\\\\/([^\\\\s<>"{}|\\\\\\\\^`[]*)/g;'
    content = content.replace(actual_pattern, new_pattern)
    
    if content != f.read():
        with open('src/transformations.ts', 'w') as f:
            f.write(content)
        print("Fixed with actual pattern")
    else:
        print("No changes made")