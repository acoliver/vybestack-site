#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getFormatter, getSupportedFormats } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    console.error(`Supported formats: ${getSupportedFormats().join(', ')}`);
    process.exit(1);
  }
  
  const inputFile = args[0];
  
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label is required and must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount is required and must be a number`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Validate format
    const formatter = getFormatter(args.format);
    if (!formatter) {
      console.error(`Error: Unsupported format "${args.format}". Supported formats: ${getSupportedFormats().join(', ')}`);
      process.exit(1);
    }
    
    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Cannot read file "${args.inputFile}": ${(error as Error).message}`);
      process.exit(1);
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${args.inputFile}": ${(error as Error).message}`);
      process.exit(1);
    }
    
    // Validate and transform data
    const reportData = validateReportData(jsonData);
    
    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    
    const output = formatter(reportData, options);
    
    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Cannot write to file "${args.outputPath}": ${(error as Error).message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();