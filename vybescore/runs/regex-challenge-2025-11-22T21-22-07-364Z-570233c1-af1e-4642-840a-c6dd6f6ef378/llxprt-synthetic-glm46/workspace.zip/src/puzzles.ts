/**
 * Find words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a negative lookahead for exceptions
  const exceptionsPattern = exceptions.length > 0 
    ? `(?!(?:${exceptions.join('|')})(?=\\W|$))` 
    : '';
  
  // Pattern to match words starting with prefix (word boundary)
  // [\p{L}]+ matches one or more unicode letters
  const pattern = new RegExp(`\\b${exceptionsPattern}${escapedPrefix}[\\p{L}]+`, 'gu');
  
  const matches = text.match(pattern) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Finds occurrences of a token when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for pattern matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\\\$&');
  
// Pattern to find the token after a digit but not at the start of the string
  // Since we want to return the digit+token pair, we'll use a direct approach
  const pattern = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  // Find all occurrences of digit followed by token
  while ((match = pattern.exec(text)) !== null) {
    // Ensure we're not matching at the very beginning of the string
    if (match.index > 0) {
      matches.push(`${match[1]}${match[2]}`); // Return the digit+token combination
    }
  }
  
  return matches;
}

/**
 * Validates passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, and no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric character)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123", "aaa")
  // For sequences of length 2 or more that repeat immediately
  const repeatedSequencePattern = /(..+?)\1+/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 pattern excluding IPv4
  // This pattern matches IPv6 addresses in various formats:
  // - Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Shorthand with :: for consecutive zero groups
  // - Leading zeros can be omitted
  // - IPv6-mapped IPv4 addresses are not matched
  
  // First, ensure there's at least one colon (IPv6 always has colons)
  if (!value.includes(':')) {
    return false;
  }
  
  // Pattern to match IPv6 addresses
  // (?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}) - Full form (8 groups)
  // |(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}::[0-9a-fA-F]{1,4}) - Shorthand with ::
  // |(?:::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}) - Starting with ::
  const ipv6Pattern = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}::[0-9a-fA-F]{1,4})|(?:::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6})|(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}:))/;
  
  // Check for IPv4 pattern first and exclude those
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Find all potential IPv6-like addresses
  const potentialMatches = value.match(/\b[0-9a-fA-F:]+\b/g) || [];
  
  // Check each potential match to see if it's actually IPv6
  for (const match of potentialMatches) {
    // Skip if it's a valid IPv4 address
    if (ipv4Pattern.test(match)) {
      continue;
    }
    
    // Check if it matches IPv6 pattern
    if (ipv6Pattern.test(match)) {
      return true;
    }
  }
  
  return false;
}
