/**
 * Capitalizes the first character of each sentence in the text.
 * Handles sentence boundaries (., !, ?), inserts proper spacing, and collapses extra spaces.
 * Attempts to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // First, replace multiple spaces with a single space
  const result = text.replace(/[ \t]+/g, ' ');
  
  // Split by punctuation marks (., !, ?)
  const parts = result.split(/([.!?])/);
  
  // Process each sentence (even indices) and keep punctuation (odd indices)
  for (let i = 0; i < parts.length; i += 2) {
    const sentence = parts[i];
    if (!sentence) continue;
    
    // Find first letter and capitalize it
    const firstLetterIndex = sentence.search(/[A-Za-zÀ-ÖØ-öø-ÿ]/);
    if (firstLetterIndex !== -1) {
      parts[i] = sentence.substring(0, firstLetterIndex) + 
                 sentence.substring(firstLetterIndex, firstLetterIndex + 1).toUpperCase() + 
                 sentence.substring(firstLetterIndex + 1);
    }
  }
  
  // Rejoin parts with single spaces
  return parts.join('').replace(/\s*([.!?])\s*/g, '$1 ').trim();
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  const urlPattern = /(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)\]\}\s]+$/, ''));
}

/**
 * Replaces all http:// schemes with https://.
 * Leaves existing https:// URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  const httpPattern = /http:\/\//g;
  return text.replace(httpPattern, 'https://');
}

/**
 * Rewrites documentation URLs from http://example.com/docs/* to https://docs.example.com/*
 * while maintaining secure protocol for non-docs URLs and skipping dynamic URLs.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Match URLs with http or https protocol
  const urlPattern = /(https?:\/\/)([^\/:]+)(\/.*)?/g;
  
  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to HTTPS
    const newProtocol = 'https://';
    
    // Split path from possible query string or fragment
    const [cleanPath] = path.split(/[\\?#]/);
    
    // Check if we should rewrite the host
    // Skip host rewrite for dynamic paths or legacy server pages
    const dynamicPatterns = [
      /\/cgi-bin\//i,
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    // Skip if the path contains dynamic patterns
    if (cleanPath && dynamicPatterns.some(pattern => pattern.test(cleanPath))) {
      return `${newProtocol}${host}${path}`;
    }
    
    // Skip if there's a query string
    if (path.includes('?')) {
      return `${newProtocol}${host}${path}`;
    }
    
    // Rewrite docs.example.com format for /docs paths
    if (cleanPath && cleanPath.startsWith('/docs/')) {
      return `${newProtocol}docs.${host}${path}`;
    }
    
    // Just upgrade to HTTPS for non-docs URLs
    return `${newProtocol}${host}${path}`;
  });
}

/**
 * Extracts the year from a mm/dd/yyyy formatted date.
 * Returns 'N/A' if the format doesn't match or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  return match[3]; // Return the year (capturing group 3)
}