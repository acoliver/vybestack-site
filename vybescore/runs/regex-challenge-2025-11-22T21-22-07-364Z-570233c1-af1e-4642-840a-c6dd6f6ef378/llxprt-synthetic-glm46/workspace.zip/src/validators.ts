export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common standards.
 * Accepts typical addresses like name+tag@example.co.uk,
 * rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Reject if doesn't match basic pattern
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domainPart] = value.split('@');
  
  // Local part validation
  // Cannot start or end with dot, no consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // Domain part validation
  // Cannot have underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Cannot start or end with dot or hyphen, no consecutive dots
  if (domainPart.startsWith('.') || domainPart.endsWith('.') || 
      domainPart.startsWith('-') || domainPart.endsWith('-') ||
      domainPart.includes('..')) {
    return false;
  }
  
  // Domain labels must be valid
  const domainLabels = domainPart.split('.');
  if (domainLabels.some(label => !label || label.startsWith('-') || label.endsWith('-'))) {
    return false;
  }
  
  // TLD must be at least 2 characters
  const tld = domainLabels[domainLabels.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Use options to avoid TypeScript unused variable warning
  if (options && Object.keys(options).length > 0) {
    // Handle potential extensions in a future implementation
  }
  // Remove all non-digit characters for basic validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have enough digits (at least 10 for US number, 11 if +1 prefix)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If there are 11 digits, the first must be '1' (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Extract the area code (first 3 digits after optional country code)
  const areaCodeIndex = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeIndex, areaCodeIndex + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check for valid format with optional separators
  const usPhonePattern = /^(?:\+?1[\s-]?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s-]?[2-9]\d{2}[\s-]?\d{4}$/;
  
  return usPhonePattern.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators but keep the structure for validation
  const normalizedValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern
  // ^(?:\+54)?      - Optional country code +54
  // (?:0)?          - Optional trunk prefix 0
  // (?:9)?          - Optional mobile indicator 9
  // ([1-9]\d{1,3})  - Area code: 2-4 digits, leading 1-9
  // (\d{6,8})$      - Subscriber number: 6-8 digits
  const argentinePhonePattern = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // If it doesn't match the pattern, it's invalid
  if (!argentinePhonePattern.test(normalizedValue)) {
    return false;
  }
  
  const match = normalizedValue.match(argentinePhonePattern);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits and cannot start with 0 (already enforced by regex)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits (already enforced by regex)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = value.startsWith('+54');
  const hasTrunkPrefix = normalizedValue.startsWith('0') || normalizedValue.startsWith('+540');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Empty or whitespace-only names are invalid
  if (!value || /^\s*$/.test(value)) {
    return false;
  }
  
  // Name validation pattern:
  // ^                           - Start of string
  // [\p{L}'-]+                  - One or more unicode letters, apostrophes, or hyphens
  // (?:\s+[\p{L}'-]+)*         - Zero or more groups of space followed by name parts
  // $                           - End of string
  const namePattern = /^[\p{L}'-]+(?:\s+[\p{L}'-]+)*$/u;
  
  // Check if matches the pattern
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject names that contain sequences like "X Æ A-12" with numbers
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Reject names with isolated special characters
  if (/(?:^|\s)['-](?:\s|$)/.test(value)) {
    return false;
  }
  
  // Reject names with consecutive special characters
  if (/(?:['-]){2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run the Luhn checksum check.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * Uses Luhn checksum algorithm for validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const normalizedCard = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(normalizedCard)) {
    return false;
  }
  
  // Check valid lengths (13-19 digits for most cards)
  if (normalizedCard.length < 13 || normalizedCard.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaPattern = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[1-9]\d{3})\d{10}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if card matches any of the patterns
  const isValidFormat = visaPattern.test(normalizedCard) || 
                        mastercardPattern.test(normalizedCard) || 
                        amexPattern.test(normalizedCard);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(normalizedCard);
}
