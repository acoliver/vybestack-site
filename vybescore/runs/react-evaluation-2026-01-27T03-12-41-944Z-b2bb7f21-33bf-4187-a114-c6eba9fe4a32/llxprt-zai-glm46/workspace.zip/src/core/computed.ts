/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: undefined,
    dependents: undefined,
  }
  
  const read: GetterFn<T> = () => {
    const currentActive = getActiveObserver()
    if (currentActive && currentActive !== o) {
      // Another observer is reading this computed value
      // Register that observer as depending on this computed observer
      if (!o.dependents) {
        o.dependents = new Set()
      }
      o.dependents.add(currentActive)
    }
    return o.value!
  }
  
  updateObserver(o)
  
  return read
}
