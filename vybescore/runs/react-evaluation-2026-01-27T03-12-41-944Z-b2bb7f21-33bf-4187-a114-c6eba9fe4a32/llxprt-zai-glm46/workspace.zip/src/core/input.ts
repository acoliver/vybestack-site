/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    observers: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register the observer as watching this subject
      if (!s.observers) {
        s.observers = new Set()
      }
      s.observers.add(observer)
      
      // Track which subjects this observer depends on
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      observer.subjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers watching this subject
    if (s.observers && s.observers.size > 0) {
      const observersToUpdate = Array.from(s.observers)
      for (const observer of observersToUpdate) {
        updateObserver(observer as Observer<T>)
      }
    }
    
    return s.value
  }

  return [read, write]
}
