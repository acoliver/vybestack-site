import { readFileSync } from 'fs';
import type { ReportData } from '../types.js';

/**
 * Reads and validates JSON file with report data
 */
export function readAndValidateReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    // Validate entries
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid entry label');
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error('Missing or invalid entry amount');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    
    throw error;
  }
}