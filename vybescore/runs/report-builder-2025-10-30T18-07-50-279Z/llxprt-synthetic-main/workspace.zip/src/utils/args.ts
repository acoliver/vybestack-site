/**
 * CLI argument parser using only Node's built-in modules
 */
export interface ParsedArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(args: string[]): ParsedArgs {
  // args[0] is the node executable, args[1] is the script
  const cliArgs = args.slice(2);

  if (cliArgs.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = cliArgs[0];
  
  // Find the --format flag
  const formatFlagIndex = cliArgs.findIndex(arg => arg === '--format');
  if (formatFlagIndex === -1 || formatFlagIndex === cliArgs.length - 1) {
    console.error('Error: --format flag is required and must specify a format value');
    process.exit(1);
  }
  
  const format = cliArgs[formatFlagIndex + 1];
  
  // Check if format is supported
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }

  // Check for --output flag
  const outputFlagIndex = cliArgs.findIndex(arg => arg === '--output');
  const outputPath = outputFlagIndex !== -1 && outputFlagIndex < cliArgs.length - 1 
    ? cliArgs[outputFlagIndex + 1] 
    : undefined;

  // Check for --includeTotals flag
  const includeTotals = cliArgs.includes('--includeTotals');

  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}