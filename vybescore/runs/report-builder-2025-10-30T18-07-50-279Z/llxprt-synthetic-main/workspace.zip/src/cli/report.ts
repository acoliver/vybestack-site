#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { parseArgs } from '../utils/args.js';
import { readAndValidateReportData } from '../utils/json.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map format names to their respective renderer functions
const formatters = {
  markdown: renderMarkdown,
  text: renderText
};

try {
  // Parse command line arguments
  const args = parseArgs(process.argv);
  
  // Read and validate the report data
  const reportData = readAndValidateReportData(args.inputFile);
  
  // Get the appropriate formatter
  const formatter = formatters[args.format as keyof typeof formatters];
  
  if (!formatter) {
    console.error(`Error: Unsupported format "${args.format}"`);
    process.exit(1);
  }
  
  // Format the report
  const output = formatter(reportData, {
    includeTotals: args.includeTotals
  });
  
  // Write output to stdout or file
  if (args.outputPath) {
    writeFileSync(args.outputPath, output, 'utf8');
  } else {
    console.log(output);
  }
} catch (error) {
  console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}