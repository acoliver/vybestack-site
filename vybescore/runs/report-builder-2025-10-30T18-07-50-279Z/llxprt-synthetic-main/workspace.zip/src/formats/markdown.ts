import type { ReportData, FormatOptions, ReportFormatter } from '../types.js';

/**
 * Formats report data as Markdown
 */
export const renderMarkdown: ReportFormatter = (
  data: ReportData,
  options: FormatOptions
): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries header
  lines.push('## Entries');

  // Format each entry as a bullet point
  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- **${entry.label}** — ${formattedAmount}`);
  }

  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    lines.push(`**Total:** ${formattedTotal}`);
  }

  return lines.join('\n');
};