// Constants
const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;
const INVALID_BASE64_INPUT = 'Invalid Base64 input';
const FAILED_TO_DECODE = 'Failed to decode Base64 input';
const PADDING_CHAR = '=';
const BASE64_BLOCK_SIZE = 4;

/**
 * Check if a string is a valid Base64 input.
 * Throws error if not valid.
 */
function validateBase64(input: string): void {
  // Check for valid characters
  if (!BASE64_REGEX.test(input)) {
    throw new Error(INVALID_BASE64_INPUT);
  }
  
  // Check proper padding structure
  const paddingIndex = input.indexOf(PADDING_CHAR);
  if (paddingIndex !== -1) {
    const padding = input.substring(paddingIndex);
    
    // Padding must only appear at the end
    if (input.slice(paddingIndex).replace(new RegExp(PADDING_CHAR, 'g'), '').length > 0) {
      throw new Error(INVALID_BASE64_INPUT);
    }
    
    // Padding must be 1 or 2 characters
    if (padding.length > 2) {
      throw new Error(INVALID_BASE64_INPUT);
    }
  }
  
  // Test actual decode to ensure it's valid
  const remainder = input.length % BASE64_BLOCK_SIZE;
  const testInput = remainder !== 0 ? input + PADDING_CHAR.repeat(BASE64_BLOCK_SIZE - remainder) : input;
  
  try {
    Buffer.from(testInput, 'base64');
  } catch {
    throw new Error(INVALID_BASE64_INPUT);
  }
}

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws errors for invalid payloads.
 */
export function decode(input: string): string {
  // Normalize the input by adding padding if required
  // Base64 strings should have a length that's a multiple of 4
  const remainder = input.length % BASE64_BLOCK_SIZE;
  const paddedInput = remainder > 0 ? input + PADDING_CHAR.repeat(BASE64_BLOCK_SIZE - remainder) : input;
  
  // Validate the input
  validateBase64(input);
  
  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch {
    throw new Error(FAILED_TO_DECODE);
  }
}
