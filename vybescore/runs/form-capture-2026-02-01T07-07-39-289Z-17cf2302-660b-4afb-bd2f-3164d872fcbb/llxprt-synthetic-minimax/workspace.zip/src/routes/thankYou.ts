import express, { Request, Response } from 'express';

const router = express.Router();

// GET /thank-you - Render thank you page
router.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

export default router;