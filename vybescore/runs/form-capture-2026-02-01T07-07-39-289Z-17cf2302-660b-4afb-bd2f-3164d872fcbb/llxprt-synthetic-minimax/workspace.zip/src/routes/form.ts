import express, { Request, Response } from 'express';
import DatabaseManager from '../database/DatabaseManager.js';

const router = express.Router();

// Helper to get database manager from app
function getDbManager(req: Request): DatabaseManager {
  const app = req.app as unknown as { get: (key: string) => DatabaseManager };
  return app.get('dbManager');
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

interface ValidationError {
  field: string;
  message: string;
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field checks
  if (!data.firstName?.trim()) errors.push({ field: 'firstName', message: 'First name is required' });
  if (!data.lastName?.trim()) errors.push({ field: 'lastName', message: 'Last name is required' });
  if (!data.streetAddress?.trim()) errors.push({ field: 'streetAddress', message: 'Street address is required' });
  if (!data.city?.trim()) errors.push({ field: 'city', message: 'City is required' });
  if (!data.stateProvinceRegion?.trim()) errors.push({ field: 'stateProvinceRegion', message: 'State/Province/Region is required' });
  if (!data.postalCode?.trim()) errors.push({ field: 'postalCode', message: 'Postal code is required' });
  if (!data.country?.trim()) errors.push({ field: 'country', message: 'Country is required' });
  if (!data.email?.trim()) errors.push({ field: 'email', message: 'Email is required' });
  if (!data.phoneNumber?.trim()) errors.push({ field: 'phoneNumber', message: 'Phone number is required' });

  // Email validation (simple regex)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  if (data.phoneNumber && !/^\+?[\d\s()-]+$/.test(data.phoneNumber)) {
    errors.push({ field: 'phoneNumber', message: 'Please enter a valid phone number' });
  }

  // Postal code validation (alphanumeric strings)
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return errors;
}

// GET / - Render contact form
router.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Friendly Contact Form',
    errors: [],
    formData: {}
  });
});

// POST /submit - Handle form submission
router.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvinceRegion: req.body.stateProvinceRegion,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phoneNumber: req.body.phoneNumber
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    // Validation failed, re-render form with errors
    return res.status(400).render('form', {
      title: 'Friendly Contact Form',
      errors,
      formData
    });
  }

  try {
    // Validation passed, save to database
    await getDbManager(req).insertSubmission(formData);
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal Server Error');
  }
});

export default router;