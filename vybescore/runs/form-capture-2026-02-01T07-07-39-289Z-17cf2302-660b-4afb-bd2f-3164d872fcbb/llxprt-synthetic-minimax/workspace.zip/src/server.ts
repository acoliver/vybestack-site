import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import DatabaseManager from './database/DatabaseManager.js';
import formRouter from './routes/form.js';
import thankYouRouter from './routes/thankYou.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Initialize database
const dbManager = new DatabaseManager(path.join(__dirname, '..', 'data', 'submissions.sqlite'));
await dbManager.initialize();

// Make dbManager available to routes
app.set('dbManager', dbManager);

// Routes
app.use('/', formRouter);
app.use('/', thankYouRouter);

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Error:', err.message);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default server;
