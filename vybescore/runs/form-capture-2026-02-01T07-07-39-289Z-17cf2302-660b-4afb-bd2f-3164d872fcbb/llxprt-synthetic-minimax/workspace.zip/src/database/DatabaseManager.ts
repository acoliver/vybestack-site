import initSqlJs from 'sql.js';
import fs from 'fs/promises';
import path from 'path';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

class DatabaseManager {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any = null; // sql.js database instance  
  private dbPath: string;
  private SQL: Awaited<ReturnType<typeof initSqlJs>> | null = null; // sql.js module instance

  constructor(dbPath: string) {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        // Use local WASM file instead of external URL
        const localPath = path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        return localPath;
      }
    });
    this.SQL = SQL;

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    try {
      await fs.access(dataDir);
    } catch {
      await fs.mkdir(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    try {
      const dbBuffer = await fs.readFile(this.dbPath);
      this.db = new SQL.Database(dbBuffer);
    } catch {
      // Create new database if file doesn't exist
      this.db = new SQL.Database();
      await this.createSchema();
    }

    console.log('Database initialized');
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = await fs.readFile(schemaPath, 'utf-8');
    
    this.db.exec(schema);
    await this.persist();
  }

  private async persist(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const dbBuffer = this.db.export();
    await fs.writeFile(this.dbPath, Buffer.from(dbBuffer));
  }

  async insertSubmission(formData: FormData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phoneNumber
    ]);

    stmt.free();
    await this.persist();
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database closed');
    }
  }
}

export default DatabaseManager;
