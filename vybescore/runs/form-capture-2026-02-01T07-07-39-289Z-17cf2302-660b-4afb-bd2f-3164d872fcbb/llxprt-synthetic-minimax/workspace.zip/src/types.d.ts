declare module 'sql.js' {
  interface Database {
    run(stmt: string, params?: unknown[]): void;
    prepare(stmt: string): Statement;
    close(): void;
    export(): Uint8Array;
  }

  interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  interface InitSqlJs {
    (config?: {
      locateFile?: (filename: string) => string;
      onError?: (error: string) => void;
    }): Promise<{
      Database: new (buffer?: Uint8Array) => Database;
      Statement: new () => Statement;
    }>;
  }

  const initSqlJs: InitSqlJs;
  export = initSqlJs;
}