/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after .?!
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces sensibly
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ');
  
  // Insert space after sentence terminators if missing (but not before quotes/parentheses)
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Capitalize first character of string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize after sentence terminators, but preserve known abbreviations
  // Common abbreviations that should not trigger capitalization
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'eg', 'ie', 'approx', 'dept'];
  const abbrevPattern = abbreviations.join('|');
  
  // Split on sentence boundaries, being careful with abbreviations
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, boundary, letter) => {
    // Check if this might be an abbreviation
    const beforeBoundary = result.substring(0, result.indexOf(match));
    const lastWord = beforeBoundary.split(/\s+/).pop() || '';
    
    // If the word before the period is an abbreviation, don't capitalize
    if (new RegExp(`^(${abbrevPattern}).?$`, 'i').test(lastWord)) {
      return boundary + letter;
    }
    
    return boundary + letter.toUpperCase();
  });
  
  // Clean up any double spaces that might have been introduced
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * Extract URLs from text.
 * Returns all URLs detected without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: http:// or https:// followed by domain/path
  // Domain includes alphanumeric, hyphens, dots
  // Path includes alphanumeric, hyphens, dots, slashes, and common URL characters
  const urlPattern = /https?:\/\/[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s<>"'(){}[\]]*)?/g;
  
  const matches = text.match(urlPattern);
  if (!matches) return [];
  
  // Remove trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs.
 * For http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, ?, &, =, .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/example\.com(\/[^\s<>"'(){}[\],]*)?/gi, (match, path = '') => {
    // Always upgrade to https
    const scheme = 'https://';
    
    // Check if path should skip host rewrite (dynamic content)
    const dynamicPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\/|$)/i
    ];
    
    const skipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
    
    // If path starts with /docs (including just /docs or /docs/) and no dynamic pattern, rewrite host
    if (path.startsWith('/docs') && !skipHostRewrite) {
      return `${scheme}docs.example.com${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return `${scheme}example.com${path}`;
  });
}

/**
 * Extract year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = parseInt(dateMatch[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  let maxDay = daysInMonth[month - 1];
  if (month === 2) {
    // Leap year: divisible by 4, but not by 100 unless also by 400
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (isLeapYear) {
      maxDay = 29;
    }
  }
  
  if (day < 1 || day > maxDay) return 'N/A';
  
  return year.toString();
}
