export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Additional checks:
  // - No double dots anywhere
  // - No trailing dot
  if (/\.\./.test(value)) return false;
  if (value.endsWith('.')) return false;
  
  // Check for underscore in domain
  const parts = value.split('@');
  if (parts.length < 2) return false;
  const domain = parts[parts.length - 1];
  if (domain.includes('_')) return false;
  
  // Basic email validation regex that supports tags (e.g., name@tag@example.co.uk):
  // - Local part: alphanumeric plus ._%+- but no consecutive dots
  // - Optional tags: @ followed by alphanumeric plus ._- (can have multiple tags)
  // - Final @ symbol
  // - Domain: alphanumeric parts with dots, hyphens allowed but no underscores
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9]+([._%+-][a-zA-Z0-9]+)*(@[a-zA-Z0-9._-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // options parameter reserved for future use (e.g., allowExtensions)
  void options;
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with +1 prefix)
  if (digits.length < 10 || digits.length > 11) return false;
  
  // Handle optional +1 prefix
  let areaCode: string;
  let exchangeCode: string;
  
  if (digits.length === 11) {
    if (digits[0] !== '1') return false;
    areaCode = digits.slice(1, 4);
    exchangeCode = digits.slice(4, 7);
  } else {
    areaCode = digits.slice(0, 3);
    exchangeCode = digits.slice(3, 6);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Check that the original format matches allowed patterns
  const allowedPatterns = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-.\s]?\d{4}$/,    // (212) 555-7890
    /^\+?1?\s*\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/,    // 212-555-7890
    /^\+?1?\s*\d{10}$/                             // 2125557890
  ];
  
  return allowedPatterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber: 6-8 digits
 * - Spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean and parse the number
  const cleaned = value.replace(/[\s-]/g, '');
  const digits = cleaned.replace(/\D/g, '');
  
  // Check minimum and maximum length (without country code: 8-12 digits, with: 10-14)
  if (digits.length < 8 || digits.length > 14) return false;
  
  let remaining = digits;
  let hasCountryCode = false;
  
  // Check for country code 54 (with or without +)
  if (digits.startsWith('54')) {
    hasCountryCode = true;
    remaining = remaining.slice(2);
  }
  
  // Check for mobile indicator 9 (optional)
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Check for trunk prefix 0 (required if no country code was present)
  if (!hasCountryCode) {
    if (!remaining.startsWith('0')) return false;
    remaining = remaining.slice(1);
  } else {
    // Trunk prefix is optional with country code
    if (remaining.startsWith('0')) {
      remaining = remaining.slice(1);
    }
  }
  
  // Extract area code (2-4 digits, must start with 1-9)
  const areaCodeMatch = remaining.match(/^[1-9]\d{1,3}/);
  if (!areaCodeMatch) return false;
  
  remaining = remaining.slice(areaCodeMatch[0].length);
  
  // Subscriber number: 6-8 digits
  if (remaining.length < 6 || remaining.length > 8) return false;
  
  if (!/^\d+$/.test(remaining)) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) return false;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Check for invalid symbols (anything that's not a letter, apostrophe, hyphen, space, or common accent marks)
  // Allow unicode letters, common apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names that are just symbols or have consecutive symbols
  if (/['-]{2,}/.test(value)) return false;
  
  // Reject names starting or ending with apostrophe or hyphen
  if (/^['-\s]|['-\s]$/.test(value.trim())) return false;
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check Visa: starts with 4, length 13 or 16
  const visa = /^4\d{12}(\d{3})?$/;
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercard = /^(5[1-5]\d{14}|(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12})$/;
  
  // Check AmEx: starts with 34 or 37, length 15
  const amex = /^3[47]\d{13}$/;
  
  // Validate format
  const validFormat = visa.test(cleaned) || mastercard.test(cleaned) || amex.test(cleaned);
  if (!validFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
