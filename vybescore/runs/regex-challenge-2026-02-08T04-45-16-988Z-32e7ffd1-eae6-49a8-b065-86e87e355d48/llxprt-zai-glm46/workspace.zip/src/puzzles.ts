/**
 * Find words starting with prefix, excluding exceptions.
 * Uses lookaheads to match word boundaries.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: word boundary, prefix, then more word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(pattern);
  if (!matches) return [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Find token occurrences after a digit, not at string start.
 * Uses positive lookbehind to ensure digit precedes token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: positive lookbehind for digit, then capture digit+token
  // (?<=\d) ensures there's a digit immediately before
  // We need to match the digit as part of the result
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern);
  return matches || [];
}

/**
 * Validate strong password.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // This pattern looks for any 2-4 character sequence that repeats immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand (::).
 * Ensures IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern - must contain colons (to distinguish from IPv4)
  // Full form: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can appear once to replace consecutive groups of zeros
  
  // Common IPv6 patterns that must match
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|:/;
  
  // Check if it matches IPv6 pattern
  if (!ipv6Pattern.test(value)) return false;
  
  // Extract potential IPv6 matches to verify they're actually IPv6
  const ipv6Matches = value.match(/(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|:/g);
  
  if (!ipv6Matches) return false;
  
  // Check each match to ensure it's not just a colon or something that looks like IPv6
  for (const match of ipv6Matches) {
    // Must be a valid IPv6 pattern (not just a single colon)
    if (match === ':' || match.length < 2) continue;
    
    // IPv4 pattern to exclude embedded IPv4
    const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    
    // If this match is a pure IPv4 address, skip it
    if (ipv4Pattern.test(match)) continue;
    
    // This is a valid IPv6 address
    return true;
  }
  
  return false;
}
