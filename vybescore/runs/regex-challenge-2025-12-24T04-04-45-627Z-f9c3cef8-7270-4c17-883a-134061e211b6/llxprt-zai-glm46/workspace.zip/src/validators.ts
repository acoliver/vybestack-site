export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant-ish email validation
  // Local part: alphanumeric plus . _ % + - but no consecutive dots, no leading/trailing dots
  // Domain: alphanumeric plus hyphens, no underscores, at least one dot, proper TLD
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9_%++-]*[a-zA-Z0-9])?@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks for patterns not caught by the main regex
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for consecutive dots in local part
  const [localPart] = value.split('@');
  if (localPart.includes('..')) {
    return false;
  }

  // Check for underscore in domain
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all whitespace for validation
  const cleaned = value.replace(/\s+/g, '');

  // Extract the actual phone number (without country code)
  let phoneNum = cleaned.replace(/^(\+1|1)[\s-]?/, '');
  
  // Remove all non-digit characters
  phoneNum = phoneNum.replace(/\D/g, '');

  // Check minimum length (area code + 7 digits = 10 digits minimum)
  if (phoneNum.length < 10) {
    return false;
  }

  // Check maximum reasonable length (area code + 7 digits + extension)
  if (phoneNum.length > 15) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = phoneNum.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  if (phoneNum.length >= 6) {
    const exchangeCode = phoneNum.substring(3, 6);
    if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
      return false;
    }
  }

  // Handle extensions if allowed
  if (options?.allowExtensions) {
    const extMatch = phoneNum.match(/(\d+)ext(\d+)$/);
    if (extMatch) {
      phoneNum = extMatch[1];
    }
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Supports landlines and mobiles in various formats:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required if country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Match pattern:
  // ^(\+54)? - optional +54 country code
  // (0?) - optional trunk prefix 0
  // (9?) - optional mobile indicator 9
  // (\d{2,4}) - area code (2-4 digits)
  // (\d{6,8})$ - subscriber number (6-8 digits)
  const phoneRegex = /^(\+54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(phoneRegex);

  if (!match) {
    return false;
  }

  const [, countryPrefix, trunkPrefix, , areaCode, subscriberNum] = match;

  // Country code rules
  // If country code is present, trunk prefix is NOT allowed (they are mutually exclusive)
  // If country code is absent, trunk prefix MUST be present
  if (countryPrefix && trunkPrefix) {
    return false;
  }
  if (!countryPrefix && !trunkPrefix) {
    return false;
  }

  // Area code must be 2-4 digits and must start with 1-9 (not 0)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (areaCode[0] === '0') {
    return false;
  }

  // Subscriber number must be 6-8 digits
  if (subscriberNum.length < 6 || subscriberNum.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names (with digits)
 */
export function isValidName(value: string): boolean {
  // Name must contain at least one character
  if (value.length === 0) {
    return false;
  }

  // Check for digits anywhere in the name
  if (/\d/.test(value)) {
    return false;
  }

  // Regex explanation:
  // ^\p{L}+ - starts with unicode letter(s)
  // [\p{L}\s'-]* - can contain unicode letters, spaces, apostrophes, hyphens
  // \p{L}$ - ends with a letter (not space or punctuation)
  const nameRegex = /^[\p{L}]+(?:[\s'-][\p{L}]+)*$/u;

  return nameRegex.test(value);
}

/**
 * Validate credit card numbers.
 * Accepts Visa, Mastercard, American Express prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if it's all digits
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }

  // Check prefixes and lengths for different card types
  // Visa: 4, 13-16 digits
  // Mastercard: 51-55, 2221-2720, 16 digits
  // American Express: 34 or 37, 15 digits
  
  const isVisa = /^4\d{12,15}$/.test(cleaned);
  const isMastercard = /^(?:5[1-5]\d{14}|2[2-7][0-1]\d{12}|2[2-7]2\d{11})$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);

  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function for Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}
