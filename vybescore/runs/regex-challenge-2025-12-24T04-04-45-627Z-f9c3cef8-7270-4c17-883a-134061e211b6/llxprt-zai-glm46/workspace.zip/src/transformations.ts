/**
 * Capitalize the first character of each sentence.
 * Rules:
 * - Capitalize first character after sentence-ending punctuation (. ? !)
 * - Insert exactly one space between sentences even if input omitted it
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Step 1: Normalize spacing - collapse multiple spaces to one
  let result = text.replace(/[ \t]+/g, ' ');

  // Step 2: Ensure space after sentence-ending punctuation if not present
  // Match punctuation followed immediately by a letter
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');

  // Step 3: Capitalize first letter of text
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());

  // Step 4: Capitalize first letter after sentence-ending punctuation
  // Use negative lookbehind to skip common abbreviations
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'vs', 'etc', 'eg', 'ie'];
  const abbrevPattern = abbreviations.join('|');
  
  // We need to be careful with abbreviations - check if preceded by them
  // Using a callback to check context
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    // Check the character before the punctuation
    const matchIndex = result.indexOf(match);
    const beforePunct = result.substring(Math.max(0, matchIndex - 3), matchIndex + prefix.length - 2);
    
    // If it looks like an abbreviation followed by a period, don't capitalize
    if (beforePunct.match(new RegExp(`(${abbrevPattern})\\.`, 'i'))) {
      return prefix + letter;
    }
    
    return prefix + letter.toUpperCase();
  });

  // Step 5: Clean up any double spaces that might have been introduced
  result = result.replace(/ +/g, ' ');

  return result;
}

/**
 * Extract all URLs from the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, ftp protocols and www
  // Matches:
  // - protocol://domain/path
  // - www.domain/path
  // Excludes trailing punctuation (. , ! ? ; :)
  const urlPattern = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>]+(?:[^\s.,!?;:])/g;

  const matches = text.match(urlPattern);
  if (!matches) return [];

  // Clean up any trailing punctuation that might have been captured
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * Convert all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, being careful not to double-convert
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Dynamic indicators that should prevent host rewrite
  const dynamicIndicators = [
    'cgi-bin', 
    '\\?', 
    '&', 
    '=', 
    '\\.jsp', 
    '\\.php', 
    '\\.asp', 
    '\\.aspx', 
    '\\.do', 
    '\\.cgi', 
    '\\.pl', 
    '\\.py'
  ];
  const dynamicPattern = new RegExp(`(${dynamicIndicators.join('|')})`);

  // Pattern to match example.com URLs with http/https protocol
  // We'll capture the full URL including protocol
  const urlPattern = /https?:\/\/[^\s]*example\.com[^\s]*(?:\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match) => {
    // Extract path from the URL
    const pathMatch = match.match(/https?:\/\/[^/\s]+(\/[^\s]*)/);
    const path = pathMatch ? pathMatch[1] : '';
    
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // Check if we should rewrite the host
    // Only rewrite if:
    // 1. Path exists and starts with /docs/
    // 2. No dynamic indicators in the path
    
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic indicators
      if (!dynamicPattern.test(path)) {
        // Rewrite host to docs.example.com
        return newScheme + 'docs.example.com' + path;
      }
    }
    
    // Just upgrade the scheme - reconstruct URL
    const urlMatch = match.match(/https?:\/\/([^/\s]+)(\/[^\s]*)?/);
    if (urlMatch) {
      const host = urlMatch[1];
      return newScheme + host + (path || '');
    }
    return match.replace(/^https?:/, 'https:');
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  // Month: 01-12, Day: 01-31, Year: 0000-9999
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];

  if (day < 1 || day > maxDay) {
    return 'N/A';
  }

  return year;
}
