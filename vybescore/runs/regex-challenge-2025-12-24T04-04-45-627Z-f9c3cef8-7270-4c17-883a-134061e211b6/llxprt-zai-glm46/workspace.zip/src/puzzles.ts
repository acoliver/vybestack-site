/**
 * Find words starting with the given prefix, excluding specified exceptions.
 * Uses regex with negative lookbehind for exclusions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Build pattern to match words starting with prefix
  // \b - word boundary
  // [a-zA-Z]* - matches word characters
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');

  const matches = text.match(wordPattern);
  if (!matches) return [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches
    .filter(word => !exceptionsLower.includes(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit
 * and not at the start of the string.
 * Returns the digit plus token (e.g., '1foo').
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: \dtoken - digit followed by token
  // Use word boundary to ensure we're getting the right match
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern);
  return matches || [];
}

/**
 * Validate passwords according to strong password policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric, non-whitespace)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab, abcabc should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (2+ character patterns)
  // e.g., "abab" contains "ab" repeated, "abcabc" contains "abc" repeated
  // Use case-insensitive comparison to catch patterns like "AbAb" or "AbCABC"
  const lowerValue = value.toLowerCase();
  for (let len = 2; len <= lowerValue.length / 2; len++) {
    for (let i = 0; i <= lowerValue.length - 2 * len; i++) {
      const pattern = lowerValue.substring(i, i + len);
      const nextSegment = lowerValue.substring(i + len, i + 2 * len);
      if (pattern === nextSegment) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 * IPv6 format:
 * - 8 groups of 1-4 hex digits separated by colons
 * - Shorthand :: can replace one or more consecutive groups of zeros
 * - Can include IPv4-mapped addresses (::ffff:192.0.2.1)
 * - We exclude pure IPv4 addresses from triggering a positive match
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // 1. Full format: 8 groups of 1-4 hex digits (e.g., 2001:0db8:85a3:0000:0000:8a2e:0370:7334)
  // 2. Compressed format with :: (e.g., 2001:db8::1, fe80::1)
  // 3. IPv4-mapped IPv6 (e.g., ::ffff:192.0.2.1)
  
  // Pure IPv4 pattern (to exclude)
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  // IPv6 pattern - comprehensive
  const ipv6Pattern = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::(?:[Ff]{4}(?::0{1,4})?:)?(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}:(?::[0-9a-fA-F]{1,4}:){0,4}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,3}:(?::[0-9a-fA-F]{1,4}:){0,3}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,4}:(?::[0-9a-fA-F]{1,4}:){0,2}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}:(?::[0-9a-fA-F]{1,4}:)?[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4})(?=$|\s)/;

  // Check if it matches IPv6 pattern
  if (!ipv6Pattern.test(value)) {
    return false;
  }

  // Make sure it's not just an IPv4 address
  if (ipv4Pattern.test(value)) {
    return false;
  }

  return true;
}
