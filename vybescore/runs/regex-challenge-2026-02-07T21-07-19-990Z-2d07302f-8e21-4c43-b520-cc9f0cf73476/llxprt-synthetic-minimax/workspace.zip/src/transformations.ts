/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences by looking for end punctuation followed by space or end of text
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  return sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length === 0) {
      return trimmed;
    }
    
    // Capitalize first letter of each non-empty sentence
    const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
    
    return capitalized;
  }).join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches most common URL formats
  const urlPattern = /\bhttps?:\/\/[^\s<>"{}|\\^`[\]]+[^\s.,?!:;"<>"{}|\\^`[\]())]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation if present
    return url.replace(/[.,;!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Find all http:// URLs
  const urlPattern = /http:\/\/[^\s<>"{}|\\^`[\]]+/gi;
  
  return text.replace(urlPattern, (match) => {
    // Parse the URL to check its path
    const urlMatch = match.match(/^http:\/\/([^/]+)(.*)$/);
    
    if (!urlMatch) {
      return match;
    }
    
    const host = urlMatch[1];
    const path = urlMatch[2] || '';
    
    // Check for dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|=|&|cgi-bin)/.test(path);
    const hasLegacyExtensions = /(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    // Always upgrade scheme to https
    let rewrittenUrl = 'https://' + host;
    
    // Only rewrite host for /docs/ paths without dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasLegacyExtensions) {
      // Rewrite host to docs.domain.tld format
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts.slice(-2).join('.');
        rewrittenUrl = 'https://docs.' + domain + path;
      } else {
        // If domain structure is unclear, just change scheme
        rewrittenUrl = 'https://' + host + path;
      }
    } else {
      // Just upgrade the scheme, keep original host
      rewrittenUrl = 'https://' + host + path;
    }
    
    return rewrittenUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (isLeapYear) {
      daysInMonth[1] = 29;
    }
  }
  
  const maxDay = daysInMonth[month - 1];
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  // If validation passes, return the year
  return year.toString();
}
