export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  value = value.trim();
  
  // Basic structure check: local@domain.tld
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Check for double dots in domain
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain parts
  const domainParts = domainPart?.split('.') || [];
  for (const part of domainParts) {
    if (part.includes('_')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  // Reference the options parameter to avoid unused variable warning
  void options;
  
  // Remove all non-digit characters except leading + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Pattern to match US phone numbers with various formats
  const phonePattern = /^(?:\+?1[\s.-]?)?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  
  const match = cleaned.match(phonePattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const exchange = match[2];
  
  // Check for impossible area codes (0 or 1 as first digit)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check for impossible exchange codes (0 or 1 as first digit)
  if (exchange[0] === '0' || exchange[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except leading + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if number starts with country code +54
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3); // Remove +54
  }
  
  // Check for optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1); // Remove 9
  }
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !remaining.startsWith('0')) {
    return false;
  }
  
  if (!hasCountryCode && remaining.startsWith('0')) {
    remaining = remaining.slice(1); // Remove trunk prefix 0
  }
  
  // Now remaining should be: area code (2-4 digits, leading 1-9) + subscriber (6-8 digits)
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }
  
  // Extract area code (first 2-4 digits, but must be at least 6 total length for subscriber)
  let areaCodeLength = remaining.length <= 8 ? 2 : 3;
  
  // Check if we can have a 4-digit area code
  if (remaining.length >= 11) {
    areaCodeLength = 4;
  } else if (remaining.length >= 10) {
    // Could be 3 or 4, but 3 is more common, let's be flexible
    areaCodeLength = 3;
  }
  
  const areaCode = remaining.slice(0, areaCodeLength);
  const subscriberNumber = remaining.slice(areaCodeLength);
  
  // Area code must start with digit 1-9 (not 0)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // All remaining characters must be digits
  if (!/^\d+$/.test(areaCode) || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  value = value.trim();
  
  if (value.length === 0) {
    return false;
  }
  
  // Check for digits - names should not contain numbers
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols that are not allowed (excluding apostrophes, hyphens, spaces)
  // Allow unicode letters, apostrophes, hyphens, spaces, and accented characters
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional check: names should not be empty or just punctuation
  if (/^[\s'-]*$/.test(value)) {
    return false;
  }
  
  // Check for obviously invalid patterns like "X Æ A-12"
  // This is a simple pattern to catch some obvious fake names
  if (/^[xXæÆ]/.test(value) || /[\d-]{3,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card prefixes and lengths
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (cleaned.startsWith('4')) {
    isValidType = cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
           cleaned.startsWith('54') || cleaned.startsWith('55') ||
           (cleaned.startsWith('222') && cleaned.startsWith('2221', 0)) ||
           (cleaned.startsWith('2720'))) {
    isValidType = cleaned.length === 16;
  }
  
  // American Express: starts with 34 or 37, length 15
  else if (cleaned.startsWith('34') || cleaned.startsWith('37')) {
    isValidType = cleaned.length === 15;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i));
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
