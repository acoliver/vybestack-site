/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word pattern that matches the prefix at word boundaries
  const wordPattern = new RegExp(`\\b${prefix}[\\w-]*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case insensitive)
  const results = matches.filter(match => {
    return !exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    );
  });
  
  return [...new Set(results)]; // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to ensure token is after a digit but not at string start
  // (?<!^)\d ensures we don't match at string start but have a digit before token
  const pattern = `(?<!^)\\d(${escapeRegex(token)})`;
  
  const matches = text.match(new RegExp(pattern, 'gi')) || [];
  
  return matches; // Return full matches including the digit
}

// Helper function to escape special regex characters in token
function escapeRegex(token: string): string {
  return token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*(),.?":{}|<>[\]\\`~+-_=<>;:'"]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, ababab)
  // This pattern looks for sequences that repeat immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's an IPv4 address (we want to exclude these)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address pattern including shorthand notation
  // IPv6 addresses can be represented in several ways:
  // 1. Full 8 groups: 2001:0db8:0000:0000:0000:ff00:0042:8329
  // 2. With shorthand :: for consecutive zeros: 2001:db8::ff00:42:8329
  // 3. IPv4-mapped IPv6: ::ffff:192.0.2.1
  const ipv6Pattern = /\b(?:(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){1,7}:|(?:[a-fA-F0-9]{1,4}:){1,6}:[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){1,5}(?::[a-fA-F0-9]{1,4}){1,2}|(?:[a-fA-F0-9]{1,4}:){1,4}(?::[a-fA-F0-9]{1,4}){1,3}|(?:[a-fA-F0-9]{1,4}:){1,3}(?::[a-fA-F0-9]{1,4}){1,4}|(?:[a-fA-F0-9]{1,4}:){1,2}(?::[a-fA-F0-9]{1,4}){1,5}|[a-fA-F0-9]{1,4}:(?:(?::[a-fA-F0-9]{1,4}){1,6})|:(?:(?::[a-fA-F0-9]{1,4}){1,7}|:)|(?:[a-fA-F0-9]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}|(?:[a-fA-F0-9]{1,4}:){0,5}:(?:\d{1,3}\.){3}\d{1,3}|::(?:(?::[a-fA-F0-9]{1,4}){1,6}|:))\b/i;
  
  return ipv6Pattern.test(value);
}
