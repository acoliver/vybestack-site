const STANDARD_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate that a string contains only valid Base64 characters.
 * @param input The string to validate
 * @returns true if the string contains only valid Base64 characters
 */
function isValidBase64(input: string): boolean {
  // Check for invalid characters
  if (!STANDARD_BASE64_REGEX.test(input)) {
    return false;
  }

  // Check for padding in the middle of the string (invalid)
  const paddingIndex = input.indexOf('=');
  const hasPaddingInMiddle = paddingIndex !== -1 && input.slice(paddingIndex + 1).length > 0 && !input.slice(paddingIndex + 1).startsWith('=');
  if (hasPaddingInMiddle) {
    return false;
  }

  // Check length modulo 4 (Base64 strings must be multiple of 4 when padded,
  // but we'll accept unpadded strings that are valid modulo 4)
  const unpaddedLength = input.replace(/=+$/, '').length;
  return unpaddedLength !== 0;
}

/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 * @param input The UTF-8 string to encode
 * @returns Base64 encoded string with padding
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input is valid Base64 before attempting to decode.
 * @param input The Base64 string to decode
 * @returns The decoded UTF-8 string
 * @throws Error if the input is not valid Base64
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmed = input.trim();

  // Validate the input contains only valid Base64 characters
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  try {
    const decoded = Buffer.from(trimmed, 'base64');
    
    // Check if decoding was successful by checking if we got any data back
    // and if the input was valid (Buffer doesn't throw on invalid base64)
    if (decoded.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    // Additional validation: try to encode back and compare (normalized)
    // This catches cases like "a=b" which have valid chars but invalid structure
    const normalized = trimmed.padEnd(Math.ceil(trimmed.length / 4) * 4, '=');
    const reEncoded = decoded.toString('base64');
    if (reEncoded !== normalized && trimmed.replace(/=+$/, '') !== reEncoded.replace(/=+$/, '')) {
      throw new Error('Invalid Base64 input: malformed data');
    }

    return decoded.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
