import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';
import type { Database, SqlJsStatic } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3535', 10);
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

// Type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private SqlJs: SqlJsStatic | null = null;

  async init(): Promise<void> {
    const wasmPath = path.resolve(__dirname, '..', 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm');
    const SqlJsModule = await initSqlJs({
      locateFile: () => {
        return wasmPath;
      }
    });
    
    this.SqlJs = SqlJsModule;

    const dbExists = fs.existsSync(DB_PATH);
    if (dbExists) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      this.db = new SqlJsModule.Database(dbBuffer);
    } else {
      this.db = new SqlJsModule.Database();
      this.createSchema();
    }
  }

  private createSchema(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    this.db.run(schema);
  }

  insertSubmission(data: FormData): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    stmt.free();
    this.save();
  }

  save(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const data = this.db.export();
    fs.writeFileSync(DB_PATH, data);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

class Validator {
  static validateForm(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];
    
    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];
    
    requiredFields.forEach(field => {
      if (!data[field] || (typeof data[field] === 'string' && data[field].trim() === '')) {
        errors.push({ field, message: `${field} is required` });
      }
    });

    // Email validation
    if (data.email && !this.isValidEmail(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation (allow international formats)
    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !this.isValidPostalCode(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    return errors;
  }

  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private static isValidPhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  private static isValidPostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings (handles UK "SW1A 1AA" and simple formats)
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.length >= 3;
  }
}

async function main(): Promise<import('http').Server> {
  const app = express();
  const dbManager = new DatabaseManager();
  
  await dbManager.init();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(PUBLIC_DIR));
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [], 
      formData: {},
      pageTitle: 'Contact Us - Friendly International Form'
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName?.trim(),
      lastName: req.body.lastName?.trim(),
      streetAddress: req.body.streetAddress?.trim(),
      city: req.body.city?.trim(),
      stateProvince: req.body.stateProvince?.trim(),
      postalCode: req.body.postalCode?.trim(),
      country: req.body.country?.trim(),
      email: req.body.email?.trim(),
      phone: req.body.phone?.trim()
    };

    const errors = Validator.validateForm(formData);

    if (errors.length > 0) {
      return res.status(400).render('form', {
        errors,
        formData,
        pageTitle: 'Contact Us - Please Fix Errors'
      });
    }

    // Insert into database
    dbManager.insertSubmission(formData as FormData);
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', { 
      pageTitle: 'Thank You!'
    });
  });

  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('\nShutting down gracefully...');
    dbManager.close();
    process.exit(0);
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  // Start server
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  return server;
}

// Start the server
main().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default main;