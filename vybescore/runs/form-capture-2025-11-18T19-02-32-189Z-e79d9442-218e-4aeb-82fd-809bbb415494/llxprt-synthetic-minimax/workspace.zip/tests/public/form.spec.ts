import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', () => {
    // Verify the form template exists and has the right structure
    const formPath = path.resolve('src', 'templates', 'form.ejs');
    const formContent = fs.readFileSync(formPath, 'utf-8');
    
    expect(formContent).toContain('firstName');
    expect(formContent).toContain('lastName');
    expect(formContent).toContain('streetAddress');
    expect(formContent).toContain('city');
    expect(formContent).toContain('stateProvince');
    expect(formContent).toContain('postalCode');
    expect(formContent).toContain('country');
    expect(formContent).toContain('email');
    expect(formContent).toContain('phone');
    expect(formContent).toContain('action="/submit"');
    expect(formContent).toContain('method="post"');
  });

  it('has proper server structure', () => {
    const serverPath = path.resolve('src', 'server.ts');
    const serverContent = fs.readFileSync(serverPath, 'utf-8');
    
    expect(serverContent).toContain('express');
    expect(serverContent).toContain('sql.js');
    expect(serverContent).toContain('FormData');
    expect(serverContent).toContain('app.get(\'/\'');
    expect(serverContent).toContain('app.post(\'/submit\'');
    expect(serverContent).toContain('app.get(\'/thank-you\'');
  });

  it('has thank-you page template', () => {
    const thankYouPath = path.resolve('src', 'templates', 'thank-you.ejs');
    const thankYouContent = fs.readFileSync(thankYouPath, 'utf-8');
    
    expect(thankYouContent).toContain('Thank you');
    expect(thankYouContent).toContain('warning');
    expect(thankYouContent).toContain('disclaimer');
  });

  it('has styling for form and thank-you page', () => {
    const cssPath = path.resolve('public', 'styles.css');
    const cssContent = fs.readFileSync(cssPath, 'utf-8');
    
    expect(cssContent).toContain('.form-shell');
    expect(cssContent).toContain('.thankyou-card');
    expect(cssContent).toContain('.submit-btn');
    expect(cssContent).toContain('.error-summary');
  });

  it('has the server built successfully', () => {
    const serverPath = path.resolve('dist', 'server.js');
    expect(fs.existsSync(serverPath)).toBe(true);
    
    const serverContent = fs.readFileSync(serverPath, 'utf-8');
    expect(serverContent).toContain('express');
    expect(serverContent).toContain('DatabaseManager');
    expect(serverContent).toContain('Validator');
    expect(serverContent).toContain('main');
  });

  it('has database schema', () => {
    const schemaPath = path.resolve('db', 'schema.sql');
    expect(fs.existsSync(schemaPath)).toBe(true);
    
    const schemaContent = fs.readFileSync(schemaPath, 'utf-8');
    expect(schemaContent).toContain('submissions');
    expect(schemaContent).toContain('CREATE TABLE');
  });
});