#!/usr/bin/env node

import { readFileSync } from 'fs';
import { writeFile } from 'fs/promises';
import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command-line arguments
 */
function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  
  if (!args.includes('--format')) {
    console.error('Missing required --format option');
    process.exit(1);
  }

  const formatIndex = args.indexOf('--format');
  const format = args[formatIndex + 1];
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

/**
 * Load and parse JSON data from file
 */
function loadData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    return JSON.parse(content) as ReportData;
  } catch (error) {
    console.error(`Error loading data file: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

/**
 * Validate report data structure
 */
function validateData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    console.error('Invalid data: expected JSON object');
    process.exit(1);
  }

  const dataObj = data as Record<string, unknown>;

  if (!dataObj.title || typeof dataObj.title !== 'string') {
    console.error('Invalid data: missing or invalid "title" field');
    process.exit(1);
  }

  if (!dataObj.summary || typeof dataObj.summary !== 'string') {
    console.error('Invalid data: missing or invalid "summary" field');
    process.exit(1);
  }

  if (!Array.isArray(dataObj.entries)) {
    console.error('Invalid data: missing or invalid "entries" array');
    process.exit(1);
  }

  for (const entry of dataObj.entries) {
    if (!entry || typeof entry !== 'object') {
      console.error('Invalid data: entries must be objects');
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      console.error('Invalid data: each entry must have a "label" string');
      process.exit(1);
    }

    if (typeof entryObj.amount !== 'number') {
      console.error('Invalid data: each entry must have an "amount" number');
      process.exit(1);
    }
  }

  return data as ReportData;
}

/**
 * Get the appropriate renderer for the requested format
 */
function getRenderer(format: string): ReportRenderer {
  const formatMap: Record<string, typeof renderMarkdown | typeof renderText> = {
    markdown: renderMarkdown,
    text: renderText
  };

  const renderer = formatMap[format];
  if (!renderer) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return renderer as ReportRenderer;
}

/**
 * Main function
 */
function main(): void {
  const args = process.argv;
  const { dataFile, format, outputPath, includeTotals } = parseArgs(args);

  const rawData = loadData(dataFile);
  const reportData = validateData(rawData);
  const renderer = getRenderer(format);

  const options: RenderOptions = {
    includeTotals
  };

  const output = renderer(reportData, options);

  if (outputPath) {
    writeFile(outputPath, output)
      .then(() => {
        console.log(`Report written to ${outputPath}`);
      })
      .catch((error) => {
        console.error(`Error writing output file: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      });
  } else {
    console.log(output);
  }
}

// Run the CLI
main();