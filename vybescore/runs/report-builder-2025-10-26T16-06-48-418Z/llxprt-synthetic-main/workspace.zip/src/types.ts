/**
 * Data model for a report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Data model for a complete report
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering a report
 */
export interface RenderOptions {
  includeTotals?: boolean;
}

/**
 * Renderer function interface for formatters
 */
export type ReportRenderer = (data: ReportData, options: RenderOptions) => string;