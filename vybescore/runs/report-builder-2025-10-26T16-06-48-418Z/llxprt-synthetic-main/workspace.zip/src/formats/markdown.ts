import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

/**
 * Renders a report in markdown format
 */
export function renderMarkdown(data: ReportData, options?: RenderOptions): string {
  const lines = [];
  
  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  
  data.entries.forEach(entry => {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  });
  
  if (options?.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`\n**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}

/**
 * Create a markdown renderer function with the given options
 */
export function createMarkdownRenderer(options?: RenderOptions): ReportRenderer {
  return (data: ReportData) => renderMarkdown(data, options);
}