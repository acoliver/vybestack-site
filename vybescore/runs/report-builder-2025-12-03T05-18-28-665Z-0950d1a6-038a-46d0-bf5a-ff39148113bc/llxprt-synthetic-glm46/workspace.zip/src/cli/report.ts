#!/usr/bin/env node

import * as fs from 'node:fs';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  if (!dataFile) {
    console.error('Error: JSON data file path is required');
    process.exit(1);
  }
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format option is required');
    process.exit(1);
  }
  
  const formatValue = args[formatIndex + 1];
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    console.error('Error: Unsupported format. Supported formats are: markdown, text');
    process.exit(1);
  }
  
  const format = formatValue as 'markdown' | 'text';
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Validate the data structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    const entries = reportData.entries as unknown[];
    
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid "label" field`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid "amount" field`);
      }
      
      if (entryObj.amount < 0) {
        throw new Error(`Invalid JSON: entry at index ${i} has negative amount`);
      }
    }
    
    return {
      title: reportData.title,
      summary: reportData.summary,
      entries: entries.map(entry => {
        const entryObj = entry as { label: string; amount: number };
        return {
          label: entryObj.label,
          amount: entryObj.amount,
        };
      }),
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Malformed JSON file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to load report data');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: ReportOptions, format: 'markdown' | 'text'): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
}

function main(): void {
  const args = parseArguments();
  const reportData = loadReportData(args.dataFile);
  
  const options: ReportOptions = {
    includeTotals: args.includeTotals,
  };
  
  const output = renderReport(reportData, options, args.format);
  
  if (args.outputPath) {
    fs.writeFileSync(args.outputPath, output, 'utf8');
    console.log(`Report written to ${args.outputPath}`);
  } else {
    console.log(output);
  }
}

main();
