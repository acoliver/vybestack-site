import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: import('node:http').Server;
let app: import('express').Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the server module dynamically to avoid ESM import issues
  const serverModule = await import('../../src/server.js');
  
  // Use the exported app
  app = serverModule.default || serverModule.app;
  
  // Start the server manually for testing
  const serverResult = await serverModule.startServer();
  if (serverResult) {
    server = serverResult.server;
  }
  
  // Wait for server to be ready
  await new Promise(resolve => setTimeout(resolve, 500));
});

afterAll(async () => {
  if (server && server.close) {
    server.close();
  }
  // Close database connection after tests
  const { closeDatabase } = await import('../../src/database.js');
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const html = response.text;
    const $ = cheerio.load(html);

    // Check that all required form fields are present
    expect($('form[method="POST"]').length).toBe(1);
    expect($('input[name="first_name"]').length).toBe(1);
    expect($('input[name="last_name"]').length).toBe(1);
    expect($('input[name="street_address"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="state_province"]').length).toBe(1);
    expect($('input[name="postal_code"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Springfield',
      state_province: 'Illinois',
      postal_code: '62701',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);

    // Check redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');

    // Verify the database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
