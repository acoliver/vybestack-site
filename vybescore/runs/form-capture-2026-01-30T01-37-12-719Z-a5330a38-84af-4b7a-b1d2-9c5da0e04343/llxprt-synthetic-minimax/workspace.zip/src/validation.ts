import { ContactSubmission } from './database.js';

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow international formats like @44 20 7946 0958, @54 9 11 1234-5678
  // Accept digits, spaces, parentheses, dashes, @, and + for country codes
  const phoneRegex = /^[+]?@?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function isValidPostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handle UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

export function validateSubmission(data: Partial<ContactSubmission>): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ] as const;

  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim().length === 0) {
      errors.push({
        field: field,
        message: `${field.replace('_', ' ')} is required`
      });
    }
  }

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !isValidPhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  if (data.postal_code && !isValidPostalCode(data.postal_code)) {
    errors.push({
      field: 'postal_code',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}