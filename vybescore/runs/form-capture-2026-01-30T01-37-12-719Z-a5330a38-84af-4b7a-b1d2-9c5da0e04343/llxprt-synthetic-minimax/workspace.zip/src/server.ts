import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, closeDatabase, insertSubmission } from './database.js';
import { validateSubmission } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Body parser middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('index', { 
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData = {
    first_name: req.body.first_name?.trim(),
    last_name: req.body.last_name?.trim(),
    street_address: req.body.street_address?.trim(),
    city: req.body.city?.trim(),
    state_province: req.body.state_province?.trim(),
    postal_code: req.body.postal_code?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim()
  };

  const validation = validateSubmission(formData);

  if (!validation.isValid) {
    return res.status(400).render('index', {
      errors: validation.errors,
      formData: formData
    });
  }

  try {
    insertSubmission(formData);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('index', {
      errors: [{ field: 'general', message: 'Internal server error. Please try again.' }],
      formData: formData
    });
  }
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

type HttpServer = import('node:http').Server;

export async function startServer(): Promise<{ app: express.Application, server: HttpServer } | void> {
  try {
    await initializeDatabase();
    const server: HttpServer = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server reference for graceful shutdown
    app.set('server', server);

    return { app, server };
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Auto-start server only if this module is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

// Export app for testing
export default app;
