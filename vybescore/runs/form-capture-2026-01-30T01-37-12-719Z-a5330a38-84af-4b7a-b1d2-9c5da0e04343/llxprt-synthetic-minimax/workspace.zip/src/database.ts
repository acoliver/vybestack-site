import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

export interface ContactSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let sql: any = null; // sql.js module - using any to avoid ESM type issues
let db: Database | null = null;

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

export async function initializeDatabase(): Promise<void> {
  if (!sql) {
    sql = await initSqlJs({
      locateFile: (file: string) => {
        // For sql.js WASM file
        return `node_modules/sql.js/dist/${file}`;
      }
    });
  }

  if (!fs.existsSync(path.dirname(DB_PATH))) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    db = new (sql as any).Database(fileBuffer);
  } else {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    db = new (sql as any).Database();
  }

  // Initialize schema for new database
  if (!fs.existsSync(DB_PATH)) {
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (db as any).exec(schema);
  }
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized.');
  }
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Error saving database:', error);
    throw error;
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export function insertSubmission(submission: ContactSubmission): void {
  const database = getDatabase();
  
  const stmt = database.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone
  ]);

  stmt.free();
  saveDatabase();
}