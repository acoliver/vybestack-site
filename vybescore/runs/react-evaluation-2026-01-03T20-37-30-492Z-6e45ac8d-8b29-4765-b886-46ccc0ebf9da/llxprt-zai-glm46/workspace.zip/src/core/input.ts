/**
 * Input closure implementation for reactive primitives.
 */

import type { InputPair, Subject, Observer, EqualFn, GetterFn, SetterFn, Options } from '../types/reactive.js'
import { getActiveObserver, updateObserver, isObserverDisposed } from '../types/reactive.js'

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'function') return equal
  if (equal === false) return undefined
  return (lhs: T, rhs: T) => lhs === rhs
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: normalizeEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !isObserverDisposed(observer)) {
      s.observers.add(observer)
      // Track this subject in the observer for cleanup
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      observer.subjects.add(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = s.equalFn || ((lhs: T, rhs: T) => lhs === rhs)
    if (equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    
    // Notify all observers
    for (const observer of s.observers) {
      if (!isObserverDisposed(observer)) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    
    return s.value
  }

  return [read, write]
}
