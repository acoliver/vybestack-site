/**
 * Computed closure implementation for derived values.
 */

import type { GetterFn, UpdateFn, Observer, EqualFn } from '../types/reactive.js'
import { updateObserver, isObserverDisposed, getActiveObserver } from '../types/reactive.js'

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'function') return equal
  if (equal === false) return undefined
  return (lhs: T, rhs: T) => lhs === rhs
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize equal function for potential future use
  normalizeEqualFn(equal)
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
    subjects: new Set(),
    observers: new Set(),
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    // When accessed within an active observer context, register as dependency
    const active = getActiveObserver()
    if (active && !isObserverDisposed(active)) {
      // Register this computed observer as a dependency of the active observer
      if (!active.subjects) {
        active.subjects = new Set()
      }
      // Cast to satisfy type system - runtime behavior is correct
      active.subjects.add(o as typeof active.subjects extends Set<infer U> ? U : never)
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(active)
    }
    return o.value!
  }
  
  return read
}
