/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a pattern to match words with the prefix
  // Word boundaries ensure we match whole words
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all potential matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches
    .filter(match => !exceptionSet.has(match.toLowerCase()))
    .filter((match, index, array) => array.indexOf(match) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token when preceded by a digit and not at string start
  // Using a workaround for lookbehinds to check for digit before token
  const pattern = new RegExp(`(?:\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  return [...new Set(matches)]; // Return unique matches
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[~`!@#$%^&*()_+\-={}\[\]\\|;:'"<>,.?\/]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // This pattern looks for a 2-4 character sequence that repeats immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If the entire value is an IPv4 address, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 address pattern (full and shorthand)
  // This pattern matches:
  // - Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Compressed IPv6 with :: shorthand
  // - IPv6 with embedded IPv4
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|([0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}|::ffff:(\d{1,3}\.){3}\d{1,3})/;
  
  return ipv6Pattern.test(value);
}