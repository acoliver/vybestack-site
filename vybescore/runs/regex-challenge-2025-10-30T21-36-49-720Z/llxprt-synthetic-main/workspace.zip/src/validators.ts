export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject emails with double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Reject emails ending with a dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check if domain has underscores (not allowed in domain)
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Remove optional +1 country code
  const strippedDigits = digits.startsWith('1') && digits.length > 10 ? 
    digits.substring(1) : digits;
  
  // Must be exactly 10 digits after stripping country code
  if (strippedDigits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = strippedDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the format matches one of the valid patterns
  const usPhonePatterns = [
    /^\+?1?\s*\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/, // (212) 555-7890, 212-555-7890
    /^\+?1?\s*\d{3}[\s-]?\d{3}[\s-]?\d{4}$/,        // 212 555 7890, 2125557890
  ];
  
  return usPhonePatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other non-digit characters except for +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix
  // Optional 9 for mobile
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0|9)?([2-9]\d{1,3})(\d{6,8})$/;
  
  // Check if matches the pattern
  const match = argentinePhoneRegex.exec(cleaned);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code must be 2-4 digits starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols like Æ
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  // Special check for names with unusual symbols like X Æ A-12
  if (/Æ|\d|[^\p{L}'\-\s]/u.test(value)) {
    return false;
  }
  
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const digits = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Check Visa (13 or 16 digits, starts with 4)
  // Mastercard (16 digits, starts with 51-55 or 2221-2720)
  // Amex (15 digits, starts with 34 or 37)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-5]\d|4[0-9]\d|5[01]\d|620)\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}