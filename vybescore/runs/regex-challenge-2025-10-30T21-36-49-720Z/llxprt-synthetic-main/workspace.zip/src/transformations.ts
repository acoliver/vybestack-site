/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim() === '') {
    return text;
  }

  // First, normalize spacing between sentences
  // Add a space after sentence endings if there isn't one and the next character isn't already a space
  const normalizedSpacing = text.replace(/([.?!])(?=[A-Za-z])(?!\s)/g, '$1 ');
  
  // Then, split into sentences and capitalize each
  return normalizedSpacing.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // URL regex pattern
  const urlPattern = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/\/=]*)/g;
  
  // Find all matches
  const matches = text.match(urlPattern);
  
  // If no matches, return empty array
  if (!matches) {
    return [];
  }
  
  // Process each match to remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,!?;:) etc.
    return url.replace(/[.,!?;:)$/]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Pattern to match http://example.com/... URLs
  // Group 1: example.com
  // Group 2: path (everything after the domain)
  const urlPattern = /http:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, domain, path) => {
    // Always upgrade to https
    const httpsUrl = `https://${domain}${path}`;
    
    // Check if path contains dynamic hints or legacy extensions
    const dynamicHints = /(?:cgi-bin|[?.=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
      // Rewrite to https://docs.example.com/...
      return `https://docs.${domain}${path}`;
    }
    
    // Just upgrade to https if conditions aren't met for host rewrite
    return httpsUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string for return
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days in each month (simplified, not accounting for leap years in february)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  
  // Special case for February 29 on leap years
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Leap year: divisible by 4 but not by 100, or divisible by 400
    if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
      return year;
    }
    return 'N/A';
  }
  
  // Check if day is valid for the month
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return year;
}