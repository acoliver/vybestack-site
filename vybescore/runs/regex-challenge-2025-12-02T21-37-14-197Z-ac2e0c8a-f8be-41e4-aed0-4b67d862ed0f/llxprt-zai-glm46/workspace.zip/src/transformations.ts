/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Capitalizes after sentence-ending punctuation (.?!), inserts exactly one space between sentences,
 * and collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Common abbreviations that don't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e'];
  
  // Step 1: Insert proper spacing between sentences
  // Add space after sentence-ending punctuation if not present
  let result = text.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Step 2: Collapse multiple spaces into single spaces
  result = result.replace(/\s+/g, ' ');

  // Step 3: Trim leading and trailing whitespace
  result = result.trim();

  // Step 4: Capitalize first letter of sentences
  // Use a more sophisticated approach to avoid capitalizing after abbreviations
  const sentences = result.split(/([.!?]\s)/);
  
  let capitalizeNext = true;
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (capitalizeNext && sentence.length > 0) {
      // Capitalize first letter of the sentence
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      capitalizeNext = false;
    }
    
    // Check if this segment ends with sentence punctuation
    if (/[.!?]\s?$/.test(sentence)) {
      // Look ahead to see if the next sentence starts with an abbreviation
      const nextIndex = i + 1;
      if (nextIndex < sentences.length) {
        const nextText = result.substring(
          result.indexOf(sentence) + sentence.length,
          result.indexOf(sentence) + sentence.length + 50
        );
        
        // Check if the next text starts with an abbreviation
        const hasAbbreviation = abbreviations.some(abbr => 
          nextText.toLowerCase().startsWith(abbr.toLowerCase() + '.')
        );
        
        if (!hasAbbreviation) {
          capitalizeNext = true;
        }
      }
    }
  }

  return sentences.join('');
}

/**
 * Find URLs in the text and return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // URL regex pattern that matches:
  // - http://, https://, and protocol-relative URLs
  // - www. subdomains
  // - Domain names with various TLDs
  // - IP addresses
  // - Ports, paths, query strings, fragments
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+[^\\\s<>"'.,!?,?:;]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,!?;:]+$/, '');
  }).filter(url => url.length > 0); // Filter out empty strings
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https://, but be careful not to match https:// (which would become httpss://)
  return text.replace(/https?:\/\//g, (match) => {
    if (match === 'https://') {
      return match; // Already secure, leave unchanged
    }
    return 'https://'; // Upgrade http:// to https://
  });
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https://. When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
// Pattern to match URLs in the text
const urlRegex = new RegExp('(https?://)([^/\\s]+)(/[^\\s]*)?', 'gi');

  return text.replace(urlRegex, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if we should skip host rewrite
    // Check if we should skip host rewrite
  const skipHostRewrite = /(?:cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    // If this is a docs path and we shouldn't skip host rewrite
    if (isDocsPath && !skipHostRewrite) {
      // Extract the domain from the host (remove subdomains like www)
      const domainMatch = host.match(/(?:www\.)?([^/]+)/);
      const domain = domainMatch ? domainMatch[1] : host;
      
      // Rewrite to docs.example.com
      return secureProtocol + 'docs.' + domain + path;
    }
    
    // Otherwise, just upgrade the scheme
    return secureProtocol + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Regex to match mm/dd/yyyy format and capture month, day, and year
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }

  // Additional validation for specific months (e.g., February)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified - doesn't account for century rules)
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  if (month === 2 && isLeapYear) {
    if (day > 29) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}