/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }

  // Escape the prefix for regex special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to find words starting with the prefix
  // \b ensures we match whole words only
  // [a-zA-Z]+ matches the rest of the word (letters only)
  const wordRegex = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*', 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and remove duplicates
  const filteredWords = matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptionsLower.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
  
  return filteredWords;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape the token for regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find occurrences of the token that are preceded by a digit
  // Use a regex that matches digit+token
  const regex = new RegExp('\\d' + escapedToken, 'g');
  const matches = text.match(regex) || [];
  
  // Remove duplicates while preserving order
  const uniqueMatches = matches.filter((match, index, arr) => arr.indexOf(match) === index);
  
  return uniqueMatches;
}

/**
 * Validate passwords according to the policy: at least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc)
  // This regex detects patterns where a sequence of 2+ characters is repeated immediately
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Split the string into tokens and check each one individually
  // This ensures we don't mistakenly identify IPv4 addresses as IPv6
  const tokens = value.split(/\s+/);
  
  for (const token of tokens) {
    // Check if this token looks like an IPv4 address first
    const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (ipv4Pattern.test(token)) {
      continue; // Skip IPv4 addresses
    }

    // IPv6 regex pattern that matches various IPv6 formats:
    // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    // - Shorthand with :: : 2001:db8::8a2e:370:7334
    // - Loopback: ::1
    // - Compressed: ::
    const ipv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^(?:[0-9a-fA-F]{1,4}:){1,7}:|^:(?:[0-9a-fA-F]{1,4}:){1,7}$|^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}$|^(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}$|^(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}$|^(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}$|^(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}$|^[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})$|^:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)$|^::1$|^::$/;

    if (ipv6Pattern.test(token)) {
      return true;
    }
  }

  return false;
}