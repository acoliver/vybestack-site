export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses robustly.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dots in local part or domain
  if (value.endsWith('.') || value.includes('.@') || value.includes('@.')) {
    return false;
  }

  // Reject underscores in domain
  if (value.includes('_') && value.split('@')[1]?.includes('_')) {
    return false;
  }

  // Email regex pattern
  // Local part: letters, digits, +, -, . (but not consecutive dots)
  // Domain: letters, digits, hyphens, dots, with TLD of 2-63 letters
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9+.-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;

  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common separators and optional +1.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Clean up the phone number - remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must have at least 10 digits
  const digitsOnly = cleaned.replace(/\+/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }

  // Extract area code (first 3 digits after optional country code)
  let areaCode: string;
  if (cleaned.startsWith('+1')) {
    areaCode = digitsOnly.substring(0, 3);
  } else if (cleaned.startsWith('1') && digitsOnly.length === 11) {
    areaCode = digitsOnly.substring(1, 4);
  } else {
    areaCode = digitsOnly.substring(0, 3);
  }

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Main regex pattern for US phone validation
  // Optional +1 country code
  // Optional parentheses around area code
  // Various separators: space, hyphen, dot, or none
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(?([2-9]\d{2})\)?[\s-]?)([2-9]\d{2})[\s-]?(\d{4})(?:\s*(?:ext\.?|extension)\s*\d+)?$/i;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Clean up the input - remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern:
  // ^\+54          - Optional country code
  // [\s-]?9?       - Optional mobile indicator 9
  // [\s-]?         - Optional separator
  // [1-9]\d{1,3}   - Area code (2-4 digits, not starting with 0)
  // [\s-]?\d{6,8}$ - Subscriber number (6-8 digits)
  // OR (without country code):
  // ^0             - Required trunk prefix when no country code
  // [1-9]\d{1,3}   - Area code (2-4 digits, not starting with 0)
  // [\s-]?\d{6,8}$ - Subscriber number (6-8 digits)
  
  const argentinePhoneRegex = /^(\+54[\s-]?9?|0)([1-9]\d{1,3})[\s-]?(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, , areaCode, subscriber] = match;

  // Additional validation:
  // If no country code, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }

  // Area code validation: 2-4 digits, starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }

  // Subscriber number validation: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphenation, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Trim whitespace and check for empty string
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }

  // Reject names with digits or mathematical symbols
  if (/\d|[Ææ]/.test(trimmed)) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Unicode property \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (accents, diacritics)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must start and end with a letter (not with apostrophe, hyphen, or space)
  const startsAndEndsWithLetter = /^[\p{L}\p{M}].*[\p{L}\p{M}]$/u.test(trimmed);
  
  // Check for multiple consecutive spaces or punctuation
  const hasConsecutiveSpaces = /\s{2,}/.test(trimmed);
  const hasConsecutiveApostrophes = /'{2,}/.test(trimmed);
  const hasConsecutiveHyphens = /-{2,}/.test(trimmed);
  
  return nameRegex.test(trimmed) && 
         startsAndEndsWithLetter && 
         !hasConsecutiveSpaces && 
         !hasConsecutiveApostrophes && 
         !hasConsecutiveHyphens;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express.
 * Performs Luhn checksum validation and checks appropriate prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if it's all digits and has valid length
  if (!/^\d+$/.test(cardNumber) || cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16
  if (cardNumber.startsWith('4')) {
    return (cardNumber.length === 13 || cardNumber.length === 16) && runLuhnCheck(cardNumber);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (cardNumber.length === 16) {
    const startsWith51to55 = /^5[1-5]/.test(cardNumber);
    const startsWith2221to2720 = /^2(2[2-9]|[3-6]\d|7[01-2])/.test(cardNumber);
    
    if (startsWith51to55 || startsWith2221to2720) {
      return runLuhnCheck(cardNumber);
    }
  }
  
  // American Express: starts with 34 or 37, length 15
  if (cardNumber.length === 15 && (cardNumber.startsWith('34') || cardNumber.startsWith('37'))) {
    return runLuhnCheck(cardNumber);
  }

  return false;
}
