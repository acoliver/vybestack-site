/**
 * Form Configuration Panel
 * Manages JSON schema configuration for form elements
 */

import React, { useState, useCallback } from 'react';
import { useFormContext } from '../contexts/FormContext';
import { registerTool } from '../tool-registry';
import { useToast } from '../contexts/ToastContext';

/**
 * Configuration Panel Component
 * Renders UI for editing form field configuration via JSON schema
 */
function ConfigurationPanel({ onFieldsChange }) {
  const { formData, setFormData, exportSchema, importSchema } = useFormContext();
  const [isConfigExpanded, setIsConfigExpanded] = useState(false);
  const [isValidJson, setIsValidJson] = useState(true);
  const { addToast } = useToast();

  // Handle JSON schema changes
  const handleSchemaChange = useCallback((e) => {
    const content = e.target.value;
    
    try {
      // Try to parse the JSON
      const schema = JSON.parse(content);
      
      // Update the schema
      setFormData({ ...formData, schema });
      
      // Notify the parent component of the schema change
      if (onFieldsChange) {
        onFieldsChange(schema.fields);
      }
      
      setIsValidJson(true);
      addToast('Schema updated successfully', 'success');
    } catch (error) {
      console.error('Invalid JSON schema:', error);
      setIsValidJson(false);
      addToast('Invalid JSON schema', 'error');
    }
  }, [formData, setFormData, onFieldsChange, addToast]);

  // Load default schema
  const loadDefaultSchema = useCallback(() => {
    const defaultSchema = {
      title: "Sample Form",
      description: "A sample form with various field types",
      type: "object",
      required: ["firstName", "email"],
      properties: {
        firstName: {
          type: "string",
          title: "First Name",
          description: "Enter your first name",
          minLength: 2,
          maxLength: 50
        },
        lastName: {
          type: "string",
          title: "Last Name",
          description: "Enter your last name",
          minLength: 2,
          maxLength: 50
        },
        email: {
          type: "string",
          title: "Email",
          description: "Enter your email address",
          format: "email"
        },
        age: {
          type: "number",
          title: "Age",
          description: "Enter your age",
          minimum: 18,
          maximum: 120
        },
        country: {
          type: "string",
          title: "Country",
          enum: ["US", "CA", "UK", "AU", "Other"],
          default: "US"
        },
        newsletter: {
          type: "boolean",
          title: "Subscribe to Newsletter",
          description: "Subscribe to our weekly newsletter",
          default: false
        },
        comments: {
          type: "string",
          title: "Comments",
          description: "Any additional comments",
          maxLength: 500
        }
      }
    };
    
    setFormData({ ...formData, schema: defaultSchema });
    addToast('Default schema loaded', 'success');
  }, [formData, setFormData, addToast]);

  // Render the panel
  return (
    <div className="bg-gray-100 border border-gray-300 rounded-md mb-4">
      <div 
        className="flex justify-between items-center p-3 cursor-pointer bg-gray-200 hover:bg-gray-300 rounded-t-md"
        onClick={() => setIsConfigExpanded(!isConfigExpanded)}
      >
        <h3 className="font-medium">Form Configuration</h3>
        <span className="text-sm">
          {isConfigExpanded ? '▼' : '▶'} Click to {isConfigExpanded ? 'collapse' : 'expand'}
        </span>
      </div>
      
      {isConfigExpanded && (
        <div className="p-3">
          <div className="mb-3 flex justify-between items-center">
            <h4 className="font-medium">JSON Schema Editor</h4>
            <div>
              <button
                className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 mr-2"
                onClick={() => {
                  const fileInput = document.createElement('input');
                  fileInput.type = 'file';
                  fileInput.accept = '.json';
                  fileInput.onchange = (e) => {
                    if (e.target.files && e.target.files[0]) {
                      const fileReader = new FileReader();
                      fileReader.onloadend = () => {
                        try {
                          const schema = JSON.parse(fileReader.result);
                          setFormData({ ...formData, schema });
                          addToast('Schema imported successfully', 'success');
                          if (onFieldsChange) {
                            onFieldsChange(schema.fields);
                          }
                        } catch (error) {
                          console.error('Error importing schema:', error);
                          addToast('Error importing schema. Please check the file format.', 'error');
                        }
                      };
                      fileReader.readAsText(e.target.files[0]);
                    }
                  };
                  fileInput.click();
                }}
              >
                Import
              </button>
              
              <button
                className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 mr-2"
                onClick={() => {
                  const dataStr = JSON.stringify(formData.schema, null, 2);
                  const dataBlob = new Blob([dataStr], { type: 'application/json' });
                  const url = URL.createObjectURL(dataBlob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = 'form-schema.json';
                  link.click();
                  URL.revokeObjectURL(url);
                  addToast('Schema exported successfully', 'success');
                }}
              >
                Export
              </button>
              
              <button
                className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700"
                onClick={loadDefaultSchema}
              >
                Reset to Default
              </button>
            </div>
          </div>
          
          <div className={`border ${isValidJson ? 'border-gray-300' : 'border-red-500'} rounded-md`}>
            <textarea
              className="w-full h-64 p-2 font-mono text-sm bg-white"
              value={JSON.stringify(formData.schema, null, 2)}
              onChange={handleSchemaChange}
              placeholder="Enter JSON schema here..."
            />
          </div>
          
          {!isValidJson && (
            <div className="mt-2 p-2 bg-red-100 text-red-700 text-sm rounded">
              Invalid JSON schema. Please check the syntax and try again.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Register this tool with the registry
registerTool('form-capture-config-panel', {
  label: 'Form Configuration',
  icon: 'settings',
  category: 'form',
  description: 'Configure form fields via JSON schema',
  component: ConfigurationPanel,
  acceptsMultipleInstances: false
});

export default ConfigurationPanel;