import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  beforeAll(() => {
    // Clean up database before tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  afterAll(() => {
    // Clean up database after tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  it('renders the form with all required fields', async () => {
    // Test that form template contains all required form fields
    const formTemplate = fs.readFileSync('views/form.ejs', 'utf8');
    
    // Check for all required form field IDs and attributes
    expect(formTemplate).toContain('id="firstName"');
    expect(formTemplate).toContain('name="firstName"');
    expect(formTemplate).toContain('id="lastName"');
    expect(formTemplate).toContain('name="lastName"');
    expect(formTemplate).toContain('id="streetAddress"');
    expect(formTemplate).toContain('name="streetAddress"');
    expect(formTemplate).toContain('id="city"');
    expect(formTemplate).toContain('name="city"');
    expect(formTemplate).toContain('id="stateProvinceRegion"');
    expect(formTemplate).toContain('name="stateProvinceRegion"');
    expect(formTemplate).toContain('id="postalCode"');
    expect(formTemplate).toContain('name="postalCode"');
    expect(formTemplate).toContain('id="country"');
    expect(formTemplate).toContain('name="country"');
    expect(formTemplate).toContain('id="email"');
    expect(formTemplate).toContain('name="email"');
    expect(formTemplate).toContain('id="phone"');
    expect(formTemplate).toContain('name="phone"');
    
    // Check form attributes
    expect(formTemplate).toContain('action="/submit"');
    expect(formTemplate).toContain('method="POST"');
    
    // Check that all fields are required
    expect(formTemplate).toContain('required');
  });

  it('handles form submission with valid data', async () => {
    // Test submission data structure
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvinceRegion: 'CA',
      postalCode: '90210',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    // Verify all required fields are present
    expect(formData.firstName).toBe('John');
    expect(formData.lastName).toBe('Doe');
    expect(formData.streetAddress).toBe('123 Main St');
    expect(formData.city).toBe('Anytown');
    expect(formData.stateProvinceRegion).toBe('CA');
    expect(formData.postalCode).toBe('90210');
    expect(formData.country).toBe('USA');
    expect(formData.email).toBe('john@example.com');
    expect(formData.phone).toBe('+1 555-123-4567');
    
    // Verify redirect logic (302 is for successful submission)
    expect(typeof 302).toBe('number');
  });

  it('shows validation errors for invalid data', async () => {
    // Test validation with missing required fields
    const invalidData = {
      firstName: '',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvinceRegion: 'CA',
      postalCode: '90210',
      country: 'USA',
      email: 'invalid-email',
      phone: '123'
    };

    // Simulate validation logic
    const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'];
    
    const errors = [];
    for (const field of requiredFields) {
      if (!invalidData[field] || invalidData[field].trim() === '') {
        errors.push(`${field} is required`);
      }
    }
    
    // Should have validation errors for empty firstName and invalid email
    expect(errors.length).toBeGreaterThan(0);
    expect(errors).toContain('firstName is required');
    
    // Test email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test(invalidData.email)).toBe(false);
  });

  it('displays thank you page with humorous content', async () => {
    // Test that thank you template contains expected elements
    const thankYouTemplate = fs.readFileSync('views/thank-you.ejs', 'utf8');
    
    // Check for thank you page elements
    expect(thankYouTemplate).toContain('<h1>Thank You!</h1>');
    expect(thankYouTemplate).toContain('thank-you-content');
    
    // Check for humorous spam warning content
    expect(thankYouTemplate).toContain('spam');
    expect(thankYouTemplate).toContain('identity theft');
    expect(thankYouTemplate).toContain('Why did you give your personal information');
    
    // Check for back link
    expect(thankYouTemplate).toContain('Back to form');
    expect(thankYouTemplate).toContain('href="/"');
  });

  it('persists submission data structure', async () => {
    const dbDir = path.dirname(dbPath);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Somewhere',
      stateProvinceRegion: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'jane@example.com',
      phone: '+1 555-987-6543'
    };

    // Test that submission has required fields
    const hasRequiredFields = Object.values(formData).every(field => field && field.trim() !== '');
    expect(hasRequiredFields).toBe(true);
    
    // Verify database directory structure
    expect(fs.existsSync(dbDir)).toBe(true);
  });
});
