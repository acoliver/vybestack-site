import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dbManager } from './database.js';
import { FormValidator } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Configure view engine and middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Form',
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation = FormValidator.validateSubmission(req.body);

  if (!validation.valid) {
    // Re-render form with errors and previously entered values
    return res.status(400).render('form', {
      title: 'Contact Form',
      errors: validation.errors,
      formData: req.body
    });
  }

  // Successful submission
  if (validation.data) {
    dbManager.insertSubmission(validation.data);
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Initialize database for testing
async function initializeForTesting() {
  await dbManager.initialize();
}

// Server startup function
async function startServer() {
  try {
    await dbManager.initialize();
    console.log(`Database initialized`);

    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('Received SIGTERM, shutting down gracefully');
      server.close(() => {
        dbManager.close();
        console.log('Server and database connections closed');
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export app and start function for testing
export { app };
export { startServer };
export { initializeForTesting };

// Start the server only if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
