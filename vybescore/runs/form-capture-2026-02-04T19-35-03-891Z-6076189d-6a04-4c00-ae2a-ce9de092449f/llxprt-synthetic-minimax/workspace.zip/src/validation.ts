import { FormSubmission } from './database.js';

export interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvinceRegion?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  data?: FormSubmission;
}

export class FormValidator {
  static validateSubmission(data: FormData): ValidationResult {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
    ] as const;

    for (const field of requiredFields) {
      const fieldValue = data[field];
      if (!fieldValue || fieldValue.trim() === '') {
        errors.push({
          field,
          message: `${this.formatFieldName(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email && data.email.trim() !== '') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation (allow international formats)
    if (data.phone && data.phone.trim() !== '') {
      const phoneRegex = /^\+?[\d\s\-()@]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number'
        });
      }
    }

    // Postal code validation (allow alphanumeric)
    if (data.postalCode && data.postalCode.trim() !== '') {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal code'
        });
      }
    }

    const valid = errors.length === 0;
    const result: ValidationResult = { valid, errors };

    if (valid && data.firstName && data.lastName && data.streetAddress && 
        data.city && data.stateProvinceRegion && data.postalCode && 
        data.country && data.email && data.phone) {
      result.data = {
        firstName: data.firstName.trim(),
        lastName: data.lastName.trim(),
        streetAddress: data.streetAddress.trim(),
        city: data.city.trim(),
        stateProvinceRegion: data.stateProvinceRegion.trim(),
        postalCode: data.postalCode.trim(),
        country: data.country.trim(),
        email: data.email.trim(),
        phone: data.phone.trim()
      };
    }

    return result;
  }

  private static formatFieldName(field: string): string {
    return field
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str) => str.toUpperCase())
      .trim();
  }
}