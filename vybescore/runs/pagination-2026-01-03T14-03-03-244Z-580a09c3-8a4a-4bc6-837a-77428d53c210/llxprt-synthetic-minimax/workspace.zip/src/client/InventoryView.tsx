import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  onPageChange: (page: number) => void; 
}): JSX.Element {
  return (
    <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', alignItems: 'center' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage <= 1}
        style={{ 
          padding: '0.5rem 1rem',
          backgroundColor: currentPage <= 1 ? '#ccc' : '#007bff',
          color: currentPage <= 1 ? '#666' : 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: currentPage <= 1 ? 'not-allowed' : 'pointer'
        }}
      >
        Previous
      </button>
      <span>Page {currentPage}</span>
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext}
        style={{ 
          padding: '0.5rem 1rem',
          backgroundColor: !hasNext ? '#ccc' : '#007bff',
          color: !hasNext ? '#666' : 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: !hasNext ? 'not-allowed' : 'pointer'
        }}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  // Handle empty state
  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        currentPage={data.page}
        hasNext={data.hasNext}
        onPageChange={setCurrentPage}
      />
      <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', color: '#666' }}>
        Showing {data.items.length} of {data.total} items
      </div>
    </section>
  );
}
