import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

let db: Database;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  sanitizedData?: FormData;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const sanitized: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };

  // First Name validation
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push('First name is required');
  } else {
    sanitized.firstName = data.firstName.trim();
  }

  // Last Name validation
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push('Last name is required');
  } else {
    sanitized.lastName = data.lastName.trim();
  }

  // Street Address validation
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  } else {
    sanitized.streetAddress = data.streetAddress.trim();
  }

  // City validation
  if (!data.city || data.city.trim().length === 0) {
    errors.push('City is required');
  } else {
    sanitized.city = data.city.trim();
  }

  // State/Province validation
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  } else {
    sanitized.stateProvince = data.stateProvince.trim();
  }

  // Postal Code validation (alphanumeric)
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else {
    const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalCodeRegex.test(data.postalCode.trim())) {
      errors.push('Postal / Zip code must contain only letters, numbers, spaces, and dashes');
    } else {
      sanitized.postalCode = data.postalCode.trim();
    }
  }

  // Country validation
  if (!data.country || data.country.trim().length === 0) {
    errors.push('Country is required');
  } else {
    sanitized.country = data.country.trim();
  }

  // Email validation
  if (!data.email || data.email.trim().length === 0) {
    errors.push('Email is required');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push('Please enter a valid email address');
    } else {
      sanitized.email = data.email.trim();
    }
  }

  // Phone validation (international formats)
  if (!data.phone || data.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
    } else {
      sanitized.phone = data.phone.trim();
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    sanitizedData: sanitized
  };
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    let dbBuffer: Uint8Array | null = null;
    
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(dbFile);
    }
    
    db = new SQL.Database(dbBuffer);
    
    // Read and execute schema
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      validation.sanitizedData!.firstName,
      validation.sanitizedData!.lastName,
      validation.sanitizedData!.streetAddress,
      validation.sanitizedData!.city,
      validation.sanitizedData!.stateProvince,
      validation.sanitizedData!.postalCode,
      validation.sanitizedData!.country,
      validation.sanitizedData!.email,
      validation.sanitizedData!.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(validation.sanitizedData!.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
