/**
 * Finds words starting with the prefix but excluding banned words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix) return [];
  
  // Create a regex pattern to match words beginning with the prefix
  // Use word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token) return [];
  
  // Create a regex with lookbehind to ensure token follows a digit
  // and lookahead to ensure it's not at the beginning of the string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches
  return text.match(regex) || [];
}

/**
 * Validates passwords according to strength policy
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // At least one uppercase
  if (!/[a-z]/.test(value)) return false; // At least one lowercase
  if (!/\d/.test(value)) return false;     // At least one digit
  if (!/[^A-Za-z0-9\s]/.test(value)) return false; // At least one symbol (non-alphanumeric, non-whitespace)
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any sequence of 2+ characters that immediately repeats
  if (/^(?=.*(.{2,})\1).+$/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern (includes full and compressed formats)
  // This is a simplified pattern that covers most common IPv6 formats
  const ipv6Regex = /(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){1,7}:|(?<!\d\.):(?::[0-9a-fA-F]{1,4}){1,7}|(?<!\d\.)::/g;
  
  // IPv4 regex pattern
  const ipv4Regex = /\b(?<!\.)(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?!\.)\b/g;
  
  // Check if it contains IPv6 but not IPv4
  return ipv6Regex.test(value) && !ipv4Regex.test(value);
}