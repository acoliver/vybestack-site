export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email format validity
  if (!value || typeof value !== 'string') return false;
  
  // RFC-like pattern for email validation
  // - Local part: alphanumeric chars, dots, underscores, dashes, plus signs
  // - No double dots, no leading/trailing dots
  // - Domain part: alphanumeric chars, dots, dashes (no underscores in domain)
  // - TLD must be at least 2 chars
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  // Additional checks for special cases
  if (!emailRegex.test(value)) return false;
  if (value.includes('..')) return false; // No double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // No leading/trailing dots in local part
  
  // Check that domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers in common formats
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for length and area code validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's a valid length (10 digits or 11 digits with +1 prefix)
  if (digitsOnly.length !== 10 && !(digitsOnly.length === 11 && digitsOnly.startsWith('1'))) {
    return false;
  }
  
  // Extract the actual phone number (10 digits)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Area code cannot start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Valid formats:
  // - (212) 555-7890
  // - 212-555-7890
  // - 2125557890
  // - +1 212 555 7890
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)\s?|[2-9]\d{2}[-\s.]?)\d{3}[-\s.]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for digit analysis
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for valid country code if present
  let phoneNumber = cleanValue;
  if (cleanValue.startsWith('+54')) {
    phoneNumber = cleanValue.substring(3);
  } else if (cleanValue.startsWith('54')) {
    phoneNumber = cleanValue.substring(2);
  } else if (!cleanValue.startsWith('0')) {
    // If no country code, must start with trunk prefix 0
    return false;
  }
  
  // Check for trunk prefix
  if (phoneNumber.startsWith('0')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check for mobile indicator
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Validate area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = phoneNumber.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = phoneNumber.substring(areaCode.length);
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  // Check that the whole phone number structure matches one of the valid patterns
  const validPatterns = [
    /^\+54\s?9?\s?([1-9]\d{1,3})\s?\d{6,8}$/, // +54 9 11 1234 5678 format
    /^\+54\s?([1-9]\d{1,3})\s?\d{6,8}$/, // +54 341 123 4567 format
    /^0([1-9]\d{1,3})\s?\d{6,8}$/, // 011 1234 5678 format
    /^([1-9]\d{1,3})\s?\d{6,8}$/ // 341 123 4567 format after removing country code and prefixes
  ];
  
  return validPatterns.some(pattern => pattern.test(cleanValue));
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Disallow digits and most symbols
  const nameRegex = /^[^\d\$\%\^\&\*\=\+\[\]\{\}\|\\\/\`\~\#\<\>\;\:\"\,\.]+$/;
  
  // Additional check to reject X Æ A-12 style names (which have numbers)
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u017F]/.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for valid length and prefix
  // Visa: starts with 4, 13 or 16 digits
  // Mastercard: starts with 5, 16 digits
  // AmEx: starts with 34 or 37, 15 digits
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^5[1-5][0-9]{14}$/;
  const amexRegex = /^3[47][0-9]{13}$/;
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanValue);
}