/**
 * Capitalizes the first character of each sentence while preserving spacing rules
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // First, normalize whitespace between sentences
  // Insert exactly one space after sentence-ending punctuation that isn't followed by a space
  const normalizedText = text.replace(/([.?!])(\S)/g, '$1 $2');
  
  // Then capitalize first letter of each sentence
  // Matches first non-whitespace character after sentence-ending punctuation or at the beginning
  return normalizedText.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
}

/**
 * Extracts URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Find URLs with common protocols
  // Then remove any trailing punctuation like commas, periods, etc.
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^\s.,;:!?]/gi;
  const matches = text.match(urlRegex);
  
  // Filter out matches that end with prohibited extensions in path
  const filteredMatches = matches ? matches.filter(url => {
    // Extract the path part (after the domain)
    const urlObj = new URL(url);
    const path = urlObj.pathname;
    
    // Check if path contains dynamic elements or legacy extensions
    return !(/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$)/.test(path) || 
             /[?&=]/.test(path) || 
             path.includes('cgi-bin'));
  }) : [];
  
  return filteredMatches || [];
}

/**
 * Forces all HTTP URLs to HTTPS while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Replace http:// with https:// for all URLs
  return text.replace(/http:/gi, 'https:');
}

/**
 * Rewrites HTTP URLs to HTTPS and moves docs paths to docs subdomain where applicable
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Upgrade all HTTP to HTTPS
  let result = text.replace(/http:/gi, 'https:');
  
  // Find URLs that may need host rewriting
  // Match https://example.com/docs/... but not paths with dynamic elements
  const docsUrlRegex = /https:\/\/([a-zA-Z0-9.-]+)\/(docs\/[^\s.,;:?&=\[\]{}]*[^\s.,;:!?"']?)/gi;
  
  result = result.replace(docsUrlRegex, (match, host, path) => {
    // Only rewrite if path doesn't contain dynamic hints
    if (!/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$)/.test(path) && 
        !/[?&=]/.test(path) && 
        !path.includes('cgi-bin')) {
      return `https://docs.${host}/${path}`;
    }
    return match;
  });
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when format is invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Validate date format mm/dd/yyyy
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}