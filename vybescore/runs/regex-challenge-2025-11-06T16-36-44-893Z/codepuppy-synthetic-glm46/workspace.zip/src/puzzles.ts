/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefixRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => 
    !exceptions.includes(word.toLowerCase()) && 
    !exceptions.includes(word)
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Simplified approach: find all digit+token patterns
  const tokenPattern = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const digitTokenRegex = new RegExp(`\\d+${tokenPattern}`, 'g');
  
  const matches = text.match(digitTokenRegex) || [];
  
  // Filter out ones that are at the very start of the string
  const filtered = matches.filter(match => {
    const index = text.indexOf(match);
    return index > 0;
  });
  
  // Return unique matches
  return [...new Set(filtered)];
}

/**
 * Validate passwords according to policy: at least 10 characters, uppercase, lowercase, digit, symbol,
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 123123)
  for (let i = 0; i < value.length - 2; i++) {
    const chunk1 = value.substring(i, i + 2);
    const chunk2 = value.substring(i + 2, i + 4);
    if (chunk1 === chunk2) return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 pattern that includes full format, shorthand with ::, and embedded IPv4
  // Must not match pure IPv4 addresses
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits
    /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})(?![0-9.])/,  
    // IPv6 with :: (count groups carefully to avoid IPv4)
    /(?:(?:[0-9a-fA-F]{1,4}:){1,7}:)(?![0-9.])/,  // trailing ::
    /(?:::(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4})(?![0-9.])/,  // leading ::
    /(?:(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4})(?![0-9.])/,  // single :: in middle
    /(?:(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2})(?![0-9.])/,  // :: with 2 group suffix
    /(?:(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3})(?![0-9.])/,  // :: with 3 group suffix
    /(?:(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4})(?![0-9.])/,  // :: with 4 group suffix
    // IPv6 with embedded IPv4 (these should count as IPv6)
    /(?:(?:[0-9a-fA-F]{1,4}:){1,5}:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/
  ];
  
  // Test all patterns - if any match, we have IPv6
  return ipv6Patterns.some(pattern => pattern.test(value));
}