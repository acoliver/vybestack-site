export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses accepting typical formats like name+tag@example.co.uk.
 * Reject double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic pattern for email validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for common invalid patterns
  const hasDoubleDot = value.includes('..');
  const hasTrailingDot = value.endsWith('.');
  const hasDomainUnderscore = value.split('@')[1]?.includes('_');
  const hasConsecutiveDotsInDomain = value.split('@')[1]?.includes('..');
  
  return emailRegex.test(value) && !hasDoubleDot && !hasTrailingDot && !hasDomainUnderscore && !hasConsecutiveDotsInDomain;
}

/**
 * Validate US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890, +1 prefix.
 * Disallow impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be 10 or 11 digits (with +1 prefix)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove the leading 1 for validation
    const tenDigits = digits.substring(1);
    
    // Area code cannot start with 0 or 1
    if (tenDigits[0] === '0' || tenDigits[0] === '1') return false;
    
    // Common US phone pattern
    const phoneRegex = /^\+?1?\s*\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
    return phoneRegex.test(value);
  } else if (digits.length === 10) {
    // Area code cannot start with 0 or 1
    if (digits[0] === '0' || digits[0] === '1') return false;
    
    // Common US phone pattern without country code
    const phoneRegex = /^\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
    return phoneRegex.test(value);
  }
  
  return false;
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Match Argentine phone patterns
  const phoneRegex = /^(\+54)?(9)?0?(\d{2,4})(\d{6,8})$/;
  const match = normalized.match(phoneRegex);
  
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits, leading digit 1-9 (no leading 0)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) return false;
  
  // If no country code, must start with trunk prefix 0 before area code
  if (!countryCode && !value.startsWith('0')) return false;
  
  return true;
}

/**
 * Validate personal names permitting unicode letters, accents, apostrophes, hyphens, spaces.
 * Reject digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional validation: ensure it's not just symbols or contains digits
  const hasLetter = /[\p{L}]/u.test(value);
  const hasDigit = /\d/.test(value);
  const hasExoticSymbols = /[^\p{L}\p{M}'\-\s]/u.test(value);
  
  return hasLetter && !hasDigit && !hasExoticSymbols;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for valid lengths and prefixes
  const visaRegex = /^4(\d{12}|\d{15})$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Luhn checksum algorithm
  return runLuhnCheck(digits);
}

/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
