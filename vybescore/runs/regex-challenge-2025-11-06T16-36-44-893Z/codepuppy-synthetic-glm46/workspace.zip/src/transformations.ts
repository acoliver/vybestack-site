/**
 * Capitalize the first character of each sentence after `.?!`.
 * Insert exactly one space between sentences and collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, collapse multiple spaces into single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence endings
  normalized = normalized.replace(/([.!?])\s*/g, '$1 ');
  
  // Capitalize first letter of each sentence (including first character of text)
  normalized = normalized.replace(/(?:^|[.!?]\s+)([a-z])/g, (match) => match.toUpperCase());
  
  // Trim leading/trailing space that might have been added
  return normalized.trim();
}

/**
 * Find URLs in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL pattern matching common protocols and domains
  // Excludes trailing punctuation like .,!?;:
  const urlRegex = /https?:\/\/(?:www\.)?[^\s,;:!?()\[\]{}"']+[^\s,;:!?()\[\]{}"'\.]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up any trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,;:!?()\[\]{}"']+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but don't change https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions) but still upgrades scheme.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/https?:\/\/example\.com(\/[^\s]*)?/gi, (match, path = '') => {
    // Always upgrade to https
    let newUrl = 'https://example.com' + path;
    
    // Check if we should rewrite host to docs.example.com
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const hasDynamicHint = /(?:cgi-bin|[?&=]|\.(?:jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!hasDynamicHint) {
        // Rewrite to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Additional validation for day based on month (simple version)
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Basic validation for day ranges
  const maxDays = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simple leap year handling
  
  if (dayNum > maxDays[monthNum]) return 'N/A';
  
  return year;
}
