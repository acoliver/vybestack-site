import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse page and limit parameters
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      page = Number(pageParam);
      if (isNaN(page) || !Number.isInteger(page) || page <= 0) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
    }
    
    if (limitParam !== undefined) {
      limit = Number(limitParam);
      if (isNaN(limit) || !Number.isInteger(limit) || limit <= 0) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof Error) {
        return res.status(400).json({ error: error.message });
      }
      return res.status(400).json({ error: 'Invalid pagination parameters' });
    }
  });

  return app;
}
