import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import server from '../../src/server.ts';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Set a different port for testing to avoid conflicts
  process.env.PORT = '0'; // Let OS pick a random port
  
  // Start the server
  await server.start();
});

afterAll(async () => {
  // Stop the server and clean up
  await server.stop();
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server.app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toBeDefined();
    
    // Basic string checks instead of cheerio for now
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
    expect(response.text).toContain('/submit');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(server.app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you?firstName=John');
    
    // Check that database was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify thank you page works
    const thankYouResponse = await request(server.app)
      .get('/thank-you?firstName=John');
    
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you, John!');
    expect(thankYouResponse.text).toContain('stranger on the internet');
  });
});
