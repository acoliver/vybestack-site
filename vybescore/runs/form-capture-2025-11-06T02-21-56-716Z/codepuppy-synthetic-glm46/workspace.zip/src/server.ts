import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  public app: express.Application;
  private server: import('http').Server | null;
  private db: import('sql.js').Database | null;
  private SQL: { Database: new (buffer?: ArrayBuffer) => import('sql.js').Database } | null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.server = null;
    this.db = null;
    this.SQL = null;
    this.dbPath = path.resolve('data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static('public'));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, '..', 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      this.SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new this.SQL.Database(dbBuffer.buffer);
      } else {
        this.db = new this.SQL.Database();
        const schemaPath = path.join(__dirname, '../db/schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        this.db.run(schema);
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    try {
      if (!this.db) throw new Error('Database not initialized');
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateForm(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field]!.trim().length === 0) {
        errors.push({
          field,
          message: `${this.getFieldLabel(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email && data.email.trim().length > 0) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation - accept international formats
    if (data.phone && data.phone.trim().length > 0) {
      const phoneRegex = /^[+]?[0-9\s\-())]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({
          field: 'phone',
          message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +'
        });
      }
    }

    // Postal code validation - accept alphanumeric
    if (data.postalCode && data.postalCode.trim().length > 0) {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({
          field: 'postalCode',
          message: 'Postal code can only contain letters, numbers, spaces, and dashes'
        });
      }
    }

    return errors;
  }

  private getFieldLabel(field: string): string {
    const labels: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field] || field;
  }

  private setupRoutes(): void {
    // GET / - render form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);
      
      if (errors.length > 0) {
        // Render form with errors
        const errorMessages = errors.map(e => e.message);
        res.status(400).render('form', {
          errors: errorMessages,
          values: formData
        });
        return;
      }

      try {
        if (!this.db) throw new Error('Database not initialized');
        
        const trimmedData = {
          firstName: formData.firstName.trim(),
          lastName: formData.lastName.trim(),
          streetAddress: formData.streetAddress.trim(),
          city: formData.city.trim(),
          stateProvince: formData.stateProvince.trim(),
          postalCode: formData.postalCode.trim(),
          country: formData.country.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim()
        };
        
        // Insert into database
        const stmt = this.db.prepare(`
          INSERT INTO submissions 
          (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          trimmedData.firstName,
          trimmedData.lastName,
          trimmedData.streetAddress,
          trimmedData.city,
          trimmedData.stateProvince,
          trimmedData.postalCode,
          trimmedData.country,
          trimmedData.email,
          trimmedData.phone
        ]);
        
        stmt.free();
        this.saveDatabase();
        
        // Redirect to thank you page
        res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    // GET /thank-you - render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    const port = process.env.PORT || 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  public async stop(): Promise<void> {
    if (this.server) {
      return new Promise<void>((resolve) => {
        this.server!.close(() => {
          if (this.db) {
            this.db.close();
          }
          resolve();
        });
      });
    }
    
    if (this.db) {
      this.db.close();
    }
  }
}

// Create server instance
const server = new FormServer();

// Export for testing
export default server;

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  // Handle graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully');
    await server.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully');
    await server.stop();
    process.exit(0);
  });

  // Start the server
  server.start().catch(console.error);
}