import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private SqlJs: ReturnType<typeof initSqlJs> | null = null;
  private dbPath: string;

  constructor(dbPath = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    const SqlJsInstance = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const sqlFile = fs.readFileSync(this.dbPath);
      this.db = new SqlJsInstance.Database(sqlFile);
    } else {
      this.db = new SqlJsInstance.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    // Try multiple possible locations for the schema file
    const possiblePaths = [
      path.join(__dirname, '../../db/schema.sql'),
      path.join(process.cwd(), 'db/schema.sql'),
      path.join(__dirname, '../db/schema.sql'),
      './db/schema.sql'
    ];

    let schemaSql = '';
    let schemaFound = false;

    for (const schemaPath of possiblePaths) {
      if (fs.existsSync(schemaPath)) {
        schemaSql = fs.readFileSync(schemaPath, 'utf8');
        schemaFound = true;
        break;
      }
    }

    if (!schemaFound) {
      throw new Error('Schema file not found in any expected location');
    }

    this.db.exec(schemaSql);
  }

  async insertSubmission(submission: FormSubmission): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const binaryArray = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(binaryArray));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async getAllSubmissions(): Promise<Record<string, unknown>[]> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY submitted_at DESC');
    const results: Record<string, unknown>[] = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject() as Record<string, unknown>;
      results.push(row);
    }
    
    stmt.free();
    return results;
  }
}

export { DatabaseManager, type FormSubmission };