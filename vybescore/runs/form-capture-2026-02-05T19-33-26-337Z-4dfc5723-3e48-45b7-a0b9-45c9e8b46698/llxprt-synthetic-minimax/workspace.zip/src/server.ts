import express, { Request, Response, NextFunction } from 'express';
import * as path from 'path';
import { Server } from 'node:http';
import { DatabaseManager, type FormSubmission } from './database';

interface ValidationError {
  field: string;
  message: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}



class FormValidator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and leading @ symbol
    const phoneRegex = /^@?[\d\s()-]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  static validatePostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings for international formats
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.length >= 3;
  }

  static validateSubmission(data: FormData): { isValid: boolean; errors: ValidationError[]; validatedData?: FormSubmission } {
    const errors: ValidationError[] = [];
    
    // Required field validation
    const requiredFields: (keyof FormSubmission)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field];
      if (!value || typeof value !== 'string' || value.trim() === '') {
        errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
      }
    }

    // Email validation
    if (data.email && !this.validateEmail(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation
    if (data.phone && !this.validatePhone(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation
    if (data.postalCode && !this.validatePostalCode(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    if (errors.length === 0) {
      const validatedData: FormSubmission = {
        firstName: (data.firstName || '').trim(),
        lastName: (data.lastName || '').trim(),
        streetAddress: (data.streetAddress || '').trim(),
        city: (data.city || '').trim(),
        stateProvince: (data.stateProvince || '').trim(),
        postalCode: (data.postalCode || '').trim(),
        country: (data.country || '').trim(),
        email: (data.email || '').trim(),
        phone: (data.phone || '').trim()
      };
      
      return { isValid: true, errors: [], validatedData };
    }

    return { isValid: false, errors };
  }
}

class Application {
  private app: express.Application;
  private dbManager: DatabaseManager;
  private server: Server | null = null;

  constructor() {
    this.app = express();
    this.dbManager = new DatabaseManager();
    this.setupMiddleware();
    this.setupRoutes();
    this.setupGracefulShutdown();
  }

  private setupMiddleware(): void {
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, '../views'));
    
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use(express.static(path.join(__dirname, '../public')));

    // Middleware for form data persistence
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      res.locals.formData = req.body || {};
      next();
    });
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      res.render('index', { 
        title: 'Contact Form',
        formData: {},
        errors: []
      });
    });

    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const validation = FormValidator.validateSubmission(req.body);
        
        if (!validation.isValid) {
          return res.status(400).render('index', {
            title: 'Contact Form - Please Fix Errors',
            formData: req.body,
            errors: validation.errors
          });
        }

        if (validation.validatedData) {
          await this.dbManager.insertSubmission(validation.validatedData);
        }

        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error processing submission:', error);
        res.status(500).render('index', {
          title: 'Contact Form - Error',
          formData: req.body,
          errors: [{ field: 'general', message: 'An error occurred. Please try again.' }]
        });
      }
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', { 
        title: 'Thank You!'
      });
    });
  }

  private setupGracefulShutdown(): void {
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}. Starting graceful shutdown...`);
      
      if (this.server) {
        this.server.close(async () => {
          console.log('HTTP server closed.');
          await this.dbManager.close();
          console.log('Database connection closed.');
          process.exit(0);
        });
      } else {
        await this.dbManager.close();
        process.exit(0);
      }
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }

  async start(): Promise<void> {
    try {
      await this.dbManager.initialize();
      const port = process.env.PORT || 3535;
      
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
        console.log(`Visit http://localhost:${port} to see the form`);
      });
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  async stop(): Promise<void> {
    if (this.server) {
      this.server.close();
    }
    await this.dbManager.close();
  }
}

// Start the server if this file is run directly
if (require.main === module) {
  const app = new Application();
  app.start().catch(error => {
    console.error('Failed to start application:', error);
    process.exit(1);
  });
}

export { Application };
