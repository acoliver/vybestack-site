import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Type declarations for SQL.js
interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(params?: unknown[]): void;
  free(): void;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface SqlJsInitOptions {
  locateFile?: (file: string) => string;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface SqlJsResult {
  Database: new (data?: ArrayBuffer) => Database;
}

// Type alias for Database
type SQLDatabase = Database;
// Import sql.js function - will be used inside async context
async function getInitSqlJs() {
  // @ts-expect-error sql.js module has no types but we use its default export
  const sqlJsModule = await import('sql.js');
  return sqlJsModule.default;
}

let db: SQLDatabase;

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

const app = express();
const port = process.env.PORT || 3535;

// Initialize database
async function initDatabase() {
  try {
    const initSqlJs = await getInitSqlJs();
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.resolve(__dirname, '..', 'node_modules', 'sql.js', 'dist', file),
    });

    // Load or create database
    let data: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const fileData = fs.readFileSync(dbPath);
      // Convert Buffer to Uint8Array
      data = new Uint8Array(fileData);
    }

    db = new SQL.Database(data || new Uint8Array(0));

    // Create schema if needed
    const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase() {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Validation function
function validateSubmission(formData: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Required fields check
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`);
    }
  }

  // Email validation
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  if (formData.phone && !/^\+?[0-9\s\-()]+$/.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Postal code validation (alphanumeric, letters, digits, spaces)
  if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const { isValid, errors } = validateSubmission(req.body);

  if (!isValid) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page with first name as query param
    res.redirect(`/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    firstName: req.query.firstName || 'friend'
  });
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  try {
    await initDatabase();
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
