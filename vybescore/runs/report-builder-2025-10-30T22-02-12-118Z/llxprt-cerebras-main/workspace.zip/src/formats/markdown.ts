import { ReportData, ReportOptions } from '../types/report.js';

export function renderMarkdown(data: ReportData, options: ReportOptions = {}): string {
  if (!data.title) {
    throw new Error('Missing required field: title');
  }
  
  if (!data.summary) {
    throw new Error('Missing required field: summary');
  }
  
  if (!Array.isArray(data.entries)) {
    throw new Error('Missing required field: entries');
  }

  let output = `# ${data.title}\n\n${data.summary}\n\n## Entries\n`;
  
  for (const entry of data.entries) {
    if (!entry.label || entry.amount === undefined) {
      throw new Error('Invalid entry format: each entry must have a label and amount');
    }
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** $${total.toFixed(2)}\n`;
  }
  
  return output;
}