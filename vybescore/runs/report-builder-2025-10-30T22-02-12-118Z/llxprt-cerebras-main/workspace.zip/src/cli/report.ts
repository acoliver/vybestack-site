#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { parseArgs } from './args.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../types/report.js';

// Parse command line arguments
const args = parseArgs(process.argv.slice(2));

// Read and parse data file
let data: ReportData;
try {
  const rawData = readFileSync(args.dataFile, 'utf-8');
  data = JSON.parse(rawData);
} catch (error) {
  if (error instanceof SyntaxError) {
    console.error(`Error parsing JSON: ${(error as Error).message}`);
    process.exit(1);
  }
  console.error(`Error reading file: ${(error as Error).message}`);
  process.exit(1);
}

// Choose formatter based on format argument
let output: string;
switch (args.format) {
  case 'markdown':
    output = renderMarkdown(data, { includeTotals: args.includeTotals });
    break;
  case 'text':
    output = renderText(data, { includeTotals: args.includeTotals });
    break;
  default:
    console.error(`Unsupported format: ${args.format}`);
    process.exit(1);
}

// Write output to file or stdout
if (args.output) {
  try {
    writeFileSync(args.output, output);
  } catch (error) {
    console.error(`Error writing to file: ${(error as Error).message}`);
    process.exit(1);
  }
} else {
  console.log(output);
}