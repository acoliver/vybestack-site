interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

export function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Missing format value');
      }
      result.format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Missing output path');
      }
      result.output = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('-') && !result.dataFile) {
      result.dataFile = arg;
    }
  }

  if (!result.dataFile) {
    throw new Error('Missing data file argument');
  }

  if (!result.format) {
    throw new Error('Missing --format option');
  }

  return result;
}