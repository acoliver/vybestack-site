/**
 * Finds words beginning with the specified prefix but excluding words in the exceptions list.
 * Returns an array of matching words without duplicates.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Normalize exceptions to lowercase for case-insensitive comparison
  const normalizedExceptions = exceptions.map(word => word.toLowerCase());
  
  // Filter out exceptions and return unique words
  const filteredWords = matches
    .map(word => word.toLowerCase()) // Normalize for comparison
    .filter(word => !normalizedExceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
  
  return filteredWords;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex to match the preceded by a digit and the token
  // We'll use a simpler approach that captures the digit + token and returns the full match
  const tokenRegex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  // Pattern captures any 2-3 character sequence that repeats immediately
  const repeatedPattern = /(.{2,3})\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that handles various formats:
  // - Full notation: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Shorthand with :: for consecutive zeros
  // - Mixed notation with IPv4 embedded (but we want to avoid matching IPv4 alone)
  
  // First check for pure IPv4 addresses and exclude them
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Regex.test(value)) return false;
  
  // IPv6 regex pattern
  const ipv6Regex = /(?:^|[^0-9a-fA-F:])((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?:[^0-9a-fA-F:]|$)/;
  
  return ipv6Regex.test(value);
}