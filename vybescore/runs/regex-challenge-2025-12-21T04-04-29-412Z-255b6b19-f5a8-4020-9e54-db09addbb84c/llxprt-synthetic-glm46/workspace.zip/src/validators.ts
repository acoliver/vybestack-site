export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for typical formats like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles common cases
  // Local part: letters, digits, +, ., -, _ but no consecutive dots, no leading/trailing dots
  // Domain part: letters, digits, - but no underscores, proper TLD format
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject emails with consecutive dots
  if (/\.{2,}/.test(value)) return false;
  
  // Reject emails with leading or trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Test against the main pattern
  if (!emailRegex.test(value)) return false;
  
  // Additional domain validation - must have at least one dot and proper TLD
  const domainParts = value.substring(value.lastIndexOf('@') + 1).split('.');
  if (domainParts.length < 2) return false;
  
  // Last part (TLD) must be at least 2 characters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats:
 * - (212) 555-7890
 * - 212-555-7890  
 * - 2125557890
 * - Optional +1 country code prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // TODO: Handle allowExtensions option when implemented
  void options;
  
  // Remove all whitespace for validation
  const cleanValue = value.replace(/\s/g, '');
  
  // Check minimum length - at least 10 digits
  if (cleanValue.replace(/\D/g, '').length < 10) return false;
  
  // Regex for US phone patterns with optional +1 country code
  const usPhoneRegex = /^(\+1[\s-]?)?(\()?([2-9]\d{2})(\))?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  
  if (!usPhoneRegex.test(cleanValue)) return false;
  
  // Extract area code to verify it doesn't start with 0 or 1
  const match = cleanValue.match(usPhoneRegex);
  if (!match) return false;
  
  const areaCode = match[3];
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both mobile and landline formats:
 * - +54 9 11 1234 5678 (mobile)
 * - 011 1234 5678 (landline)
 * - +54 341 123 4567 (landline)
 * - 0341 4234567 (landline)
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required when country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits, leading digit 1-9
 * - Subscriber number must be 6-8 digits after area code
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex following the specified rules
  const argPhoneRegex = /^(?:\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argPhoneRegex.test(cleanValue)) return false;
  
  const match = cleanValue.match(argPhoneRegex);
  if (!match) return false;
  
  const hasCountryCode = cleanValue.startsWith('+54');
  const hasTrunkPrefix = match[2] !== undefined;
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Area code validation: 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // When country code omitted, trunk prefix is required
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  return true;
}

/**
 * Validates personal names allowing:
 * - Unicode letters and accented characters
 * - Apostrophes (O'Connell)
 * - Hyphens (Mary-Jane)
 * - Spaces
 * 
 * Rejects:
 * - Digits
 * - Symbols other than allowed ones
 * - "X Æ A-12" style names with numbers and unusual symbols
 */
export function isValidName(value: string): boolean {
  // Name regex allowing unicode letters, spaces, apostrophes, and hyphens
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check against the basic pattern
  if (!nameRegex.test(value)) return false;
  
  // Ensure at least one letter is present
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject names that are only spaces or punctuation marks
  const trimmedValue = value.trim();
  if (trimmedValue.length === 0) return false;
  
  // Reject consecutive apostrophes or hyphens (unlikely in valid names)
  if (/''{1,}|--{1,}/.test(trimmedValue)) return false;
  
  // Ensure not starting or ending with apostrophe or hyphen
  if (trimmedValue.startsWith("'") || trimmedValue.startsWith("-") || 
      trimmedValue.endsWith("'") || trimmedValue.endsWith("-")) return false;
  
  return true;
}

/**
 * Luhn algorithm helper function for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express:
 * - Visa: 13 or 16 digits, starts with 4
 * - Mastercard: 16 digits, starts with 51-55 or 2221-2720
 * - American Express: 15 digits, starts with 34 or 37
 * - Applies Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(?:\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type
  const isValidFormat = visaRegex.test(cleanNumber) || 
                        mastercardRegex.test(cleanNumber) || 
                        amexRegex.test(cleanNumber);
  
  if (!isValidFormat) return false;
  
  // Apply Luhn checksum
  return runLuhnCheck(cleanNumber);
}