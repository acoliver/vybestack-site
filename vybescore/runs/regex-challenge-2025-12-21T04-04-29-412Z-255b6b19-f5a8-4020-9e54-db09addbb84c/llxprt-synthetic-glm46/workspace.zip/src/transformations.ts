/**
 * Capitalizes the first character of each sentence while preserving spacing:
 * - Sentences end with ., ?, or !
 * - Inserts exactly one space between sentences even if input omitted it
 * - Collapses extra spaces
 * - Leaves abbreviations intact when possible (e.g., e.g., i.e., Mr.)
 */
export function capitalizeSentences(text: string): string {
  // A simpler approach: use regex to find sentence starts and capitalize them
  // This handles the core requirement more reliably
  let result = text.replace(/\s+/g, ' ').trim(); // normalize spaces
  result = result.replace(/([.!?])(?=\S)/g, '$1 '); // ensure space after punctuation
  
  // Find beginning of string and each sentence start after punctuation
  return result.replace(/(?:^|[.!?]\s+)([a-z])/g, (match, p1) => {
    return match.slice(0, -1) + p1.toUpperCase();
  });
}

/**
 * Extracts all URLs found in the text, returning them without trailing punctuation.
 * Supports HTTP, HTTPS, and protocol-relative URLs.
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|https?:\/\/[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;!?'"\()[\]{}]+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// that doesn't have 's' after http with https://
  // Use a simpler approach that doesn't rely on lookbehinds which may not be supported
  // First replace the existing https:// URLs with a placeholder
  const placeholder = '__HTTPS_PLACEHOLDER__';
  let result = text.replace(/https:\/\//g, placeholder);
  
  // Replace all http:// with https:// 
  result = result.replace(/http:\/\//g, 'https://');
  
  // Restore the original https:// URLs
  result = result.replace(new RegExp(placeholder, 'g'), 'https://');
  
  return result;
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // For URLs with /docs/ path, we need to rewrite the host
  // Pattern: https://example.com/docs/... -> https://docs.example.com/...
  // Skip if the URL contains cgi-bin, query strings, or legacy extensions
  const specialPatterns = [
    /\/cgi-bin\//,
    /[?&=]/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/
  ];
  
  // Regex to match URLs with /docs/ path - using string constructor to avoid escape issues
  const docsUrlRegex = new RegExp('(https:\\/\\/)([^\\/\\s]+)(\\/docs\\/[^\\s]+)', 'g');
  
  result = result.replace(docsUrlRegex, (match, protocol, host, path) => {
    // Check if URL should be excluded from host rewrite
    const shouldExclude = specialPatterns.some(pattern => pattern.test(path));
    
    if (shouldExclude) {
      // Keep the original host, only upgrading to https (already done)
      return match;
    }
    
    // Rewrite to docs.example.com format
    return `${protocol}docs.${host}${path}`;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from a date string in mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or if month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for day based on month
  // April, June, September, November have 30 days
  if ([4, 6, 9, 11].includes(month) && day > 30) return 'N/A';
  
  // February has 28 days (ignoring leap years for simplicity)
  if (month === 2 && day > 28) return 'N/A';
  
  // All other months have 31 days
  if (![4, 6, 9, 11, 2].includes(month) && day > 31) return 'N/A';
  
  return year;
}