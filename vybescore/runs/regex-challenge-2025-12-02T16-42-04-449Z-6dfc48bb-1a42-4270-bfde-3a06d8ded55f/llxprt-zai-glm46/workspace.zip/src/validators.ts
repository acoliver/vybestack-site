export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: letters, digits, +, -, ., apostrophes (but no consecutive dots or trailing dots)
  // Domain part: letters, digits, -, . (no underscores, no consecutive dots, no trailing dots)
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional validation for no consecutive dots and no trailing dots
  if (!emailRegex.test(value)) return false;
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional country code +1
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) return false;
    // Process without the leading 1
    const mainDigits = digitsOnly.slice(1);
    return validateUSPhoneFormat(mainDigits);
  } else if (digitsOnly.length === 10) {
    return validateUSPhoneFormat(digitsOnly);
  }
  
  return false;
}

function validateUSPhoneFormat(digits: string): boolean {
  if (digits.length !== 10) return false;
  
  // Area code validation (can't start with 0 or 1)
  const areaCode = digits.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code validation (can't start with 0 or 1)
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Argentine phone number patterns:
  // +54 9 11 1234 5678 (mobile with country code)
  // +54 11 1234 5678 (landline with country code)
  // 011 1234 5678 (Buenos Aires landline without country code)
  // 0341 4234567 (provincial landline without country code)
  
  let remainingDigits = digitsOnly;
  
  // Check for country code +54
  if (remainingDigits.startsWith('54')) {
    remainingDigits = remainingDigits.slice(2);
  } else {
    // If no country code, must start with 0 (trunk prefix)
    if (!remainingDigits.startsWith('0')) return false;
  }
  
  // Remove trunk prefix 0 if present
  if (remainingDigits.startsWith('0')) {
    remainingDigits = remainingDigits.slice(1);
  }
  
  // Check for mobile indicator 9 (only for mobile numbers)
  const hasMobileIndicator = remainingDigits.startsWith('9');
  if (hasMobileIndicator) {
    remainingDigits = remainingDigits.slice(1);
  }
  
  // Now we should have: area code (2-4 digits) + subscriber number (6-8 digits)
  // Area code validation (leading digit 1-9, total 2-4 digits)
  if (remainingDigits.length < 8 || remainingDigits.length > 12) return false;
  
  // Try different area code lengths (2-4 digits)
  for (let areaCodeLen = 2; areaCodeLen <= 4; areaCodeLen++) {
    if (remainingDigits.length < areaCodeLen + 6) break; // Not enough digits for this area code length
    if (remainingDigits.length > areaCodeLen + 8) continue; // Too many digits for this area code length
    
    const areaCode = remainingDigits.slice(0, areaCodeLen);
    const subscriberNumber = remainingDigits.slice(areaCodeLen);
    
    // Area code must start with 1-9 and be exactly areaCodeLen digits
    if (!/^[1-9]\d{0,}$/.test(areaCode)) continue;
    if (areaCode.length !== areaCodeLen) continue;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && /^\d+$/.test(subscriberNumber)) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and patterns like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value.trim())) return false;
  
  // Additional validation: reject names that contain digits
  if (/\d/.test(value)) return false;
  
  // Reject names that are just symbols or have too many special characters in a row
  if (/^['\-\s]+$/.test(value.trim())) return false;
  
  // Should have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers for Visa/Mastercard/AmEx with Luhn check.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: starts with 4, length 13 or 16
  if (/^4\d{12}(\d{3})?$/.test(cleanNumber)) {
    return runLuhnCheck(cleanNumber);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (/^(5[1-5]\d{14}|2[2-7]\d{13}|2[2-7]0\d{12}|2[2-7]1\d{12}|2[2-7]2\d{12})$/.test(cleanNumber) ||
      /^2(2[2-9]|[3-6]\d|7[0-1])\d{12}$/.test(cleanNumber)) {
    return runLuhnCheck(cleanNumber);
  }
  
  // AmEx: starts with 34 or 37, length 15
  if (/^3[47]\d{13}$/.test(cleanNumber)) {
    return runLuhnCheck(cleanNumber);
  }
  
  return false;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */