/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and return unique words
  const result = matches
    .filter(word => !exceptions.includes(word.toLowerCase()))
    .filter((word, index, array) => array.indexOf(word.toLowerCase()) === index)
    .map(word => word.toLowerCase());
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to find token preceded by a digit
  const tokenRegex = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the full match including the digit
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
// No immediate repeated sequences (like abab, abcabc)
  // Check for patterns of length 2-6 that repeat immediately
  for (let len = 2; len <= 6; len++) {
    const pattern = new RegExp('(.{' + len + '})\\1+');
    if (pattern.test(value)) return false;
  }
  
  // Additional check for repeated characters (no more than 2 in a row)
  if (/(.)\1\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes shorthand notation
  const ipv6Pattern = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:/;
  
  // IPv4 pattern to exclude  
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/gm;
  
  // First check if the whole text is just an IPv4 address
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check for IPv6 in the text
  return ipv6Pattern.test(value);
}
