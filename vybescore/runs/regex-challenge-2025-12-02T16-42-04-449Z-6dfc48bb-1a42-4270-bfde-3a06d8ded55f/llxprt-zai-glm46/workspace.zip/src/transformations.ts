/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) return text;
  
  // First, normalize spacing by collapsing multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Then ensure proper spacing after sentence endings
  normalized = normalized.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Split into sentences and capitalize each
  const sentences = normalized.split(/([.!?]\s*)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.trim() === '') {
      result += part;
      continue;
    }
    
    // Check if this is a sentence ending punctuation
    if (/^[.!?]+\s*$/.test(part)) {
      result += part;
      capitalizeNext = true;
      continue;
    }
    
    // This is a sentence part that should be capitalized
    if (capitalizeNext) {
      result += part.charAt(0).toUpperCase() + part.slice(1);
      capitalizeNext = false;
    } else {
      result += part;
    }
  }
  
  return result.trim();
}

/**
 * TODO: Extract all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * TODO: Upgrade http:// URLs to https:// while preserving already secure URLs.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Upgrade http:// to https:// and rewrite docs URLs as described in problem.md.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with various domains  
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)?/g, (match, domain, path = '') => {
    // First upgrade to https
    let newUrl = 'https://' + domain;
    
    // Check if we should rewrite the host for docs
    if (path.startsWith('/docs/')) {
      // Check for dynamic patterns that should prevent host rewrite
      const hasDynamicHints = /[?&=]/.test(path) || // query params
                             /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/.test(path); // dynamic extensions
      const hasCgiBin = path.includes('/cgi-bin/'); // legacy CGI paths
      
      // Only rewrite host if no dynamic patterns found
      if (!hasDynamicHints && !hasCgiBin) {
        newUrl = 'https://docs.' + domain;
      }
    }
    
    return newUrl + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy format or return N/A.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day/month combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const isLeapYear = (year: number) => {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  };
  
  // Adjust February for leap years
  if (month === 2 && isLeapYear(parseInt(year, 10))) {
    daysInMonth[1] = 29;
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}