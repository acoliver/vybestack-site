#!/bin/bash
set -e

CLI="node dist/cli/report.js"
DATA="fixtures/data.json"

echo "=== Testing Markdown Format with Totals ==="
$CLI $DATA --format markdown --includeTotals
echo ""

echo "=== Testing Markdown Format without Totals ==="
$CLI $DATA --format markdown
echo ""

echo "=== Testing Text Format with Totals ==="
$CLI $DATA --format text --includeTotals
echo ""

echo "=== Testing Text Format without Totals ==="
$CLI $DATA --format text
echo ""

echo "=== Testing Output to File ==="
$CLI $DATA --format text --output /tmp/report.txt
cat /tmp/report.txt
echo ""

echo "=== Testing Error: Invalid Format ==="
$CLI $DATA --format pdf 2>&1 || true
echo ""

echo "=== Testing Error: Missing Required Field ==="
$CLI fixtures/malformed.json --format markdown 2>&1 || true
echo ""

echo "=== Testing Error: Invalid JSON ==="
$CLI fixtures/invalid-json.json --format markdown 2>&1 || true
echo ""

echo "=== All tests completed successfully! ==="
