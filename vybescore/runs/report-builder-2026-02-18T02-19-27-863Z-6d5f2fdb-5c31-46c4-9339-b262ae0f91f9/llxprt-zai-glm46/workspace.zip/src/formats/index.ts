import type { FormatRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatRenderers: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getRenderer(format: string): FormatRenderer {
  const renderer = formatRenderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}
