#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData } from '../types.js';
import { getRenderer } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let argIndex = 0;
  while (argIndex < args.length) {
    const arg = args[argIndex];

    if (arg === '--format') {
      argIndex++;
      if (argIndex >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[argIndex];
    } else if (arg === '--output') {
      argIndex++;
      if (argIndex >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[argIndex];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!result.inputFile) {
      result.inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }

    argIndex++;
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

function loadData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    // Validate the data structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }

    const reportData = data as Partial<ReportData>;

    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
    }

    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
    }

    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid entry at index ${i}: expected an object`);
      }

      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
      }

      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
      }
    }

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${filePath}": ${error.message}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const data = loadData(args.inputFile);
    const renderer = getRenderer(args.format);
    const output = renderer(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
