/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initialize the value by running the update function to track dependencies
  let isUpdating = false
  
  const getter: GetterFn<T> = () => {
    // If we're already updating, prevent infinite recursion
    if (isUpdating) {
      return observer.value!
    }
    
    // Get the active observer (if any) to chain dependencies
    const activeObserver = getActiveObserver()
    
    // If there's an active observer, register this computed as a dependency of it
    if (activeObserver) {
      observer.observer = activeObserver
    }
    
    // Execute the update function with this observer as active to track dependencies
    updateObserver(observer)
    
    return observer.value!
  }
  
  // Override the observer's update function to handle recomputation properly
  observer.updateFn = (currentValue?: T) => {
    // Prevent infinite recursion
    if (isUpdating) {
      return observer.value!
    }
    
    isUpdating = true
    try {
      // Execute the original function to recompute the value
      const result = updateFn(currentValue)
      observer.value = result
      
      // Cascade updates to any observers that depend on this computed value
      if (observer.observer) {
        updateObserver(observer.observer as Observer<unknown>)
      }
      
      return result
    } finally {
      isUpdating = false
    }
  }
  
  return getter
}