/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> = equal === false 
    ? () => false 
    : equal === true || equal === undefined
      ? (lhs: T, rhs: T) => lhs === rhs
      : equal

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Chain observers - new observer becomes the main one,
      // but the old observer should be notified through the new one
      const previousObserver = s.observer
      if (previousObserver && previousObserver !== observer) {
        // Link the previous observer to the new one
        observer.observer = previousObserver
      }
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    
    // Notify through the observer chain
    let current = s.observer
    const notified = new Set<ObserverR>()
    
    while (current && !notified.has(current)) {
      notified.add(current)
      updateObserver(current as Observer<unknown>)
      current = current.observer
    }
    
    return s.value
  }

  return [read, write]
}
