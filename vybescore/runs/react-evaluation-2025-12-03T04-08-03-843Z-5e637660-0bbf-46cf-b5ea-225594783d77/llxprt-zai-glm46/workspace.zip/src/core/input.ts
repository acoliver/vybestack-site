/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    equal === false ? undefined :
    equal === true || equal === undefined ? ((lhs: T, rhs: T) => lhs === rhs) :
    typeof equal === 'function' ? equal :
    undefined

  // Create observer for this input that can notify dependents
  const inputObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => value,
    observers: []
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track dependency: this input observer notifies the current observer
      addObserver(inputObserver, observer)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    inputObserver.value = nextValue
    
    // Notify all dependent observers
    if (inputObserver.observers && inputObserver.observers.length > 0) {
      for (const dependent of inputObserver.observers) {
        const obs = dependent as Observer<unknown>
        updateObserver(obs)
      }
    }
    return s.value
  }

  return [read, write]
}