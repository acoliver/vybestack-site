/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Note: equalFn parameter is kept for API compatibility but not used in current implementation

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: []
  }

  // Initialize the computed value
  updateObserver(o)
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed value becomes a dependency of the current observer
      addObserver(o, observer)
    }
    return o.value!
  }
}