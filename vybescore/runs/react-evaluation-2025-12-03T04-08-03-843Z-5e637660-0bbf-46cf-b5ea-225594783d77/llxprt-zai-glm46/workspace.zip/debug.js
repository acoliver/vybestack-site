// Debug script to understand the reactive system
import { createInput, createComputed } from './build/index.js'

console.log('Testing basic reactive system...')

const [getter, setter] = createInput(1)
console.log('Initial value:', getter())

const double = createComputed(() => {
  const val = getter() * 2
  console.log('Computing double:', getter(), '* 2 =', val)
  return val
})

console.log('Double:', double())
console.log('Setting to 3...')
setter(3)
console.log('After set - getter():', getter())
console.log('After set - double():', double())

console.log('Testing dependency chain...')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  const result = input() * 2
  console.log('timesTwo computed:', input(), '* 2 =', result)
  return result
})
const timesThirty = createComputed(() => {
  const result = input() * 30
  console.log('timesThirty computed:', input(), '* 30 =', result)
  return result
})
const sum = createComputed(() => {
  const result = timesTwo() + timesThirty()
  console.log('sum computed:', timesTwo(), '+', timesThirty(), '=', result)
  return result
})

console.log('Initial sum:', sum())
console.log('Setting input to 3...')
setInput(3)
console.log('Final sum:', sum())