// Simplified debug script for reactive system
import { createInput, createComputed } from './build/index.js'

console.log('=== Debug: Simple dependency chain ===')

const [input, setInput] = createInput(1, false, { name: 'input' })
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  const result = input() * 2
  console.log('timesTwo computing:', input(), '* 2 =', result)
  return result
}, undefined, false, { name: 'timesTwo' })

const timesThirty = createComputed(() => {
  const result = input() * 30
  console.log('timesThirty computing:', input(), '* 30 =', result)
  return result
}, undefined, false, { name: 'timesThirty' })

const sum = createComputed(() => {
  const result = timesTwo() + timesThirty()
  console.log('sum computing:', timesTwo(), '+', timesThirty(), '=', result)
  return result
}, undefined, false, { name: 'sum' })

console.log('Initial sum:', sum())
console.log('--- Setting input to 3 ---')
setInput(3)
console.log('Final sum:', sum())
console.log('Expected: 96, Got:', sum())