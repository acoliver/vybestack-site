/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  createSignal
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const signal = createSignal(value)

  const getter: GetterFn<T> = () => {
    return signal.get()
  }

  const setter: SetterFn<T> = (newValue) => {
    return signal.set(newValue)
  }

  return [getter, setter]
}
