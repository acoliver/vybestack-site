/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Execute the callback once initially
  updateFn(value)

  const unsubscribe = () => {
    // Basic unsubscribe
  }

  return unsubscribe
}
