/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Types for compatibility
export type ObserverR = any
export type ObserverV = any
export type SubjectR = any
export type SubjectV = any
export type Subject = any

// Core reactive interfaces
export interface Signal<T = any> {
  value: T
  get: () => T
  set: (value: T) => T
  notify: () => void
}

export interface Observer<T = any> {
  updateFn: UpdateFn<T>
  value: T
  compute: () => T
  notify: () => void
  dependencies: Signal[]
  isDisposed: boolean
}

export interface ComputedValue<T = any> {
  get: () => T
  notify: () => void
}

// Global reactive context
let activeObserver: Observer | undefined = undefined
const allSignals: Signal[] = []
const allObservers: Observer[] = []

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}

export function updateObserver(observer: Observer): any {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.compute()
    return observer.value
  } finally {
    activeObserver = previous
  }
}

export function createSignal<T>(value: T): Signal<T> {
  const signal: Signal<T> = {
    value,
    get: () => {
      const observer = activeObserver
      if (observer) {
        // Register this signal as a dependency of the active observer
        signal.observers = signal.observers || []
        signal.observers.push(observer)
        observer.dependencies = observer.dependencies || []
        observer.dependencies.push(signal)
      }
      return signal.value
    },
    set: (newValue: T) => {
      signal.value = newValue
      // Notify all observers that depend on this signal
      const observers = [...(signal.observers || [])]
      for (const observer of observers) {
        if (observer && !observer.isDisposed && observer.notify) {
          observer.notify()
        }
      }
      return signal.value
    },
    notify: () => {
      const observers = [...(signal.observers || [])]
      for (const observer of observers) {
        if (observer && !observer.isDisposed && observer.notify) {
          observer.notify()
        }
      }
    }
  }
  
  allSignals.push(signal)
  return signal
}

export function createObserver<T>(computeFn: () => T, updateFn?: UpdateFn<T>): Observer<T> {
  const observer: Observer<T> = {
    updateFn: updateFn || (() => {}),
    value: undefined,
    compute: computeFn,
    notify: () => {
      if (observer.isDisposed) return
      observer.value = observer.compute()
      // Notify observers of this computed value
      if (observer.dependents) {
        for (const dependent of observer.dependents) {
          if (dependent && dependent.notify) {
            dependent.notify()
          }
        }
      }
    },
    dependencies: [],
    isDisposed: false
  }
  
  updateObserver(observer)
  allObservers.push(observer)
  return observer
}

export function notifySignal(signal: Signal): void {
  const observers = [...(signal.observers || [])]
  for (const observer of observers) {
    if (observer && !observer.isDisposed) {
      updateObserver(observer)
      observer.notify()
    }
  }
}

export function addDependency(observer: Observer, signal: Signal): void {
  if (signal && observer) {
    signal.observers = signal.observers || []
    signal.observers.push(observer)
    observer.dependencies = observer.dependencies || []
    observer.dependencies.push(signal)
  }
}

export function removeObserver(observer: Observer): void {
  if (observer) {
    observer.isDisposed = true
    observer.dependencies = []
    for (const signal of allSignals) {
      if (signal.observers) {
        const index = signal.observers.indexOf(observer)
        if (index > -1) {
          signal.observers.splice(index, 1)
        }
      }
    }
  }
}
