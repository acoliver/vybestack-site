/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equality parameter
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Store all observers that depend on this input
  const observers = new Set<Observer<unknown>>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add observer to the set of observers that depend on this input
      observers.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all dependent observers of the change
    for (const obs of observers) {
      // Execute the observer's update function directly
      const newValue = (obs as any).updateFn(obs.value)
      obs.value = newValue
      
      // Propagate to parent observers if they exist
      if (obs.parentObserver) {
        const notifyObserver = (parentObs: Observer<unknown>) => {
          const parentNewValue = (parentObs as any).updateFn(parentObs.value)
          parentObs.value = parentNewValue
          
          if (parentObs.parentObserver) {
            notifyObserver(parentObs.parentObserver as Observer<unknown>)
          }
        }
        notifyObserver(obs.parentObserver as Observer<unknown>)
      }
    }
    
    return s.value
  }

  return [read, write]
}
