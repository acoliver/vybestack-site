/**
 * Validate that the input string only contains valid Base64 characters.
 */
function validateBase64Input(input: string): void {
  // Base64 regex: allows A-Z, a-z, 0-9, +, /, and = for padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check padding rules: padding can only appear at the end
  // and there can be 0, 1, or 2 padding characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.substring(paddingIndex);
    // Padding must be all = characters
    if (!/^=?=?$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    // No non-padding characters after padding
    if (paddingPart.length > 0 && paddingIndex + paddingPart.length !== input.length) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
  }
}

/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Uses standard Base64 with A-Z, a-z, 0-9, +, / characters and includes = padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with canonical alphabet and proper padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  validateBase64Input(input);
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
