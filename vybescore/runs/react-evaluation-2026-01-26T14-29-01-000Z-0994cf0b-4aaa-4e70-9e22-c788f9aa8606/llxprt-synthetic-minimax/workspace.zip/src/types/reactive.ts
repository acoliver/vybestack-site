/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Subject<unknown>[]
  notify?: (value: T) => void
}

export type Subject<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Observer<unknown>[]
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer?: Observer<unknown>) {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function trackSubject<T>(subject: Subject<T>) {
  const observer = getActiveObserver()
  if (observer) {
    if (!subject.observers) subject.observers = []
    if (!subject.observers.includes(observer)) {
      subject.observers.push(observer)
    }
    
    if (!observer.subjects) observer.subjects = []
    if (!observer.subjects.includes(subject as Subject<unknown>)) {
      observer.subjects.push(subject as Subject<unknown>)
    }
  }
}

export function notifySubjects<T>(observer: Observer<T>) {
  if (observer.subjects) {
    observer.subjects.forEach(subject => {
      if (subject.observers) {
        subject.observers.forEach(o => {
          if (o !== observer) {
            updateObserver(o as Observer<unknown>)
          }
        })
      }
    })
  }
  
  if (observer.notify) {
    observer.notify(observer.value!)
  }
}
