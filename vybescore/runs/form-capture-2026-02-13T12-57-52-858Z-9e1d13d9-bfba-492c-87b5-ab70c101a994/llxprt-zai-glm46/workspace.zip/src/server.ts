import express, { type Request, type Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { type Database } from 'sql.js';

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const dbPath = path.resolve('data', 'submissions.sqlite');
const schemaPath = path.resolve('db', 'schema.sql');

// Ensure data directory exists
const dataDir = path.resolve('data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

let db: Database | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer);
      console.log('Loaded existing database from', dbPath);
    } else {
      db = new SQL.Database();
      console.log('Created new database');
    }

    // Read and execute schema
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    db.run(schema);
    console.log('Database schema initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    console.log('Database saved to', dbPath);
  }
}

// Express middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve('public')));

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhoneNumber(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading + or @
  const phoneRegex = /^[+@]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.length >= 5;
}

function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric strings with spaces and dashes
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postal) && postal.trim().length >= 2;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Check required fields
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  }
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  }
  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  }

  // Validate email format
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Validate phone format
  if (data.phone && !validatePhoneNumber(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Validate postal code format
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: null,
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  // Insert into database
  try {
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName!,
        formData.lastName!,
        formData.streetAddress!,
        formData.city!,
        formData.stateProvince!,
        formData.postalCode!,
        formData.country!,
        formData.email!,
        formData.phone!
      ]);

      stmt.free();

      // Save database after insert
      saveDatabase();
    }

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    firstName: 'Friend'
  });
});

// Graceful shutdown
async function shutdown(signal: string): Promise<void> {
  console.log(`\nReceived ${signal}, closing server gracefully...`);

  if (db) {
    try {
      db.close();
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }

  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();

    app.listen(port, () => {
      console.log(`Server is running on http://localhost:${port}`);
      console.log('Press Ctrl+C to stop');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

// Export for testing
export default app;
