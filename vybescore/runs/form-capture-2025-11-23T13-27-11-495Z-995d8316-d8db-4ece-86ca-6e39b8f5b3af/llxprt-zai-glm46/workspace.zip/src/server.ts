import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(process.cwd(), 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      let dbBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(dbFile);
      }
      
      this.db = new SQL.Database(dbBuffer);
      
      // Initialize schema
      const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      this.db.exec(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

  // Phone validation - international format
    if (data.phone && !/^[+]?[0-9\s\-()]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation - alphanumeric
    if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    // Postal code validation - alphanumeric
    if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    // Postal code validation - alphanumeric
    if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

// Postal code validation - alphanumeric
    if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', { 
        errors: [], 
        formData: {} as FormData,
        title: 'International Contact Form'
      });
    });

    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        return res.render('form', {
          errors,
          formData,
          title: 'International Contact Form - Please Correct Errors'
        });
      }

      // Insert into database
      if (this.db) {
        const stmt = this.db.prepare(`
          INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);
        
        stmt.free();
        this.saveDatabase();
      }

      res.redirect(302, '/thank-you');
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', { title: 'Thank You!' });
    });

    // 404 handler
    this.app.use((req: Request, res: Response) => {
      res.status(404).render('form', {
        errors: [],
        formData: {} as FormData,
        title: 'Page Not Found'
      });
    });

    // Error handler
    this.app.use((err: Error, req: Request, res: Response) => {
      console.error(err);
      res.status(500).render('form', {
        errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
        formData: {} as FormData,
        title: 'Error'
      });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT || 3535;
    
    const server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const shutdown = () => {
      console.log('Shutting down server...');
      server.close(() => {
        if (this.db) {
          this.db.close();
        }
        process.exit(0);
      });
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  }
}

// Start the server
async function main() {
  const server = new FormServer();
  try {
    await server.start();
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

main().catch(console.error);
