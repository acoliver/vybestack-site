import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';

import { MarkdownFormatter } from '../formats/markdown.js';

import { TextFormatter } from '../formats/text.js';

// Map of supported formatters
const formatters = {
  markdown: new MarkdownFormatter(),
  text: new TextFormatter()
};

// Function to parse command line arguments
function parseArguments(args: string[]): CliOptions {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let dataPath = "";
  let format = "";
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (i === 0) {
      // First argument is the data file path
      dataPath = arg;
    } else if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!dataPath) {
    throw new Error('Data file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
  }

  return {
    dataPath,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals
  };
}

// Function to load and validate JSON data
function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf8');
    const data = JSON.parse(rawData) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }

    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label is required and must be a string`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}].amount is required and must be a number`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

// Main CLI execution
try {
  const options = parseArguments(process.argv.slice(2));
  const reportData = loadReportData(options.dataPath);
  const formatter = formatters[options.format];
  
  if (!formatter) {
    throw new Error(`Unsupported format: ${options.format}`);
  }

  const output = formatter.format(reportData, options.includeTotals);

  if (options.outputPath) {
    writeFileSync(options.outputPath, output, 'utf8');
  } else {
    console.log(output);
  }
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  console.error(`Error: ${message}`);
  process.exit(1);
}
