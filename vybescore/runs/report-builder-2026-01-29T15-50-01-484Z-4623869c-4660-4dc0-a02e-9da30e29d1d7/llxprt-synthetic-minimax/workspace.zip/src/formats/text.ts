import { ReportData, Formatter } from '../types.js';

export class TextFormatter implements Formatter {
  format(data: ReportData, includeTotals: boolean): string {
    const lines: string[] = [];

    // Add title
    lines.push(data.title);
    lines.push("");

    // Add summary
    lines.push(data.summary);
    lines.push("");

    // Add entries heading
    lines.push("Entries:");

    // Add each entry as bullet point
    data.entries.forEach(entry => {
      const amount = entry.amount.toFixed(2);
      lines.push(`- ${entry.label}: $${amount}`);
    });

    // Add totals if requested
    if (includeTotals) {
      lines.push("");
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`Total: $${total.toFixed(2)}`);
    }

    return lines.join("\n");
  }
}
