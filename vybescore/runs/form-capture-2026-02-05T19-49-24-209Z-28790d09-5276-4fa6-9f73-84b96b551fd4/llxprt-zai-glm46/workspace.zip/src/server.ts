import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Configure EJS - templates are in src/templates
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Initialize database
async function initializeDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize sql.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validation functions
function isRequired(value: string): boolean {
  return value.trim().length > 0;
}

function isEmail(value: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(value);
}

function isPhone(value: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(value) && value.trim().length > 0;
}

function isPostalCode(value: string): boolean {
  // Allow alphanumeric characters, spaces, dashes
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(value) && value.trim().length > 0;
}

function validateForm(data: FormData): string[] {
  const errors: string[] = [];

  if (!isRequired(data.firstName)) {
    errors.push('First name is required');
  }
  if (!isRequired(data.lastName)) {
    errors.push('Last name is required');
  }
  if (!isRequired(data.streetAddress)) {
    errors.push('Street address is required');
  }
  if (!isRequired(data.city)) {
    errors.push('City is required');
  }
  if (!isRequired(data.stateProvince)) {
    errors.push('State / Province / Region is required');
  }
  if (!isRequired(data.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!isPostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and dashes');
  }
  if (!isRequired(data.country)) {
    errors.push('Country is required');
  }
  if (!isRequired(data.email)) {
    errors.push('Email is required');
  } else if (!isEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!isRequired(data.phone)) {
    errors.push('Phone number is required');
  } else if (!isPhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form.ejs', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    },
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    res.render('form.ejs', {
      errors,
      values: formData,
    });
    return;
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );
    saveDatabase();
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Get the most recent submission for personalization
  let firstName = 'friend';
  if (db) {
    const result = db.exec(
      'SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1'
    );
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  }

  res.render('thank-you.ejs', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Handle process termination signals
process.on('SIGTERM', () => {
  shutdown();
  process.exit(0);
});

process.on('SIGINT', () => {
  shutdown();
  process.exit(0);
});

// Start server
async function start(): Promise<void> {
  await initializeDatabase();

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

// Export for testing
export { app, initializeDatabase, shutdown };

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  start();
}
