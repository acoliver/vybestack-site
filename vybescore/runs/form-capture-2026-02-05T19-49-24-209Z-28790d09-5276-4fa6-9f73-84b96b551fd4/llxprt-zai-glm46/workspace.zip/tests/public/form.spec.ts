import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase, shutdown } from '../../src/server.js';
import { Server } from 'node:http';

let server: Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await initializeDatabase();
  server = app.listen(0); // Use random available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  shutdown();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);
    const fields = [
      { id: 'firstName', label: 'First name' },
      { id: 'lastName', label: 'Last name' },
      { id: 'streetAddress', label: 'Street address' },
      { id: 'city', label: 'City' },
      { id: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', label: 'Country' },
      { id: 'email', label: 'Email' },
      { id: 'phone', label: 'Phone number' },
    ];

    fields.forEach(({ id, label }) => {
      const labelElement = $(`label[for="${id}"]`);
      const inputElement = $(`#${id}`);
      expect(labelElement.text().trim()).toBe(label);
      expect(inputElement.attr('name')).toBe(id);
    });
  });

  it('persists submission and redirects', async () => {
    // Clear database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorList = $('.error-list');
    expect(errorList.length).toBe(1);
    expect(errorList.text()).toContain('First name is required');
    expect(errorList.text()).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('valid email address');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: 'invalid-phone!',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Phone number must contain only digits');
  });

  it('validates postal code format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: 'Invalid@Postal!',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Postal / Zip code must contain only letters');
  });

  it('accepts international phone formats', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Maria',
        lastName: 'Gonzalez',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria@example.com',
        phone: '+54 9 11 1234-5678',
      });

    expect(response.status).toBe(302);
  });

  it('renders thank-you page with personalized message', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('.thankyou-card h1').text()).toMatch(/Thank you/);
    expect($('.thankyou-card').text()).toMatch(/stranger on the internet/);
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 555-999-8888',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('#firstName').attr('value')).toBe('Jane');
    expect($('#email').attr('value')).toBe('invalid-email');
  });
});
