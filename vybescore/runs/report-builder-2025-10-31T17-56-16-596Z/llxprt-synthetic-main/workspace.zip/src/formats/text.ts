import { ReportData, FormatOptions } from '../types.js';

/**
 * Formats a report as plain text
 */
export function renderText(data: ReportData, options: FormatOptions): string {
  const lines: string[] = [];

  // Add title
  lines.push(data.title);
  lines.push('');

  // Add summary
  lines.push(data.summary);
  lines.push('');

  // Add entries
  lines.push('Entries:');
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }

  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`\nTotal: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}