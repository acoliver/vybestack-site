#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command-line arguments
 */
function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  let dataFile = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    switch (arg) {
      case '--format':
        if (i + 1 < args.length) {
          format = args[i + 1];
          i++;
        } else {
          throw new Error('--format requires a value');
        }
        break;
      case '--output':
        if (i + 1 < args.length) {
          outputPath = args[i + 1];
          i++;
        } else {
          throw new Error('--output requires a value');
        }
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (!dataFile) {
          dataFile = arg;
        } else {
          throw new Error(`Unexpected argument: ${arg}`);
        }
        break;
    }
  }

  if (!dataFile) {
    throw new Error('Data file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, outputPath, includeTotals };
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries array');
  }

  const entries: { label: string; amount: number }[] = [];
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: entry missing or invalid label');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: entry missing or invalid amount');
    }

    entries.push({
      label: entryObj.label,
      amount: entryObj.amount,
    });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

/**
 * Main CLI function
 */
async function main(): Promise<void> {
  try {
    const args = process.argv.slice(2);
    const { dataFile, format, outputPath, includeTotals } = parseArgs(args);

    // Read and parse JSON data
    const dataPath = dataFile;
    const fileContent = await readFile(dataPath, 'utf8');
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Invalid JSON in file ${dataFile}: ${error instanceof Error ? error.message : String(error)}`);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Format the report based on the requested format
    const options = { includeTotals };
    let output: string;

    switch (format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        throw new Error(`Unsupported format: ${format}`);
    }

    // Write output
    if (outputPath) {
      await writeFile(outputPath, output, 'utf8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Run the CLI
main();
