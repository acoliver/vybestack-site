/**
 * Represents a single entry in the report
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Represents the complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for formatting the report
 */
export interface FormatOptions {
  includeTotals: boolean;
}