#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { exit } from 'node:process';

import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportOptions } from '../types.js';

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

type Format = keyof typeof formatters;

function parseArgs(): {
  filePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }
  
  const filePath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format is required');
    exit(1);
  }
  
  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return { filePath, format, outputPath, includeTotals };
}

function validateFormat(format: string): format is Format {
  return format in formatters;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string' || typeof report.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(report.entries)) {
    return false;
  }
  
  for (const entry of report.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

async function main(): Promise<void> {
  try {
    const { filePath, format, outputPath, includeTotals } = parseArgs();
    
    if (!validateFormat(format)) {
      console.error(`Error: Unsupported format "${format}"`);
      exit(1);
    }
    
    let fileContent: string;
    
    try {
      fileContent = await readFile(filePath, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file "${filePath}"`);
      console.error(error instanceof Error ? error.message : 'Unknown error');
      exit(1);
    }
    
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error('Error: Malformed JSON');
      console.error(error instanceof Error ? error.message : 'Unknown error');
      exit(1);
    }
    
    if (!validateReportData(data)) {
      console.error('Error: Invalid report data structure. Missing required fields or incorrect types.');
      exit(1);
    }
    
    const options: ReportOptions = { includeTotals };
    const formatter = formatters[format];
    const output = formatter(data, options);
    
    if (outputPath) {
      try {
        await writeFile(outputPath, output);
        console.log(`Report written to ${outputPath}`);
      } catch (error) {
        console.error(`Error: Could not write to file "${outputPath}"`);
        console.error(error instanceof Error ? error.message : 'Unknown error');
        exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Unexpected error:', error instanceof Error ? error.message : 'Unknown error');
    exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch(() => {
    console.error('An unexpected error occurred');
    exit(1);
  });
}

export { main };
