import type { ReportRenderer, ReportData, ReportOptions } from '../types.js';

export const renderText: ReportRenderer = (
  data: ReportData,
  options?: ReportOptions,
): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = `${data.title}\n${data.summary}\n\nEntries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options?.includeTotals) {
    output += `Total: $${total.toFixed(2)}`;
  }
  
  return output;
};