export type ReportEntry = {
  label: string;
  amount: number;
};

export type ReportData = {
  title: string;
  summary: string;
  entries: ReportEntry[];
};

export type ReportOptions = {
  includeTotals: boolean;
};

export type ReportRenderer = (
  data: ReportData,
  options?: ReportOptions,
) => string;