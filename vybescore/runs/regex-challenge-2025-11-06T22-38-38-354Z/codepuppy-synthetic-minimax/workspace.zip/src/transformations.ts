/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty input
  if (!text.trim()) return text;
  
  // First, collapse multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Add space after sentence-ending punctuation if missing
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Capitalize first character of each sentence
  // Handle start of string and after sentence-ending punctuation
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
  
  // Handle common abbreviations to avoid incorrect sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e\.g', 'i\.e'];
  const abbrevPattern = new RegExp(`\b(${abbreviations.join('|')})\.`,'gi');
  
  // For abbreviations, ensure the following word isn't capitalized
  result = result.replace(abbrevPattern, (match) => match.toLowerCase());
  
  // Clean up any extra spaces around punctuation
  result = result.replace(/\s+([.?!])/g, '$1');
  
  return result.trim();
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https protocols and common domains
  const urlPattern = /\bhttps?:\/\/[^\s<>"'{}|\^`\[\]]+(?=\b|[.,;:!?)](?:\s|$))/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs: always upgrade to https, move /docs/ paths to docs.example.com.
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Pattern to match example.com URLs with docs path
  // Exclude dynamic content that should not have host rewritten
  const docsUrlPattern = /https:\/\/example\.com(\/docs\/[^\s?]*)(?![^\s]*\?(?:[^\s]*\.(?:jsp|php|asp|aspx|do|cgi|pl|py)|[^\s]*cgi-bin))/gi;
  
  result = result.replace(docsUrlPattern, (match, docsPath) => {
    return `https://docs.example.com${docsPath}`;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (yearInt: number) => {
    return (yearInt % 4 === 0 && yearInt % 100 !== 0) || yearInt % 400 === 0;
  };
  
  const yearInt = parseInt(year, 10);
  const maxDays = month === 2 ? (isLeapYear(yearInt) ? 29 : 28) : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}
