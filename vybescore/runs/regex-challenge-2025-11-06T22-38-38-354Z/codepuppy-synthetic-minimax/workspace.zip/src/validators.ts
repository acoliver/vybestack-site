export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that handles:
  // - Local part: letters, digits, +, -, ., apostrophes
  // - Domain: letters, digits, hyphens, dots
  // - No double dots, no trailing dots, no underscores in domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for specific invalid patterns
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots in local part or domain
  if (/\.\./.test(value)) return false;
  
  // Reject dot at start or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for US number)
  if (digits.length < 10 || digits.length > 11) return false;
  
  // Extract 10-digit number (exclude leading +1 if present)
  const phoneNumber = digits.length === 11 ? digits.slice(1) : digits;
  
  // If 11 digits, must start with 1 (US country code)
  if (digits.length === 11 && digits[0] !== '1') return false;
  
  // Area code can't start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if matches common US phone patterns
  const phonePattern = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return phonePattern.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep count of digits
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with all components
  const argPhonePattern = /^(?:(?:\+54)|0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argPhonePattern);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits and start with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Validate format with optional separators
  const patternWithSeparators = /^(?:\+54[\s-]?|0)(?:9[\s-]?)?([1-9]\d{1,3})[\s-]?(\d{3,4})[\s-]?(\d{4})$/;
  return patternWithSeparators.test(value) || argPhonePattern.test(cleanValue);
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letter pattern that includes accented characters and common name punctuation
  const namePattern = /^[\p{L}\p{M}'][\p{L}\p{M}'\s-]*[\p{L}\p{M}']$/u;
  
  // Must not contain digits or parentheses (for names like X Æ A-12)
  if (/\d|[()]/.test(value)) return false;
  
  // Must not start or end with hyphen or apostrophe
  if (/^[\-'\s]|[\-'\s]$/.test(value)) return false;
  
  // Must not have consecutive spaces, hyphens, or apostrophes
  if (/[\s'-]{2,}/.test(value)) return false;
  
  // Minimum length of 2 characters
  if (value.trim().length < 2) return false;
  
  return namePattern.test(value);
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx).
 * Checks prefixes, lengths, and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaPattern = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if matches any card pattern
  const isValidPrefix = visaPattern.test(cleanNumber) || 
                       mastercardPattern.test(cleanNumber) || 
                       amexPattern.test(cleanNumber);
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
