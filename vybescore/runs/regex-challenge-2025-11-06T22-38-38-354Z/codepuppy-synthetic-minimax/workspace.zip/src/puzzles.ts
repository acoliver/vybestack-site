/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple approach: split into words and filter
  const words = text.match(/\b\w+\b/g) || [];
  
  // Filter words that start with prefix
  const prefixedWords = words.filter(word => 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );
  
  // Filter out exceptions (case-insensitive)
  return prefixedWords.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token first
  const results: string[] = [];
  let index = text.indexOf(token);
  
  while (index !== -1) {
    // Check if it's not at the start and preceded by a digit
    if (index > 0 && /\d/.test(text[index - 1])) {
      // Extract the full match including the digit and token
      const startIdx = index - 1;
      const endIdx = index + token.length;
      results.push(text.substring(startIdx, endIdx));
    }
    
    // Look for next occurrence
    index = text.indexOf(token, index + 1);
  }
  
  return results;
}

/**
 * Validates passwords: at least 10 chars, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-word character)
  if (!/[^\w]/.test(value)) return false;
  
  // No immediate repeated sequences of 2+ characters (like abab, abcabc)
  // Check for patterns where a sequence of 2+ chars repeats immediately
  const repeatedSequencePattern = /(.{2,})\1+/;
  if (repeatedSequencePattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes full format and shorthand with ::
  // Uses negative lookahead to exclude IPv4 addresses
  const ipv6Pattern = /\b(?:(?!\d+\.\d+\.\d+\.\d+))([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // Test the pattern
  if (!ipv6Pattern.test(value)) return false;
  
  // Additional validation to ensure it's actually IPv6
  // More comprehensive IPv6 pattern
  const fullIpv6Pattern = /\b((?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,7}:|(?:[0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,5}(?::[0-9A-Fa-f]{1,4}){1,2}|(?:[0-9A-Fa-f]{1,4}:){1,4}(?::[0-9A-Fa-f]{1,4}){1,3}|(?:[0-9A-Fa-f]{1,4}:){1,3}(?::[0-9A-Fa-f]{1,4}){1,4}|(?:[0-9A-Fa-f]{1,4}:){1,2}(?::[0-9A-Fa-f]{1,4}){1,5}|[0-9A-Fa-f]{1,4}:(?:(?::[0-9A-Fa-f]{1,4}){1,6})|:(?:(?::[0-9A-Fa-f]{1,4}){1,7}|:))\b/;
  
  return fullIpv6Pattern.test(value);
}
