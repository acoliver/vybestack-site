import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
let db: Database | null = null;

// Ensure data directory exists
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Load or create database
async function loadDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  let db: Database;

  if (fs.existsSync(dbPath)) {
    const dbBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(dbBuffer);
  } else {
    db = new SQL.Database();
  }

  // Ensure schema exists
  const schemaSql = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  db.run(schemaSql);

  return db;
}

// Save database to disk
function saveDatabase(db: Database): void {
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[a-zA-Z0-9s-]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(formData: FormData): FormErrors {
  const errors: FormErrors = {};

  // Required fields
  if (!formData.firstName || !formData.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  if (!formData.lastName || !formData.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  if (!formData.streetAddress || !formData.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  if (!formData.city || !formData.city.trim()) {
    errors.city = 'City is required';
  }
  if (!formData.stateProvince || !formData.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  if (!formData.postalCode || !formData.postalCode.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }
  if (!formData.country || !formData.country.trim()) {
    errors.country = 'Country is required';
  }
  if (!formData.email || !formData.email.trim()) {
    errors.email = 'Email is required';
  }
  if (!formData.phone || !formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  }

  // Validations
  if (formData.email && !validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Validation failed, re-render form with errors
    res.status(400).render('form', { errors, values: formData });
    return;
  }

  // Validation passed, save to database
  try {
    if (!db) {
      db = await loadDatabase();
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();

    // Save database changes
    saveDatabase(db);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { general: 'Failed to save submission. Please try again.' },
      values: formData
    });
    return;
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

app.get('/thank-you', async (req: Request, res: Response) => {
  // Get the most recent submission to display the first name
  let firstName = 'friend';
  
  try {
    if (!db) {
      // Load fresh database for this request
      db = await loadDatabase();
    }

    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
    const result = stmt.get() as unknown as { first_name: string } | undefined;
    
    // Check if we got a result and it has a first_name
    if (result && typeof result === 'object' && 'first_name' in result && result.first_name) {
      firstName = result.first_name;
    }
    
    stmt.free();
  } catch (error) {
    console.error('Database error:', error);
  }

  res.render('thank-you', { firstName });
});

// Start server
let server: unknown;

async function startServer() {
  try {
    // Initialize database
    db = await loadDatabase();
    
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase(db);
    db.close();
    db = null;
  }

  if (server) {
    (server as { close: (callback?: () => void) => void }).close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, startServer, gracefulShutdown };
