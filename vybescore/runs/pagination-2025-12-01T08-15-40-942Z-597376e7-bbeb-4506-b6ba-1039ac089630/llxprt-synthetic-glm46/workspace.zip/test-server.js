// Test script to verify pagination API manually
import request from 'supertest';
import { createApp } from './src/server/app';
import { createDatabase } from './src/server/db';

async function testPaginationAPI() {
  console.log('Testing pagination API...\n');

  try {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test 1: Default parameters (should use page=1, limit=5)
    console.log('1. Testing default parameters...');
    const response1 = await request(app).get('/inventory');
    console.log(`Status: ${response1.status}`);
    console.log(`Response: ${JSON.stringify(response1.body, null, 2)}`);
    
    // Test 2: Explicit page and limit
    console.log('\n2. Testing explicit page=1, limit=3...');
    const response2 = await request(app).get('/inventory?page=1&limit=3');
    console.log(`Status: ${response2.status}`);
    console.log(`Response: ${JSON.stringify(response2.body, null, 2)}`);
    
    // Test 3: Second page
    console.log('\n3. Testing page=2, limit=3...');
    const response3 = await request(app).get('/inventory?page=2&limit=3');
    console.log(`Status: ${response3.status}`);
    console.log(`Response: ${JSON.stringify(response3.body, null, 2)}`);
    
    // Test 4: Invalid page parameter
    console.log('\n4. Testing invalid page parameter...');
    const response4 = await request(app).get('/inventory?page=0');
    console.log(`Status: ${response4.status}`);
    console.log(`Response: ${JSON.stringify(response4.body, null, 2)}`);
    
    // Test 5: Invalid limit parameter
    console.log('\n5. Testing invalid limit parameter...');
    const response5 = await request(app).get('/inventory?limit=0');
    console.log(`Status: ${response5.status}`);
    console.log(`Response: ${JSON.stringify(response5.body, null, 2)}`);
    
    // Test 6: Non-numeric parameters
    console.log('\n6. Testing non-numeric parameters...');
    const response6 = await request(app).get('/inventory?page=abc&limit=xyz');
    console.log(`Status: ${response6.status}`);
    console.log(`Response: ${JSON.stringify(response6.body, null, 2)}`);
    
    console.log('\n[OK] All tests completed successfully!');
  } catch (error) {
    console.error('[ERROR] Test failed:', error);
  }
}

testPaginationAPI();