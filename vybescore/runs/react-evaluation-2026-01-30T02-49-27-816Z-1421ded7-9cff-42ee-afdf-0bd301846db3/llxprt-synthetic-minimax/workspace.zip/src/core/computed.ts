/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => {
      // Recompute when dependencies change
      computedValue = updateFn(computedValue)
      return computedValue
    },
  }

  const read: GetterFn<T> = () => {
    // Track dependencies by setting this as active observer
    const previousObserver = getActiveObserver()
    setActiveObserver(observer)
    try {
      computedValue = updateFn(computedValue)
      return computedValue!
    } finally {
      setActiveObserver(previousObserver)
    }
  }

  return read
}
