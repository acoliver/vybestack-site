/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  dependents?: Set<ObserverR>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function addDependent<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function removeDependent<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.dependents?.delete(observer)
}

export function notifyDependents<T>(subject: Subject<T>): void {
  if (!subject.dependents) return
  
  // Create a copy to avoid modification during iteration
  const dependents = new Set(subject.dependents)
  for (const dependent of dependents) {
    // Cast to full observer type to access updateFn and value
    const observer = dependent as ObserverV<T>
    if (observer.updateFn && typeof observer.updateFn === 'function') {
      observer.value = observer.updateFn(observer.value)
    }
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}
