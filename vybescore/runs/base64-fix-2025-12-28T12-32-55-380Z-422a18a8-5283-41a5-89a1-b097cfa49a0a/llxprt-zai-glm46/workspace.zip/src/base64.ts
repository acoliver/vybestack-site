const VALID_BASE64_CHARS = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Check if a string is valid Base64 (with or without padding).
 */
function isValidBase64(input: string): boolean {
  // Check characters are valid
  if (!VALID_BASE64_CHARS.test(input)) {
    return false;
  }
  
  // Padding must be at the end and at most 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
    // Padding characters cannot appear in the middle
    const beforePadding = input.slice(0, -paddingLength);
    if (beforePadding.includes('=')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the canonical alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 with or without padding, rejects invalid input.
 */
export function decode(input: string): string {
  // Strip whitespace
  const trimmed = input.trim();
  
  // Validate input
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  // Add padding if needed (Buffer.from requires correct padding)
  let padded = trimmed;
  while (padded.length % 4 !== 0) {
    padded += '=';
  }

  try {
    const buffer = Buffer.from(padded, 'base64');
    
    // Check if decoding was successful (invalid base64 may produce empty buffer)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
