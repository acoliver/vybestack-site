/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Add a Set to track observers of this computed value
  o.observers = new Set()
  
  // Register this computed as an observer of its dependencies whenever it's accessed
  const getter = (): T => {
    // If another observer is active, register this computed as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver && 'observers' in activeObserver) {
      // If the active observer has observers, add this computed
      (activeObserver.observers as Set<Observer<unknown>>).add(o as Observer<unknown>)
    }
    
    // Execute the update function to get the latest value
    // We set this computed as the active observer while executing to track dependencies
    const prevActiveObserver = getActiveObserver()
    setActiveObserver(o)
    try {
      o.value = o.updateFn(o.value)
    } finally {
      setActiveObserver(prevActiveObserver)
    }
    
    return o.value!
  }
  
  return getter
}