/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create observer and register it to track dependencies
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Add a Set to track observers of this callback
  observer.observers = new Set()
  
  // Register this observer to track dependencies
  // We run it once initially to establish dependencies
  const prevActiveObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(prevActiveObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Notify all observers that this callback has been disposed
    if (observer.observers) {
      const observers = new Set(observer.observers)
      observers.forEach(obs => {
        updateObserver(obs)
      })
    }
  }
}