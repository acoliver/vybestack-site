/**
 * Encode plain text to Base64 using standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64 decoding.
 * Validates input to ensure it contains only valid Base64 characters.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  const base64UrlRegex = /^[A-Za-z0-9+/_-]*={0,2}$/;
  
  // Check if input contains only standard Base64 characters
  if (!base64Regex.test(input) && !base64UrlRegex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Normalize URL-safe Base64 to standard Base64 if needed
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
