/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject-like structure to hold the computed value and track observers
  const computedSubject: Subject<T> & { observers?: Set<Observer<T>> } = {
    name: options?.name,
    observer: undefined,
    value: value as T,
  }
  
  // Create the observer that will recalculate when dependencies change
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Define the getter function that reads the computed value
  const getter = (): T => {
    // When the computed value is accessed, check if we're being observed
    const observer = getActiveObserver()
    if (observer) {
      // If we're being observed, register ourselves as a dependency
      computedSubject.observer = observer
      
      // Also track in the observers set for notification when we change
      if (!computedSubject.observers) {
        computedSubject.observers = new Set()
      }
      // We need to cast because observer is ObserverR but we need Observer<T>
      // The actual runtime object will be a full Observer<T>
      computedSubject.observers.add(observer as Observer<T>)
    }
    return computedSubject.value
  }
  
  // Wrap the update function to update both the observer value, subject value, and notify observers
  const originalUpdateFn = updateFn
  o.updateFn = (prev?: T) => {
    const result = originalUpdateFn(prev)
    o.value = result
    computedSubject.value = result
    
    // Notify all observers of this computed value
    if (computedSubject.observers) {
      for (const obs of computedSubject.observers) {
        updateObserver(obs)
      }
    }
    
    return result
  }
  
  // Initialize the computed value by running the update function
  // This will track dependencies from inputs
  updateObserver(o)
  
  return getter
}
