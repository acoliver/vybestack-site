/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> & { observers?: Set<Observer<T>> } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Store the observer on the subject
      s.observer = observer
      
      // Also track in the observers set for cleanup
      if (!s.observers) {
        s.observers = new Set()
      }
      // We need to cast because observer is ObserverR but we need Observer<T>
      // The actual runtime object will be a full Observer<T>
      s.observers.add(observer as Observer<T>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers
    if (s.observers) {
      for (const obs of s.observers) {
        updateObserver(obs)
      }
    }
    
    return s.value
  }

  return [read, write]
}
