import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination (public)', () => {
  it('returns default pagination (page=1, limit=5)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBe(5);
  });

  it('supports custom page and limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items.length).toBe(3);
    // Verify correct items for page 2
    expect(response.body.items[0].id).toBe(4); // offset (2-1)*3 + 1 = 4
    expect(response.body.items[2].id).toBe(6);
  });

  it('validates page parameter (rejects non-numeric)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid pagination parameters');
  });

  it('validates page parameter (rejects negative)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid pagination parameters');
  });

  it('validates page parameter (rejects zero)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid pagination parameters');
  });

  it('validates limit parameter (rejects non-numeric)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=xyz');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid pagination parameters');
  });

  it('validates limit parameter (rejects zero)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid pagination parameters');
  });

  it('validates limit parameter (rejects excessive values)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid pagination parameters');
  });

  it('calculates hasNext correctly for final page', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false); // 15 items, page 3 has 5 items, no next page
    expect(response.body.items.length).toBe(5);
  });

  it('handles empty page gracefully', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=4&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(4);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.items.length).toBe(0); // No items on page 4 (only 15 items total)
    expect(response.body.hasNext).toBe(false);
  });

  it('returns correct slice without skipping items', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get page 1
    const page1Response = await request(app).get('/inventory?page=1&limit=5');
    expect(page1Response.body.items.map((item: any) => item.id)).toEqual([1, 2, 3, 4, 5]);
    
    // Get page 2
    const page2Response = await request(app).get('/inventory?page=2&limit=5');
    expect(page2Response.body.items.map((item: any) => item.id)).toEqual([6, 7, 8, 9, 10]);
    
    // Get page 3
    const page3Response = await request(app).get('/inventory?page=3&limit=5');
    expect(page3Response.body.items.map((item: any) => item.id)).toEqual([11, 12, 13, 14, 15]);
  });

  it('includes all required pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('limit');
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
    expect(typeof response.body.page).toBe('number');
    expect(typeof response.body.limit).toBe('number');
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });
});