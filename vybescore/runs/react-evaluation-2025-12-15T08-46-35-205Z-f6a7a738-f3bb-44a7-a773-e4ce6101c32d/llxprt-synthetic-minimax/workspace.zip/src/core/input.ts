/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  notifyObserver,
  subscribe,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = equal === true 
    ? (a: T, b: T) => a === b
    : equal === false 
    ? (_a: T, _b: T) => false
    : typeof equal === 'function'
    ? equal as EqualFn<T>
    : (a: T, b: T) => a === b

  const inputObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (current) => current!,
    subscriptions: new Set(),
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== inputObserver) {
      subscribe(observer as Observer<unknown>, inputObserver as Observer<unknown>)
    }
    return inputObserver.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    const currentValue = inputObserver.value as T
    if (!equalFn(currentValue, nextValue)) {
      inputObserver.value = nextValue
      notifyObserver(inputObserver)
    }
    return inputObserver.value as T
  }

  return [read, write]
}
