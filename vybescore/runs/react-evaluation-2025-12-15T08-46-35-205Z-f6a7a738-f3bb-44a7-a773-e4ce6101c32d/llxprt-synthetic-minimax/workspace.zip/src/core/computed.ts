/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  subscribe,
  getActiveObserver,
  EqualFn,
  notifyObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = equal === true 
    ? (a: T, b: T) => a === b
    : equal === false 
    ? (_a: T, _b: T) => false
    : typeof equal === 'function'
    ? equal as EqualFn<T>
    : (a: T, b: T) => a === b

  const computedObserver: Observer<T> = {
    name: options?.name,
    value: value,
    updateFn: updateFn,
    subscriptions: new Set(),
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const currentActive = getActiveObserver()
    if (currentActive && currentActive !== computedObserver) {
      subscribe(currentActive as Observer<unknown>, computedObserver as Observer<unknown>)
    }
    
    // Store previous value to check for changes
    const previousValue = computedObserver.value
    
    // Always recompute the value when accessed
    updateObserver(computedObserver)
    
    // If value changed, notify all subscribers
    const currentValue = computedObserver.value
    const valueChanged = previousValue === undefined || currentValue === undefined || !equalFn(previousValue as T, currentValue as T)
    
    if (valueChanged && computedObserver.subscribers) {
      // Create a copy to avoid issues during iteration
      const subscribers = new Set(computedObserver.subscribers)
      for (const subscriber of subscribers) {
        updateObserver(subscriber)
      }
    }
    
    return computedObserver.value as T
  }

  return read
}
