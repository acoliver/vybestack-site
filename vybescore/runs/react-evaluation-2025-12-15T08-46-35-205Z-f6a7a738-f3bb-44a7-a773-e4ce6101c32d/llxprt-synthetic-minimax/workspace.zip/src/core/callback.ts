/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, notifyObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    value,
    updateFn,
    subscriptions: new Set(),
    subscribers: new Set(),
  }
  
  let disposed = false

  // Execute the callback to establish dependencies and run initial side effect
  updateObserver(callbackObserver)

  return () => {
    if (disposed) return
    disposed = true
    
    // Clear all subscriptions - notify dependencies that we're no longer interested
    for (const dependency of callbackObserver.subscriptions || []) {
      dependency.subscribers?.delete(callbackObserver)
    }
    callbackObserver.subscriptions?.clear()
    
    // Clear the observer to stop further updates
    callbackObserver.value = undefined as T
  }
}