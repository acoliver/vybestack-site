/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T = unknown> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subscriptions?: Set<Observer> // Observers that this observer depends on
  subscribers?: Set<Observer> // Observers that depend on this observer
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObserver<T>(subject: Observer<T>): void {
  if (!subject.subscribers || subject.subscribers.size === 0) return
  
  // Create a copy to avoid issues with concurrent modification
  const subscribersToUpdate = new Set(subject.subscribers)
  
  for (const subscriber of subscribersToUpdate) {
    updateObserver(subscriber)
  }
}

export function subscribe(observer: Observer<unknown>, dependency: Observer<unknown>): void {
  if (!dependency.subscribers) {
    dependency.subscribers = new Set()
  }
  if (!observer.subscriptions) {
    observer.subscriptions = new Set()
  }
  dependency.subscribers.add(observer)
  observer.subscriptions.add(dependency)
}

export function unsubscribe(observer: Observer<unknown>, dependency: Observer<unknown>): void {
  dependency.subscribers?.delete(observer)
  observer.subscriptions?.delete(dependency)
}
