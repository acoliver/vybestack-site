export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to typical email format rules.
 * Accepts standard addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const trimmed = value.trim();
  // Check for invalid patterns first
  if (/\.\.|^@|\.$|\.@|_/.test(value)) {
    return false;
  }
  // Email regex that allows subdomains with @ but blocks other invalid patterns
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(trimmed);
}

/**
 * Validates US phone numbers supporting common separators and optional +1 prefix.
 * Formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[\s()]/g, '').replace(/-/g, '');
  const phoneRegex = /^(\+?1)?[2-9]\d{9}$/;
  return phoneRegex.test(cleaned);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code: 2-4 digits (leading digit 1-9), subscriber: 6-8 digits.
 * When country code is omitted, number must begin with trunk prefix 0.
 * Allows single spaces or hyphens as separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  // Case 1: With country code +54, optional 9 (mobile), area code 2-4 digits, subscriber 6-8 digits
  const withCountry = /^\+54(9)?[1-9]\d{1,3}\d{6,8}$/;
  // Case 2: Without country code, must have trunk prefix 0, area code 2-4 digits, subscriber 6-8 digits
  const withoutCountry = /^0[1-9]\d{1,3}\d{6,8}$/;
  return withCountry.test(cleaned) || withoutCountry.test(cleaned);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!nameRegex.test(value)) {
    return false;
  }
  if (/\d/.test(value)) {
    return false;
  }
  if (value.trim().length === 0) {
    return false;
  }
  return true;
}

/**
 * Validates credit card numbers using length/prefix validation and Luhn checksum.
 * Accepts Visa (4, 13-16 digits), Mastercard (51-55, 16 digits), AmEx (34/37, 15 digits).
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (!/^\d{13,16}$/.test(cleaned)) {
    return false;
  }
  
  const isVisa = /^4\d{12}(\d{3})?$/.test(cleaned);
  const isMastercard = /^5[1-5]\d{14}$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
