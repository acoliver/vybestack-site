/**
 * Capitalizes the first character of each sentence.
 * Ensures exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure proper spacing after sentence endings
  let result = text.replace(/([.!?])(\S)/g, '$1 $2');
  
  // Collapse multiple spaces into one
  result = result.replace(/\s+/g, ' ');
  
  // Trim leading/trailing whitespace
  result = result.trim();
  
  // Capitalize first letter of text and after sentence boundaries
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s<>"()[\]{}|^`]+[^\s<>"()[\]{}|^`.,!?;:]/g;
  const matches = text.match(urlRegex) || [];
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Converts all http:// URLs to https://, leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/(https?:\/\/)?/gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s]*)/gi, (match, path) => {
    const hasDynamicHint = path.includes('cgi-bin') ||
                          /[?&=]/.test(path) || 
                          /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      return 'https://docs.example.com' + path;
    }
    
    return 'https://example.com' + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
