/**
 * Finds words starting with the given prefix, excluding specified exception words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validates passwords according to strength policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10) {
    return false;
  }
  
  if (/\s/.test(value)) {
    return false;
  }
  
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // Use case-insensitive comparison
  const lowerValue = value.toLowerCase();
  for (let i = 0; i < lowerValue.length - 3; i++) {
    const seq = lowerValue.substring(i, i + 2);
    const nextSeq = lowerValue.substring(i + 2, i + 4);
    if (seq === nextSeq) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  if (ipv4Pattern.test(value) && !value.includes('::')) {
    return false;
  }
  
  const ipv6WithShorthand = /::/;
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  
  return ipv6WithShorthand.test(value) || ipv6Pattern.test(value);
}
