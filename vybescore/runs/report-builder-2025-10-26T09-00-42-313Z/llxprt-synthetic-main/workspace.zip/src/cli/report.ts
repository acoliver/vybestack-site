#!/usr/bin/env node

import { writeFileSync, readFileSync, existsSync } from 'node:fs';
import type { FormatType, ReportOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    console.error('Missing required --format argument');
    process.exit(1);
  }

  const format = args[formatIndex + 1];
  if (format !== 'markdown' && format !== 'text') {
    console.error('Unsupported format');
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  return {
    inputFile,
    format: format as FormatType,
    outputPath,
    includeTotals
  };
}

function main() {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArgs();

    if (!existsSync(inputFile)) {
      throw new Error(`Input file not found: ${inputFile}`);
    }

    const jsonData = readFileSync(inputFile, 'utf8');
    let reportData;
    
    try {
      reportData = JSON.parse(jsonData);
    } catch (error) {
      throw new Error(`Invalid JSON in input file: ${error instanceof Error ? error.message : String(error)}`);
    }

    const validatedData = validateReportData(reportData);
    const options: ReportOptions = { includeTotals };

    let output: string;
    
    switch (format) {
      case 'markdown':
        output = renderMarkdown(validatedData, options);
        break;
      case 'text':
        output = renderText(validatedData, options);
        break;
      default:
        throw new Error('Unsupported format');
    }

    if (outputPath) {
      writeFileSync(outputPath, output, 'utf8');
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
