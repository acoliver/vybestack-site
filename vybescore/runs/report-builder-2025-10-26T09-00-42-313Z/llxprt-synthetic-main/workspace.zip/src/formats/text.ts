import type { ReportData, ReportOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  let output = '';

  // Add title
  output += `${data.title}\n`;

  // Add summary
  output += `${data.summary}\n`;

  // Add entries section
  output += '\nEntries:\n';
  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }

  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    output += `\nTotal: ${formatAmount(total)}`;
  }

  return output;
}