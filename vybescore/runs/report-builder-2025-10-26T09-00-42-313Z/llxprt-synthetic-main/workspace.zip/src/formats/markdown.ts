import type { ReportData, ReportOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  let output = '';

  // Add title
  output += `# ${data.title}\n\n`;

  // Add summary
  output += `${data.summary}\n\n`;

  // Add entries section
  output += '## Entries\n';
  for (const entry of data.entries) {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }

  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    output += `\n**Total:** ${formatAmount(total)}`;
  }

  return output;
}