import type { ReportData, ReportEntry } from './types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const dataObj = data as { title?: unknown; summary?: unknown; entries?: unknown };

  if (typeof dataObj.title !== 'string') {
    throw new Error('Missing or invalid title field');
  }

  if (typeof dataObj.summary !== 'string') {
    throw new Error('Missing or invalid summary field');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Missing or invalid entries field');
  }

  for (let i = 0; i < dataObj.entries.length; i++) {
    const entry = dataObj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }

    const entryObj = entry as { label?: unknown; amount?: unknown };
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
    }
  }

  return data as ReportData;
}