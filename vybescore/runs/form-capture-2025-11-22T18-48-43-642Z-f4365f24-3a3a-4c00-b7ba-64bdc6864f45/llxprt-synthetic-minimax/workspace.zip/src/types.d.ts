// Global type declarations

export {};

declare global {
  namespace NodeJS {
    interface ProcessEnv {
      NODE_ENV?: string;
      PORT?: string;
    }
  }
}

declare module 'sql.js' {
  export interface Database {
    exec(sql: string): { values: unknown[][]; columns: string[] }[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    bind(params: unknown[]): void;
    run(params: unknown[]): void;
    step(): boolean;
    getAsObject(): Record<string, unknown>;
    free(): void;
  }

  export interface SqlJsStatic {
    new (buffer?: Uint8Array): Database;
  }

  export interface SqlJsConfig {
    locateFile?: (file: string) => string;
  }

  const initSqlJsModule: {
    initSqlJs: (config?: SqlJsConfig) => Promise<SqlJsStatic>;
    SqlJs: SqlJsStatic;
  };

  export default initSqlJsModule;
}