#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): CliOptions {
  const args = argv.slice(2); // Remove 'node' and script name

  if (args.length < 2) {
    printUsage();
    process.exit(1);
  }

  const inputPath = args[0];

  // Parse flags
  let format: 'markdown' | 'text' | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1] as 'markdown' | 'text';
      i++; // Skip next argument as it's the value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return {
    inputPath,
    format,
    outputPath,
    includeTotals
  };
}

function printUsage(): void {
  console.error('Usage: report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('  format: markdown, text');
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const jsonData = JSON.parse(rawData);

    // Validate required fields
    if (!jsonData.title || !jsonData.summary || !jsonData.entries) {
      console.error('Error: Invalid report data. Missing required fields: title, summary, entries');
      process.exit(1);
    }

    // Validate entries structure
    if (!Array.isArray(jsonData.entries)) {
      console.error('Error: Invalid report data. "entries" must be an array');
      process.exit(1);
    }

    for (let i = 0; i < jsonData.entries.length; i++) {
      const entry = jsonData.entries[i];
      if (!entry.label || typeof entry.amount !== 'number') {
        console.error(`Error: Invalid entry at index ${i}. Required fields: label (string), amount (number)`);
        process.exit(1);
      }
    }

    return jsonData as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if ('code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found '${filePath}'`);
      } else {
        console.error(`Error: Failed to read file '${filePath}': ${error.message}`);
      }
    } else {
      console.error(`Error: Failed to read file '${filePath}'`);
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${outputPath}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(content);
  }
}

// Main execution
function main(): void {
  const options = parseArgs(process.argv);
  const reportData = loadReportData(options.inputPath);

  let output: string;

  if (options.format === 'markdown') {
    output = renderMarkdown(reportData, options.includeTotals);
  } else {
    output = renderText(reportData, options.includeTotals);
  }

  writeOutput(output, options.outputPath);
}

main();
