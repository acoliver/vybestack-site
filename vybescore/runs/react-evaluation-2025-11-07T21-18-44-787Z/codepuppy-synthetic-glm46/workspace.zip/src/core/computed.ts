/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  addObserver,
  notifyObservers,
  Subject,
  EqualFn,
  Options
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (a: T, b: T) => a === b : undefined
  }
  return equal
}

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Create a dummy subject for this computed value to track observers
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (_prevValue?: T) => {
      // For computed values, we don't pass the previous value as the computation input
      // The updateFn should compute based on dependencies, not based on previous value
      return updateFn()
    },
  }
  
  let isUpdating = false
  
  const computed: GetterFn<T> = () => {
    // Register dependencies - if there's an active observer, it depends on this computed
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      addObserver(subject, activeObserver as Observer<T>)
    }
    
    // Prevent re-entrant updates
    if (isUpdating) {
      return subject.value!
    }
    
    isUpdating = true
    try {
      const oldValue = subject.value
      // Call updateObserver which will run the updateFn and track dependencies
      updateObserver(observer)
      subject.value = observer.value!
      
      // Check equality if function provided
      if (equalFn && oldValue !== undefined && subject.value !== undefined && equalFn(oldValue, subject.value)) {
        subject.value = oldValue
      }
      
      // Only notify dependents if the value actually changed
      if (!equalFn || oldValue === undefined || !equalFn(oldValue, subject.value)) {
        notifyObservers(subject)
      }
    } finally {
      isUpdating = false
    }
    
    return subject.value!
  }
  
  // Initialize the computed value if it wasn't provided
  if (subject.value === undefined) {
    // This will call updateObserver with the current value (undefined)
    // The updateFn should handle undefined by using its default parameter
    computed()
  }
  
  return computed
}