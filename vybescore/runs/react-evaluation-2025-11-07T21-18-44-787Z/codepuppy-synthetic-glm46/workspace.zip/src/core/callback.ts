/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue as T
      return updateFn(prevValue)
    },
  }
  
  // Execute initial callback to track dependencies
  updateObserver(observer)
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
  }
  
  return unsubscribe
}