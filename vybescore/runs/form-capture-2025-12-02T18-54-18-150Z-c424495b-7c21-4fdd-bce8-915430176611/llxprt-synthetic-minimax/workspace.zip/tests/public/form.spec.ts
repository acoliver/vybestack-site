import { describe, expect, it } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // Simple test to verify the server can handle requests
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);

    expect(response.text).toContain('Contact Us');
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Email');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'Greater London',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    await request('http://localhost:3535')
      .post('/submit')
      .send(submissionData)
      .expect(302);

    // Check if database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
