import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize sql.js
let db: Database;

// Configure view engine and middleware
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Database initialization
async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
  });

  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  const dataDir = path.dirname(dbPath);

  // Ensure data directory exists
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let database: Database;
  
  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    database = new SQL.Database(buffer);
  } else {
    database = new SQL.Database();
    
    // Create schema
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf-8');
    database.exec(schema);
  }

  return database;
}

// Save database to file
function saveDatabase(): void {
  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings, spaces, and dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Contact Us - International Edition'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData,
      title: 'Contact Us - International Edition'
    });
  }

  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);

  stmt.free();
  saveDatabase();

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => { // eslint-disable-line @typescript-eslint/no-unused-vars
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  if (db) {
    db.close();
  }
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully');
  if (db) {
    db.close();
  }
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    db = await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;