#!/usr/bin/env node

import * as fs from 'fs';
import { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function printUsage() {
  console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('Supported formats: markdown, text');
}

function parseArgs(): { 
  dataFile: string; 
  format: string; 
  outputFile?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    printUsage();
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    printUsage();
    process.exit(1);
  }
  
  const format = args[2];
  
  let outputFile: string | undefined;
  let includeTotals = false;
  
  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        console.error('--output flag requires a file path');
        process.exit(1);
      }
      outputFile = args[i + 1];
      i++; // Skip the next argument as it's the output path
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${args[i]}`);
      printUsage();
      process.exit(1);
    }
  }
  
  return { dataFile, format, outputFile, includeTotals };
}

function validateFormat(format: string): format is 'markdown' | 'text' {
  return format === 'markdown' || format === 'text';
}

function validateData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Data must be an object');
  }
  
  const reportData = data as ReportData;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid title');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid summary');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid entries array');
  }
  
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Each entry must be an object');
    }
    
    if (typeof entry.label !== 'string') {
      throw new Error('Missing or invalid label in entry');
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error('Missing or invalid amount in entry');
    }
  }
}

function main() {
  const { dataFile, format, outputFile, includeTotals } = parseArgs();
  
  if (!validateFormat(format)) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  try {
    const dataContent = fs.readFileSync(dataFile, 'utf-8');
    const data: ReportData = JSON.parse(dataContent);
    
    validateData(data);
    
    let output: string;
    if (format === 'markdown') {
      output = renderMarkdown(data, { includeTotals });
    } else {
      output = renderText(data, { includeTotals });
    }
    
    if (outputFile) {
      fs.writeFileSync(outputFile, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON in ${dataFile}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: ${String(error)}`);
    }
    process.exit(1);
  }
}

main();