export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(num: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = num.length - 1; i >= 0; i--) {
    let digit = parseInt(num[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses using a comprehensive regex pattern
 * Accepts typical addresses such as name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  const noDoubleDots = !value.includes('..');
  const noTrailingDot = !value.endsWith('.');
  const noUnderscoresInDomain = !value.split('@')[1]?.includes('_');
  return emailRegex.test(value) && noDoubleDots && noTrailingDot && noUnderscoresInDomain;
}

/**
 * Validates US phone numbers with support for various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Normalize the input by removing non-digit characters except for + at the beginning
  const normalized = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  const phoneWithoutCountry = normalized.startsWith('+1') ? normalized.substring(2) : normalized;
  
  // Check minimum length (10 digits for standard US number)
  if (phoneWithoutCountry.length < 10) return false;
  
  // Extract the 10-digit phone number
  const phoneNumber = phoneWithoutCountry.length === 10 ? phoneWithoutCountry : phoneWithoutCountry.substring(0, 10);
  
  // Validate area code (first 3 digits cannot start with 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Full phone validation regex
  const phoneRegex = /^(?:\+?1)?\s*\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers with complex formatting rules
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex - matches all accepted formats
  const argentinePhoneRegex = /^\+54(?:9)?(\d{2,4})(\d{6,8})$/;
  const argentinePhoneWith0Regex = /^0(\d{2,4})(\d{6,8})$/;
  
  // Extract parts for detailed validation
  const mainMatch = normalized.match(argentinePhoneRegex);
  const zeroMatch = normalized.match(argentinePhoneWith0Regex);
  
  const match = mainMatch || zeroMatch;
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits and start with 1-9 (not 0)
  if (!/^[1-9]\d{0,3}$/.test(areaCode)) return false;
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  // When country code is omitted, must begin with trunk prefix 0
  if (!value.includes('+54') && !value.startsWith('0')) return false;
  
  // Check for valid format with spaces/hyphens - be more permissive
  const validFormatRegex = /^(?:\+54\s*)?(?:9\s*)?\d{2,4}[\s-]?\d{3}[\s-]?\d{4}$|^(?:\+54\s*)?(?:9\s*)?\d{2,4}[\s-]?\d{4}[\s-]?\d{4}$|^0\d{2,4}[\s-]?\d{3}[\s-]?\d{4}$|^(?:0\d{2,4}[\s-]?\d{4}[\s-]?\d{4}$)/;
  
  return validFormatRegex.test(value) || (value.includes('+54') && /^(\+54\s*)?\d{3,4}[\s-]?\d{7,8}$/.test(value));
}

/**
 * Validates personal names with support for unicode letters, accents, apostrophes, and hyphens
 * Rejects digits, symbols, and invalid name patterns like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Name regex that allows unicode letters, spaces, apostrophes, and hyphens
  // \p{L} matches any unicode letter (including accented characters)
  const nameRegex = /^[\p{L}\-'’\s]+$/u;
  
  // Basic pattern match
  if (!nameRegex.test(value)) return false;
  
  // Reject names that contain digits or non-name symbols
  if (/\d/.test(value)) return false;
  
  // Reject names with unusual symbols that might indicate invalid data
  const invalidSymbols = /[!@#$%^&*()_+=[\]{}|\\:";<>,./?~`]/;
  if (invalidSymbols.test(value)) return false;
  
  // Ensure the name doesn't look like "X Æ A-12" style names (digits mixed with letters)
  // We're being stricter here - names with digits mixed in should be rejected
  const invalidPatternWithDigits = /[A-Za-zÀ-ÖØ-öø-ÿ]\d|\d[A-Za-zÀ-ÖØ-öø-ÿ]/;
  if (invalidPatternWithDigits.test(value)) return false;
  
  // Should not be empty or just spaces
  if (value.trim() === '') return false;
  
  // At least one letter character
  if (!/[\p{L}]/u.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers using Luhn checksum and basic format validation
 * Accepts Visa/Mastercard/AmEx prefixes and lengths
 */
export function isValidCreditCard(value: string): boolean {
  // Remove non-digit characters
  const normalized = value.replace(/\D/g, '');
  
  // Check for minimum length
  if (normalized.length < 13 || normalized.length > 19) return false;
  
  // Check prefixes for major card types
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 2221-2720 or 51-55, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(?:5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{12})))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const validPrefix = visaRegex.test(normalized) || mastercardRegex.test(normalized) || amexRegex.test(normalized);
  if (!validPrefix) return false;
  
  // Run Luhn checksum validation
  return runLuhnCheck(normalized);
}