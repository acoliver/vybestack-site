/**
 * Helper function to escape special regex characters
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds words starting with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Helper function to escape special regex characters in the prefix
  
  // Create word boundary regex pattern for words with given prefix
  const prefixRegex = new RegExp(`\\b${escapeRegex(prefix)}\\w*`, 'gi');
  const matches = text.match(prefixRegex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  // Filter out exceptions and return unique matches
  return matches
    .map(match => match)
    .filter(word => !exceptionsSet.has(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Helper function to escape special regex characters in the token
  
  // Escape special regex characters in the token
  const escapedToken = escapeRegex(token);
  
  // Use lookbehind to include the digit before the token
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validates passwords according to security policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol
 * No whitespace, no immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // This pattern checks for any sequence of 2 or more characters repeated immediately
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // Check for pure IPv4 addresses (to exclude them first)
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) return false;
  
  // IPv6 pattern with shorthand (::) support
  // This pattern handles various IPv6 formats including:
  // - Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8:85a3::8a2e:370:7334
  // - Loopback: ::1
  // - Compressed: ::ffff:192.0.2.128 (though IPv4 embedded form is tricky)
  const ipv6Regex = /\b([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b::1\b|\b::[0-9a-fA-F]{1,4}\b|\b[0-9a-fA-F]{1,4}::\b|\b[0-9a-fA-F]{1,4}:([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b|\b::[fF]{4}(?::(?:\d{1,3}\.){3}\d{1,3})?\b/;
  
  return ipv6Regex.test(value);
}
