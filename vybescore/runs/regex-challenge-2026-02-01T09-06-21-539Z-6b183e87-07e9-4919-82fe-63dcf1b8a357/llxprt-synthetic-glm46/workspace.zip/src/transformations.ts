/**
 * Capitalizes the first character of each sentence, preserving spacing rules
 * Inserts exactly one space between sentences and collapses extra spaces
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences using punctuation .?! followed by whitespace or end of string
  const sentences = text.split(/([.?!]+(?:\s+|$))/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // If this part is punctuation followed by whitespace, we need to capitalize the next part
    if (/^[.?!]+\s*$/.test(part) || /^[.?!]+\s+/.test(part)) {
      result += part;
      capitalizeNext = true;
    } else if (capitalizeNext && part.trim()) {
      // Capitalize the first alphabetic character of the part
      const sentencesWords = part.split(/\b/);
      for (let j = 0; j < sentencesWords.length; j++) {
        const word = sentencesWords[j];
        if (j === 0 && word.match(/^[a-z]/)) {
          result += word.charAt(0).toUpperCase() + word.slice(1);
          capitalizeNext = false;
        } else {
          result += word;
        }
      }
    } else {
      result += part;
      capitalizeNext = false;
    }
  }
  
  // Collapse multiple spaces into a single space and normalize spacing around punctuation
  return result.replace(/\s+/g, ' ').replace(/\s([.?!])/, '$1');
}

/**
 * Finds URLs in the text and returns them without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  const urlRegex = /(https?:\/\/[^\s<>"]+)/gi;
  const urls: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[1];
    // Remove trailing punctuation like .,!?) etc.
    url = url.replace(/[.,;:!?)]+$/, '');
    urls.push(url);
  }
  
  return urls;
}

/**
 * Replaces all http:// URLs with https:// while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites example.com URLs with the following rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com URLs and capture the path
  return text.replace(/http:\/\/(example\.com)(\/[^?\s]*)?(\?[^#\s]*)?(#[^?\s]*)?/gi, (match, host, path = '', query = '', fragment = '') => {
    // Upgrade scheme to https by default
    let newHost = host;
    const newPath = path;
    
    // Check if path contains dynamic hints that would prevent host rewrite
    const hasDynamicHints = /\/cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/.test(path) || query?.includes('=');
    
    // If path begins with /docs/ and doesn't have dynamic hints, rewrite the host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      newHost = 'docs.example.com';
    }
    
    return `https://${newHost}${newPath}${query}${fragment}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings
 * Returns 'N/A' when the format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Check for valid month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Check for valid day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check for February
  const isLeapYear = (year: string) => {
    const yr = parseInt(year, 10);
    return (yr % 4 === 0 && yr % 100 !== 0) || yr % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(year)) {
    if (day < 1 || day > 29) return 'N/A';
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
