#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ReportData, RenderOptions } from '../types.js';
import { renderers } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        fatalError('Error: --format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        fatalError('Error: --output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      fatalError(`Error: Unknown option: ${arg}`);
    } else {
      // Positional argument - input file
      if (result.inputFile) {
        fatalError(`Error: Too many input files specified: "${arg}"`);
      }
      result.inputFile = arg;
    }

    i++;
  }

  // Validate required arguments
  if (!result.inputFile) {
    fatalError('Error: Input file path is required');
  }

  if (!result.format) {
    fatalError('Error: --format is required (supported: markdown, text)');
  }

  return result;
}

function fatalError(message: string): never {
  console.error(message);
  process.exit(1);
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object at root level');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: "title" field is required and must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: "summary" field is required and must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: "entries" field is required and must be an array');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(
        `Invalid report data: entry at index ${index} must be an object with "label" and "amount"`
      );
    }

    const e = entry as Record<string, unknown>;

    if (typeof e.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${index} must have a "label" string field`
      );
    }

    if (typeof e.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${index} must have an "amount" number field`
      );
    }

    return { label: e.label, amount: e.amount };
  });

  return { title: obj.title, summary: obj.summary, entries };
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Resolve input file path relative to current working directory
  const inputPath = path.resolve(process.cwd(), args.inputFile);

  // Check if input file exists
  if (!fs.existsSync(inputPath)) {
    fatalError(`Error: Input file not found: ${args.inputFile}`);
  }

  // Read and parse JSON
  let jsonData: unknown;
  try {
    const content = fs.readFileSync(inputPath, 'utf-8');
    jsonData = JSON.parse(content);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    fatalError(`Error: Failed to parse JSON file: ${message}`);
  }

  // Validate data structure
  let reportData: ReportData;
  try {
    reportData = validateReportData(jsonData);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    fatalError(`Error: ${message}`);
  }

  // Get renderer
  const renderer = renderers[args.format];
  if (!renderer) {
    fatalError(`Error: Unsupported format: "${args.format}" (supported: markdown, text)`);
  }

  // Render report
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const output = renderer(reportData, options);

  // Write output
  if (args.outputPath) {
    try {
      const outputPath = path.resolve(process.cwd(), args.outputPath);
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      fatalError(`Error: Failed to write output file: ${message}`);
    }
  } else {
    console.log(output);
  }
}

try {
  main();
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  fatalError(`Error: ${message}`);
}
