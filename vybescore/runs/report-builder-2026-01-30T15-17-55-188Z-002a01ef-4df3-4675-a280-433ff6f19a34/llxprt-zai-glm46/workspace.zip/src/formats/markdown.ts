/**
 * Markdown format renderer for reports.
 */

import type { ReportData, RenderOptions, ReportEntry } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function formatEntry(entry: ReportEntry): string {
  return `- **${entry.label}** — ${formatAmount(entry.amount)}`;
}

export const renderMarkdown = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  for (const entry of data.entries) {
    lines.push(formatEntry(entry));
  }

  // Optional total
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(``);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
