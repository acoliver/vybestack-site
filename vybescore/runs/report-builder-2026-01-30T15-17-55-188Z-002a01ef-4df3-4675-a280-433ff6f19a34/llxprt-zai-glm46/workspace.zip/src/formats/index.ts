/**
 * Format registry for report renderers.
 */

import type { Renderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const renderers: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};
