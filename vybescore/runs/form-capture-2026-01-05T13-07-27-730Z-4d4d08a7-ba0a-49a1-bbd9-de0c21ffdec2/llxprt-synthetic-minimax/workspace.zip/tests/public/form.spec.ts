import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { load as cheerioLoad } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // Test that the form renders with all required fields
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);
    
    const $ = cheerioLoad(response.text);
    
    // Check for all form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1234567890'
    };
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(302); // Should redirect to thank you page
    
    expect(response.headers.location).toContain('/thank-you');
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
  
  it('validates required fields', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: '', // Empty required field
        lastName: 'Doe'
        // Missing other required fields
      })
      .expect(400); // Should return validation errors
    
    const $ = cheerioLoad(response.text);
    expect($('.error-list').length).toBeGreaterThan(0);
  });
  
  it('validates email format', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'invalid-email', // Invalid format
      phone: '+1234567890'
    };
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(400);
    
    const $ = cheerioLoad(response.text);
    expect($('.error-list').text()).toContain('email');
  });
  
  it('accepts international phone formats', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'UK',
      email: 'john@example.com',
      phone: '+44 20 7946 0958' // UK format
    };
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toContain('/thank-you');
  });
  
  it('accepts international postal codes', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA', // UK format
      country: 'UK',
      email: 'john@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toContain('/thank-you');
  });
  
  it('shows humorous thank you page', async () => {
    const response = await request('http://localhost:3535')
      .get('/thank-you?firstName=John')
      .expect(200);
    
    const $ = cheerioLoad(response.text);
    expect($('h1').text()).toContain('Thank you, John!');
    expect($('p').first().text()).toContain('treasure your data');
    expect($('p').eq(1).text()).toContain('Why did you give your info');
  });
});
