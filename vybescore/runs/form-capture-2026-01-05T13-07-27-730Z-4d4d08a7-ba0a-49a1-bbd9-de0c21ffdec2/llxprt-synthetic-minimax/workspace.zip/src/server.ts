import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Configure EJS as view engine
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Database configuration
const DB_FILE_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
let db: Database | null = null;

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    // Load existing database or create new one
    let dbExists = false;
    try {
      await fs.access(DB_FILE_PATH);
      dbExists = true;
    } catch {
      // File doesn't exist, we'll create it
    }

    if (dbExists) {
      const dbBuffer = await fs.readFile(DB_FILE_PATH);
      db = new SQL.Database(new Uint8Array(dbBuffer));
    } else {
      db = new SQL.Database();
      // Create submissions table
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf-8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to file
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    await fs.writeFile(DB_FILE_PATH, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
interface ValidationResult {
  isValid: boolean;
  errors: string[];
  values: Record<string, string>;
}

function validateFormData(data: Record<string, string>): ValidationResult {
  const errors: string[] = [];
  const values: Record<string, string> = {};

  // Required fields validation
  const requiredFields = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim() || '';
    values[field] = value;
    
    if (!value) {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`);
    }
  }

  // Email validation (simple but effective)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (values.email && !emailRegex.test(values.email)) {
    errors.push('Please provide a valid email address');
  }

  // Phone validation (international format support)
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  if (values.phone && !phoneRegex.test(values.phone)) {
    errors.push('Please provide a valid phone number');
  }

  // Postal code validation (alphanumeric support)
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  if (values.postalCode && !postalRegex.test(values.postalCode)) {
    errors.push('Please provide a valid postal code');
  }

  return {
    isValid: errors.length === 0,
    errors,
    values
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const validation = validateFormData(req.body);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        values: validation.values
      });
    }

    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      validation.values.firstName,
      validation.values.lastName,
      validation.values.streetAddress,
      validation.values.city,
      validation.values.stateProvince,
      validation.values.postalCode,
      validation.values.country,
      validation.values.email,
      validation.values.phone
    ]);

    stmt.free();
    
    // Save database changes
    await saveDatabase();

    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(validation.values.firstName)}`);
  } catch (error) {
    console.error('Submission error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  // Save database before exit
  if (db) {
    try {
      await saveDatabase();
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(PORT, '0.0.0.0', () => {
      console.log(` Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
