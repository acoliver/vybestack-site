#!/usr/bin/env node

import * as fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions, FormatRenderer } from '../types.js';

/**
 * Maps format names to their rendering functions
 */
const FORMATS: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parses command line arguments
 */
function parseArgs(args: string[]): {
  inputPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 1) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputPath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    switch (arg) {
      case '--format':
        if (!nextArg) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = nextArg;
        i++;
        break;
      case '--output':
        if (!nextArg) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = nextArg;
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument: ${arg}`);
        process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputPath, format, outputPath, includeTotals };
}

/**
 * Validates and parses report data from JSON
 */
function parseReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>,
  };
}

/**
 * Main CLI execution
 */
function main(): void {
  const args = process.argv.slice(2);
  const { inputPath, format, outputPath, includeTotals } = parseArgs(args);

  // Check if format is supported
  const renderer = FORMATS[format];
  if (!renderer) {
    console.error(`Error: Unsupported format: ${format}`);
    console.error(`Supported formats: ${Object.keys(FORMATS).join(', ')}`);
    process.exit(1);
  }

  // Read input file
  let inputContent: string;
  try {
    inputContent = fs.readFileSync(inputPath, 'utf-8');
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: Failed to read input file "${inputPath}": ${errorMessage}`);
    process.exit(1);
  }

  // Parse JSON
  let rawData: unknown;
  try {
    rawData = JSON.parse(inputContent);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: Failed to parse JSON from "${inputPath}": ${errorMessage}`);
    process.exit(1);
  }

  // Validate and parse report data
  let reportData: ReportData;
  try {
    reportData = parseReportData(rawData);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }

  // Render report
  const options: RenderOptions = { includeTotals };
  const output = renderer(reportData, options);

  // Write output
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Error: Failed to write output file "${outputPath}": ${errorMessage}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
