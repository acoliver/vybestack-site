/**
 * Represents a single entry in the report
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Report data structure matching fixtures/data.json
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering the report
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Format function signature shared by all formatters
 */
export type FormatRenderer = (data: ReportData, options: RenderOptions) => string;
