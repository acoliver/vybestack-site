/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  const normalized = normalizeInput(input);

  if (!isValidBase64(normalized)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    if (buffer.length === 0 && normalized.length > 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Normalize Base64 input by stripping whitespace and adding padding if missing.
 */
function normalizeInput(input: string): string {
  const trimmed = input.replace(/\s/g, '');
  
  // Add padding if necessary
  const paddingLength = (4 - (trimmed.length % 4)) % 4;
  return trimmed + '='.repeat(paddingLength);
}

/**
 * Validate that input is valid Base64 format.
 */
function isValidBase64(input: string): string {
  // Empty string is not valid
  if (input.length === 0) {
    return '';
  }
  
  // Check length is multiple of 4
  if (input.length % 4 !== 0) {
    return '';
  }
  
  // Check for valid Base64 characters (standard alphabet)
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Pattern.test(input)) {
    return '';
  }
  
  // Check padding is only at the end and no more than 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return '';
    }
    // Padding can only be 1 or 2 characters when present
    if (paddingLength === 1) {
      // For single padding, the previous char must be from the first 64 chars
      const prevChar = input[input.length - 2];
      if (!prevChar || !isFirst64Chars(prevChar)) {
        return '';
      }
    }
  }
  
  return input;
}

/**
 * Check if a character is from the first 64 characters of Base64 alphabet.
 */
function isFirst64Chars(char: string): boolean {
  return /^[A-Za-z0-9+/]$/.test(char);
}
