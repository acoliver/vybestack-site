/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  SubjectNode,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subjectNode: SubjectNode<T> = {
    name: options?.name,
    value,
    dependents: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subjectNode.dependents.add(observer)
    }
    return subjectNode.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = subjectNode.value
    subjectNode.value = nextValue
    
    // Notify all dependents when value actually changes
    if (subjectNode.dependents && !Object.is(oldValue, nextValue)) {
      for (const dependent of [...subjectNode.dependents]) {
        updateObserver(dependent)
      }
    }
    return subjectNode.value
  }

  return [read, write]
}
