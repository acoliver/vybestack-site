/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  setActiveObserver,
  updateObserver,
  UpdateFn,
  Observer
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer = {
    name: 'callback',
    value,
    updateFn: () => {
      if (disposed) return value
      return updateFn(value)
    },
    dependents: new Set()
  }
  
  // Set active observer during registration to track dependencies
  setActiveObserver(observer as Observer)
  try {
    updateObserver(observer)
  } finally {
    setActiveObserver(undefined)
  }
  
  return () => {
    if (disposed) return
    disposed = true
  }
}
