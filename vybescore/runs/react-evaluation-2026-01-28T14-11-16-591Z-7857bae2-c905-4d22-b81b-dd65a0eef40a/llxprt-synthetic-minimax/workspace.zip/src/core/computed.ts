/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  setActiveObserver,
  updateObserver,
  EqualFn,
  Observer
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set()
  }
  
  const getter: GetterFn<T> = () => {
    // Set this observer as active before computation
    setActiveObserver(observer as Observer)
    try {
      updateObserver(observer)
    } finally {
      setActiveObserver(undefined)
    }
    
    // Notify dependents of computed value changes
    if (observer.dependents) {
      for (const dependent of [...observer.dependents]) {
        updateObserver(dependent)
      }
    }
    
    return observer.value!
  }

  return getter
}
