/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T = unknown> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependents?: Set<Observer>
}

export type SubjectNode<T> = {
  name?: string
  value: T
  dependents?: Set<Observer>
}

export type ObserverNode<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependents?: Set<Observer>
}

export type SubjectR = Subject<unknown>
export type SubjectV = Subject<unknown>
export type ObserverR = Observer<unknown>
export type ObserverV = Observer<unknown>

export type Subject<T> = {
  name?: string
  value: T
  dependents?: Set<Observer>
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: { value?: T; updateFn: UpdateFn<T> }): void {
  const previous = activeObserver
  activeObserver = observer as Observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}
