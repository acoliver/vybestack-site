#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): ReportOptions & { filePath: string } {
  const args = argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1] as 'markdown' | 'text';
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format option is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }
  
  return { filePath, format, output, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const typedData = data as Record<string, unknown>;
  
  if (!typedData.title || typeof typedData.title !== 'string') {
    throw new Error('Invalid JSON: "title" field is required and must be a string');
  }
  
  if (!typedData.summary || typeof typedData.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field is required and must be a string');
  }
  
  if (!Array.isArray(typedData.entries)) {
    throw new Error('Invalid JSON: "entries" field is required and must be an array');
  }
  
  const entries = typedData.entries as unknown[];
  
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }
    
    const typedEntry = entry as Record<string, unknown>;
    
    if (!typedEntry.label || typeof typedEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof typedEntry.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
  
  // Construct the properly typed return object
  const validatedData: ReportData = {
    title: String(typedData.title),
    summary: String(typedData.summary),
    entries: entries.map(entry => {
      const typedEntry = entry as Record<string, unknown>;
      return {
        label: String(typedEntry.label),
        amount: Number(typedEntry.amount)
      };
    })
  };
  
  return validatedData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found - ${filePath}`);
      } else if (error.message.includes('JSON.parse')) {
        console.error('Error: Invalid JSON file - parse error');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read JSON file');
    }
    process.exit(1);
  }
}

function routeFormatter(format: 'markdown' | 'text') {
  const formatters = {
    markdown: renderMarkdown,
    text: renderText
  };
  
  return formatters[format];
}

function handleOutput(output: string | undefined, content: string): void {
  if (output) {
    try {
      writeFileSync(output, content, 'utf-8');
    } catch (error) {
      console.error('Error: Failed to write output file');
      process.exit(1);
    }
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  const options = parseArgs(process.argv);
  const data = loadReportData(options.filePath);
  const formatter = routeFormatter(options.format);
  
  if (!formatter) {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  const content = formatter(data, options);
  handleOutput(options.output, content);
}

main();
