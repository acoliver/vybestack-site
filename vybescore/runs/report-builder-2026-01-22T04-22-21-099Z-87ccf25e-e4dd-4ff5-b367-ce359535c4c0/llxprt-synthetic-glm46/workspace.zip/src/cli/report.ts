#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { ReportData, FormatOptions, Format } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

const renderers: Record<Format, import('../types.js').Renderer> = {
  markdown: markdownRenderer,
  text: textRenderer
};

function parseArgs(): { dataPath: string; format: Format; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  let format: Format = 'markdown'; // Default value
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      const formatStr = args[i + 1];
      if (formatStr !== 'markdown' && formatStr !== 'text') {
        console.error('Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      format = formatStr as Format;
      i++; // Skip format value
    } else if (args[i] === '--output') {
      outputPath = args[i + 1];
      i++; // Skip output path value
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry ${index} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry ${index} label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry ${index} amount must be a number`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs();
    
    // Read and parse JSON file
    let data: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error parsing JSON file: ${error.message}`);
      } else {
        console.error(`Error reading file: ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }
    
    // Validate data
    const reportData = validateReportData(data);
    
    // Render report
    const renderer = renderers[format];
    const options: FormatOptions = { includeTotals };
    const output = renderer.render(reportData, options);
    
    // Output result
    if (outputPath) {
      writeFile(outputPath, output, 'utf-8')
        .then(() => {
          console.log(`Report written to ${outputPath}`);
        })
        .catch((error) => {
          console.error(`Error writing to file: ${error.message}`);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
