import type { EqualFn, GetterFn, InputPair, Options, SetterFn, Subject } from '../types/reactive.js'
import { getActiveObserver } from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options,
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: equal || ((a: T, b: T) => a === b),
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subject.observers.add(observer)
    }
    return subject.value
  }

  const setter: SetterFn<T> = (newValue: T): T => {
    if (!(subject.equalFn as EqualFn<T>)(subject.value, newValue)) {
      subject.value = newValue
      
      // Notify all observers by calling their update functions
      for (const observer of subject.observers) {
        if ('updateFn' in observer && typeof observer.updateFn === 'function') {
          try {
            observer.updateFn()
          } catch (e) {
            // Ignore errors in callback execution
          }
        }
      }
    }
    return subject.value
  }

  return [getter, setter]
}