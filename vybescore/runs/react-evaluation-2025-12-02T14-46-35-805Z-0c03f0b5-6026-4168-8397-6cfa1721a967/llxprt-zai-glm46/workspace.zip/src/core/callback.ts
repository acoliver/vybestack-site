import type { UnsubscribeFn, UpdateFn, Observer } from '../types/reactive.js'
import { getActiveObserver, setActiveObserver } from '../types/reactive.js'

export function createCallback<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
): UnsubscribeFn {
  // Create observer that will be notified when dependencies change
  const observer: Observer<T> = {
    updateFn,
  }

  // Execute callback immediately to establish dependencies
  // This should happen in the context of any currently active observer
  const previousActiveObserver = getActiveObserver()
  
  // If there's an active observer (like a computed value), register our callback
  if (previousActiveObserver) {
    const subject = previousActiveObserver as { observers?: Set<unknown> }
    if (subject.observers) {
      subject.observers.add(observer)
    }
  }
  
  // Execute the callback to establish dependencies and get initial value
  updateFn()
  
  // Restore previous active observer
  setActiveObserver(previousActiveObserver)

  const unsubscribe: UnsubscribeFn = () => {
    // Remove observer from any subject that contains it
    if (previousActiveObserver) {
      const subject = previousActiveObserver as { observers?: Set<unknown> }
      if (subject.observers) {
        subject.observers.delete(observer)
      }
    }
  }

  return unsubscribe
}