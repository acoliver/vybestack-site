import type { EqualFn, GetterFn, Options, UpdateFn, Subject, Observer } from '../types/reactive.js'
import { getActiveObserver, setActiveObserver } from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: Options,
): GetterFn<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value !== undefined ? value : (updateFn() as T),
    equalFn: equal || ((a: T, b: T) => a === b),
  }

  const observer: Observer<T> = {
    updateFn,
  }

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observers.add(activeObserver)
    }
    
    // Set current observer to track dependencies
    setActiveObserver(observer)
    
    // Execute update function to compute new value
    const newValue = updateFn(subject.value)
    
    // Restore previous observer
    setActiveObserver(activeObserver)

    // Update subject value if changed
    if (!(subject.equalFn as EqualFn<T>)(subject.value, newValue)) {
      subject.value = newValue
      
      // Notify all observers by calling their update functions
      for (const obs of subject.observers) {
        if ('updateFn' in obs && typeof obs.updateFn === 'function') {
          try {
            obs.updateFn()
          } catch (e) {
            // Ignore errors in callback execution
          }
        }
      }
    }
    
    return subject.value
  }

  return getter
}