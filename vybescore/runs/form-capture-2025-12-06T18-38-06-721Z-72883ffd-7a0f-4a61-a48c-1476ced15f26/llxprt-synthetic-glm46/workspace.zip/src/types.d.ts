declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): unknown[][];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    bind(...params: unknown[]): void;
    step(): unknown[] | undefined;
    get(): unknown[];
    run(...params: unknown[]): unknown;
    free(): void;
  }

  interface SqlJsConfig {
    Database: new (data?: Uint8Array) => Database;
  }

  export default function initSqlJs(options?: Record<string, unknown>): Promise<SqlJsConfig>;
}