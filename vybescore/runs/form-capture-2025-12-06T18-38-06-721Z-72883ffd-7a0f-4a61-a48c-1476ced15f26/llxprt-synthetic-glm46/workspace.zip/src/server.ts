import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database setup
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
let db: Database | null = null;

interface Database {
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string): unknown[][];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  bind(...params: unknown[]): void;
  step(): unknown[] | undefined;
  get(): unknown[];
  run(...params: unknown[]): unknown;
  free(): void;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Initialize database variable
    if (!db) {
      // Check if database file exists
      if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        db = new SQL.Database(fileBuffer);
        console.log('Database loaded from existing file');
      } else {
        db = new SQL.Database();
        
        // Create schema from schema.sql
        const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');
        db.run(schemaSql);
        
        // Save the database
        saveDatabase();
        console.log('Database created with new schema');
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, buffer);
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use('/public', express.static(path.join(__dirname, '..', 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} as FormData,
    title: 'Friendly Contact Form'
  });
});

// Validation functions
function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // First name validation
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  // Last name validation
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  // Street address validation
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  // City validation
  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  // State/province validation
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  // Postal code validation (alphanumeric)
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code should only contain letters, numbers, spaces and hyphens' });
  }
  
  // Country validation
  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  // Email validation with simple regex
  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  // Phone validation (allow international formats)
  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+]?[(]?[0-9][\d\s()-]*$/.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} as FormData,
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData,
      title: 'Friendly Contact Form'
    });
  }
  
  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName?.trim(),
      formData.lastName?.trim(),
      formData.streetAddress?.trim(),
      formData.city?.trim(),
      formData.stateProvince?.trim(),
      formData.postalCode?.trim(),
      formData.country?.trim(),
      formData.email?.trim(),
      formData.phone?.trim()
    ]);
    
    stmt.free();
    saveDatabase();
  }
  
  return res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || 'Friend')}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { 
    firstName,
    title: 'Thank You!'
  });
});



// Helper function to start server for testing or direct execution
const createServer = async () => {
  try {
    await initializeDatabase();
    const port = process.env.PORT || 3535;
    return app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to initialize server:', error);
    process.exit(1);
  }
};

// Only start the server if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  createServer();
}

export default app;
export { createServer };
