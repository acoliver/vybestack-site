import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import express from 'express';

let server: express.Application | null = null;
let serverInstance: any = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start the server for testing
  const serverModule = await import('../../dist/server.js');
  server = serverModule.default;
  const { createServer } = serverModule;
  
  // Start the server on a different port for testing
  serverInstance = await createServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('<form');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555-123-4567'
      })
      .expect(302);
    
    expect(response.headers.location).toContain('/thank-you?firstName=');
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
afterAll(() => {
  if (serverInstance) {
    serverInstance.close();
  }
});
  });
});
