/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updatingObserver = false // Prevent recursive updates
const updatingObservers = new Set<ObserverR>() // Track which observers are currently updating

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion
  if (updatingObserver || updatingObservers.has(observer)) return
  
  const previous = activeObserver
  activeObserver = observer
  updatingObserver = true
  updatingObservers.add(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    updatingObserver = false
    updatingObservers.delete(observer)
  }
}

// Special observer update for notifications that doesn't track dependencies
export function notifyObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = undefined
  try {
    // Set activeObserver to null to prevent dependency tracking during notifications
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (subject.observer) {
    notifyObserver(subject.observer as Observer<unknown>)
  }
  if (subject.observers && subject.observers.size > 0) {
    // Create a snapshot of observers to avoid issues with removal during iteration
    const observersSnapshot = Array.from(subject.observers)
    for (const observer of observersSnapshot) {
      // Only notify if the observer is still in the set (wasn't disposed)
      if (subject.observers.has(observer)) {
        notifyObserver(observer as Observer<unknown>)
      }
    }
  }
}

export function addObserverToSubject(subject: Subject<unknown>, observer: ObserverR): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
  
  // Track reverse mapping for cleanup
  if (!observerToSubjects.has(observer)) {
    observerToSubjects.set(observer, new Set())
  }
  observerToSubjects.get(observer)!.add(subject)
}

export function removeObserverFromSubject(subject: Subject<unknown>, observer: ObserverR): void {
  if (subject.observers) {
    subject.observers.delete(observer)
  }
  
  // Clean up reverse mapping
  const subjects = observerToSubjects.get(observer)
  if (subjects) {
    subjects.delete(subject)
    if (subjects.size === 0) {
      observerToSubjects.delete(observer)
    }
  }
}

// Global registry to track which observers are subscribed to which subjects
const observerToSubjects = new Map<ObserverR, Set<Subject<unknown>>>()

export function trackObserverSubject(observer: ObserverR, subject: Subject<unknown>): void {
  if (!observerToSubjects.has(observer)) {
    observerToSubjects.set(observer, new Set())
  }
  observerToSubjects.get(observer)!.add(subject)
}

export function getObserverSubjects(observer: ObserverR): Set<Subject<unknown>> {
  return observerToSubjects.get(observer) || new Set()
}

export function cleanupObserver(observer: ObserverR): void {
  const subjects = observerToSubjects.get(observer)
  if (subjects) {
    for (const subject of subjects) {
      removeObserverFromSubject(subject, observer)
    }
    observerToSubjects.delete(observer)
  }
}
