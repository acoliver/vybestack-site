/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, cleanupObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track dependencies by running the callback once at creation
  // This registers the observer with all dependencies in the function
  updateObserver(callbackObserver)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up observer from all subjects it was observing
    cleanupObserver(callbackObserver)
    
    // Clear the observer to stop further updates
    callbackObserver.value = undefined
  }
}
