/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addObserverToSubject,
  getActiveObserver,
  getObserverSubjects,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject for this computed value to allow observers to track it
  const computedSubject = {
    name: options?.name,
    observer: o,
    value,
    observers: new Set(),
  }
  
  // Always recompute on access to get latest dependencies values
  const getter: GetterFn<T> = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // If someone is accessing this computed value, track this computed as a dependency
      addObserverToSubject(computedSubject as Subject<unknown>, activeObserver)
    }
    
    // Update the computed value by running the updateFn
    const newValue = updateFn()
    o.value = newValue
    computedSubject.value = newValue
    
    return o.value!
  }
  
  // Register this computed as an observer to track its dependencies
  // and make sure it gets notified when dependencies change
  updateObserver(o)
  
  // For each dependency this computed depends on, make sure to notify this computed
  // when that dependency changes
  const subjects = getObserverSubjects(o)
  
  for (const subject of subjects) {
    if (!subject.observers) {
      subject.observers = new Set()
    }
    subject.observers.add(o)
  }
  
  return getter
}
