/**
 * Encode plain text to Base64 using the canonical alphabet.
 * Output includes padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding).
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Validate Base64 format - must only contain valid Base64 characters and optional padding
  // Valid characters: A-Z, a-z, 0-9, +, /, and optional padding (=) at the end
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;

  if (!validBase64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check padding is valid (only at end, at most 2 characters)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    // Padding must be at the end
    const lastNonPaddingIndex = input.length - paddingLength - 1;
    for (let i = lastNonPaddingIndex + 1; i < input.length; i++) {
      if (input[i] !== '=') {
        throw new Error('Invalid Base64 input: padding not at end');
      }
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if the decoded buffer is empty but input wasn't just whitespace
    if (buffer.length === 0 && input.trim().length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
