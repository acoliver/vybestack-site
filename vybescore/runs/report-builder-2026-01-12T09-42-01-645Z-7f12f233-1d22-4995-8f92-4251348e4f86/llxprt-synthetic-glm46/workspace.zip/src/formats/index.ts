import type { ReportData } from '../types.js';
import { MarkdownRenderer } from './markdown.js';
import { TextRenderer } from './text.js';

export const renderers: Record<string, (data: ReportData, includeTotals?: boolean) => string> = {
  markdown: (data: ReportData, includeTotals?: boolean) => {
    const renderer = new MarkdownRenderer();
    return renderer.render(data, includeTotals);
  },
  text: (data: ReportData, includeTotals?: boolean) => {
    const renderer = new TextRenderer();
    return renderer.render(data, includeTotals);
  }
};

export type { ReportData } from '../types.js';