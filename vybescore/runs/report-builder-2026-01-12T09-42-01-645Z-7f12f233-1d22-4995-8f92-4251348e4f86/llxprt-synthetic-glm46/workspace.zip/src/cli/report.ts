#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderers } from '../formats/index.js';
import type { ReportData } from '../types.js';

function parseArguments(): { filePath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { filePath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: expected an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: label must be a string');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: amount must be a number');
    }
  }
  
  return data as ReportData;
}

function main() {
  try {
    const { filePath, format, outputPath, includeTotals } = parseArguments();
    
    // Validate format
    if (!['markdown', 'text'].includes(format)) {
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Read and validate input file
    let content: string;
    try {
      content = readFileSync(filePath, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file: ${filePath}`);
      console.error((error as Error).message);
      process.exit(1);
    }
    
    let data: unknown;
    try {
      data = JSON.parse(content);
    } catch (error) {
      console.error(`Error: Invalid JSON in file: ${filePath}`);
      console.error((error as Error).message);
      process.exit(1);
    }
    
    const reportData = validateReportData(data);
    
    // Render report
    const renderer = renderers[format];
    if (!renderer) {
      console.error(`Error: No renderer available for format: ${format}`);
      process.exit(1);
    }
    
    const output = renderer(reportData, includeTotals);
    
    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Could not write to file: ${outputPath}`);
        console.error((error as Error).message);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
