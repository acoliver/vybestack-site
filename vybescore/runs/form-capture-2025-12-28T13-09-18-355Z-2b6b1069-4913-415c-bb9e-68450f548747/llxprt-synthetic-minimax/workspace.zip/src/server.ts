import express, { Request, Response, NextFunction } from 'express';
import * as path from 'path';
import { dbManager } from './database';
import { ContactValidator, ContactFormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Middleware to handle form validation errors
function handleValidationErrors(req: Request, res: Response, _next: NextFunction) { // eslint-disable-line @typescript-eslint/no-unused-vars
  const body = req.body;
  
  const formData: ContactFormData = {
    firstName: (body.firstName as string) || '',
    lastName: (body.lastName as string) || '',
    streetAddress: (body.streetAddress as string) || '',
    city: (body.city as string) || '',
    stateProvince: (body.stateProvince as string) || '',
    postalCode: (body.postalCode as string) || '',
    country: (body.country as string) || '',
    email: (body.email as string) || '',
    phone: (body.phone as string) || ''
  };

  const validation = ContactValidator.validateFormData(formData);
  
  if (!validation.isValid) {
    // Re-render form with errors and previous values
    return res.status(400).render('contact-form', {
      errors: validation.errors,
      formData: formData,
      hasErrors: true
    });
  }

  // Attach validated data to request for next middleware
  (req as Express.Request & { validatedData?: ContactFormData }).validatedData = formData;
  _next();
}

// Routes

// GET / - Contact form
app.get('/', (req: Request, res: Response) => {
  res.render('contact-form', {
    errors: {},
    formData: {},
    hasErrors: false
  });
});

// POST /submit - Handle form submission
app.post('/submit', handleValidationErrors, async (req: Request, res: Response) => {
  try {
    const validatedData = (req as Express.Request & { validatedData?: ContactFormData }).validatedData as ContactFormData;
    
    // Insert submission into database
    await dbManager.insertSubmission({
      firstName: validatedData.firstName,
      lastName: validatedData.lastName,
      streetAddress: validatedData.streetAddress,
      city: validatedData.city,
      stateProvince: validatedData.stateProvince,
      postalCode: validatedData.postalCode,
      country: validatedData.country,
      email: validatedData.email,
      phone: validatedData.phone
    });

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('contact-form', {
      errors: { submit: 'An error occurred while processing your submission. Please try again.' },
      formData: req.body,
      hasErrors: true
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// 404 handler
app.use('*', (req: Request, res: Response) => {
  res.status(404).send('Page not found');
});

// Error handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => { // eslint-disable-line @typescript-eslint/no-unused-vars
  console.error('Unhandled error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
async function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    // Close database connection
    await dbManager.close();
    console.log('Database connection closed');
    
    console.log('Server closed');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

// Handle shutdown signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer() {
  try {
    // Initialize database
    await dbManager.initialize();
    
    // Start server
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the contact form`);
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();
