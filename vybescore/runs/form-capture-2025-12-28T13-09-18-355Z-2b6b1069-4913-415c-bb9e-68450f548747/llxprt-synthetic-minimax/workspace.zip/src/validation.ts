export interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class ContactValidator {
  private static emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  private static phoneRegex = /^\+?[\d\s\-()]+$/;

  static validateFormData(data: ContactFormData): ValidationResult {
    const errors: { [key: string]: string } = {};

    // Required field validation
    if (!data.firstName.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!data.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!data.streetAddress.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!data.city.trim()) {
      errors.city = 'City is required';
    }

    if (!data.stateProvince.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }

    if (!data.postalCode.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    }

    if (!data.country.trim()) {
      errors.country = 'Country is required';
    }

    if (!data.email.trim()) {
      errors.email = 'Email is required';
    } else if (!this.emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!data.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!this.phoneRegex.test(data.phone.replace(/\s/g, ''))) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code format validation (alphanumeric support)
    if (data.postalCode.trim() && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and dashes';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }
}