import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      const SqlJs = await initSqlJs({
        locateFile: (file: string) => {
          // For the WASM file, look in node_modules
          return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        }
      });
      this.sqlJs = SqlJs;

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SqlJs.Database(dbBuffer);
      } else {
        this.db = new SqlJs.Database();
        await this.createSchema();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Read and execute schema
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schemaSql = fs.readFileSync(schemaPath, 'utf-8');
        this.db.exec(schemaSql);
        console.log('Database schema created successfully');
      } else {
        throw new Error('Schema file not found');
      }
    } catch (error) {
      console.error('Failed to create database schema:', error);
      throw error;
    }
  }

  async insertSubmission(submission: ContactSubmission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvince,
        submission.postalCode,
        submission.country,
        submission.email,
        submission.phone
      ]);

      stmt.free();
      await this.saveDatabase();
      
      console.log('Contact submission inserted successfully');
    } catch (error) {
      console.error('Failed to insert contact submission:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Export database and write to file
      const dbBuffer = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(dbBuffer));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database closed successfully');
    }
  }
}

// Export singleton instance
export const dbManager = new DatabaseManager();