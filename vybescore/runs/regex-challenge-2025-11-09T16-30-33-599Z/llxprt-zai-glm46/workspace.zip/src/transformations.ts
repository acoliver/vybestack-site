/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  
  
  let result = text.replace(/\s+/g, ' ').trim();
  
  result = result.replace(/([.?!])([a-zA-Z])/g, '$1 $2');
  
  result = result.replace(/([.?!])(\s+)([a-z])/g, (match, punctuation, spaces, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  result = result.replace(/([.?!]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  const urlRegex = /(?:https?:\/\/)?(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&//=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => url.replace(/[.,;:!?]+$/, '')).filter(url => url);
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/http:\/\/([^\/\s]+)(\/docs\/[^\/\s]*)/gi, (match, hostname, path) => {
    if (/\/(cgi-bin|.*\?.*=|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path)) {
      return `https://${hostname}${path}`;
    }
    
    const domainWithoutWww = hostname.replace(/^www\./, '');
    return `https://docs.${domainWithoutWww}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  const maxDay = new Date(parseInt(year, 10), month, 0).getDate();
  if (day > maxDay) return 'N/A';
  
  return year;
}
