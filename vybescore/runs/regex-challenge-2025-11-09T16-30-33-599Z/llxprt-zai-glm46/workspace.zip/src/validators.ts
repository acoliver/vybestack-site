export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  if (value.includes('..')) return false;
  
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  if (domain.includes('_')) return false;
  
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  if (domainParts.some(part => !part)) return false;
  
  if (domainParts.some(part => part.startsWith('-') || part.endsWith('-'))) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const cleanValue = value.trim().replace(/[\s-]/g, '');
  
  const withCountryCodeRegex = /^(\+1)?1?(\(?([2-9]\d{2})\)?([2-9]\d{2})(\d{4}))$/;
  const withoutCountryCodeRegex = /^(\(?([2-9]\d{2})\)?([2-9]\d{2})(\d{4}))$/;
  
  const match = cleanValue.match(withCountryCodeRegex) || cleanValue.match(withoutCountryCodeRegex);
  if (!match) return false;
  
  const areaCode = match[3] || match[2];
  if (areaCode && (areaCode.startsWith('0') || areaCode.startsWith('1'))) {
    return false;
  }
  
  const coreNumber = match[4] || match[3];
  if (coreNumber && (coreNumber.startsWith('0') || coreNumber.startsWith('1'))) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const normalizedValue = value.replace(/[-\s]/g, '');
  
  const argentinePhoneRegex = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalizedValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const countryCode = match[1];
  const trunkPrefix = match[3];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s][\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value)) return false;
  
  if (/[\d]/.test(value)) return false;
  
  if (/^X\s+Æ\s+A-12$/i.test(value)) return false;
  
  if (value.length > 100) return false;
  
  return true;
}

function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const cleanValue = value.replace(/[\s-]/g, '');
  
  if (!/^\d+$/.test(cleanValue)) return false;
  
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleanValue) || 
                       mastercardRegex.test(cleanValue) || 
                       amexRegex.test(cleanValue);
  
  if (!isValidFormat) return false;
  
  return runLuhnCheck(cleanValue);
}
