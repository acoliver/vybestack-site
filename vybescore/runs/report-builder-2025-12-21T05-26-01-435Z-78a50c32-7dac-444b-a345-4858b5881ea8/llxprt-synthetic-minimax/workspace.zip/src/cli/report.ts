#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { CliOptions, ReportData } from '../types.js';

function parseArgs(argv: string[]): { dataFile: string; options: CliOptions } {
  const args = argv.slice(2); // Remove node and script name

  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  
  let format: CliOptions['format'] | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1] as CliOptions['format'];
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataFile, options: { format, output, includeTotals } };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: must be an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  const entries = report.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const reportEntry = entry as Record<string, unknown>;

    if (typeof reportEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label must be a string`);
    }

    if (typeof reportEntry.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${index}].amount must be a number`);
    }

    return {
      label: reportEntry.label,
      amount: reportEntry.amount,
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries,
  };
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    
    // Read and parse JSON file
    const jsonContent = readFileSync(dataFile, 'utf8');
    const rawData = JSON.parse(jsonContent);
    const reportData = validateReportData(rawData);

    // Select formatter
    const formatter = options.format === 'markdown' ? renderMarkdown : renderText;
    
    // Generate output
    const output = formatter.render(reportData, options.includeTotals);

    // Write output
    if (options.output) {
      writeFileSync(options.output, output, 'utf8');
    } else {
      process.stdout.write(output);
    }

  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
