/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // Using word boundaries to match whole words only
const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const lowercaseExceptions = exceptions.map(exc => exc.toLowerCase());
  
  return matches.filter(word => !lowercaseExceptions.includes(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences of the token where it appears after a digit and not at the start
  // Return the full match (including the digit prefix)
  
  // Pattern matches: digit followed by the token (as word boundaries)
  const pattern = new RegExp(`\\d${token}\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab, 1212, etc.)
  // Check for patterns where any 2+ character sequence repeats immediately
  for (let i = 0; i < value.length - 1; i++) {
    for (let len = 2; i + len * 2 <= value.length; len++) {
      const seq1 = value.substring(i, i + len);
      const seq2 = value.substring(i + len, i + len * 2);
      if (seq1 === seq2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's purely IPv4 format
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If it matches IPv4 pattern exactly, return false (we want IPv6 only)
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match within the string:
  
  // Pattern for full IPv6 addresses
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Pattern for partial IPv6 addresses with colons
  const partialIPv6 = /[0-9a-fA-F:]*:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*/;
  
  // Pattern to detect double colons (IPv6 shorthand)
  const doubleColon = /::/;
  
  // If we find double colons, it's likely IPv6
  if (doubleColon.test(value)) {
    return true;
  }
  
  // Check for patterns that look like IPv6 addresses
  return fullIPv6.test(value) || partialIPv6.test(value);
}
