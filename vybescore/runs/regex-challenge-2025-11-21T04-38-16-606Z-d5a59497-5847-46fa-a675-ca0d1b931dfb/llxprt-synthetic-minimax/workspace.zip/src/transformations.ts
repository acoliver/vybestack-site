/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and handle sentence boundaries
  let result = text.trim();
  
  // Replace multiple spaces with single spaces (but preserve meaningful whitespace in abbreviations)
  result = result.replace(/\s+/g, ' ');
  
  // Capitalize first letter after sentence endings (.?!)
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize the very first character of the text
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Handle cases where sentences end without space (e.g., ".Hello")
  result = result.replace(/([.!?])([A-Z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter;
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs, capturing the full URL without trailing punctuation
  // This pattern matches:
  // - http:// or https://
  // - Optional www.
  // - Domain name with TLD
  // - Optional port
  // - Optional path, query, fragment
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b[-a-zA-Z0-9()@:%_+.~#?&/=]*/g;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation that might have been captured
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([a-zA-Z0-9.-]+)([^\s]*)/g, (match, domain, pathAndQuery) => {
    // Always upgrade to https
    let newUrl = `https://${domain}${pathAndQuery}`;
    
    // Check if path begins with /docs/
    if (pathAndQuery.startsWith('/docs/')) {
      // Check for dynamic hints in the path
      const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
      const hasDynamicHints = dynamicHints.some(hint => pathAndQuery.includes(hint));
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.domain
        const newDomain = `docs.${domain}`;
        newUrl = `https://${newDomain}${pathAndQuery}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month and day ranges
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic month/day validation (more comprehensive date validation could be added)
  if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
    return year;
  }
  
  return 'N/A';
}
