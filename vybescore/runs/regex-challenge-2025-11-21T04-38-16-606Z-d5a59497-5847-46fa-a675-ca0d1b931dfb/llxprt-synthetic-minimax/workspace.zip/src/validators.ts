export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with support for +tag and multi-level domains
  // Reject double dots, trailing dots, and domains with underscores
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // No double dots in any part
  if (value.includes('..')) {
    return false;
  }
  
  // Domain shouldn't contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // No trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean { // eslint-disable-line @typescript-eslint/no-unused-vars
  // Remove all non-digit characters except + for country code
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1 (optional)
  if (cleanValue.startsWith('+1')) {
    const remaining = cleanValue.substring(3);
    return remaining.length === 10 && /^[2-9]\d{9}$/.test(remaining);
  }
  
  // For numbers without +1, should be exactly 10 digits
  if (cleanValue.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) can't start with 0 or 1
  const areaCode = cleanValue.substring(0, 3);
  if (!/^[2-9]\d{2}$/.test(areaCode)) {
    return false;
  }
  
  // Exchange code (next 3 digits) also can't start with 0 or 1
  const exchangeCode = cleanValue.substring(3, 6);
  if (!/^[2-9]\d{2}$/.test(exchangeCode)) {
    return false;
  }
  
  // Last 4 digits can be any digit
  const subscriberNumber = cleanValue.substring(6);
  return /^\d{4}$/.test(subscriberNumber);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Mobile with country code: +54 9 [area] [subscriber]
  if (/^\+549[1-9]\d{1,3}\d{4,6}$/.test(cleanValue)) {
    return true;
  }
  
  // Landline with country code: +54 [area] [subscriber] (no 0 or 9 needed after +54)
  if (/^\+54[1-9]\d{1,3}\d{6,8}$/.test(cleanValue)) {
    return true;
  }
  
  // Mobile without country code: 0 9 [area] [subscriber]
  if (/^09[1-9]\d{1,3}\d{4,6}$/.test(cleanValue)) {
    return true;
  }
  
  // Landline without country code: 0 [area] [subscriber]
  if (/^0[1-9]\d{1,3}\d{6,8}$/.test(cleanValue)) {
    return true;
  }
  
return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject if empty or just whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens, and accents
  // Pattern breakdown:
  // - [\p{L}\p{M}]+: One or more unicode letters and marks (accents)
  // - [\s'-]: spaces, apostrophes, and hyphens between letter groups
  // The pattern ensures it starts and ends with letters
  const namePattern = /^[A-Za-zÀ-ÿ\s'-]+$/;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Explicitly reject names containing digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject symbols like Æ and other special symbols that aren't allowed
  // Allow only letters, spaces, apostrophes, and hyphens
  if (/[^A-Za-zÀ-ÿ\s'-]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number).reverse();
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    // Double every second digit (starting from the first)
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanCard = value.replace(/\D/g, '');
  
  // Check minimum and maximum card lengths
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Check card type patterns
  const isVisa = cleanCard.startsWith('4') && (cleanCard.length === 13 || cleanCard.length === 16 || cleanCard.length === 19);
  const isMastercard = (cleanCard.startsWith('51') || cleanCard.startsWith('52') || 
                       cleanCard.startsWith('53') || cleanCard.startsWith('54') || 
                       cleanCard.startsWith('55') || (cleanCard.length === 16 && 
                       (cleanCard.startsWith('2221') || cleanCard.startsWith('2222') || 
                        cleanCard.startsWith('2223') || cleanCard.startsWith('2224') || 
                        cleanCard.startsWith('2225') || cleanCard.startsWith('2226') || 
                        cleanCard.startsWith('2227') || cleanCard.startsWith('2228') || 
                        cleanCard.startsWith('2229') || cleanCard.startsWith('223') || 
                        cleanCard.startsWith('224') || cleanCard.startsWith('225') || 
                        cleanCard.startsWith('226') || cleanCard.startsWith('227') || 
                        cleanCard.startsWith('228') || cleanCard.startsWith('229') || 
                        cleanCard.startsWith('23') || cleanCard.startsWith('24') || 
                        cleanCard.startsWith('25') || cleanCard.startsWith('26') || 
                        cleanCard.startsWith('270') || cleanCard.startsWith('271') || 
                        cleanCard.startsWith('2720')))); // Close: inner group, length check, main isMastercard group
  const isAmex = (cleanCard.startsWith('34') || cleanCard.startsWith('37')) && cleanCard.length === 15;
  
  // If it doesn't match any known card type, reject
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanCard);
}
