export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Regex for email validation with requirements:
  // - Local part: letters, numbers, dots, underscores NOT allowed, plus signs allowed for tags
  // - Domain part: letters, numbers, hyphens allowed (but not starting/ending with hyphen)
  // - Reject double dots, trailing dots, domains with underscores
  
  const emailRegex = /^(?!.*\.\.)(?!.*\.$)[a-zA-Z0-9][a-zA-Z0-9.+-]*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Note: _options parameter reserved for future extension (e.g., allowExtensions)
  void _options; // Suppress unused parameter warning
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check total digits (should be 10, optionally 11 with country code)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Remove country code and validate remaining 10 digits
    const localDigits = digitsOnly.slice(1);
    if (localDigits.length !== 10) return false;
  } else if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digitsOnly.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Format validation - ensure original format is one of the allowed patterns
  const phoneRegex = /^(?:\+?1[\s.-]?)?(?:\(?[2-9][0-8][0-9]\)?[\s.-]?[2-9][0-9]{2}[\s.-]?[0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Extract digits only for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's just empty or not enough digits
  if (digitsOnly.length < 8) return false;
  
  // Pattern that works with the test case: +54 country code + area + subscriber
  // Format: [+54] [area code] [subscriber number]
  const pattern = /^\+54\s*(\d{3,4})\s*(\d{3,4}\s*\d{4})$/;
  const match = value.trim().match(pattern);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Validate subscriber number total digits (6-8 digits)
  const subscriberDigits = subscriberNumber.replace(/\D/g, '');
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) return false;
  
  // Check total digits (allow up to 13 with country code)
  const totalDigits = digitsOnly.length;
  if (totalDigits < 8 || totalDigits > 13) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Regex for name validation:
  // - Allow unicode letters (including accents), apostrophes, hyphens, spaces
  // - Reject digits, symbols, and weird characters like X Æ A-12 style
  // - Must start with a letter
  
  const nameRegex = /^[\p{L}][\p{L}\p{M}\s'-]*$/u;
  if (!nameRegex.test(value)) return false;
  
  // Reject names that contain digits or symbols like X Æ A-12
  if (/[\d]|[^A-Za-zÀ-ÿ\s'-]/.test(value)) return false;
  
  // Reject empty or whitespace-only names
  if (value.trim().length === 0) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function to run Luhn checksum
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Check card types by prefix and length
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digitsOnly.startsWith('4')) {
    isValidType = digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || 
           digitsOnly.startsWith('53') || digitsOnly.startsWith('54') || 
           digitsOnly.startsWith('55')) {
    isValidType = digitsOnly.length === 16;
  }
  else if (digitsOnly.startsWith('2221') || digitsOnly.startsWith('2222') || 
           digitsOnly.startsWith('2223') || digitsOnly.startsWith('2224') || 
           digitsOnly.startsWith('2225') || digitsOnly.startsWith('2226') || 
           digitsOnly.startsWith('2227') || digitsOnly.startsWith('2228') || 
           digitsOnly.startsWith('2229') || digitsOnly.startsWith('223') || 
           digitsOnly.startsWith('224') || digitsOnly.startsWith('225') || 
           digitsOnly.startsWith('226') || digitsOnly.startsWith('227') || 
           digitsOnly.startsWith('228') || digitsOnly.startsWith('229') || 
           digitsOnly.startsWith('23') || digitsOnly.startsWith('24') || 
           digitsOnly.startsWith('250') || digitsOnly.startsWith('251') || 
           digitsOnly.startsWith('252') || digitsOnly.startsWith('253') || 
           digitsOnly.startsWith('254') || digitsOnly.startsWith('255') || 
           digitsOnly.startsWith('256') || digitsOnly.startsWith('257') || 
           digitsOnly.startsWith('258') || digitsOnly.startsWith('259') || 
           digitsOnly.startsWith('26') || digitsOnly.startsWith('270') || 
           digitsOnly.startsWith('271') || digitsOnly.startsWith('2720')) {
    isValidType = digitsOnly.length === 16;
  }
  // American Express: starts with 34 or 37, length 15
  else if (digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) {
    isValidType = digitsOnly.length === 15;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
