/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  const filteredMatches = matches.filter(word => 
    !exceptionsSet.has(word.toLowerCase())
  );
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token that appears after a digit - return the token with its preceding digit
  const result: string[] = [];
  
  // Simple approach: iterate through text and find token after digits
  const regex = new RegExp(`(\\d)${escapedToken}`, 'gi');
  const matches = text.match(regex);
  
  if (matches) {
    for (const match of matches) {
      result.push(match);
    }
  }
  
  return result;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/\d/.test(value)) return false;
  
  // Check for symbol using individual character test
  const symbols = '!@#$%^&*()_+-={}[];:"|,.<>/?';
  const hasSymbol = symbols.split('').some(symbol => value.includes(symbol));
  if (!hasSymbol) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // Only reject very obvious repetitions like "abab" or "1212"
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check if value contains an IPv6 address (including shorthand ::)
  // and ensure IPv4 addresses do not trigger a positive result
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIpv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shortened IPv6 with :: shorthand
  const shorthandIpv6 = /\b(?:[0-9a-fA-F]{1,4}:){0,7}:(?:[0-9a-fA-F]{1,4})?\b/;
  
  // Mixed IPv6/IPv4 format (IPv4 embedded in IPv6)
  const mixedIpv6 = /\b(?:[0-9a-fA-F]{1,4}:){6,}\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Check for IPv4 pattern to exclude it
  const ipv4Pattern = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // If it's IPv4, return false immediately
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for IPv6 patterns
  return fullIpv6.test(value) || shorthandIpv6.test(value) || mixedIpv6.test(value);
}
