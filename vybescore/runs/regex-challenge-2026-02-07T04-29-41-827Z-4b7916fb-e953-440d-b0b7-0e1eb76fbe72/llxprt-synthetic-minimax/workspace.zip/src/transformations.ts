/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing to collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize first character of text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize sentences after . ? !
  // Use regex to find sentence endings and capitalize the next letter
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, separator, letter) => {
    return separator + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs - allow dots but stop at sentence punctuation
  const urlRegex = /\bhttps?:\/\/[^\s"'<>;:!?]+[.][^\s"'<>;:!?]*[^\s"'<>;:!?.]/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) return [];
  
  // Clean up URLs by removing trailing punctuation that might have been captured
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation while preserving valid URL characters
    return url.replace(/[.,;:!?[\]]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing https untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http scheme
  const httpUrlRegex = /http:\/\/([^/]+)(\/docs\/[^\s.,;:!?]*)/gi;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|&|=)|(cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade the scheme to https://
      return `https://${host}${path}`;
    } else {
      // Upgrade scheme and rewrite host for docs paths
      // Transform example.com to docs.example.com
      const docsHost = `docs.${host}`; // prefix with docs.
      return `https://${docsHost}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with regex
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation: month 01-12, day 01-31
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days validation by month (simplified - doesn't handle leap years for February)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
