/**
 * Capitalize the first character of each sentence after sentence terminators.
 * Insert exactly one space between sentences and collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spaces around sentence terminators
  const result = text
    .replace(/\s*([.!?])\s*/g, '$1 ') // Ensure one space after terminators
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .trim();
  
  // Split by sentence terminators, capitalize first letter of each sentence
  const sentences = result.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    if (sentence && sentence.trim()) {
      // Capitalize first letter if it's lowercase and not part of abbreviation
      const firstChar = sentence[0];
      if (firstChar && firstChar === firstChar.toLowerCase() && /[a-z]/.test(firstChar)) {
        sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
    }
  }
  
  return sentences.join('');
}

/**
 * Extract all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,!?;:]/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation while preserving URLs that legitimately end with those characters
  return matches.map(url => url.replace(/[.,!?;:]+$/g, '')).filter(url => url);
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /http:\/\/([^/:]+)([\/][^ \t]*)?/g;
  
  return text.replace(urlPattern, (match, hostname, path = '') => {
    // Always upgrade to https
    const baseUrl = `https://${hostname}`;
    
    // If no path, just return the upgraded URL
    if (!path) {
      return baseUrl;
    }
    
    // Check if path starts with /docs/ and should be rewritten
    if (path.startsWith('/docs/')) {
      // Check for dynamic content indicators that should prevent host rewrite
      const dynamicIndicators = [
        /\/cgi-bin\//,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?.*)?$/i,
      ];
      
      const hasDynamicContent = dynamicIndicators.some(indicator => indicator.test(path));
      
      if (!hasDynamicContent) {
        // Rewrite to docs.example.com for documentation paths
        return `https://docs.${hostname}${path}`;
      }
    }
    
    // Return upgraded URL without host rewrite
    return `${baseUrl}${path}`;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format, returning 'N/A' for invalid inputs.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for specific month-day combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (year: number) => {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  };
  
  const maxDays = month === 2 && isLeapYear(parseInt(year, 10)) ? 29 : daysInMonth[month - 1];
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}