/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and deduplicate
  const uniqueWords = [...new Set(
    matches
      .map(word => word.toLowerCase())
      .filter(word => !exceptions.some(exception => 
        word.toLowerCase() === exception.toLowerCase()
      ))
  )];
  
  return uniqueWords;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern to match the full occurrence including the preceding digit
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenPattern) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Validate passwords according to the policy: at least 10 chars, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns of length 2-4 that repeat immediately
  const repeatedPattern = /(.{1,4})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches full IPv6 addresses
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Pattern for shorthand IPv6 (with ::)
  const shorthandIPv6Pattern = /::/;
  
  // Pattern for IPv4 addresses to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if the whole text contains IPv4
  const hasIPv4 = ipv4Pattern.test(value);
  
  // If it contains IPv4, check if it also has IPv6 patterns
  if (hasIPv4) {
    // Check for IPv6 patterns that are not part of IPv4
    const ipv6Matches = value.match(/[\da-fA-F:]+/g) || [];
    return ipv6Matches.some(match => 
      (fullIPv6Pattern.test(match) || shorthandIPv6Pattern.test(match)) &&
      !ipv4Pattern.test(match)
    );
  }
  
  // If no IPv4, just check for IPv6 patterns
  return fullIPv6Pattern.test(value) || shorthandIPv6Pattern.test(value);
}
