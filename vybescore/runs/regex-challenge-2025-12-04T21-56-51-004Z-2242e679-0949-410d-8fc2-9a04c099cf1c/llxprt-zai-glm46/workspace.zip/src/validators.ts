export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with support for common formats and rejection of obvious invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Reject double dots, trailing dots, leading dots
  if (localPart.includes('..') || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats and optional +1 prefix.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('1') && digits.length > 10) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits for a valid US phone number
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code and validate it doesn't start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the original format is valid
  const validFormats = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-.\s]?\d{4}$/, // (212) 555-7890
    /^\+?1?\s*\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // 212-555-7890
    /^\+?1?\s*\d{10}$/, // 2125557890
  ];
  
  return validFormats.some(regex => regex.test(value));
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^\+?54?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Validate area code length (2-4 digits after removing trunk prefix)
  const normalizedAreaCode = areaCode.startsWith('0') ? areaCode.slice(1) : areaCode;
  if (normalizedAreaCode.length < 2 || normalizedAreaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 */
export function isValidName(value: string): boolean {
  // Name should contain only unicode letters, spaces, apostrophes, hyphens, and accents
  // Should have at least 2 characters and reject digits, symbols, and weird names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s\p{L}\p{M}'-]+)*$/u;
  
  // Basic format validation
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Reject names that are too short (less than 2 characters)
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject names with consecutive spaces, apostrophes, or hyphens
  if (/\s{2,}|'{2,}|-{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with space, apostrophe, or hyphen
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  // Reject names that contain digits (though regex should already catch this)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit and move left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for major cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5][0-9]{14}$/; // 16 digits
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits
  
  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validPrefix) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}
