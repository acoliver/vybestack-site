import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.dirname(__dirname);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Database = any;

let db: Database | null = null;
const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<Database> {
  try {
    let data: Buffer;
    
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    } else {
      data = Buffer.alloc(0);
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }
    
    const SQL = await initSqlJs({ locateFile: () => path.join(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm') });
    const database = new SQL.Database(data);
    
    if (!fs.existsSync(dbPath) || data.length === 0) {
      const schema = fs.readFileSync(path.join(projectRoot, 'db', 'schema.sql'), 'utf8');
      database.run(schema);
      saveDatabase(database);
    }
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(database: Database): void {
  try {
    const data = database.export();
    fs.writeFileSync(dbPath, data);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and hyphens';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }
  
if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[0-9\\s()\\+\-]+$/.test(data.phone.trim())) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

async function initialize(): Promise<void> {
  try {
    db = await initializeDatabase();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize application:', error);
    process.exit(1);
  }
}

async function main(): Promise<void> {
  await initialize();
  
  const app = express();
  const port = process.env.PORT || 3535;
  
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(projectRoot, 'public')));
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(projectRoot, 'src', 'templates'));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: {},
      formData: {}
    });
  });
  
  app.post('/submit', (req: Request, res: Response) => {
    if (!db) {
      return res.status(500).send('Database not initialized');
    }
    console.log('Received form data:', req.body);
    
    const formData: FormData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.render('form', {
        errors: validation.errors,
        formData
      });
    }
    
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName!.trim(),
        formData.lastName!.trim(),
        formData.streetAddress!.trim(),
        formData.city!.trim(),
        formData.stateProvince!.trim(),
        formData.postalCode!.trim(),
        formData.country!.trim(),
        formData.email!.trim(),
        formData.phone!.trim()
      ]);
      
      stmt.free();
      saveDatabase(db);
      
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).send('Internal server error');
    }
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you');
  });
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('Server closed');
      if (db) {
        try {
          db.close();
          console.log('Database closed');
        } catch (error) {
          console.error('Error closing database:', error);
        }
      }
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

main().catch(error => {
  console.error('Application startup failed:', error);
  process.exit(1);
});