import type { ReportData } from './types.js';

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid title');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid entries');
  }
  
  // Validate each entry
  const entries = obj.entries.map((entry: unknown) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: expected object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid amount');
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

export function parseAndValidateJSON(jsonString: string): ReportData {
  try {
    const data = JSON.parse(jsonString);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Malformed JSON: ' + error.message);
    }
    throw error;
  }
}