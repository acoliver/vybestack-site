import { readFileSync, writeFileSync } from 'fs';

export function readJSONFile(path: string): string {
  try {
    return readFileSync(path, 'utf8');
  } catch (error) {
    throw new Error(`Could not read file: ${path}`);
  }
}

export function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf8');
      console.log(`Report written to: ${outputPath}`);
    } catch (error) {
      throw new Error(`Could not write to file: ${outputPath}`);
    }
  } else {
    // Write to standard output
    process.stdout.write(content);
  }
}