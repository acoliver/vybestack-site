#!/usr/bin/env node

import { parseArgs } from './args.js';
import { parseAndValidateJSON } from '../validation.js';
import { readJSONFile, writeOutput } from '../io.js';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';

async function main(): Promise<void> {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse JSON input
    const inputJson = readJSONFile(args.dataPath);
    const reportData = parseAndValidateJSON(inputJson);
    
    // Select appropriate renderer
    let renderer;
    switch (args.format) {
      case 'markdown':
        renderer = new MarkdownRenderer();
        break;
      case 'text':
        renderer = new TextRenderer();
        break;
      default:
        throw new Error('Unsupported format');
    }
    
    // Render report
    const renderedReport = renderer.render(reportData, {
      includeTotals: args.includeTotals,
    });
    
    // Write output
    writeOutput(renderedReport, args.output);
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main().catch(error => {
  console.error('Unexpected error:', error);
  process.exit(1);
});
