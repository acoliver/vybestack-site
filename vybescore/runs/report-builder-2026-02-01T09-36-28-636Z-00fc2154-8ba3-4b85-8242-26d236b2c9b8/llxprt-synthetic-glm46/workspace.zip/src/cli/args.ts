import type { CLIParsedArgs, RenderFormat } from '../types.js';

export function parseArgs(args: string[]): CLIParsedArgs {
  const processArgs = args.slice(2); // Remove node and script path
  
  if (processArgs.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataPath = processArgs[0];
  
  const formatIndex = processArgs.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || !processArgs[formatIndex + 1]) {
    throw new Error('Missing required --format argument');
  }
  const format: RenderFormat = processArgs[formatIndex + 1] as RenderFormat;
  if (format !== 'markdown' && format !== 'text') {
    throw new Error('Unsupported format');
  }
  
  let output: string | undefined;
  const outputIndex = processArgs.findIndex(arg => arg === '--output');
  if (outputIndex !== -1 && !processArgs[outputIndex + 1]) {
    throw new Error('Missing output path after --output');
  }
  if (outputIndex !== -1) {
    output = processArgs[outputIndex + 1];
  }
  
  const includeTotals = processArgs.includes('--includeTotals');
  
  return {
    dataPath,
    format,
    output,
    includeTotals,
  };
}