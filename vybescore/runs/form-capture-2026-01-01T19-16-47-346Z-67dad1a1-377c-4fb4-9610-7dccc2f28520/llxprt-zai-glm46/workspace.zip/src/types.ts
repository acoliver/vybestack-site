export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export interface Submission extends FormData {
  id?: number;
  createdAt?: string;
}
