import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import initSqlJs, { Database } from 'sql.js';
import type { Submission } from './types.js';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

export class DatabaseManager {
  private db: Database | null = null;
  private SqlJs: {
    Database: new (data?: ArrayBuffer) => Database;
  } | null = null;

  async initialize(): Promise<void> {
    this.SqlJs = await initSqlJs();

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    await fs.mkdir(dataDir, { recursive: true });

    // Load existing database or create new one
    try {
      const buffer = await fs.readFile(DB_PATH);
      const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
      this.db = new this.SqlJs.Database(arrayBuffer as ArrayBuffer);
    } catch (error: unknown) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        this.db = new this.SqlJs.Database();
        await this.loadSchema();
      } else {
        throw error;
      }
    }
  }

  private async loadSchema(): Promise<void> {
    if (!this.db) return;

    const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
    this.db.run(schema);
  }

  async saveSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone,
    ]);

    stmt.free();

    const result = this.db.exec('SELECT last_insert_rowid() as id');
    const insertId = result[0].values[0][0] as number;

    await this.persist();

    return insertId;
  }

  private async persist(): Promise<void> {
    if (!this.db) return;

    const data = this.db.export();
    const buffer = Buffer.from(data);
    await fs.writeFile(DB_PATH, buffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.persist();
      this.db.close();
      this.db = null;
    }
  }
}
