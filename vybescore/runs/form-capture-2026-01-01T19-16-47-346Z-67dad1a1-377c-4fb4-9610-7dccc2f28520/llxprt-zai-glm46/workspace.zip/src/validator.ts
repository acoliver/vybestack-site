import type { FormData, ValidationError } from './types.js';

export function validateForm(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvinceRegion || data.stateProvinceRegion.trim() === '') {
    errors.push({ field: 'stateProvinceRegion', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and hyphens' });
  }

  if (!data.country || data.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  if (!data.email || data.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }

  // Phone validation - international formats
  if (!data.phone || data.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else {
    // Phone can contain digits, spaces, parentheses, dashes, and a leading +
    // eslint-disable-next-line no-useless-escape
    const phoneRegex = /^\+?[\d\s()\-]+/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
    }
  }

  return errors;
}
