import express from 'express';
import { join } from 'node:path';
import { DatabaseManager } from './database.js';
import { validateForm } from './validator.js';
import type { FormData, ValidationError } from './types.js';

const app = express();
const dbManager = new DatabaseManager();

// Trust proxy for proper X-Forwarded-* handling
app.set('trust proxy', true);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(join(process.cwd(), 'public')));

// Set EJS as templating engine
app.set('views', join(process.cwd(), 'src', 'views'));
app.set('view engine', 'ejs');

// Helper function to get field error message
function getFieldError(errors: ValidationError[], field: string): string | undefined {
  return errors.find((e) => e.field === field)?.message;
}

// GET / - Render the form
app.get('/', (_req, res) => {
  res.render('index', {
    errors: [],
    data: {},
    getFieldError,
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('index', {
      errors,
      data: formData,
      getFieldError,
    });
  }

  void dbManager.saveSubmission(formData);

  res.redirect(302, '/thank-you');
});

// GET /thank-you - Thank you page
app.get('/thank-you', (_req, res) => {
  res.render('thank-you');
});

// Start server
async function startServer() {
  const PORT = Number(process.env.PORT) || 3535;

  await dbManager.initialize();

  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('HTTP server closed');
    });

    await dbManager.close();
    console.log('Database closed');
    process.exit(0);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
