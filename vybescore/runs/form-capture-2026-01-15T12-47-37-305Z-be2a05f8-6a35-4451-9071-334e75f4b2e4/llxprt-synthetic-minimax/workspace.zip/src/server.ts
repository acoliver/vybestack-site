import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/styles.css', express.static(path.join(__dirname, '..', 'public', 'styles.css')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// Types
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database setup
let db: Database | null = null;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(new Uint8Array(dbBuffer));
    } else {
      db = new SQL.Database();
      
      // Initialize schema
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db.exec(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (db !== null) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Validation functions
function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = formData[field];
    if (!value || value.trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  });

  // Email validation
  if (formData.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation (international formats allowed)
  if (formData.phone) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation (alphanumeric allowed)
  if (formData.postalCode) {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(formData.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim(),
    lastName: req.body.lastName?.trim(),
    streetAddress: req.body.streetAddress?.trim(),
    city: req.body.city?.trim(),
    stateProvince: req.body.stateProvince?.trim(),
    postalCode: req.body.postalCode?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim()
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    // Re-render form with errors and previous values
    const errorMessages = errors.map(error => error.message);
    return res.status(400).render('index', {
      errors: errorMessages,
      formData
    });
  }

  // Save to database
  if (db !== null) {
    try {
      db.run(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || ''
      ]);

      // Save database to file
      saveDatabase();

      // Redirect to thank you page
      return res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      return res.status(500).render('index', {
        errors: ['Internal server error. Please try again.'],
        formData
      });
    }
  } else {
    return res.status(500).render('index', {
      errors: ['Database error. Please try again.'],
      formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (db !== null) {
    saveDatabase();
    console.log('Database saved.');
  }

  server.close(() => {
    console.log('Server closed.');
    process.exit(0);
  });
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  initializeDatabase().then(() => {
    console.log('Database initialized successfully');
  }).catch(error => {
    console.error('Database initialization failed:', error);
  });
});

export default app;
