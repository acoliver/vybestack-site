import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import http from 'http';

let server: http.Server;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Import the compiled server application
  const serverModule = await import(path.resolve(__dirname, '../../dist/server.js'));
  app = serverModule.default;
  
  return new Promise((resolve) => {
    server = app.listen(0, () => {
      console.log('Test server started');
      resolve(true);
    });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    expect(response.text).toContain('Get In Touch');
    
    // Check for form fields using simple text search
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('streetAddress');
    expect(response.text).toContain('city');
    expect(response.text).toContain('stateProvince');
    expect(response.text).toContain('postalCode');
    expect(response.text).toContain('country');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
    
    // Check for stylesheet link
    expect(response.text).toContain('href="/styles.css"');
  });

  it('persists submission and redirects', async () => {
    // Clean any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .type('form-urlencoded')
      .send(testData)
      .expect(302); // Should redirect

    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database was created and data persisted
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form-urlencoded')
      .send({
        firstName: 'John',
        // Missing required fields
        lastName: '',
        streetAddress: '',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'invalid-email', // Invalid email
        phone: '+1 555-123-4567'
      })
      .expect(400);

    expect(response.text).toContain('Get In Touch');
    expect(response.text).toContain('required');
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form-urlencoded')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'not-an-email',
        phone: '+1 555-123-4567'
      })
      .expect(400);

    expect(response.text).toContain('valid email address');
  });

  it('shows thank you page after successful submission', async () => {
    // First create a submission
    await request(app)
      .post('/submit')
      .type('form-urlencoded')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane.smith@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302);

    // Then check thank you page
    const response = await request(app)
      .get('/thank-you')
      .expect(200);

    expect(response.text).toContain('Thank You For Your Submission!');
    expect(response.text).toContain('Why did you give your information');
    expect(response.text).toContain('spam');
    expect(response.text).toContain('identity theft');
  });

  it('accepts international phone formats', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form-urlencoded')
      .send({
        firstName: 'Carlos',
        lastName: 'Rodriguez',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1043',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts alphanumeric postal codes', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form-urlencoded')
      .send({
        firstName: 'Alice',
        lastName: 'Johnson',
        streetAddress: '10 Downing St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'alice@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });
});
