/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Uses standard Base64 with padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate basic Base64 format (only allow A-Z, a-z, 0-9, +, /, = and whitespace)
  if (!/^[A-Za-z0-9+/=\s]*$/.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Remove whitespace and try to decode
  const cleaned = input.replace(/\s/g, '');

  try {
    const result = Buffer.from(cleaned, 'base64').toString('utf8');
    
    // Additional validation: if the result contains invalid UTF-8 sequences,
    // Buffer will have replaced them with replacement characters
    if (result.includes("\ufffd")) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}