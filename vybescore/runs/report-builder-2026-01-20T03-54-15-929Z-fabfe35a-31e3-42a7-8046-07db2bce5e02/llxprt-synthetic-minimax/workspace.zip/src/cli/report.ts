#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { createWriteStream } from 'node:fs';
import { formatters } from '../formats/index.js';
import type { CLIOptions, ReportData } from '../types/report.js';

function parseArgs(args: string[]): CLIOptions {
  const options: CLIOptions = {
    dataFile: '',
    format: 'markdown',
    output: undefined,
    includeTotals: false
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        options.format = args[i + 1] as 'markdown' | 'text';
        i += 2;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        options.output = args[i + 1];
        i += 2;
        break;
      case '--includeTotals':
        options.includeTotals = true;
        i += 1;
        break;
      default:
        if (arg.startsWith('--')) {
          throw new Error(`Unknown option: ${arg}`);
        }
        if (!options.dataFile) {
          options.dataFile = arg;
        } else {
          throw new Error(`Unexpected argument: ${arg}`);
        }
        i += 1;
        break;
    }
  }

  if (!options.dataFile) {
    throw new Error('Data file path is required');
  }

  if (!options.format || !['markdown', 'text'].includes(options.format)) {
    throw new Error('Unsupported format: must be "markdown" or "text"');
  }

  return options;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const reportData = data as Partial<ReportData>;
  
  if (typeof reportData.title !== 'string' || !reportData.title.trim()) {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof reportData.summary !== 'string' || !reportData.summary.trim()) {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const partialEntry = entry as Partial<{ label: string; amount: number }>;
    
    if (typeof partialEntry.label !== 'string' || !partialEntry.label.trim()) {
      throw new Error(`Invalid JSON: entries[${i}].label must be a non-empty string`);
    }

    if (typeof partialEntry.amount !== 'number' || isNaN(partialEntry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a valid number`);
    }
  }

  return true;
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const options = parseArgs(args);

    // Read and parse JSON file
    let jsonContent: string;
    try {
      jsonContent = readFileSync(options.dataFile, 'utf-8');
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${options.dataFile}`);
      }
      throw new Error(`Failed to read file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    let reportData: unknown;
    try {
      reportData = JSON.parse(jsonContent);
    } catch (error) {
      throw new Error('Invalid JSON: malformed JSON syntax');
    }

    // Validate input data structure
    validateReportData(reportData);

    // Route to appropriate formatter
    const formatter = formatters[options.format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${options.format}`);
    }

    const formattedOutput = formatter.render(reportData as ReportData, options.includeTotals);

    // Write output to stdout or specified file
    if (options.output) {
      try {
        const stream = createWriteStream(options.output);
        stream.write(formattedOutput);
        stream.end();
      } catch (error) {
        throw new Error(`Failed to write output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    } else {
      process.stdout.write(formattedOutput);
    }

  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
