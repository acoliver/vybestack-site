import type { ReportData } from '../types/report.js';

export interface MarkdownFormatter {
  format: string;
  render: (data: ReportData, includeTotals: boolean) => string;
}

export const markdownFormatter: MarkdownFormatter = {
  format: 'markdown',
  render: (data: ReportData, includeTotals: boolean): string => {
    let output = `# ${data.title}\n\n`;
    output += `${data.summary}\n\n`;
    output += `## Entries\n`;
    
    for (const entry of data.entries) {
      const amount = entry.amount.toFixed(2);
      output += `- **${entry.label}** — $${amount}\n`;
    }
    
    if (includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `\n**Total:** $${total.toFixed(2)}`;
    }
    
    return output;
  }
};