import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!Number.isFinite(pageNum) || pageNum <= 0 || !Number.isInteger(pageNum)) {
        return res.status(400).json({ error: 'page must be a positive integer' });
      }
      if (pageNum > 10000) { // Reasonable upper bound
        return res.status(400).json({ error: 'page is too large' });
      }
      page = pageNum;
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!Number.isFinite(limitNum) || limitNum <= 0 || !Number.isInteger(limitNum)) {
        return res.status(400).json({ error: 'limit must be a positive integer' });
      }
      if (limitNum > 100) { // Reasonable upper bound
        return res.status(400).json({ error: 'limit is too large' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
