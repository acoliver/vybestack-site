/**
 * Capitalizes first character of each sentence.
 * Inserts one space between sentences, collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first letter of entire string
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Capitalize after sentence-ending punctuation followed by space
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https
  // Captures the URL but excludes trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"'(){}|[\]^`]+[^<>"'(){}|[\]^\s.,!?;:]/g;
  
  const matches = text.match(urlPattern);
  return matches ? matches : [];
}

/**
 * Converts all http:// URLs to https://
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/(https?:\/\/|[^\s"')>]*)/gi, (_, url) => {
    // Only replace if it's not already https
    if (!url.startsWith('https')) {
      return `https://${url}`;
    }
    return `http://${url}`;
  });
}

/**
 * Rewrites http://example.com/... URLs to https://
 * When path begins with /docs/, moves to docs.example.com
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /https?:\/\/example\.com(\/[^\s"')>]*)/gi,
    (_, path) => {
      // Always upgrade to https
      const scheme = 'https://';
      
      // Check if path contains dynamic hints
      const hasDynamicHint = 
        path.includes('/cgi-bin') ||
        path.includes('?') ||
        path.includes('&') ||
        path.includes('=') ||
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(path);
      
      // If docs path and no dynamic hints, rewrite host
      if (path.startsWith('/docs/') && !hasDynamicHint) {
        return `${scheme}docs.example.com${path}`;
      }
      
      // Otherwise just upgrade the scheme
      return `${scheme}example.com${path}`;
    }
  );
}

/**
 * Extracts year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check leap year for February
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  const maxDay = (month === 2 && isLeapYear) ? 29 : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return yearStr;
}
