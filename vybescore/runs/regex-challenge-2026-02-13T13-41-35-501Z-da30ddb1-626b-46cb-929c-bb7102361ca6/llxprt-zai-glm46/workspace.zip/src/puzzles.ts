/**
 * Finds words starting with prefix, excluding exception words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a Set for O(1) lookup of exceptions
  const exceptionSet = new Set(exceptions);
  
  // Pattern: word boundary, then prefix, then word characters
  const pattern = new RegExp(`\\b(${prefix}[a-zA-Z]+)`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const word = match[1];
    // Only add if not in exceptions list
    if (!exceptionSet.has(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Finds occurrences of token appearing after a digit and not at string start.
 * Uses lookahead to find digit before token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: match digit + token, but only when not at start of string
  // Using (?:^|(?<=\D)) negative lookbehind to ensure we're not at start
  // Actually, using positive lookbehind to ensure digit precedes
  const pattern = new RegExp(`(?:^|\\D)\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Extract just the digit + token part (without preceding non-digit)
    const fullMatch = match[0];
    const digitToken = fullMatch.replace(/^\D/, '');
    matches.push(digitToken);
  }
  
  return matches;
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase, lowercase, digit, symbol
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 1212, abcabc)
  // Look for any 2-4 character pattern that repeats
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.slice(i, i + len);
      const nextOccurrence = value.slice(i + len, i + len * 2);
      if (pattern === nextOccurrence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand).
 * Excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude - must NOT match
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it's purely an IPv4 address, return false
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false;
  }
  
  // IPv6 patterns - look for presence of colons which IPv6 requires
  const ipv6Patterns = [
    // Full IPv6 (8 groups of 1-4 hex digits)
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // IPv6 with :: shorthand in middle  
    /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}/,
    // IPv6 starting with :: (leading shorthand)
    /::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/,
    // IPv6 ending with :: (trailing shorthand)
    /(?:[0-9a-fA-F]{1,4}:)+::/,
    // Just ::
    /::/,
  ];
  
  // Check if any IPv6 pattern matches
  return ipv6Patterns.some(pattern => pattern.test(value));
}
