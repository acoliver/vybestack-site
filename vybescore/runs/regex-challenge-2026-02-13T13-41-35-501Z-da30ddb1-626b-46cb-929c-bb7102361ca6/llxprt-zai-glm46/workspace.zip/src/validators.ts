export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for obvious issues first
  if (!value || value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Count @ signs - must have at least 1
  const atCount = (value.match(/@/g) || []).length;
  if (atCount < 1) {
    return false;
  }
  
  // For emails like "name@tag@example.com", local part is "name@tag"
  // Find the last @ which separates local from domain
  const lastAtIndex = value.lastIndexOf('@');
  const localPart = value.slice(0, lastAtIndex);
  const domainPart = value.slice(lastAtIndex + 1);
  
  // Local part cannot start/end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot have underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Domain cannot start/end with dot or have consecutive dots
  if (domainPart.startsWith('.') || domainPart.endsWith('.') || domainPart.includes('..')) {
    return false;
  }
  
  // Domain must have at least one dot and valid TLD
  const domainRegex = /^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domainPart)) {
    return false;
  }
  
  // Local part regex - allows letters, digits, dots, hyphens, underscores, plus, percent, @ (for @ in local part)
  const localRegex = /^[a-zA-Z0-9._%+-@]+$/;
  if (!localRegex.test(localPart)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digits.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let mainNumber = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    mainNumber = digits.slice(1);
  } else if (digits.length > 11) {
    // Too long even with country code
    return false;
  }
  
  // Must be exactly 10 digits after removing country code
  if (mainNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = mainNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = mainNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate the format matches one of the accepted patterns
  const patterns = [
    /^\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890 or (212)555-7890
    /^\d{3}-\d{3}-\d{4}$/, // 212-555-7890
    /^\d{10}$/, // 2125557890
    /^\+1\s*\d{3}-\d{3}-\d{4}$/, // +1 212-555-7890
    /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // +1 (212) 555-7890
  ];
  
  const normalizedValue = value.trim();
  return patterns.some(pattern => pattern.test(normalizedValue));
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles with:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep track of structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^(?:\+?54)? - Optional country code +54 (non-capturing)
  // (0)? - Optional trunk prefix 0 (captured)
  // (9)? - Optional mobile indicator 9 (captured)
  // (\d{2,4}) - Area code (2-4 digits, captured)
  // (\d{6,8})$ - Subscriber number (6-8 digits, captured)
  const pattern = /^(?:\+?54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  
  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }
  
  const [, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // Check area code starts with 1-9
  if (!/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Check subscriber number is 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix 0 before area code
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  if (!hasCountryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate the original format uses only allowed separators
  const validSeparators = /^[\d\s+-]+$/;
  if (!validSeparators.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s][\p{L}\p{M}'-]+)*$/u;
  
  // Additional check: must contain at least one unicode letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  // Check for digits or other invalid characters
  const hasInvalidChars = /[0-9]|[\u0021-\u002F\u003A-\u0040\u005B-\u0060\u007B-\u00BF]/.test(
    value.replace(/[\s'-]/g, '')
  );
  
  return nameRegex.test(value) && hasLetter && !hasInvalidChars;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length and prefix for different card types
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const isValidLengthAndPrefix = 
    (cleaned.length === 13 || cleaned.length === 16) && cleaned.startsWith('4') || // Visa
    (cleaned.length === 16 && (/^5[1-5]/.test(cleaned) || /^2[2-7][0-9]{2}/.test(cleaned))) || // Mastercard
    (cleaned.length === 15 && (/^34/.test(cleaned) || /^37/.test(cleaned))); // AmEx
  
  if (!isValidLengthAndPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
