/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  // Word boundaries to ensure we match whole words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exc => exc.toLowerCase() === lowerMatch);
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, but the digit is not at the start of the string
  // Using negative lookbehind to ensure the digit is not at the beginning
  const pattern = new RegExp(`(?<!^)(\\d)${escapedToken}`, 'gi');
  const matches = text.match(pattern) || [];
  
  // The match includes the digit, which is what we want to return
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for any 2-character sequence that repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to match IPv6 addresses
  // IPv6 can be:
  // - Full format: 8 groups of 4 hex digits (0-9, a-f, A-F) separated by colons
  // - Shorthand: :: for one or more groups of zeros
  // - IPv4-mapped: last two groups can be IPv4 format
  
  // First, check if this looks like an IPv4 address (should not match)
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Pattern.test(value)) {
    // But make sure it's not part of IPv6 (IPv4-mapped)
    // Check if the IPv4 pattern is part of an IPv6 address
    const ipv4InIPv6Pattern = /(?:[0-9A-Fa-f]{1,4}:){2,}(?:\d{1,3}\.){3}\d{1,3}/;
    if (!ipv4InIPv6Pattern.test(value)) {
      // If it matches pure IPv4 pattern, exclude
      // But we need to be more careful - check if it's standalone
      const standaloneIPv4 = /(?<![0-9A-Fa-f:])(?:\d{1,3}\.){3}\d{1,3}(?![0-9A-Fa-f:])/;
      if (standaloneIPv4.test(value)) {
        return false;
      }
    }
  }
  
  // IPv6 patterns - match anywhere in the string
  // Full IPv8: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const fullIPv8Pattern = /(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}/;
  
  // IPv6 with :: shorthand - multiple patterns to catch all cases
  const patterns = [
    fullIPv8Pattern,
    /::[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*/,
    /[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*::/,
    /[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*::(?::[0-9A-Fa-f]{1,4})+/,
    // IPv4-mapped IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:d.d.d.d
    /(?:[0-9A-Fa-f]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}/
  ];
  
  // Test each pattern
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}