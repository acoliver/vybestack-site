export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern explanation:
  // - Local part: letters, digits, and allowed symbols . + -
  // - No double dots (..) or trailing dots
  // - Domain: letters/digits, no underscores, at least one dot, proper TLD
  const emailRegex = /^(?=.{1,254}$)(?=.{1,64}@)[A-Za-z0-9]([A-Za-z0-9.+-]*[A-Za-z0-9])?@[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$/;
  return emailRegex.test(value.trim());
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Pattern explanation:
  // - Optional +1 country code
  // - Area code: 3 digits, first digit 2-9 (not 0 or 1)
  // - Separator: space, hyphen, parentheses, or no separator
  // - Exchange code: 3 digits
  // - Subscriber number: 4 digits
  const phoneRegex = /^(?:\+1[\s.-]?)?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  const match = value.trim().match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  // If allowExtensions is true, we could extend this to handle extensions
  // For now, we don't handle extensions
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Pattern explanation:
  // - Optional country code +54
  // - Optional trunk prefix 0 immediately before area code
  // - Optional mobile indicator 9 between country/trunk and area code
  // - Area code: 2-4 digits, first digit 1-9
  // - Subscriber number: 6-8 digits total after area code
  // - Allow spaces or hyphens as separators
  
  // Remove all whitespace to simplify validation
  const cleaned = value.replace(/\s+/g, ' ').trim();
  
  // Pattern that allows subscriber number with spaces/hyphens
  // Match: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const pattern = /^(?:\+54\s*)?(?:0\s*)?(?:9\s*)?([1-9]\d{1,3})\s+(?:[\d\s-]{6,15})$/;
  const match = cleaned.match(pattern);
  
  if (!match) {
    return false;
  }
  
  // When country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = /^0/.test(cleaned);
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Validate total digit count (excluding country code if present)
  const digitsOnly = cleaned.replace(/\D/g, '');
  // If has country code, total should be 12-14 digits (+54 = 2, area = 2-4, subscriber = 6-8)
  // If no country code, total should be 10-13 digits (trunk = 1, area = 2-4, subscriber = 6-8)
  if (hasCountryCode) {
    const totalLength = digitsOnly.length;
    // +54 = 2 digits, area = 2-4 digits, subscriber = 6-8 digits, total = 10-14 digits
    if (totalLength < 10 || totalLength > 14) {
      return false;
    }
  } else {
    const totalLength = digitsOnly.length;
    // trunk (0) = 1 digit, area = 2-4 digits, subscriber = 6-8 digits, total = 9-13 digits
    if (totalLength < 9 || totalLength > 13) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern explanation:
  // - Allow unicode letters, accents, apostrophes ('), hyphens (-), and spaces
  // - Must start with a letter
  // - No digits or special symbols
  // - Must contain at least one letter
  const nameRegex = /^[\p{L}](?:[\p{L}\p{M}'\-\s]*[\p{L}\p{M}])?$/u;
  
  // Reject names that look like X Æ A-12
  if (/[0-9Æ]/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value.trim());
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all remaining characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card length (13-19 digits)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card prefixes and validate length:
  // - Visa: starts with 4 (13-19 digits)
  // - Mastercard: starts with 51-55 or 2221-2720 (16 digits)
  // - AmEx: starts with 34 or 37 (15 digits)
  // - Discover: starts with 6011, 65, 644-649, or 622126-622925
  // - JCB: starts with 3528-3589
  
  let isValidPrefix = false;
  
  // Visa
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValidPrefix = true;
  }
  // Mastercard 51-55
  else if (cleaned.length === 16 && (cleaned.startsWith('51') || cleaned.startsWith('52') || 
            cleaned.startsWith('53') || cleaned.startsWith('54') || cleaned.startsWith('55'))) {
    isValidPrefix = true;
  }
  // Mastercard 2221-2720 range
  else if (cleaned.length === 16) {
    const prefix4 = parseInt(cleaned.substring(0, 4), 10);
    if (prefix4 >= 2221 && prefix4 <= 2720) {
      isValidPrefix = true;
    }
    // JCB 3528-3589
    else if (prefix4 >= 3528 && prefix4 <= 3589) {
      isValidPrefix = true;
    }
    // Discover 644-649, 65, 6011, 622126-622925
    else {
      const prefix3 = parseInt(cleaned.substring(0, 3), 10);
      const prefix2 = parseInt(cleaned.substring(0, 2), 10);
      const prefix6 = parseInt(cleaned.substring(0, 6), 10);
      
      if ((prefix3 >= 644 && prefix3 <= 649) || prefix2 === 65 || 
          cleaned.startsWith('6011') || (prefix6 >= 622126 && prefix6 <= 622925)) {
        isValidPrefix = true;
      }
    }
  }
  // American Express
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
