/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence boundaries: end of sentence (., ?, !) followed by whitespace
  // We need to preserve abbreviations like "Mr." or "Dr." which shouldn't end sentences
  
  // Strategy:
  // 1. Split text into sentences based on .?! followed by whitespace
  // 2. Capitalize first letter of each sentence
  // 3. Join with exactly one space
  
  const sentences = text.split(/([.!?]+\s+)/);
  let result = '';
  
  for (let i = 0; i < sentences.length; i += 2) {
    // Get the sentence (odd indices are punctuation+space)
    let sentence = sentences[i];
    
    // Skip empty sentences
    if (!sentence.trim()) {
      continue;
    }
    
    // Capitalize first character
    if (sentence.length > 0) {
      sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    result += sentence;
    
    // Add punctuation and space if they exist
    if (i + 1 < sentences.length) {
      result += sentences[i + 1];
    }
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https only)
  // Match http:// or https:// followed by domain and path
  // Capture until we hit whitespace or common punctuation
  const urlRegex = /\bhttps?:\/\/[^\s<>"'\)\]\}]+/gi;
  
  const urls = text.match(urlRegex) || [];
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http:// URLs and capture host and path
  // Pattern: http:// followed by domain, then capture the rest
  return text.replace(/http:\/\/([^\/\s]+)(\S*)/g, (match, host, path) => {
    // Check if path contains dynamic hints (query strings or dynamic extensions)
    const hasQueryString = /[?&=]/.test(path);
    const hasDynamicExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i.test(path);
    const hasCgiBin = /cgi-bin/i.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasQueryString && !hasDynamicExtension && !hasCgiBin) {
      return `https://docs.${host}${path}`;
    }
    
    // Otherwise, just upgrade to https
    return `https://${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Leap year consideration
  const maxDay = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
