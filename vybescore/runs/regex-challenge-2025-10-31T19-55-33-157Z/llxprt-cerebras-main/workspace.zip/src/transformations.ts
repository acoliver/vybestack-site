/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Split text into sentences by punctuation followed by whitespace or end of string
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim beginning and end spaces
    sentence = sentence.trim();
    
    // If sentence is empty, skip it
    if (!sentence) return sentence;
    
    // Capitalize first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join sentences with exactly one space
  return processedSentences.filter(s => s).join(' ');
}

/**
 * Extract URLs from text.
 * Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern (simplified but functional)
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  // Find all URLs
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.!?;:,]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:/g, 'https:');
}

/**
 * Rewrite URLs moving docs paths to docs subdomain.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match URLs with exclusions for dynamic paths
  const urlRegex = /http:\/\/([\w.-]+)\/(?!cgi-bin|.*[?&=]|.*\.(?:jsp|php|asp|aspx|do|cgi|pl|py))(docs\/.*)/g;
  
  return text.replace(urlRegex, (match, host, path) => {
    return `https://docs.${host}/${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Validate date format mm/dd/yyyy
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match.map(Number);
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year.toString();
}