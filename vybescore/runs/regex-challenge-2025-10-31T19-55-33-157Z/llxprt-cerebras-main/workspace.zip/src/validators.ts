export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag @example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure and common invalid patterns
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for invalid patterns
  if (!value || value.includes('..') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for valid pattern with optional +1 prefix
  const phoneRegex = /^(\+1)?([2-9]\d{2})(\d{3})(\d{4})$/;
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  // Extract components
  const [, , areaCode] = match;
  
  // Validate area code (must not start with 0 or 1)
  if (!areaCode || areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers in various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace, hyphens and parentheses for validation
  const cleaned = value.replace(/[\s\-\(\)]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Supports optional +54 country code, optional 0 prefix, optional 9 mobile indicator
  // Area code 2-4 digits (1-9), subscriber number 6-8 digits
  const phoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , , subscriberNumber] = match;
  
  // Either country code or trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate subscriber number length
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value) {
    return false;
  }

  // Check for digits or symbols (excluding allowed characters: letters, accents, apostrophes, hyphens, spaces)
  const validNameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  const hasInvalidChars = !validNameRegex.test(value);
  
  if (hasInvalidChars) {
    return false;
  }
  
  // Check for X Æ A-12 style names (with digit)
  const containsDigit = /\d/.test(value);
  if (containsDigit) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all spaces and hyphens
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Check basic format (only digits)
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type prefixes and lengths
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/; // 16 digits, starts with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  if (!(visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))) {
    return false;
  }
  
  // Luhn algorithm implementation
  return runLuhnCheck(cleaned);
}

// Helper function to perform Luhn algorithm check
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}