// Simple debug script to test reactive behavior
import { createInput, createComputed } from './src/index.js';

console.log('Testing reactive computations...');

// Test case from failing tests
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const timesThirty = createComputed(() => input() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());

console.log('Initial sum (should be 32):', sum());
setInput(3);
console.log('Updated sum (should be 96):', sum());