/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  UnsubscribeFn,
  Observer,
  UpdateFn,
  updateObserver
} from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      // Execute the callback function which will track dependencies
      const result = updateFn(currentValue)
      return result
    }
  }
  
  // Register observer by executing it to track dependencies
  try {
    updateObserver(observer)
  } catch (error) {
    console.error('Error creating callback:', error)
  }
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // Replace updateFn with no-op
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}