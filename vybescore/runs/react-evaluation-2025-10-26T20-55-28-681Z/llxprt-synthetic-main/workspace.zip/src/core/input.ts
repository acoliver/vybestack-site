/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    // Always false, means no equality check
    equalFn = () => false
  } else if (equal === true) {
    // Always true, means always equal
    equalFn = () => true
  } else {
    // Default equality using Object.is
    equalFn = (a, b) => Object.is(a, b)
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observer !== observer) {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if the value has actually changed
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // If there's an observer depending on this subject, update it
      if (s.observer) {
        updateObserver(s.observer as unknown as Observer<T>)
      }
    }
    return s.value
  }

  return [read, write]
}