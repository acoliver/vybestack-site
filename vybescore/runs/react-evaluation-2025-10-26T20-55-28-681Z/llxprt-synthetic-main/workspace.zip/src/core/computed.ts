/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

// Extending Observer to include observer property
interface ComputedObserver<T> extends Observer<T> {
  observer?: ObserverR
}

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    // Always false, means no equality check
    equalFn = () => false
  } else if (equal === true) {
    // Always true, means always equal
    equalFn = () => true
  } else {
    // Default equality using Object.is
    equalFn = (a, b) => Object.is(a, b)
  }

  const computed: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initialize the computed value - only if no initial value is provided
  if (value === undefined) {
    // Don't initialize here - let the getter compute on first access
  } else {
    computed.value = value
  }

  // Override update function to handle recomputation
  const originalUpdateFn = computed.updateFn
  computed.updateFn = (currentValue) => {
    // Execute the original update function to recompute the value
    const newValue = originalUpdateFn(currentValue)
    
    // Only update if value has actually changed
    if (!equalFn(currentValue as T, newValue)) {
      computed.value = newValue
      
      // Notify any observers that depend on this computed value
      // This is handled through the observer.observer reference
      if (computed.observer) {
        updateObserver(computed.observer as unknown as Observer<T>)
      }
    }
    
    return newValue
  }

  const getter: GetterFn<T> = () => {
    const active = getActiveObserver()
    
    // If there's an active observer, set this computed as their observer
    if (active && computed.observer !== active) {
      computed.observer = active
    }
    
    // If the computed value hasn't been initialized yet, compute it now
    if (computed.value === undefined) {
      try {
        computed.value = updateFn()
      } catch (error) {
        console.error('Error computing value:', error)
        computed.value = undefined
      }
    }
    
    return computed.value as T
  }

  // Initialize the computed by executing it once to establish dependencies
  try {
    updateObserver(computed as Observer<T>)
  } catch (error) {
    console.error('Error initializing computed:', error)
  }

  return getter
}