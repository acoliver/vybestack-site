export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject dots at start or end of local part
  const [local, domain] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain parts that start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers in common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const cleanNumber = value.replace(/\D/g, '');
  
  // Optional +1 prefix
  let digits = cleanNumber;
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must have exactly 10 digits for a valid US number
  if (digits.length !== 10) {
    return false;
  }
  
  // Validate area code (first three digits)
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Accept various formats with the digits we've validated
  const patterns = [
    /^\(\d{3}\) \d{3}-\d{4}$/, // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,    // 212-555-7890  
    /^\d{10}$/,               // 2125557890
    /^\+\d{1} \(\d{3}\) \d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+\d{1} \d{3}-\d{3}-\d{4}$/,     // +1 212-555-7890
    /^\+\d{1}\d{10}$/                 // +12125557890
  ];
  
  return patterns.some(pattern => pattern.test(value)) || value.replace(/\D/g, '').length === 10;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code  
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must have 6-8 digits total
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allows spaces/hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Main regex pattern for Argentine phone numbers
  const argPhonePattern = /^(\+?54)?(9?)(0?[2-9]\d{1,3})(\d{6,8})$/;
  
  if (!argPhonePattern.test(cleanValue)) {
    return false;
  }
  
  const match = cleanValue.match(argPhonePattern);
  if (!match) return false;
  
  const [, countryCode, _mobileIndicator, areaCode, subscriber] = match;
  
  // If no country code, must have trunk prefix (starts with 0)
  if (!countryCode) {
    // The cleaned value should start with 0 in this case
    if (!cleanValue.startsWith('0')) {
      return false;
    }
  }
  
  // Area code must be 2-4 digits with leading digit 1-9 (we already enforce this in regex)
  const areaCodeDigits = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (areaCodeDigits.length < 2 || areaCodeDigits.length > 4) {
    return false;
  }
  
  // Subscriber number validation (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names using unicode letters, accents, apostrophes, and hyphens.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Unicode letter pattern that includes accented characters
  // Allows letters (including unicode), apostrophes, hyphens, and spaces
  // Must contain at least one letter
  const namePattern = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  // Check if the pattern matches
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Ensure at least one letter is present (prevents just spaces/symbols)
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names that are just sequences of the same character repeated
  const cleanName = value.replace(/[\s'’\-]/g, '');
  if (cleanName.length > 0 && new Set(cleanName).size === 1) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using format checks and Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits and have valid length (13-19 digits)
  if (!/^\d{13,19}$/.test(cleanValue)) {
    return false;
  }
  
  // Check card prefixes and lengths
  // Visa: starts with 4, length 13 or 16 digits
  const visaPattern = /^4(\d{12}|\d{15})$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16 digits
  const mastercardPattern1 = /^5[1-5]\d{14}$/;
  const mastercardPattern2 = /^2(2[2-9]\d|3[0-9]\d|[4-9]\d\d|1\d{3}|0\d{4}|7[0-2]\d{2})\d{10}$/;
  // AmEx: starts with 34 or 37, length 15 digits  
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if number matches any known card pattern
  const validFormat = visaPattern.test(cleanValue) ||
                     mastercardPattern1.test(cleanValue) ||
                     mastercardPattern2.test(cleanValue) ||
                     amexPattern.test(cleanValue);
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
