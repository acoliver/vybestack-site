/**
 * Capitalizes the first character of each sentence.
 * Handles sentence boundaries after .?! punctuation, inserts exactly one space between sentences,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Common abbreviations that don't end sentences
  const abbreviations = /\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|Ln|etc|e\.g|i\.e)\.?$/i;
  
  // Split text into potential sentences
  const sentences = [];
  let currentSentence = '';
  
  for (let i = 0; i < text.length; i++) {
    currentSentence += text[i];
    
    const char = text[i];
    const nextChar = text[i + 1];
    
    // Check for sentence-ending punctuation
    if (char === '.' || char === '!' || char === '?') {
      // Look ahead to see if this is really a sentence end
      // by checking what follows
      let isSentenceEnd = true;
      
      // Check if current sentence with punctuation might be an abbreviation
      const beforePunct = currentSentence.slice(0, -1).trim();
      if (abbreviations.test(beforePunct)) {
        isSentenceEnd = false;
      }
      
      // Also check if there's a lowercase letter right after punctuation
      if (nextChar && /[a-z]/.test(nextChar)) {
        isSentenceEnd = false;
      }
      
      if (isSentenceEnd) {
        sentences.push(currentSentence);
        currentSentence = '';
      }
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence);
  }
  
  // Process each sentence: collapse spaces, capitalize first letter, add single space between
  const processedSentences = sentences.map(sentence => {
    let processed = sentence.trim();
    
    if (processed.length > 0) {
      // Capitalize first character if it's a letter
      const firstChar = processed[0];
      if (/[a-z]/.test(firstChar)) {
        processed = processed.substring(0, 1).toUpperCase() + processed.substring(1);
      }
    }
    
    return processed;
  });
  
  return processedSentences.join(' ');
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches common URL formats
  const urlPattern = /(https?:\/\/)?([\da-z\.-]+)\.([a-z.]{2,6})([\/\w .-]*)*\/?/gi;
  
  // Find all matches
  const matches = text.match(urlPattern);
  
  if (!matches) {
    return [];
  }
  
  // Clean matches by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;!?')]+$/g, '');
  });
  
  // If the protocol is missing, add http:// for validation and then remove it
  const processedUrls = cleanedUrls.map(url => {
    if (!url.match(/^https?:\/\//)) {
      return url;
    }
    return url;
  });
  
  return processedUrls;
}

/**
 * Forces all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/....
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?,?,&=), or legacy extensions like .jsp, .php, etc., but still upgrade the scheme to https://.
 * - Preserve nested paths (e.g., /docs/api/v1).
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/example\.com(\/[^?\s]*)/g, (match, path) => {
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = /(\/cgi-bin|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    
    // Always upgrade to https
    let rewrittenUrl = `https://example.com${path}`;
    
    // Check if we should rewrite host to docs.example.com
    if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
      rewrittenUrl = `https://docs.example.com${path}`;
    } else {
      // Just ensure https scheme
      rewrittenUrl = `https://example.com${path}`;
    }
    
    return rewrittenUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Strict pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Additional validation for days based on month
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Basic validation for valid days per month (non-leap year for simplicity)
  const validDaysPerMonth = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  // Check if day is valid for the month
  if (dayNum > validDaysPerMonth[monthNum as keyof typeof validDaysPerMonth]) {
    // Check leap year for February
    if (monthNum === 2 && dayNum === 29) {
      // Leap year check (year divisible by 4, but not 100 unless also 400)
      const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
      if (!isLeapYear) {
        return 'N/A';
      }
    } else {
      return 'N/A';
    }
  }
  
  return year;
}
