/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(exc => exc.toLowerCase());
  
  return matches.filter(word => 
    !lowerExceptions.includes(word.toLowerCase())
  ).filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds as described in requirements.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, but token not at start of string
  const pattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates password strength according to the policy requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, cdcd)
  // Look for any 2-character sequence that repeats immediately
  if (/(.{2})\\1/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences of length 3 or more (e.g., abcabc)
  if (/(.{3,})\\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 * Returns true if a valid IPv6 address is found in the text.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern to exclude
  const ipv4Pattern = /\b\d{1,3}(?:\.\d{1,3}){3}\d{1,3}\b/;
  
  // Check if the string contains an IPv4 address
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address patterns
  // Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (compressed)
  const ipv6Short1 = /(?:[0-9a-fA-F]{1,4}:){1,7}:/;
  const ipv6Short2 = /:(?:[0-9a-fA-F]{1,4}:){1,7}/;
  const ipv6Short3 = /(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}/;
  const ipv6Short4 = /(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}/;
  const ipv6Short5 = /(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}/;
  const ipv6Short6 = /(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}/;
  
  // Special case for ::
  const ipv6DoubleColon = /::/;
  
  // IPv6 with IPv4 embedded: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:ipv4
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check any IPv6 pattern
  const ipv6Patterns = [
    ipv6Full,
    ipv6Short1,
    ipv6Short2,
    ipv6Short3,
    ipv6Short4,
    ipv6Short5,
    ipv6Short6,
  ];
  
  // Check for any valid IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (value.match(pattern)) {
      // Ensure it's not just a colon at the end or weird formatting
      if (ipv6DoubleColon.test(value)) {
        // Additional validation for :: cases
        const segments = value.split(':');
        const validSegments = segments.filter(seg => seg !== '');
        
        // Should have 8 segments total when fully expanded
        if (validSegments.length <= 8) {
          return true;
        }
      } else {
        return true;
      }
    }
  }
  
  // Special check for :: at boundaries
  if (value.includes('::')) {
    return true;
  }
  
  // Check IPv6 with embedded IPv4
  if (ipv6WithIPv4.test(value)) {
    return true;
  }
  
  return false;
}
