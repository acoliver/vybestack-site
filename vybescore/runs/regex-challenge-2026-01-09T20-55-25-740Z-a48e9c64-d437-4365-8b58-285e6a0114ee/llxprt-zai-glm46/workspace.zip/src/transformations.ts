/**
 * Capitalize the first character of each sentence.
 * - Capitalize after .?!
 * - Insert exactly one space between sentences
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }

  // First, normalize spaces - collapse multiple spaces to one
  let result = text.replace(/\s+/g, ' ');

  // Ensure there's exactly one space after sentence-ending punctuation
  // Match .!? followed by optional space, then lowercase letter
  result = result.replace(/([.!?])(\s*)([a-z])/g, '$1 $3');

  // Now capitalize the first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Capitalize after sentence boundaries (., !, ?) followed by space and lowercase
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  // Handle abbreviations - if a single letter followed by dot is followed by lowercase,
  // it's likely an abbreviation like "e.g." or "i.e."
  // We need to avoid capitalizing after common abbreviations
  const abbreviations = ['e\\.g\\.', 'i\\.e\\.', 'etc\\.', 'vs\\.', 'mr\\.', 'mrs\\.', 'ms\\.', 'dr\\.', 'prof\\.', 'sr\\.', 'jr\\.', 'no\\.', 'st\\.'];

  // For each abbreviation, find the pattern and check if capitalization was incorrectly applied
  abbreviations.forEach(abbr => {
    const pattern = new RegExp(`(${abbr}\\s+)([A-Z])`, 'gi');
    result = result.replace(pattern, (match, prefix, letter) => {
      return prefix + letter.toLowerCase();
    });
  });

  return result.trim();
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // Comprehensive URL regex pattern
  // Matches http://, https://, www., or domain-only URLs
  // Captures the URL while allowing trailing punctuation to be excluded
  const urlRegex = /(?:https?:\/\/|www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:[.][a-zA-Z0-9][a-zA-Z0-9-]*)+(?::\d+)?(?:\/[^\s\])}\.,;!?"]*)?(?<![.,;!?])/g;

  const matches = text.match(urlRegex);

  if (!matches) {
    return [];
  }

  // Post-process to remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that might have been included
    return url.replace(/[.,;!?]+$/, '');
  }).filter(url => {
    // Ensure URL has a valid structure
    const hasProtocol = url.startsWith('http://') || url.startsWith('https://');
    const hasWww = url.startsWith('www.');
    const hasDomain = /\.[a-zA-Z]{2,}/.test(url);
    const hasPath = url.includes('/');

    // Must have either protocol or www, and a valid domain or path
    return (hasProtocol || hasWww) && (hasDomain || hasPath);
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://...
 * Move docs paths to https://docs.example.com/ where applicable.
 * Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Dynamic hints that should prevent host rewrite
  const dynamicHints = [
    'cgi-bin',
    '\\?',
    '&',
    '=',
    '\\.jsp$',
    '\\.php$',
    '\\.asp$',
    '\\.aspx$',
    '\\.do$',
    '\\.cgi$',
    '\\.pl$',
    '\\.py$'
  ];

  // Build regex to detect dynamic hints in the path portion
  const dynamicPattern = new RegExp(dynamicHints.join('|'));

  // Pattern to match example.com URLs
  // Captures: scheme, subdomain, domain, path
  const urlPattern = /(https?:\/\/)(?:www\.)?(example\.com)(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, scheme, domain, path = '') => {
    // Always upgrade scheme to https
    const newScheme = 'https://';

    // Check if path contains dynamic hints that should prevent host rewrite
    const hasDynamicHint = dynamicPattern.test(path);

    if (path.startsWith('/docs/') && !hasDynamicHint) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.' + domain + path;
    } else {
      // Only upgrade scheme
      return newScheme + 'www.' + domain + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  // Validate year is reasonable (not 0000, and within reasonable range)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }

  return yearStr;
}
