/**
 * Find words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Regex to find words starting with the prefix
  // \b ensures we match whole words only
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(wordPattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const results = matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));

  // Return unique results (preserving case)
  return Array.from(new Set(results));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // We need to return the actual matched strings (including the digit)
  // Let's adjust: we want to find the digit+token combination
  const fullPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const fullMatches = text.match(fullPattern) || [];

  return fullMatches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }

  // Minimum length of 10
  if (value.length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // A repeated sequence is a pattern that repeats itself immediately
  // For example: "abab" has "ab" repeating
  for (let i = 2; i <= value.length / 2; i++) {
    for (let j = 0; j <= value.length - 2 * i; j++) {
      const substr1 = value.substring(j, j + i);
      const substr2 = value.substring(j + i, j + 2 * i);
      if (substr1 === substr2) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // First, explicitly exclude IPv4 addresses
  // IPv4 pattern: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Extract potential IPv6 addresses from the text
  const ipv6Candidates = value.match(/[0-9a-fA-F:]+/g) || [];

  for (const candidate of ipv6Candidates) {
    // Must contain colons
    if (!candidate.includes(':')) {
      continue;
    }

    // Must have only hex digits and colons
    if (!/^[0-9a-fA-F:]+$/.test(candidate)) {
      continue;
    }

    // Can't have more than one ::
    if ((candidate.match(/::/g) || []).length > 1) {
      continue;
    }

    // Split by : to analyze structure
    const parts = candidate.split(':');

    // Validate each part
    let validStructure = true;
    for (const part of parts) {
      if (part === '') {
        continue; // Empty part is ok with ::
      }
      if (part.length > 4) {
        validStructure = false;
        break;
      }
      if (!/^[0-9a-fA-F]+$/.test(part)) {
        validStructure = false;
        break;
      }
    }

    if (validStructure && parts.length >= 2 && parts.length <= 8) {
      return true;
    }

    // Check against standard patterns
    const trimmed = candidate;

    // Full form: 8 groups of 1-4 hex digits
    const fullForm = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    if (fullForm.test(trimmed)) {
      return true;
    }

    // Compressed with :: at start
    const startCompressed = /^::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$/;
    if (startCompressed.test(trimmed)) {
      return true;
    }

    // Compressed with :: at end
    const endCompressed = /^(?:[0-9a-fA-F]{1,4}:){1,7}:$/;
    if (endCompressed.test(trimmed)) {
      return true;
    }

    // Compressed with :: in middle
    const middleCompressed = /^(?:[0-9a-fA-F]{1,4}:){1,6}:(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}$/;
    if (middleCompressed.test(trimmed)) {
      return true;
    }

    // IPv6 with IPv4 embedded (e.g., ::ffff:192.168.1.1)
    const embeddedIPv4 = /^::$|^::1$|^(?:[0-9a-fA-F]{1,4}:){1,5}:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/;
    if (embeddedIPv4.test(trimmed)) {
      return true;
    }
  }

  return false;
}
