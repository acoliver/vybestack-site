export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 254) {
    return false;
  }

  // Email regex pattern:
  // - Local part: alphanumeric, dots, hyphens, underscores, plus signs
  // - No consecutive dots, no leading/trailing dots in local part
  // - @ symbol
  // - Domain: alphanumeric and hyphens only (no underscores)
  // - No consecutive dots, no leading/trailing dots in domain
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9+._-]*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for invalid patterns
  const [, domain] = value.split('@');

  // No double dots
  if (value.includes('..')) {
    return false;
  }

  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) {
    return false;
  }

  // Remove all common separators and spaces for validation
  const cleaned = value.replace(/[\s\-().]/g, '');

  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    // If exactly 11 digits and starts with 1, treat 1 as country code
    digits = digits.slice(1);
  }

  // Must be exactly 10 digits (without country code)
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Handle extensions if allowed
  if (options?.allowExtensions) {
    const extMatch = cleaned.match(/ext\.?\s*(\d+)$/i);
    if (extMatch) {
      // Extension found, basic validation already passed
      return true;
    }
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove all spaces, hyphens, and parentheses for validation
  const cleaned = value.replace(/[\s\-()]/g, '');

  // Argentine phone regex breakdown:
  // ^\+?54? - Optional +54 country code
  // (?:(?:0)?9)? - Optional trunk prefix 0, followed by optional mobile indicator 9
  // (\d{2,4}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const phoneRegex = /^(\+?54)?(?:0?9)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(phoneRegex);
  if (!match) {
    return false;
  }

  const [, countryCode] = match;

  // If country code is omitted, number must begin with trunk prefix 0
  const hasCountryCode = countryCode && countryCode.startsWith('+54');
  if (!hasCountryCode) {
    // When no country code, must have trunk prefix 0 before area code
    if (!cleaned.match(/^0/)) {
      return false;
    }
  }

  // Area code must be 2-4 digits (already enforced by regex)
  // Leading digit of area code must be 1-9 (already enforced by regex)

  // Validate total length makes sense
  // Country code (54 if present) + optional 9 (mobile) + area code + subscriber
  // Should be between 10-14 digits total
  const totalDigits = cleaned.replace(/\+/g, '').length;
  if (totalDigits < 10 || totalDigits > 14) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Regex explanation:
  // ^\p{L}+ - Start with one or more unicode letters
  // [\p{L}\s\'\-]* - Followed by any combination of unicode letters, spaces, apostrophes, hyphens
  // \p{L}+$ - End with one or more unicode letters
  // This ensures:
  // - No digits
  // - No symbols (except apostrophe and hyphen in appropriate positions)
  // - Names like "X Æ A-12" are rejected (contains digits and symbols like Æ)
  const nameRegex = /^\p{L}+(?:[\p{L}\s''\-]*\p{L}+)?$/u;

  // Additional validation to reject problematic patterns
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }

  // Check for invalid symbols (anything not a letter, space, apostrophe, or hyphen)
  // Using a broader check to catch symbols like Æ, -, etc.
  const validCharsRegex = /^[\p{L}\s''\-]+$/u;
  if (!validCharsRegex.test(value)) {
    return false;
  }

  // Ensure at least two letter characters (first and last name)
  const letterCount = (value.match(/\p{L}/gu) || []).length;
  if (letterCount < 2) {
    return false;
  }

  return nameRegex.test(value);
}

/**
 * Run Luhn checksum algorithm on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12,15}$/;

  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-9]{14})$/;

  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validPrefix = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);

  if (!validPrefix) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(digits);
}
