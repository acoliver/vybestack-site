import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';
import type { ReportData } from '../../src/types.js';

describe('report CLI formatting', () => {
  const testData: ReportData = {
    title: 'Quarterly Financial Summary',
    summary: 'Highlights include record revenue across regions and a healthy outlook for the next quarter.',
    entries: [
      { label: 'North Region', amount: 12345.67 },
      { label: 'South Region', amount: 23456.78 },
      { label: 'West Region', amount: 34567.89 }
    ]
  };

  describe('markdown formatter', () => {
    it('should format report without totals', () => {
      const result = renderMarkdown(testData, { includeTotals: false });
      const lines = result.split('\n');
      
      expect(lines[0]).toBe('# Quarterly Financial Summary');
      expect(lines[2]).toBe('Highlights include record revenue across regions and a healthy outlook for the next quarter.');
      expect(lines[4]).toBe('## Entries');
      expect(lines[5]).toBe('- **North Region** — $12345.67');
      expect(lines[6]).toBe('- **South Region** — $23456.78');
      expect(lines[7]).toBe('- **West Region** — $34567.89');
      expect(lines).toHaveLength(8);
    });

    it('should format report with totals', () => {
      const result = renderMarkdown(testData, { includeTotals: true });
      const lines = result.split('\n');
      
      expect(lines[0]).toBe('# Quarterly Financial Summary');
      expect(lines[5]).toBe('- **North Region** — $12345.67');
      expect(lines[8]).toBe('**Total:** $70370.34');
      expect(lines).toHaveLength(9);
    });
  });

  describe('text formatter', () => {
    it('should format report without totals', () => {
      const result = renderText(testData, { includeTotals: false });
      const lines = result.split('\n');
      
      expect(lines[0]).toBe('Quarterly Financial Summary');
      expect(lines[1]).toBe('Highlights include record revenue across regions and a healthy outlook for the next quarter.');
      expect(lines[2]).toBe('Entries:');
      expect(lines[3]).toBe('- North Region: $12345.67');
      expect(lines[4]).toBe('- South Region: $23456.78');
      expect(lines[5]).toBe('- West Region: $34567.89');
      expect(lines).toHaveLength(6);
    });

    it('should format report with totals', () => {
      const result = renderText(testData, { includeTotals: true });
      const lines = result.split('\n');
      
      expect(lines[0]).toBe('Quarterly Financial Summary');
      expect(lines[3]).toBe('- North Region: $12345.67');
      expect(lines[6]).toBe('Total: $70370.34');
      expect(lines).toHaveLength(7);
    });
  });
});
