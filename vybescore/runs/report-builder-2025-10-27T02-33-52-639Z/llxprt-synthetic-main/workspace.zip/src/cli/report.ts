#!/usr/bin/env node

import { existsSync } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { ReportData } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

/**
 * Parse command-line arguments.
 * Expected format: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(): {
  dataFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('--format argument is required');
  }
  const format = args[formatIndex + 1];
  
  const outputIndex = args.indexOf('--output');
  const outputFile = outputIndex !== -1 && outputIndex + 1 < args.length 
    ? args[outputIndex + 1] 
    : undefined;
    
  const includeTotals = args.includes('--includeTotals');
  
  return { dataFile, format, outputFile, includeTotals };
}

/**
 * Validate the report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: expected an object');
  }
  
  const dataObj = data as Record<string, unknown>;
  
  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid data: title (string) is required');
  }
  
  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid data: summary (string) is required');
  }
  
  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid data: entries (array) is required');
  }
  
  for (const entry of dataObj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: expected an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: label (string) is required');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: amount (number) is required');
    }
  }
  
  return data as ReportData;
}

/**
 * Load and parse JSON data from file
 */
async function loadDataFile(filePath: string): Promise<ReportData> {
  try {
    // First try to treat the path as absolute
    if (existsSync(filePath)) {
      const content = await readFile(filePath, 'utf8');
      const data = JSON.parse(content);
      return validateReportData(data);
    }
    
    // If not found, try as relative to the working directory
    const absolutePath = join(process.cwd(), filePath);
    
    if (!existsSync(absolutePath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    
    const content = await readFile(absolutePath, 'utf8');
    const data = JSON.parse(content);
    
    return validateReportData(data);
  } catch (error: unknown) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}`);
    }
    throw error;
  }
}

/**
 * Main CLI execution
 */
async function main(): Promise<void> {
  try {
    const { dataFile, format, outputFile, includeTotals } = parseArgs();
    
    const data = await loadDataFile(dataFile);
    
    let formatter;
    switch (format) {
      case 'markdown':
        formatter = markdownFormatter;
        break;
      case 'text':
        formatter = textFormatter;
        break;
      default:
        throw new Error(`Unsupported format: ${format}`);
    }
    
    const result = formatter.render(data, { includeTotals });
    
    if (outputFile) {
      await writeFile(outputFile, result);
      console.log(`Report saved to ${outputFile}`);
    } else {
      console.log(result);
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error(errorMessage);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}