/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.length === 0) {
    return text;
  }
  
  // Split text by sentence delimiters (. ? !) and handle spacing
  const sentences = text.split(/([.?!])/);
  
  for (let i = 0; i < sentences.length; i++) {
    // Even indices are the sentence text, odd are punctuation
    if (i % 2 === 0) {
      const sentence = sentences[i].trim();
      if (sentence.length > 0) {
        sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
    }
  }
  
  // Join together with proper spacing
  let result = '';
  for (let i = 0; i < sentences.length; i++) {
    result += sentences[i];
    
    // Add space after punctuation unless at end or next element starts with space
    if (i % 2 === 1 && i < sentences.length - 1 && !sentences[i+1].startsWith(' ')) {
      result += ' ';
    }
  }
  
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https followed by domain and optional path
  const urlPattern = /(https?:\/\/[^\s)]+)/g;
  
  const matches = [];
  let match;
  
  // eslint-disable-next-line no-cond-assign
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?]+$/g, '');
    matches.push(url);
  }
  
  return [...new Set(matches)];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when not already secure
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // First upgrade to https, then optionally rewrite host if path begins with /docs/ and doesn't contain dynamic hints
  return text.replace(
    /http:\/\/example\.com(\/(?:docs\/(?:[^?&\#]*|(?:[^?&\#]*\.[?&\#]*))|(?!docs)[^?&\#]*)[^?&\#]*(?:\.[?&\#]*)?)/g,
    (match, path) => {
      // Always upgrade to https
      const httpsUrl = 'https://example.com' + path;
      
      // Skip host rewrite if path contains cgi-bin, query hints, or legacy extensions
      const skipConditions = [
        /cgi-bin/,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)/
      ];
      
      const shouldSkipHostRewrite = skipConditions.some(condition => 
        condition.test(path)
      );
      
      // If path begins with /docs/ and should not skip, rewrite host
      if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
        return httpsUrl.replace('https://example.com', 'https://docs.example.com');
      }
      
      return httpsUrl;
    }
  );
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Additional validation for month/day combinations
  const maxDay = {
    1: 31, // January
    2: (yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0)) ? 29 : 28, // February (leap year)
    3: 31, // March
    4: 30, // April
    5: 31, // May
    6: 30, // June
    7: 31, // July
    8: 31, // August
    9: 30, // September
    10: 31, // October
    11: 30, // November
    12: 31 // December
  };
  
  if (dayNum > (maxDay as Record<number, number>)[monthNum]) {
    return 'N/A';
  }
  
  return year;
}
