export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Accept typical addresses such as name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores, and other obviously invalid forms
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check against basic pattern first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks to catch invalid cases
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No domain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // No trailing dots in local part or domain
  const parts = value.split('@');
  if (parts[0].endsWith('.') || parts[1].endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if we have appropriate number of digits (10 for US number, 11 if country code included)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove leading +1
    const withoutCountryCode = digits.substring(1);
    return isValidUSPhoneDigits(withoutCountryCode);
  } else if (digits.length === 10) {
    return isValidUSPhoneDigits(digits);
  }
  
  return false;
}

function isValidUSPhoneDigits(digits: string): boolean {
  // Check first digit of area code is not 0 or 1
  return !(digits[0] === '0' || digits[0] === '1');
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  // - Optional country code +54
  // - Optional trunk prefix 0 immediately before the area code
  // - Optional mobile indicator 9 between country/trunk and the area code
  // - Area code must be 2-4 digits (leading digit 1-9)
  // - Subscriber number (after the area code) must contain 6-8 digits in total
  // - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
  // - Allow single spaces or hyphens as separators; ignore punctuation when validating
  
  // Remove spaces and hyphens for validation
  const normalizedValue = value.replace(/[ -]/g, '');
  
  // Regex pattern:
  // ^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = normalizedValue.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix] = match;
  
  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Unicode letters, accents, apostrophes, hyphens, and spaces
  const namePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check against pattern first
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject digits and symbols
  if (/\d/.test(value) || /[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEvenDigit = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    
    if (isEvenDigit) {
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        doubledDigit = (doubledDigit % 10) + 1;
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    isEvenDigit = !isEvenDigit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[ -]/g, '');
  
  // Validate basic pattern - simplified for common cards
  // Visa: starts with 4, 13 or 16 digits
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/;
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  const mastercardPattern = /^5[1-5][0-9]{14}$|^22[2-9][0-9]{12}$|^2[3-6][0-9]{13}$|^27[01][0-9]{12}$|^2720[0-9]{10}$/;
  // Amex: starts with 34 or 37, 15 digits
  const amexPattern = /^3[47][0-9]{13}$/;
  
  // Check if matches any card pattern
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
