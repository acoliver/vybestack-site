/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with the prefix
  const prefixPattern = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches = [];
  let match;
  
  // eslint-disable-next-line no-cond-assign
  while ((match = prefixPattern.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if word is in exceptions
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return [...new Set(matches)]; // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create pattern to find token after a digit and not at start of string
  // Since lookbehind is not supported in all environments, use a different approach
  const digitAndTokenPattern = new RegExp(`(\\d)(${token})(\\b)`, 'g');
  
  const matches = [];
  let match;
  
  // eslint-disable-next-line no-cond-assign
  while ((match = digitAndTokenPattern.exec(text)) !== null) {
    // Return the digit and token combined
    matches.push(match[1] + match[2]);
  }
  
  return [...new Set(matches)]; // Remove duplicates
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>\/?]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 1212)
  for (let i = 0; i < value.length - 3; i++) {
    const sequence1 = value.substring(i, i + 2);
    const sequence2 = value.substring(i + 2, i + 4);
    
    if (sequence1 === sequence2) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (including shorthand ::)
  // Match IPv6 with more comprehensive patterns
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}|::/g;
  
  // Check if value contains IPv6 pattern
  return ipv6Pattern.test(value);
}
