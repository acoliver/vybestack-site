#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
let filePath: string | null = null;
let format: string | null = null;
let outputPath: string | null = null;
let includeTotals = false;

for (let i = 0; i < args.length; i++) {
  switch (args[i]) {
    case '--format':
      format = args[i + 1];
      i++;
      break;
    case '--output':
      outputPath = args[i + 1];
      i++;
      break;
    case '--includeTotals':
      includeTotals = true;
      break;
    default:
      if (!filePath) {
        filePath = args[i];
      }
      break;
  }
}

// Validate arguments
if (!filePath) {
  console.error('Error: No input file provided');
  process.exit(1);
}

if (!format) {
  console.error('Error: No format specified');
  process.exit(1);
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'`);
  process.exit(1);
}

// Read and parse data file
let data: ReportData;
try {
  const fileContent = readFileSync(filePath, 'utf-8');
  data = JSON.parse(fileContent) as ReportData;
} catch (error) {
  console.error(`Error: Failed to read or parse file '${filePath}'`);
  process.exit(1);
}

// Validate data structure
if (!data.title || !data.summary || !Array.isArray(data.entries)) {
  console.error('Error: Invalid data structure in JSON file');
  process.exit(1);
}

// Validate entries
for (const entry of data.entries) {
  if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
    console.error('Error: Invalid entry structure in JSON file');
    process.exit(1);
  }
}

// Render report
let output: string;
switch (format) {
  case 'markdown':
    output = renderMarkdown(data, { includeTotals });
    break;
  case 'text':
    output = renderText(data, { includeTotals });
    break;
  default:
    console.error(`Error: Unsupported format '${format}'`);
    process.exit(1);
}

// Write output
if (outputPath) {
  try {
    writeFileSync(outputPath, output, 'utf-8');
  } catch (error) {
    console.error(`Error: Failed to write to output file '${outputPath}'`);
    process.exit(1);
  }
} else {
  console.log(output);
}