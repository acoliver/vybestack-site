/**
 * Encode plain text to Base64 using standard alphabet.
 * Returns encoded output with proper padding when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts input with or without padding, and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Normalize input: remove whitespace and handle missing padding
  const normalized = input.replace(/\s/g, '');

  // Validate Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input');
  }

  // Check for reasonable length (must be multiple of 4 when padded)
  if (normalized.length === 0) {
    throw new Error('Empty Base64 input');
  }

  // Add missing padding if necessary
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  const padded = normalized + '='.repeat(paddingNeeded);

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
