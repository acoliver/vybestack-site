import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const page = pageParam ? Number(pageParam) : 1;
    const limit = limitParam ? Number(limitParam) : 5;

    // Check for invalid numeric inputs
    if (Number.isNaN(page) || Number.isNaN(limit)) {
      return res.status(400).json({ error: 'Page and limit must be valid numbers' });
    }

    // Check for negative, zero, or excessive values
    if (page <= 0 || limit <= 0) {
      return res.status(400).json({ error: 'Page and limit must be positive numbers' });
    }

    if (page > 10000 || limit > 1000) {
      return res.status(400).json({ error: 'Page and limit values are too large' });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
