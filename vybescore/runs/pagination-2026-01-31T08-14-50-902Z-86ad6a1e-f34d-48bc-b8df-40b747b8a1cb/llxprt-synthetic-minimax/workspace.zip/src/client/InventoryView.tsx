import React from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = React.useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const handlePrevious = (): void => {
    if (data.page > 1) {
      setCurrentPage(data.page - 1);
    }
  };

  const handleNext = (): void => {
    if (data.hasNext) {
      setCurrentPage(data.page + 1);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      
      <nav>
        <button 
          onClick={handlePrevious}
          disabled={data.page <= 1}
          type="button"
        >
          Previous
        </button>
        <span>Page {data.page} of {Math.ceil(data.total / data.limit) || 1}</span>
        <button 
          onClick={handleNext}
          disabled={!data.hasNext}
          type="button"
        >
          Next
        </button>
      </nav>
    </section>
  );
}
