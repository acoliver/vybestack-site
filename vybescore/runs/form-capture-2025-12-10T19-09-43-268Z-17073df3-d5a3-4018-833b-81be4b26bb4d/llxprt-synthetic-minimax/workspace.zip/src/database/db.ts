import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      let buffer: Uint8Array | undefined;
      
      // Load existing database if it exists
      if (fs.existsSync(this.dbPath)) {
        buffer = fs.readFileSync(this.dbPath);
      }

      // Initialize sql.js
      this.sqlJs = await initSqlJs({
        locateFile: () => {
          return require('sql.js/dist/sql-wasm.wasm');
        }
      });

      if (buffer) {
        this.db = new this.sqlJs.Database(buffer);
      } else {
        this.db = new this.sqlJs.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schemaPath = path.join(process.cwd(), 'data', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      
      // Execute schema statements
      const statements = schema.split(';').filter(stmt => stmt.trim() !== '');
      for (const statement of statements) {
        if (statement.trim()) {
          this.db.exec(statement);
        }
      }
    } catch (error) {
      console.error('Failed to create schema:', error);
      throw error;
    }
  }

  async saveSubmission(formData: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (first_name, last_name, street_address, city, state_province_region, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.bind([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvinceRegion,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      stmt.step();
      stmt.free();

      return this.db.getRowsModified();
    } catch (error) {
      console.error('Failed to save submission:', error);
      throw error;
    }
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        SELECT id, first_name, last_name, street_address, city, state_province_region, postal_code, country, email, phone, created_at
        FROM submissions
        ORDER BY created_at DESC
      `);

      const results: Submission[] = [];
      while (stmt.step()) {
        const row = stmt.getAsObject() as any;
        const submission: Submission = {
          id: row.id,
          first_name: row.first_name,
          last_name: row.last_name,
          street_address: row.street_address,
          city: row.city,
          state_province_region: row.state_province_region,
          postal_code: row.postal_code,
          country: row.country,
          email: row.email,
          phone: row.phone,
          created_at: row.created_at
        };
        results.push(submission);
      }
      stmt.free();

      return results;
    } catch (error) {
      console.error('Failed to get submissions:', error);
      throw error;
    }
  }

  persistToDisk(): void {
    if (!this.db || !this.sqlJs) {
      throw new Error('Database not initialized');
    }

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to persist database to disk:', error);
      throw error;
    }
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();