import express, { Request, Response, NextFunction } from 'express';
import * as path from 'path';
import { dbManager, FormData } from './database/db';

export interface ValidationErrors {
  [key: string]: string;
}

export interface FormRequestBody extends Request {
  body: FormData & {
    [key: string]: string;
  };
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'views'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\+]?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone) && phone.replace(/[\d]/g, '').length >= 3;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (e.g., UK "SW1A 1AA", Argentine "C1000", "B1675")
  const postalRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field checks
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Form',
    errors: {},
    values: {}
  });
});

app.post('/submit', async (req: FormRequestBody, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvinceRegion: req.body.stateProvinceRegion?.trim() || '',
      postalCode: req.body.postalCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone: req.body.phone?.trim() || ''
    };

    const errors = validateFormData(formData);

    if (Object.keys(errors).length > 0) {
      return res.status(400).render('form', {
        title: 'Contact Form',
        errors,
        values: formData
      });
    }

    await dbManager.saveSubmission(formData);
    dbManager.persistToDisk();
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Error:', err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Graceful shutdown...`);
  dbManager.close();
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  startServer();
}

export default app;