/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const normalized = input.replace(/\s/g, '');

  if (normalized.length === 0) {
    return '';
  }

  validateBase64Chars(normalized);
  validatePadding(normalized);
  
  return decodeWithValidation(normalized);
}

function validateBase64Chars(normalized: string): void {
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
}

function validatePadding(normalized: string): void {
  const paddingIndex = normalized.indexOf('=');
  
  if (paddingIndex !== -1) {
    const paddingSection = normalized.slice(paddingIndex);
    
    if (!/^=+$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
    
    if (paddingSection.length > 2) {
      throw new Error('Invalid Base64 input: excessive padding');
    }
  }
}

function decodeWithValidation(normalized: string): string {
  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    if (normalized.length > 0 && !isValidDecoding(normalized, buffer)) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}

function isValidDecoding(input: string, buffer: Buffer): boolean {
  const reEncoded = buffer.toString('base64');
  const inputNoPadding = input.replace(/=+$/, '');
  const reEncodedNoPadding = reEncoded.replace(/=+$/, '');
  
  return inputNoPadding === reEncodedNoPadding || input === reEncoded;
}
