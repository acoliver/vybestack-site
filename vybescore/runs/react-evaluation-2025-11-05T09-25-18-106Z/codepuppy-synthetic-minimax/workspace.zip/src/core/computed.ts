/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create subject for this computed value (to track observers that depend on it)
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Create the computed observer (to track dependencies it depends on)
  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // Track this computed value as the active observer while computing
      const result = updateFn(prevValue)
      // Update subject value and notify dependents if changed
      if (computedSubject.value !== result) {
        computedSubject.value = result
        notifyObservers(computedSubject)
      }
      return result
    },
    disposed: false,
  }
  
  // Initial computation
  updateObserver(computedObserver)
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If this computed value is being accessed by another observer,
    // register that observer as dependent on this computed value
    if (activeObserver && (!('disposed' in activeObserver) || !(activeObserver as { disposed?: boolean }).disposed)) {
      computedSubject.observers.add(activeObserver)
    }
    
    // When accessed by a new observer, make sure dependencies are tracked
    if (activeObserver) {
      // Recompute to track dependencies while this observer is active
      updateObserver(computedObserver)
    }
    
    return computedSubject.value
  }
  
  return getter
}