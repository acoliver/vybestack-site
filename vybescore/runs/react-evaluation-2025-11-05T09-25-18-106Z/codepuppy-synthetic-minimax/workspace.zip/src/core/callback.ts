/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
    disposed: false,
  }
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(callbackObserver)
  
  const unsubscribe: UnsubscribeFn = () => {
    if (callbackObserver.disposed) return
    
    // Mark as disposed to prevent further updates
    callbackObserver.disposed = true
    
    // Remove from all subjects that might be observing this callback
    // Note: In a more complex system we'd track and remove from specific subjects
    
    // Clear references to help with garbage collection
    callbackObserver.value = undefined
    // Keep updateFn as is to avoid breaking any ongoing computations
  }
  
  return unsubscribe
}