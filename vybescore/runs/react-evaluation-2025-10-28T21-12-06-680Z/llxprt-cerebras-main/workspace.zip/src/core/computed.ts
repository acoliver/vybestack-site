/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the boolean case for equal parameter
  const equalFn = typeof equal === 'function' ? equal : 
                 equal === true ? Object.is : 
                 undefined;
                 
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Array to track dependencies
  const dependencies: Observer<unknown>[] = []
  
  // Wrapper function to track dependencies
  const trackedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    // Save the current active observer
    const previousObserver = getActiveObserver()
    
    // Clear previous dependencies
    dependencies.length = 0
    
    try {
      // Set this observer as the active one
      // This will allow any inputs accessed in updateFn to register this observer
      updateObserver(o)
      
      // Run the update function
      return updateFn(prevValue)
    } finally {
      // Restore previous observer
      updateObserver(previousObserver as Observer<unknown>)
    }
  }
  
  // Update the observer with the tracked update function
  o.updateFn = trackedUpdateFn
  
  // Run the initial computation
  updateObserver(o)
  
  // Return a getter function that returns the computed value
  return (): T => {
    // Register dependencies when this computed value is accessed
    const observer = getActiveObserver()
    if (observer) {
      dependencies.push(observer)
    }
    
    return o.value!
  }
}