/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary regex for the prefix
  const wordBoundaryRegex = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(wordBoundaryRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const results = matches.filter(word => {
    const wordLower = word.toLowerCase();
    return !exceptions.some(exception => 
      wordLower === exception.toLowerCase()
    );
  });
  
  // Remove duplicates and return unique words
  return [...new Set(results)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use regex to find token preceded by a digit
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Match digit followed by the token (global, case insensitive)
  const pattern = `(\\d${escapedToken})`;
  const regex = new RegExp(pattern, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[1]); // Add the full match (digit + token)
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // This regex looks for any pattern that repeats immediately
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (various formats including shorthand ::)
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with shorthand :: (can appear at beginning, middle, or end)
  // Pattern accounts for :: representing one or more groups of zeros
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 starting with ::
  const startsWithShorthand = /\b::[0-9a-fA-F:.]*\b/;
  
  // IPv6 ending with ::
  const endsWithShorthand = /\b[0-9a-fA-F:.]*::\b/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4 = /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:)?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Check for any of the IPv6 patterns
  const hasIPv6 = fullIPv6.test(value) || shorthandIPv6.test(value) || 
                  startsWithShorthand.test(value) || endsWithShorthand.test(value) ||
                  ipv6WithIPv4.test(value);
  
  return hasIPv6;
}