/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text) {
    // First, normalize spaces: collapse multiple spaces into single spaces
    const normalized = text.replace(/\s+/g, ' ');
    // Pattern to find sentence boundaries and capitalize first letter after sentence ending
    // Matches: . ? ! followed by optional spaces, then a lowercase letter
    return normalized.replace(/([.!?])\s*([a-z])/g, (match, punctuation, letter) => {
        return punctuation + ' ' + letter.toUpperCase();
    }).replace(/^([a-z])/, (match, letter) => {
        // Capitalize first letter of the string if it's lowercase
        return letter.toUpperCase();
    });
}
/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text) {
    // Match URLs starting with http:// or https://
    const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,!?;:')]/gi;
    return text.match(urlRegex) || [];
}
/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text) {
    return text.replace(/http:\/\//g, 'https://');
}
/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text) {
    // Use regex literal to match http URLs - escape slashes to avoid linting issues
    const httpUrlPattern = String.raw `http:\/\/([^\/\s]+)(\/[^\s]*)`;
    const httpUrlRegex = new RegExp(httpUrlPattern, 'g');
    return text.replace(httpUrlRegex, (match, host, path) => {
        // Always upgrade to https
        let newUrl = 'https://' + host + path;
        // Check if path begins with /docs/
        if (path.startsWith('/docs/')) {
            // Check for dynamic hints in the path
            const hasDynamicHints = /(cgi-bin|\?.*=|&.*=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
            if (!hasDynamicHints) {
                // Rewrite host to docs.hostname
                const docsHost = 'docs.' + host;
                newUrl = 'https://' + docsHost + path;
            }
        }
        return newUrl;
    });
}
/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value) {
    // Match mm/dd/yyyy format with valid month (01-12), day (01-31), and year (1000-9999)
    const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/([1-9]\d{3})$/;
    const match = value.match(dateRegex);
    if (!match) {
        return 'N/A';
    }
    // Extract year and validate it's a 4-digit year
    const year = match[3];
    if (year.length !== 4 || year[0] === '0') {
        return 'N/A';
    }
    return year;
}
