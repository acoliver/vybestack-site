export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for valid length (11 digits with +1, 10 digits without)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Check area code doesn't start with 0 or 1
    const areaCode = digits.substring(1, 4);
    return areaCode[0] !== '0' && areaCode[0] !== '1';
  } else if (digits.length === 10) {
    // Check area code doesn't start with 0 or 1
    const areaCode = digits.substring(0, 3);
    return areaCode[0] !== '0' && areaCode[0] !== '1';
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for easier parsing
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern: ^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$
  // Groups:
  // 1. Optional country code +54
  // 2. Optional trunk prefix 0
  // 3. Optional mobile indicator 9
  // 4. Area code (2-4 digits, first digit 1-9)
  // 5. Subscriber number (6-8 digits)
  
  const argentinaPhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(argentinaPhoneRegex);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // When country code is omitted, must start with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and special symbols like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  return hasLetter;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  // Check length and format
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check major card type prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const cardType = 
    (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) ||
    ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
      digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16) ||
    ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15);
  
  if (!cardType) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digits);
}
