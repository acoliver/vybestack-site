declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, params?: any[]): void;
    prepare(sql: string): Statement;
    get(sql: string, params?: any[]): any;
    export(): Uint8Array;
    close(): void;
  }

  export class Statement {
    run(params?: any[]): void;
    get(params?: any[]): any;
    getAsObject(params?: any[]): any | any[];
    free(): void;
  }
}