import { FormData, FormErrors } from './types';

export function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};
  
  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    const value = data[field as keyof FormData]?.trim();
    if (!value) {
      errors[field] = [`${getFieldLabel(field)} is required`];
    }
  });
  
  // Email validation
  if (data.email?.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.email = errors.email || [];
      errors.email.push('Please enter a valid email address');
    }
  }
  
  // Phone validation (international format)
  if (data.phone?.trim()) {
    const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.phone = errors.phone || [];
      errors.phone.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
    }
  }
  
  // Postal code validation (alphanumeric)
  if (data.postalCode?.trim()) {
    const postalRegex = /^[a-z0-9\s-]+$/i;
    if (!postalRegex.test(data.postalCode.trim())) {
      errors.postalCode = errors.postalCode || [];
      errors.postalCode.push('Postal code can only contain letters, numbers, spaces, and hyphens');
    }
  }
  
  return errors;
}

function getFieldLabel(field: string): string {
  const labels: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State / Province / Region',
    postalCode: 'Postal / Zip code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone number'
  };
  
  return labels[field] || field;
}

export function hasErrors(errors: FormErrors): boolean {
  return Object.keys(errors).length > 0;
}

export function getErrorMessages(errors: FormErrors): string[] {
  return Object.values(errors).flat() as string[];
}