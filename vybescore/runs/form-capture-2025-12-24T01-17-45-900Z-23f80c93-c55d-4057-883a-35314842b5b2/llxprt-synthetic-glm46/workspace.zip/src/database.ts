import { readFile, writeFile } from 'fs/promises';
import { join } from 'path';
import Database from 'sql.js';
import { FormData, SubmissionRow } from './types';

export class DatabaseManager {
  private db: Database.Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      let dbBuffer: Uint8Array;
      
      try {
        const data = await readFile(this.dbPath);
        dbBuffer = new Uint8Array(data);
      } catch (error) {
        const SQL = await import('sql.js');
        const db = new SQL.Database();
        
        const schemaSql = await this.getSchema();
        db.run(schemaSql);
        
        dbBuffer = db.export();
        
        await this.ensureDataDirectory();
        await writeFile(this.dbPath, Buffer.from(dbBuffer));
      }

      const SQL = await import('sql.js');
      this.db = new SQL.Database(dbBuffer);
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async getSchema(): Promise<string> {
    const fs = await import('fs/promises');
    const schemaPath = join(process.cwd(), 'db', 'schema.sql');
    return await fs.readFile(schemaPath, 'utf8');
  }

  private async ensureDataDirectory(): Promise<void> {
    const fs = await import('fs/promises');
    const dataDir = join(process.cwd(), 'data');
    
    try {
      await fs.access(dataDir);
    } catch {
      await fs.mkdir(dataDir, { recursive: true });
    }
  }

  async insertSubmission(formData: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      const result = this.db.get('SELECT last_insert_rowid() as id') as { id: number };
      return result.id;
    } finally {
      stmt.free();
    }
  }

  async getSubmissions(): Promise<SubmissionRow[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
    try {
      const result = stmt.getAsObject([]) as SubmissionRow[];
      return Array.isArray(result) ? result : [result];
    } finally {
      stmt.free();
    }
  }

  async exportDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const dbBuffer = this.db.export();
      await writeFile(this.dbPath, Buffer.from(dbBuffer));
    } catch (error) {
      console.error('Failed to export database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.exportDatabase();
      this.db.close();
      this.db = null;
    }
  }
}