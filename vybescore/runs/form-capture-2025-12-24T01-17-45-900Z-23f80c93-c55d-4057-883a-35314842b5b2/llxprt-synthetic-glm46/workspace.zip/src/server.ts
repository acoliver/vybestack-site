import express from 'express';
import { join } from 'path';
import { DatabaseManager } from './database';
import { validateForm, hasErrors, getErrorMessages } from './validation';
import { FormData } from './types';

const app = express();
const PORT = process.env.PORT || 3535;
const db = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(join(process.cwd(), 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', join(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);
    
    if (hasErrors(errors)) {
      res.status(400).render('form', {
        errors: getErrorMessages(errors),
        values: formData
      });
      return;
    }

    await db.insertSubmission(formData);
    await db.exportDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    firstName: 'Friend'
  });
});

// Graceful shutdown
let server: express.Application | null = null;

async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`
${signal} received. Shutting down gracefully...`);
  
  if (server) {
    server.close(async () => {
      console.log('HTTP server closed.');
      try {
        await db.close();
        console.log('Database closed successfully.');
        process.exit(0);
      } catch (error) {
        console.error('Error closing database:', error);
        process.exit(1);
      }
    });
  } else {
    process.exit(0);
  }
}

// Start server
async function startServer(): Promise<void> {
  try {
    await db.initialize();
    console.log('Database initialized successfully.');
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to view the application`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
