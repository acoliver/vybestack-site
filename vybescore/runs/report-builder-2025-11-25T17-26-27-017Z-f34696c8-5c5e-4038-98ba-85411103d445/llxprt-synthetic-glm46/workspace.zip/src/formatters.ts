import type { ReportData, RenderOptions } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

export type Renderer = (data: ReportData, options: RenderOptions) => string;
export type RenderFormat = 'markdown' | 'text';

export const RENDERERS: Record<RenderFormat, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export function getRenderer(format: RenderFormat): Renderer {
  const renderer = RENDERERS[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}

export function validateFormat(format: unknown): RenderFormat {
  if (typeof format === 'string' && format in RENDERERS) {
    return format as RenderFormat;
  }
  throw new Error(`Unsupported format: ${format}`);
}