#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import type { ReportData } from '../types.js';
import { getRenderer, validateFormat, type RenderFormat } from '../formatters.js';

interface CliOptions {
  format: RenderFormat;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): { dataPath: string; options: CliOptions } {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  let format: RenderFormat | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format' && i + 1 < args.length) {
      format = validateFormat(args[i + 1]);
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('Missing required argument: --format <format>');
  }

  return { dataPath, options: { format, output, includeTotals } };
}

function loadReportData(dataPath: string): ReportData {
  const resolvedPath = path.resolve(dataPath);
  try {
    const data = fs.readFileSync(resolvedPath, 'utf-8');
    const reportData = JSON.parse(data) as unknown;

    // Validate the report data structure
    if (
      typeof reportData !== 'object' ||
      reportData === null ||
      !('title' in reportData) ||
      !('summary' in reportData) ||
      !('entries' in reportData)
    ) {
      throw new Error('Invalid report data: missing required fields');
    }

    const dataObject = reportData as Record<string, unknown>;
    if (typeof dataObject.title !== 'string') {
      throw new Error('Invalid report data: title must be a string');
    }
    if (typeof dataObject.summary !== 'string') {
      throw new Error('Invalid report data: summary must be a string');
    }
    if (!Array.isArray(dataObject.entries)) {
      throw new Error('Invalid report data: entries must be an array');
    }

    for (const entry of dataObject.entries) {
      if (
        typeof entry !== 'object' ||
        entry === null ||
        !('label' in entry) ||
        !('amount' in entry) ||
        typeof entry.label !== 'string' ||
        typeof entry.amount !== 'number'
      ) {
        throw new Error('Invalid report data: each entry must have label (string) and amount (number)');
      }
    }

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${dataPath}`);
    }
    if (error instanceof Error) {
      throw error;
    }
    throw new Error(`Unknown error reading file: ${dataPath}`);
  }
}

function main() {
  try {
    const { dataPath, options } = parseArgs(process.argv.slice(2));
    const reportData = loadReportData(dataPath);
    const render = getRenderer(options.format);
    const output = render(reportData, { includeTotals: options.includeTotals });

    if (options.output) {
      fs.writeFileSync(path.resolve(options.output), output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

main();
