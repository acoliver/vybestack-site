/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create equality function
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal 
    : _equal === true ? (a: T, b: T) => a === b 
    : undefined
    
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // If this is a callback being executed to track dependencies, 
      // add it to the observers list
      s.observers.add(observer as Observer<unknown>)
      s.observer = observer
    }
    
    // Also check if we're in callback mode and a callback observer needs to be registered
    const gt = globalThis as unknown as Record<string, unknown>
    if (gt._callbackObserver && observer !== gt._callbackObserver) {
      // A callback is currently executing and accessing this value
      const callbackObserver = gt._callbackObserver as Observer<unknown>
      s.observers.add(callbackObserver)
    }
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function if provided
    let hasChanged = true
    if (equalFn) {
      hasChanged = !equalFn(s.value, nextValue)
    }

    if (hasChanged) {
      s.value = nextValue
      
      // Create a copy of observers to avoid issues with observers being removed/added during notification
      const currentObservers = Array.from(s.observers)
      
      // Notify all registered observers immediately
      for (const observer of currentObservers) {
        updateObserver(observer)
      }
    }
    
    return s.value
  }

  return [read, write]
}
