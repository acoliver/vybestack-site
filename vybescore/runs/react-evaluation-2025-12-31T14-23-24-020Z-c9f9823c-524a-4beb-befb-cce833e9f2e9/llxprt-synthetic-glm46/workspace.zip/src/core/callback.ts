/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Immediately register callback for side effects
  const currentActiveObserver = getActiveObserver()
  if (currentActiveObserver) {
    // If in an active observer context, execute once to register dependencies
    observer.value = updateFn(observer.value)
  }
  
  // Override updateObserver to track when this function is called as a callback
  const originalUpdateObserver = updateObserver
  
  // We need a more comprehensive approach to track which subjects we depend on
  // Let's set a global flag during callback execution to capture dependencies
  const gt = globalThis as unknown as Record<string, unknown>
  const originalCallbackObserver = gt._callbackObserver
  gt._callbackObserver = observer
  
  // Register the callback
  originalUpdateObserver(observer)
  
  // Restore original
  gt._callbackObserver = originalCallbackObserver
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer reference to stop further updates
    observer.value = undefined
    // Replace updateFn with a no-op to prevent further execution
    observer.updateFn = () => value!
  }
}
