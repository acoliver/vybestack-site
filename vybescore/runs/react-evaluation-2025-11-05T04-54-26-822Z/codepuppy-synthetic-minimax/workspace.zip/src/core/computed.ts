/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Computed,
  Subject,
  updateObserver,
  getActiveObserver,
  notifyObservers,
  registerObserverDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  options?: { name?: string }
): GetterFn<T> {
  const computed: Computed<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Initial computation to establish dependencies
  updateObserver(computed)
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Register the current observer as dependent on this computed value
      registerObserverDependency(computed as Subject<unknown>, currentObserver)
    }
    
    // Return the current computed value
    return computed.value!
  }
  
  // Override the update function to notify observers when value changes
  const originalUpdateFn = updateFn
  computed.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    const changed = newValue !== computed.value
    computed.value = newValue
    
    // If value changed, notify all observers of this computed value
    if (changed) {
      notifyObservers(computed.observers)
    }
    
    return newValue
  }
  
  return getter
}