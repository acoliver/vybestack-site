import { ReportData, FormatOptions } from '../types.js';

export function formatText(data: ReportData, options: FormatOptions): string {
  const lines: string[] = [];
  
  // Add title
  lines.push(data.title);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries section
  lines.push('Entries:');
  
  // Add each entry
  for (const entry of data.entries) {
    const amountFormatted = `$${entry.amount.toFixed(2)}`;
    lines.push(`- ${entry.label}: ${amountFormatted}`);
  }
  
  // Add total if requested
  if (options.includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = `$${total.toFixed(2)}`;
    lines.push(`Total: ${totalFormatted}`);
  }
  
  return lines.join('\n');
}