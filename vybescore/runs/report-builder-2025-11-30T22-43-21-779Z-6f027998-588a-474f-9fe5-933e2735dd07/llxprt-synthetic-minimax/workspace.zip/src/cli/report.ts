import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Skip node and script name
  const inputArgs = argv.slice(2);

  let i = 0;
  while (i < inputArgs.length) {
    const arg = inputArgs[i];

    if (arg === '--format') {
      if (i + 1 >= inputArgs.length) {
        throw new Error('Missing value for --format');
      }
      args.format = inputArgs[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= inputArgs.length) {
        throw new Error('Missing value for --output');
      }
      args.output = inputArgs[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
      i += 1;
    } else if (!arg.startsWith('--')) {
      // This should be the data file
      args.dataFile = arg;
      i += 1;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  // Validate required arguments
  if (!args.dataFile) {
    throw new Error('Missing data file argument');
  }
  if (!args.format) {
    throw new Error('Missing --format option');
  }

  return args;
}

function validateAndParseData(jsonContent: string): ReportData {
  try {
    const data = JSON.parse(jsonContent);

    // Validate required fields
    if (typeof data.title !== 'string' || data.title.trim() === '') {
      throw new Error('Invalid or missing "title" field');
    }
    if (typeof data.summary !== 'string' || data.summary.trim() === '') {
      throw new Error('Invalid or missing "summary" field');
    }
    if (!Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Invalid or missing "entries" field');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string' || entry.label.trim() === '') {
        throw new Error(`Invalid or missing "label" in entry ${i + 1}`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid or missing "amount" in entry ${i + 1}`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON format');
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  const options = { includeTotals };

  switch (format) {
    case 'markdown':
      return formatMarkdown(data, options);
    case 'text':
      return formatText(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Read and parse data file
    const jsonContent = readFileSync(args.dataFile, 'utf-8');
    const data = validateAndParseData(jsonContent);

    // Render report
    const report = renderReport(data, args.format, args.includeTotals);

    // Output result
    if (args.output) {
      writeFileSync(args.output, report, 'utf-8');
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();