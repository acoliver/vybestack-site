// Create a simplified computed function to test the expected behavior
function createComputed(updateFn, value) {
  return () => {
    // Call with undefined first to use the default parameter
    return updateFn(undefined);
  }
}

const computed = createComputed((x = 3) => x * 2)
console.log(computed()) // Should print 6