/**
 * Simplified computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  Subject,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Parse the equal parameter (not used for now, but kept for future optimization)
  const unusedEqualFn: EqualFn<T> | undefined = _equal === true
    ? (a: T, b: T) => a === b
    : _equal === false
      ? undefined
      : typeof _equal === 'function'
        ? _equal
        : undefined
  
  const dependencies: Subject<unknown>[] = []
  
  // Track when this computed value needs to be refreshed
  let needsRefresh = true
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter = (): T => {
    // If we're already being computed, return the cached value
    const active = getActiveObserver()
    if (active === o) {
      return o.value!
    }
    
    // If we don't need to refresh, return the cached value
    if (!needsRefresh && o.value !== undefined) {
      // Still track dependencies for potential future updates
      for (const dep of dependencies) {
        const observer = getActiveObserver()
        if (observer) {
          // Link this subject to the current observer
          dep.observer = observer
        }
      }
      return o.value
    }
    
    // Set this observer as the active one to track dependencies
    const previous = getActiveObserver()
    
    // Manually set the active observer
    setActiveObserver(o)
    
    // Clear previous dependencies to track fresh dependencies
    dependencies.length = 0
    
    try {
      // Execute the update function to calculate the current value
      o.value = updateFn(o.value)
      needsRefresh = false
      return o.value!
    } finally {
      // Restore the previous observer
      setActiveObserver(previous)
    }
  }
  
  // Initialize the computed value if we have an initial value
  if (value !== undefined) {
    needsRefresh = false
  } else {
    o.value = updateFn()
    needsRefresh = false
  }
  
  return getter
}