/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Parse the equal parameter (not used for now, but kept for future optimization)
  const unusedEqualFn: EqualFn<T> | undefined = _equal === true
    ? (a: T, b: T) => a === b
    : _equal === false
      ? undefined
      : typeof _equal === 'function'
        ? _equal
        : undefined
  
  // Current computed value, initialize to provided value or undefined
  let currentValue: T | undefined = value
  
  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn,
  }
  
  const getter = (): T => {
    // If we're already being computed, return the cached value
    const active = getActiveObserver()
    if (active === o) {
      return currentValue!
    }
    
    // Clear previous dependencies to track fresh dependencies
    
    // Set this observer as active to track dependencies
    const previous = getActiveObserver()
    setActiveObserver(o)
    
    try {
      // Execute the update function to calculate the current value
      // Use undefined on first call to trigger default parameter
      const result = currentValue === undefined ? updateFn(undefined) : updateFn(currentValue)
      currentValue = result
      return result
    } finally {
      // Restore the previous observer
      setActiveObserver(previous)
    }
  }
  
  // No initialization here - value will be computed on first access
  
  return getter
}
