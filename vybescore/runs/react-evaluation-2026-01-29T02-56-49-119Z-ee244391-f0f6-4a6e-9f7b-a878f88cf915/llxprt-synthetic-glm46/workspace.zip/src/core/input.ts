/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Parse the equal parameter
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    // Use default equality
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    // No equality checking
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    // Custom equality function
    equalFn = _equal
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Link this subject to the current observer
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value actually changed
    const hasChanged = s.equalFn ? !s.equalFn(s.value, nextValue) : s.value !== nextValue
    
    if (hasChanged) {
      s.value = nextValue
      // Notify the observer that this subject changed
      if (s.observer) {
        updateObserver(s.observer as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}
