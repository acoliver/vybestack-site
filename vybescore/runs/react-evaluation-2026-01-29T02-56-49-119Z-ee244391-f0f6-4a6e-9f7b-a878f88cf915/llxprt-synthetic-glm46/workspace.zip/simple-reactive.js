// Simplified reactive dependency test focusing on the core issue

let currentObserver = null

function createInput(initialValue) {
  let value = initialValue
  const observers = new Set()
  
  const getter = () => {
    console.log('Reading input value')
    if (currentObserver) {
      console.log('Tracking dependency')
      observers.add(currentObserver)
    }
    return value
  }
  
  const setter = (newValue) => {
    console.log(`Setting input from ${value} to ${newValue}`)
    if (value !== newValue) {
      value = newValue
      console.log('Notifying observers:', observers.size)
      // Notify all observers
      for (const observer of observers) {
        console.log('Notifying observer')
        observer()
      }
    }
    return value
  }
  
  return [getter, setter]
}

function createComputed(fn) {
  let cachedValue = undefined
  let needsRecompute = true
  
  function computeValue() {
    console.log('Computing value')
    // Set up to track dependencies
    const previousObserver = currentObserver
    currentObserver = computeValue
    
    try {
      cachedValue = fn()
      needsRecompute = false
      console.log('Computed value:', cachedValue)
      return cachedValue
    } finally {
      currentObserver = previousObserver
    }
  }
  
  return computeValue
}

function createCallback(fn) {
  function callback() {
    console.log('Callback executed')
    fn()
  }
  
  return callback
}

// Test the functionality
const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('Computing output = input + 1')
  return input() + 1
})

let value = 0
const callback = createCallback(() => {
  console.log('Setting value = output()')
  value = output()
})

// Establish dependency chain
console.log('=== SETTING UP DEPENDENCIES ===')
output() // Track output -> input dependency
callback() // Set callback as dependent on output

console.log('\n=== TRIGGERING UPDATE ===')
setInput(3) // Should trigger callback -> output -> input chain

console.log('\n=== FINAL VALUES ===')
console.log(`value: ${value}`)
console.log(`output: ${output()}`)
console.log(`input: ${input()}`)