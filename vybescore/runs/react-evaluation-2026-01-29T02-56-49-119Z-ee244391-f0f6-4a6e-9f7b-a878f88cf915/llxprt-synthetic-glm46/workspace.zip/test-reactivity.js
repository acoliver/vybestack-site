// Simple test to understand the reactive dependency pattern

let currentObserver = null

function createInput(initialValue) {
  let value = initialValue
  const observers = new Set()
  
  const getter = () => {
    if (currentObserver) {
      observers.add(currentObserver)
    }
    return value
  }
  
  const setter = (newValue) => {
    if (value !== newValue) {
      value = newValue
      // Notify all observers
      for (const observer of observers) {
        observer()
      }
    }
    return value
  }
  
  return [getter, setter]
}

function createComputed(fn) {
  let cachedValue = undefined
  let needsRecompute = true
  const dependencies = new Set()
  
  const computed = () => {
    if (!needsRecompute) {
      return cachedValue
    }
    
    // Set up to track dependencies
    const previousObserver = currentObserver
    currentObserver = computed
    
    try {
      // Clear previous dependencies
      for (const dep of dependencies) {
        dep.observers.delete(computed)
      }
      dependencies.clear()
      
      // Compute the value
      cachedValue = fn()
      needsRecompute = false
      return cachedValue
    } finally {
      currentObserver = previousObserver
    }
  }
  
  computed.invalidate = () => {
    needsRecompute = true
  }
  
  // Add this computed to dependencies when they are accessed
  const originalGetter = computed
  computed = () => {
    const result = originalGetter()
    return result
  }
  
  return computed
}

function createCallback(fn) {
  const callback = () => {
    const previousObserver = currentObserver
    currentObserver = callback
    try {
      fn()
    } finally {
      currentObserver = previousObserver
    }
  }
  
  return callback
}

// Manual tracking of dependencies
function trackDependency(getter, observer) {
  if (!getter._observers) getter._observers = new Set()
  getter._observers.add(observer)
}

// Test the functionality
const [input, setInput] = createInput(1)

const output = createComputed(() => input() + 1)

let value = 0
const callback = createCallback(() => (value = output()))

// Force dependency tracking
currentObserver = callback
output()
currentObserver = null

setInput(3) // Should trigger callback, setting value to 4

console.log(`value: ${value}`)
console.log(`output: ${output()}`)