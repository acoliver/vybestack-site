/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create regex to find words starting with the prefix
  // \b ensures we match whole words only
  // \w+ matches one or more word characters (letters, digits, underscore)
  const wordPattern = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'gi');

  // Find all matches
  const matches = text.match(wordPattern) || [];

  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );

  // Return unique matches (preserving order of first occurrence)
  const uniqueWords: string[] = [];
  const seen = new Set<string>();

  filteredMatches.forEach(word => {
    if (!seen.has(word.toLowerCase())) {
      uniqueWords.push(word);
      seen.add(word.toLowerCase());
    }
  });

  return uniqueWords;
}

/**
 * TODO: Find occurrences of token that appear after a digit but not at string start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Simple approach: look for digit followed by token
  // Make it robust without using lookbehind
  const pattern = new RegExp('\\d' + escapedToken, 'gi');
  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., "abab", "1212", etc.)
  // Look for any sequence of 2+ characters repeated immediately
  if (/(.{2,})\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses while excluding IPv4.
 */
export function containsIPv6(value: string): boolean {
  // More comprehensive IPv4 pattern to exclude
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  // Check if this is a pure IPv4 address
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 regex patterns (including shorthand)
  // Full IPv6 pattern: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed IPv6 with :: 
  const compressedWithDoubleColon = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.0.2.128)
  const embeddedIPv4 = /(?:[0-9a-fA-F]{1,4}:)*:(?:[0-9]{1,3}\.){3}[0-9]{1,3}/;
  
  // Check for IPv6 anywhere in the string
  const hasIPv6 = fullIPv6.test(value) || 
                 compressedWithDoubleColon.test(value) || 
                 embeddedIPv4.test(value);

  return hasIPv6;
}