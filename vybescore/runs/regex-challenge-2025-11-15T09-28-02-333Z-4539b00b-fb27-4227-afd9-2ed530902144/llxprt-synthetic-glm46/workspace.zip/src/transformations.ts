/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // First, collapse multiple spaces to single spaces, except after sentence enders
  let result = text.replace(/  +/g, ' ');

  // Ensure there's exactly one space after sentence enders (.?!) when there's text
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');

  // Split into sentences by sentence enders followed by whitespace
  const sentences = result.split(/([.!?]\s*)/);

  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    if (sentence && sentence.trim().length > 0) {
      // Capitalize the first letter of the sentence
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
  }

  // Join back together
  return sentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that captures http, https, and www URLs
  // This pattern matches common URL formats including subdomains, ports, query strings
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*(?:\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])*(?:\.[a-zA-Z]{2,})(?::\d+)?(?:\/[^\s)]*)?/g;

  const matches = text.match(urlPattern) || [];

  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but leave https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: For example.com URLs (and similar), rewrite docs to docs.example.com while upgrading scheme.
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com and similar patterns
  // Capture the domain to reconstruct as docs.domain.com
  // Only apply the rewrite when path starts with /docs/
  // Skip if the path contains dynamic hints (cgi-bin, query strings, certain extensions)

  return text.replace(
    /http:\/\/([a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])*(?:\.[a-zA-Z]{2,}))(\/docs\/[^\s?]*)\b(?!(?:.*\?(?=.*(&|=))|(?:.*\.(?:jsp|php|asp|aspx|do|cgi|pl|py))))/g,
    'https://docs.$1$2'
  ).replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Extract a four-digit year from mm/dd/yyyy format, or N/A if no match.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;

  const match = value.match(datePattern);
  if (match) {
    return match[3]; // Return the year group
  }

  return 'N/A';
}