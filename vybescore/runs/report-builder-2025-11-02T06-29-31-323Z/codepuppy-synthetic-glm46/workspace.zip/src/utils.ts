import { ReportData } from './types.js';

/**
 * Validates and parses report data from JSON string
 */
export function parseReportData(jsonString: string): ReportData {
  let parsed: unknown;
  
  try {
    parsed = JSON.parse(jsonString);
  } catch (error) {
    throw new Error('Invalid JSON: Unable to parse input file');
  }

  // Basic type validation
  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('Invalid data: Expected JSON object');
  }

  const data = parsed as Record<string, unknown>;

  // Validate required fields
  if (typeof data.title !== 'string') {
    throw new Error('Invalid data: Missing or invalid "title" field (expected string)');
  }

  if (typeof data.summary !== 'string') {
    throw new Error('Invalid data: Missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(data.entries)) {
    throw new Error('Invalid data: Missing or invalid "entries" field (expected array)');
  }

  // Validate entries
  const entries = data.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: Entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: Entry ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: Entry ${i} missing or invalid "amount" field (expected number)`);
    }
  }

  // Return validated data
  return {
    title: data.title,
    summary: data.summary,
    entries: entries as ReportData['entries']
  };
}

/**
 * Parses command line arguments
 */
export interface CLIParsedArgs {
  inputFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

export function parseCLIArgs(args: string[]): CLIParsedArgs {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Error: --format requires a value');
      }
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error('Unsupported format: must be markdown or text');
      }
      format = formatValue;
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Error: --output requires a path');
      }
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Error: Unknown argument ${arg}`);
    }
  }

  if (!format) {
    throw new Error('Error: --format is required');
  }

  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}