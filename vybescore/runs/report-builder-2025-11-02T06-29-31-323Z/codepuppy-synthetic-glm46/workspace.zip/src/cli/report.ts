#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs';
import { resolve } from 'node:path';

import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseReportData, parseCLIArgs } from '../utils.js';

/**
 * Main CLI entry point
 */
async function main(): Promise<void> {
  try {
    // Parse command line arguments (skip first two: node and script path)
    const args = process.argv.slice(2);
    const { inputFile, format, outputPath, includeTotals } = parseCLIArgs(args);

    // Read and parse the input file
    const filePath = resolve(inputFile);
    const fileContent = await new Promise<string>((resolve, reject) => {
      readFile(filePath, 'utf8', (err, data) => {
        if (err) {
          reject(new Error(`Error reading file ${inputFile}: ${err.message}`));
        } else {
          resolve(data);
        }
      });
    });

    // Parse and validate the JSON data
    const reportData = parseReportData(fileContent);

    // Render the report in the requested format
    const options = { includeTotals };
    let output: string;

    switch (format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        // This should never happen due to validation in parseCLIArgs
        throw new Error('Unsupported format');
    }

    // Write output
    if (outputPath) {
      const outputFilePath = resolve(outputPath);
      await new Promise<void>((resolve, reject) => {
        writeFile(outputFilePath, output, 'utf8', (err) => {
          if (err) {
            reject(new Error(`Error writing to file ${outputPath}: ${err.message}`));
          } else {
            resolve();
          }
        });
      });
    } else {
      // Write to stdout
      process.stdout.write(output);
    }

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error(errorMessage);
    process.exit(1);
  }
}

// Run the main function
main();