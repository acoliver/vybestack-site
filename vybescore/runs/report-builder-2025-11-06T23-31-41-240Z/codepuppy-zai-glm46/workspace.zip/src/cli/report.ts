#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArgs(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Find format argument
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next argument
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

/**
 * Validate the report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: label is required and must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: amount is required and must be a number`);
    }
  }
  
  return data as ReportData;
}

/**
 * Main CLI execution
 */
function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs();
    
    // Validate format
    if (format !== 'markdown' && format !== 'text') {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Read and parse JSON
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(dataPath, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Invalid JSON in file ${dataPath}: ${error.message}`);
      } else {
        console.error(`Error reading file ${dataPath}: ${(error as Error).message}`);
      }
      process.exit(1);
    }
    
    // Validate data structure
    const reportData = validateReportData(jsonData);
    
    // Generate report
    let output: string;
    if (format === 'markdown') {
      output = renderMarkdown(reportData, includeTotals);
    } else {
      output = renderText(reportData, includeTotals);
    }
    
    // Output to file or stdout
    if (outputPath) {
      writeFile(outputPath, output, 'utf-8')
        .then(() => {
          console.log(`Report written to ${outputPath}`);
        })
        .catch((error) => {
          console.error(`Error writing to file ${outputPath}: ${error.message}`);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

// Run the CLI
main();