/**
 * Report entry representing a single line item
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Common interface for all formatters
 */
export interface ReportFormatter {
  format(data: ReportData, includeTotals: boolean): string;
}

/**
 * CLI options interface
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}