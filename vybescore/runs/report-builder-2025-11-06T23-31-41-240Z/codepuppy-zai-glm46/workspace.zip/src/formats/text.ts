import type { ReportData, ReportFormatter } from '../types.js';

/**
 * Text formatter for reports
 */
export class TextFormatter implements ReportFormatter {
  format(data: ReportData, includeTotals: boolean): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('Entries:');
    
    // Add each entry
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
    }
    
    // Add totals if requested
    if (includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`Total: $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
}

/**
 * Convenience function to render text
 */
export function renderText(data: ReportData, includeTotals: boolean): string {
  const formatter = new TextFormatter();
  return formatter.format(data, includeTotals);
}