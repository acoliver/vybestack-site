/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix (word boundaries)
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => lowerMatch === exception.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match the full token that appears after a digit
  // This finds sequences like "1foo", "2bar", etc.
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  return text.match(pattern) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab"
  // This regex looks for 2 characters repeated with no characters in between
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/gi;
  
  // Compressed IPv6: Uses :: to represent multiple zero groups
  // Handle cases like ::, ::1, 2001::, ::ffff, etc.
  const compressedIPv6 = /\b(?:[a-f0-9]{0,4}:){0,7}:(?::[a-f0-9]{1,4}){0,7}\b/gi;
  
  // IPv4-mapped IPv6: ::ffff: followed by IPv4 address
  const ipv4MappedIPv6 = /::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/gi;
  
  // Check for any IPv6 pattern
  const hasFullIPv6 = fullIPv6.test(value);
  const hasCompressedIPv6 = compressedIPv6.test(value);
  const hasIPv4Mapped = ipv4MappedIPv6.test(value);
  
  // Also need to check if the value itself is IPv6 (not just contains it)
  // This is to exclude IPv4 addresses that might match some patterns
  const trimmedValue = value.trim();
  
  // If it's clearly an IPv4 address, don't match
  const isIPv4 = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/.test(trimmedValue);
  if (isIPv4) return false;
  
  return hasFullIPv6 || hasCompressedIPv6 || hasIPv4Mapped;
}
