/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Trim the text first
  let result = text.trim();
  
  if (!result) return result;
  
  // Capitalize first letter of the text
  result = result.replace(/^([a-z])/, (_, letter) => letter.toUpperCase());
  
  // Pattern to find sentence endings and capitalize following letters
  // Use negative lookbehind to avoid common abbreviations like "Mr.", "Dr.", etc.
  const sentencePattern = /(?<!\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|vs|etc|e\.g|i\.e))([.!?])(\s*)([a-z])/g;
  
  result = result.replace(sentencePattern, (match, punct, space, letter) => {
    return punct + space + letter.toUpperCase();
  });
  
  // Ensure exactly one space after sentence endings
  result = result.replace(/([.!?])\s{2,}/g, '$1 ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern to match common URL formats
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"{}|\\^`\[\]()]*[a-zA-Z0-9\/]/g;

  const urls = text.match(urlPattern) || [];

  // Clean up trailing punctuation from URLs
  return urls.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlPattern = /http:\/\/([^\/\s]+)([^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, domain, path) => {
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    const hasDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    let newUrl = 'https://';
    
    if (hasDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.domain
      newUrl += `docs.${domain}`;
    } else {
      // Keep original domain
      newUrl += domain;
    }
    
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // For February, check if it's a valid leap year if day is 29
  if (month === 2 && day === 29) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  // Return the year as string
  return year.toString();
}