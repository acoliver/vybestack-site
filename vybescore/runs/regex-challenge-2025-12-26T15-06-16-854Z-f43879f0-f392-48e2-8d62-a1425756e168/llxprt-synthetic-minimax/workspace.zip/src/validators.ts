export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obviously invalid patterns
  if (value.includes('@@') || value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain (but allow in local part)
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [local, domain] = parts;
  if (!local || !domain) return false;
  
  // Reject domain with underscores
  if (domain.includes('_')) return false;
  
  // Basic email pattern - matches typical valid emails
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  if (!cleaned) return false;
  
  // Check if it has country code
  let phoneNumber = cleaned;
  
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.slice(2);
  } else if (phoneNumber.startsWith('1') && (phoneNumber.length === 11)) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Remove all non-digit characters
  const digitsOnly = phoneNumber.replace(/\D/g, '');
  
  // Must have exactly 10 digits for US numbers
  if (digitsOnly.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digitsOnly.substring(0, 3);
  
  // Area codes cannot start with 0 or 1 (impossible area codes)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check for extensions if allowed
  if (options?.allowExtensions) {
    // Should handle extensions like "ext 123", "x123", etc.
    return true; // For now, if we got here and extensions are allowed, it's valid
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match Argentine phone number patterns
  const pattern = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})\d{6,8}$/;
  const match = cleaned.match(pattern);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = cleaned.substring(cleaned.indexOf(areaCode) + areaCode.length);
  
  // Area code must be 2-4 digits (already enforced by regex)
  // Subscriber number must be 6-8 digits
  const subscriberLength = subscriberNumber.length;
  
  return subscriberLength >= 6 && subscriberLength <= 8;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Must not contain any digits
  if (/\d/.test(value)) return false;
  
  // Must not contain unusual symbols like Æ or special characters
  // Allow: Unicode letters (including accented), apostrophes, hyphens, spaces
  const namePattern = /^[\p{L}\p{M}\s'’-]+$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Must not be empty or just whitespace
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Reject names that are clearly not real (like X Æ A-12 style)
  // This should not contain uppercase letters followed by spaces and symbols
  if (/[A-Z]+\s*[ÆØÅÅ]+|[A-Z]{2,}/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function for Luhn checksum algorithm
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').reverse().map(Number);
  
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    // Double every second digit
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  const firstTwoDigits = digitsOnly.substring(0, 2);
  const firstDigit = digitsOnly.charAt(0);
  
  let isValidCardType = false;
  
  // Check for different card types
  if (firstDigit === '4' && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19)) {
    // Visa
    isValidCardType = true;
  } else if ((firstTwoDigits >= '51' && firstTwoDigits <= '55') || 
             (digitsOnly.length === 16 && parseInt(firstTwoDigits) >= 22 && parseInt(firstTwoDigits) <= 27)) {
    // Mastercard
    isValidCardType = true;
  } else if ((firstTwoDigits === '34' || firstTwoDigits === '37') && digitsOnly.length === 15) {
    // American Express
    isValidCardType = true;
  }
  
  if (!isValidCardType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
