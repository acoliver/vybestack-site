const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate that the input is a valid Base64 string.
 * Throws an error if the input contains characters outside the Base64 alphabet.
 */
function validateBase64(input: string): void {
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, = padding)
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for proper padding placement (only at the end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, it must be at the end
    const withoutPadding = input.replace(/=+$/, '');
    if (withoutPadding.includes('=')) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
  }

  // Check length is valid (must be multiple of 4, or can be made so by adding padding)
  const normalizedLength = input.length;
  if (normalizedLength % 4 !== 0) {
    throw new Error('Invalid Base64 input: length must be a multiple of 4 (with or without padding)');
  }
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input before attempting to decode
  validateBase64(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced a valid result
    // Buffer.from with 'base64' is lenient and may produce empty buffer for invalid input
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Failed to decode Base64 input: no valid data produced');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
