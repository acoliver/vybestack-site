#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs } from 'node:util';
import type { ReportData, RenderOptions, Format } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function validateData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const reportData = data as Record<string, unknown>;
  
  // Check required string fields
  if (typeof reportData.title !== 'string' || typeof reportData.summary !== 'string') {
    return false;
  }

  // Check entries array
  if (!Array.isArray(reportData.entries)) {
    return false;
  }

  // Validate each entry
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }

    const reportEntry = entry as Record<string, unknown>;
    
    if (typeof reportEntry.label !== 'string' || typeof reportEntry.amount !== 'number') {
      return false;
    }
  }

  return true;
}

function main(): void {
  try {
    const { values, positionals } = parseArgs({
      options: {
        format: { type: 'string' },
        output: { type: 'string' },
        includeTotals: { type: 'boolean' }
      },
      allowPositionals: true
    });
    
    if (positionals.length === 0) {
      console.error('Error: Data file path is required');
      process.exit(1);
    }

    const dataFile = positionals[0] as string;
    const format = values.format as Format;
    const output = values.output as string | undefined;
    const includeTotals = values.includeTotals === true;

    if (!format) {
      console.error('Error: --format parameter is required');
      process.exit(1);
    }

    if (format !== 'markdown' && format !== 'text') {
      console.error(`Error: Unsupported format '${format}'`);
      process.exit(1);
    }

    // Read and parse JSON file
    const rawData = readFileSync(dataFile, 'utf-8');
    const data = JSON.parse(rawData);

    if (!validateData(data)) {
      console.error('Error: Invalid report data format');
      process.exit(1);
    }

    const options: RenderOptions = { includeTotals };
    let result: string;

    switch (format) {
      case 'markdown':
        result = renderMarkdown(data, options);
        break;
      case 'text':
        result = renderText(data, options);
        break;
      default:
        console.error(`Error: Unsupported format '${format}'`);
        process.exit(1);
    }

    if (output) {
      writeFileSync(output, result, 'utf-8');
    } else {
      process.stdout.write(result);
    }

  } catch (error) {
    if (error instanceof Error) {
      if ('code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found - ${error.message}`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
