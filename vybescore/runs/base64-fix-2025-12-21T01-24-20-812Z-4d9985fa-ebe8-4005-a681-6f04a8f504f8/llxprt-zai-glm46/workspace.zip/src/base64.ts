const STANDARD_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate input format
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check if input contains only valid Base64 characters
  const trimmedInput = input.trim();
  if (!STANDARD_BASE64_REGEX.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for invalid padding patterns
  const paddingIndex = trimmedInput.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = trimmedInput.substring(paddingIndex);
    if (!/^(=|==)$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: invalid padding pattern');
    }
    
    // Check if padding appears too early
    if (paddingIndex < trimmedInput.length - 3) {
      throw new Error('Invalid Base64 input: invalid padding position');
    }
  }

  // Check if length is valid for Base64 (not too short for padding logic)
  if (trimmedInput.length % 4 === 1 || trimmedInput.length < 2) {
    throw new Error('Invalid Base64 input: invalid length');
  }

  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
