import * as fs from 'node:fs';
import type { ReportData } from './types.js';

export function loadAndValidateReport(filePath: string): ReportData {
  let content: string;

  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON: ${(error as Error).message}`);
  }

  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (string expected)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (string expected)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (array expected)');
  }

  const entries = obj.entries;

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];

    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${i} has missing or invalid "label" field (string expected)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${i} has missing or invalid "amount" field (number expected)`
      );
    }
  }

  return data as ReportData;
}
