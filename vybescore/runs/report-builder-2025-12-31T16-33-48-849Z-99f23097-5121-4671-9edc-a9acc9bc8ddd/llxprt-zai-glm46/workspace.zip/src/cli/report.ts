#!/usr/bin/env node

import * as fs from 'node:fs';
import { formatters, supportedFormats } from '../formatters.js';
import { loadAndValidateReport } from '../validator.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputPath = args[0];
  const formatValue = args[1];

  if (formatValue !== '--format') {
    console.error('Error: --format flag is required');
    process.exit(1);
  }

  if (args.length < 3) {
    console.error('Error: --format requires a value');
    process.exit(1);
  }

  const format = args[2];
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  let i = 3;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  return {
    inputPath,
    format,
    outputPath,
    includeTotals
  };
}

function main(): void {
  const args = process.argv.slice(2);

  try {
    const { inputPath, format, outputPath, includeTotals } = parseArgs(args);

    if (!supportedFormats.includes(format)) {
      console.error(`Unsupported format: ${format}`);
      console.error(`Supported formats: ${supportedFormats.join(', ')}`);
      process.exit(1);
    }

    const data = loadAndValidateReport(inputPath);
    const renderer = formatters[format];
    const options: RenderOptions = { includeTotals };

    const output = renderer(data, options);

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
