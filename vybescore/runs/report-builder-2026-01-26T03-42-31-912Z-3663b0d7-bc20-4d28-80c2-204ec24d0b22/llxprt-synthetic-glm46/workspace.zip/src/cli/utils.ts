import type { ReportData } from '../types.js';

export interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(args: string[]): ParsedArgs {
  const parsedArgs: ParsedArgs = {
    dataPath: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsedArgs.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      parsedArgs.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      parsedArgs.includeTotals = true;
    } else if (!parsedArgs.dataPath) {
      parsedArgs.dataPath = arg;
    }
  }

  return parsedArgs;
}

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: expected object');
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid "label" field');
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid "amount" field');
    }
  }

  return data as ReportData;
}