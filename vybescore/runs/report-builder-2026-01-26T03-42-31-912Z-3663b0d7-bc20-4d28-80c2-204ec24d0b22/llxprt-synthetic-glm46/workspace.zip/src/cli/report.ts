#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { parseArgs, validateReportData } from './utils.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
};

function main() {
  try {
    const args = process.argv.slice(2);
    const parsedArgs = parseArgs(args);

    if (!parsedArgs.dataPath) {
      console.error('Error: Missing data file path');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (!parsedArgs.format) {
      console.error('Error: Missing --format argument');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    const formatter = formatters[parsedArgs.format as keyof typeof formatters];
    if (!formatter) {
      console.error(`Error: Unsupported format "${parsedArgs.format}"`);
      process.exit(1);
    }

    const fileContent = readFileSync(parsedArgs.dataPath, 'utf-8');
    let jsonData;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error parsing JSON file "${parsedArgs.dataPath}": ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }

    const reportData = validateReportData(jsonData);
    const result = formatter.render(reportData, { includeTotals: parsedArgs.includeTotals });

    if (parsedArgs.outputPath) {
      writeFileSync(parsedArgs.outputPath, result, 'utf-8');
      console.log(`Report saved to ${parsedArgs.outputPath}`);
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
