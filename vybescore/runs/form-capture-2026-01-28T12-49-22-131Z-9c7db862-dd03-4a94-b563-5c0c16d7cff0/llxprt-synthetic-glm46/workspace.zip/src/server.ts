import express, { Express, Request, Response, RequestHandler } from 'express';
import path from 'path';
import fs from 'fs';

// Type definitions for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}



interface ValidationError {
  field: string;
  message: string;
}

// Helper function for validation
function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields check
  if (!data.firstName.trim()) errors.push({ field: 'firstName', message: 'First name is required' });
  if (!data.lastName.trim()) errors.push({ field: 'lastName', message: 'Last name is required' });
  if (!data.streetAddress.trim()) errors.push({ field: 'streetAddress', message: 'Street address is required' });
  if (!data.city.trim()) errors.push({ field: 'city', message: 'City is required' });
  if (!data.stateProvince.trim()) errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  if (!data.postalCode.trim()) errors.push({ field: 'postalCode', message: 'Postal code is required' });
  if (!data.country.trim()) errors.push({ field: 'country', message: 'Country is required' });
  
  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  // Phone validation (can contain digits, spaces, parentheses, dashes, and a leading +)
  const phoneRegex = new RegExp(/^\\\\+?[0-9\\s()\\-]+$/);
  if (!data.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!phoneRegex.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }
  
  return errors;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let database: any = null;
let dbInitialized = false;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    // Dynamically import sql.js
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL = await import('sql.js') as any;
    const initSqlJs = SQL.default;
    
    // Create the data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    
    // Read the schema
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    const SQLModule = await initSqlJs();
    
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const filebuffer = fs.readFileSync(dbPath);
      database = new SQLModule.Database(filebuffer);
      console.log('Loaded existing database');
    } else {
      // Create new database
      database = new SQLModule.Database();
      console.log('Created new database');
      
      // Run schema
      database.run(schema);
      console.log('Database schema initialized');
    }
    
    dbInitialized = true;
    console.log('Database initialization complete');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabaseToDisk(): void {
  if (!dbInitialized || !database) {
    console.error('Database not initialized');
    return;
  }
  
  try {
    const data = database.export();
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const dataDir = path.join(process.cwd(), 'data');
    
    // Ensure directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Insert submission into database
function insertSubmission(data: FormData): void {
  if (!dbInitialized || !database) {
    console.error('Database not initialized');
    return;
  }
  
  try {
    const stmt = database.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    stmt.free();
    console.log('Submission saved to database');
  } catch (error) {
    console.error('Failed to insert submission:', error);
  }
}

// Setup Express app
async function createApp(): Promise<Express> {
  const app: Express = express();
  
  // Initialize database
  await initializeDatabase();
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static('public'));
  
  // Set EJS as the view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));
  
  // GET / - Display the form
  const getRoot: RequestHandler = (req: Request, res: Response) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  };
  app.get('/', getRoot);
  
  // POST /submit - Handle form submission
  const postSubmit: RequestHandler = (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    // Validate form
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      // Re-render form with errors
      return res.status(400).render('form', {
        errors: errors.map(e => e.message),
        values: formData
      });
    }
    
    // Save to database
    insertSubmission(formData);
    saveDatabaseToDisk();
    
    // Redirect to thank you page
    return res.redirect('/thank-you');
  };
  app.post('/submit', postSubmit);
  
  // GET /thank-you - Display thank you page
  const getThankYou: RequestHandler = (req: Request, res: Response) => {
    // Get first name from query or use a default
    const firstName = (req.query.firstName as string) || 'friend';
    return res.render('thank-you', { firstName });
  };
  app.get('/thank-you', getThankYou);
  
  return app;
}

// Start the server
async function startServer(): Promise<void> {
  try {
    const app = await createApp();
    const port = process.env.PORT || 3535;
    
    const server = app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
    
    // Handle graceful shutdown
    const shutdown = () => {
      console.log('Shutting down gracefully...');
      if (dbInitialized && database) {
        database.close();
      }
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    };
    
    // Listen for shutdown signals
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
