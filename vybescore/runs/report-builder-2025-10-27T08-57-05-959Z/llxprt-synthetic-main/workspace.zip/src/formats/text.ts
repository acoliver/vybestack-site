/**
 * Plain text formatter for reports
 */
import type { ReportData, FormatOptions, ReportFormatter } from '../types.js';

export const renderText: ReportFormatter = (
  data: ReportData,
  options: FormatOptions = {}
): string => {
  const { includeTotals = false } = options;
  
  // Calculate total if needed
  const total = includeTotals
    ? data.entries.reduce((sum, entry) => sum + entry.amount, 0)
    : 0;

  // Build the text output
  const lines = [
    data.title,
    '',
    data.summary,
    '',
    'Entries:',
    ...data.entries.map(entry => `- ${entry.label}: $${entry.amount.toFixed(2)}`),
  ];

  // Add total if requested
  if (includeTotals) {
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
};