/**
 * Format registry for report formatters
 */
import type { ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Available formatters
 */
export const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Get a formatter by name
 */
export function getFormatter(format: string): ReportFormatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

/**
 * List of available format names
 */
export function getAvailableFormats(): string[] {
  return Object.keys(formatters);
}