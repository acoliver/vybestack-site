/**
 * Report data structure
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for formatting reports
 */
export interface FormatOptions {
  includeTotals?: boolean;
}

/**
 * Function signature for report formatters
 */
export interface ReportFormatter {
  (data: ReportData, options?: FormatOptions): string;
}