/**
 * Command line argument parsing using Node's standard library
 */
import { parseArgs } from 'node:util';


export interface CliArguments {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

export function parseArguments(argv: string[]): CliArguments {
  try {
    // Parse command line arguments
    const { values, positionals } = parseArgs({
      args: argv,
      options: {
        format: {
          type: 'string',
          short: 'f'
        },
        output: {
          type: 'string',
          short: 'o'
        },
        includeTotals: {
          type: 'boolean',
          default: false
        },
        help: {
          type: 'boolean',
          short: 'h'
        }
      },
      strict: true,
      allowPositionals: true
    });

    // Check for help flag
    if (values.help) {
      console.log(`
Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]

Options:
  -f, --format <format>      Output format (markdown, text)
  -o, --output <path>        Output file path (default: stdout)
  --includeTotals           Include totals in the report
  -h, --help                Show this help message

Arguments:
  data.json                  Path to the JSON file containing report data
      `);
      process.exit(0);
    }

    // Validate required arguments
    if (positionals.length !== 1) {
      throw new Error('Missing required data file argument');
    }

    if (!values.format) {
      throw new Error('Missing required --format option');
    }

    return {
      dataFile: positionals[0],
      format: values.format,
      output: values.output,
      includeTotals: values.includeTotals || false
    };
  } catch (error: unknown) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    console.error('Use --help for usage information');
    process.exit(1);
  }
}