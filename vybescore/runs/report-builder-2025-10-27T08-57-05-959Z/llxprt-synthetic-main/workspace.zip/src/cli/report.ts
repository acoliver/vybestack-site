#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { exit, argv } from 'node:process';
import type { ReportData, FormatOptions } from '../types.js';
import { getFormatter } from '../formatters/index.js';
import { parseArguments, type CliArguments } from '../utils/argv.js';

/**
 * Load and parse the report data from a JSON file
 */
async function loadData(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf8');
    const data = JSON.parse(content) as unknown;

    // Validate the data structure
    if (
      !data ||
      typeof data !== 'object' ||
      !('title' in data) ||
      !('summary' in data) ||
      !('entries' in data)
    ) {
      throw new Error('Invalid report data structure');
    }

    const reportData = data as ReportData;
    if (
      typeof reportData.title !== 'string' ||
      typeof reportData.summary !== 'string' ||
      !Array.isArray(reportData.entries)
    ) {
      throw new Error('Invalid report data types');
    }

    // Validate entries
    for (const entry of reportData.entries) {
      if (
        typeof entry !== 'object' ||
        entry === null ||
        !('label' in entry) ||
        !('amount' in entry)
      ) {
        throw new Error('Invalid entry structure');
      }

      if (
        typeof entry.label !== 'string' ||
        typeof entry.amount !== 'number'
      ) {
        throw new Error('Invalid entry types');
      }
    }

    return reportData;
  } catch (error) {
    console.error(`Error loading data from ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
    exit(1);
  }
}

/**
 * Write content to file or stdout
 */
async function writeOutput(content: string, outputPath?: string): Promise<void> {
  try {
    if (outputPath) {
      await writeFile(outputPath, content, 'utf8');
    } else {
      console.log(content);
    }
  } catch (error) {
    console.error(`Error writing output: ${error instanceof Error ? error.message : String(error)}`);
    exit(1);
  }
}

/**
 * Main CLI logic
 */
async function main(): Promise<void> {
  // Parse command line arguments
  const args: CliArguments = parseArguments(argv.slice(2));

  // Load the data
  const data: ReportData = await loadData(args.dataFile);

  // Get the formatter
  const formatter = getFormatter(args.format);

  // Format options
  const options: FormatOptions = {
    includeTotals: args.includeTotals
  };

  // Generate report
  const report = formatter(data, options);

  // Write output
  await writeOutput(report, args.output);
}

// Run the CLI
main().catch(error => {
  console.error(`Unexpected error: ${error instanceof Error ? error.message : String(error)}`);
  exit(1);
});
