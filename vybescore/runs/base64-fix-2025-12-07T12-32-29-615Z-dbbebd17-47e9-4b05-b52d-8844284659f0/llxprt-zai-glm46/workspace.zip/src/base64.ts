
/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string format.
 */
function isValidBase64(input: string): boolean {
  // Check for valid Base64 characters: A-Z, a-z, 0-9, +, /, and optional padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check proper padding - padding must be at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, check that all remaining chars are padding
    const remainingChars = input.substring(paddingIndex);
    if (!/^[=]+$/.test(remainingChars)) {
      return false;
    }
    
    // Maximum 2 padding characters
    if (remainingChars.length > 2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }
  
  // Validate input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input format');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
