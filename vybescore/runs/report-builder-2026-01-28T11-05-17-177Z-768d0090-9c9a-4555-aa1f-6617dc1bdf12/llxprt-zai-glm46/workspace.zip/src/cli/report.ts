/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ReportData } from '../types.js';
import { getFormatter } from '../formatters.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: undefined,
    includeTotals: false
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!result.inputFile) {
      result.inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
    i++;
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required (supported: markdown, text)');
  }

  return result;
}

function loadReportData(filePath: string): ReportData {
  const resolvedPath = path.resolve(filePath);
  const content = fs.readFileSync(resolvedPath, 'utf-8');

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}\n${error.message}`);
    }
    throw error;
  }

  // Validate data structure
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: must be an object');
  }

  const report = data as Partial<Record<string, unknown>>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }

    const entryObj = entry as Partial<Record<string, unknown>>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid entry at index ${i}: missing or invalid "label" field (must be a string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid entry at index ${i}: missing or invalid "amount" field (must be a number)`
      );
    }
  }

  return {
    title: report.title,
    summary: report.summary,
    entries: report.entries as Array<{ label: string; amount: number }>
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));
    const data = loadReportData(args.inputFile);
    const formatter = getFormatter(args.format);
    const output = formatter(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

main();
