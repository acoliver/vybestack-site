import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { initializeDatabase, insertSubmission, closeDatabase, FormData } from './database.js';
import { validateFormData } from './validation.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Types for form data
interface FormRequestBody extends FormData {
  consent?: string;
}

// Middleware to handle errors
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
  _next; // unused parameter for Express error middleware signature
});

// Routes
app.get('/', async (req: Request, res: Response) => {
  try {
    res.render('form', {
      errors: [],
      formData: {}
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Error loading form');
  }
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormRequestBody = req.body;
    
    // Check consent
    if (!formData.consent) {
      return res.status(400).render('form', {
        errors: [{ field: 'consent', message: 'You must consent to spam (required!)' }],
        formData
      });
    }

    // Validate form data
    const validation = validateFormData(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        formData
      });
    }

    // Insert submission into database
    const submissionData: FormData = {
      first_name: formData.first_name!,
      last_name: formData.last_name!,
      street_address: formData.street_address!,
      city: formData.city!,
      state_province: formData.state_province!,
      postal_code: formData.postal_code!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!
    };

    await insertSubmission(submissionData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).send('Error processing form submission');
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  try {
    res.render('thank-you');
  } catch (error) {
    console.error('Error rendering thank you page:', error);
    res.status(500).send('Error loading thank you page');
  }
});

// 404 handler
app.use('*', (req: Request, res: Response) => {
  res.status(404).send('Page not found');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, '0.0.0.0', () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });

    // Graceful shutdown on server close
    server.on('close', () => {
      closeDatabase();
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();

export default app;
