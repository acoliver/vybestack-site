import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

let dbInstance: Database | null = null;
let SqlJsConstructor: any = null;

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

export async function initializeDatabase(): Promise<void> {
  if (!SqlJsConstructor) {
    SqlJsConstructor = await initSqlJs({
      locateFile: (file: string) => {
        return file === 'sql-wasm.wasm' 
          ? path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm')
          : file;
      }
    });
  }

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const fileBuffer = fs.readFileSync(DB_PATH);
    if (SqlJsConstructor && dbInstance === null) {
      dbInstance = new SqlJsConstructor.Database(fileBuffer);
    }
  } else {
    // Create new database and load schema
    if (SqlJsConstructor && dbInstance === null) {
      dbInstance = new SqlJsConstructor.Database();
    }
  }

  // Ensure dbInstance is initialized before operations
  if (dbInstance === null && SqlJsConstructor) {
    dbInstance = new SqlJsConstructor.Database();
  }

  // Load schema if database is new (after initialization)
  if (dbInstance && !fs.existsSync(DB_PATH)) {
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    dbInstance.exec(schema);
    saveDatabase();
  }
}

export function saveDatabase(): void {
  if (!dbInstance) return;
  
  const binaryDb = dbInstance.export();
  fs.writeFileSync(DB_PATH, Buffer.from(binaryDb));
}

export async function insertSubmission(data: FormData): Promise<void> {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const stmt = dbInstance.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.first_name,
    data.last_name,
    data.street_address,
    data.city,
    data.state_province,
    data.postal_code,
    data.country,
    data.email,
    data.phone
  ]);

  stmt.free();
  saveDatabase();
}

export function closeDatabase(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}