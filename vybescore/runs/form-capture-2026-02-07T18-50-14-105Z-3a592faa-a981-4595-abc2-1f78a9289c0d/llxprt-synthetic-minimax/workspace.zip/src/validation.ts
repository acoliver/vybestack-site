import { FormData } from './database.js';

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city',
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const fieldValue = data[field];
    if (!fieldValue || typeof fieldValue !== 'string' || fieldValue.trim() === '') {
      errors.push({
        field: field as string,
        message: `${formatFieldName(field as string)} is required`
      });
    }
  }

  // Email validation
  if (data.email && !emailRegex.test(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone number validation (allow international formats)
  if (data.phone) {
    const phoneRegex = /^@?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading @'
      });
    }
  }

  // Postal code validation (accept letters and digits)
  if (data.postal_code) {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postal_code)) {
      errors.push({
        field: 'postal_code',
        message: 'Postal code can only contain letters, digits, spaces, and dashes'
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

function formatFieldName(field: string): string {
  return field
    .replace(/_/g, ' ')
    .replace(/\b\w/g, l => l.toUpperCase());
}