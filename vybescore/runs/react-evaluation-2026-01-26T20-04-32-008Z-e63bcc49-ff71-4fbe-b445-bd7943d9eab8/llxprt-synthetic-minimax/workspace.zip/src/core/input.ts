/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  trackSubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

interface InputSubject<T> extends Subject<T> {
  observers?: Set<Observer<T>>
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: InputSubject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Track this read for dependency tracking
    const observer = getActiveObserver<T>()
    if (observer) {
      trackSubject(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers that depend on this input
    if (s.observers && s.observers.size > 0) {
      // Create a copy to avoid issues during iteration
      const observers = Array.from(s.observers)
      observers.forEach((observer) => {
        updateObserver(observer)
      })
    }
    return s.value
  }

  return [read, write]
}
