/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false

  const observer: Observer<T> = {
    value: value as T,
    updateFn: (prevValue) => {
      if (disposed) return value as T
      const result = updateFn(prevValue ?? value)
      return result as T
    },
    dispose: () => {
      disposed = true
    }
  }
  
  // Set this observer as active so dependencies can track to it
  setActiveObserver(observer)
  
  try {
    // Run the callback to establish dependencies and initial value
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(undefined)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    observer.dispose?.()
  }
}
