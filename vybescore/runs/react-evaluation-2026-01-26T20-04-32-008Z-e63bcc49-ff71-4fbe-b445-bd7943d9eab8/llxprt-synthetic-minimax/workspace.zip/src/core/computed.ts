/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  setActiveObserver,
  trackSubject,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

interface ComputedSubject<T> extends Subject<T> {
  observers?: Set<Observer<T>>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const s: ComputedSubject<T> = {
    name: options?.name,
    value: value as T,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Track this read for dependency tracking
    const observer = getActiveObserver<T>()
    if (observer) {
      trackSubject(s)
    }

    // Store current value before computation
    const currentValue = s.value
    
    // Set this observer as active so dependencies can track to it
    const previous = setActiveObserver(undefined)
    try {
      // Only pass current value if it's defined, otherwise let defaults work
      const newValue = currentValue !== undefined 
        ? updateFn(currentValue) 
        : updateFn()
      
      // Check if value changed and notify observers
      const valueChanged = s.value !== newValue
      s.value = newValue!
      
      // Notify all observers that depend on this computed value
      if (valueChanged && s.observers && s.observers.size > 0) {
        const observers = Array.from(s.observers)
        observers.forEach((observer) => {
          observer.value = observer.updateFn(observer.value)
        })
      }
    } finally {
      // Restore previous active observer
      setActiveObserver(previous)
    }
    
    return s.value!
  }

  return read
}
