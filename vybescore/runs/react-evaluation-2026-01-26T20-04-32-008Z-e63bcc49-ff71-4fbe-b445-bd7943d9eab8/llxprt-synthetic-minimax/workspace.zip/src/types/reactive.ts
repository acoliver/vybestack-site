/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  listeners?: Set<(value?: T) => void>
  dispose?: () => void
}

export interface Subject<T> {
  name?: string
  value: T
  observers?: Set<Observer<T>>
  equalFn?: EqualFn<T>
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver<T>(): Observer<T> | undefined {
  return activeObserver as Observer<T> | undefined
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): Observer<T> | undefined {
  const previous = activeObserver as Observer<T> | undefined
  activeObserver = observer as Observer<unknown> | undefined
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver as Observer<T> | undefined
  activeObserver = observer as Observer<unknown> | undefined
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous as Observer<unknown> | undefined
  }
}

export function trackSubject<T>(subject: Subject<T>): void {
  const observer = getActiveObserver<T>()
  if (!observer) return
  
  // Register reverse dependency
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function notifySubject<T>(subject: Subject<T>, newValue: T): void {
  subject.value = newValue
  
  // Notify all observers of this subject
  if (subject.observers) {
    subject.observers.forEach((observer) => {
      updateObserver(observer)
      // Fire any listeners attached to this observer
      observer.listeners?.forEach((listener) => {
        listener(observer.value)
      })
    })
  }
}

export function addListener<T>(observer: Observer<T>, listener: (value?: T) => void): void {
  if (!observer.listeners) {
    observer.listeners = new Set()
  }
  observer.listeners.add(listener)
}

export function removeListener<T>(observer: Observer<T>, listener: (value?: T) => void): void {
  observer.listeners?.delete(listener)
}

export function disposeObserver<T>(observer: Observer<T>): void {
  observer.listeners?.clear()
  observer.dispose?.()
}

export function notifyListeners<T>(observer: Observer<T>): void {
  observer.listeners?.forEach((listener) => {
    listener(observer.value)
  })
}
