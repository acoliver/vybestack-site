/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let needsUpdate = true
  const trackedObservers = new Set<ObserverR>()
  
  const compute = (): T => {
    if (needsUpdate) {
      // Clear previous dependencies
      trackedObservers.clear()
      
      // Set this computed as the active observer to track dependencies
      updateObserver(observer)
      needsUpdate = false
    }
    return observer.value!
  }
  
  const computedGetter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      trackedObservers.add(activeObserver)
    }
    return compute()
  }
  
  // Store the tracked observers so they can be notified when this computed changes
  ;(observer as Observer<T> & { trackedObservers: Set<ObserverR> }).trackedObservers = trackedObservers
  
  // Override updateObserver to intercept notifications for this specific computed
  const originalUpdateObserver = updateObserver
  const updateComputedIfNeeded = (<T>(obs: Observer<T>) => {
    const result = originalUpdateObserver(obs)
    if ((obs as unknown) === (observer as unknown)) {
      // This computed just updated, notify all its dependents
      needsUpdate = true
      notifyObservers(trackedObservers)
    }
    return result
  })
  
  // Temporarily override updateObserver during initial computation
  ;(globalThis as unknown as { updateObserver: typeof updateObserver }).updateObserver = updateComputedIfNeeded
  
  try {
    compute() // Initial computation
  } finally {
    (globalThis as unknown as { updateObserver: typeof updateObserver }).updateObserver = originalUpdateObserver
  }
  
  return computedGetter
}
