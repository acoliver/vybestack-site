/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  const trackedObservers = new Set<ObserverR>()
  
  const executeCallback = () => {
    // Clear previous dependencies
    trackedObservers.clear()
    
    // Set this callback as the active observer to track dependencies
    updateObserver(observer)
  }
  
  // Override updateObserver to intercept notifications
  const originalUpdateObserver = updateObserver
  const updateCallbackIfNeeded = (<T>(obs: Observer<T>) => {
    const result = originalUpdateObserver(obs)
    if ((obs as unknown) !== (observer as unknown)) {
      // Some dependency changed, execute callback
      executeCallback()
    }
    return result
  })
  
  // Temporarily override updateObserver during initial execution
  ;(globalThis as unknown as { updateObserver: typeof updateObserver }).updateObserver = updateCallbackIfNeeded
  
  try {
    executeCallback() // Initial execution
  } finally {
    (globalThis as unknown as { updateObserver: typeof updateObserver }).updateObserver = originalUpdateObserver
  }
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove from all tracked subjects
    trackedObservers.clear()
  }
  
  return unsubscribe
}
