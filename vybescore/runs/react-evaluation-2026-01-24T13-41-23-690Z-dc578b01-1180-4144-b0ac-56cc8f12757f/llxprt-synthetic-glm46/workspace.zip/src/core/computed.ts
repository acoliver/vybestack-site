/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const getter: GetterFn<T> = () => {
    // If this computed is being accessed by another observer, track dependency
    const observer = getActiveObserver()
    if (observer) {
      // Store the active observer so this computed can notify it when dependencies change
      o.observer = observer
    }
    
    // Re-compute on every access to ensure we get the latest values from dependencies
    updateObserver(o)
    
    return o.value!
  }
  
  return getter
}
