import express, { Application } from 'express';
import path from 'path';
import fs from 'fs';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const sqliteModule = require('sql.js');

interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  get(): { first_name?: string } | undefined;
  free(): void;
}

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: Application;
  private db: Database;
  private server: import('http').Server | null = null;
  private dataDir: string;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dataDir = path.join(process.cwd(), 'data');
    this.dbPath = path.join(this.dataDir, 'submissions.sqlite');
    this.db = {} as Database; // Will be properly initialized in initializeDatabase
    
    this.setupMiddleware();
    this.ensureDataDirectory();
    this.initializeDatabase();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.static(path.join(process.cwd(), 'public')));
    this.app.use(express.urlencoded({ extended: true }));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
  }

  private ensureDataDirectory(): void {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await sqliteModule;
      
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbFile) as Database;
      } else {
        this.db = new SQL.Database() as Database;
        const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        this.db.run(schema);
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(data: FormSubmission): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    if (data.phone && !/^[\d\s()\-\+]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and +' });
    }

    // Postal code validation - allow alphanumeric characters and spaces
    if (data.postalCode && !/^[a-zA-Z0-9\s]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, and spaces' });
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', { 
        errors: [], 
        values: {} 
      });
    });

    this.app.post('/submit', (req, res) => {
      const formData: FormSubmission = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);
      
      if (errors.length > 0) {
        res.status(400).render('form', { 
          errors: errors.map(e => e.message), 
          values: formData 
        });
        return;
      }

      try {
        const stmt = this.db.prepare(`
          INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run(
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        );
        
        stmt.free();
        this.saveDatabase();
        
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', { 
          errors: ['An error occurred while saving your submission. Please try again.'], 
          values: formData 
        });
      }
    });

    this.app.get('/thank-you', (req, res) => {
      const firstName = this.getRecentSubmissionFirstName();
      res.render('thank-you', { firstName });
    });

    this.app.use((req, res) => {
      res.status(404).send('Page not found');
    });
  }

  private getRecentSubmissionFirstName(): string {
    try {
      const stmt = this.db.prepare(`
        SELECT first_name FROM submissions 
        ORDER BY created_at DESC 
        LIMIT 1
      `);
      const result = stmt.get() as { first_name?: string } | undefined;
      stmt.free();
      return result?.first_name || 'friend';
    } catch (error) {
      console.error('Error fetching recent submission:', error);
      return 'friend';
    }
  }

  public async start(): Promise<void> {
    const port = process.env.PORT || 3535;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown handling
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}, shutting down gracefully...`);
      
      if (this.server) {
        this.server.close(() => {
          console.log('HTTP server closed');
        });
      }
      
      if (this.db) {
        this.saveDatabase();
        this.db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }
}

async function main() {
  const server = new FormServer();
  await server.start();
}

main().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
