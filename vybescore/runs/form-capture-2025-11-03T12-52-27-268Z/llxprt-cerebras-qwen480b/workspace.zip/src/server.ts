import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation functions
const validateField = (value: string): boolean => {
  return value.trim().length > 0;
};

const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Alphanumeric postal codes with possible spaces or dashes
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
};

// Validate form data
const validateForm = (data: FormData): string[] => {
  const errors: string[] = [];
  
  if (!validateField(data.firstName)) errors.push('First name is required');
  if (!validateField(data.lastName)) errors.push('Last name is required');
  if (!validateField(data.streetAddress)) errors.push('Street address is required');
  if (!validateField(data.city)) errors.push('City is required');
  if (!validateField(data.stateProvince)) errors.push('State/Province is required');
  if (!validateField(data.postalCode)) errors.push('Postal code is required');
  if (!validateField(data.country)) errors.push('Country is required');
  if (!validateField(data.email)) errors.push('Email is required');
  if (!validateField(data.phone)) errors.push('Phone number is required');
  
  if (data.email && !validateEmail(data.email)) {
    errors.push('Email format is invalid');
  }
  
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  return errors;
};

// Database operations
class DatabaseManager {
  private db: Database | null = null;
  private filePath: string;
  
  constructor(filePath: string) {
    this.filePath = filePath;
  }
  
  async initialize(): Promise<void> {
    const SQL = await initSqlJs({ 
      locateFile: (file) => `https://sql.js.org/dist/${file}` 
    });
    
    // Load existing database or create new one
    try {
      if (fs.existsSync(this.filePath)) {
        const fileBuffer = fs.readFileSync(this.filePath);
        this.db = new SQL.Database(new Uint8Array(fileBuffer));
      } else {
        this.db = new SQL.Database();
        this.db.run(fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8'));
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Database initialization error:', error);
      this.db = new SQL.Database();
      this.db.run(fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8'));
      this.saveDatabase();
    }
  }
  
  saveDatabase(): void {
    if (this.db) {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(this.filePath, buffer);
    }
  }
  
  insertSubmission(data: FormData): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const query = `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
      
    this.db.run(query, [
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    this.saveDatabase();
  }
  
  close(): void {
    if (this.db) {
      this.db.close();
      this.saveDatabase();
    }
  }
}

// Create Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Initialize database
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const dbManager = new DatabaseManager(dbPath);

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: formData
    });
  }
  
  dbManager.insertSubmission(formData);
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Just render a default thank you page if no submissions exist yet
  res.render('thank-you', { firstName: 'Valued Customer' });
});

// Start server and initialize database
const startServer = async () => {
  await dbManager.initialize();
  
  const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      dbManager.close();
      console.log('Server closed');
      process.exit(0);
    });
  });
  
  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    server.close(() => {
      dbManager.close();
      console.log('Server closed');
      process.exit(0);
    });
  });
};

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});