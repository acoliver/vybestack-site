/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the given prefix
  // Word boundary \b ensures we match whole words only
  const prefixPattern = new RegExp(`\\b${prefix}\\w*`, 'g');
  
  // Find all matches
  const matches = text.match(prefixPattern);
  
  if (!matches) return [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(match => 
    !exceptions.includes(match.toLowerCase())
  );
  
  // Return unique matches
  return [...new Set(filteredMatches)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a pattern that matches the token when:
  // 1. It appears after a digit
  // 2. It's not at the start of the string
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern);
  return matches ? matches : [];
}

/**
 * Validate password strength based on specified criteria.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  // Use character set without escaping inside
  if (!/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses without false positives for IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // 1. Full form: eight groups of four hex digits
  // 2. Short form: with :: shorthand
  // 3. Mixed form: IPv4-mapped IPv6 addresses
  
  // Pattern to detect IPv6 addresses (excluding IPv4)
  const ipv6Pattern = /((?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){1,7}:|(?:[0-9a-f]{1,4}:){1,6}:[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){1,5}(?::[0-9a-f]{1,4}){1,2}|(?:[0-9a-f]{1,4}:){1,4}(?::[0-9a-f]{1,4}){1,3}|(?:[0-9a-f]{1,4}:){1,3}(?::[0-9a-f]{1,4}){1,4}|(?:[0-9a-f]{1,4}:){1,2}(?::[0-9a-f]{1,4}){1,5}|[0-9a-f]{1,4}:(?:(?::[0-9a-f]{1,4}){1,6})|:(?:(?::[0-9a-f]{1,4}){1,7}|:))/i;
  
  // First check if we have any IPv6-like patterns
  if (!ipv6Pattern.test(value)) {
    return false;
  }
  
  // Additional check to exclude IPv4 addresses
  // IPv4 pattern: n.n.n.n where n is 0-255
  const ipv4Pattern = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  const words = value.split(/\s+/);
  
  for (const word of words) {
    // If it matches our IPv6 pattern
    if (ipv6Pattern.test(word)) {
      // But it's also a valid IPv4 address, exclude it
      if (!ipv4Pattern.test(word)) {
        return true;
      }
    }
  }
  
  return false;
}