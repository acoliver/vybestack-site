/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.length === 0) return text;
  
  let result = text;
  
  // Split by sentence endings (., ?, !) followed by whitespace or end of string
  // Using regex with lookbehind to preserve punctuation
  const sentences = result.split(/(?<=[.?!])(?=\s|$)/);
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i].trim();
    if (sentence.length === 0) {
      sentences[i] = sentence; // Empty sentence
      continue;
    }
    
    // Simple capitalization after sentence punctuation
    const firstChar = sentence.charAt(0);
    if (firstChar && firstChar.match(/[a-z]/)) {
      sentences[i] = firstChar.toUpperCase() + sentence.slice(1);
    }
  }
  
  // Join sentences with a single space
  result = sentences.join(' ');
  
  // Collapse multiple spaces to single
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * Extract all URLs from the given text, without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || text.length === 0) return [];
  
  // Use Regex class to create the pattern
  const urlPattern = new RegExp('https?:\\/\\/(?:[-\\w.])+(?:[:\\d]+)?(?:\\/(?:[\\w\\/_.])*(?:\\?(?:[\\w&=%.])*)?(?:#(?:[\\w.])*)?)?', 'g');
  
  const matches = text.match(urlPattern);
  if (!matches) return [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    const punctPattern = /[.,;:?!)}\]"']+$/;
    return url.replace(punctPattern, '');
  });
}

/**
 * Convert all http:// URLs to https://.
 */
export function enforceHttps(text: string): string {
  if (!text || text.length === 0) return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs according to the specific rules.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || text.length === 0) return text;
  
  // Pattern to match all URLs
  const urlPattern = /(http:\/\/)([-\w.]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    let result = 'https://' + host;
    
    if (path) {
      // Check if path starts with /docs/
      const isDocsPath = /^\/docs\//.test(path);
      
      // Dynamic hints to skip host rewrite
      const hasDynamicHints = /\/(cgi-bin\/|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path);
      
      if (isDocsPath && !hasDynamicHints) {
        // Rewrite host to docs.example.com
        result = 'https://docs.' + host;
      }
      
      result += path;
    }
    
    return result;
  });
}

/**
 * Extract the year from a mm/dd/yyyy format date string.
 */
export function extractYear(value: string): string | 'N/A' {
  if (!value || value.length === 0) return 'N/A';
  
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month and leap years
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const isLeapYear = (year: string) => {
    const yr = parseInt(year, 10);
    return (yr % 4 === 0 && yr % 100 !== 0) || (yr % 400 === 0);
  };
  
  // Adjust February for leap year
  if (month === 2 && isLeapYear(year)) {
    if (day > 29) return 'N/A';
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}