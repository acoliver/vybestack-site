export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with specific requirements
  // Reject double dots, trailing dots, domains with underscores
  
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic structure check: one @ symbol
  const atCount = (email.match(/@/g) || []).length;
  if (atCount !== 1) return false;
  
  const [localPart, domain] = email.split('@');
  
  // Local part validation (before @)
  // - Not empty
  // - No leading or trailing dots
  // - No double dots
  // - Allow letters, numbers, dots, hyphens, plus, underscores
  if (!localPart || localPart.length === 0) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Valid local part pattern
  const localPartPattern = /^[a-zA-Z0-9._+-]+$/;
  if (!localPartPattern.test(localPart)) return false;
  
  // Domain validation (after @)
  // - Not empty
  // - No leading or trailing dots
  // - No double dots
  // - No underscores
  if (!domain || domain.length === 0) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  if (domain.includes('_')) return false;
  
  // Valid domain pattern (including subdomains)
  // Should end with a valid TLD (2-63 characters)
  const domainPattern = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$/;
  if (!domainPattern.test(domain)) return false;
  
  return true;
}

/**
 * Validate US phone numbers with various supported formats.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits
  // 10 digits for standard US number, 11 digits if starting with 1 (country code)
  if (digits.length !== 10 && digits.length !== 11) return false;
  
  // If 11 digits, must start with +1 or 1
  if (digits.length === 11 && !digits.startsWith('1')) return false;
  
  // Extract the actual 10-digit number (remove country code if present)
  const tenDigitNumber = digits.length === 11 ? digits.substring(1) : digits;
  
  // Check area code (first 3 digits)
  // Should not start with 0 or 1
  const areaCode = tenDigitNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Verify the rest of the number is 7 digits
  if (tenDigitNumber.substring(3).length !== 7) return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other punctuation for validation
  // Remove also the + if present to work with digits only
  let digits = value.replace(/[\s-()]/g, '');
  if (digits.startsWith('+')) {
    digits = digits.substring(1);
  }
  
  // Argentine phone patterns:
  // 1. With country code: +54 [9] [area code] [subscriber number]
  // 2. Without country code: 0[area code][subscriber number]
  
  let areaCode: string;
  let subscriberNumber: string;
  
  // Check if starts with country code
  if (digits.startsWith('54')) {
    const remaining = digits.substring(2);
    
    // Check for mobile prefix (9)
    let afterMobile = remaining;
    if (remaining.startsWith('9')) {
      afterMobile = remaining.substring(1);
    }
    
    // Area code is 2-4 digits, starting with 1-9
    const areaCodeMatch = afterMobile.match(/^([1-9]\d{1,3})(\d+)$/);
    if (!areaCodeMatch) return false;
    
    areaCode = areaCodeMatch[1];
    subscriberNumber = areaCodeMatch[2];
  } else if (digits.startsWith('0')) {
    // Must start with trunk prefix 0 if no country code
    const afterTrunk = digits.substring(1);
    
    // Area code is 2-4 digits, starting with 1-9
    const areaCodeMatch = afterTrunk.match(/^([1-9]\d{1,3})(\d+)$/);
    if (!areaCodeMatch) return false;
    
    areaCode = areaCodeMatch[1];
    subscriberNumber = areaCodeMatch[2];
  } else {
    // Invalid format - must start with +54 or 0
    return false;
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validate names with Unicode support.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  const name = value.trim();
  
  // Empty names are invalid
  if (!name || name.length === 0) return false;
  
  // Name should only contain letters (including Unicode), apostrophes, hyphens, and spaces
  // Should not contain digits or symbols
  const namePattern = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!namePattern.test(name)) return false;
  
  // Reject names that contain only symbols or are primarily symbols
  const lettersOnly = name.replace(/[^\p{L}]/gu, '');
  if (lettersOnly.length === 0) return false;
  
  // Additional validation for extremely non-standard names
  // Reject names that seem to have too many special characters
  const specialCount = (name.match(/['\- ]/g) || []).length;
  if (specialCount > name.length / 2) return false;
  
  return true;
}

/**
 * Luhn algorithm to validate credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = 1 + (digit % 10);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa, Mastercard, AmEx).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits and valid length (13-19 digits for most cards)
  if (!/^\d+$/.test(cardNumber)) return false;
  if (cardNumber.length < 13 || cardNumber.length > 19) return false;
  
  // Check with Luhn algorithm
  if (!runLuhnCheck(cardNumber)) return false;
  
  // Visa: starts with 4, length 13 or 16
  if (cardNumber.startsWith('4') && (cardNumber.length === 13 || cardNumber.length === 16)) {
    return true;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const masterCardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  if (masterCardPattern.test(cardNumber)) return true;
  
  // American Express: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  if (amexPattern.test(cardNumber)) return true;
  
  // Additional card types could be added here
  // For now, only Visa, Mastercard, and Amex are supported
  
  return false;
}