import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { Server as HttpServer } from 'http';

const app = express();
const PORT = process.env.PORT || 3535;
let serverInstance: HttpServer | null = null;

// Configure Express
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// SQLite database setup
let db: Database | null = null;
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

// Database initialization
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
  });

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.exec(schema);
    saveDatabase();
  }
}

// Save database to file
function saveDatabase(): void {
  if (db) {
    const fileBuffer = db.export();
    fs.writeFileSync(DB_PATH, fileBuffer);
  }
}

// Validation functions
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s()-]+$/;
  return phoneRegex.test(phone);
}

function validateFormData(data: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check required fields
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  // Validate email format
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Validate phone number format
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('contact-form', {
    errors: [],
    formData: {},
    title: 'Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvince: (req.body.stateProvince || '').trim(),
    postalCode: (req.body.postalCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim()
  };

  // Ensure we have valid values before insertion
  const insertData = [
    formData.firstName || '',
    formData.lastName || '',
    formData.streetAddress || '',
    formData.city || '',
    formData.stateProvince || '',
    formData.postalCode || '',
    formData.country || '',
    formData.email || '',
    formData.phone || ''
  ];

  const validation = validateFormData(req.body as Record<string, string>);
  
  if (!validation.isValid) {
    res.status(400).render('contact-form', {
      errors: validation.errors,
      formData,
      title: 'Contact Form - Please Fix Errors'
    });
    return;
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(insertData);
    
    stmt.free();
    saveDatabase();
  }

  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`
Received ${signal}. Starting graceful shutdown...`);
  
  if (db) {
    db.close();
    console.log('Database connection closed.');
  }
  
  if (serverInstance) {
    serverInstance.close(() => {
      console.log('Express server closed.');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Initialize database and start server
async function startServer(): Promise<void> {
  await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Store server reference for graceful shutdown
  serverInstance = server;
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

export { app, db };
