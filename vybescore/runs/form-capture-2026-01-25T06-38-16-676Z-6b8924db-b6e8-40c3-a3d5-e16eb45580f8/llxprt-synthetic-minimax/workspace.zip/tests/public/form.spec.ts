import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import { app } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // Server will be started separately for testing
});

afterAll(() => {
  // Cleanup handled by test framework
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('Contact Information');
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip Code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email Address');
    expect(response.text).toContain('Phone Number');
  });

  it('persists submission and redirects', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(testData)
      .expect(302); // Expect redirect
    
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({})
      .expect(400);
    
    expect(response.text).toContain('Please fix the following errors');
  });

  it('validates email format', async () => {
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(testData)
      .expect(400);
    
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('renders thank-you page', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);
    
    expect(response.text).toContain('Thank You So Much!');
    expect(response.text).toContain('Congratulations');
  });
});

afterAll(() => {
  // Cleanup handled by test framework
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
