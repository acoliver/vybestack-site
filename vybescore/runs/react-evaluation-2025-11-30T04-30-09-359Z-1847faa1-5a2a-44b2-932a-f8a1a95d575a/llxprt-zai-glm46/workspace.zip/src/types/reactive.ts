/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  dependents: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependent(subject: SubjectR | ObserverR, dependent: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(dependent)
}

export function removeDependent(subject: SubjectR | ObserverR, dependent: ObserverR): void {
  if (subject.dependents) {
    subject.dependents.delete(dependent)
  }
}

export function notifyDependents(subject: SubjectR | ObserverR): void {
  if (subject.dependents) {
    for (const dependent of subject.dependents) {
      if ('updateFn' in dependent && 'value' in dependent) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
  }
}