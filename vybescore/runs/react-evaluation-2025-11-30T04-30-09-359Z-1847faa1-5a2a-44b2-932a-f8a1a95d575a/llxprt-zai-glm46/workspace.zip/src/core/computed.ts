/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  addDependent,
  notifyDependents,
  EqualFn,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? (a, b) => a === b 
    : equal === false 
    ? undefined 
    : typeof equal === 'function' 
    ? equal 
    : undefined

  let currentValue = value
  let isComputing = false
  
  const o: Observer<T> & { dependents: Set<ObserverR> } = {
    name: options?.name,
    value: currentValue,
    dependents: new Set(),
    updateFn: (prevValue) => {
      if (isComputing) return prevValue as T
      isComputing = true
      setActiveObserver(o)
      try {
        const newValue = updateFn(prevValue)
        if (currentValue === undefined || !equalFn || !equalFn(currentValue, newValue)) {
          currentValue = newValue
          o.value = currentValue
          // Notify dependents when value changes
          notifyDependents(o)
        }
        return currentValue as T
      } finally {
        isComputing = false
        setActiveObserver(undefined)
      }
    },
  }
  
  // Initial computation
  updateObserver(o)
  
  return (): T => {
    // Register this computed value as a dependency of the current observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addDependent(o, activeObserver)
    }
    
    return currentValue as T
  }
}