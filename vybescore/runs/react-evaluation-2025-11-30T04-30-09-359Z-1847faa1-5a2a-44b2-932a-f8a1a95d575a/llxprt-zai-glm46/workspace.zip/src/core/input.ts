/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addDependent,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? (a, b) => a === b 
    : equal === false 
    ? undefined 
    : typeof equal === 'function' 
    ? equal 
    : undefined

  const s: Subject<T> = {
    name: options?.name,
    dependents: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addDependent(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    notifyDependents(s)
    return s.value
  }

  return [read, write]
}