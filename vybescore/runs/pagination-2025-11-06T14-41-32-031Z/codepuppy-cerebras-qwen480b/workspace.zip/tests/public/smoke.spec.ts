import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: import('sql.js').Database;
  let app: import('express').Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  describe('pagination basic behavior', () => {
    it('returns default pagination with page 1 and limit 5', async () => {
      const response = await request(app).get('/inventory');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(5);
      expect(response.body.items).toHaveLength(5);
      expect(response.body.total).toBe(15); // Total items in seed data
      expect(response.body.hasNext).toBe(true);
    });

    it('returns correct items for page 1', async () => {
      const response = await request(app).get('/inventory?page=1&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.items).toHaveLength(5);
      // Should return items with IDs 1-5
      const itemIds = response.body.items.map((item: { id: number }) => item.id);
      expect(itemIds).toEqual([1, 2, 3, 4, 5]);
    });

    it('returns correct items for page 2', async () => {
      const response = await request(app).get('/inventory?page=2&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(2);
      expect(response.body.items).toHaveLength(5);
      // Should return items with IDs 6-10
      const itemIds = response.body.items.map((item: { id: number }) => item.id);
      expect(itemIds).toEqual([6, 7, 8, 9, 10]);
    });

    it('returns correct items for page 3 (last page)', async () => {
      const response = await request(app).get('/inventory?page=3&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(3);
      expect(response.body.items).toHaveLength(5);
      // Should return items with IDs 11-15
      const itemIds = response.body.items.map((item: { id: number }) => item.id);
      expect(itemIds).toEqual([11, 12, 13, 14, 15]);
      expect(response.body.hasNext).toBe(false);
    });

    it('returns empty result for page beyond available data', async () => {
      const response = await request(app).get('/inventory?page=4&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(4);
      expect(response.body.items).toHaveLength(0);
      expect(response.body.hasNext).toBe(false);
    });

    it('handles different limit values correctly', async () => {
      const response = await request(app).get('/inventory?page=1&limit=3');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(3);
      expect(response.body.items).toHaveLength(3);
      const itemIds = response.body.items.map((item: { id: number }) => item.id);
      expect(itemIds).toEqual([1, 2, 3]);
      expect(response.body.hasNext).toBe(true);
    });
  });

  describe('input validation', () => {
    it('rejects non-numeric page parameter', async () => {
      const response = await request(app).get('/inventory?page=abc');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page parameter must be a valid number');
    });

    it('rejects non-numeric limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=xyz');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit parameter must be a valid number');
    });

    it('rejects negative page parameter', async () => {
      const response = await request(app).get('/inventory?page=-1');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page parameter must be greater than 0');
    });

    it('rejects zero page parameter', async () => {
      const response = await request(app).get('/inventory?page=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page parameter must be greater than 0');
    });

    it('rejects negative limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=-5');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit parameter must be greater than 0');
    });

    it('rejects zero limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit parameter must be greater than 0');
    });

    it('rejects excessively large limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=101');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Limit cannot exceed 100');
    });

    it('rejects excessively large page parameter', async () => {
      const response = await request(app).get('/inventory?page=10001');
      expect(response.status).toBe(400);
      expect(response.body.error).toBe('Page cannot exceed 10000');
    });
  });

  describe('pagination metadata', () => {
    it('returns correct structure for incomplete last page', async () => {
      const response = await request(app).get('/inventory?page=1&limit=7');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(7);
      expect(response.body.items).toHaveLength(7);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
    });

    it('returns correct metadata for exact division', async () => {
      const response = await request(app).get('/inventory?page=1&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.total).toBe(15);
      expect(response.body.hasNext).toBe(true);
    });
  });
});
