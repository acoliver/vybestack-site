/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Normalize: replace multiple spaces with single space, but be careful with sentence endings
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence terminators (if missing, add one space)
  result = result.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Split by sentence terminators, but keep them in the array
  const sentences = result.split(/([.?!])/);
  
  // Rebuild with proper capitalization
  let newResult = '';
  let shouldCapitalize = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i].trim();
    
    if (!part) continue;
    
    // If it's a sentence terminator, add it and mark next part for capitalization
    if (/[.?!]/.test(part)) {
      newResult += part + ' ';
      shouldCapitalize = true;
    } else if (shouldCapitalize) {
      // Capitalize the first character of the sentence
      const capitalized = part.charAt(0).toUpperCase() + part.slice(1);
      newResult += capitalized;
      shouldCapitalize = false;
    } else {
      // Regular word, just add it
      newResult += part;
    }
  }
  
  return newResult.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern that matches:
  // - http:// or https:// schemes
  // - www. without scheme
  // - domain names with various TLDs
  // - optional paths, query strings, fragments
  // - excludes trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+?(?=[,.!?;:)]?(?:\s|$))/gi;
  
  const matches = text.match(urlRegex);
  return matches || [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https:// but don't touch already secure URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // First upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then process docs URLs
  result = result.replace(
    /https:\/\/(?:example\.com)(\/docs\/[^\s?&]*)(?![^\s]*\?(?:[^&]*&)*(?:[^&]*=))/gi,
    (match, path) => {
      // Check if path contains dynamic hints or legacy extensions
      const isDynamic = /\/cgi-bin|[?&=]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
      
      if (isDynamic) {
        // Keep the original host, just ensure https
        return match;
      } else {
        // Rewrite to docs.example.com
        return `https://docs.example.com${path}`;
      }
    }
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for day based on month
  const maxDay = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  
  // Special case for February in non-leap years
  if (month === 2 && day === 29) {
    // Check if it's a leap year
    const yearNum = parseInt(year, 10);
    if (!(yearNum % 400 === 0 || (yearNum % 100 !== 0 && yearNum % 4 === 0))) {
      return 'N/A';
    }
  } else if (day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
