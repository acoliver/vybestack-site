export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: allows letters, digits, + tag, dots, hyphens
  // Domain: letter/digit/hyphen segments, no underscores, no trailing dots, no double dots
  const emailRegex = /^[a-zA-Z0-9]+([+\-_][a-zA-Z0-9]+)*(\.[a-zA-Z0-9]+([+\-_][a-zA-Z0-9]+)*)*@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all whitespace first
  const cleanedValue = value.replace(/\s+/g, '');
  
  // Support optional +1 country code
  const phoneRegex = /^(\+1)?[()\s-]*([2-9]\d{2})[()\s-]*[2-9]\d{2}[()\s-]*\d{4}$/;
  
  // Check if the format is valid
  if (!phoneRegex.test(cleanedValue)) {
    return false;
  }
  
  // Extract just the digits to check minimum length
  const digitsOnly = cleanedValue.replace(/\D/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace for validation
  const cleanedValue = value.replace(/\s+/g, '');
  
  // Regex for Argentine phone numbers
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code is omitted)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?0?(\d?9)?([1-9]\d{1,3})[\s-]?(\d{6,8})$/;
  
  const match = cleanedValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  // If no country code, ensure trunk prefix 0 is present
  const hasCountryCode = match[1] !== undefined;
  if (!hasCountryCode && !cleanedValue.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols (except apostrophe and hyphen), and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-]+(?: [\p{L}\p{M}'\-]+)*$/u;
  
  // Additional check to make sure it doesn't contain digits or special symbols
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that look like "X Æ A-12" (contains digits mixed with letters)
  const hasDigitsAndLetters = /\d.*[\p{L}]|[\p{L}].*\d/u;
  if (hasDigitsAndLetters.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  // Check for Mastercard (16 digits, starts with 51-55 or 2221-2720)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|\d{3,})\d{12}$/;
  // Check for AmEx (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Ensure digits pass one of the card format checks
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digits);
}
