/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  const matches = [...text.matchAll(prefixedWordRegex)].map(match => match[0]);
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a pattern to find digit+token combinations, not at start of string
  // This captures the digit and token together
  const embeddedTokenRegex = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  // Find all matches, but only include those not at the start of the string
  while ((match = embeddedTokenRegex.exec(text)) !== null) {
    const index = match.index;
    // Only include if not at the start of the string
    if (index > 0) {
      matches.push(match[0]); // Return the full match (digit + token)
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for whitespace (should not contain any)
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This pattern checks for sequences of 2-4 characters that are repeated immediately
  const repeatedSequenceRegex = /(.{1,4})\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regular expression pattern
  // Matches:
  // - Standard IPv6 (e.g., 2001:db8:85a3:0000:0000:8a2e:0370:7334)
  // - Shorthand IPv6 with :: (e.g., 2001:db8::1)
  // - IPv6 with embedded IPv4 (e.g., 2001:db8::192.0.2.33)
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?:[0-9a-fA-F]{1,4}:){1,7}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // IPv4 regular expression (to exclude these cases)
  const ipv4Regex = /(?:\d{1,3}\.){3}\d{1,3}/;
  
  // First check if this looks like an IPv4 address (simple case)
  // If it is IPv4, return false immediately
  if (ipv4Regex.test(value) && !ipv6Regex.test(value)) {
    return false;
  }
  
  // Test for IPv6
  return ipv6Regex.test(value);
}