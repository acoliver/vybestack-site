import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  const handlePrevious = () => {
    if (page > 1) setPage(page - 1);
  };

  const handleNext = () => {
    if (data?.hasNext) setPage(page + 1);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      {data.items.length > 0 ? (
        <>
          <InventoryList items={data.items} />
          <div>
            <button onClick={handlePrevious} disabled={page <= 1}>
              Previous
            </button>
            <span>Page {data.page}</span>
            <button onClick={handleNext} disabled={!data.hasNext}>
              Next
            </button>
          </div>
        </>
      ) : (
        <p>No items found.</p>
      )}
    </section>
  );
}
