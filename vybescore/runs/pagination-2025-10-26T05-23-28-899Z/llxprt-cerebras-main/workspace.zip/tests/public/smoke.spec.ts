import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns paginated inventory rows with correct metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    expect(response1.status).toBe(200);
    expect(response1.body.items).toHaveLength(5);
    expect(response1.body.page).toBe(1);
    expect(response1.body.limit).toBe(5);
    expect(response1.body.total).toBe(15);
    expect(response1.body.hasNext).toBe(true);
    
    // Get second page
    const response2 = await request(app).get('/inventory?page=2&limit=5');
    expect(response2.status).toBe(200);
    expect(response2.body.items).toHaveLength(5);
    expect(response2.body.page).toBe(2);
    expect(response2.body.limit).toBe(5);
    expect(response2.body.total).toBe(15);
    expect(response2.body.hasNext).toBe(true);
    
    // Get third page
    const response3 = await request(app).get('/inventory?page=3&limit=5');
    expect(response3.status).toBe(200);
    expect(response3.body.items).toHaveLength(5);
    expect(response3.body.page).toBe(3);
    expect(response3.body.limit).toBe(5);
    expect(response3.body.total).toBe(15);
    expect(response3.body.hasNext).toBe(false);
  });

  it('validates query parameters correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test invalid page parameter (negative number)
    const response1 = await request(app).get('/inventory?page=-1&limit=5');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toBe('Invalid page parameter. Must be a positive integer.');
    
    // Test invalid page parameter (non-integer)
    const response2 = await request(app).get('/inventory?page=1.5&limit=5');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toBe('Invalid page parameter. Must be a positive integer.');
    
    // Test invalid limit parameter (zero)
    const response3 = await request(app).get('/inventory?page=1&limit=0');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toBe('Invalid limit parameter. Must be a positive integer not exceeding 100.');
    
    // Test invalid limit parameter (exceeds maximum)
    const response4 = await request(app).get('/inventory?page=1&limit=101');
    expect(response4.status).toBe(400);
    expect(response4.body.error).toBe('Invalid limit parameter. Must be a positive integer not exceeding 100.');
  });
});
