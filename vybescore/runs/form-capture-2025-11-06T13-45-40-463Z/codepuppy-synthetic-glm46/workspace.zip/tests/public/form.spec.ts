import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Set test environment variable
  process.env.NODE_ENV = 'test';
  
  // Start the server manually
  const { startServer } = await import('../../dist/server.js');
  await startServer();
  
  // Wait for server to be ready
  await new Promise<void>(resolve => setTimeout(resolve, 2000));
});

afterAll(async () => {
  const { shutdownGracefully } = await import('../../dist/server.js');
  // Clean up resources
  shutdownGracefully('test complete');
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3000')
      .get('/');
    
    expect(response.status).toBe(200);
    
    const htmlContent = response.text || response.body;
    expect(htmlContent).toBeDefined();
    
    const $ = cheerio.load(htmlContent);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62704',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1-555-123-4567'
    };
    
    const response = await request('http://localhost:3000')
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=John/);
    
    // Check if database file was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify the thank-you page loads
    const thankYouResponse = await request('http://localhost:3000')
      .get(response.headers.location!);
    
    expect(thankYouResponse.status).toBe(200);
    
    const htmlContent = thankYouResponse.text || thankYouResponse.body;
    const $ = cheerio.load(htmlContent);
    expect($('h1').text()).toContain('Thank you, John!');
  });
});
