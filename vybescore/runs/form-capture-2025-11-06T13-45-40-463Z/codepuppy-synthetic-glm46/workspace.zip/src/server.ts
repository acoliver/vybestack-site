import express, { Request, Response, RequestHandler } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs from 'sql.js';
import { fileURLToPath } from 'url';

// ES module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

// SQL.js types (inline to avoid module import issues)
interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  get(...params: unknown[]): unknown;
  all(...params: unknown[]): unknown[];
  free(): void;
}

interface SqlJsStatic {
  Database: new(data?: Uint8Array) => Database;
}

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, `../node_modules/sql.js/dist/${file}`)
    }) as SqlJsStatic;

    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Try to load existing database or create new one
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }

    db = new SQL.Database(dbData || undefined);

    // Read and execute schema
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      if (db) {
        db.run(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Validation functions
function validateFormData(data: Partial<FormData>): { errors: FormErrors; isValid: boolean } {
  const errors: FormErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field]!.trim() === '') {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required.`;
    }
  });

  // Email validation
  if (data.email && !/^\S+@\S+\.\S+$/.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }

  // Phone validation - allow international formats
  if (data.phone && !/^[+]?[\d\s\-()]+$/.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number with digits, spaces, parentheses, dashes, and optional leading +.';
  }

  // Postal code validation - accept alphanumeric
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code (letters, numbers, spaces, and dashes allowed).';
  }

  return {
    errors,
    isValid: Object.keys(errors).length === 0
  };
}

// Routes
const showForm: RequestHandler = (req: Request, res: Response): void => {
  res.render('form', {
    errors: [],
    values: {}
  });
};

const submitForm: RequestHandler = (req: Request, res: Response): void => {
  const formData = req.body as FormData;
  
  const { errors, isValid } = validateFormData(formData);

  if (!isValid) {
    res.status(400);
    res.render('form', {
      errors: Object.values(errors),
      values: formData
    });
    return;
  }

  // Insert into database
  if (!db) {
    console.error('Database not initialized');
    res.status(500).render('form', {
      errors: ['Database error occurred. Please try again.'],
      values: formData
    });
    return;
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    ]);
    
    stmt.free();
    saveDatabase();
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['Database error occurred. Please try again.'],
      values: formData
    });
    return;
  }

  // Redirect to thank-you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
};

const showThankYou: RequestHandler = (req: Request, res: Response): void => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
};

app.get('/', showForm);
app.post('/submit', submitForm);
app.get('/thank-you', showThankYou);

// Graceful shutdown
let server: unknown = null;

function shutdownGracefully(signal: string): void {
  console.log(`\nReceived ${signal}. Shutting down gracefully...`);
  
  if (server) {
    (server as { close: (callback: () => void) => void }).close(() => {
      console.log('HTTP server closed.');
    });
  }
  
  if (db) {
    try {
      db.close();
      console.log('Database connection closed.');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  // Don't call process.exit in test environment
  if (process.env.NODE_ENV !== 'test') {
    process.exit(0);
  }
}

// Start server function that can be called from tests
export async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully.');
    
    server = app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
    
    process.on('SIGTERM', () => shutdownGracefully('SIGTERM'));
    process.on('SIGINT', () => shutdownGracefully('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export functions for testing
export { initializeDatabase, shutdownGracefully };

// Auto-start server only if not in test environment
if (process.env.NODE_ENV !== 'test') {
  startServer();
}