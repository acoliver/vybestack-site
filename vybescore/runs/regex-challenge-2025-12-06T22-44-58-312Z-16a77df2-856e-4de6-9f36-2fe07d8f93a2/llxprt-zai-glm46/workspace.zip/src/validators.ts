export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict RFC compliance.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for obvious invalid patterns first
  if (!value || value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Domain cannot contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be at least 10 digits (US number) and at most 11 if includes +1 country code
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (US country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract the 10-digit number (remove country code if present)
  const number10 = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Area code cannot start with 0 or 1
  const areaCode = number10.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with common separators
  const phoneRegex = /^(\+?1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)[2-9]\d{2}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Optional +54 country code, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits (leading 1-9)
  // Subscriber number: 6-8 digits total after area code
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix before area code
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Total subscriber digits (area code + subscriber number) must be reasonable
  const totalSubscriberDigits = areaCode.length + subscriberNumber.length;
  if (totalSubscriberDigits < 8 || totalSubscriberDigits > 12) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and multiple consecutive spaces/hyphens/apostrophes
  const nameRegex = /^[\p{L}\p{M}]+(?:['\-\s][\p{L}\p{M}]+)*$/u;
  
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Reject names with consecutive separators
  if (value.includes("  ") || value.includes("--") || value.includes("''")) {
    return false;
  }
  
  // Reject names that start or end with separators
  if (value.startsWith(" ") || value.startsWith("-") || value.startsWith("'") ||
      value.endsWith(" ") || value.endsWith("-") || value.endsWith("'")) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Helper function to perform Luhn checksum validation for credit card numbers.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be 13-19 digits for major cards
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Validate card prefixes and lengths
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{4})|(2[2-9]\d{3})|(2[0-1]\d{2})|(22[0-2]\d{1})|(22[3-9]\d{0})|(2[3-6]\d{2})|(27[0-1]\d{1}))\d{10}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  const isValidPrefix = visaRegex.test(digitsOnly) || 
                       mastercardRegex.test(digitsOnly) || 
                       amexRegex.test(digitsOnly);
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}