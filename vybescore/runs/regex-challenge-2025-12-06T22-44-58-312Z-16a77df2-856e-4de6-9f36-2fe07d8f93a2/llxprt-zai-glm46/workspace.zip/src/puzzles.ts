/**
 * Find words beginning with the given prefix, excluding the listed exception words.
 * Uses word boundaries to match complete words only.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary regex for the prefix
  // This matches words that start with the prefix
  const prefixRegex = new RegExp(`\\b${escapeRegex(prefix)}\\w*`, 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions and return unique results
  const result = matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptions.includes(word.toLowerCase()));
  
  // Remove duplicates while preserving order
  return [...new Set(result)];
}

/**
 * Helper function to escape special regex characters in the prefix.
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to find embedded tokens.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = escapeRegex(token);
  
  // Find digit+token combinations
  const digitTokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const digitTokenMatches = text.match(digitTokenRegex) || [];
  
  return digitTokenMatches;
}

/**
 * Validate passwords according to security policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace and no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character classes
  if (!/[A-Z]/.test(value)) { // Uppercase
    return false;
  }
  
  if (!/[a-z]/.test(value)) { // Lowercase
    return false;
  }
  
  if (!/\d/.test(value)) { // Digit
    return false;
  }
  
  if (!/[^A-Za-z0-9]/.test(value)) { // Symbol/special character
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212, etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 * Returns true if IPv6 address is found, false for IPv4 only or no matches.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex for exclusion
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Comprehensive IPv6 regex that includes shorthand notation
  // Matches full IPv6, compressed IPv6 with ::, and mixed notation
  const ipv6Regex = /(?:^|(?<=[^\w:.]))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/g;
  
  // First check if there's an IPv4 pattern that could be confused with IPv6
  const hasIPv4 = ipv4Regex.test(value);
  
  // Find all IPv6 matches
  const ipv6Matches = value.match(ipv6Regex);
  
  if (!ipv6Matches) {
    return false;
  }
  
  // If we found IPv4 but no pure IPv6 patterns that aren't also IPv4-like, return false
  if (hasIPv4 && ipv6Matches.every(match => ipv4Regex.test(match))) {
    return false;
  }
  
  return true;
}