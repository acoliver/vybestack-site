/**
 * Capitalize the first character of each sentence after .?! punctuation.
 * Insert exactly one space between sentences and collapse extra spaces.
 * Preserves abbreviations when possible by avoiding sentence breaks after single letters.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after punctuation if missing and next character is a letter
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Split into sentences using . ? or ! as boundaries
  // This approach ensures we handle text between punctuation correctly
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    
    if (/[.!?]/.test(char)) {
      // This is punctuation - add it and mark next character for capitalization
      result += char;
      capitalizeNext = true;
    } else if (capitalizeNext && /[a-zA-Z]/.test(char)) {
      // This is the first letter after punctuation, capitalize it
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      // Regular character, add as-is and ensure we don't capitalize mid-word
      result += char;
      if (/[a-zA-Z]/.test(char)) {
        capitalizeNext = false;
      }
    }
  }
  
  return result;
}

/**
 * Extract all URLs from the given text, returning them without trailing punctuation.
 * Supports HTTP/HTTPS protocols and common domain patterns.
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs
  // Matches http:// or https:// protocol
  // Followed by domain name with optional subdomains
  // Optional port number
  // Optional path, query, and fragment
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation characters that are unlikely to be part of the URL
    return url.replace(/[.,;:!?()[\]{}"']+$/g, '');
  }).filter(url => url.length > 0); // Filter out any empty results
}

/**
 * Force all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only for actual URLs (not just the string "http://")
  // Use word boundary to avoid replacing within other strings
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs from http://example.com/docs/... to https://docs.example.com/...
 * Always upgrades to HTTPS, and rewrites host for docs paths unless they contain
 * dynamic hints (cgi-bin, query strings, or legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs that need rewriting
  // Matches http://example.com/... where path starts with /docs/
  // But excludes URLs with dynamic hints or legacy extensions
  const urlRegex = /\bhttp:\/\/([^/\s]+)(\/docs\/[^\s]*?)(?=[\s]|$)/gi;
  
  return text.replace(urlRegex, (match, domain, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(?:\?|&|=|#|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
    
    if (hasDynamicHints) {
      // Don't rewrite the host, just upgrade to HTTPS
      return `https://${domain}${path}`;
    } else {
      // Rewrite to docs subdomain and upgrade to HTTPS
      return `https://docs.${domain}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day range for the month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const yearNum = parseInt(year, 10);
  
  // Check for leap year
  const isLeapYear = yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0);
  if (month === 2 && isLeapYear) {
    daysInMonth[1] = 29; // February has 29 days in leap year
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}