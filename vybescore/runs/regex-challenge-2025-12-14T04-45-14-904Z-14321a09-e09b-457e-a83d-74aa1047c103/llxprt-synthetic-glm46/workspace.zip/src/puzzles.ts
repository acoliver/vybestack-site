/**
 * Finds words beginning with the specified prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(exc => exc.toLowerCase());
  
  // Create regex to find words starting with the prefix (case-insensitive)
  // \b ensures we match whole words, [\w'-]+ matches word characters, hyphens, and apostrophes
  const wordRegex = new RegExp(`\\b[${prefix.charAt(0)}${prefix.charAt(0).toLowerCase()}][\\w'-]*`, 'gi');
  
  // Find all words matching the pattern
  const allMatches = text.match(wordRegex) || [];
  
  // Filter out the exceptions and words that don't actually start with the prefix
  const filteredWords = allMatches.filter(word => {
    const lowerWord = word.toLowerCase();
    
    // Check if the word actually starts with the prefix (case-insensitive)
    if (!lowerWord.startsWith(prefix.toLowerCase())) {
      return false;
    }
    
    // Check if the word is in the exceptions list
    if (lowerExceptions.includes(lowerWord)) {
      return false;
    }
    
    return true;
  });
  
  // Return unique words (case-insensitive deduplication)
  const uniqueWords = [];
  const seenWords = new Set();
  
  for (const word of filteredWords) {
    const lowerWord = word.toLowerCase();
    if (!seenWords.has(lowerWord)) {
      seenWords.add(lowerWord);
      uniqueWords.push(word);
    }
  }
  
  return uniqueWords;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds as required.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of token, but with special handling for those after digits
  // First find all full occurrences of the token
  const allTokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const digitTokenMatches = text.match(allTokenRegex) || [];
  
  // Extract just the token part from each match (remove the digit)
  const result: string[] = [];
  for (const match of digitTokenMatches) {
    // Remove the leading digit
    const tokenOnly = match.substring(1);
    if (tokenOnly === token) {
      result.push(match);
    }
  }
  
  // Return unique matches
  return [...new Set(result)];
}

/**
 * Validates passwords according to strong password policy.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This catches patterns like "abab", "123123", "abcabc", etc.
  for (let i = 0; i < value.length / 2; i++) {
    const firstHalf = value.substring(i, i + Math.floor((value.length - i) / 2));
    const secondHalfStart = i + Math.floor((value.length - i) / 2);
    const secondHalf = value.substring(secondHalfStart, secondHalfStart + firstHalf.length);
    
    if (firstHalf === secondHalf && firstHalf.length >= 2) {
      return false;
    }
  }
  
  // Alternative approach for repeated sequences: catch any 2+ character sequence that repeats immediately
  const repeatedPatternRegex = /(..).*\1/;
  if (repeatedPatternRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation) and excludes IPv4 addresses.
 * Returns true if the text contains a valid IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Define regex patterns for IPv6
  // Full IPv6 format: eight groups of four hexadecimal digits
  const ipv6FullRegex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed IPv6 format: with :: for consecutive zero groups
  const ipv6CompressedRegex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv4-mapped IPv6: ::ffff:192.0.2.128
  const ipv6MappedIPv4Regex = /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Special IPv6 loopback and unspecified addresses
  const ipv6Specials = /\b::1\b|\b::\b/;
  
  // IPv4 regex (to ensure we're not matching these)
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if we have IPv6-like patterns
  const hasIPv6Pattern = ipv6FullRegex.test(value) || 
                        ipv6CompressedRegex.test(value) || 
                        ipv6MappedIPv4Regex.test(value) || 
                        ipv6Specials.test(value);
  
  if (!hasIPv6Pattern) {
    return false;
  }
  
  // Extract potential IPv6 addresses and validate them individually
  // This helps avoid false positives on IPv4 addresses that might have matched
  const potentialIPv6s = value.match(/(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}(?:[.:][0-9a-fA-F.]*)?/g) || [];
  
  for (const match of potentialIPv6s) {
    // Skip if this is an IPv4 address with extra characters
    if (ipv4Regex.test(match.replace(/\s/g, '')) && !match.includes(':')) {
      continue;
    }
    
    // Check if this matches our IPv6 patterns
    if (ipv6FullRegex.test(match) || 
        ipv6CompressedRegex.test(match) || 
        ipv6MappedIPv4Regex.test(match) || 
        ipv6Specials.test(match)) {
      return true;
    }
  }
  
  return false;
}