export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common rules.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Email should have exactly one @ and no spaces
  if (value.indexOf(' ') !== -1 || value.split('@').length !== 2) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Validate local part
  // Cannot be empty, start or end with dot, or have consecutive dots
  if (!localPart || localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // Local part allows letters, digits, underscores, hyphens, plus signs, and dots
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localRegex.test(localPart)) {
    return false;
  }
  
  // Validate domain part
  if (!domain || domain.startsWith('.') || domain.endsWith('.') || domain.includes('..')) {
    return false;
  }
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // For Internationalized Domain Names (IDN), allow punycode format and unicode
  // But stick to basic ASCII for simplicity as per requirements
  const domainRegex = /^[a-zA-Z0-9.-]+$/;
  if (!domainRegex.test(domain)) {
    return false;
  }
  
  // Domain should have at least one dot to separate TLD
  if (!domain.includes('.')) {
    return false;
  }
  
  // Check if any part of the domain is empty (e.g., example..com)
  const domainParts = domain.split('.');
  if (domainParts.some(part => !part)) {
    return false;
  }
  
  // TLD should be reasonable length (2-63 characters)
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2 || tld.length > 63) {
    return false;
  }
  
  // Final validation using more comprehensive regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // options parameter accepted but not used
  void options;
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters for parsing
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length after removing non-digits
  // US phone numbers should have 10 digits (without country code) or 11 (with country code)
  if (digits.length < 10) {
    return false;
  }
  
  // If there are 11 digits, the first should be '1' for US country code
  let phoneNumberDigits = digits;
  
  if (digits.length === 11) {
    if (digits[0] !== '1') {
      return false; // Invalid country code
    }
    phoneNumberDigits = digits.substring(1);
  } else if (digits.length > 11) {
    return false; // Too many digits
  }
  
  // Check area code - cannot start with 0 or 1
  if (phoneNumberDigits[0] === '0' || phoneNumberDigits[0] === '1') {
    return false;
  }
  
  // Validate with regex pattern
  // Accepts formats like:
  // +1 (212) 555-7890
  // 212-555-7890
  // 212.555.7890
  // 212 555 7890
  // (212) 555-7890
  // 2125557890
  const usPhoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)\s?|[2-9]\d{2}[-.\s]?)[2-9]\d{2}[-.\s]?\d{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers in various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2-4 digits (leading digit 1-9).
 * - Subscriber number must contain 6-8 digits.
 * - When country code is omitted, number must begin with trunk prefix 0.
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all spaces and hyphens for validation
  const normalizedValue = value.replace(/[\s-]/g, '');
  
  // Check basic pattern
  // Either starts with +54 or with 0 (trunk prefix if country code is omitted)
  const argPhoneRegex = /^(\+54)?(0?9?)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = normalizedValue.match(argPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const countryCode = match[1];  // +54 or undefined
  const prefixParts = match[2]; // Optional 09, 9, 0, or undefined
  const areaCode = match[3];    // 2-4 digits, starts with 1-9
  const subscriberNumber = match[4]; // 6-8 digits
  
  // If country code is absent, must start with trunk prefix (0)
  if (!countryCode && !prefixParts.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate with comprehensive regex that checks the input format directly
  // This regex handles proper spacing and hyphens
  const argPhoneFormatRegex = /^(\+54\s?)?9?\s?([1-9]\d{1,3})\s?(\d{3,4})\s?(\d{4})$|^0([1-9]\d{1,3})[-\s]?(\d{3,4})(\d{4})$/;
  return argPhoneFormatRegex.test(value) || argPhoneRegex.test(normalizedValue);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Accepts names like "John O'Neill", "José Martínez", "Mary-Jane Watson".
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Should contain at least one letter
  if (!/[a-zA-Z\u00C0-\u017F]/.test(value)) {
    return false;
  }
  
  // Reject names with consecutive dots or names that start/end with hyphens or apostrophes
  if (value.includes("..") || value.includes("--") || 
      value.startsWith("-") || value.endsWith("-") || 
      value.startsWith("'") || value.endsWith("'") ||
      /^\s|\s$/.test(value)  // Leading or trailing spaces
     ) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Also allow periods for initials like "J.R.R. Tolkien"
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\s'’.-]+$/;
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that contain only special characters or spaces
  const lettersOnly = value.replace(/[^a-zA-Z\u00C0-\u017F]/g, '');
  const specialCharsOnly = value.replace(/[a-zA-Z\u00C0-\u017F\s]/g, '');
  
  // Should have more letters than special characters
  if (specialCharsOnly.length > lettersOnly.length / 2) {
    return false;
  }
  
  // Reject names that contain unusual characters like Æ which are uncommon in names
  // We're focusing on common name patterns
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Checks valid prefixes, lengths, and validates with Luhn checksum.
 */ 
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const cleanedValue = value.replace(/\D/g, '');
  
  // Check basic length requirements
  if (cleanedValue.length < 13 || cleanedValue.length > 19) {
    return false;
  }
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanedValue)) {
    return false;
  }
  
  // Card validation patterns
  const visaRegex = /^4[0-9]{12,18}$/;        // Visa: 13-19 digits, starts with 4
  const mastercardRegex = /^5[1-5][0-9]{14}$|^2[2-7][0-9]{14}$/;  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const amexRegex = /^3[47][0-9]{13}$/;       // AmEx: 15 digits, starts with 34 or 37
  const discoverRegex = /^6(?:011|5[0-9]{2})[0-9]{12}$/;  // Discover: 16 digits
  
  // Check if the card matches any known pattern
  const isValidFormat = visaRegex.test(cleanedValue) || 
                        mastercardRegex.test(cleanedValue) || 
                        amexRegex.test(cleanedValue) ||
                        discoverRegex.test(cleanedValue);
                        
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return luhnCheck(cleanedValue);
}

/**
 * Helper function to perform Luhn algorithm checksum validation
 */
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    // Double every second digit (from right)
    if (isEven) {
      digit *= 2;
      
      // If doubling results in a two-digit number, add its digits
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
