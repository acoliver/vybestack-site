/**
 * Capitalizes the first character of each sentence.
 * Capitalizes after .!? punctuation, ensures exactly one space between sentences,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // First, normalize spacing: replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence-ending punctuation
  // This ensures exactly one space after ., !, and ?
  result = result.replace(/([.!?])\s*/g, '$1 ');
  
  // Trim any leading or trailing spaces
  result = result.trim();
  
  // Capitalize the first character
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Split the text by sentence boundaries and process each sentence
  // We'll use a regex that matches sentence-ending punctuation that's not part of an abbreviation
  const sentences = result.split(/(?<=[.!?])(?=(?:[^a-zA-Z]|$))(?!(?:(?:(?:Mrs|Mr|Ms|Dr|Prof|St|Ave|Blvd|Rd|etc)\.?)(?:\s|$)))/g);
  
  // Process each sentence to capitalize the first letter
  result = sentences.map((sentence) => {
    // Trim extra spaces
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';
    
    // Don't re-capitalize if this looks like an abbreviation sentence
    // Check if the sentence begins with a known abbreviation
    const lowerCaseFirstWord = trimmed.split(/\s+/)[0]?.toLowerCase();
    
    // If the first word is an abbreviation, lowercase it
    if (lowerCaseFirstWord && /^(mr|mrs|ms|dr|prof)$/i.test(lowerCaseFirstWord)) {
      return trimmed.charAt(0).toLowerCase() + trimmed.slice(1);
    }
    
    // Otherwise, capitalize the first character
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  }).join(' ');
  
  // Final cleanup: ensure no double spaces and proper sentence spacing
  return result.replace(/\s+/g, ' ');
}

/**
 * Extracts all URLs detected in the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // URL regex pattern matching http, https, and protocol-less URLs
  // This regex matches domain names, IP addresses, and various URL formats
  const urlRegex = /((?:https?:\/\/|www\.)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?)/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,;:!?)]}
    return url.replace(/[.,;!?)\]]+$/g, '');
  });
}

/**
 * Forces all http:// schemes to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Replace http:// with https:// but leave already https:// URLs unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrades http to https
 * - When the path begins with /docs/, rewrites the host to docs.example.com
 * - Skips host rewrite when path contains dynamic hints like cgi-bin or query strings
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // First ensure all URLs are using https
  let result = enforceHttps(text);
  
  // Split text by potential URLs
  // Use a simpler approach to avoid regex escaping issues
  result = result.replace(/https?:\/\/example\.com(\/[^\s]*)?/g, (match, path = '') => {
    // Ensure https
    let url = 'https://example.com' + path;
    
    // Check if the path starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check if path contains dynamic hints
      const dynamicHints = /\/cgi-bin|[?&=]|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)(?=[/?#]|$)/i;
      
      if (dynamicHints.test(path)) {
        // Keep original hostname but ensure https
        url = 'https://example.com' + path;
      } else {
        // Rewrite to docs.example.com
        url = 'https://docs.example.com' + path;
      }
    }
    
    return url;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from a date string in mm/dd/yyyy format.
 * Returns the year if the string is valid, otherwise returns 'N/A'.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format and extract year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract month, day, and year
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  // Check for valid day ranges per month
  const maxDaysPerMonth = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > (maxDaysPerMonth as Record<string, number>)[month]) {
    return 'N/A';
  }
  
  // Return the extracted year
  return year;
}