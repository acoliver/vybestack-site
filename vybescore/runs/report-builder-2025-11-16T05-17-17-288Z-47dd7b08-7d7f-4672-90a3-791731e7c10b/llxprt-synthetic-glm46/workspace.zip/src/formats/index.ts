import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { FormatType, RenderFunction } from '../types.js';

export const formatters: Record<FormatType, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};