import { RenderFunction, ReportData, RenderOptions } from '../types.js';

export const renderText: RenderFunction = (data: ReportData, options: RenderOptions): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);

  let output = `${data.title}
${data.summary}

Entries:
`;

  for (const entry of data.entries) {
    const amount = `$${entry.amount.toFixed(2)}`;
    output += `- ${entry.label}: ${amount}\n`;
  }

  if (options.includeTotals) {
    const totalAmount = `$${total.toFixed(2)}`;
    output += `\nTotal: ${totalAmount}\n`;
  }

  return output;
};