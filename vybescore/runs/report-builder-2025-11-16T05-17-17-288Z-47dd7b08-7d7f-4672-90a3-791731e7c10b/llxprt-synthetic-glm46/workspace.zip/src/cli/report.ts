#!/usr/bin/env node

import * as fs from 'fs';
import { ReportData, RenderOptions, FormatType } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliOptions {
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): [string, CliOptions] {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format option requires a value');
    process.exit(1);
  }

  const formatArg = args[formatIndex + 1] as FormatType;
  if (!['markdown', 'text'].includes(formatArg)) {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  const options: CliOptions = {
    format: formatArg,
    output: outputPath,
    includeTotals,
  };

  return [inputFile, options];
}

function parseJsonInput(filePath: string): ReportData {
  try {
    const jsonContent = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(jsonContent);

    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label" field');
      }

      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid "amount" field');
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to read file ${filePath}`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CliOptions): string {
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };

  const formatter = formatters[options.format];
  return formatter(data, renderOptions);
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    fs.writeFileSync(outputPath, content, 'utf-8');
    console.log(`Report written to ${outputPath}`);
  } else {
    console.log(content);
  }
}

function main(): void {
  const [inputFile, options] = parseArguments();

  try {
    const data = parseJsonInput(inputFile);
    const reportContent = renderReport(data, options);
    writeOutput(reportContent, options.output);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
