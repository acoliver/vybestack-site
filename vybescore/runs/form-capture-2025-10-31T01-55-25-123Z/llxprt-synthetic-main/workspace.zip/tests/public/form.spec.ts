import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let server: unknown;
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Import the server module for testing
const importServer = async () => {
  // Ensure no module cache issues
  const serverModule = await import('../../src/server.ts');
  app = serverModule.default;
  
  // Start server for testing
  server = app.listen(0); // Use random port
  
  // Make the server instance available globally for tests
  global.server = server;
  
  return server;
};

beforeAll(async () => {
  return importServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that all form fields are present
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'ABC123',
      country: 'Testland',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form
    const response = await request(server)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    
    // Check that the database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});