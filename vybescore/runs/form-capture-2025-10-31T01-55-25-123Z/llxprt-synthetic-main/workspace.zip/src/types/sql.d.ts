declare module 'sql.js' {
  export interface Database {
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): Statement;
    run(sql: string, ...params: unknown[]): unknown;
    exec(sql: string): QueryResults[];
  }

  export interface Statement {
    bind(values: unknown[]): void;
    run(values?: unknown[]): Statement;
    free(): void;
    get(): unknown | undefined;
  }

  export interface QueryResults {
    columns: string[];
    values: unknown[][];
  }

  export default function initSqlJs(): Promise<unknown>;
}

export interface Database {
  export(): Uint8Array;
  close(): void;
  prepare(sql: string): Statement;
  run(sql: string, ...params: unknown[]): unknown;
  exec(sql: string): QueryResults[];
}

export interface Statement {
  bind(values: unknown[]): void;
  run(values?: unknown[]): Statement;
  free(): void;
  get(): unknown | undefined;
}

export interface QueryResults {
  columns: string[];
  values: unknown[][];
}