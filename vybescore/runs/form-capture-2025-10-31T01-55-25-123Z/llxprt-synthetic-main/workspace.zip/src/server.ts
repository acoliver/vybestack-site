import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// @ts-expect-error - No types available for sql.js
import initSqlJs from 'sql.js';

// SQL.js type definition
interface Database {
  export(): Uint8Array;
  close(): void;
  prepare(sql: string): Statement;
  run(sql: string, ...params: unknown[]): unknown;
  exec(sql: string): QueryResults[];
}

interface Statement {
  bind(values: unknown[]): void;
  run(values?: unknown[]): Statement;
  free(): void;
  get(): unknown | undefined;
}

interface QueryResults {
  columns: string[];
  values: unknown[][];
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set view engine for EJS templates
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Helper functions for database operations
const initDb = async (): Promise<Database> => {
  const SQL = await initSqlJs();
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  let db: Database;
  
  try {
    // Try to load existing database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      // Create a new database
      db = new SQL.Database();
      
      // Initialize tables from schema
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      db.run(schemaSql);
      
      // Save the newly created database
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
  
  return db;
};

const saveDb = (db: Database): void => {
  try {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
};

// Initialize the database
let db: Database;
initDb().then(database => {
  db = database;
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

// Validation functions
const validateForm = (formData: Record<string, string>): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  // Required fields
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`);
    }
  }
  
  // Email validation
  if (formData.email && !(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))) {
    errors.push('Please provide a valid email address');
  }
  
  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
  if (formData.phone && !(/^[\+]?[0-9\(\)\s\-]+$/.test(formData.phone))) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  
  // Postal code validation - allow alphanumeric with spaces
  if (formData.postalCode && !(/^[a-zA-Z0-9\s]+$/.test(formData.postalCode))) {
    errors.push('Postal code can only contain letters, digits, and spaces');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

// Form route
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

// Form submission route
app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDb(db);
    
    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

// Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  // For a basic implementation, use a placeholder name
  // In a real app, we might retrieve this from session or database
  res.render('thank-you', { firstName: req.query.firstName || 'Friend' });
});

// Server startup logic with graceful shutdown
const startServer = async () => {
  const port = process.env.PORT || 3000;
  
  // The database should already be initialized, but let's wait for it
  if (!db) {
    await initDb().then(database => {
      db = database;
    }).catch(err => {
      console.error('Failed to initialize database:', err);
      throw err;
    });
  }
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Handle SIGTERM for graceful shutdown
  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully`);
    
    if (db) {
      db.close();
    }
    
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  
  return server;
};

// Export the app for testing
export default app;

// Start the server if this module is run directly (not for testing)
if (!module.parent) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}