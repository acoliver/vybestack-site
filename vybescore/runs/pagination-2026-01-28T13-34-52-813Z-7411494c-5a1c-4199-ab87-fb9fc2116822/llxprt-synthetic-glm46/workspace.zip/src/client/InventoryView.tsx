import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePreviousPage = (): void => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  const handleNextPage = (): void => {
    setCurrentPage((prev) => prev + 1);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error') {
    return (
      <div>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
        <button onClick={() => setCurrentPage(1)}>Retry</button>
      </div>
    );
  }

  if (!data) {
    return <p>No inventory data available.</p>;
  }

  const canGoPrevious = currentPage > 1;
  const canGoNext = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      {data.items.length === 0 ? (
        <p>No inventory items available.</p>
      ) : (
        <>
          <InventoryList items={data.items} />
          <nav>
            <button 
              onClick={handlePreviousPage} 
              disabled={!canGoPrevious}
              aria-label="Previous page"
            >
              Previous
            </button>
            <span>Page {data.page} of {Math.ceil(data.total / data.limit)}</span>
            <button 
              onClick={handleNextPage} 
              disabled={!canGoNext}
              aria-label="Next page"
            >
              Next
            </button>
          </nav>
          <p>Total items: {data.total}</p>
        </>
      )}
    </section>
  );
}


