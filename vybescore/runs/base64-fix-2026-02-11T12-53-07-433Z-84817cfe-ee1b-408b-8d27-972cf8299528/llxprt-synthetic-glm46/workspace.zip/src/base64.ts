const PADDING_REGEX = /=+$/;

/**
 * Encode plain text to Base64.
 * Uses standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Handles standard Base64 with proper padding.
 */
export function decode(input: string): string {
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
