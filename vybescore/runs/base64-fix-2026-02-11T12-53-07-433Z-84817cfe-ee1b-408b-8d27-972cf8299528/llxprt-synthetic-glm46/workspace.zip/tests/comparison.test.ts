import { describe, it, expect } from 'vitest';
import { 
  faultyEncode, 
  encodeCorrectly, 
  encodeFixed
} from '../src/fix-implementation.js';

// Test data
const testData = new Uint8Array([0, 2, 255, 192]);

describe('Base64 Encoding Comparison', () => {
  it('should show the difference between faulty and correct implementations', () => {
    console.log('=== COMPARISON: Faulty vs Correct Implementation ===');
    console.log('Test data:', Array.from(testData), '(should encode to "AAH/EA==")');
    
    // This will produce incorrect result with underscores
    const faultyResult = faultyEncode(testData);
    console.log('[ERROR] Faulty implementation:', faultyResult);
    console.log('   [ERROR] Contains underscores:', faultyResult.includes('_'));
    
    // This should produce correct result
    const correctResult = encodeCorrectly(testData);
    console.log('[OK] Correct implementation:', correctResult);
    console.log('   [OK] Ends with equal signs:', correctResult.endsWith('=='));
    console.log('   [OK] No underscores:', !correctResult.includes('_'));
    
    // The fixed implementation should match the correct one
    const fixedResult = encodeFixed(testData);
    console.log(' Fixed implementation:', fixedResult);
    
    // Verify the results
    expect(faultyResult).not.toBe(correctResult); // They should be different
    expect(fixedResult).toBe(correctResult); // Fixed should match correct
    expect(correctResult).toBe('AAH/EA=='); // Expected correct result
  });

  it('should handle various byte arrays correctly', () => {
    const testCases: Array<{data: Uint8Array, expected: string, description: string}> = [
      {
        data: new Uint8Array([70, 97, 99, 116, 111, 114, 121]),
        expected: 'RmFjdG9yeQ==',
        description: 'Simple text "Factory"'
      },
      {
        data: new Uint8Array([255]),
        expected: '/w==',
        description: 'Single byte that requires max padding'
      },
      {
        data: new Uint8Array([255, 255]),
        expected: '//8=',
        description: 'Two bytes that require some padding'
      },
      {
        data: new Uint8Array([72, 101, 108, 108, 111]),
        expected: 'SGVsbG8=',
        description: 'Simple text "Hello"'
      }
    ];

    console.log('\n=== COMPARISON: Multiple Test Cases ===');
    
    testCases.forEach(({data, expected, description}) => {
      console.log('\nTest case:', description);
      console.log('Input bytes:', Array.from(data));
      
      const faultyResult = faultyEncode(data);
      const correctResult = encodeCorrectly(data);
      const fixedResult = encodeFixed(data);
      
      console.log('[ERROR] Faulty:', faultyResult);
      console.log('[OK] Correct:', correctResult);
      console.log(' Fixed:', fixedResult);
      
      expect(fixedResult).toBe(correctResult);
      expect(correctResult).toBe(expected);
      
      if (faultyResult !== correctResult) {
        console.log(' Faulty implementation incorrectly replaced "=" with "_":', faultyResult.includes('_'));
      }
    });
  });
});