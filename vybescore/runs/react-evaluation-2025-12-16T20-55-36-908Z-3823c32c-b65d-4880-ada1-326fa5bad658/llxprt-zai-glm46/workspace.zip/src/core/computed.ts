/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean) | undefined,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name || 'computed',
    value,
    updateFn,
  }
  
  // Observers that depend on this computed value
  const dependents: ObserverR[] = []
  
  // Initialize the computed value
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    const currentObserver = getActiveObserver()
    
    if (currentObserver && currentObserver !== o) {
      // Another observer is accessing this computed, track the dependency
      if (!dependents.includes(currentObserver)) {
        dependents.push(currentObserver)
      }
    }
    
    return o.value!
  }
  
  // Override the observer's update function to handle notifying dependents
  const originalUpdateFn = o.updateFn
  o.updateFn = (currentValue?: T) => {
    const newValue = originalUpdateFn(currentValue)
    
    // Always notify dependents, even if value didn't change, because dependencies might have changed
    o.value = newValue
    
    // Notify all observers that depend on this computed
    const currentDependents = [...dependents] // Make a copy to avoid issues
    currentDependents.forEach(dependent => {
      updateObserver(dependent as Observer<unknown>)
    })
    
    return newValue
  }
  
  return getter
}
