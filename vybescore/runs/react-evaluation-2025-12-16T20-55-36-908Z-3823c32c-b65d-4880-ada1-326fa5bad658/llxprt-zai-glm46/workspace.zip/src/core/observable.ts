/**
 * Implementation for multiple observer support and proper dependency tracking.
 */

import { Observer, getActiveObserver, updateObserver } from '../types/reactive.js'

export class ObservableSubject<T> {
  private observers: Observer<T>[] = []
  private value: T

  constructor(initialValue: T) {
    this.value = initialValue
  }

  getValue(): T {
    const observer = getActiveObserver()
    if (observer && !this.observers.includes(observer as Observer<T>)) {
      this.observers.push(observer as Observer<T>)
    }
    return this.value
  }

  setValue(newValue: T): void {
    if (this.value === newValue) return
    this.value = newValue
    this.notifyObservers()
  }

  private notifyObservers(): void {
    this.observers.forEach(observer => {
      updateObserver(observer)
    })
  }

  // For cleanup and testing
  getObservers(): Observer<T>[] {
    return [...this.observers]
  }

  clearObservers(): void {
    this.observers = []
  }
}