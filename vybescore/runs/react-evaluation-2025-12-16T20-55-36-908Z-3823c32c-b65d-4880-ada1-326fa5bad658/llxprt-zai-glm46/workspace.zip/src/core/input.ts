/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof _equal === 'function' ? _equal : 
                  _equal === true ? (a: T, b: T) => a === b : 
                  undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // List of observers that depend on this input
  const observers: Observer<T>[] = []

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const typedObserver = observer as Observer<T>
      if (!observers.includes(typedObserver)) {
        observers.push(typedObserver)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value // No change, return current value
    }
    
    s.value = nextValue
    
    // Notify all dependent observers
    const currentObservers = [...observers]
    currentObservers.forEach(observer => {
      updateObserver(observer)
    })
    
    return s.value
  }

  return [read, write]
}