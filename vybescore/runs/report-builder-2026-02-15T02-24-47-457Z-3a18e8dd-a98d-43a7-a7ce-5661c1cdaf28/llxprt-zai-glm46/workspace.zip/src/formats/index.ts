import type { FormatHandler } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Map of format names to their handlers.
 */
export const formatHandlers: Record<string, FormatHandler> = {
  markdown: renderMarkdown,
  text: renderText
};

/**
 * Get a format handler by name.
 */
export function getFormatHandler(format: string): FormatHandler {
  const handler = formatHandlers[format];
  if (!handler) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return handler;
}

export { renderMarkdown } from './markdown.js';
export { renderText } from './text.js';
