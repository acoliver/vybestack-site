import type { FormatHandler, ReportData, RenderOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

/**
 * Plain text format handler.
 */
export const renderText: FormatHandler = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(data.title);
    lines.push('');

    // Summary
    lines.push(data.summary);
    lines.push('');

    // Entries section
    lines.push('Entries:');
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }

    // Optional total
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push(`Total: ${formatAmount(total)}`);
    }

    return lines.join('\n');
  }
};
