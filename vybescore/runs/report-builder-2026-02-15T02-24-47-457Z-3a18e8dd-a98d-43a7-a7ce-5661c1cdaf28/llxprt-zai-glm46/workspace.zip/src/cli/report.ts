#!/usr/bin/env node

import * as fs from 'fs';
import { getFormatHandler } from '../formats/index.js';
import { validateReportData } from '../utils.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments.
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  const formatFlagIndex = args.indexOf('--format');

  if (formatFlagIndex === -1 || formatFlagIndex + 1 >= args.length) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  const format = args[formatFlagIndex + 1];

  const outputFlagIndex = args.indexOf('--output');
  const outputPath = outputFlagIndex !== -1 && outputFlagIndex + 1 < args.length
    ? args[outputFlagIndex + 1]
    : undefined;

  const includeTotals = args.includes('--includeTotals');

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Read and parse JSON file.
 */
function readJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Malformed JSON in ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Main CLI entry point.
 */
function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and validate input
    const rawData = readJsonFile(args.inputFile);
    const data = validateReportData(rawData);

    // Get format handler
    const handler = getFormatHandler(args.format);

    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    const output = handler.render(data, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
