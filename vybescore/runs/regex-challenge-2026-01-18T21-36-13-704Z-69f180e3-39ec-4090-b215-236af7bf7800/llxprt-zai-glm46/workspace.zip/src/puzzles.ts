/**
 * Find words starting with prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with prefix (word boundary to ensure whole words)
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions and duplicates
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const uniqueMatches = new Set<string>();
  
  matches.forEach(match => {
    const matchLower = match.toLowerCase();
    if (!exceptionsLower.includes(matchLower)) {
      uniqueMatches.add(match);
    }
  });
  
  return Array.from(uniqueMatches);
}

/**
 * Find occurrences of token that appear after a digit and not at string start.
 * Uses lookahead/lookbehind.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token
  // The match should include both the digit and the token
  // The pattern matches: digit + token, where digit comes before token
  // And it's not at the start of the string
  
  // Pattern: digit followed by token (capture the whole thing)
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for repeated sequences like abab, abcabc, etc.
  // We'll look for any 2-4 character pattern that repeats immediately
  for (let len = 2; len <= 4; len++) {
    const pattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (pattern.test(value)) return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 pattern:
  // - 8 groups of hex digits separated by colons
  // - Can use :: shorthand for one or more consecutive zero groups
  // - Each group is 1-4 hex digits
  // - Can have IPv4 address at the end (e.g., ::ffff:192.168.1.1)
  
  // First, let's define a pattern that matches IPv6
  // This needs to handle:
  // - Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1
  // - Mixed with IPv4: ::ffff:192.168.1.1
  
  // Negative lookahead to exclude pure IPv4 addresses
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check if it's pure IPv4 - if so, return false
  if (ipv4Pattern.test(value.replace(/\s/g, ''))) {
    // But need to ensure we're not looking at IPv6 with embedded IPv4
    // So we'll check if there's a colon in the string
    if (!value.includes(':')) {
      return false;
    }
  }
  
  // IPv6 hex group: 1-4 hex digits
  const hexGroup = '[0-9a-fA-F]{1,4}';
  
  // Full IPv6 (8 groups)
  const fullIPv6 = new RegExp(`^(${hexGroup}:){7}${hexGroup}$`);
  
  // IPv6 with :: shorthand
  // :: can replace one or more groups
  // Pattern for :: somewhere in the address
  const shorthandIPv6 = new RegExp(`^(${hexGroup}:)*:(${hexGroup}:)*${hexGroup}$|^(${hexGroup}:)*::(${hexGroup}:)*${hexGroup}$|^::(${hexGroup}:)*${hexGroup}$`);
  
  // Mixed IPv6/IPv4
  const mixedPattern = /^(([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?:(:[0-9a-fA-F]{1,4})*:((?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Extract potential IP addresses from the text
  const ipPattern = /[0-9a-fA-F:]+:[0-9a-fA-F:]*/gi;
  const matches = value.match(ipPattern) || [];
  
  for (const match of matches) {
    // Check each match against IPv6 patterns
    const cleaned = match.trim();
    
    if (fullIPv6.test(cleaned) || 
        shorthandIPv6.test(cleaned) || 
        mixedPattern.test(cleaned) ||
        cleaned.includes('::')) {
      return true;
    }
  }
  
  return false;
}
