/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces.
 * Attempts to preserve abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';

  // First, normalize whitespace: collapse multiple spaces to one
  let normalized = text.replace(/[ \t]+/g, ' ');

  // Ensure exactly one space after sentence endings
  // Add space after . ? ! if not followed by space or end of string
  normalized = normalized.replace(/([.?!])(?=[^ \t\n])(?!$)/g, '$1 ');

  // Capitalize first character of string
  normalized = normalized.replace(/^./, char => char.toUpperCase());

  // Capitalize after sentence endings . ? ! followed by space and lowercase letter
  // But be careful about abbreviations (e.g., Mr., Dr., etc.)
  // We'll use a lookbehind to avoid capitalizing after common abbreviations
  // Split into sentences and capitalize
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  
  const capitalized = sentences.map((sentence, index) => {
    if (sentence.length === 0) return '';
    
    // For first sentence or sentences after .!?, capitalize first letter
    if (index === 0 || /[.!?]$/.test(sentences[index - 1] || '')) {
      return sentence.replace(/^([a-z])/, char => char.toUpperCase());
    }
    
    return sentence;
  });
  
  return capitalized.join(' ');
}

/**
 * Find URLs in text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];

  // URL pattern: scheme://domain.tld/path...
  // Capture URLs but exclude trailing punctuation
  const urlPattern = /https?:\/\/(?:[-\w._~:/?#[\]@!$&'()*+,;=%]|(?!\.\s|\.$|[!,:;]))[^\s\])}>"]+/gi;

  const matches = text.match(urlPattern) || [];

  // Strip trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,!?:;)\]>"']+$/, ''));
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';

  // Replace http:// with https://
  return text.replace(/http:\/+([^/])/gi, 'https://$1');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - For /docs/ paths, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';

  // Pattern to match http://example.com URLs
  // We'll handle both the scheme upgrade and potential host rewrite
  const urlPattern = /(http:)(\/\/example\.com)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, scheme, rest, path) => {
    // Always upgrade to https
    const newScheme = 'https:';
    
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = [
      '/cgi-bin',
      '?',
      '&',
      '=',
      '.jsp',
      '.php',
      '.asp',
      '.aspx',
      '.do',
      '.cgi',
      '.pl',
      '.py'
    ];
    
    const shouldSkipHostRewrite = dynamicHints.some(hint => path.includes(hint));
    
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      // Rewrite to docs.example.com
      return newScheme + rest.replace('example.com', 'docs.example.com') + path;
    } else {
      // Just upgrade the scheme
      return newScheme + rest + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';

  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^\d{2}\/\d{2}\/\d{4}$/);

  if (!dateMatch) return 'N/A';

  const parts = value.split('/');
  const month = parseInt(parts[0], 10);
  const day = parseInt(parts[1], 10);
  const yearStr = parts[2];
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [
    31, // Jan
    29, // Feb (leap year handled loosely)
    31, // Mar
    30, // Apr
    31, // May
    30, // Jun
    31, // Jul
    31, // Aug
    30, // Sep
    31, // Oct
    30, // Nov
    31  // Dec
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  // Validate year (reasonable range: 1900-2100)
  if (year < 1900 || year > 2100) return 'N/A';
  
  // Special case for Feb 29
  if (month === 2 && day === 29) {
    // Check if leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) return 'N/A';
  }
  
  return yearStr;
}
