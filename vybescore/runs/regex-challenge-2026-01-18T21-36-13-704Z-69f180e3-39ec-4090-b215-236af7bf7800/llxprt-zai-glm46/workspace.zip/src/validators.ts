export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 320) return false;
  
  // Main pattern: local@domain.tld
  // Local part: alphanumeric plus . _ % + - but no consecutive dots or leading/trailing dots
  // Domain: alphanumeric plus hyphens, no underscores, TLD at least 2 chars
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9_%++-]*[a-zA-Z0-9])?@(?!-)[a-zA-Z0-9-]+(?:\.(?!-)[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) return false;
  
  const [localPart, domain] = value.split('@');
  
  // Check for consecutive dots in local part
  if (localPart.includes('..')) return false;
  
  // Check for leading, trailing, or consecutive dots in domain
  if (domain.startsWith('.') || domain.endsWith('.') || domain.includes('..')) return false;
  
  // Domain cannot contain underscores
  if (domain.includes('_')) return false;
  
  // Domain parts cannot start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value) return false;

  // Remove all separators and whitespace
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(digits)) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (digits 4-6) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;

  // Remove all whitespace, hyphens, and parentheses
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Handle optional +54 or 54 country code
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
    hasCountryCode = true;
  } else if (remaining.startsWith('54') && remaining.length > 10) {
    remaining = remaining.slice(2);
    hasCountryCode = true;
  }
  
  // Handle optional trunk prefix 0 (required when no country code)
  let hasTrunkPrefix = false;
  if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
    hasTrunkPrefix = true;
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // Handle optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Remaining must be all digits
  if (!/^\d+$/.test(remaining)) return false;
  
  // Area code: 2-4 digits, leading digit 1-9
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) return false;
  
  const [, areaCode, subscriberNumber] = areaCodeMatch;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // Total digits check (area code + subscriber should be at least 8, at most 12)
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Cannot be only spaces, hyphens, or apostrophes
  const trimmed = value.replace(/[\s'-]/g, '');
  if (trimmed.length === 0) return false;
  
  // Check for digits (should have been caught by regex, but double check)
  if (/\d/.test(value)) return false;
  
  return true;
}

/**
 * Run Luhn checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let double = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    double = !double;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Check card prefixes and lengths
  const visa = /^4\d{12}(\d{3})?$/;
  const mastercard = /^5[1-5]\d{14}$/;
  const amex = /^3[47]\d{13}$/;
  
  const isValidFormat = visa.test(cleaned) || mastercard.test(cleaned) || amex.test(cleaned);
  if (!isValidFormat) return false;
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
