import { readFileSync } from 'fs';
import { formatters } from '../formats/index.js';
import { ReportData } from '../types.js';

function parseArgs(args: string[]): { dataPath: string; format: string; output?: string; includeTotals: boolean } {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];

  let format: string | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i + 1];
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      output = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataPath, format, output, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const report = data as Partial<ReportData>;

  if (!report.title || typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (!report.summary || typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!report.entries || !Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  // Validate entries
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] is not an object`);
    }

    const typedEntry = entry as Partial<{ label: string; amount: number }>;

    if (!typedEntry.label || typeof typedEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "label" field`);
    }

    if (typeof typedEntry.amount !== 'number' || isNaN(typedEntry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "amount" field`);
    }
  }

  return report as ReportData;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));
    
    // Read and parse JSON
    const fileContent = readFileSync(args.dataPath, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    
    // Validate data
    const reportData = validateReportData(jsonData);
    
    // Check if format is supported
    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Error: Unsupported format`);
      process.exit(1);
    }
    
    // Generate report
    const report = formatter.format(reportData, args.includeTotals);
    
    // Write output
    if (args.output) {
      // Write to file
      import('fs').then(fs => {
        fs.writeFileSync(args.output!, report);
      });
    } else {
      // Write to stdout
      console.log(report);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();