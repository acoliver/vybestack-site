import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { Formatter } from '../types.js';

export const formatters: Record<string, Formatter> = {
  markdown: {
    format: renderMarkdown,
  },
  text: {
    format: renderText,
  },
};

export { renderMarkdown, renderText };