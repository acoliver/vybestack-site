import { ReportData } from '../types.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Entry bullets
  for (const entry of data.entries) {
    const amount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- ${entry.label}: ${amount}`);
  }
  
  // Total (if requested)
  if (includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}