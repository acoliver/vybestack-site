/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and filter those that start with prefix
  const words = text.match(/\b[a-zA-Z]+\b/g) || [];
  
  // Filter words starting with prefix
  const filteredWords = words.filter(word => 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );
  
  // Filter out exceptions
  const exceptionsSet = new Set(exceptions.map(word => word.toLowerCase()));
  const result = filteredWords.filter(word => 
    !exceptionsSet.has(word.toLowerCase())
  );
  
  // Remove duplicates while preserving order
  return result.filter((word, index, self) => self.indexOf(word) === index);
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token
  let index = 0;
  const matches: string[] = [];
  
  while ((index = text.indexOf(token, index)) !== -1) {
    // Check if token is not at start and is preceded by a digit
    if (index > 0 && /\d/.test(text[index - 1])) {
      // Include the preceding digit in the match
      matches.push(text.substring(index - 1, index + token.length));
    }
    index += token.length;
  }
  
  // Remove duplicates
  return Array.from(new Set(matches));
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences
  // Check for patterns like 'abab', 'abcabc', etc. (repeated sequences)
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const sequence = value.substr(i, len);
      const nextSequence = value.substr(i + len, len);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  // Also check for repeated single characters like 'aaa', '111', etc.
  if (/(.)\1{2,}/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns (more comprehensive)
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const ipv6FullRegex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressing zeros) - can appear at most once
  const ipv6ShorthandRegex = /\b([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with only :: (all zeros)
  const ipv6AllZerosRegex = /\b::\b/;
  
  // IPv6 with leading :: (cannot end with another ::)
  const ipv6LeadingRegex = /\b::([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with trailing :: (cannot start with another ::)
  const ipv6TrailingRegex = /\b([0-9a-fA-F]{1,4}:){1,7}:\b/;
  
  // IPv6 with embedded IPv4
  const ipv6WithIPv4Regex = /\b([0-9a-fA-F]{1,4}:){1,5}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  const hasIPv6 = ipv6FullRegex.test(value) ||
                  ipv6ShorthandRegex.test(value) ||
                  ipv6AllZerosRegex.test(value) ||
                  ipv6LeadingRegex.test(value) ||
                  ipv6TrailingRegex.test(value) ||
                  ipv6WithIPv4Regex.test(value);
  
  // If no IPv6 found, return false immediately
  if (!hasIPv6) return false;
  
  // Check if this is a pure IPv4 address (not mixed content)
  // IPv4 regex to exclude pure IPv4 addresses
  const ipv4Regex = /^\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b$/;
  
  // If the entire string is just a pure IPv4 address, return false
  // Otherwise, if we found IPv6 (even in mixed content), return true
  return !ipv4Regex.test(value.trim());
}
