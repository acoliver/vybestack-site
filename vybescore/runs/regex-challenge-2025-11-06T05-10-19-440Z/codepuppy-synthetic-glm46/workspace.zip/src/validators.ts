export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure validation with a more comprehensive regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Split into local and domain parts
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [localPart, domainPart] = parts;
  
  // Check for consecutive dots anywhere in the email
  if (value.includes('..')) return false;
  
  // Check for dots at start or end of local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Check for underscores in domain part
  if (domainPart.includes('_')) return false;
  
  // Domain should not start with dot or end with dot
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) return false;
  
  // Domain labels shouldn't start or end with hyphens
  const domainLabels = domainPart.split('.');
  for (const label of domainLabels) {
    if (label.startsWith('-') || label.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const cleanValue = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits without country code, 11 with +1)
  if (cleanValue.length < 10) return false;
  
  // Extract digits for validation
  let digits = cleanValue;
  
  // Handle optional +1 country code
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1); // Remove country code
  } else if (digits.length > 10) {
    return false; // Too many digits
  }
  
  // Must have exactly 10 digits after removing country code
  if (digits.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Final validation with regex to ensure proper format
  const phoneRegex = /^\+?1?[\s.-]?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep track for format checking
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if the basic format is valid first
  // Must be either +54... or starts with 0 (trunk prefix)
  if (!cleanValue.match(/^\+54.*|^0.*/)) return false;
  
  // Extract components for validation
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  let areaCode = '';
  let subscriberNumber = '';
  
  // Remove country code if present
  let remaining = cleanValue;
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Remove trunk prefix if present
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }
  
  // Remove mobile indicator if present (optional 9)
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  if (!remaining.match(/^[1-9]\d{1,3}/)) return false;
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  areaCode = areaCodeMatch![1];
  remaining = remaining.slice(areaCode.length);
  
  // Check subscriber number (6-8 digits)
  if (!remaining.match(/^\d{6,8}$/)) return false;
  subscriberNumber = remaining;
  
  // Validate rules:
  // 1. When country code is omitted, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // 2. Area code length must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // 3. Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and tech-style names like "X Æ A-12"
  const nameRegex = /^[A-Za-zÀ-ž\u0400-\u04FF'\-\s]+$/;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject if contains digits
  if (/\d/.test(value)) return false;
  
  // Reject overly symbol-heavy names like "X Æ A-12"
  const symbolCount = (value.match(/[^A-Za-zÀ-ž\u0400-\u04FF\s]/g) || []).length;
  const totalChars = value.replace(/\s/g, '').length;
  
  // If more than 30% are non-letter symbols, reject (to catch "X Æ A-12" style)
  if (totalChars > 0 && symbolCount / totalChars > 0.3) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check length (typically 13-19 digits)
  if (cleanValue.length < 13 || cleanValue.length > 19) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9][0-9]|3[0-9][0-9]|4[0-9][0-9]|5[0-9][0-9]|6[0-9][0-9]|7[0-1][0-9]|720)\d{12}))$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type pattern
  const validFormat = visaRegex.test(cleanValue) || 
                      mastercardRegex.test(cleanValue) || 
                      amexRegex.test(cleanValue);
  
  if (!validFormat) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
