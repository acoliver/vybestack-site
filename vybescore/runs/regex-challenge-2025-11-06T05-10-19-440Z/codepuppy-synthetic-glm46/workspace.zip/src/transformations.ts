/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty input
  if (!text.trim()) return text;
  
  // First, ensure proper spacing between sentences
  let result = text.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Then collapse multiple spaces to single spaces (but keep one space after sentence endings)
  result = result.replace(/ {2,}/g, ' ');
  
  // Capitalize first character of each sentence
  // Look for sentence endings followed by optional quotes/brackets and whitespace, then a letter
  result = result.replace(/(^|[.!?]\s*)(["'\(\[]*)([a-z])/g, (match, prefix, quote, letter) => {
    return prefix + quote + letter.toUpperCase();
  });
  
  // Also handle the very first character of the text
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match http/https URLs
  const urlRegex = /https?:\/\/(?:www\.)?[^\s<>"']+|www\.[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like ., ), ], etc.
  return matches.map(url => {
    return url.replace(/[.,;:!?)\]\}]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch existing https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http scheme
  const urlPattern = /\bhttp:\/\/([^\s\/]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, domain, path = '') => {
    // First, always upgrade to https
    const newScheme = 'https://';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Look for dynamic hints that should prevent host rewrite
      const hasDynamicHints = /(?:cgi-bin|[?&=]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/i.test(path);
      
      if (hasDynamicHints) {
        // Only upgrade scheme, keep same domain
        return newScheme + domain + path;
      } else {
        // Rewrite host to docs.example.com
        return newScheme + 'docs.' + domain + path;
      }
    } else {
      // Not a docs path, just upgrade scheme
      return newScheme + domain + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month/day combinations
  // Days per month (ignoring leap years for simplicity, but handling February 29 leap year logic)
  const daysInMonth = [
    31, // January
    isLeapYear(parseInt(year)) ? 29 : 28, // February
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}

/**
 * Helper function to check if a year is a leap year
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
