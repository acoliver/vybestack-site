#!/usr/bin/env python3
import re

# Read the file
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the unnecessary escape characters
# Replace http:\\/\\/ with http:\/\/ 
content = content.replace(r'http:\\/\\/', r'http:\/\/')

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed unnecessary escape characters in transformations.ts")