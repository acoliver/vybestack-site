#!/usr/bin/env python3

# Read the file
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Print the current content around line 29 to debug
lines = content.split('\n')
for i, line in enumerate(lines):
    if i >= 25 and i <= 35:
        print(f"Line {i+1}: {repr(line)}")

print("\n--- Fixing ---\n")

new_lines = []
for i, line in enumerate(lines):
    if i == 28:  # Line 29 (0-indexed)
        # Fix the regex pattern by removing unnecessary escapes
        # http:\\\\/\\\\/ -> http://
        # (also fix other unnecessary escapes in the pattern)
        fixed_line = line.replace('http:\\\\/\\\\/', 'http://')
        fixed_line = fixed_line.replace('([^\\\\/\\\\s]+)', '([^/\\s]+)')
        fixed_line = fixed_line.replace('(\\\\/docs\\\\/', '(/docs/')
        fixed_line = fixed_line.replace('[^\\\\s]*', '[^\\s]*')
        print(f"Fixed line {i+1}: {repr(fixed_line)}")
        new_lines.append(fixed_line)
    else:
        new_lines.append(line)

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write('\n'.join(new_lines))

print("Fixed line 29 in transformations.ts")