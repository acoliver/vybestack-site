/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token that appears after a digit and not at the start of string
  // Use capturing group to include the digit and token
  const pattern = new RegExp(`(?<!^)(\\d${token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'g');
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, 1212, etc.)
  if (/(..+)\1/.test(value)) return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol
  const symbolPattern = "[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]";
  if (!new RegExp(symbolPattern).test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern with shorthand :: support
  const ipv6Pattern = /(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}|::(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}|[a-fA-F0-9]{1,4}::(?:[a-fA-F0-9]{1,4}:){0,5}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){1,2}::(?:[a-fA-F0-9]{1,4}:){0,4}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){0,2}::(?:[a-fA-F0-9]{1,4}:){0,3}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){0,3}::(?:[a-fA-F0-9]{1,4}:){0,2}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){0,4}::(?:[a-fA-F0-9]{1,4}:){0,1}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){0,5}::[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){0,6}::/;
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if it contains IPv6 but not IPv4
  const hasIPv6 = ipv6Pattern.test(value);
  const hasIPv4 = ipv4Pattern.test(value);
  
  return hasIPv6 && !hasIPv4;
}