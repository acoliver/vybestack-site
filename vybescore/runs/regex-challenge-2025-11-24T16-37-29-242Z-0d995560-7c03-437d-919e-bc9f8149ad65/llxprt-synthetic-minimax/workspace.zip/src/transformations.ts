/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text.replace(/(^|[.!?]\s*)(\w)/g, (match, start, char) => {
    return start + char.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlPattern = /\bhttps?:\/\/[^\s)]+[^\s.,)]/g;
  return text.match(urlPattern) || [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/\s]+)(\/docs\/[^\s]*)/g, (match, host, path) => {
    // Check if path contains dynamic hints
    if (/(?:cgi-bin|[?&].*=|.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path)) {
      return `https://${host}${path}`;
    }
    // For docs paths, rewrite host to docs.hostname
    return `https://docs.${host}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = parseInt(match[3]);
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year.toString();
}