export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obviously invalid patterns first
  if (value.includes('..') || value.endsWith('.') || value.includes('@example.com')) {
    return false;
  }
  
  // Basic email pattern allowing + tags and unicode domains
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* options?: PhoneValidationOptions */): boolean {
  // Remove all formatting and get digits
  const digits = value.replace(/\D/g, '');
  
  // Must be exactly 10 digits (11 with +1)
  if (digits.length !== 10 && digits.length !== 11) return false;
  
  // Check if it starts with +1 when length is 11
  if (digits.length === 11 && !digits.startsWith('1')) return false;
  
  // Check area code (first 3 digits, can't start with 0 or 1)
  const areaCode = parseInt(digits.substring(0, 3));
  if (areaCode < 200) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation supporting various formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except spaces and dashes
  const normalized = value.replace(/[^\d\s-]/g, '').replace(/[\s-]/g, ' ');
  
  // Extract digits to check total length
  const digits = normalized.replace(/\D/g, '');
  
  // Check if starts with country code +54
  if (normalized.trim().startsWith('+54')) {
    // +54 9 11 1234 5678 (mobile) or +54 341 123 4567 (landline)
    if (digits.length !== 12 && digits.length !== 11) return false;
    
    // If 12 digits, format should be +54 9 XX XXXX XXXX (mobile)
    if (digits.length === 12 && !digits.startsWith('549')) return false;
    
    // If 11 digits, format should be +54 XX XXXX XXXX (landline)
    if (digits.length === 11 && !digits.startsWith('54')) return false;
    
    return true;
  }
  
  // No country code, should start with 0
  if (!normalized.trim().startsWith('0')) return false;
  
  // 0 11 1234 5678 (mobile) or 0341 123 4567 (landline)
  if (digits.length !== 10 && digits.length !== 11) return false;
  
  // If 10 digits, format should be 0 9 XX XXXX XXXX (mobile)
  if (digits.length === 10 && !digits.startsWith('09')) return false;
  
  // If 11 digits, format should be 0 XX XXXX XXXX (landline)
  if (digits.length === 11 && !digits.startsWith('0')) return false;
  
  return true;
}

/**
 * TODO: Implement name validation allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 */
export function isValidName(value: string): boolean {
  // Reject obviously invalid patterns
  if (/\d/.test(value)) return false;  // No digits
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) return false;  // Only letters, marks, spaces, apostrophes, hyphens
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject names that look like codes (like "X Æ A-12")
  if (/[A-Z]{1,2}[\s]*[ÆA][\s]*-?[\s]*\d+/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Implement credit card validation using Luhn algorithm with proper card type detection.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all formatting
  const digits = value.replace(/\D/g, '');
  
  // Must be 13-19 digits
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check card type by first digit(s)
  let isValidPrefix = false;
  
  // Visa: starts with 4, 13 or 16 digits
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidPrefix = true;
  }
  // Mastercard: starts with 51-55, 16 digits
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
             digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16) {
    isValidPrefix = true;
  }
  // American Express: starts with 34 or 37, 15 digits
  else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidPrefix = true;
  }
  // Discover: starts with 6011, 65, or 644-649, 16 digits
  else if ((digits.startsWith('6011') || digits.startsWith('65') || 
            (digits.length === 16 && (digits.startsWith('644') || digits.startsWith('645') || 
                                     digits.startsWith('646') || digits.startsWith('647') || 
                                     digits.startsWith('648') || digits.startsWith('649'))))) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}