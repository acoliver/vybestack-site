#!/usr/bin/env python3

# Read the file
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the specific line with correct regex pattern
old_line = '  return text.replace(/http:\\\\/\\\\/([^\\\\/\\\\s]+)(\\\\/docs\\\\/[^\\\\s]*)/g, (match, host, path) => {'
new_line = '  return text.replace(/http:\/\/([^\/\s]+)(\/docs\/[^\s]*)/g, (match, host, path) => {'

content = content.replace(old_line, new_line)

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write(content)

print('Fixed the regex pattern correctly')
print('Old:', repr(old_line))
print('New:', repr(new_line))