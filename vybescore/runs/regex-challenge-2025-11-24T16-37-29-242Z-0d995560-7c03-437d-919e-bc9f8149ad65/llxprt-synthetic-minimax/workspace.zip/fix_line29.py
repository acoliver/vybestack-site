#!/usr/bin/env python3

# Read the file
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Print the current content around line 29 to debug
lines = content.split('\n')
for i, line in enumerate(lines):
    if i >= 25 and i <= 35:
        print(f"Line {i+1}: {repr(line)}")

print("\n--- Fixing ---\n")

# The issue is with the backslashes in the regex pattern
# We need to replace: http:\\\\/\\\\/ with http:\/\/
# But the raw content has literal backslashes that need to be reduced

new_lines = []
for i, line in enumerate(lines):
    if i == 28:  # Line 29 (0-indexed)
        # Fix the regex pattern
        fixed_line = line.replace('http:\\\\/\\\\/', 'http:\/\/')
        print(f"Fixed line {i+1}: {repr(fixed_line)}")
        new_lines.append(fixed_line)
    else:
        new_lines.append(line)

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write('\n'.join(new_lines))

print("Fixed line 29 in transformations.ts")