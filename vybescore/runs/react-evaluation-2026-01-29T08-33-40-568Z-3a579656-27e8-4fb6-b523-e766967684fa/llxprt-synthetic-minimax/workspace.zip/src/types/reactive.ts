/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const dependents = new Map<object, Set<ObserverR>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependent<T>(subject: Subject<T>, observer: ObserverR): void {
  const subjectId = subject as object
  
  if (!dependents.has(subjectId)) {
    dependents.set(subjectId, new Set())
  }
  
  dependents.get(subjectId)!.add(observer)
}

export function notifyDependents<T>(subject: Subject<T>): void {
  const subjectId = subject as object
  const subjectDependents = dependents.get(subjectId)
  
  if (subjectDependents) {
    // Create a copy to avoid modification during iteration
    const observersToNotify = Array.from(subjectDependents)
    
    for (const observer of observersToNotify) {
      if (observer && 'updateFn' in observer) {
        // Check if this observer also has dependencies that need to be tracked
        // by re-executing its update function, which will access reactive values
        updateObserver(observer as Observer<unknown>)
      }
    }
  }
}

export { dependents }
