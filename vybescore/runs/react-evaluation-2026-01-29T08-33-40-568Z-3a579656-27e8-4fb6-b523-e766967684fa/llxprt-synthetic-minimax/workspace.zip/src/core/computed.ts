/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  addDependent,
  notifyDependents,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const subject: Subject<T> = {
    name: options?.name,
    observer: o,
    value,
    equalFn: undefined,
  }
  
  const read: GetterFn<T> = (): T => {
    // Track dependencies by seeing if there's an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this computed value as a dependent of the active observer
      addDependent(subject, activeObserver)
    }
    
    const previousValue = o.value
    
    // Evaluate the computed function to get current value and track dependencies
    updateObserver(o)
    
    // Notify dependents if the computed value changed
    const newValue = o.value
    if (previousValue !== newValue) {
      subject.value = newValue
      notifyDependents(subject)
    }
    
    // At this point, newValue should always be defined because updateFn returns T
    return newValue!
  }
  
  return read
}
