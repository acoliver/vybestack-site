/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  addDependent,
  notifyDependents,
  Subject,
  getActiveObserver,
  dependents
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>, 
  value?: T
): UnsubscribeFn {
  let disposed = false
  
  // Create the subject for this callback to enable dependency tracking
  const subject: Subject<T> = {
    name: 'callback',
    observer: undefined,
    value: value,
    equalFn: undefined,
  }
  
  // Create the observer to track dependencies
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue!
      
      // This update function is called during dependency updates
      // We need to execute the user's callback function here
      const result = updateFn(observer.value)
      observer.value = result
      return result
    },
  }
  
  // Store the observer reference in the subject for proper tracking
  subject.observer = observer
  
  // Create a getter for the callback to access reactive values
  const readCallback = () => {
    // Track this getter as a dependency for any active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this callback as a dependent of the active observer
      addDependent(subject, activeObserver)
    }
    
    // Execute the callback function with the current observer value
    const result = updateFn(observer.value)
    observer.value = result
    return result
  }
  
  // Execute the callback immediately to track initial dependencies
  // This evaluates updateFn which should access reactive values through getters
  // Those getters will register this observer as a dependent via addDependent
  updateObserver(observer)
  
  // Return an unsubscribe function that disposes of the callback
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this callback from all dependency tracking
    if (dependents) {
      dependents.forEach((observers) => {
        observers.delete(observer)
      })
    }
  }
}
