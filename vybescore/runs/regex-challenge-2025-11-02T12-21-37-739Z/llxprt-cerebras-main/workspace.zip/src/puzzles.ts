/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Use word boundaries to ensure we match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\\]$\$$/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  return matches.filter(match => !exceptions.includes(match.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern with lookbehind for a digit
  const escapedToken = token.replace(/[.*+?^${}()|[\\]$\$$/g, '\\$&');
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab)
  // This pattern matches any sequence of 2+ characters that repeats immediately
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that handles full and shorthand formats
  // This is a simplified pattern but should work for most cases
  const ipv6Regex = /(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){1,5}:(?:[0-9a-fA-F]{1,4}:){1,2}[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){1,4}:(?:[0-9a-fA-F]{1,4}:){1,3}[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){1,3}:(?:[0-9a-fA-F]{1,4}:){1,4}[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){1,2}:(?:[0-9a-fA-F]{1,4}:){1,5}[0-9a-fA-F]{1,4}|(?<!\d\.)[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}|(?<!\d\.)::(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?<!\d\.)[0-9a-fA-F]{1,4}::|(?<!\d\.)::/g;
  
  // Check for IPv6 addresses
  const ipv6Matches = value.match(ipv6Regex);
  
  if (!ipv6Matches) {
    return false;
  }
  
  // Verify that any found matches are not actually IPv4 addresses in disguise
  for (const match of ipv6Matches) {
    // Check if this is actually an IPv4 address (contains 4 digit groups separated by dots)
    const ipv4Regex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    if (!ipv4Regex.test(match)) {
      return true; // Found a valid IPv6 address
    }
  }
  
  return false; // All matches were IPv4 addresses
}