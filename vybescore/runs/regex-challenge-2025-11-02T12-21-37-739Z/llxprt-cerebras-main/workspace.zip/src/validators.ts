export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure with local part and domain
  // Local part allows alphanumeric, dots, hyphens, underscores, and plus signs
  // Domain part allows alphanumeric, dots, and hyphens but not underscores
  // Reject double dots, trailing dots in either part
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots or trailing dots in local part or domain
  const [localPart, domainPart] = value.split('@');
  
  // Check for double dots
  if (localPart.includes('..') || domainPart.includes('..')) {
    return false;
  }
  
  // Check for trailing dots
  if (localPart.endsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Check if domain contains underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length and area code validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // If allowExtensions option is not provided or false, reject if there are more than 10 digits
  if (!options?.allowExtensions && digitsOnly.length > 10 && !(digitsOnly.length === 11 && digitsOnly.startsWith('1'))) {
    return false;
  }
  
  // Check if it's a valid length: 10 digits, or 11 digits starting with 1
  if (digitsOnly.length !== 10 && !(digitsOnly.length === 11 && digitsOnly.startsWith('1'))) {
    return false;
  }
  
  // If 11 digits and starts with 1, remove the leading 1 for area code validation
  const numberToCheck = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Extract area code (first 3 digits)
  const areaCode = numberToCheck.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Use regex to validate the format with common separators
  const phoneRegex = /^(\+?1[-.\s]?)?\(?([2-9][0-9]{2})\)?[-.\s]?([2-9][0-9]{2})[-.\s]?([0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // First clean the value by removing all spaces
  const cleanedValue = value.replace(/\s/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Supports formats like +5491112345678, 01112345678, +543411234567, 03414234567
  const phoneRegex = /^(\+54|0)(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if format matches
  const match = cleanedValue.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  // Extract area code and subscriber number
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Validate area code length (2-4 digits) and starts with 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode.charAt(0) === '0') {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols (except the allowed ones)
  const nameRegex = /^[^\d]*$/; // Basic check to reject strings with digits
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // More specific check - allow letters, spaces, hyphens, and apostrophes
  const refinedNameRegex = /^[\p{L}\s\-']+$/u;
  return refinedNameRegex.test(value) && value.trim().length > 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any spaces or dashes
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanedValue)) {
    return false;
  }
  
  // Check prefix and length for different card types
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/; // 16 digits, starts with 51-55 or 22-27
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if value matches any valid card pattern
  if (!(visaRegex.test(cleanedValue) || mastercardRegex.test(cleanedValue) || amexRegex.test(cleanedValue))) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanedValue);
}

/**
 * Helper function to run Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}