/**
 * Capitalizes the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space
  text = text.replace(/\s+/g, ' ');
  
  // Capitalize first letter of the text
  text = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Find sentence endings (.?! followed by space and lowercase letter) and capitalize next letter
  // Using regex with capture groups to preserve the punctuation and space
  text = text.replace(/([.?!])\s+([a-z])/g, (match, p1, p2) => {
    return p1 + ' ' + p2.toUpperCase();
  });
  
  // Trim any leading/trailing whitespace
  return text.trim();
}

/**
 * Finds URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs starting with http:// or https://
  // Allow letters, digits, and certain special characters in the URL
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^.?!,\s]/gi;
  const matches = text.match(urlRegex);
  
  return matches ? matches : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not if it's already https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs that start with http://, followed by a domain, and a path
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)?/gi, (match, domain, path = '') => {
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/') && 
        !path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)/) && 
        !path.includes('cgi-bin') && 
        !path.includes('?') && 
        !path.includes('&') && 
        !path.includes('=')) {
      // Rewrite host to docs.example.com
      return `https://docs.${domain}${path}`;
    } else {
      // Just upgrade the scheme to https://
      return `https://${domain}${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match dates in mm/dd/yyyy format, with validation for valid months and days
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const matches = value.match(dateRegex);
  
  if (matches) {
    return matches[3]; // Return the year component
  } else {
    return 'N/A';
  }
}