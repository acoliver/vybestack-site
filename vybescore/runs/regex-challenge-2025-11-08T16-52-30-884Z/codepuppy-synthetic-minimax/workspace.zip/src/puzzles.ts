/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix) return [];
  
  // Split by whitespace and filter
  const words = text.split(/\s+/);
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return words
    .filter(word => word.toLowerCase().startsWith(prefix.toLowerCase()))
    .filter(word => !exceptionsSet.has(word.toLowerCase()))
    .filter((match, index, array) => array.indexOf(match) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token) return [];
  
  // Note: Token escaping not needed for this simple split approach
  
  // Split by space and check each token
  const tokens = text.split(/\s+/);
  const matches: string[] = [];
  
  for (let i = 0; i < tokens.length; i++) {
    const currentToken = tokens[i];
    // Check if token ends with our target and starts with a digit
    if (currentToken.endsWith(token) && /\d/.test(currentToken[0])) {
      matches.push(currentToken);
    }
  }
  
  // Remove duplicates while preserving order
  return matches.filter((match, index, array) => array.indexOf(match) === index);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for required character classes
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/?]/.test(value);
  const hasNoWhitespace = /^\S+$/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol || !hasNoWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (like 'abab', 'abcabc')
  // This looks for any substring of length 2-4 that repeats immediately after itself
  const repeatedPattern = /(.{1,4})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that matches various formats:
  // - Full: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shortened: 2001:db8:85a3::8a2e:370:7334
  // - Loopback: ::1
  // - Unspecified: ::
  // - With IPv4 embedded: ::ffff:192.0.2.128
  
  // First, ensure it's not just an IPv4 address
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) return false;
  
  // IPv6 pattern (comprehensive)
  const ipv6Pattern = /(?:^|(?<![\d.]))((?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:(?:[0-9a-fA-F]{1,4})?|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?:$|(?![\d.]))/;
  
  return ipv6Pattern.test(value);
}
