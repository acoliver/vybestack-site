/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Split text into sentences using sentence-ending punctuation
  // Look for . ? ! followed by optional quotes/brackets and spaces
  const sentences = text.split(/([.?!]\s*(?:["'\)\]\}]?\s*))/);
  
  // Process sentences and capitalize
  let result = '';
  let capitalizeNext = true; // First sentence should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (segment.trim() === '') {
      result += segment;
      continue;
    }
    
    // If this is sentence-ending punctuation, add as-is and set flag to capitalize next
    if (/^[.!?]/.test(segment)) {
      result += segment;
      capitalizeNext = true;
    } else {
      // This is actual content to potentially capitalize
      if (capitalizeNext && segment.length > 0) {
        // Find the first non-space character and capitalize it
        const firstCharIndex = segment.search(/\S/);
        if (firstCharIndex !== -1) {
          const before = segment.substring(0, firstCharIndex);
          const firstChar = segment[firstCharIndex];
          const rest = segment.substring(firstCharIndex + 1);
          
          // Capitalize the first letter if it's a letter
          const capitalizedFirst = /[a-z]/.test(firstChar) 
            ? firstChar.toUpperCase() 
            : firstChar;
          
          result += before + capitalizedFirst + rest;
        } else {
          result += segment;
        }
        capitalizeNext = false;
      } else {
        result += segment;
      }
    }
  }
  
  // Clean up multiple spaces between sentences
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern - matches http/https and www URLs
  // Includes domain names, IP addresses, ports, paths, query strings, fragments
  const urlPattern = /\b((?:https?:\/\/|www\.)[^\s<>"'()\[\]{}]+)(?=[\s<>"'()\[\]{}]|$)/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean trailing punctuation (.,!?;:) but not other meaningful characters
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but don't touch https://
  // Use word boundary to avoid partial matches
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match URLs with various schemes
  // Captures: scheme, domain, path
  const urlPattern = /(\bhttps?:\/\/)([^\/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, scheme, domain, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Default: keep the same domain
    let newDomain = domain;
    
    // Only rewrite host if path starts with /docs/ AND doesn't contain excluded patterns
    if (path && path.startsWith('/docs/')) {
      // Check for excluded patterns that indicate dynamic/legacy content
      const hasExcludedPattern = /(?:cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
      
      if (!hasExcludedPattern) {
        // Extract the base domain (without subdomains) and rewrite to docs.
        // Handle case where domain might already have subdomains
        const domainParts = domain.split('.');
        if (domainParts.length >= 2) {
          // Example: example.com -> docs.example.com
          newDomain = `docs.${domainParts.slice(-2).join('.')}`;
        }
      }
    }
    
    return newScheme + newDomain + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation - not accounting for leap years in detail)
  const daysInMonth = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > daysInMonth[monthNum as keyof typeof daysInMonth]) {
    return 'N/A';
  }
  
  return year;
}
