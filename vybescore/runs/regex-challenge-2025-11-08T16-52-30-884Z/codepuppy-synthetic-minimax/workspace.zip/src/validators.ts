export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern that supports:
  // - Unicode letters with accents
  // - Dots (but not consecutive or at start/end)
  // - Plus tags
  // - Hyphens
  // - Common domain formats
  // Rejects:
  // - Double dots
  // - Trailing dots
  // - Domains with underscores
  const emailPattern = /^[\p{L}\p{M}0-9+=._-]+@[\p{L}\p{M}0-9.-]+\.[\p{L}\p{M}]{2,}$/u;
  
  // Additional checks for invalid patterns
  if (!value || typeof value !== 'string') return false;
  
  // Reject double dots anywhere
  if (value.includes('..')) return false;
  
  // Reject leading/trailing dots in local part
  const [local, domain] = value.split('@');
  if (!local || !domain) return false;
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Basic regex validation
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all common separators and spaces
  const cleaned = value.replace(/[\s\-\(\)]/g, '');
  
  // Check for optional +1 prefix
  const hasCountryCode = cleaned.startsWith('+1');
  const digits = hasCountryCode ? cleaned.slice(2) : cleaned;
  
  // Must be exactly 10 digits for US phone numbers
  if (digits.length !== 10 || !/^\d+$/.test(digits)) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Disallow impossible area codes (leading 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate the original format matches acceptable patterns
  const patterns = [
    /^\+1\s?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/, // +1 (###) ###-####
    /^\(\d{3}\)\s?\d{3}[\s-]?\d{4}$/, // (###) ###-####
    /^\d{3}[\s-]?\d{3}[\s-]?\d{4}$/, // ###-#### or ### ####
    /^\d{10}$/, // ##########
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, but keep track of structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern matches:
  // +54 9 11 1234 5678 (mobile with country code)
  // 011 1234 5678 (Buenos Aires, no country code)
  // +54 341 123 4567 (landline with country code)
  // 0341 4234567 (landline with trunk prefix)
  const argentinePhonePattern = /^(\+54)?(9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhonePattern);
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // If no country code, must start with trunk prefix 0
  if (!countryCode && !areaCode.startsWith('0')) return false;
  
  // Extract area code without trunk prefix for length check
  const effectiveAreaCode = areaCode.startsWith('0') ? areaCode.slice(1) : areaCode;
  
  // Area code must be 2-4 digits and must not start with 0
  if (effectiveAreaCode.length < 2 || effectiveAreaCode.length > 4) return false;
  if (effectiveAreaCode.startsWith('0')) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace for validation
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Allow: Unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject: Digits, most symbols (except apostrophe and hyphen)
  const namePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!namePattern.test(trimmed)) return false;
  
  // Additional validation to reject obviously invalid patterns like "X Æ A-12"
  // Check if contains digits or unusual symbols
  if (/\d/.test(trimmed)) return false;
  
  // Reject names with consecutive spaces, hyphens, or apostrophes
  if (/\s{2,}/.test(trimmed) || /-{2,}/.test(trimmed) || /'{2,}/.test(trimmed)) return false;
  
  // Ensure name starts and ends with a letter (not punctuation or space)
  if (!/^[\p{L}\p{M}]/u.test(trimmed) || !/[\p{L}\p{M}]$/u.test(trimmed)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(number: string): boolean {
  const digits = number.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Card patterns: Visa starts with 4, Mastercard starts with 51-55 or 2221-2720, AmEx starts with 34 or 37
  const visaPattern = /^4(\d{12}|\d{15})$/;
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  const isValidFormat = visaPattern.test(cleaned) || 
                        mastercardPattern.test(cleaned) || 
                        amexPattern.test(cleaned);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
