import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  const MAX_LIMIT = 100;

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Invalid page: must be a number' });
      }
      page = Number(pageParam);
      if (page < 1 || !Number.isInteger(page)) {
        return res.status(400).json({ error: 'Invalid page: must be a positive integer' });
      }
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Invalid limit: must be a number' });
      }
      limit = Number(limitParam);
      if (limit < 1 || !Number.isInteger(limit)) {
        return res.status(400).json({ error: 'Invalid limit: must be a positive integer' });
      }
      if (limit > MAX_LIMIT) {
        return res.status(400).json({ error: `Invalid limit: must not exceed ${MAX_LIMIT}` });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
