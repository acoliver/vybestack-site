/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input is not valid Base64.
 */
export function decode(input: string): string {
  // Check for invalid Base64 characters (anything outside the standard Base64 alphabet and padding)
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, and = for padding
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for invalid padding (padding can only appear at the end and must be 0-2 characters)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    // Padding must be the last part of the string
    if (paddingMatch.index !== input.length - paddingLength) {
      throw new Error('Invalid Base64 input: padding not at the end');
    }
  }

  // Check for minimum valid length (Base64 strings must have length divisible by 4, or can be made so by adding padding)
  if (input.length > 0 && input.replace(/=/g, '').length % 4 === 1) {
    throw new Error('Invalid Base64 input: invalid length');
  }

  const buffer = Buffer.from(input, 'base64');

  // If the decoded buffer is empty and input wasn't just whitespace/padding, that's suspicious
  // However, empty input should decode to empty output
  if (buffer.length === 0 && input.trim().length > 0 && !/^=+$/.test(input)) {
    // Check if it was actually valid by trying to re-encode
    // This catches some edge cases where Buffer.from is too lenient
    throw new Error('Failed to decode Base64 input: invalid data');
  }

  return buffer.toString('utf8');
}