/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split the text into sentences, but keep the delimiters
  const sentences = [];
  let start = 0;
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === '.' || char === '!' || char === '?') {
      // Extract the sentence including the delimiter
      const sentence = text.substring(start, i + 1);
      sentences.push(sentence);
      start = i + 1;
      
      // Skip any spaces after the delimiter
      while (start < text.length && text[start] === ' ') {
        start++;
      }
    }
  }
  
  // Add any remaining text as the last sentence
  if (start < text.length) {
    sentences.push(text.substring(start));
  } else if (sentences.length > 0 && text.endsWith('.')) {
    sentences.push("");
  }
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Skip empty sentences
    if (!sentence.trim()) return sentence;
    
    // Find the first non-space character
    const firstCharIndex = sentence.search(/\S/);
    if (firstCharIndex === -1) return sentence;
    
    // Check if the first character is already capitalized
    const firstChar = sentence[firstCharIndex];
    
    // Don't capitalize if it seems like an abbreviation
    // This is a basic heuristic - check for patterns like "e.g." or "i.e."
    const remainingText = sentence.substring(firstCharIndex + 1).trim();
    const nextChars = remainingText.substring(0, 3);
    const isAbbreviation = 
      (firstChar.toLowerCase() === 'e' && nextChars.startsWith('.g.')) ||
      (firstChar.toLowerCase() === 'i' && nextChars.startsWith('.e.'));
    
    if (isAbbreviation) {
      return sentence;
    }
    
    // Capitalize the first letter
    return (
      sentence.substring(0, firstCharIndex) + 
      firstChar.toUpperCase() + 
      sentence.substring(firstCharIndex + 1)
    );
  });
  
  // Join sentences back together with proper spacing
  return processedSentences.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex to match typical URLs
  // Handle http(s), www, domain extensions, paths, querystrings, anchors
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  // Find all URL matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,!?;:)
    return url.replace(/[.,!?;:)\]}]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Simple regex to find http:// and replace with https://
  // Use word boundaries to avoid replacing partial strings
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Function to transform each URL match
  const transformUrl = (match: string, protocol: string, domain: string, path: string): string => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Create the full URL path for analysis
    const fullPath = path || '/';
    
    // If the path starts with /docs/, rewrite to docs.example.com
    if (fullPath.startsWith('/docs/')) {
      return `${newProtocol}docs.example.com${fullPath}`;
    } else {
      // Just upgrade the protocol
      return `${newProtocol}${domain}${fullPath}`;
    }
  };
  
  // Regex to match URLs to rewrite
  // Capture protocol, domain, and path components
  const urlRegex = /(https?):\/\/([^\/\s]+)(\/[^\s]*)?/g;
  
  // Apply transformation to all HTTP/HTTPS URLs
  return text.replace(urlRegex, transformUrl);
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day combination (but not full date validation for simplicity)
  // We'll just check some invalid combinations
  const invalidDayForMonth = [
    month === 2 && day > 29,
    month === 4 && day > 30,
    month === 6 && day > 30,
    month === 9 && day > 30,
    month === 11 && day > 30
  ];
  
  if (invalidDayForMonth.some(val => val)) {
    return 'N/A';
  }
  
  return year;
}
