export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that meets the requirements:
  // - Allows typical addresses like name+tag@example.co.uk
  // - Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Quick regex check first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Domain part should not contain underscores
  const domain = value.split('@')[1];
  if (domain?.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for checking
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if the number is at least 10 digits (minimum for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Remove +1 country code prefix if present
  let normalizedDigits = digitsOnly;
  if (normalizedDigits.startsWith('1') && normalizedDigits.length > 10) {
    normalizedDigits = normalizedDigits.substring(1);
  }
  
  // Check if we have exactly 10 digits after removing country code
  if (normalizedDigits.length !== 10) {
    return false;
  }
  
  // Area code should not start with 0 or 1
  const areaCode = normalizedDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Full US phone regex check for common formats
  const phoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) to get just the digits
  const digitsOnly = value.replace(/[ -]/g, '');
  
  // Full regex to validate structure
  // Optional +54 country code
  // Optional 0 trunk prefix
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, starting with 1-9
  // Subscriber: 6-8 digits
  const argPhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check the structure
  if (!argPhoneRegex.test(digitsOnly)) {
    return false;
  }
  
  // Extract components
  const hasCountryCode = digitsOnly.startsWith('+54');
  
  // If not using country code, must start with trunk prefix 0
  if (!hasCountryCode && !digitsOnly.startsWith('0')) {
    return false;
  }
  
  // Let's extract the parts more carefully
  // Remove +54 if present
  let tempDigits = hasCountryCode ? digitsOnly.substring(3) : digitsOnly;
  
  // Remove trunk prefix if present
  if (tempDigits.startsWith('0')) {
    tempDigits = tempDigits.substring(1);
  }
  
  // Remove mobile indicator if present
  if (tempDigits.startsWith('9')) {
    tempDigits = tempDigits.substring(1);
  }
  
  // Now tempDigits should be areaCode + subscriberNumber
  // Area code is 2-4 digits, subscriber is 6-8 digits
  const areaCodeLength = 2 + Math.min(2, Math.max(0, tempDigits.length - 8));
  const areaCode = tempDigits.substring(0, areaCodeLength);
  const subscriberNumber = tempDigits.substring(areaCodeLength);
  
  // Validate parts
  // Area code must start with 1-9
  if (areaCode[0] === '0') {
    return false;
  }
  // Subscriber must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[a-zA-Z\u00c0-\u024fáéíóúÁÉÍÓÚñÑ'’\- ]+$/;
  
  // Quick regex check first
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if it contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (can't be all spaces, hyphens, apostrophes)
  if (/(?<![a-zA-Z])/.test(value)) {
    const hasLetter = /[a-zA-Z\u00c0-\u024f]/.test(value);
    if (!hasLetter) {
      return false;
    }
  }
  
  // Check for excessive special characters that would indicate non-names
  const ratioSpecialChars = (value.match(/[ '\-]/g) || []).length / value.length;
  if (value.length > 1 && ratioSpecialChars > 0.5) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn algorithm check
 */
function runLuhnCheck(number: string): boolean {
  // Implementation of Luhn algorithm
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    const digitStr = number.charAt(i);
    if (!/\d/.test(digitStr)) {
      continue; // Skip non-digits (should be none for clean input)
    }
    
    let digit = parseInt(digitStr, 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // First, remove any non-digit characters (spaces, hyphens)
  const digitsOnly = value.replace(/\D/g, '');
  
  // Validate based on credit card patterns
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  
  // Visa pattern
  const visaPattern = /^4\d{12}(?:\d{3})?$/; // 13 or 16 digits
  
  // Mastercard pattern
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  
  // American Express pattern
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if number matches any of the patterns
  const isValidPattern = 
    visaPattern.test(digitsOnly) ||
    mastercardPattern.test(digitsOnly) ||
    amexPattern.test(digitsOnly);
  
  if (!isValidPattern) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(digitsOnly);
}
