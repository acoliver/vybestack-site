declare module 'sql.js' {
  export interface SqlJs {
    Database: {
      new(data?: ArrayBuffer): Database;
    };
  }

  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): unknown[][];
    prepare(sql: string): Statement;
    export(): ArrayBuffer;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }

  const sqljs: SqlJs;
  export { sqljs as default, SqlJs, Database, Statement };
}