import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { createServer } from 'http';
import * as fs from 'fs';
import * as path from 'path';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = join(__dirname, '..');

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class FormCaptureApp {
  private app: express.Application;
  private server: ReturnType<typeof createServer>;
  private db: import('sql.js').Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.server = createServer(this.app);
    this.dbPath = join(projectRoot, 'data', 'submissions.sqlite');
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(join(projectRoot, 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', join(projectRoot, 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();

      let dbBuffer: ArrayBuffer;
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        dbBuffer = dbFile.buffer.slice(dbFile.byteOffset, dbFile.byteOffset + dbFile.byteLength);
      } else {
        dbBuffer = new ArrayBuffer(0);
      }

      this.db = new SQL.Database(dbBuffer);

      // Initialize schema if database is empty
      if (this.db) {
        const result = this.db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='submissions'");
        if (result.length === 0) {
          const schemaPath = path.join(projectRoot, 'db', 'schema.sql');
          const schema = fs.readFileSync(schemaPath, 'utf-8');
          this.db.run(schema);
        }
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      process.exit(1);
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: {},
        formData: {},
        success: false
      });
    });

    this.app.post('/submit', (req, res) => {
      const formData = req.body as FormSubmission;
      const errors = this.validateForm(formData);

      if (Object.keys(errors).length > 0) {
        return res.status(400).render('form', {
          errors,
          formData,
          success: false
        });
      }

      this.saveSubmission(formData);
      res.redirect(302, '/thank-you');
    });

    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });
  }

  private validateForm(data: FormSubmission): Record<string, string> {
    const errors: Record<string, string> = {};

    if (!data.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!data.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!data.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!data.city?.trim()) {
      errors.city = 'City is required';
    }

    if (!data.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province is required';
    }

    if (!data.postalCode?.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    }

    if (!data.country?.trim()) {
      errors.country = 'Country is required';
    }

    if (!data.email?.trim()) {
      errors.email = 'Email is required';
    } else if (!this.isValidEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!data.phone?.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!this.isValidPhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    return errors;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  private saveSubmission(data: FormSubmission): void {
    if (!this.db) return;

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run(
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone
      );
    } finally {
      stmt.free();
      this.saveDatabase();
    }
  }

  public async start(port: number = 3535): Promise<void> {
    await this.initializeDatabase();
    
    return new Promise((resolve) => {
      this.server.listen(port, () => {
        console.log(`Form capture server running on port ${port}`);
        resolve();
      });
    });
  }

  public async stop(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    
    return new Promise((resolve) => {
      this.server.close(() => {
        console.log('Server stopped');
        resolve();
      });
    });
  }
}

// Create and start the server
const app = new FormCaptureApp();

process.on('SIGTERM', async () => {
  await app.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  await app.stop();
  process.exit(0);
});

// Start the server
app.start(Number(process.env.PORT) || 3535).catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});