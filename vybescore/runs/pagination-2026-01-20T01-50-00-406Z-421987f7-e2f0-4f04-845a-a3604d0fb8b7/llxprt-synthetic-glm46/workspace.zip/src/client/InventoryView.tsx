import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (!items.length) {
    return <p>No items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ data, onPageChange }: { data: { page: number; limit: number; total: number; hasNext: boolean }; onPageChange: (page: number) => void }): JSX.Element {
  const { page, limit, total, hasNext } = data;

  const hasPrevious = page > 1;
  const totalPages = Math.ceil(total / limit);

  return (
    <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <button 
        disabled={!hasPrevious} 
        onClick={() => onPageChange(page - 1)}
      >
        Previous
      </button>
      
      <span>
        {page} / {totalPages || 1} ({total} items)
      </span>
      
      <button 
        disabled={!hasNext} 
        onClick={() => onPageChange(page + 1)}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls data={data} onPageChange={setCurrentPage} />
    </section>
  );
}
