// Manual testing script for pagination implementation
import request from 'supertest';
import { createApp } from './src/server/app';
import { createDatabase } from './src/server/db';

(async () => {
  console.log('Testing pagination API...\n');
  
  const db = await createDatabase();
  const app = await createApp(db);
  
  // Test 1: Basic request (default page=1, limit=5)
  console.log('1. Testing default pagination (page=1, limit=5):');
  const response1 = await request(app).get('/inventory');
  console.log(JSON.stringify(response1.body, null, 2));
  console.log(`Status: ${response1.status}\n`);
  
  // Test 2: Second page
  console.log('2. Testing page=2:');
  const response2 = await request(app).get('/inventory?page=2&limit=5');
  console.log(JSON.stringify(response2.body, null, 2));
  console.log(`Status: ${response2.status}\n`);
  
  // Test 3: Last page (partial data)
  console.log('3. Testing page=3 (last page):');
  const response3 = await request(app).get('/inventory?page=3&limit=5');
  console.log(JSON.stringify(response3.body, null, 2));
  console.log(`Status: ${response3.status}\n`);
  
  // Test 4: Beyond last page (should return empty)
  console.log('4. Testing page=4 (beyond last page):');
  const response4 = await request(app).get('/inventory?page=4&limit=5');
  console.log(JSON.stringify(response4.body, null, 2));
  console.log(`Status: ${response4.status}\n`);
  
  // Test 5: Invalid page parameter
  console.log('5. Testing invalid page parameter (page=0):');
  const response5 = await request(app).get('/inventory?page=0');
  console.log(JSON.stringify(response5.body, null, 2));
  console.log(`Status: ${response5.status}\n`);
  
  // Test 6: Invalid limit parameter
  console.log('6. Testing invalid limit parameter (limit=-5):');
  const response6 = await request(app).get('/inventory?limit=-5');
  console.log(JSON.stringify(response6.body, null, 2));
  console.log(`Status: ${response6.status}\n`);
  
  console.log('Testing complete!');
  process.exit(0);
})().catch(error => {
  console.error('Error during testing:', error);
  process.exit(1);
});