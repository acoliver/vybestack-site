const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validate if a string is valid Base64 according to the standard specification.
 * Checks for correct characters, length (multiple of 4), and valid padding.
 */
function isValidBase64(input: string): boolean {
  // Remove padding for validation
  const withoutPadding = input.replace(/=+$/, '');
  
  // Check that all non-padding characters are from the Base64 alphabet
  const validCharsRegex = /^[A-Za-z0-9+/]*$/;
  if (!validCharsRegex.test(withoutPadding)) {
    return false;
  }
  
  // Empty string is not valid Base64
  if (withoutPadding.length === 0) {
    return false;
  }
  
  // Check that total length (including padding) is a multiple of 4
  if (input.length % 4 !== 0) {
    return false;
  }
  
  // Check padding is valid (only 1-2 padding chars at the end)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    // Only 0, 1, or 2 padding chars are allowed
    if (paddingLength > 2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  const buffer = Buffer.from(input, 'utf8');
  return buffer.toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Trim whitespace from input
  const trimmed = input.trim();
  
  // Add padding if missing to make length a multiple of 4
  let normalized = trimmed;
  const paddingNeeded = (4 - (trimmed.length % 4)) % 4;
  if (paddingNeeded > 0) {
    normalized = trimmed + '='.repeat(paddingNeeded);
  }
  
  // Validate the Base64 input
  if (!isValidBase64(normalized)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if decoding produced valid UTF-8
    // Buffer.from with 'base64' encoding is lenient and may not throw
    // on invalid input, so we need to verify the result
    const decoded = buffer.toString('utf8');
    
    // Verify by re-encoding - if it doesn't match, the input was invalid
    // This catches cases like malformed Base64 that Buffer accepts
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    const normalizedOriginal = normalized.replace(/=+$/, ''); // Remove padding for comparison
    
    // Handle edge case where original had no padding
    if (normalizedOriginal !== reEncoded.replace(/=+$/, '')) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message === INVALID_BASE64_ERROR) {
      throw error;
    }
    throw new Error(INVALID_BASE64_ERROR);
  }
}
