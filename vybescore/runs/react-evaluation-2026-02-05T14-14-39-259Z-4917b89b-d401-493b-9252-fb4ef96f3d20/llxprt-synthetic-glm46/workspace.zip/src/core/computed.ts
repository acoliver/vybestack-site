/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track if we have an explicit initial value
  const hasInitialValue = value !== undefined
  
  const getter = (): T => {
    const previousObserver = getActiveObserver()
    setActiveObserver(o)
    try {
      // For the first access with an initial value, the updateFn should treat the parameter as undefined
      // to use the default parameter in the update function
      if (hasInitialValue && o.value === value) {
        // This is the initial computation, use the default parameter behavior
        // by passing undefined as the parameter
        o.value = updateFn(undefined)
      } else {
        o.value = updateFn(o.value)
      }
      return o.value!
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Initialize the computed value immediately by running the getter
  getter()
  
  return getter
}
