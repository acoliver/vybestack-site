/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Track subscription state and observers
  let isSubscribed = true
  const dependentObservers: Observer<unknown>[] = []
  
  // Create an observer for this callback
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (!isSubscribed) return value!
      
      // Execute the callback function
      const prevObserver = getActiveObserver()
      setActiveObserver(observer)
      try {
        // Reset dependencies and collect new ones
        dependentObservers.length = 0
        const result = updateFn(currentValue)
        return result
      } finally {
        setActiveObserver(prevObserver)
      }
    }
  }
  
  // Execute callback immediately to track initial dependencies
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    if (!isSubscribed) return
    isSubscribed = false
  }
}
