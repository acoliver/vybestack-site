/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Use array to track all dependent observers for multiple subscribers
  const observers: Observer<unknown>[] = []
  const pendingCallbacks: Observer<unknown>[] = []
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observers.includes(observer as Observer<unknown>)) {
      observers.push(observer as Observer<unknown>)
      
      
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    value = nextValue
    
// Notify all dependent observers, allowing for cascading updates
    let index = 0
    while (index < observers.length) {
      const observer = observers[index]
      
      updateObserver(observer as Observer<T>)
      
      // Check if new observers were added during this update
      if (index < observers.length && observers[index] !== observer) {
        // Observers changed during update, don't advance index yet
        continue
      }
      index++
    }
      index++
    }
    
    // Process any pending callbacks that should be notified
    while (pendingCallbacks.length > 0) {
      const callback = pendingCallbacks.shift()!
      if (callback.__isCallback) {
        updateObserver(callback as Observer<T>)
      }
    }
    
    return value
  }

  return [read, write]
}
