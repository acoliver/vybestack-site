import { Formatter, ReportData } from '../types/interfaces.js';

export const renderText: Formatter = {
  render: (data: ReportData, includeTotals: boolean): string => {
    let output = '';
    
    // Title (no markdown heading)
    output += `${data.title}\n\n`;
    
    // Summary
    output += `${data.summary}\n\n`;
    
    // Entries heading
    output += `Entries:\n`;
    
    // Format each entry
    data.entries.forEach(entry => {
      output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
    });
    
    // Add totals if requested
    if (includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `\nTotal: $${total.toFixed(2)}`;
    }
    
    return output;
  }
};