#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { ReportData, CliOptions } from '../types/interfaces.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): CliOptions & { dataFile?: string } {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = resolve(args[0]);
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && args[i + 1]) {
      format = args[i + 1] as 'markdown' | 'text';
      i++; // Skip next arg as it's the value
    } else if (arg === '--output' && args[i + 1]) {
      output = args[i + 1];
      i++; // Skip next arg as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return { dataFile, format, output, includeTotals };
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    // Validate entries
    data.entries.forEach((entry, index) => {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Missing or invalid label in entry ${index + 1}`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Missing or invalid amount in entry ${index + 1}`);
      }
    });
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${filePath}'`);
    } else if (error instanceof Error && error.message.includes("ENOENT")) {
      console.error(`Error: File '${filePath}' not found`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Invalid data file'}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const options = parseArgs(process.argv);
  const data = loadAndValidateData(options.dataFile!);
  
  let output: string;
  switch (options.format) {
    case 'markdown':
      output = renderMarkdown.render(data, options.includeTotals);
      break;
    case 'text':
      output = renderText.render(data, options.includeTotals);
      break;
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
  
  if (options.output) {
    try {
      writeFileSync(resolve(options.output), output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${options.output}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
