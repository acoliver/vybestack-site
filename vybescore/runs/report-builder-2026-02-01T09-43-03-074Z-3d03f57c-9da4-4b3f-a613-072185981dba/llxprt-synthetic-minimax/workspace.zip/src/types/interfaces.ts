export interface Entry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: Entry[];
}

export interface CliOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

export interface Formatter {
  render: (data: ReportData, includeTotals: boolean) => string;
}