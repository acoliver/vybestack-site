/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  value?: T
  updateFn: UpdateFn<T>
  notify?: () => void
}

export interface Signal<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<T>>
}

let activeObserver: Observer<unknown> | undefined = undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function trackSignal<T>(signal: Signal<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    signal.observers.add(observer as Observer<T>)
  }
}

export function updateSignal<T>(signal: Signal<T>): void {
  const observers = [...signal.observers]
  for (const observer of observers) {
    if (observer.notify) {
      observer.notify()
    } else if (observer.updateFn) {
      observer.value = observer.updateFn(observer.value)
    }
  }
}
