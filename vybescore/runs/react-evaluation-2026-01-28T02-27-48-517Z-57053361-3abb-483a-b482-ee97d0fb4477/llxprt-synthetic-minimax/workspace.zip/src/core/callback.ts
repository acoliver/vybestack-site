/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    notify: () => {
      // Execute the callback when dependencies change
      if (observer.updateFn) {
        observer.value = observer.updateFn(observer.value)
      }
    }
  }
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
  }
  
  return unsubscribe
}
