/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  setActiveObserver,
  trackSignal,
  updateSignal,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let computedValue: T = value as T

  const read: GetterFn<T> = () => {
    // Track this observer as active during dependency reading
    const previous = getActiveObserver()
    setActiveObserver(observer)
    try {
      // Re-evaluate the computed function
      computedValue = updateFn(computedValue)
    } finally {
      setActiveObserver(previous)
    }
    
    return computedValue
  }

  return read
}
