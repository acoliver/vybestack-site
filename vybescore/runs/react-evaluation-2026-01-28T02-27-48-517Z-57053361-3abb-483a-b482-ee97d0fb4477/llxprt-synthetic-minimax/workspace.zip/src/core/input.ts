/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Signal,
  getActiveObserver,
  setActiveObserver,
  trackSignal,
  updateSignal,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const signal: Signal<T> = {
    name: options?.name,
    value,
    observers: new Set(),
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    trackSignal(signal)
    return signal.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasEqualFn = typeof _equal === 'function'
    const shouldUpdate = hasEqualFn 
      ? !_equal(signal.value, nextValue)
      : signal.value !== nextValue

    if (shouldUpdate) {
      signal.value = nextValue
      updateSignal(signal)
    }
    return signal.value
  }

  return [read, write]
}
