/**
 * Encode plain text to Base64 using RFC 4648 canonical alphabet.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with the canonical alphabet and validates it properly.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Handle empty string
  if (input.length === 0) {
    return '';
  }

  // Basic validation: check for valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Validate padding is correct (only at the end and in proper amounts)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.slice(paddingIndex);
    if (!/^=?=?$/.test(padding) || paddingIndex < input.length - 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  // Additional validation: check if the string contains only padding
  if (/^=+$/.test(input)) {
    return '';
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: ensure the input was actually valid Base64
    // by checking if re-encoding gives us back the original input (possibly with different padding)
    const reencoded = Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '');
    const normalizedInput = input.replace(/=+$/, '');
    
    if (reencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
