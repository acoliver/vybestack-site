#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { ReportData, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals?: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: CliArgs = {
    dataFile: '',
    format: '',
  };
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      result.format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      result.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
    } else if (!result.dataFile) {
      result.dataFile = arg;
      i += 1;
    } else {
      console.error(`Unexpected argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!result.dataFile) {
    console.error('Missing data file argument');
    process.exit(1);
  }
  
  if (!result.format) {
    console.error('Missing --format argument');
    process.exit(1);
  }
  
  if (result.format !== 'markdown' && result.format !== 'text') {
    console.error('Unsupported format');
    process.exit(1);
  }
  
  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid input: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid input: missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid input: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid input: missing or invalid entries field');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid input: entry at index ${index} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid input: entry at index ${index} has missing or invalid label field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid input: entry at index ${index} has missing or invalid amount field`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Read and parse the JSON data file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error('Invalid JSON in data file');
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error('Data file not found');
      } else {
        console.error('Error reading data file:', error);
      }
      process.exit(1);
    }
    
    // Validate the report data structure
    const reportData = validateReportData(jsonData);
    
    // Create format options
    const options: FormatOptions = {
      includeTotals: args.includeTotals,
    };
    
    // Select the appropriate formatter
    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else if (args.format === 'text') {
      output = renderText(reportData, options);
    } else {
      // This should not happen as we validate the format in parseArgs
      console.error('Unsupported format');
      process.exit(1);
    }
    
    // Write to output file or stdout
    if (args.output) {
      writeFile(args.output, output)
        .then(() => {
          console.log(`Report written to ${args.output}`);
        })
        .catch((error) => {
          console.error('Error writing output file:', error);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
