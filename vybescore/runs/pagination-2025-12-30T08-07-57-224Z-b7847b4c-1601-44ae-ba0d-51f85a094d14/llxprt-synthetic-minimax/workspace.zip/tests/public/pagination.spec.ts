import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination', () => {
  let app: Express;
  let db: Database;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns correct default pagination', async () => {
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBeGreaterThan(0);
    expect(response.body.hasNext).toBe(true);
  });

  it('handles page and limit parameters correctly', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
  });

  it('validates invalid page parameter', async () => {
    const response = await request(app).get('/inventory?page=abc&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=-1&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?page=1&limit=200');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('provides correct hasNext for last page', async () => {
    // Get first page to determine total
    const firstResponse = await request(app).get('/inventory?page=1&limit=5');
    const total = firstResponse.body.total;
    const lastPage = Math.ceil(total / 5);
    
    // Request last page
    const response = await request(app).get(`/inventory?page=${lastPage}&limit=5`);
    
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(false);
  });
});