/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  const trimmed = input.replace(/\s/g, '');
  
  if (!hasValidBase64Characters(trimmed)) {
    throw new Error('Invalid Base64 input: invalid format');
  }

  if (!hasValidPadding(trimmed)) {
    throw new Error('Invalid Base64 input: invalid format');
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    if (!isValidBase64Result(trimmed, result)) {
      throw new Error('Invalid Base64 input: cannot decode');
    }
    return result;
  } catch {
    throw new Error('Invalid Base64 input: cannot decode');
  }
}

function hasValidBase64Characters(input: string): boolean {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

function hasValidPadding(input: string): boolean {
  const length = input.length;
  
  if (length % 4 === 1) {
    return false;
  }
  
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return true; // No padding
  }
  
  const paddingCount = length - paddingIndex;
  return paddingCount <= 2;
}

function isValidBase64Result(input: string, result: string): boolean {
  const reencoded = Buffer.from(result, 'utf8').toString('base64');
  return normalizeBase64(reencoded) === normalizeBase64(input);
}

function normalizeBase64(input: string): string {
  return input.replace(/=+$/, '');
}