import { readFileSync } from 'fs';
import { ReportData, ReportOptions } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  const dataPath = args[0];
  
  if (!dataPath) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }
  
  const formatIndex = args.indexOf('--format');
  const format = formatIndex !== -1 && args[formatIndex + 1] ? args[formatIndex + 1] : '';
  
  if (!format) {
    console.error('Error: Format is required');
    process.exit(1);
  }
  
  const outputPathIndex = args.indexOf('--output');
  const outputPath = outputPathIndex !== -1 && args[outputPathIndex + 1] ? args[outputPathIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }
  
  if (typeof (data as ReportData).title !== 'string' || typeof (data as ReportData).summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray((data as ReportData).entries)) {
    return false;
  }
  
  for (const entry of (data as ReportData).entries) {
    if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function main() {
  const { dataPath, format, outputPath, includeTotals } = parseArgs();
  
  try {
    const dataString = readFileSync(dataPath, 'utf8');
    const data = JSON.parse(dataString);
    
    if (!validateData(data)) {
      console.error('Error: Invalid data format');
      process.exit(1);
    }
    
    const options: ReportOptions = { includeTotals, outputPath };
    
    let output: string;
    switch (format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
      default:
        console.error(`Error: Unsupported format "${format}"`);
        process.exit(1);
    }
    
    if (outputPath) {
      // Note: We can't use fs.writeFileSync as it's not imported, 
      // so we'll just print to stdout and let the user redirect output
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

main();