declare module 'sql.js' {
  export interface SqlValue {
    // Represents a value that can be stored in SQLite
  }

  export interface SqlExecResult {
    columns: string[];
    values: SqlValue[][];
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): SqlExecResult[];
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | Uint8Array) => Database;
  }

  export default function initSqlJs(config?: { locateFile?: (filename: string) => string }): Promise<SqlJsStatic>;
}
