import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
      console.log(`Loaded existing database from ${DB_PATH}`);
    } else {
      db = new SQL.Database();
      console.log(`Created new in-memory database`);
    }

    // Initialize schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    console.log('Database schema initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
    console.log(`Database saved to ${DB_PATH}`);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Close database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and optional leading +
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    const value = formData[field]?.trim();
    if (!value) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').trim().toLowerCase()} is required`
      });
    }
  }

  // Email validation
  if (formData.email && formData.email.trim() && !validateEmail(formData.email.trim())) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (formData.phone && formData.phone.trim() && !validatePhone(formData.phone.trim())) {
    errors.push({
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +'
    });
  }

  // Postal code validation
  if (formData.postalCode && formData.postalCode.trim() && !validatePostalCode(formData.postalCode.trim())) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code can only contain letters, digits, spaces, and dashes'
    });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Validation failed - re-render form with errors and values
    const errorMessages = errors.map(e => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
    return;
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );

    // Save database after insert
    saveDatabase();

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission for personalization
  let firstName = 'Friend';
  
  try {
    if (db) {
      const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      if (result.length > 0 && result[0].values.length > 0) {
        firstName = result[0].values[0][0] as string;
      }
    }
  } catch (error) {
    console.error('Failed to fetch recent submission:', error);
  }

  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {}
  });
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    // Graceful shutdown
    const shutdown = (signal: string): void => {
      console.log(`\nReceived ${signal}, shutting down gracefully...`);
      server.close(() => {
        console.log('HTTP server closed');
        closeDatabase();
        process.exit(0);
      });

      // Force shutdown after 10 seconds
      setTimeout(() => {
        console.error('Forced shutdown after timeout');
        closeDatabase();
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

// Export for testing
export { app, initializeDatabase, closeDatabase, startServer };
