import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase, closeDatabase } from '../../src/server.js';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Initialize database
  await initializeDatabase();

  // Start server
  await new Promise<void>((resolve) => {
    server = app.listen(0, () => {
      resolve();
    });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check for proper label associations
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const submission = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(submission);

    // Should redirect
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Database file should exist
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errors = $('.error-list li').map((_, el) => $(el).text()).get();
    
    expect(errors.length).toBeGreaterThan(0);
    expect(errors.some(e => e.includes('required'))).toBe(true);
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Street',
        city: 'City',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'invalid-email',
        phone: '+1 234 567 8900'
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errors = $('.error-list li').map((_, el) => $(el).text()).get();
    
    expect(errors.some(e => e.includes('valid email'))).toBe(true);
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Street',
        city: 'City',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'test@example.com',
        phone: 'invalid-phone@!'
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errors = $('.error-list li').map((_, el) => $(el).text()).get();
    
    expect(errors.some(e => e.includes('Phone number'))).toBe(true);
  });

  it('renders thank-you page with recent submission', async () => {
    // First submit a form
    await request(app)
      .post('/submit')
      .send({
        firstName: 'Alice',
        lastName: 'Smith',
        streetAddress: '456 Oak Avenue',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'alice@example.com',
        phone: '+54 9 11 1234-5678'
      });

    // Then check thank-you page
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Alice');
    expect(response.text.toLowerCase()).toContain('thank you');
  });

  it('accepts international postal codes', async () => {
    const testCases = [
      { postalCode: 'SW1A 1AA', country: 'UK' },
      { postalCode: 'C1000', country: 'Argentina' },
      { postalCode: 'B1675', country: 'Argentina' },
      { postalCode: '12345', country: 'US' }
    ];

    for (const testCase of testCases) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Street',
          city: 'City',
          stateProvince: 'State',
          postalCode: testCase.postalCode,
          country: testCase.country,
          email: 'test@example.com',
          phone: '+1 234 567 8900'
        });

      expect(response.status).toBe(302);
    }
  });

  it('accepts international phone formats', async () => {
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '123-456-7890'
    ];

    for (const phone of testCases) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Street',
          city: 'City',
          stateProvince: 'State',
          postalCode: '12345',
          country: 'US',
          email: 'test@example.com',
          phone: phone
        });

      expect(response.status).toBe(302);
    }
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Street',
        city: 'City',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'invalid-email',
        phone: '+1 234 567 8900'
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]').val()).toBe('John');
    expect($('input[name="lastName"]').val()).toBe('Doe');
    expect($('input[name="email"]').val()).toBe('invalid-email');
  });
});
