#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';
import { getFormatter } from '../formats/index.js';
import type { RenderOptions, ReportData } from '../types.js';
import { validateReportData } from '../utils.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments using Node's standard library.
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 3) {
    printUsage();
    process.exit(1);
  }

  const inputFile = args[2];
  const formatArgIndex = args.indexOf('--format');
  const outputArgIndex = args.indexOf('--output');
  const includeTotalsIndex = args.indexOf('--includeTotals');

  if (formatArgIndex === -1 || formatArgIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    printUsage();
    process.exit(1);
  }

  const format = args[formatArgIndex + 1];
  const outputPath = outputArgIndex !== -1 && outputArgIndex + 1 < args.length ? args[outputArgIndex + 1] : null;
  const includeTotals = includeTotalsIndex !== -1;

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Prints usage information.
 */
function printUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Arguments:');
  console.error('  <data.json>       Path to the JSON file containing report data');
  console.error('  --format <format> Output format: "markdown" or "text"');
  console.error('  --output <path>   Optional: write output to file instead of stdout');
  console.error('  --includeTotals   Optional: include total amount at the end');
}

/**
 * Reads and parses the JSON input file.
 */
function readInputFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);

    if (!validateReportData(data)) {
      // This should never happen since validateReportData always throws on failure
      throw new Error('Invalid report data');
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON in ${filePath}`);
      console.error(`  ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

/**
 * Writes output to stdout or a file.
 */
function writeOutput(content: string, outputPath: string | null): void {
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, content, 'utf-8');
      console.error(`Report written to ${outputPath}`);
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error: Failed to write output to ${outputPath}`);
        console.error(`  ${error.message}`);
        process.exit(1);
      }
      throw error;
    }
  } else {
    console.log(content);
  }
}

/**
 * Main entry point.
 */
function main(): void {
  try {
    const args = parseArgs(process.argv);
    const data = readInputFile(args.inputFile);

    const formatter = getFormatter(args.format);
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter(data, options);
    writeOutput(output, args.outputPath);
  } catch (error) {
    if (error instanceof Error) {
      // Check for unsupported format error
      if (error.message.includes('Unsupported format')) {
        console.error(`Error: ${error.message}`);
        process.exit(1);
      }
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    process.exit(1);
  }
}

main();
