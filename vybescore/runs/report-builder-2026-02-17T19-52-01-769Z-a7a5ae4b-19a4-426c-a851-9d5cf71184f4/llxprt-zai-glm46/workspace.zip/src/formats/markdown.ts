/**
 * Markdown format renderer for reports.
 */

import type { Formatter, ReportData, RenderOptions } from '../types.js';
import { computeTotal, formatCurrency } from '../utils.js';

export const renderMarkdown: Formatter = (data: ReportData, options: RenderOptions): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);

  // Blank line
  lines.push('');

  // Summary
  lines.push(data.summary);

  // Blank line
  lines.push('');

  // Entries section
  lines.push('## Entries');

  // Entries list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatCurrency(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = computeTotal(data.entries);
    lines.push(`**Total:** ${formatCurrency(total)}`);
  }

  return lines.join('\n');
};
