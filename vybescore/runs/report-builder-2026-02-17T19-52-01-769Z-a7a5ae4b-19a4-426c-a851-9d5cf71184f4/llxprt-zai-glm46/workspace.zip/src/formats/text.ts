/**
 * Text format renderer for reports.
 */

import type { Formatter, ReportData, RenderOptions } from '../types.js';
import { computeTotal, formatCurrency } from '../utils.js';

export const renderText: Formatter = (data: ReportData, options: RenderOptions): string => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);

  // Summary
  lines.push(data.summary);

  // Entries section
  lines.push('Entries:');

  // Entries list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatCurrency(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = computeTotal(data.entries);
    lines.push(`Total: ${formatCurrency(total)}`);
  }

  return lines.join('\n');
};
