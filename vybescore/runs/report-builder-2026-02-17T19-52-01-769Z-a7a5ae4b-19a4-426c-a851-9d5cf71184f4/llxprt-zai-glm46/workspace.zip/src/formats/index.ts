/**
 * Format registry for easy extensibility.
 */

import type { Formatter } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

export type SupportedFormat = keyof typeof formatters;

export function isSupportedFormat(format: string): format is SupportedFormat {
  return format in formatters;
}

export function getFormatter(format: string): Formatter {
  if (!isSupportedFormat(format)) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatters[format];
}
