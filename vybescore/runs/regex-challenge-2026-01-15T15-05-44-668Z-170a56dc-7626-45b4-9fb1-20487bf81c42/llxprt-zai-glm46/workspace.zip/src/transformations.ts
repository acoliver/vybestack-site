/**
 * Capitalize the first character of each sentence.
 * - Capitalize after . ? !
 * - Insert exactly one space between sentences
 * - Collapse extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing - collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ').trim();

  // Insert a space after sentence endings if missing (before capital letters)
  // This handles cases like "Hello.World"
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Split by sentence boundaries (. ? !) followed by space or end of string
  // We'll process each sentence to capitalize it
  const sentences = result.split(/([.!?]\s*)/);

  // Process sentences: capitalize each sentence, keep delimiters
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i]) {
      sentences[i] = sentences[i].charAt(0).toUpperCase() + sentences[i].slice(1);
    }
  }

  return sentences.join('');
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, www.
  // Captures the URL without trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+?(?=[,.!?;:)]?(?:\s|<|"|$))/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation: .,!?;:)
    return url.replace(/[,!?;:)+]+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://...
 * When path begins with /docs/, rewrite host to docs.example.com
 * Skip host rewrite when path contains cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  let result = text;

  // Match http://example.com/ URLs
  // We need to capture the scheme, host, and path
  const urlRegex = /(http?:\/\/)(example\.com)(\/[^\s]*)/gi;

  result = result.replace(urlRegex, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';

    // Check if we should skip host rewrite
    // Skip conditions: cgi-bin, query strings (?,&,=), or legacy extensions
    const skipHostRewrite = /\/cgi-bin|[?&=]|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)(?:\?|\/|$)/i.test(path);

    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Rewrite host to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade the scheme
      return newScheme + host + path;
    }
  });

  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;

  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  const maxDays = daysInMonth[month];
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }

  return yearStr;
}
