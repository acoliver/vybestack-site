/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create regex to match words starting with prefix
  // \\b ensures we match whole words only
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');

  const matches = text.match(wordRegex) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));

  return matches.filter(word => !exceptionsLower.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use lookbehind to assert token is preceded by a digit
  // Use negative lookbehind to ensure token is not at start of string
  // (?<=\\d) is a positive lookbehind for a digit
  // (?<!^) is a negative lookbehind to ensure not at start
  const tokenRegex = new RegExp(`(?<=\\d)${escapedToken}(?!\\d)`, 'g');

  // The match will just be the token, but we need to include the digit in the result
  // Let's use a different approach with exec to capture the full match
  const results: string[] = [];
  let match: RegExpExecArray | null;

  // Reset regex state
  tokenRegex.lastIndex = 0;

  while ((match = tokenRegex.exec(text)) !== null) {
    // Get the preceding digit
    const index = match.index;
    const precedingChar = text.charAt(index - 1);

    if (/\d/.test(precedingChar)) {
      results.push(precedingChar + match[0]);
    }
  }

  return results;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, 123123)
  // Look for patterns of 2+ characters that repeat immediately
  // Capture any 2-4 character sequence and check if it repeats
  for (let len = 2; len <= 4; len++) {
    // Create a pattern that captures a group of length len and checks if it repeats
    // Using dynamic regex construction
    const pattern = `(.{${len}})\\1`;
    const repeatRegex = new RegExp(pattern, 'g');
    if (repeatRegex.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // Matches:
  // 1. Full notation: 8 groups of 1-4 hex digits (e.g., 2001:0db8:85a3:0000:0000:8a2e:0370:7334)
  // 2. Shorthand with :: (can represent one or more consecutive zero groups)
  //    - Leading :: (e.g., ::1)
  //    - Trailing :: (e.g., fe80::)
  //    - Middle :: (e.g., 2001:db8::1)
  // 3. Does not match IPv4 addresses like 192.168.1.1

  const ipv6Pattern = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})|(?:(?:[0-9a-fA-F]{1,4}:){1,7}:)|(?::(?:[0-9a-fA-F]{1,4}:){1,7})|(?:::)/;

  return ipv6Pattern.test(value);
}
