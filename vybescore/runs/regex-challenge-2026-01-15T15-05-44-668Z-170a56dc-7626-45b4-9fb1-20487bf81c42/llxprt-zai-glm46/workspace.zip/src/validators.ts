export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex explanation:
  // - Local part: alphanumeric plus !#$%&'*+/=?^_`{|}~- and dots (but not consecutive/leading/trailing)
  // - @ symbol
  // - Domain: alphanumeric with hyphens and dots (but no underscores, no consecutive dots)
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!-)[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;

  // Check for double dots in local or domain part
  if (value.includes('..')) {
    return false;
  }

  // Check for underscore in domain
  const atIndex = value.lastIndexOf('@');
  if (atIndex !== -1) {
    const domain = value.substring(atIndex + 1);
    if (domain.includes('_')) {
      return false;
    }
  }

  // Check for trailing dot before @ or at end
  if (value.endsWith('.') || (atIndex !== -1 && value[atIndex - 1] === '.')) {
    return false;
  }

  // Check for leading dot in local part
  if (value.startsWith('.')) {
    return false;
  }

  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }

  // US phone number must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Silence unused variable warning (we could use this option in the future)
  void options;

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (without country code, with trunk prefix)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (without country code, with trunk prefix)
 *
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total after area code
 * - When country code omitted, must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Regex for Argentine phone numbers
  // Group 1: Optional +54 country code
  // Group 2: Optional trunk prefix 0 (required if no country code)
  // Group 3: Optional mobile indicator 9
  // Group 4: Area code (2-4 digits, leading 1-9)
  // Group 5: Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(0)?[9]?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(argentinePhoneRegex);

  if (!match) {
    return false;
  }

  const [, trunkPrefix] = match;

  // Silence unused variable warnings - these could be used for more detailed validation
  void match[3]; // areaCode
  void match[4]; // subscriber

  // If no country code (+54), trunk prefix (0) must be present
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !trunkPrefix) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Allows: Unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: Digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Reject digits, symbols, and other special characters
  const nameRegex = /^[\p{L}'\-\s]+$/u;

  // Must not be empty or only spaces
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }

  // Check for invalid symbols (anything not in our allowed set)
  // Our regex already handles this, but let's be explicit about rejecting things like Æ-12

  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }

  return nameRegex.test(value);
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa/Mastercard/AmEx prefixes and lengths
 * Performs: Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be 13-19 digits (standard lengths)
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }

  // Check card prefixes
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const visaRegex = /^4/;
  const mastercardRegex = /^5[1-5]|^2[2-7][0-2][0-9]|^27[0-1][0-9]|^2720/;
  const amexRegex = /^3[47]/;

  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }

  // Additional length checks based on card type
  if (amexRegex.test(cleaned) && cleaned.length !== 15) {
    return false; // AmEx is always 15 digits
  }

  if (visaRegex.test(cleaned) && (cleaned.length < 13 || cleaned.length > 19)) {
    return false; // Visa is 13-19 digits
  }

  if (mastercardRegex.test(cleaned) && cleaned.length !== 16) {
    return false; // Mastercard is always 16 digits
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
