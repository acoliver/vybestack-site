/**
 * Capitalize the first character of each sentence.
 * - After sentence-ending punctuation (.?!)
 * - Insert exactly one space between sentences
 * - Collapse extra spaces
 * - Preserve abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';

  // First, normalize spaces around sentence boundaries
  let result = text
    // Insert space after sentence endings if missing
    .replace(/([.!?])([A-Z])/g, '$1 $2')
    // Collapse multiple spaces into one
    .replace(/\s+/g, ' ')
    .trim();

  // Capitalize first character of the entire string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Capitalize after sentence-ending punctuation
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  // Also handle case where sentence starts right after punctuation without space
  result = result.replace(/([.!?])([a-z])/g, (_, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });

  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];

  // URL pattern matching http/https URLs
  // Allows: domain, IP, port, path, query, fragment
  // Excludes trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.]|(?:%[0-9a-fA-F]{2})|[!$&'()*+,;=:@])+(?:\/(?:[-\w._~!$&'()*+,;=:@%]|(?:%[0-9a-fA-F]{2}))*)*(?:\?(?:[-\w._~!$&'()*+,;=:@/?%]|(?:%[0-9a-fA-F]{2}))*)?(?:#(?:[-\w._~!$&'()*+,;=:@/?%]|(?:%[0-9a-fA-F]{2}))*)?/g;

  const matches = text.match(urlRegex) || [];

  // Strip trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';

  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\/(?!https:)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';

  // Pattern to match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, schemeAndHost, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    let newHost = 'example.com';

    // Check if path should trigger special handling
    // Skip if contains dynamic hints
    const hasDynamicHint = /[?&=]|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);

    // Check if path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      newHost = 'docs.example.com';
    }

    return newScheme + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';

  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

  if (!dateMatch) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  return year;
}
