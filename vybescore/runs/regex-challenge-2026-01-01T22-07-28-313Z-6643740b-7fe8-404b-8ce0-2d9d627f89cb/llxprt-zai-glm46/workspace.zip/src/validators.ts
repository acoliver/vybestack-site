export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts: name+tag@example.co.uk style addresses
 * Rejects: double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Check for basic structure and reject invalid patterns
  if (!value || value.length > 254) return false;

  // Reject double dots, trailing dots, leading dots
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Main email regex pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Split and validate parts
  const [local, domain] = value.split('@');

  // Local part should not be empty and no trailing dot
  if (!local || local.endsWith('.') || local.startsWith('.')) {
    return false;
  }

  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }

  const tld = domainParts[domainParts.length - 1];
  // TLD must be at least 2 characters and only letters
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  // Each domain part should be valid
  for (const part of domainParts) {
    if (!part || part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value) return false;

  // Remove all whitespace and common separators
  const cleaned = value.replace(/[\s()\-.]/g, '');

  // Check for optional +1 prefix
  const hasPlusPrefix = cleaned.startsWith('+1');
  const digits = hasPlusPrefix ? cleaned.slice(2) : cleaned;

  // Must be exactly 10 digits (NANP format)
  if (digits.length !== 10 || !/^\d+$/.test(digits)) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required if country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;

  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if number starts with country code
  const hasCountryCode = cleaned.startsWith('+54');

  // Extract parts without country code
  const withoutCountry = hasCountryCode ? cleaned.slice(3) : cleaned;

  // If no country code, must have trunk prefix 0
  if (!hasCountryCode && !withoutCountry.startsWith('0')) {
    return false;
  }

  // Remove trunk prefix for further processing
  const withoutTrunk = withoutCountry.startsWith('0') ? withoutCountry.slice(1) : withoutCountry;

  // Check for mobile indicator 9
  let areaCode: string;
  let subscriber: string;

  if (withoutTrunk.startsWith('9')) {
    // Mobile format: 9 + area code + subscriber
    const mobileMatch = withoutTrunk.slice(1).match(/^([1-9]\d{1,3})(\d{6,8})$/);
    if (!mobileMatch) return false;
    areaCode = mobileMatch[1];
    subscriber = mobileMatch[2];
  } else {
    // Landline format: area code + subscriber
    const landlineMatch = withoutTrunk.match(/^([1-9]\d{1,3})(\d{6,8})$/);
    if (!landlineMatch) return false;
    areaCode = landlineMatch[1];
    subscriber = landlineMatch[2];
  }

  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Validate subscriber length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  // Verify leading digit of area code is 1-9
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, strange names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Name regex: allows unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any unicode letter, \p{M} matches marks (accents)
  const nameRegex = /^[\p{L}\p{M}'][\p{L}\p{M}'\s-]*[\p{L}\p{M}']$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Reject names with digits or common symbols (already handled by regex, but double check)
  if (/\d/.test(value)) {
    return false;
  }

  // Reject names with excessive symbols (more than 2 non-letter characters)
  const nonLetterCount = (value.match(/[^\p{L}\p{M}\s]/gu) || []).length;
  if (nonLetterCount > 2) {
    return false;
  }

  // Check for reasonable length (at least 2 chars, max 100)
  if (value.length < 2 || value.length > 100) {
    return false;
  }

  // Reject names that are just spaces, hyphens, or apostrophes
  const trimmed = value.trim();
  if (!/^[\p{L}\p{M}]/u.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa (starts with 4, 13-19 digits), Mastercard (starts with 5 or 2, 16 digits),
 *          AmEx (starts with 34 or 37, 15 digits)
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: starts with 4, length 13-19
  const visaRegex = /^4\d{12,18}$/;
  // Mastercard: starts with 5 or 2, length 16
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7]\d{14})$/;
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidPrefix = visaRegex.test(cleaned) ||
                        mastercardRegex.test(cleaned) ||
                        amexRegex.test(cleaned);

  if (!isValidPrefix) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
