/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create regex pattern to match words starting with prefix
  // \b ensures word boundary
  const pattern = new RegExp(`\\b(${escapedPrefix}[\\w'-]*)`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));

  return matches
    .map(word => word.replace(/['"]/g, ''))
    .filter(word => !exceptionsLower.has(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index);
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use positive lookbehind to ensure token is preceded by a digit
  // The negative lookbehind (?<!^) ensures we're not at the start of string
  const regex = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');

  const matches = text.match(regex) || [];

  return matches;
}

/**
 * Validate passwords according to strong password policy.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, abcabc)
  // This checks for any pattern of 2-4 characters that repeats immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;

  // IPv6 pattern (including shorthand ::)
  // This matches:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8::1
  // - Loopback: ::1
  // - With embedded IPv4: ::ffff:192.0.2.1
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::(?:ffff:)?(?:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/;

  // Check if the value contains IPv6 pattern
  if (!ipv6Pattern.test(value)) {
    return false;
  }

  // Make sure we're not just matching IPv4
  // IPv4 pattern: simple dotted decimal
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

  // If it looks like IPv4 only, return false
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false;
  }

  return true;
}
