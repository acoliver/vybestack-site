import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validateQueryParams(pageParam: string | undefined, limitParam: string | undefined): { page?: number; limit?: number; error?: string } {
  if (pageParam !== undefined) {
    const page = Number(pageParam);
    if (isNaN(page) || !Number.isInteger(page)) {
      return { error: 'page must be a positive integer' };
    }
    if (page === 0) {
      return { error: 'page cannot be zero' };
    }
    if (page < 0) {
      return { error: 'page must be a positive integer' };
    }
    if (page > 1000) {
      return { error: 'page must not exceed 1000' };
    }
  }

  if (limitParam !== undefined) {
    const limit = Number(limitParam);
    if (isNaN(limit) || !Number.isInteger(limit)) {
      return { error: 'limit must be a positive integer' };
    }
    if (limit === 0) {
      return { error: 'limit cannot be zero' };
    }
    if (limit < 0) {
      return { error: 'limit must be a positive integer' };
    }
    if (limit > 100) {
      return { error: 'limit must not exceed 100' };
    }
  }

  const page = pageParam !== undefined ? Number(pageParam) : undefined;
  const limit = limitParam !== undefined ? Number(limitParam) : undefined;
  
  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validateQueryParams(pageParam, limitParam);
    if (validation.error) {
      return res.status(400).json({ error: validation.error });
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
