/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine the equality function
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is : 
    equal === false ? undefined : 
    equal

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observer = activeObserver as Observer<T>
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    // Check if the value actually changed
    if (!subject.equalFn || !subject.equalFn(subject.value, nextValue)) {
      subject.value = nextValue
      if (subject.observer) {
        // Update the observer when input changes
        updateObserver(subject.observer)
      }
    }
    return subject.value
  }

  return [read, write]
}