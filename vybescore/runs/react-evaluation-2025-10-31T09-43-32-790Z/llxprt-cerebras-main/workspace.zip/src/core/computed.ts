/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine the equality function
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is : 
    equal === false ? undefined : 
    equal

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Track what dependencies this computed has
  const dependencies = new Set<Subject<T>>()
  let isFirstRun = true
  
  // Enhanced update function that tracks dependencies
  const enhancedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    if (isFirstRun) {
      // On first run, compute initial value
      observer.value = updateFn(prevValue)
      isFirstRun = false
      return observer.value
    }
    
    // Save current dependencies for potential cleanup
    const oldDependencies = new Set(dependencies)
    dependencies.clear()
    
    // Temporarily replace the update function to track dependencies during computation
    const originalUpdateFn = observer.updateFn
    observer.updateFn = (prevVal?: T) => {
      const active = getActiveObserver()
      if (active && active !== observer) {
        // Add active observer as a dependency
        dependencies.add(active as unknown as Subject<T>)
      }
      return updateFn(prevVal)
    }
    
    try {
      // Execute computation with dependency tracking
      const newValue = originalUpdateFn(prevValue)
      
      // Notify previous dependencies that are no longer used
      oldDependencies.forEach(dep => {
        if (dep.observer === observer && !dependencies.has(dep)) {
          dep.observer = undefined
        }
      })
      
      return newValue
    } finally {
      // Restore original update function
      observer.updateFn = originalUpdateFn
    }
  }

  observer.updateFn = enhancedUpdateFn

  // Initialize computed value
  updateObserver(observer)

  const read: GetterFn<T> = () => {
    // Track dependencies when this computed is read
    const active = getActiveObserver()
    if (active && active !== observer) {
      dependencies.add(active as unknown as Subject<T>)
    }
    
    return observer.value!
  }

  return read
}