import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page = 1; // default
    if (pageParam !== undefined) {
      if (isNaN(Number(pageParam)) || Number(pageParam) <= 0) {
        return res.status(400).json({ error: 'Page must be a positive number' });
      }
      page = Number(pageParam);
    }

    // Validate limit parameter  
    let limit = 5; // default
    if (limitParam !== undefined) {
      if (isNaN(Number(limitParam)) || Number(limitParam) <= 0 || Number(limitParam) > 100) {
        return res.status(400).json({ error: 'Limit must be a positive number (max 100)' });
      }
      limit = Number(limitParam);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
