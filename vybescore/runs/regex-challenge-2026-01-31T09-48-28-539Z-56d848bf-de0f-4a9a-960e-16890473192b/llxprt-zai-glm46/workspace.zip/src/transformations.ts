/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Capitalize first character of text
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }

  // Split by sentence delimiters, but be smart about it
  let result = normalized;

  // Pattern: sentence-ending punctuation followed by space and lowercase letter
  // But not if preceded by common abbreviation
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punctuation, letter) => {
    return `${punctuation} ${letter.toUpperCase()}`;
  });

  return result;
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: protocol://domain[:port][/path][?query][#fragment]
  // Capture the URL but exclude trailing punctuation
  const urlPattern = /(https?:\/\/[^\s<>"()[\]{}|\\^`[\]]+[^\s<>"()[\]{}|\\^`[\].,!?;:])/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing dots, commas, etc.
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Forces all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://... and moves docs paths to docs.example.com.
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for example.com URLs
  const exampleUrlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(exampleUrlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
  // Check if we should skip host rewrite
  // Dynamic hints: cgi-bin, query strings, legacy extensions
  const skipHostRewrite = /\/cgi-bin\/|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py)($|[?/]))/i.test(path);
    
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return `${newProtocol}docs.example.com${path}`;
    } else {
      // Just upgrade the protocol
      return `${newProtocol}${host}${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern: mm/dd/yyyy
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Feb allows 29 for leap years
  const maxDays = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
