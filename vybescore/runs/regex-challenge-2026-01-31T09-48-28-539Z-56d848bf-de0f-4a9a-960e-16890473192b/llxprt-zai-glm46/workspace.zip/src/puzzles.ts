/**
 * Finds words beginning with the specified prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  // Word boundary at start, then prefix, then word characters
  const pattern = new RegExp(`\\b(${prefix}\\w+)`, 'g');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));

  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: digit followed by token, not at start of string
  // Return the digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must have at least one symbol/special character
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, 123123)
  // Pattern: any sequence of 2+ characters that repeats immediately
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - OR with :: shorthand (one or more consecutive zero groups)
  // - Must not match IPv4 addresses

  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Check if it's actually an IPv6 address with embedded IPv4 (e.g., ::ffff:192.168.1.1)
    const ipv6WithEmbeddedIPv4 = /:[a-f0-9]*:.*?(?:\d{1,3}\.){3}\d{1,3}/i;
    if (!ipv6WithEmbeddedIPv4.test(value)) {
      return false;
    }
  }

  // Full IPv6 pattern (8 groups of hex, or with :: shorthand)
  const ipv6Pattern = /(?:^|[\s[\]:])(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}(?:$|[\s[\]:])/i;
  const ipv6WithShorthand = /(?:^|[\s[\]:])[a-f0-9]{0,4}::[a-f0-9]{0,4}(?:$|[\s[\]:])/i;
  const ipv6PartialShorthand = /(?:^|[\s[\]:])(?:[a-f0-9]{1,4}:){1,6}:(?:[a-f0-9]{1,4}:){0,5}[a-f0-9]{0,4}(?:$|[\s[\]:])/i;

  // Match any valid IPv6 pattern
  const isValidIPv6 = ipv6Pattern.test(value) ||
                      ipv6WithShorthand.test(value) ||
                      ipv6PartialShorthand.test(value);

  return isValidIPv6;
}
