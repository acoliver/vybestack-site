declare module 'sql.js' {
  interface SqlJsConfig {
    locateFile?: (file: string) => string;
  }
  
  interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): ArrayBuffer;
    close(): void;
  }
  
  interface Statement {
    run(...params: unknown[]): unknown;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }
  
  function createDatabase(config?: SqlJsConfig): Promise<{ Database: new (data?: ArrayBuffer | null) => Database }>;
  
  export = createDatabase;
}