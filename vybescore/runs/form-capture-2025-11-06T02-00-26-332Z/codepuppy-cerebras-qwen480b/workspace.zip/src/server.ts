import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import { default as createDatabase } from 'sql.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private db: unknown;
  private server: unknown;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      await fs.mkdir(dataDir, { recursive: true });

      // Load sql.js
      const SQL = await createDatabase({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });

      // Try to load existing database or create new one
      let dbBuffer: ArrayBuffer | null = null;
      try {
        const dbData = await fs.readFile(this.dbPath);
        dbBuffer = dbData.buffer.slice(0) as ArrayBuffer;
      } catch (error) {
        // Database doesn't exist, will create new one
      }

      this.db = new SQL.Database(dbBuffer);

      // Initialize schema
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf-8');
      const db = this.db as { run: (sql: string) => void };
      db.run(schema);

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation
    if (data.email && ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation - accept international formats
    if (data.phone && ! /^[+]?[\d\s()\-/]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation - alphanumeric
    if (data.postalCode && ! /^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    return errors;
  }

  private async saveSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const db = this.db as { prepare: (sql: string) => { run: (params: string[]) => void; free: () => void } };
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const db = this.db as { export: () => ArrayBuffer };
    const data = db.export();
    await fs.writeFile(this.dbPath, Buffer.from(data));
  }

  private setupRoutes(): void {
    // GET / - Show form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Process form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const errors = this.validateForm(formData);

        if (errors.length > 0) {
          res.status(400).render('form', {
            errors: errors.map(e => e.message),
            values: formData
          });
          return;
        }

        // Save to database
        await this.saveSubmission(formData);

        // Redirect to thank you page
        res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
      } catch (error) {
        console.error('Error processing submission:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while processing your submission. Please try again.'],
          values: req.body
        });
      }
    });

    // GET /thank-you - Show thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = parseInt(process.env.PORT || '3000', 10);
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => this.gracefulShutdown());
    process.on('SIGINT', () => this.gracefulShutdown());
  }

  private async gracefulShutdown(): Promise<void> {
    console.log('Shutting down gracefully...');
    
    if (this.server) {
      const server = this.server as { close: (callback?: () => void) => void };
      server.close(() => {
        console.log('HTTP server closed');
      });
    }
    
    if (this.db) {
      const db = this.db as { close: () => void };
      db.close();
      console.log('Database connection closed');
    }
    
    process.exit(0);
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});