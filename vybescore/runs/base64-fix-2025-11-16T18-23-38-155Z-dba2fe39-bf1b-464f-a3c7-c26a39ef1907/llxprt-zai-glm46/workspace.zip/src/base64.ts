const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_INPUT_PREFIX = 'Invalid Base64 input:';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws errors for invalid Base64 data.
 */
export function decode(input: string): string {
  // Remove any whitespace from the input
  const cleanedInput = input.trim();
  
  // Validate the Base64 input - must only contain valid Base64 characters
  if (!BASE64_REGEX.test(cleanedInput)) {
    throw new Error(`${INVALID_INPUT_PREFIX} contains invalid characters`);
  }
  
  // Validate padding and length
  validatePaddingAndLength(cleanedInput);
  
  try {
    const result = Buffer.from(cleanedInput, 'base64').toString('utf8');
    // Verify the result by re-encoding and comparing
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Normalize padding for comparison (Buffer.toString doesn't always add padding)
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    const normalizedInput = cleanedInput.replace(/=+$/, '');
    if (normalizedReencoded !== normalizedInput) {
      throw new Error(`${INVALID_INPUT_PREFIX} cannot decode`);
    }
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes(INVALID_INPUT_PREFIX)) {
      throw error;
    }
    throw new Error(`${INVALID_INPUT_PREFIX} cannot decode`);
  }
}

/**
 * Validates Base64 padding and length requirements.
 */
function validatePaddingAndLength(input: string): void {
  // Validate length - Base64 length must be a multiple of 4
  if (input.length % 4 !== 0) {
    throw new Error(`${INVALID_INPUT_PREFIX} incorrect length`);
  }
  
  // Check for invalid padding - padding must be at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.substring(paddingIndex);
    // Padding must be at the end and consist of 1 or 2 '=' characters
    if (paddingPart.length > 2 || !/^=+$/.test(paddingPart)) {
      throw new Error(`${INVALID_INPUT_PREFIX} contains invalid characters`);
    }
    // No non-padding characters allowed after padding starts
    const nonPaddingAfterPadding = input.substring(paddingIndex + 1).replace(/=/g, '');
    if (nonPaddingAfterPadding.length > 0) {
      throw new Error(`${INVALID_INPUT_PREFIX} contains invalid characters`);
    }
  }
}