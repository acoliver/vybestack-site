import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';
import ejs from 'ejs';

const app = express();
const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

let db: Database | null = null;

// Configure EJS view engine immediately
app.engine('ejs', ejs.renderFile);
app.set('view engine', 'ejs');
app.set('views', path.resolve('views'));

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve('public')));

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();

    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
    }

    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validation functions
function isNotEmpty(value: string): boolean {
  return value.trim().length > 0;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateForm(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || !isNotEmpty(data.firstName)) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || !isNotEmpty(data.lastName)) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || !isNotEmpty(data.streetAddress)) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || !isNotEmpty(data.city)) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || !isNotEmpty(data.stateProvince)) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || !isValidPostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal/zip code'
    });
  }

  if (!data.country || !isNotEmpty(data.country)) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || !isValidEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || !isValidPhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number (use + for international format)'
    });
  }

  return errors;
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  const errors: ValidationError[] = [];
  const formData: Partial<FormData> = {};

  res.render('index', { errors, formData });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('index', { errors, formData });
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );

    saveDatabase();
  } catch (error) {
    console.error('Failed to save submission:', error);
    errors.push({ field: 'general', message: 'Failed to save submission. Please try again.' });
    return res.status(500).render('index', { errors, formData });
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware for debugging
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Error:', err);
  res.status(500).send(`Internal Server Error: ${err.message}
${err.stack}`);
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down server...');

  if (db) {
    db.close();
    db = null;
  }

  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();

    const server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });

    // Attach close method for graceful shutdown
    (server as unknown as { closeWithDb: (callback?: () => void) => void }).closeWithDb = (callback?: () => void) => {
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        if (callback) callback();
      });
    };

    // Make server available for testing
    (app as unknown as { server: typeof server }).server = server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

// Export app for testing
export default app;
