/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with prefix (word boundary + prefix + word characters)
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find token that follows a digit and captures the digit too
  // Uses positive lookbehind for digit and negative lookbehind for start of string
  const tokenRegex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Get the position and extract the digit + token
    const startPos = match.index - 1;
    const endPos = match.index + token.length;
    matches.push(text.substring(startPos, endPos));
  }
  
  return matches;
}

/**
 * Validates strong passwords with comprehensive rules.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // No immediate repeated sequences (like "abab", "123123", etc.)
  for (let i = 0; i < value.length - 3; i++) {
    const pattern1 = value.substring(i, i + 2);
    const pattern2 = value.substring(i + 2, i + 4);
    if (pattern1 === pattern2) return false;
  }
  
  // Check for longer repeated sequences
  for (let i = 0; i < value.length - 5; i++) {
    const pattern1 = value.substring(i, i + 3);
    const pattern2 = value.substring(i + 3, i + 6);
    if (pattern1 === pattern2) return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns that exclude IPv4 addresses
  const ipv6Patterns = [
    // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Compressed with :: at start: ::1
    /\b::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/,
    // Compressed with :: at end: 2001:db8::
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/,
    // Compressed with :: in middle: 2001:db8::1
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}\b/,
    // Shorter forms: 2001:db8::8a2e:370:7334
    /\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,6}\b/,
    // IPv6 with embedded IPv4 (should match): ::ffff:192.0.2.128
    /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  // First, explicitly exclude pure IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  const isPureIPv4 = ipv4Pattern.test(value);
  
  // Check if any IPv6 pattern matches
  const hasIPv6 = ipv6Patterns.some(pattern => pattern.test(value));
  
  // Return true only if IPv6 pattern matches and it's not a pure IPv4 address
  return hasIPv6 && !isPureIPv4;
}