/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 * Handles sentence boundaries (.?!) and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, normalize spacing around sentence-ending punctuation
  // This ensures exactly one space after punctuation
  const normalized = text.replace(/([.!?])\s*/g, '$1 ');
  
  // Split into sentences using sentence-ending punctuation followed by a space
  const sentences = normalized.split(/([.!?]\s)/);
  let result = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    // If this is sentence content (not just punctuation/whitespace)
    if (i % 2 === 0) {
      // Trim and capitalize if it contains alphabetic characters
      const trimmed = segment.trim();
      if (trimmed && /[a-zA-Z]/.test(trimmed)) {
        // Capitalize first letter, preserve the rest as-is
        const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        result += capitalized;
      } else {
        // If no alphabetic characters, add the segment as-is (but trimmed)
        result += trimmed;
      }
    } else {
      // This is punctuation + space, preserve it as-is
      result += segment;
    }
  }
  
  // Clean up any extra spaces and trim the result
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex - matches http(s), www, and domain patterns
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation but keep internal punctuation
  return matches.map(url => url.replace(/[.,;:!?)+]+$/g, ''));
}

/**
 * Converts all HTTP URLs to HTTPS in the given text.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrade scheme to HTTPS
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths with CGI, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/(https?:\/\/)([^\/]+)(\/[^\s<>"]*)/g, (match, scheme, host, path) => {
    // Always upgrade to HTTPS
    const newScheme = 'https://';
    
    // Check if we should skip host rewrite
    const skipHostRewrite = /\/(cgi-bin|.*\?.*|.*&.*|.*=.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?.*)?)/i.test(path);
    
    // If path starts with /docs/ and we don't skip the rewrite
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Extract domain from host (remove subdomains if any)
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts.slice(-2).join('.');
        return newScheme + 'docs.' + domain + path;
      }
    }
    
    // Otherwise just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts year from mm/dd/yyyy format.
 * Returns N/A if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  // Additional validation for days per month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year in February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}