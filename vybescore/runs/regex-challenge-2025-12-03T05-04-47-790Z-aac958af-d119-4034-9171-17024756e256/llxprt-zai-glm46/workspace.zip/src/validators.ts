export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject leading or trailing dots in local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Reject domain starting or ending with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 * Accepts formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US numbers, 11 with country code)
  if (digits.length < 10 || digits.length > 11) return false;
  
  // Extract area code (first 3 digits after optional country code)
  const startIndex = digits.length === 11 ? 1 : 0;
  const areaCode = digits.substring(startIndex, startIndex + 3);
  
  // Reject area codes starting with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate country code if present
  if (digits.length === 11 && digits[0] !== '1') return false;
  
  // Optional extensions handling
  if (options?.allowExtensions && /ext\.?\s*\d+$/i.test(value)) {
    return true;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all separators (spaces, hyphens) but keep digits, plus, and leading 0
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Extract country code, mobile indicator, trunk prefix, area code, and subscriber
  const argentinePhoneRegex = /^(?:(\+54))?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) return false;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, areaCodeWithTrunk, subscriberNumber] = match;
  
  // If no country code, must start with trunk prefix 0
  if (!countryCode && !cleanValue.startsWith('0')) return false;
  
  // Area code must be 2-4 digits (leading digit 1-9)
  const areaCode = areaCodeWithTrunk.startsWith('0') ? areaCodeWithTrunk.substring(1) : areaCodeWithTrunk;
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names with only spaces or special characters
  const trimmedValue = value.trim();
  if (!trimmedValue || trimmedValue === '') return false;
  
  // Reject names with consecutive apostrophes or hyphens
  if (trimmedValue.includes("''") || trimmedValue.includes('--')) return false;
  
  // Reject names that are too short or too long
  if (trimmedValue.length < 1 || trimmedValue.length > 100) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using Luhn checksum.
 * Accepts valid prefixes and lengths for major card types.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Check length based on card type
  const length = cleanNumber.length;
  const isValidLength = length === 13 || length === 14 || length === 15 || length === 16 || length === 19;
  if (!isValidLength) return false;
  
  // Check card prefixes
  const prefixes = [
    /^4/, // Visa
    /^5[1-5]/, // Mastercard
    /^2[2-7]/, // Mastercard (new range)
    /^3[47]/, // AmEx
    /^6(?:011|5|22[1-9]|44[0-9])/, // Discover
    /^3(?:0[0-5]|[68])/, // Diners
    /^35/, // JCB
    /^62/ // UnionPay
  ];
  
  const hasValidPrefix = prefixes.some(regex => regex.test(cleanNumber));
  if (!hasValidPrefix) return false;
  
  // Luhn algorithm
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}