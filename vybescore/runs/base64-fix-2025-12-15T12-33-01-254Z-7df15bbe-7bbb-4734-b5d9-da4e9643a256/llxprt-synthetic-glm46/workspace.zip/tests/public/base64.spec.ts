import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('rejects invalid Base64 characters', () => {
    expect(() => decode('invalid!@$')).toThrow('Invalid Base64 input: contains illegal characters');
  });

  it('handles padding edge cases', () => {
    // Single character - requires maximum padding (==)
    expect(encode('a')).toBe('YQ==');
    expect(decode('YQ==')).toBe('a');
    
    // Two characters - requires one padding (=)
    expect(encode('ab')).toBe('YWI=');
    expect(decode('YWI=')).toBe('ab');
    
    // Multiple of 3 bytes - no padding needed
    expect(encode('abc')).toBe('YWJj');
    expect(decode('YWJj')).toBe('abc');
  });

  it('handles Unicode characters correctly', () => {
    const unicodeText = ' emoji test';
    const encoded = encode(unicodeText);
    expect(decode(encoded)).toBe(unicodeText);
  });

  it('rejects incorrectly padded Base64', () => {
    expect(() => decode('YW55IGNhcm5hbCBwbGVhc3VyZA')).toThrow('Invalid Base64 input: incorrect length without padding');
  });
});
