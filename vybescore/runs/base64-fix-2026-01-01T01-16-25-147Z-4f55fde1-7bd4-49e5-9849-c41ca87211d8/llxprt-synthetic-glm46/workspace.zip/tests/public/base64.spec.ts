import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('encodes and decodes without padding', () => {
    const encoded = encode('test');
    const decoded = decode(encoded);
    expect(decoded).toBe('test');
  });

  it('decodes Base64 without padding', () => {
    const result = decode('aGVsbG8');
    expect(result).toBe('hello');
  });

  it('rejects invalid characters', () => {
    expect(() => decode('invalid!base64')).toThrow('Invalid Base64 input');
  });

  it('handles Unicode characters', () => {
    const text = 'こんにちは';
    const encoded = encode(text);
    const decoded = decode(encoded);
    expect(decoded).toBe(text);
  });

  it('handles Base64 with spaces', () => {
    const result = decode('aGVs bG8=');
    expect(result).toBe('hello');
  });

  it('returns error for inputs with non-whitespace invalid characters', () => {
    expect(() => decode('aGVsbG8!')).toThrow('Invalid Base64 input');
  });
});
