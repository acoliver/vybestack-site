const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that input contains only valid Base64 characters before decoding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Remove whitespace characters that might be present in the input
  const cleaned = input.replace(/\s/g, '');
  
  // Check if the input contains only valid Base64 characters
  if (!BASE64_REGEX.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Additional validation: check if length can be padded to multiple of 4
  const paddedLength = cleaned.includes('=') 
    ? cleaned.length 
    : cleaned.length + (4 - (cleaned.length % 4)) % 4;
  
  // If padded length isn't a multiple of 4, it's invalid base64
  // The only exception is when the string is empty
  if (cleaned && paddedLength % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    const result = Buffer.from(cleaned, 'base64').toString('utf8');
    
    // Additional verification: check for decoding anomalies
    // Node's Buffer implementation can decode some technically invalid inputs
    // We want to reject clearly invalid patterns
    if (cleaned && cleaned.length < 4 && (!result || result.length === 0)) {
      // Very short strings without explicit padding are suspect
      // Only valid if they decode to meaningful UTF-8
      throw new Error('Invalid Base64 input: cannot decode');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
