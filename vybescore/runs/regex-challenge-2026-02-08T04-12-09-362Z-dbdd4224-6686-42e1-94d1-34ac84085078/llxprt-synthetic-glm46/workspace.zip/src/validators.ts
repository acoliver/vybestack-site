export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC rules.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Basic structure: local@domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) return false;
  
  // No double dots
  if (value.includes('..')) return false;
  
  // No domain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  // No leading or trailing dots
  const [localPart, domainPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 */
export function isValidUSPhone(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Strip all non-digit characters except + for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  const withOptionalCountry = digitsOnly.startsWith('1') ? digitsOnly.slice(1) : digitsOnly;
  
  // Must be exactly 10 digits after removing country code
  if (withOptionalCountry.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  if (withOptionalCountry[0] === '0' || withOptionalCountry[0] === '1') return false;
  
  // Validate format with allowed separators - more flexible pattern
  const phoneRegex = /^(\+?1\s*)?(\(\d{3}\)\s*|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering landlines and mobiles.
 * Allows optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code must be 2-4 digits with leading digit 1-9.
 * Subscriber number must be 6-8 digits after area code.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Remove all separators (spaces, hyphens) for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // Optional country code: +54
  // Optional trunk prefix: 0
  // Optional mobile indicator: 9
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  
  // Try pattern with country code: +54[9]?<area><subscriber>
  // Example: +5491112345678, +543411234567
  const withCountryCode = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Try pattern without country code: 0<area><subscriber>
  // Example: 01112345678, 03414234567
  const withoutCountryCode = /^(0[1-9]\d{1,3})(\d{6,8})$/;
  
  let match = cleanValue.match(withCountryCode);
  if (match) {
    // const mobileIndicator = match[1]; // optional '9' - we don't need to use this
    const areaCode = match[2];
    const subscriberNumber = match[3];
    
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  }
  
  match = cleanValue.match(withoutCountryCode);
  if (match) {
    const areaCodeWithPrefix = match[1]; // includes the leading '0'
    const subscriberNumber = match[2];
    
    // Remove trunk prefix '0' to get actual area code
    const areaCode = areaCodeWithPrefix.slice(1);
    
    // Area code must be 2-4 digits (excluding the trunk prefix)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid formats like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Allow Unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(value.trim());
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(digitsOnly)) return false;
  
  // Visa: 13 or 16 digits starting with 4
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  // AmEx: 15 digits starting with 34 or 37
  const visaRegex = /^4(?:\d{12}|\d{15})$/;
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidPrefix = visaRegex.test(digitsOnly) || 
                       mastercardRegex.test(digitsOnly) || 
                       amexRegex.test(digitsOnly);
  
  if (!isValidPrefix) return false;
  
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit and work left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value[i], 10);
    
    if (shouldDouble) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
