/**
 * Finds words beginning with the specified prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }
  
  // Create a regex pattern for words with the given prefix (word boundaries)
  const prefixPattern = new RegExp(`\\b${escapeRegExp(prefix)}[a-zA-Z]*\\b`, 'g');
  
  // Find all words with the prefix
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
}

/**
 * Helper function to escape special regex characters in a string.
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string' || text.length === 0) {
    return [];
  }
  
  // Manual scan to find token after digit, not at start
  const result: string[] = [];
  
  for (let i = 1; i < text.length; i++) {
    // Check if we have a digit followed by the token
    if (/\d/.test(text[i-1]) && text.startsWith(token, i)) {
      result.push(text[i-1] + token);
      i += token.length - 1; // Skip ahead past the token
    }
  }
  
  return result;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab")
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string' || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like "abab", "123123", "testtest")
  // Pattern: any sequence of 2-4 characters immediately repeated
  if (/(.{2,4})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) while ensuring IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) return false;
  
  // IPv6 regex patterns (various formats)
  const ipv6Patterns = [
    // Full notation (8 groups of 1-4 hex digits)
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // Shorthand with :: (can replace 1 or more groups)
    /\b(?:[0-9a-fA-F]{1,4}:)*::[0-9a-fA-F]*\b/,
    /\b::[0-9a-fA-F]{1,4}\b/,
    /\b::\b/,
    
    // Mixed with IPv4 embedded (like ::ffff:192.168.0.1)
    /\b::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/
  ];
  
  // IPv4 regex pattern (to exclude these cases)
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  
  // First check if the entire value is an IPv4 address
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // Check for IPv6 patterns
  if (ipv6Patterns.some(pattern => pattern.test(value))) {
    // Make sure we're not just matching IPv4 addresses
    const ipv4Matches = value.match(ipv4Regex) || [];
    
    if (ipv4Matches.length === 0) {
      return true;
    }
    
    // Check if there's also an IPv6 address that's not an IPv4 address
    for (const pattern of ipv6Patterns) {
      const matches = value.match(pattern) || [];
      
      for (const match of matches) {
        if (!ipv4Regex.test(match.trim())) {
          return true;
        }
      }
    }
  }
  
  return false;
}
