/**
 * Capitalizes the first character of each sentence, inserts exactly one space between sentences,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string' || text.length === 0) return text;
  
  // First, normalize spacing: remove extra spaces and ensure proper spacing after punctuation
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure there's a space after sentence-ending punctuation if followed by a letter
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Process the text character by character to capitalize after sentence endings
  let result = '';
  let capitalizeNext = true; // Start by capitalizing first character
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    
    if (capitalizeNext && /[a-zA-Z]/.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      result += char;
    }
    
    // Reset capitalize flag after sentence-ending punctuation
    if (/[.!?]/.test(char)) {
      capitalizeNext = true;
    }
  }
  
  // Clean up any remaining spacing issues
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extracts all URLs from the given text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string' || text.length === 0) return [];
  
  // URL regex pattern - captures http/https, www, and domain patterns
  const urlRegex = /(https?:\/\/(www\.)?|www\.)[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]}]+$/g, ''));
}

/**
 * Replaces all http:// URLs with https:// while leaving existing https:// URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string' || text.length === 0) return text;
  
  // Pattern to match http:// URLs (but not https://)
  const httpUrlRegex = /http:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  return text.replace(httpUrlRegex, (match) => match.replace('http://', 'https://'));
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string' || text.length === 0) return text;
  
  // Pattern for http://example.com URLs with optional path
  const exampleUrlRegex = /http:\/\/example\.com(\/[^\s]*)?/g;
  
  return text.replace(exampleUrlRegex, (match) => {
    const path = match.replace('http://example.com', '');
    
    // Always upgrade scheme to https://
    let result = match.replace('http://', 'https://');
    
    // Extract the path for further processing
    if (path) {
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints that should prevent host rewrite
        const dynamicHints = /(cgi-bin|[?&=]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/;
        
        // Only rewrite host if no dynamic hints are present
        if (!dynamicHints.test(path)) {
          // Rewrite host to docs.example.com but keep the path
          result = 'https://docs.example.com' + path;
        }
      }
    }
    
    return result;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string' || value.length === 0) return 'N/A';
  
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month (including leap year for February)
  const maxDays = {
    1: 31, 2: isLeapYear(parseInt(year, 10)) ? 29 : 28, 3: 31, 4: 30,
    5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > maxDays[month as keyof typeof maxDays]) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to check if a year is a leap year.
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}
