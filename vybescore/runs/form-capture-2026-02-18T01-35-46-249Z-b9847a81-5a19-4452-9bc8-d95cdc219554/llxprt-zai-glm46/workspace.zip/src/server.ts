import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
// When running from dist/, templates are in src/templates
app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading @
  const phoneRegex = /^@?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces (e.g., "SW1A 1AA", "C1000", "B1675", "12345")
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateFormData(data: FormData): string[] {
  const errors: string[] = [];

  if (!validateRequired(data.firstName)) {
    errors.push('First name is required');
  }
  if (!validateRequired(data.lastName)) {
    errors.push('Last name is required');
  }
  if (!validateRequired(data.streetAddress)) {
    errors.push('Street address is required');
  }
  if (!validateRequired(data.city)) {
    errors.push('City is required');
  }
  if (!validateRequired(data.stateProvince)) {
    errors.push('State / Province / Region is required');
  }
  if (!validateRequired(data.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and dashes');
  }
  if (!validateRequired(data.country)) {
    errors.push('Country is required');
  }
  if (!validateRequired(data.email)) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Email must be a valid email address');
  }
  if (!validateRequired(data.phone)) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and may start with @');
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  // Create table from schema
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', { errors, values: formData });
    return;
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    stmt.free();

    // Save database after insert
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission for personalization
  let firstName = 'Friend';
  if (db) {
    const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  }
  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized');

    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server instance for graceful shutdown
    const serverWithClose = server as unknown as { gracefulClose: () => Promise<void> };
    serverWithClose.gracefulClose = () => {
      return new Promise<void>((resolve) => {
        server.close(() => {
          if (db) {
            db.close();
            db = null;
          }
          resolve();
        });
      });
    };

    process.on('SIGTERM', async () => {
      console.log('SIGTERM received, shutting down gracefully...');
      await serverWithClose.gracefulClose();
      process.exit(0);
    });

    process.on('SIGINT', async () => {
      console.log('SIGINT received, shutting down gracefully...');
      await serverWithClose.gracefulClose();
      process.exit(0);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, initializeDatabase, shutdown };

// Auto-start if not imported
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
