/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Signal<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer>
}

export type Observer = {
  name?: string
  value?: unknown
  updateFn: UpdateFn<unknown>
  disposed?: boolean
  observers?: Set<Observer>
  isCallback?: boolean
}

export type Computed<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  observers: Set<Observer>
  disposed?: boolean
  isCallback?: boolean
}

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}

export function evaluateComputed<T>(computed: Observer): T {
  const previous = activeObserver
  activeObserver = computed
  try {
    computed.value = computed.updateFn(computed.value as T)
    return computed.value as T
  } finally {
    activeObserver = previous
  }
}

export function subscribeSignal<T>(signal: Signal<T>, computed: any): void {
  if (!signal.observers.has(computed)) {
    signal.observers.add(computed)
  }
}

export function notifyObservers<T>(signal: Signal<T>): void {
  const snapshot = Array.from(signal.observers)
  snapshot.forEach((observer: Observer) => {
    if (observer && !observer.disposed && 'updateFn' in observer) {
      // Always re-evaluate to trigger side effects
      evaluateComputed(observer)
      // If this observer is a computed value, notify its observers too
      if (observer.observers && observer.observers.size > 0) {
        const dependentsSnapshot = Array.from(observer.observers)
        dependentsSnapshot.forEach((dependent: Observer) => {
          if (dependent && !dependent.disposed && 'updateFn' in dependent) {
            evaluateComputed(dependent)
          }
        })
      }
    }
  })
}

let activeObserver: Observer | undefined = undefined
