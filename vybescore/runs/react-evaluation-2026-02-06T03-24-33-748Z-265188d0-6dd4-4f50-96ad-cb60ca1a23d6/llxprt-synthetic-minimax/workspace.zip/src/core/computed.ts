/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Computed, 
  EqualFn,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Computed<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
    disposed: false
  }
  
  const getter = (): T => {
    // Always re-evaluate to get the latest value with proper dependency tracking
    const previous = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      observer.value = observer.updateFn(observer.value)
      return observer.value as T
    } finally {
      setActiveObserver(previous)
    }
  }
  
  return getter
}
