/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  evaluateComputed
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer = {
    name: undefined,
    value,
    updateFn,
    observers: new Set(),
    disposed: false,
    isCallback: true
  }
  
  // Execute immediately to establish dependencies
  evaluateComputed(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
  }
}
