/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Signal,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  subscribeSignal,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const signal: Signal<T> = {
    name: options?.name,
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver && 'observers' in currentObserver) {
      // Register this signal as being observed by the current observer
      subscribeSignal(signal, currentObserver)
    }
    return signal.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = signal.equalFn || ((a: T, b: T) => a === b)
    
    // Only notify observers if the value actually changed
    if (!equalFn(signal.value, nextValue)) {
      signal.value = nextValue
      // Notify all observers (computed values, callbacks, etc.)
      notifyObservers(signal)
    }
    
    return signal.value
  }

  return [read, write]
}
