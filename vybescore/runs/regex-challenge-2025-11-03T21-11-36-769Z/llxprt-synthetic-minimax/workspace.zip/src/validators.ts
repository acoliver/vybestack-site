export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that accepts typical formats including + tags
  // Rejects: double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional check for double dots and trailing dots
  if (value.includes('..') || value.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  const startsWithPlus1 = cleaned.startsWith('+1');
  const digits = startsWithPlus1 ? cleaned.slice(2) : cleaned;
  
  // Must have exactly 10 digits if no +1, or 10 digits after +1
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) doesn't start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check the original format is valid
  // Allow: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890, +12125557890
  const phoneRegex = /^(\+1[\s-]?)?(\([0-9]{3}\)|[0-9]{3})[\s-]?[0-9]{3}[\s-]?[0-9]{4}$/;
  if (!phoneRegex.test(value.trim())) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for country code +54
  const hasCountryCode = cleaned.startsWith('+54');
  const rest = hasCountryCode ? cleaned.slice(3) : cleaned;
  
  // Check for mobile indicator 9
  const hasMobileIndicator = rest.startsWith('9');
  const afterIndicator = hasMobileIndicator ? rest.slice(1) : rest;
  
  // Must start with trunk prefix 0
  if (!afterIndicator.startsWith('0')) {
    return false;
  }
  
  const afterTrunk = afterIndicator.slice(1);
  
  // Area code: 2-4 digits, first digit 1-9
  if (afterTrunk.length < 6) {
    return false;
  }
  
  // Extract area code (2-4 digits)
  let areaCodeLength = 0;
  if (afterTrunk.length >= 8) {
    // 4-digit area code
    areaCodeLength = 4;
  } else if (afterTrunk.length >= 7) {
    // 3-digit area code
    areaCodeLength = 3;
  } else {
    // 2-digit area code
    areaCodeLength = 2;
  }
  
  const areaCode = afterTrunk.substring(0, areaCodeLength);
  
  // First digit of area code must be 1-9
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  const subscriberNumber = afterTrunk.substring(areaCodeLength);
  
  // Subscriber number must be 6-8 digits total (after area code)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Verify the format matches one of the expected patterns
  const validFormats = [
    /^\+54\s9\s\d{2,4}\s\d{6,8}$/,  // +54 9 11 1234 5678
    /^\+54\s9\s\d{2,4}\d{6,8}$/,    // +54 9 1112345678
    /^\+54\s\d{2,4}\s\d{6,8}$/,     // +54 341 123 4567
    /^\+54\s\d{2,4}\d{6,8}$/,       // +54 3411234567
    /^0\s?\d{2,4}\s?\d{6,8}$/,      // 011 1234 5678
    /^0\d{2,4}\d{6,8}$/             // 01112345678
  ];
  
  return validFormats.some(regex => regex.test(value));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Reject if contains digits or symbols except apostrophes, hyphens, and spaces
  const invalidPattern = /[0-9]/;
  const symbolPattern = /[!@#$%^&*()_+=[\]{};':"\\|,.<>/?`~]/;
  
  if (invalidPattern.test(value) || symbolPattern.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (including unicode)
  const hasLetter = /\p{L}/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject the X Æ A-12 style names
  if (value.includes('Æ') || value.includes('æ')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type and length
  let isValidType = false;
  
  // Visa: starts with 4, 13, 16, or 19 digits
  if (cleaned.startsWith('4')) {
    if (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19) {
      isValidType = true;
    }
  }
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  else if ((cleaned.startsWith('5') && cleaned.length === 16) ||
           (cleaned.startsWith('222') && cleaned.length === 16)) {
    const firstTwo = parseInt(cleaned.substring(0, 2));
    const firstFour = parseInt(cleaned.substring(0, 4));
    if ((firstTwo >= 51 && firstTwo <= 55) || 
        (firstFour >= 2221 && firstFour <= 2720)) {
      isValidType = true;
    }
  }
  // AmEx: starts with 34 or 37, 15 digits
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}