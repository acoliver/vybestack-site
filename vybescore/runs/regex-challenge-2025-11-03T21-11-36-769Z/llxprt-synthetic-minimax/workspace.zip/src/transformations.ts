/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first letter of the text
  let result = text.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Find sentences ending with .?! and capitalize next letter
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Normalize spaces - replace multiple spaces with single space
  result = result.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence endings
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs including http://, https://, and www.
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,;:!?]+$/, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http:// URLs
  const httpRegex = /http:\/\/([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpRegex, (match, host, path) => {
    let newPath = path || '/';
    
    // Check if path contains dynamic hints that should skip host rewrite
    const hasDynamicHints = /(\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|cgi-bin)/i.test(newPath);
    
    // If path begins with /docs/ and no dynamic hints, rewrite host
    if (newPath.startsWith('/docs/') && !hasDynamicHints) {
      const newHost = `docs.${host}`;
      return `https://${newHost}${newPath}`;
    }
    
    // Otherwise, just upgrade to https
    return `https://${host}${newPath}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (reasonable range)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) {
    return 'N/A';
  }
  
  return year;
}