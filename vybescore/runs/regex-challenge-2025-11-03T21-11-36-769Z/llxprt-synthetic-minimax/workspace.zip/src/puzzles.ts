/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words that start with the prefix
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use negative lookbehind to ensure not at start
  // Use positive lookbehind to ensure preceded by a digit
  const regex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212, abcabc)
  // This pattern looks for any sequence of 2+ characters that repeats immediately
  const repeatedSequencePattern = /(\w{2,})\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern including shorthand :: notation
  // IPv6 addresses have 8 groups of 4 hexadecimal digits separated by colons
  // Shorthand :: can replace one or more consecutive groups of zeros
  const ipv6Regex = /(^|[\s:])(([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}|(::)([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4}|[0-9A-Fa-f]{1,4}::(([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:)|:(:[0-9A-Fa-f]{1,4}){1,7})($|[\s:.,])/;
  
  // IPv4 regex pattern to exclude (we want to make sure these don't trigger IPv6 detection)
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // First check if there's an IPv4 address - if so, return false
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Check for IPv6 address
  return ipv6Regex.test(value);
}