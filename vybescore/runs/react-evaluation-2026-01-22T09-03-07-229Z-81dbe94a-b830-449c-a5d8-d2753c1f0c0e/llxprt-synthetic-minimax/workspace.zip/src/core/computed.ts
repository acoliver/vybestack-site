/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addSubscriber,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set()
  }
  
  const getter: GetterFn<T> = (): T => {
    // Register as subscriber when being accessed during evaluation
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o) {
      addSubscriber(o, currentObserver)
    }
    
    return o.value!
  }
  
  // Initial computation to set up dependencies
  updateObserver(o)
  
  return getter
}
