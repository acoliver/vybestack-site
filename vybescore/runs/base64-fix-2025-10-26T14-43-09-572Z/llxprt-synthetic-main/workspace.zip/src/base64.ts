/**
 * Validates if a string is valid Base64 according to RFC 4648.
 * Valid Base64 contains only A-Z, a-z, 0-9, +, /, and optionally padding = at the end.
 */
function isValidBase64(input: string): boolean {
  // Check for valid Base64 characters and proper padding placement
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check that padding only appears at the end
  const padIndex = input.indexOf('=');
  if (padIndex !== -1) {
    // Once padding starts, it must continue to the end
    const paddingSection = input.substring(padIndex);
    if (!paddingSection.match(/^=+$/)) {
      return false;
    }
    
    // Calculate expected padding length based on string length
    const lengthWithoutPadding = input.length - paddingSection.length;
    const expectedPadding = lengthWithoutPadding % 4;
    if (expectedPadding === 0 && paddingSection.length > 0) {
      // No padding should be present if length is divisible by 4
      return false;
    }
    if (expectedPadding !== 0 && paddingSection.length !== (4 - expectedPadding)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Includes proper padding with '=' characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the RFC 4648 standard alphabet.
 * Accepts valid Base64 with or without padding.
 */
export function decode(input: string): string {
  // Validate input format
  if (!input || !isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
