export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: 1+ alphanumeric chars + allowed special chars, no consecutive dots, no leading/trailing dots
  // Domain: no underscores, proper TLD format
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check basic format first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject leading dots in local part
  if (value.startsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  let phoneNumber = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must have exactly 10 digits for standard US number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  const areaCode = phoneNumber.substring(0, 3);
  const lineNumber = phoneNumber.substring(3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1 (for valid US numbers)
  const exchangeCode = lineNumber.substring(0, 3);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  // Check if the original format matches one of the accepted patterns
  const usPhoneRegex = /^(\+?1[-.\s]?)?(\()?([2-9]\d{2})(\)?[-.\s]?)([2-9]\d{2})[-.\s]?(\d{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Argentine phone number pattern explanation:
  // Examples:
  // +54 9 11 1234 5678 -> country code + mobile indicator + area code + subscriber
  // 011 1234 5678 -> trunk prefix + area code + subscriber
  // +54 341 123 4567 -> country code + area code + subscriber
  // 0341 4234567 -> trunk prefix + area code + subscriber
  
  // Try different patterns based on format
  const phoneRegexWithCountry = /^\+54([1-9]\d{2})(\d{7})$/;
  const phoneRegexWithTrunk = /^0([1-9]\d{1,3})(\d{6,8})$/;
  const phoneRegexLocal = /^([1-9]\d{1,3})(\d{6,8})$/;
  
  let areaCode: string;
  
  if (phoneRegexWithCountry.test(cleaned)) {
    const match = cleaned.match(phoneRegexWithCountry)!;
    areaCode = match[1];
  } else if (phoneRegexWithTrunk.test(cleaned)) {
    const match = cleaned.match(phoneRegexWithTrunk)!;
    areaCode = match[1];
  } else if (phoneRegexLocal.test(cleaned)) {
    const match = cleaned.match(phoneRegexLocal)!;
    areaCode = match[1];
  } else {
    return false;
  }
  
  // Validate area code length (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || !areaCode.match(/^[1-9]/)) {
    return false;
  }
  
  return true;
}

/**
 * Validate names (first, last, full names).
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Basic name validation with unicode support
  // Allow letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with numbers mixed with symbols (like X Æ A-12)
  if (/[\p{L}]\s*[Ææ]\s*[\p{L}]\s*-\s*\d/u.test(value)) {
    return false;
  }
  
  // Name must have reasonable length (not empty or just spaces)
  if (value.trim().length < 1) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm implementation for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let currentDigit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      currentDigit *= 2;
      if (currentDigit > 9) {
        currentDigit -= 9;
      }
    }
    
    sum += currentDigit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if digits only
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{14}|2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12})$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card number matches any accepted format
  const isValidFormat = visaRegex.test(digits) || 
                       mastercardRegex.test(digits) || 
                       amexRegex.test(digits);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}