/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with prefix
  // \b ensures word boundary, \w+ matches the rest of the word
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Convert to lowercase for case-insensitive comparison with exceptions
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions
  const filteredMatches = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !lowerExceptions.includes(lowerWord);
  });
  
  // Return unique matches (case-sensitive original casing)
  return [...new Set(filteredMatches)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to find the token in the right context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Return the digit + token combination (as the test expects)
  const results: string[] = [];
  text.replace(new RegExp(`(\\d)${escapedToken}`, 'g'), (match) => {
    results.push(match);
    return match;
  });
  
  return results;
}

/**
 * Validate passwords according to security policy.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Minimum length requirement
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This regex finds any sequence of 2-4 characters that is immediately repeated
  const repeatedSequenceRegex = /(.{2,4})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv6 address patterns (various forms)
  const ipv6Patterns = [
    // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Compressed :: (can appear at start, middle, or end)
    /(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?/,
    // IPv6 with IPv4 embedded: ::ffff:192.0.2.128
    /::ffff:(\d{1,3}\.){3}\d{1,3}/,
    // Simple shorthand: ::1, ::ffff
    /::[0-9a-fA-F]*/,
    // IPv6 with port: [2001:db8::1]:8080
    /\[([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\](:\d+)?/
  ];
  
  // First, check if it's an IPv4 address to exclude those
  const ipv4Pattern = /(\d{1,3}\.){3}\d{1,3}/;
  
  // Check for IPv4 first and exclude
  if (ipv4Pattern.test(value)) {
    // Make sure it's not actually IPv6 with embedded IPv4
    const ipv6WithIPv4Pattern = /::ffff:(\d{1,3}\.){3}\d{1,3}/;
    return ipv6WithIPv4Pattern.test(value);
  }
  
  // Check if it matches any IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // Additional check for IPv6-like patterns with mixed formats
  // This catches more complex IPv6 representations
  const mixedPattern = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  if (mixedPattern.test(value) && value.includes(':')) {
    // Make sure it has enough colons to be IPv6
    const colonCount = (value.match(/:/g) || []).length;
    if (colonCount >= 2) {
      return true;
    }
  }
  
  return false;
}