/**
 * Capitalize the first character of each sentence.
 * After .!? punctuation, capitalize first character and insert exactly one space.
 * Collapse extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty string
  if (!text || text.trim() === '') {
    return text;
  }
  
  // First, normalize spacing around sentence endings
  // Add space after sentence endings if missing (but not for common abbreviations)
  
  // Common abbreviations that shouldn't end sentences (currently unused but kept for reference)
  // const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e'];
  
  // Split text into potential sentences and process
  // This regex finds sentence boundaries (., ?, !) that aren't part of abbreviations
  const sentenceSplitRegex = /([.!?])(?=(?:[^"']*"[^"']*")*[^"']*$)(?!(?:'?[A-Za-z]))/g;
  
  // Split into segments and process each
  const segments = text.split(sentenceSplitRegex);
  
  let result = '';
  let capitalizeNext = true; // Start with capitalization
  
  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i];
    
    if (segment === '' || segment === undefined) continue;
    
    // Check if this is a sentence-ending punctuation
    if (segment.match(/^[.!?]$/)) {
      result += segment;
      capitalizeNext = true;
      continue;
    }
    
    // Process the segment
    let processedSegment = segment;
    
    // Capitalize first letter if needed
    if (capitalizeNext && processedSegment.length > 0) {
      // Find first letter character and capitalize it
      const firstLetterMatch = processedSegment.match(/[a-zA-Z\u00C0-\uFFFF]/);
      if (firstLetterMatch) {
        const firstLetterIndex = firstLetterMatch.index!;
        const firstLetter = processedSegment[firstLetterIndex];
        const capitalLetter = firstLetter.toUpperCase();
        
        processedSegment = processedSegment.substring(0, firstLetterIndex) + 
                          capitalLetter + 
                          processedSegment.substring(firstLetterIndex + 1);
      }
      capitalizeNext = false;
    }
    
    // Normalize spaces within the segment
    // Collapse multiple spaces to single space, but preserve at least one space
    processedSegment = processedSegment.replace(/\s+/g, ' ');
    
    // Trim leading spaces except when it's part of sentence structure
    if (processedSegment !== '' && !processedSegment.match(/^\s/)) {
      // Ensure single space between segments if needed
      if (result.length > 0 && !result.match(/[.!?]\s*$/)) {
        result += ' ';
      }
    }
    
    result += processedSegment;
  }
  
  // Final cleanup: ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(?=[^\s])/g, '$1 ');
  
  // Remove any double spaces that might have been created
  result = result.replace(/\s{2,}/g, ' ');
  
  // Trim final result
  result = result.trim();
  
  return result;
}

/**
 * Extract URLs from text.
 * Returns all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || text.trim() === '') {
    return [];
  }
  
  // URL extraction regex
  // Matches:
  // - http:// or https:// protocols
  // - www. (without protocol)
  // - Domain names with various TLDs
  // - IP addresses
  // - Ports, paths, query strings, fragments
  
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|https?:\/\/[^\s<>"']+|www\.[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches - remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?)\]]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https://, but only when it's at the start of a URL
  // Use negative lookbehind to ensure we're not already in an https URL
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/....
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://.
 * - Preserve nested paths (e.g., /docs/api/v1).
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // Pattern to match HTTP URLs from example.com
  // This is a complex regex that captures the different parts of the URL
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https
    const upgradedProtocol = 'https://';
    
    // Check if we should rewrite the host to docs.example.com
    const shouldRewriteHost = shouldRewriteToDocs(path);
    
    if (shouldRewriteHost) {
      return upgradedProtocol + 'docs.example.com' + path;
    } else {
      return upgradedProtocol + domain + path;
    }
  });
}

/**
 * Helper function to determine if a path should be rewritten to docs.example.com.
 */
function shouldRewriteToDocs(path: string): boolean {
  // Normalize path to start with /
  const normalizedPath = path.startsWith('/') ? path : '/' + path;
  
  // Check if path starts with /docs/
  if (!normalizedPath.startsWith('/docs/')) {
    return false;
  }
  
  // Check for dynamic hints that should prevent host rewrite
  const excludePatterns = [
    /\/cgi-bin\//i,
    /\?/,           // query string
    /[?&=]/,        // query parameters
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i  // legacy extensions
  ];
  
  return !excludePatterns.some(pattern => pattern.test(normalizedPath));
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string | 'N/A' {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    29, // February (leap year handled below)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  // Check if day is valid for the month
  if (day < 1 || day > daysInMonth[month - 1]) {
    // Special handling for February in non-leap years
    if (month === 2 && day === 29) {
      const yearNum = parseInt(year, 10);
      const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
      if (!isLeapYear) {
        return 'N/A';
      }
    } else {
      return 'N/A';
    }
  }
  
  return year;
}
