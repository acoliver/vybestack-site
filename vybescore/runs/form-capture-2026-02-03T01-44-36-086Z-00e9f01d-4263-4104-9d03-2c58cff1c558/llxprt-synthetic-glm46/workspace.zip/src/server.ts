import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import { Database } from 'sql.js';

// Define __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define form data type
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define validation errors type
interface ValidationError {
  [key: string]: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database variables
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Try to load existing database or create a new one
    let dbBuffer: Uint8Array;
    if (fs.existsSync(dbPath)) {
      const dbFile = readFileSync(dbPath);
      dbBuffer = new Uint8Array(dbFile);
    } else {
      dbBuffer = new Uint8Array(0);
    }
    
    // Create database instance
    db = new SQL.Database(dbBuffer);
    
    // Create table if it doesn't exist
    const schema = readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes
  return /^[A-Za-z0-9\s]+$/.test(postalCode) && postalCode.length > 0;
}

function validateForm(formData: FormData): ValidationError {
  const errors: ValidationError = {};
  
  // Required fields validation
  if (!formData.firstName.trim()) errors.firstName = 'First name is required';
  if (!formData.lastName.trim()) errors.lastName = 'Last name is required';
  if (!formData.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!formData.city.trim()) errors.city = 'City is required';
  if (!formData.stateProvince.trim()) errors.stateProvince = 'State/Province/Region is required';
  if (!formData.postalCode.trim()) errors.postalCode = 'Postal/Zip code is required';
  if (!formData.country.trim()) errors.country = 'Country is required';
  if (!formData.email.trim()) errors.email = 'Email is required';
  if (!formData.phone.trim()) errors.phone = 'Phone number is required';
  
  // Email format validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone format validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.phone = 'Phone number can contain digits, spaces, parentheses, dashes, and a leading +';
  }
  
  // Postal code validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Postal code can contain letters and numbers';
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: { 
      firstName: '', 
      lastName: '', 
      streetAddress: '', 
      city: '', 
      stateProvince: '', 
      postalCode: '', 
      country: '', 
      email: '', 
      phone: '' 
    } 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    // Validation failed, re-render form with errors
    return res.status(400).render('form', { errors, formData });
  }
  
  // Validation passed, insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    db.run(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    const serverError: ValidationError = { server: 'Failed to save your submission. Please try again.' };
    res.status(500).render('form', { errors: serverError, formData });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err);
  res.status(500).render('form', { 
    errors: { server: 'Something went wrong. Please try again later.' }, 
    formData: { 
      firstName: '', 
      lastName: '', 
      streetAddress: '', 
      city: '', 
      stateProvince: '', 
      postalCode: '', 
      country: '', 
      email: '', 
      phone: '' 
    } 
  });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    try {
      db.close();
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle SIGTERM for graceful shutdown
    process.on('SIGTERM', () => {
      console.log('Received SIGTERM');
      server.close(() => {
        shutdown();
      });
    });
    
    process.on('SIGINT', () => {
      console.log('Received SIGINT');
      server.close(() => {
        shutdown();
      });
    });
    
    return new Promise((resolve) => {
      server.on('listening', resolve);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch((error) => {
  console.error('Server startup failed:', error);
  process.exit(1);
});
