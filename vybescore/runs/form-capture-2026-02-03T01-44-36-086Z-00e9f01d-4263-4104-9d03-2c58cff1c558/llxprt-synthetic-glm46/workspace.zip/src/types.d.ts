export interface Database {
  run(sql: string, ...params: unknown[]): void;
  export(): Uint8Array;
  close(): void;
}

declare module 'sql.js' {
  export default initSqlJs;
  export interface SqlJsStatic {
    Database: new(data?: Uint8Array) => Database;
  }
  
  function initSqlJs(): Promise<SqlJsStatic>;
}