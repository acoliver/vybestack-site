/**
 * Capitalizes the first character of each sentence and ensures proper spacing
 * Preserves abbreviations when possible, collapses extra spaces
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize first letter of the text
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Find sentence endings (.!?) followed by space and lowercase letter
  // and capitalize that letter
  result = result.replace(/([.!?])\s+([a-z])/g, (match, p1, p2) => `${p1} ${p2.toUpperCase()}`);
  
  // Ensure exactly one space after sentence endings when missing
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  return result.trim();
}

/**
 * Extracts URLs from text, excluding trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // This regex matches URLs starting with http:// or https://
  // It includes domain names, paths, query parameters, and fragments
  // It excludes trailing punctuation marks like .,!?;:
  const urlRegex = /https?:\/\/[^\s.,!?;:()[\]{}<>"']+/g;
  const matches = text.match(urlRegex);
  
  // Filter out results that might be cutting off the domain too early
  if (!matches) return [];
  
  return matches.filter(url => {
    // Make sure we have at least a basic domain structure
    const domainPart = url.split('/')[2];
    return domainPart && domainPart.includes('.');
  });
}

/**
 * Converts all http URLs to https while preserving existing https URLs
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't change https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs with /docs/ paths to use docs.example.com domain
 * Skips rewrite for dynamic paths with query params or CGI scripts
 */
export function rewriteDocsUrls(text: string): string {
  // Match http URLs with example.com domain
  // Check if path begins with /docs/ but doesn't contain dynamic elements
  return text.replace(
    /http:\/\/example\.com(\/docs\/[^?&=\s]*)/g,
    (match, path) => {
      // If path contains dynamic elements, only upgrade scheme
      if (path.includes('?') || path.includes('&') || path.includes('=') || 
          /\.(jsp|php|asp|aspx|do|cgi|pl|py)/.test(path)) {
        return match.replace('http://', 'https://');
      }
      
      // Otherwise, rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  );
}

/**
 * Extracts the year from mm/dd/yyyy format strings
 * Returns 'N/A' if the format is invalid or month/day values are out of range
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}