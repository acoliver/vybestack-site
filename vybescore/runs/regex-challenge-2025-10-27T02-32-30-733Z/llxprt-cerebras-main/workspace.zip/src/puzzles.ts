/**
 * Finds words that start with a given prefix but excludes specified exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Use word boundaries to ensure we match whole words
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive comparison)
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string
 * Uses lookaheads/lookbehinds for precise matching
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex that matches a digit immediately followed by the token
  const regex = new RegExp(`\\d${token}`, 'g');
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * Validates passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No repeated sequences like abab
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab)
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positive results
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex pattern for exclusion
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it matches an IPv4 address, return false
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Simplified IPv6 regex that should cover most common formats
  const ipv6Regex = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|:([0-9a-fA-F]{1,4}:){1,7}|::/g;
  
  // Test for IPv6 patterns
  return ipv6Regex.test(value);
}