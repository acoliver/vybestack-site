export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic pattern for email validation
  // Local part can contain letters, digits, and special characters like +, -, _, .
  // Domain part must follow standard domain naming conventions
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic email format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check if local part ends with a dot
  const [localPart] = value.split('@');
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Check if domain contains underscores (which is not allowed)
  const [, domainPart] = value.split('@');
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +1 (if present) and remove it for further validation
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must have exactly 10 digits now to be valid
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code can't start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for landlines and mobiles
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove extra spaces and hyphens for easier processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for country code +54
  let phone = cleaned;
  const hasCountryCode = phone.startsWith('+54');
  if (hasCountryCode) {
    phone = phone.substring(3);
  }
  
  // Check for trunk prefix 0
  const hasTrunkPrefix = phone.startsWith('0');
  if (hasTrunkPrefix) {
    phone = phone.substring(1);
  }
  
  // Check for mobile indicator 9 (we don't actually need to use this variable)
  if (phone.startsWith('9')) {
    phone = phone.substring(1);
  }
  
  // Area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = phone.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  phone = phone.substring(areaCode.length);
  
  // Subscriber number (6-8 digits)
  if (phone.length < 6 || phone.length > 8 || !/^\d+$/.test(phone)) {
    return false;
  }
  
  // Validate the logic for country code vs trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false; // Must have either country code or trunk prefix
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Names should only contain letters, accents, apostrophes, hyphens, and spaces
  // Using Unicode categories to match letters from any language
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check if it matches the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits or symbols (except the allowed ones)
  // Also reject X Æ A-12 style names (combination of letters and numbers)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Trim whitespace and check if the name is not empty
  if (value.trim().length === 0) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using prefix/length checks and Luhn algorithm
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  if (/^4\d{12}(\d{3})?$/.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Mastercard: starts with 5[1-5], length 16
  if (/^5[1-5]\d{14}$/.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^(34|37)\d{13}$/.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  return false;
}