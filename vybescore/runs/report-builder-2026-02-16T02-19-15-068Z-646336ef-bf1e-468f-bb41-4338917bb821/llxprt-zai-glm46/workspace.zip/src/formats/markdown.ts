/**
 * Markdown report formatter
 */

import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

/**
 * Format an amount as a currency string with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate the total of all entry amounts
 */
function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report data as Markdown format
 */
export const renderMarkdown: ReportRenderer = (data: ReportData, options: RenderOptions): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  lines.push('');

  // Entry list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};
