#!/usr/bin/env node
/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats
 */

import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

// Import format renderers
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Map of supported format names to their renderer functions
 */
const FORMAT_RENDERERS: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parse command line arguments
 */
function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

/**
 * Validate and parse report data from JSON
 */
function parseReportData(jsonContent: string, filePath: string): ReportData {
  let data: unknown;

  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}"`);
      console.error(`  ${error.message}`);
      process.exit(1);
    }
    throw error;
  }

  // Validate data structure
  if (!data || typeof data !== 'object') {
    console.error(`Error: Invalid data structure in "${filePath}" (expected object)`);
    process.exit(1);
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error(`Error: Missing or invalid "title" field (expected string)`);
    process.exit(1);
  }

  if (typeof obj.summary !== 'string') {
    console.error(`Error: Missing or invalid "summary" field (expected string)`);
    process.exit(1);
  }

  if (!Array.isArray(obj.entries)) {
    console.error(`Error: Missing or invalid "entries" field (expected array)`);
    process.exit(1);
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      console.error(`Error: Invalid entry at index ${i} (expected object)`);
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Missing or invalid "label" in entry at index ${i} (expected string)`);
      process.exit(1);
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Missing or invalid "amount" in entry at index ${i} (expected number)`);
      process.exit(1);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI execution
 */
function main(): void {
  const args = process.argv.slice(2);
  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

  // Validate format
  if (!(format in FORMAT_RENDERERS)) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }

  // Read and parse input file
  let jsonContent: string;
  try {
    jsonContent = readFileSync(resolve(dataPath), 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found "${dataPath}"`);
      process.exit(1);
    }
    throw error;
  }

  const data = parseReportData(jsonContent, dataPath);

  // Render report
  const renderer = FORMAT_RENDERERS[format];
  const options: RenderOptions = { includeTotals };
  const output = renderer(data, options);

  // Write output
  if (outputPath) {
    try {
      writeFileSync(resolve(outputPath), output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to file "${outputPath}"`);
      throw error;
    }
  } else {
    console.log(output);
  }
}

// Execute CLI
main();
