#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
const dataFilePath = args[0];

if (!dataFilePath) {
  console.error('Error: Data file path is required.');
  process.exit(1);
}

// Find format argument
const formatIndex = args.indexOf('--format');
if (formatIndex === -1 || formatIndex + 1 >= args.length) {
  console.error('Error: --format argument is required.');
  process.exit(1);
}
const format = args[formatIndex + 1];

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format "${format}". Supported formats are: markdown, text.`);
  process.exit(1);
}

// Check for --output argument
const outputIndex = args.indexOf('--output');
const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : null;

// Check for --includeTotals argument
const includeTotals = args.includes('--includeTotals');

// Read and parse data file
let data: ReportData;
try {
  const fileContent = readFileSync(dataFilePath, 'utf8');
  data = JSON.parse(fileContent);
  
  // Validate data structure
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    throw new Error('Invalid data structure');
  }
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.amount !== 'number') {
      throw new Error('Invalid entry structure');
    }
  }
} catch (error) {
  console.error(`Error: Failed to read or parse data file. ${error instanceof Error ? error.message : 'Unknown error'}`);
  process.exit(1);
}

// Render report
let report: string;
if (format === 'markdown') {
  report = renderMarkdown(data, { includeTotals });
} else {
  report = renderText(data, { includeTotals });
}

// Output report
if (outputPath) {
  try {
    writeFileSync(outputPath, report);
    console.log(`Report written to ${outputPath}`);
  } catch (error) {
    console.error(`Error: Failed to write report to ${outputPath}. ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
} else {
  console.log(report);
}