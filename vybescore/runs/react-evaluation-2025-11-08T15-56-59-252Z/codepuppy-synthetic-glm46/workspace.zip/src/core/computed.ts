/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality parameter
  const handleEqual = (equal: boolean | EqualFn<T> | undefined): EqualFn<T> | undefined => {
    if (equal === false) return undefined
    if (typeof equal === 'function') return equal
    if (equal === true || equal === undefined) return (a: T, b: T) => a === b
    return undefined
  }

  // Create both observer and subject for the computed value
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: handleEqual(_equal),
  }
  
  // Initial computation to track dependencies and set value
  updateObserver(o)
  s.value = o.value!
  
  const getter: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed is being read as a dependency
      // Add the current observer to this computed's observers
      s.observers.add(observer)
      return s.value
    }
    
    return s.value
  }
  
  // When the observer recomputes, update the subject and notify observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (currentValue?: T): T => {
    const newValue = originalUpdateFn(currentValue)!
    
    // Check if value actually changed
    if (s.equalFn && s.equalFn(s.value, newValue)) {
      return s.value
    }
    
    s.value = newValue
    
    // Notify all observers of this computed value
    for (const obs of s.observers) {
      updateObserver(obs as Observer<unknown>)
    }
    
    return newValue
  }
  
  return getter
}