/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track what this callback depends on
  const dependencies = new Set<unknown>()
  
  const compute = () => {
    // Clear previous dependencies and track new ones
    dependencies.clear()
    updateObserver(observer)
  }
  
  // Initial computation to track dependencies
  compute()
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it was observing
    // This prevents memory leaks
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}