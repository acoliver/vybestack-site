#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { validateReportData, ValidationError } from '../utils/validation.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): { dataFile: string; options: CliOptions } {
  if (args.length < 3) {
    console.error('Usage: node report.cli <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[2];
  const options: CliOptions = {
    format: '',
    includeTotals: false,
  };
  
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataFile, options };
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      throw new ValidationError('Invalid report data format');
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}: ${error.message}`);
      process.exit(1);
    } else if (error instanceof ValidationError) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else if (error instanceof Error && error.message.includes('ENOENT')) {
      console.error(`Error: File not found: ${filePath}`);
      process.exit(1);
    } else {
      console.error(`Error reading file ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  }
}

function renderReport(data: ReportData, options: CliOptions): string {
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };
  
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, renderOptions);
    case 'text':
      return renderText(data, renderOptions);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error writing to file ${outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const { dataFile, options } = parseArguments(process.argv);
    const data = loadReportData(dataFile);
    const output = renderReport(data, options);
    writeOutput(output, options.output);
  } catch (error) {
    if (error instanceof Error && error.message.includes('Unsupported format')) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error(`Unexpected error: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  }
}

main();