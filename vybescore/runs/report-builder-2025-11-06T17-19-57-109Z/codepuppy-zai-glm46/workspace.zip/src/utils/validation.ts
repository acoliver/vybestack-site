import type { ReportData, ReportEntry } from '../types.js';

export function validateReportEntry(obj: unknown): obj is ReportEntry {
  if (typeof obj !== 'object' || obj === null) {
    return false;
  }
  
  const entry = obj as Record<string, unknown>;
  return (
    typeof entry.label === 'string' &&
    typeof entry.amount === 'number' &&
    !isNaN(entry.amount)
  );
}

export function validateReportData(obj: unknown): obj is ReportData {
  if (typeof obj !== 'object' || obj === null) {
    return false;
  }
  
  const data = obj as Record<string, unknown>;
  
  if (
    typeof data.title !== 'string' ||
    typeof data.summary !== 'string' ||
    !Array.isArray(data.entries)
  ) {
    return false;
  }
  
  // Validate all entries
  return data.entries.every((entry): boolean => validateReportEntry(entry));
}

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}