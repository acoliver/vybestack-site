import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export class TextFormatter implements ReportFormatter {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Entries
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`Total: ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
}

export const renderText = (data: ReportData, options: RenderOptions): string => {
  const formatter = new TextFormatter();
  return formatter.render(data, options);
};