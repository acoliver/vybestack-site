/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace around sentence endings but avoid trailing spaces
  let result = text.replace(/([.!?])\s*/g, '$1 ');
  
  // Then capitalize the first letter after sentence boundaries
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Remove any trailing whitespace that might have been added
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Find all URLs in the text without trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+[^\s.,?!<>"']/gi;
  const urls = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return urls.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;:)\]]}*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const docsUrlPattern = /http:\/\/example\.com(\/[^\s<>"']*)/gi;
  
  return text.replace(docsUrlPattern, (match, path) => {
    // Check if path contains dynamic hints that should skip host rewrite
    const hasDynamicHints = /\?|&|=|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade to https, keep original host
      return match.replace('http://', 'https://');
    } else {
      // Always upgrade to https and check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Replace host with docs.example.com
        return match.replace('http://example.com', 'https://docs.example.com');
      } else {
        // Just upgrade to https, keep original host
        return match.replace('http://', 'https://');
      }
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check if the string matches mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1]);
  const day = parseInt(dateMatch[2]);
  const year = parseInt(dateMatch[3]);
  
  // Basic validation for month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Basic validation for day (1-31, more sophisticated validation could be added)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year.toString();
}