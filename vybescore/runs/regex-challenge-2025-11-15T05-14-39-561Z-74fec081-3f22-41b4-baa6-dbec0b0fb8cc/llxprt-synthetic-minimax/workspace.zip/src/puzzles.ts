/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token that comes after a digit but not at the start of the string
  // This matches the full pattern including the digit, not just the token
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 123123, etc.)
  // This looks for any sequence of 2+ characters that repeats immediately
  for (let i = 0; i < value.length - 1; i++) {
    for (let length = 2; length <= Math.floor((value.length - i) / 2); length++) {
      const sequence = value.substring(i, i + length);
      const nextSequence = value.substring(i + length, i + length * 2);
      if (nextSequence === sequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses can be in various formats:
  // Full: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // Shorthand: 2001:db8::8a2e:370:7334 or ::1
  // IPv4-mapped: ::ffff:192.0.2.1
  
  // This regex matches IPv6 addresses while excluding pure IPv4
  const ipv6Regex = /\b(?:[a-f0-9]{1,4}:){1,7}[a-f0-9]{1,4}\b|\b::[a-f0-9]{1,4}\b|\b[a-f0-9]{1,4}::\b|\b::\b|\b(?:[a-f0-9]{1,4}:)+::(?:[a-f0-9]{1,4}:)*[a-f0-9]{1,4}\b|\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/gi;
  
  const matches = value.match(ipv6Regex) || [];
  
  // Filter out any pure IPv4 matches (4 groups of digits separated by dots)
  const ipv6OnlyMatches = matches.filter(match => {
    // If it contains only digits and dots, it's likely IPv4
    const digitDotOnly = /^[\d.]+$/.test(match);
    if (digitDotOnly) {
      // Check if it's IPv4 format (4 groups of 1-3 digits)
      return !/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(match);
    }
    return true;
  });
  
  return ipv6OnlyMatches.length > 0;
}