export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Email must be a single line - no newlines or other control characters
  if (trimmed.includes('\n') || trimmed.includes('\r') || trimmed.includes('\t')) {
    return false;
  }
  
  // Basic structure check - must contain exactly one @
  const atCount = (trimmed.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domainPart] = trimmed.split('@');
  
  if (!localPart || !domainPart) {
    return false;
  }
  
  // Check for invalid patterns
  // No double dots anywhere
  if (trimmed.includes('..')) {
    return false;
  }
  
  // Local part cannot start or end with dots
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain part cannot start or end with dots
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Domain part cannot start or end with hyphens
  if (domainPart.startsWith('-') || domainPart.endsWith('-')) {
    return false;
  }
  
  // Domain cannot contain underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Domain must have at least one dot (except for特殊情况, but for this challenge we require TLD)
  if (!domainPart.includes('.')) {
    return false;
  }
  
  // Check domain format - must have valid TLD (letters only, 2+ chars)
  const domainParts = domainPart.split('.');
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }
  
  // Local part validation - allow letters, numbers, and these special chars: .+-_
  // But cannot have consecutive dots, and must not start/end with dots
  if (!/^[a-zA-Z0-9][a-zA-Z0-9.+_-]*[a-zA-Z0-9]$/.test(localPart)) {
    return false;
  }
  
  // Final comprehensive check for any remaining invalid patterns
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9.+_-]*[a-zA-Z0-9])?@([a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for processing
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits without country code, 11 with +1)
  if (cleaned.length < 10 || cleaned.length > 11) {
    return false;
  }
  
  // Handle country code
  let areaCode: string;
  let remainingNumber: string;
  
  if (cleaned.length === 11 && cleaned.startsWith('1')) {
    // Has country code +1
    areaCode = cleaned.substring(1, 4);
    remainingNumber = cleaned.substring(4);
  } else if (cleaned.length === 10) {
    // No country code
    areaCode = cleaned.substring(0, 3);
    remainingNumber = cleaned.substring(3);
  } else {
    return false;
  }
  
  // Check that area code doesn't start with 0 or 1 (impossible for US area codes)
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Check that the remaining number is exactly 7 digits
  if (remainingNumber.length !== 7) {
    return false;
  }
  
  // If extensions are not allowed and we have more than 11 digits, reject
  if (options?.allowExtensions === false && cleaned.length > 11) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's a valid Argentine number format
  // Pattern: [+]54[9][0]?[1-9][0-9]{1,3}[0-9]{6,8}
  
  // Case 1: With country code +54
  const withCountryCode = cleaned.match(/^(\+54)(9)?(0)?([1-9][0-9]{1,3})(\d{6,8})$/);
  if (withCountryCode) {
    return true;
  }
  
  // Case 2: Without country code, must start with 0
  const withoutCountryCode = cleaned.match(/^(0)(9)?([1-9][0-9]{1,3})(\d{6,8})$/);
  if (withoutCountryCode) {
    return true;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if the string contains only valid name characters
  // Allow: unicode letters, accents, apostrophes, hyphens, spaces
  // Disallow: digits, symbols, X Æ A-12 style names
  
  // Regex pattern for valid name characters
  // \p{L} matches any Unicode letter
  // \p{M} matches any mark (accents, combining characters)
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject obvious X Æ A-12 style names
  // This looks for unusual character combinations
  const weirdNamePattern = /[ÆØÅ]/;
  if (weirdNamePattern.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  return hasLetter && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Helper function to calculate Luhn checksum for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (valid credit cards are typically 13-19 digits)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for valid card types based on prefix and length
  // Visa: starts with 4, length 13, 16, or 19
  const isVisa = /^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19);
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const isMastercard = (/^(5[1-5])/.test(cleaned) || /^(222[1-9])/.test(cleaned) || /^(22[3-9][0-9])/.test(cleaned) || /^(2[3-6][0-9]{2})/.test(cleaned) || /^(270[0-9])/.test(cleaned) || /^(271[0-9])/.test(cleaned) || /^(2720)/.test(cleaned)) && cleaned.length === 16;
  
  // American Express: starts with 34 or 37, length 15
  const isAmex = /^(34|37)/.test(cleaned) && cleaned.length === 15;
  
  // If none of the major card types match, reject
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
