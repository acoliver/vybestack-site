/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const _equalFn: EqualFn<T> = equal === false 
    ? () => false 
    : typeof equal === 'function' 
      ? equal 
      : (a, b) => a === b

  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue) => {
      // Run the update function to get the new value
      // This will re-establish dependency relationships
      const newValue = updateFn(currentValue)
      return newValue
    },
  }

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Chain the dependency relationship
      computedObserver.observer = activeObserver
    }
    
    // Return the current cached value
    return computedObserver.value!
  }

  // Initialize the computed value
  updateObserver(computedObserver)

  return getter
}