import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// Configure template directory
app.set('views', path.join(__dirname, 'templates'));

// Database setup
let db: Database | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Email validation regex
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Phone validation: allows digits, spaces, parentheses, dashes, and leading +
const phoneRegex = /^[+]?[\d\s()\-+]+$/;

// Initialize database
async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, `../node_modules/sql.js/dist/${file}`)
    });

    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    try {
      // Try to load existing database
      const fs = await import('fs');
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(new Uint8Array(dbBuffer));
    } catch (error) {
      // Create new database if file doesn't exist
      db = new SQL.Database();
      
      // Create table using schema
      db.run(`
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
      `);
      
      // Save initial database
      await saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to file
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const data = db.export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const fsModule = await import('fs');
    fsModule.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateFormData(data: FormData): { errors: ValidationErrors; isValid: boolean } {
  const errors: ValidationErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = `${field} is required`;
    }
  });

  // Email validation
  if (data.email && !emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    errors,
    isValid: Object.keys(errors).length === 0
  };
}

// Routes

// GET / - Render contact form
app.get('/', (req, res) => {
  res.render(path.join(__dirname, 'templates/form.ejs'), {
    errors: [],
    values: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvince: (req.body.stateProvince || '').trim(),
    postalCode: (req.body.postalCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim()
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    // Re-render form with errors and previously entered values
    res.status(400).render(path.join(__dirname, 'templates/form.ejs'), {
      errors: Object.values(validation.errors),
      values: formData
    });
    return;
  }

  // Save to database
  if (db) {
    try {
      db.run(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      // Save database to file
      await saveDatabase();

      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).send('Internal server error');
    }
  } else {
    res.status(500).send('Database not available');
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req, res) => {
  res.render(path.join(__dirname, 'templates/thank-you.ejs'), {
    firstName: req.query.firstName || 'Friend'
  });
});

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('\nShutting down gracefully...');
  
  if (db) {
    try {
      await saveDatabase();
      db.close();
      console.log('Database closed successfully');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

// Handle shutdown signals
process.on('SIGTERM', async () => {
  await gracefulShutdown();
});

process.on('SIGINT', async () => {
  await gracefulShutdown();
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
