/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  Observer, 
  Subject,
  getActiveObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (equal === false || equal === undefined) {
    equalFn = () => false // Never equal, always update
  } else {
    equalFn = equal
  }

  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }

  const observer: Observer<T> = {
    name: options?.name,
    updateFn: (currentValue?: T) => {
      let newValue: T
      
      try {
        // This computed becomes the active observer while computing
        // to track its dependencies
        newValue = updateFn(currentValue)
      } catch (e) {
        newValue = currentValue || value || (undefined as T)
      }
      
      // Update if value changed
      if (!equalFn(subject.value, newValue)) {
        subject.value = newValue
        // Notify observers of this computed value
        subject.observers.forEach(obs => {
          updateObserver(obs as Observer<T>)
        })
      }
      
      return subject.value
    },
  }

  let hasInitialized = false

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // If someone is observing this computed, add them as an observer
      subject.observers.add(activeObserver)
    }
    
    if (!hasInitialized) {
      // Initialize computed value with dependency tracking
      updateObserver(observer)
      hasInitialized = true
    } else if (activeObserver) {
      // If being accessed during another computation, update to refresh dependencies
      updateObserver(observer)
    }
    
    return subject.value
  }

  return getter
}