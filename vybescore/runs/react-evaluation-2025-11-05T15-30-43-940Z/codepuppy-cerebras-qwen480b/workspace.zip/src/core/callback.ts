/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (disposed) return currentValue || value || (undefined as T)
      
      // Execute the callback function with the current computed value
      const newValue = updateFn(currentValue)
      return newValue
    },
  }
  
  // Initialize by running updateObserver to track dependencies
  // This registers the callback as an observer of any inputs/computeds accessed
  // during the initial execution of the callback
  try {
    updateObserver(observer)
  } catch (e) {
    // In case callback throws during initialization
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // The update function will now return early due to disposed check
  }
}