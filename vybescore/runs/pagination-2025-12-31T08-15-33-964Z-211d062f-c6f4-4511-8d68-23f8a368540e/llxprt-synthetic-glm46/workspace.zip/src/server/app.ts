import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate query parameters
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      if (isNaN(Number(pageParam)) || Number(pageParam) <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      page = Number(pageParam);
    }

    if (limitParam !== undefined) {
      if (isNaN(Number(limitParam)) || Number(limitParam) <= 0) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer.' });
      }
      limit = Number(limitParam);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
