import { containsIPv6 } from './dist/src/puzzles.js';

console.log('Testing various IPv6 patterns:');
console.log('2001:0db8:85a3:0000:0000:8a2e:0370:7334 (full form) ->', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('2001:db8:85a3::8a2e:370:7334 (compressed) ->', containsIPv6('2001:db8:85a3::8a2e:370:7334'));
console.log('2001:db8:: (compressed end) ->', containsIPv6('2001:db8::'));
console.log('::1 (loopback) ->', containsIPv6('::1'));
console.log('::/64 (network) ->', containsIPv6('::/64'));
console.log('fe80:: (link-local) ->', containsIPv6('fe80::'));
console.log('::ffff:192.0.2.1 (IPv4-mapped) ->', containsIPv6('::ffff:192.0.2.1'));
console.log();
console.log('Non-IPv6 patterns:');
console.log('Just ::: ->', containsIPv6('Just :::'));
console.log('Regular text: example ->', containsIPv6('Regular text: example'));
console.log('192.168.1.1 (IPv4) ->', containsIPv6('192.168.1.1'));
console.log('2001:db8::1 is IPv6 but 192.168.1.1 is IPv4 ->', containsIPv6('2001:db8::1 is IPv6 but 192.168.1.1 is IPv4'));