export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic structure: local@domain.tld
  // Local part: allow letters, digits, +, ., -, _, but no leading/trailing dots, no consecutive dots
  // Domain: allow letters, digits, hyphens, dots, but not underscores or leading/trailing dots
  // TLD: at least 2 letters
  
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Reject obvious invalid patterns first
  if (!emailPattern.test(value)) return false;
  
  // Check for consecutive dots in local or domain parts
  if (value.includes('..')) return false;
  
  // Split into local and domain parts
  const [local, domain] = value.split('@');
  
  // Local part should not start or end with a dot
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Domain should not start or end with a dot or contain underscores
  if (domain.startsWith('.') || domain.endsWith('.') || domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  void options;
  
  // Start with a clean phone number: remove spaces, dashes, parentheses
  const cleanNumber = value.replace(/[\s-()]/g, '');
  
  // Check for optional +1 prefix
  const phonePattern = /^(\+1)?(\d{10})$/;
  if (!phonePattern.test(cleanNumber)) return false;
  
  // Extract the 10-digit number (without +1 prefix if present)
  const phoneNumber = cleanNumber.startsWith('+1') ? cleanNumber.substring(2) : cleanNumber;
  
  // Area code is the first 3 digits
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1 (impossible in NANP)
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanPhone = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers:
  // Optional +54 country code
  // When country code is omitted, must start with 0 (trunk prefix)
  // Optional 9 for mobile (between country code and area code)
  // Area code: 2-4 digits, leading 1-9
  // Subscriber number: 6-8 digits
  const argentinaPhonePattern = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$|^0([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinaPhonePattern.test(cleanPhone)) return false;
  
  // If the phone starts with +54
  if (cleanPhone.startsWith('+54')) {
    // After +54, optionally a 9 for mobile, then area code
    const afterCountry = cleanPhone.substring(3);
    const mobile = afterCountry.startsWith('9') ? afterCountry.substring(1) : afterCountry;
    
    // Extract area code (2-4 digits starting with 1-9)
    const areaCodeMatch = mobile.match(/^([1-9]\d{1,3})/);
    if (!areaCodeMatch) return false;
    
    const areaCode = areaCodeMatch[1];
    const subscriberNumber = mobile.substring(areaCode.length);
    
    // Area code must be 2-4 digits with leading 1-9
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  } 
  // If the phone starts with 0 (trunk prefix)
  else if (cleanPhone.startsWith('0')) {
    const afterTrunk = cleanPhone.substring(1);
    
    // Extract area code (2-4 digits starting with 1-9)
    const areaCodeMatch = afterTrunk.match(/^([1-9]\d{1,3})/);
    if (!areaCodeMatch) return false;
    
    const areaCode = areaCodeMatch[1];
    const subscriberNumber = afterTrunk.substring(areaCode.length);
    
    // Area code must be 2-4 digits with leading 1-9
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  } 
  // Invalid format
  else {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Names should contain Unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const namePattern = /^[\p{L}\p{M}'´`-]+(?:[\s\u00A0]+[\p{L}\p{M}'´`-]+)*$/u;
  
  // Basic check: must match the pattern
  if (!namePattern.test(value)) return false;
  
  // Additional checks to reject obvious non-names
  // Reject if contains consecutive non-letter characters (except at boundaries)
  if (/[-'´`]{2,}/.test(value)) return false;
  
  // Reject if starts or ends with apostrophe or hyphen
  if (/^[-'´`]|[-'´`]$/.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove spaces and dashes
  const cleanNumber = cardNumber.replace(/[\s-]/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process each digit from right to left
  for (let i = cleanNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum modulo 10 is 0
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers for Visa/Mastercard/AmEx using prefixes and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Check Visa: starts with 4, length 13 or 16
  if (/^4\d{12}$|^4\d{15}$/.test(cleanNumber) && runLuhnCheck(cleanNumber)) {
    return true;
  }
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  if (/^(5[1-5]\d{14}|2(2[2-9][1-9]|2[3-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/.test(cleanNumber) && runLuhnCheck(cleanNumber)) {
    return true;
  }
  
  // Check American Express: starts with 34 or 37, length 15
  if (/^3[47]\d{13}$/.test(cleanNumber) && runLuhnCheck(cleanNumber)) {
    return true;
  }

  return false;
}
