export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // \b ensures word boundaries
  // [a-zA-Z]+ matches a word
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)`, 'g');

  const matches = new Set<string>();
  let match;

  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    // Only add if not in exceptions list
    if (!exceptions.includes(word)) {
      matches.add(word);
    }
  }

  return Array.from(matches);
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match the token when preceded by a digit and include that digit
  // Lookbehind ensures there's a digit before the token
  // Positive lookahead ensures token follows this pattern
  const embeddedTokenPattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = embeddedTokenPattern.exec(text)) !== null) {
    // Find the digit that precedes this match
    const index = match.index;
    if (index > 0) {
      // Combine the digit with the token
      const precedingDigit = text[index - 1];
      const combinedToken = precedingDigit + match[0];
      matches.push(combinedToken);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) return false;

  // No whitespace allowed
  if (/\s/.test(value)) return false;

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;

  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;

  // Must contain at least one symbol
  if (!/[!"#$%&'()*+,-./:;<=>?@[\\\]^_`{|}~]/.test(value)) return false;

  // No immediate repeated sequences (e.g., abab, ababab)
  if (/(.{2,})\1+/g.test(value)) return false;

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses can include:
  // - 8 groups of 4 hex digits separated by colons
  // - Zero compression using ::
  // - Mixed notation with IPv4
  // - 3 to 8 groups total (with :: compression)
  
  // Find all potential IPv6 patterns first
  // IPv6 addresses can include:
  // - 8 groups of 4 hex digits separated by colons
  // - Zero compression using ::
  // - Mixed notation with IPv4
  // - 3 to 8 groups total (with :: compression)
  
  const ipv6Pattern = /\b([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b/;
  const ipv6WithShorthandPattern = /\b([0-9a-fA-F]{1,4}(:|::)){1,7}[0-9a-fA-F]{1,4}\b|\b::\b/;
  const ipv6MixedPattern = /\b([0-9a-fA-F]{1,4}:){1,6}:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Check for IPv6 with various patterns
  // Direct pattern matching for common IPv6 forms
  if (/\b::[0-9a-fA-F]{1,4}\b/.test(value)) {
    return true;
  }
  
  if (/\b[0-9a-fA-F]{1,4}::\b/.test(value)) {
    return true;
  }
  
  if (/\b::\b/.test(value) && /\b[0-9a-fA-F]/.test(value)) {
    return true;
  }
  
  // Check for :: shorthand first
  if (/::/.test(value)) {
    // It has :: shorthand, now verify it's an IPv6 pattern, not something with random ::
    if (ipv6WithShorthandPattern.test(value)) {
      return true;
    }
  }
  
  if (ipv6MixedPattern.test(value)) {
    return true;
  }
  
  if (ipv6Pattern.test(value)) {
    return true;
  }
  
  // No IPv6 found
  return false;
}