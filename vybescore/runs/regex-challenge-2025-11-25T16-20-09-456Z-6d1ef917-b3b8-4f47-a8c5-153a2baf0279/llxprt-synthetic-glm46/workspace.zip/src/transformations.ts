/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Check for text that doesn't need processing
  if (!text || !text.trim()) return text;
  
  // Step 1: Normalize spacing between sentences - ensure exactly one space after sentence terminators
  const normalizedSpacing = text.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Step 2: Split into sentences - using sentence terminators followed by whitespace
  // This preserves abbreviations better than a simple split
  const sentences = normalizedSpacing.split(/(?<=[.!?])\s+/);
  
  // Step 3: Capitalize the first character of each sentence
  const capitalizedSentences = sentences.map(sentence => {
    // Skip empty sentences
    if (!sentence) return '';
    
    // Find the first real character that should be capitalized
    const firstLetterMatch = sentence.match(/[a-zA-Z]/);
    if (!firstLetterMatch) return sentence;
    
    const index = firstLetterMatch.index;
    if (index === undefined) return sentence;
    
    const firstLetterIndex = index;
    const beforeFirstLetter = sentence.substring(0, firstLetterIndex);
    const firstLetter = sentence[firstLetterIndex].toUpperCase();
    const rest = sentence.substring(firstLetterIndex + 1);
    
    return beforeFirstLetter + firstLetter + rest;
  });
  
  // Step 4: Join sentences with single spaces and clean up any extra spaces created
  let result = capitalizedSentences.join(' ');
  
  // Collapse multiple spaces that don't follow sentence terminators
  result = result.replace(/(?<![.!?])\s+/g, ' ');
  
  // Trim leading and trailing whitespace
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Check for text that doesn't need processing
  if (!text || !text.trim()) return [];
  
  // Regex pattern to match URLs
  // Starts with http:// or https://
  // Matches domain with optional subdomains
  // Matches optional port
  // Matches path, query string, and fragment
  const urlPattern = /(https?:\/\/)([a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+)(:[0-9]+)?(\/[^\s]*)?/g;
  
  const matches = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    // Get the full URL match
    const fullUrl = match[0];
    
// Remove trailing punctuation but keep valid URL characters
    // Be more careful about what punctuation to remove - only trailing punctuation at the end of the URL
    const cleanedUrl = fullUrl.replace(/[.,;:!?]+(?=[^a-zA-Z0-9\-_~%/.#?=]*)$/g, '');
    matches.push(cleanedUrl);
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Check for text that doesn't need processing
  if (!text || !text.trim()) return text;
  
  // Replace all http:// with https://, but don't modify existing https://
  const httpsEnforced = text.replace(/http:\/\//g, 'https://');
  
  return httpsEnforced;
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Check for text that doesn't need processing
  if (!text || !text.trim()) return text;
  
  // Pattern to match http://example.com/... URLs
  // Captures: protocol, domain, path
  const exampleUrlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)/g;
  
  const rewrittenText = text.replace(exampleUrlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if the URL should have its domain rewritten to docs.example.com
    // Skip if path contains dynamic hints or legacy extensions
    const skipConditions = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?&\s]|$)/
    ];
    
    const shouldSkipDomainRewrite = skipConditions.some(condition => condition.test(path));
    
    // If path starts with /docs/ and doesn't match skip conditions, rewrite domain
    if (path.startsWith('/docs/') && !shouldSkipDomainRewrite) {
      return `${secureProtocol}docs.example.com${path}`;
    }
    
    // Otherwise, just upgrade to https but keep original domain
    return `${secureProtocol}${domain}${path}`;
  });
  
  return rewrittenText;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day/month combinations
  // February: 29 days (we'll assume all years could be leap years)
  if (month === 2 && day > 29) return 'N/A';
  
  // April, June, September, November: 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) return 'N/A';
  
  // All other months: 31 days
  if (day > 31) return 'N/A';
  
  return year;
}
