import { extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { containsIPv6 } from './dist/src/puzzles.js';

console.log('Testing extractUrls with trailing punctuation:');
const testText = 'Visit http://example.com/docs, http://test.org, and https://api.example.com/path?query=test';
console.log('Input:', testText);
console.log('Output:', extractUrls(testText));
console.log();

console.log('Testing enforceHttps:');
console.log('http://example.com ->', enforceHttps('http://example.com'));
console.log('https://example.com ->', enforceHttps('https://example.com'));
console.log();

console.log('Testing rewriteDocsUrls:');
const docsUrl = 'http://example.com/docs/guide';
const dynamicUrl = 'http://example.com/docs/search?q=test';
console.log('docs URL:', rewriteDocsUrls(docsUrl));
console.log('dynamic URL:', rewriteDocsUrls(dynamicUrl));
console.log();

console.log('Testing extractYear:');
console.log('01/31/2024 ->', extractYear('01/31/2024'));
console.log('13/31/2024 ->', extractYear('13/31/2024'));
console.log();

console.log('Testing containsIPv6:');
console.log('IPv6: 2001:db8::1 ->', containsIPv6('IPv6: 2001:db8::1'));
console.log('IPv6: ::1 ->', containsIPv6('IPv6: ::1'));
console.log('IPv6: fe80::1ff:fe23:4567:890a ->', containsIPv6('IPv6: fe80::1ff:fe23:4567:890a'));
console.log('No IPv6: 192.168.1.1 ->', containsIPv6('No IPv6: 192.168.1.1'));
console.log('Both IPv6 and IPv4: IPv6: 2001:db8::1 and IPv4: 192.168.0.1 ->', containsIPv6('Both IPv6 and IPv4: IPv6: 2001:db8::1 and IPv4: 192.168.0.1'));