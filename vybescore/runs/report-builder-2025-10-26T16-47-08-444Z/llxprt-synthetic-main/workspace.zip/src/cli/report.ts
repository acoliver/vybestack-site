#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Formatters map to easily access different render functions
 */
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

type Format = keyof typeof formatters;

/**
 * Parses command-line arguments
 */
function parseArgs(): {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments in a simple way
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        format = args[i + 1] as Format;
        i++; // Skip next argument
        break;
      case '--output':
        outputPath = args[i + 1];
        i++; // Skip next argument
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
    }
  }

  if (!formatters[format]) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Validates the report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data: "title" must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data: "summary" must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: "entries" must be an array');
  }

  // Validate each entry
  const entries = reportData.entries.map((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: Expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: "label" must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: "amount" must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries,
  };
}

/**
 * Main function that orchestrates the CLI
 */
function main(): void {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArgs();

    // Read and parse JSON file
    let fileContent: string;
    try {
      fileContent = readFileSync(inputFile, 'utf8');
    } catch (error) {
      console.error(`Error: Could not read file "${inputFile}"`);
      process.exit(1);
    }

    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Could not parse JSON in file "${inputFile}"`);
      process.exit(1);
    }

    const reportData = validateReportData(data);

    const options: FormatOptions = {
      includeTotals,
    };

    // Render the report
    const output = formatters[format](reportData, options);

    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf8');
        console.log(`Report written to ${outputPath}`);
      } catch (error) {
        console.error(`Error: Could not write to file "${outputPath}"`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

// Run the main function
main();