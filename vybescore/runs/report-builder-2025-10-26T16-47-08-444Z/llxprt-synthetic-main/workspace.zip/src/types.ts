/**
 * Interface for the report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Interface for individual report entries
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for formatting options
 */
export interface FormatOptions {
  includeTotals: boolean;
}

/**
 * Interface for formatters
 */
export interface Formatter {
  render(data: ReportData, options: FormatOptions): string;
}