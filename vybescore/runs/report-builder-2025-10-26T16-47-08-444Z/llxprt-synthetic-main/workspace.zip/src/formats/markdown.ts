import type { ReportData, FormatOptions, Formatter } from '../types.js';

/**
 * Formats a monetary amount with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total amount from all entries
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Renders report data in Markdown format
 */
export function renderMarkdown(data: ReportData, options: FormatOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let output = `# ${title}\n\n${summary}\n\n## Entries\n`;

  for (const entry of entries) {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }

  if (includeTotals) {
    const total = calculateTotal(entries);
    output += `\n**Total:** ${formatAmount(total)}\n`;
  }

  return output;
}

/**
 * Export as a formatter object to maintain consistent interface
 */
export const markdownFormatter: Formatter = {
  render: renderMarkdown,
};