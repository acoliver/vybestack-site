import { ReportData, Formatter } from '../types/report.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const markdownFormatter: Formatter = {
  format(data: ReportData, includeTotals: boolean): string {
    const total = calculateTotal(data.entries);
    const lines: string[] = [];

    lines.push(`# ${data.title}`);
    lines.push('');
    lines.push(data.summary);
    lines.push('');
    lines.push('## Entries');

    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }

    if (includeTotals) {
      lines.push('');
      lines.push(`**Total:** ${formatAmount(total)}`);
    }

    return lines.join('\n');
  }
};