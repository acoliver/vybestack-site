import type { Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const markdownFormatter: Formatter = {
  render: renderMarkdown,
};

const textFormatter: Formatter = {
  render: renderText,
};

export const formatters: Record<string, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export function getFormatter(format: string): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
