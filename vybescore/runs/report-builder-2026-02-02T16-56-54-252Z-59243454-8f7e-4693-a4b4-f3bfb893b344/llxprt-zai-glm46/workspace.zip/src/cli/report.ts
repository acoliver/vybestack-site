#!/usr/bin/env node

import * as fs from 'node:fs';
import type { RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { getFormatter } from '../formatters/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  let inputFile = '';
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: unknown option ${arg}`);
      process.exit(1);
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      console.error(`Error: unexpected argument ${arg}`);
      process.exit(1);
    }
  }

  if (!inputFile) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  let jsonContent: string;
  try {
    jsonContent = fs.readFileSync(args.inputFile, 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: file not found: ${args.inputFile}`);
    } else if ((error as NodeJS.ErrnoException).code === 'EACCES') {
      console.error(`Error: permission denied: ${args.inputFile}`);
    } else {
      console.error(`Error: unable to read file: ${args.inputFile}`);
    }
    process.exit(1);
    return;
  }

  let parsedData: unknown;
  try {
    parsedData = JSON.parse(jsonContent);
  } catch (error) {
    console.error(`Error: invalid JSON in file: ${args.inputFile}`);
    if ((error as SyntaxError).message) {
      console.error(`Details: ${(error as SyntaxError).message}`);
    }
    process.exit(1);
    return;
  }

  let data;
  try {
    data = validateReportData(parsedData);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
    return;
  }

  let formatter;
  try {
    formatter = getFormatter(args.format);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
    return;
  }

  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const output = formatter.render(data, options);

  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: unable to write to file: ${args.outputPath}`);
      process.exit(1);
      return;
    }
  } else {
    console.log(output);
  }
}

main();
