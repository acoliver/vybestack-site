import { describe, expect, it } from 'vitest';
import { exec } from 'child_process';
import { promisify } from 'util';
import { readFile } from 'fs/promises';

const execPromise = promisify(exec);

describe('CLI', () => {
  const cliPath = 'dist/cli/report.js';
  const dataFile = 'fixtures/data.json';

  it('should render markdown format with totals', async () => {
    const { stdout } = await execPromise(`node ${cliPath} ${dataFile} --format markdown --includeTotals`);
    const expected = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34
`;
    expect(stdout).toBe(expected);
  });

  it('should render text format with totals', async () => {
    const { stdout } = await execPromise(`node ${cliPath} ${dataFile} --format text --includeTotals`);
    const expected = `Quarterly Financial Summary
Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34
`;
    expect(stdout).toBe(expected);
  });

  it('should reject unsupported format', async () => {
    try {
      await execPromise(`node ${cliPath} ${dataFile} --format html`);
    } catch (error) {
      expect(error.message).toContain('Unsupported format: html');
    }
  });
});