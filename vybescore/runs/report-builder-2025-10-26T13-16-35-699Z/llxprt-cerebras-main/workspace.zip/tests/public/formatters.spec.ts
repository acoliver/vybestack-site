import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';

describe('Formatters', () => {
  const testData = {
    title: 'Test Report',
    summary: 'This is a test summary',
    entries: [
      { label: 'Item 1', amount: 100.50 },
      { label: 'Item 2', amount: 200.75 }
    ]
  };

  describe('renderMarkdown', () => {
    it('renders markdown without totals', () => {
      const output = renderMarkdown(testData);
      expect(output).toBe(`# Test Report

This is a test summary

## Entries
- **Item 1** — $100.50
- **Item 2** — $200.75
`);
    });

    it('renders markdown with totals', () => {
      const output = renderMarkdown(testData, { includeTotals: true });
      expect(output).toBe(`# Test Report

This is a test summary

## Entries
- **Item 1** — $100.50
- **Item 2** — $200.75

**Total:** $301.25
`);
    });
  });

  describe('renderText', () => {
    it('renders text without totals', () => {
      const output = renderText(testData);
      expect(output).toBe(`Test Report
This is a test summary

Entries:
- Item 1: $100.50
- Item 2: $200.75
`);
    });

    it('renders text with totals', () => {
      const output = renderText(testData, { includeTotals: true });
      expect(output).toBe(`Test Report
This is a test summary

Entries:
- Item 1: $100.50
- Item 2: $200.75

Total: $301.25
`);
    });
  });
});