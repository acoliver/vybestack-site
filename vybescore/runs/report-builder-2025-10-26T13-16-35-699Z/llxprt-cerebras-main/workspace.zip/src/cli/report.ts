#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseArgs } from './args.js';

async function main() {
  try {
    const args = parseArgs(process.argv.slice(2));
    const dataContent = await readFile(args.dataFile, 'utf-8');
    const data: ReportData = JSON.parse(dataContent);

    // Validate data structure
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      throw new Error('Invalid data file structure');
    }

    for (const entry of data.entries) {
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry structure in data file');
      }
    }

    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(data, { includeTotals: args.includeTotals });
        break;
      case 'text':
        output = renderText(data, { includeTotals: args.includeTotals });
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }

    if (args.output) {
      // Write to file if output path is provided
      const { writeFile } = await import('fs/promises');
      await writeFile(args.output, output, 'utf-8');
    } else {
      // Otherwise write to stdout
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();