import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Initialize database
async function initDatabase() {
  const SQL = await initSqlJs();
  let db: Database;

  try {
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      const schemaContent = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schemaContent);
      saveDatabase(db);
    }
    return { db, SQL };
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(db: Database) {
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validate form data
function validateFormData(values: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!values.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!values.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!values.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!values.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!values.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }

  if (!values.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  } else if (!/^[A-Za-z0-9\s-]+$/.test(values.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code contains invalid characters' });
  }

  if (!values.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!values.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!values.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[0-9\s-()]+$/.test(values.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number contains invalid characters' });
  }

  return errors;
}

async function startApp() {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  const app = express();
  const { db } = await initDatabase();

  // Middleware
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  // Serve static files
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  
  // Parse form data
  app.use(express.urlencoded({ extended: true }));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: null, 
      values: {} 
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validationErrors = validateFormData(formData);
    
    if (validationErrors.length > 0) {
      return res.status(400).render('form', {
        errors: validationErrors.map(e => e.message),
        values: formData
      });
    }

    try {
      db.run(
        `INSERT INTO submissions 
         (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName.trim(),
          formData.lastName.trim(),
          formData.streetAddress.trim(),
          formData.city.trim(),
          formData.stateProvince.trim(),
          formData.postalCode.trim(),
          formData.country.trim(),
          formData.email.trim(),
          formData.phone.trim()
        ]
      );
      saveDatabase(db);
    } catch (error) {
      console.error('Failed to save form submission:', error);
      return res.status(500).render('form', {
        errors: ['Failed to save your submission. Please try again.'],
        values: formData
      });
    }

    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });

  // Start server
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      console.log('Express server closed');
      db.close();
      console.log('Database connection closed');
      process.exit(0);
    });
  });

  return server;
}

// Start the application
startApp().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
