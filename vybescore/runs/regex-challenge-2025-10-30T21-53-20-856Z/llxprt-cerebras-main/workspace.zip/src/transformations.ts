/**
 * Capitalizes the first character of each sentence.
 * Preserves spacing rules and leaves abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split text by sentence-ending punctuation followed by whitespace or end of string
  const sentences = text.split(/(?<=[.?!])\s+/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim leading whitespace and find the first non-whitespace character
    const trimmed = sentence.trimStart();
    const leadingSpaces = sentence.length - trimmed.length;
    
    // Capitalize the first letter of the trimmed sentence
    if (trimmed.length > 0) {
      const firstCharIndex = trimmed.search(/\S/);
      if (firstCharIndex !== -1) {
        const beforeFirstChar = trimmed.substring(0, firstCharIndex);
        const firstChar = trimmed[firstCharIndex].toUpperCase();
        const rest = trimmed.substring(firstCharIndex + 1);
        return ' '.repeat(leadingSpaces) + beforeFirstChar + firstChar + rest;
      }
    }
    
    return sentence;
  });
  
  // Join sentences with exactly one space
  return processedSentences.join(' ');
}

/**
 * Extracts URLs from text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // This regex matches URLs beginning with http:// or https://
  // and ending before whitespace or punctuation (except those allowed in URLs)
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s()<>"]*/gi;
  const matches = text.match(urlRegex);
  return matches ? matches : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't modify already https:// URLs
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs to move docs paths to docs.example.com and enforce https.
 */
export function rewriteDocsUrls(text: string): string {
  // This regex captures the scheme, host, and path of URLs
  const urlRegex = /https?:\/\/([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlRegex, (_match, host, path = '/') => {
    // Upgrade scheme to https
    const scheme = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    const dynamicHints = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
    const isDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = dynamicHints.some(hint => path.includes(hint));
    
    // Rewrite host to docs.example.com if path starts with /docs/ and has no dynamic hints
    if (isDocsPath && !hasDynamicHints) {
      host = 'docs.' + host;
    }
    
    return scheme + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Check if month and day are valid
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}