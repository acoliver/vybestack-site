export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Check basic email format
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for trailing dots in local part or domain
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Check for underscore in domain part
  const [, domainPart] = value.split('@');
  if (domainPart && domainPart.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers with support for common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890.
 * Also supports optional +1 prefix.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length check and validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for minimum valid length (10 digits) 
  // and for area code restrictions (first digit 2-9, second digit 0-9 or 1)
  const validLength = digitsOnly.length === 10 || 
    (digitsOnly.length === 11 && digitsOnly.startsWith('1'));
  
  if (!validLength) return false;
  
  // Extract area code (either first 3 digits or digits 2-4 if 11 digits with leading 1)
  const areaCodeStartIndex = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeStartIndex, areaCodeStartIndex + 3);
  
  // Check area code (must not start with 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Match against common formats
  const phoneFormats = [
    /^\(\d{3}\) \d{3}-\d{4}$/,    // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,       // 212-555-7890
    /^\d{10}$/,                  // 2125557890
    /^\+1 \(\d{3}\) \d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1 \d{3}-\d{3}-\d{4}$/,    // +1 212-555-7890
    /^\+1\d{10}$/                // +12125557890
  ];
  
  return phoneFormats.some(format => format.test(value));
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for processing
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex patterns for Argentine phone formats
  const patterns = [
    /^\+54\d{6,10}$/,                      // +54 followed by 6-10 digits
    /^\+549\d{2,4}\d{6,8}$/,              // +549 + area code (2-4 digits) + subscriber (6-8 digits)
    /^0\d{2,4}\d{6,8}$/                   // 0 + area code (2-4 digits) + subscriber (6-8 digits)
  ];
  
  // Check if it matches any base pattern
  const matchesPattern = patterns.some(pattern => pattern.test(cleanValue));
  if (!matchesPattern) return false;
  
  // Extract the parts to validate specifics
  let areaCode: string;
  let subscriber: string;
  
  if (cleanValue.startsWith('+549')) {
    // Format: +549 + area code (2-4 digits) + subscriber (6-8 digits)
    const areaCodeStart = 4;
    const areaCodeEnd = areaCodeStart + Math.min(4, cleanValue.length - areaCodeStart - 6);
    areaCode = cleanValue.substring(areaCodeStart, areaCodeEnd);
    subscriber = cleanValue.substring(areaCodeEnd);
  } else if (cleanValue.startsWith('+54')) {
    // Format: +54 + area code (2-4 digits) + subscriber (6-8 digits)
    const areaCodeStart = 3;
    const areaCodeEnd = areaCodeStart + Math.min(4, cleanValue.length - areaCodeStart - 6);
    areaCode = cleanValue.substring(areaCodeStart, areaCodeEnd);
    subscriber = cleanValue.substring(areaCodeEnd);
  } else if (cleanValue.startsWith('0')) {
    // Format: 0 + area code (2-4 digits) + subscriber (6-8 digits)
    const areaCodeStart = 1;
    const areaCodeEnd = areaCodeStart + Math.min(4, cleanValue.length - areaCodeStart - 6);
    areaCode = cleanValue.substring(areaCodeStart, areaCodeEnd);
    subscriber = cleanValue.substring(areaCodeEnd);
  } else {
    return false;
  }
  
  // Validate area code (must be 2-4 digits with leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
  
  // Validate subscriber number (must contain 6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8 || !/^\d+$/.test(subscriber)) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols and X Æ A-12 style names (containing digits).
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and X Æ A-12 style names (containing digits)
  if (/\d/.test(value)) return false;
  
  const nameRegex = /^[\p{L}\s'-]+$/u;
  return nameRegex.test(value);
}

/**
 * Helper function to run the Luhn algorithm check on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers using prefix/length checks and Luhn algorithm.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for valid credit card formats (Visa, Mastercard, AmEx)
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starting with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/; // 16 digits, starting with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starting with 34 or 37
  
  // Check if clean value matches any credit card pattern
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Apply Luhn algorithm
  return runLuhnCheck(cleanValue);
}