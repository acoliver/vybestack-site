import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { FormServer } from '../../dist/server.js';

let server: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Start the server on a test port
  process.env.PORT = '3001';
  server = new FormServer();
  await server.start();
  
  // Get the express app for testing
  app = server.app;
}, 30000); // Increase timeout for database initialization

afterAll(async () => {
  if (server && server.server) {
    server.server.close();
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const responseText = response.text || '';
    const $ = cheerio.load(responseText);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
    
    // Check labels are properly associated
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="lastName"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    // Submit form
    await request(app)
      .post('/submit')
      .send(formData)
      .expect(302)
      .expect('Location', /thank-you/);

    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Check thank-you page renders
    const thankYouResponse = await request(app)
      .get('/thank-you?firstName=John')
      .expect(200);

    const $ = cheerio.load(thankYouResponse.text || '');
    expect($('h1').text()).toContain('Thank you, John!');
    expect($('body').text()).toContain('stranger on the internet');
  });

  it('validates email format', async () => {
    const invalidData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'invalid-email',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(200);

    const responseText = response.text || '';
    const $ = cheerio.load(responseText);
    expect($('.error-list').text()).toContain('valid email address');
  });

  it('handles international formats', async () => {
    const internationalData = {
      firstName: 'Carlos',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1000',
      city: 'Córdoba',
      stateProvince: 'Córdoba',
      postalCode: 'X5000',
      country: 'Argentina',
      email: 'carlos.garcia@example.com.ar',
      phone: '+54 (351) 456-7890'
    };

    await request(app)
      .post('/submit')
      .send(internationalData)
      .expect(302);
  });
});