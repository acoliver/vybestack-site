import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
import initSqlJs from 'sql.js';
import type { Database, Statement, SqlJsStatic } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  public app: express.Application;
  public db: Database | null = null;
  public server: import('http').Server | null = null;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3000', 10);
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  }

  private setupRoutes(): void {
    this.app.get('/', this.handleFormGet.bind(this));
    this.app.post('/submit', this.handleFormSubmit.bind(this));
    this.app.get('/thank-you', this.handleThankYouGet.bind(this));
    
    // Error handling middleware
    this.app.use((err: Error, req: express.Request, res: express.Response) => {
      console.error('Error:', err);
      res.status(500).send('Internal Server Error');
    });
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL: SqlJsStatic = await initSqlJs({
        locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
      });

      const dataDir = path.join(__dirname, '..', 'data');
      const dbPath = path.join(dataDir, 'submissions.sqlite');

      // Ensure data directory exists
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      let dbData: Uint8Array | null = null;
      if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        dbData = new Uint8Array(fileBuffer);
      }

      this.db = new SQL.Database(dbData || undefined);

      // Initialize schema
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      this.db.run(schema);
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const data = this.db.export();
      const dataDir = path.join(__dirname, '..', 'data');
      const dbPath = path.join(dataDir, 'submissions.sqlite');
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (data.email && !emailRegex.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation - international format (digits, spaces, parentheses, dashes, leading +)
    const phoneRegex = /^[+]?[0-9\s\-()]+$/;
    if (data.phone && !phoneRegex.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation - alphanumeric
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (data.postalCode && !postalRegex.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal/zip code' });
    }

    return errors;
  }

  private handleFormGet(req: express.Request, res: express.Response): void {
    res.render('form', {
      errors: [],
      values: {}
    });
  }

  private handleFormSubmit(req: express.Request, res: express.Response): void {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
 };

    const errors = this.validateForm(formData);

    if (errors.length > 0) {
      res.render('form', {
        errors: errors.map(e => e.message),
        values: formData
      });
      return;
    }

    // Save to database
    try {
      const stmt: Statement = this.db!.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      stmt.free();
      this.saveDatabase();

      // Redirect to thank-you page with first name
      res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    } catch (error) {
      console.error('Failed to save submission:', error);
      res.render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  }

  private handleThankYouGet(req: express.Request, res: express.Response): void {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    this.server = this.app.listen(this.port, () => {
      console.log(`Server running on port ${this.port}`);
    });

    // Graceful shutdown handlers
    process.on('SIGTERM', this.gracefulShutdown.bind(this));
    process.on('SIGINT', this.gracefulShutdown.bind(this));
  }

  private gracefulShutdown(): void {
    console.log('Shutting down gracefully...');
    
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    }
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export { FormServer };