/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  getActiveObserver,
  notifySubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const o: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: () => {
      // Call the update function with the current value to get the new value
      const newValue = updateFn(s.value)
      s.value = newValue
      // Notify dependents that this computed value has changed
      notifySubject(s)
      return newValue
    },
  }

  const read: GetterFn<T> = () => {
    // Register this computed as an observer of its dependencies
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    
    // Only recompute if we haven't computed yet or if value is undefined
    if (s.value === undefined) {
      // Update this observer to compute the value
      updateObserver(o)
    }
    
    return s.value!
  }

  // Initial computation to establish dependencies and initial value
  // Only if value is undefined initially
  if (value === undefined) {
    updateObserver(o)
  }

  return read
}
