/**
 * Encode plain text to Base64 using standard RFC 4648 encoding.
 * Uses the canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard RFC 4648 decoding.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Accept inputs with or without padding by normalizing them
  const inputLength = input.length;
  
  // Check for invalid Base64 characters: only A-Z, a-z, 0-9, +, /, = are allowed
  if (!/^[A-Za-z0-9+/=]+$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check for correct padding structure if padding is present
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const padding = input.substring(paddingIndex);
    
    // Padding must be one or two '=' characters
    if (!/^=+$/.test(padding) || padding.length > 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // No other characters should follow padding
    if (paddingIndex + padding.length !== inputLength) {
      throw new Error('Invalid Base64 input: characters after padding');
    }
  }
  
  // Check if the length is valid (must be multiple of 4 after adding padding)
  if (inputLength % 4 !== 0 && (inputLength % 4 !== 2 && inputLength % 4 !== 3)) {
    throw new Error('Invalid Base64 input: incorrect length');
  }
  
  try {
    // Add missing padding if necessary before decoding
    let normalizedInput = input;
    const paddingNeeded = (4 - (inputLength % 4)) % 4;
    if (paddingNeeded > 0 && !input.includes('=')) {
      normalizedInput = input + '='.repeat(paddingNeeded);
    }
    
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
