import { describe, expect, it, beforeAll, afterAll, vi } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

// Import server module - note: we're importing the default export
let server: import('http').Server;
let app: import('express').Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Completely mock the sql.js module to prevent actual database initialization
  vi.mock('sql.js', async () => {
    const mockDb = {
      run: vi.fn(),
      prepare: vi.fn().mockReturnValue({
        run: vi.fn(),
        free: vi.fn()
      }),
      export: vi.fn().mockReturnValue(new Uint8Array(100)),
      close: vi.fn()
    };
    
    return {
      default: vi.fn().mockResolvedValue({
        Database: vi.fn().mockReturnValue(mockDb)
      })
    };
  });
  
  // Mock file system operations to prevent actual file access
  vi.mock('fs', async () => {
    const actual = await vi.importActual('fs');
    return {
      ...actual,
      existsSync: vi.fn().mockReturnValue(false),
      mkdirSync: vi.fn(),
      readFileSync: vi.fn(),
      writeFileSync: vi.fn()
    };
  });
  
  // Import and start the server
  const serverModule = await import('../../dist/server.js');
  app = serverModule.default;
});

afterAll(() => {
  if (server) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('input#firstName')).toHaveLength(1);
    expect($('input#lastName')).toHaveLength(1);
    expect($('input#streetAddress')).toHaveLength(1);
    expect($('input#city')).toHaveLength(1);
    expect($('input#stateProvince')).toHaveLength(1);
    expect($('input#postalCode')).toHaveLength(1);
    expect($('input#country')).toHaveLength(1);
    expect($('input#email')).toHaveLength(1);
    expect($('input#phone')).toHaveLength(1);
    
    // Check form action
    expect($('form')).toHaveLength(1);
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check for submission button
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit valid form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555 123 4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/thank-you\?firstName=John/);
    
    // Verify thank-you page content
    const thankYouResponse = await request(app).get('/thank-you?firstName=John');
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John');
  });
});