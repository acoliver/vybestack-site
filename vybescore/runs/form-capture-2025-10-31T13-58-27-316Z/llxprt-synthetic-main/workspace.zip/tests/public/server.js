// Test file specifically for server.js
const { describe, expect, it, beforeAll, afterAll } = require('vitest');
const request = require('supertest');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

let server;
let app;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start the server - use require for the compiled CommonJS module
  app = require('../dist/server.js');
  
  // Wait a short time for initialization
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Create a test HTTP server
  server = require('http').createServer(app);
  server.listen(3000);
});

afterAll(() => {
  if (server) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3000').get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('input#firstName')).toHaveLength(1);
    expect($('input#lastName')).toHaveLength(1);
    expect($('input#streetAddress')).toHaveLength(1);
    expect($('input#city')).toHaveLength(1);
    expect($('input#stateProvince')).toHaveLength(1);
    expect($('input#postalCode')).toHaveLength(1);
    expect($('input#country')).toHaveLength(1);
    expect($('input#email')).toHaveLength(1);
    expect($('input#phone')).toHaveLength(1);
    
    // Check form action
    expect($('form')).toHaveLength(1);
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check for submission button
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit valid form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555 123 4567'
    };
    
    const response = await request('http://localhost:3000')
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/thank-you\?firstName=John/);
    
    // Verify thank-you page content
    const thankYouResponse = await request('http://localhost:3000').get('/thank-you?firstName=John');
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John');
  });
});