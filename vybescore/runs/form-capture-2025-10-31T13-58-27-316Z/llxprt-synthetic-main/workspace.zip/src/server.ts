import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize express app
const app = express();

// Configuration
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Database variables
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initializeDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();

    // Try to load existing database or create a new one
    if (fs.existsSync(dbPath)) {
      try {
        const dbData = fs.readFileSync(dbPath);
        // Check if it's actually a SQLite database file
        if (dbData.length >= 16) {
          db = new SQL.Database(dbData);
          console.log('Loaded existing database');
        } else {
          // File is empty or not a proper SQLite database
          console.log('Database file is empty, creating new database');
          fs.unlinkSync(dbPath);
          db = new SQL.Database();
        }
      } catch (error) {
        console.error('Error loading existing database, creating new one:', error);
        fs.unlinkSync(dbPath);
        db = new SQL.Database();
      }
    } else {
      db = new SQL.Database();
      console.log('Created new database');
    }

    // Read schema and execute if needed
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase() {
  if (!db) {
    throw new Error('Database not initialized');
  }
  const data = db.export();
  fs.writeFileSync(dbPath, new Uint8Array(data));
  console.log('Database saved');
}

// Close database
function closeDatabase() {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory  
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set view engine for EJS templates
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  const errors = req.query.errors ? [req.query.errors] : [];
  const values = {};
  res.render('form', { errors, values });
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Form validation function
function validateForm(req: express.Request) {
  const errors: string[] = [];
  const body = req.body;
  
  // Required fields validation
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  for (const field of requiredFields) {
    if (!body[field] || (typeof body[field] === 'string' && body[field].trim() === '')) {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`);
    }
  }
  
  if (typeof body.email === 'string' && body.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(body.email)) {
      errors.push('Please enter a valid email address');
    }
  }
  
  if (typeof body.phone === 'string' && body.phone.trim() !== '') {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(body.phone)) {
      errors.push('Please enter a valid phone number');
    }
  }
  
  return errors;
}

// Store form submission in database
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function storeSubmission(formData: FormData) {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = formData;
  
  const stmt = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone]);
  stmt.free();
  
  saveDatabase();
}

// Form submission route
app.post('/submit', (req: express.Request, res: express.Response) => {
  const errors = validateForm(req);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: req.body });
  }
  
  try {
    storeSubmission(req.body);
    
    // Redirect to thank-you page with first name
    const firstName = req.body.firstName || 'Friend';
    return res.redirect(302, `/thank-you?firstName=${encodeURIComponent(firstName)}`);
  } catch (error) {
    console.error('Error storing submission:', error);
    return res.status(500).render('form', { 
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: req.body 
    });
  }
});

// Error handler
app.use((err: Error, _req: express.Request, res: express.Response) => {
  console.error(err);
  res.status(500).send('Internal Server Error');
});

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Initialize and start server
let server: import('http').Server;
startServer().then((serverInstance) => {
  server = serverInstance;
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    closeDatabase();
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });
});



// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  closeDatabase();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export default app;