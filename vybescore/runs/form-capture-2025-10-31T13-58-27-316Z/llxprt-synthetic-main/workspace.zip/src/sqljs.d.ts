declare module 'sql.js' {
  export default function initSqlJs(options?: object): Promise<SqlJs>;
  
  export interface SqlJs {
    Database: new (data?: Uint8Array | ArrayBuffer) => Database;
  }
  
  export class Database {
    constructor(data?: Uint8Array | ArrayBuffer);
    
    run(sql: string, params?: unknown[]): void;
    
    prepare(sql: string): Statement;
    
    export(): Uint8Array;
    
    close(): void;
  }
  
  export class Statement {
    run(params?: unknown[]): unknown;
    
    get(params?: unknown[]): unknown;
    
    free(): void;
  }
}