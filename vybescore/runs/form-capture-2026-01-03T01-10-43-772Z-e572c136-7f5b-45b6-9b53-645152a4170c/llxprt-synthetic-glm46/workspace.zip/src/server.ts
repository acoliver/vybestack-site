import express from "express";
import path from "path";
import { fileURLToPath } from "url";

// @ts-expect-error SQL.js doesn't have proper TypeScript definitions
import initSqlJs from "sql.js";



interface DatabaseApi {
  export(): Uint8Array;
  run(sql: string, ...params: unknown[]): void;
  close(): void;
  prepare(sql: string): {
    run(...params: unknown[]): void;
  };
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);



interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

const PORT = process.env.PORT || 3535;

async function initDatabase(): Promise<DatabaseApi> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
  });

  const fs = await import("fs");

  try {
    const data = await fs.promises.readFile(
      path.join(process.cwd(), "data/submissions.sqlite")
    );
    return new SQL.Database(new Uint8Array(data.buffer)) as DatabaseApi;
  } catch (error: unknown) {
    const db = new SQL.Database() as DatabaseApi;
    const schema = await fs.promises.readFile(
      path.join(process.cwd(), "db/schema.sql"),
      "utf8"
    );
    db.run(schema);
    return db;
  }
}

async function saveDatabase(db: DatabaseApi): Promise<void> {
  const fs = await import("fs");
  const data = db.export();
  await fs.promises.mkdir("data", { recursive: true });
  await fs.promises.writeFile(
    path.join(process.cwd(), "data/submissions.sqlite"),
    Buffer.from(data)
  );
}

function validateForm(values: FormValues): string[] {
  const errors: string[] = [];

  if (!values.firstName?.trim()) {
    errors.push("First name is required");
  }

  if (!values.lastName?.trim()) {
    errors.push("Last name is required");
  }

  if (!values.streetAddress?.trim()) {
    errors.push("Street address is required");
  }

  if (!values.city?.trim()) {
    errors.push("City is required");
  }

  if (!values.stateProvince?.trim()) {
    errors.push("State/Province is required");
  }

  if (!values.postalCode?.trim()) {
    errors.push("Postal code is required");
  }

  if (!values.country?.trim()) {
    errors.push("Country is required");
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!values.email?.trim()) {
    errors.push("Email is required");
  } else if (!emailRegex.test(values.email.trim())) {
    errors.push("Invalid email format");
  }

  if (!values.phone?.trim()) {
    errors.push("Phone number is required");
  } else {
    const phoneRegex = /^[+]?\d[\d\s\-()]*$/;
    if (!phoneRegex.test(values.phone.trim())) {
      errors.push("Invalid phone number format");
    }
  }

  return errors;
}

async function main() {
  const app = express();
  app.use(express.urlencoded({ extended: true }));
  app.use("/public", express.static(path.join(__dirname, "../public")));

  const db: DatabaseApi = await initDatabase();

  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "templates"));

  app.get("/", (req, res) => {
    res.render("form", { values: {}, errors: [] });
  });

  app.get("/thank-you", (req, res) => {
    res.render("thank-you", { firstName: "Friend" });
  });

  app.post("/submit", (req, res) => {
    const values = req.body as FormValues;
    const errors = validateForm(values);

    if (errors.length > 0) {
      return res
        .status(400)
        .render("form", { values, errors });
    }

    try {
      const stmt = db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        values.firstName?.trim(),
        values.lastName?.trim(),
        values.streetAddress?.trim(),
        values.city?.trim(),
        values.stateProvince?.trim(),
        values.postalCode?.trim(),
        values.country?.trim(),
        values.email?.trim(),
        values.phone?.trim()
      ]);
      
    } catch (error: unknown) {
      console.error("Database error:", error);
      errors.push("Database error occurred. Please try again.");
      return res
        .status(500)
        .render("form", { values, errors });
    }

    saveDatabase(db);
    
    res.redirect(302, "/thank-you");
  });

  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  const gracefulShutdown = () => {
    console.log("Shutting down gracefully...");
    db.close();
    server.close(() => {
      console.log("Server closed");
      process.exit(0);
    });
  };

  process.on("SIGTERM", gracefulShutdown);
  process.on("SIGINT", gracefulShutdown);
}

main().catch(console.error);
