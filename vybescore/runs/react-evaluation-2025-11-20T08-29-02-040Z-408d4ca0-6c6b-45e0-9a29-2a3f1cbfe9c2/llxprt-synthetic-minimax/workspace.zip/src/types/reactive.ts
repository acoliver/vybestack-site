/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<ObserverR> // observers that depend on this one
  isCallback?: boolean // mark if this is a callback observer
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  equalFn?: EqualFn<T>
  stale?: boolean
  updating?: boolean
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  dependents?: Set<ObserverR> // observers that depend on this subject
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function subscribeObserver(observer: ObserverR, dependent: ObserverR): void {
  if (!observer.dependents) {
    observer.dependents = new Set()
  }
  observer.dependents.add(dependent)
}

export function markDependentsStale(observer: ObserverR): void {
  if (observer.dependents) {
    for (const dependent of observer.dependents) {
      if ('stale' in dependent) {
        const dependentObserver = dependent as Observer<unknown>
        dependentObserver.stale = true
        
        // If this dependent is a callback, immediately evaluate it
        if (dependentObserver.isCallback && !dependentObserver.updating) {
          evaluateObserver(dependentObserver)
        }
        
        // Recursively mark dependents stale
        markDependentsStale(dependent)
      }
    }
  }
}

export function evaluateObserver<T>(observer: Observer<T>): void {
  if (observer.updating) return
  
  const previous = activeObserver
  observer.updating = true
  
  try {
    activeObserver = observer
    
    const newValue = observer.updateFn(observer.value)
    const hasChanged = observer.value !== newValue
    
    observer.value = newValue
    observer.stale = false
    
    // Only mark dependents stale if value actually changed
    if (hasChanged) {
      markDependentsStale(observer)
    }
    
  } finally {
    observer.updating = false
    activeObserver = previous
  }
}