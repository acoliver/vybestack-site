/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, subscribeObserver, evaluateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set(),
    stale: true,
    updating: false,
    isCallback: true
  }
  
  // Establish dependencies and run the callback
  const runCallback = () => {
    const activeObserver = getActiveObserver()
    
    // Establish dependency relationship
    if (activeObserver) {
      subscribeObserver(observer, activeObserver)
    }
    
    // Re-evaluate if stale
    if (observer.stale) {
      evaluateObserver(observer)
    }
  }
  
  // Initial evaluation
  runCallback()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies and cleanup
    observer.dependents?.clear()
    observer.updateFn = () => value!
    observer.stale = false
  }
}