/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  subscribeObserver,
  evaluateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
    dependents: new Set(),
    stale: true,
    updating: false
  }
  
  const getValue: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    
    // Establish dependency relationship: current observer depends on this computed value
    if (observer) {
      subscribeObserver(o, observer)
    }
    
    // Re-evaluate if stale
    if (o.stale) {
      evaluateObserver(o)
    }
    
    return o.value!
  }
  
  return getValue
}