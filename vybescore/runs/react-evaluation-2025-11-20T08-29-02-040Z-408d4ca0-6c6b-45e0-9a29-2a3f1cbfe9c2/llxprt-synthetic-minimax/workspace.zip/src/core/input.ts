/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  subscribeObserver,
  markDependentsStale,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    dependents: new Set(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // The active observer depends on this input
      subscribeObserver(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (s.equalFn) {
      if (s.equalFn(s.value, nextValue)) {
        return s.value
      }
    } else if (s.value === nextValue) {
      return s.value
    }
    
    s.value = nextValue
    
    // Mark all observers that depend on this input as stale
    markDependentsStale(s)
    
    return s.value
  }

  return [read, write]
}