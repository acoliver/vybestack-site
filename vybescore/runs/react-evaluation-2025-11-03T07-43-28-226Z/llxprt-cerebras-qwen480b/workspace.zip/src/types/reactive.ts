/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Signal<T> {
  value: T;
  subscribe(observer: Observer<T>): UnsubscribeFn;
}

export interface Observer<T> {
  name?: string;
  value?: T;
  updateFn: UpdateFn<T>;
  update(): void;
}

let activeObserver: Observer<unknown> | undefined;

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver;
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer;
}
