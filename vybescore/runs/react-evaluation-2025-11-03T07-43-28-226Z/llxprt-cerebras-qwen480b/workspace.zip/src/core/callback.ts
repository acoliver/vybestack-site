/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

class CallbackObserver<T> implements Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependencies: Set<Observer<unknown>>
  unsubscribers: Set<UnsubscribeFn>
  
  constructor(
    updateFn: UpdateFn<T>,
    initialValue?: T,
    name?: string
  ) {
    this.updateFn = updateFn
    this.value = initialValue
    this.name = name
    this.dependencies = new Set()
    this.unsubscribers = new Set()
  }
  
  update(): void {
    // Track previous active observer
    const previousObserver = getActiveObserver()
    setActiveObserver(this)
    
    try {
      // Clear previous dependencies and subscriptions
      this.unsubscribers.forEach(unsub => unsub())
      this.unsubscribers.clear()
      this.dependencies.clear()
      
      // Execute update function
      this.value = this.updateFn(this.value)
    } finally {
      // Restore previous active observer
      setActiveObserver(previousObserver)
    }
  }
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, initialValue?: T): UnsubscribeFn {
  const observer = new CallbackObserver(updateFn, initialValue)
  
  // Track previous active observer
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Initialize callback
    observer.value = updateFn(initialValue)
  } finally {
    // Restore previous active observer
    setActiveObserver(previousObserver)
  }
  
  // Return unsubscribe function
  return () => {
    // Clear dependencies to prevent memory leaks
    observer.unsubscribers.forEach(unsub => unsub())
    observer.unsubscribers.clear()
    observer.dependencies.clear()
  }
}