/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Signal,
  Observer,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  UnsubscribeFn
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  initialValue: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equal parameter
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = Object.is
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  let value = initialValue
  const subscribers = new Set<Observer<T>>()
  
  const signal: Signal<T> = {
    get value() {
      return value
    },
    subscribe(observer: Observer<T>): UnsubscribeFn {
      subscribers.add(observer)
      return () => subscribers.delete(observer)
    }
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Setup subscription for the active observer
      const unsubscribe = signal.subscribe(observer as Observer<T>)
      // Cleanup subscription when observer is disposed
      // This part would require additional implementation for full cleanup support
    }
    return value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    // Check if value actually changed using the equality function
    const isSameValue = equalFn ? equalFn(value, nextValue) : value === nextValue
    
    if (!isSameValue) {
      value = nextValue
      // Notify all subscribers
      subscribers.forEach(observer => {
        observer.update()
      })
    }
    
    return value
  }

  return [read, write]
}
