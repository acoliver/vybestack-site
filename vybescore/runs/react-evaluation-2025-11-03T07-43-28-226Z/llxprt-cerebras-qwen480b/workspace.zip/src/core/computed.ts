/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  UnsubscribeFn
} from '../types/reactive.js'

class ComputedObserver<T> implements Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependencies: Set<Observer<unknown>>
  unsubscribers: Set<UnsubscribeFn>
  
  constructor(
    updateFn: UpdateFn<T>,
    initialValue?: T,
    name?: string
  ) {
    this.updateFn = updateFn
    this.value = initialValue
    this.name = name
    this.dependencies = new Set()
    this.unsubscribers = new Set()
  }
  
  update(): void {
    // Track previous active observer
    const previousObserver = getActiveObserver()
    setActiveObserver(this)
    
    try {
      // Clear previous dependencies and subscriptions
      this.unsubscribers.forEach(unsub => unsub())
      this.unsubscribers.clear()
      this.dependencies.clear()
      
      // Compute new value
      const newValue = this.updateFn(this.value)
      
      // Update value
      this.value = newValue
    } finally {
      // Restore previous active observer
      setActiveObserver(previousObserver)
    }
  }
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  initialValue?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equal parameter
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = Object.is
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  const observer = new ComputedObserver(updateFn, initialValue, options?.name)
  
  // Track dependencies
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      activeObserver.dependencies.add(observer)
    }
    
    // If we're computing for the first time or recomputing, 
    // make sure we're tracking dependencies
    if (activeObserver === observer) {
      return observer.value as T
    }
    
    // Track previous active observer
    const previousObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      // Clear previous subscriptions
      observer.unsubscribers.forEach(unsub => unsub())
      observer.unsubscribers.clear()
      observer.dependencies.clear()
      
      // Compute value and track dependencies
      const newValue = updateFn(observer.value)
      
      // Check if value changed
      const isSameValue = equalFn ? equalFn(observer.value as T, newValue) : observer.value === newValue
      
      if (!isSameValue) {
        observer.value = newValue
      }
      
      return observer.value as T
    } finally {
      // Restore previous active observer
      setActiveObserver(previousObserver)
    }
  }
  
  // Initialize computed value
  read()
  
  return read
}