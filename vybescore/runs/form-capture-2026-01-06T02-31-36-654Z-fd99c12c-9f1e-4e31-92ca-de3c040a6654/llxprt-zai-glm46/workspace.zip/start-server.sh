#!/bin/bash
# Script to start the server and keep it running

cd /home/runner/work/vybestack-site/vybestack-site/evals/outputs/form-capture-2026-01-06T02-31-36-654Z-fd99c12c-9f1e-4e31-92ca-de3c040a6654

# Start the server in the background
node dist/server.js &
SERVER_PID=$!

# Function to cleanup on exit
cleanup() {
    echo "Stopping server (PID: $SERVER_PID)..."
    kill $SERVER_PID 2>/dev/null
    wait $SERVER_PID 2>/dev/null
    echo "Server stopped"
}

# Register cleanup for various signals
trap cleanup SIGINT SIGTERM EXIT

echo "Server started with PID: $SERVER_PID"
echo "Server running at http://localhost:3535"
echo "Press Ctrl+C to stop"

# Wait for server process
wait $SERVER_PID
