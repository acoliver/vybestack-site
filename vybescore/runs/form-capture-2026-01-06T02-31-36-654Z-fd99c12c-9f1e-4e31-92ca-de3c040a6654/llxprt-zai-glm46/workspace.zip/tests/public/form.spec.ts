import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from 'node:http';

// Import the Express app
// We need to dynamically import the built server
let server: ReturnType<typeof createServer>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Build the project first
  const { execSync } = await import('node:child_process');
  try {
    execSync('npm run build', { stdio: 'inherit' });
  } catch (e) {
    console.error('Build failed, but continuing with tests');
  }

  // Import the compiled server module
  await import('../dist/server.js');
  // The server starts automatically when imported, so we just need to wait a bit
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(async () => {
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Close server if possible
  if (server) {
    server.close();
  }

  // Force exit
  process.exit(0);
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);

    // Check for form element
    expect($('form').length).toBeGreaterThan(0);

    // Check for all required fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);

    // Check for labels
    expect($('label[for="firstName"]').text()).toContain('First Name');
    expect($('label[for="lastName"]').text()).toContain('Last Name');
    expect($('label[for="email"]').text()).toContain('Email');
    expect($('label[for="phone"]').text()).toContain('Phone');

    // Check for submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(302);

    // Check redirect
    expect(response.headers.location).toBe('/thank-you');

    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'abc'
      })
      .expect(400);

    const $ = cheerio.load(response.text);

    // Check for error summary
    expect($('.error-summary').length).toBeGreaterThan(0);

    // Check for error messages
    expect(response.text).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'not-an-email',
        phone: '+1 234 567 8900'
      })
      .expect(400);

    expect(response.text).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: 'invalid-phone'
      })
      .expect(400);

    expect(response.text).toContain('valid phone');
  });

  it('accepts international phone formats', async () => {
    // Clean database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const internationalPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+86 138 0000 0000'
    ];

    for (const phone of internationalPhones) {
      await request('http://localhost:3535')
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: '12345',
          country: 'Test Country',
          email: `test${phone}@example.com`,
          phone
        })
        .expect(302);
    }
  });

  it('renders thank you page', async () => {
    const response = await request('http://localhost:3535')
      .get('/thank-you')
      .expect(200);

    expect(response.text).toContain('Thank You');
    expect(response.text).toLowerCase().includes('spam');
  });
});
