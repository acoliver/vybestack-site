/**
 * Validation utilities for form input
 */

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

/**
 * Validates that a field is not empty
 */
export function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
}

/**
 * Validates email format using a simple regex
 */
export function validateEmail(email: string): ValidationError | null {
  if (!email || email.trim() === '') {
    return { field: 'email', message: 'Email is required' };
  }

  // Simple but effective email regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }

  return null;
}

/**
 * Validates phone number - accepts international formats
 * Allows digits, spaces, parentheses, dashes, and leading +
 */
export function validatePhone(phone: string): ValidationError | null {
  if (!phone || phone.trim() === '') {
    return { field: 'phone', message: 'Phone number is required' };
  }

  // Allow optional leading +, then digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return { field: 'phone', message: 'Please enter a valid phone number' };
  }

  // Must contain at least some digits
  const digitsOnly = phone.replace(/\D/g, '');
  if (digitsOnly.length < 5) {
    return { field: 'phone', message: 'Phone number is too short' };
  }

  return null;
}

/**
 * Validates postal/zip code - accepts alphanumeric strings
 * Handles UK "SW1A 1AA" and Argentine "C1000" or "B1675" formats
 */
export function validatePostalCode(postalCode: string): ValidationError | null {
  if (!postalCode || postalCode === '') {
    return { field: 'postal_code', message: 'Postal/Zip code is required' };
  }

  // Allow alphanumeric characters with spaces
  const postalCodeRegex = /^[\dA-Za-z\s-]+$/;
  if (!postalCodeRegex.test(postalCode)) {
    return { field: 'postal_code', message: 'Please enter a valid postal/zip code' };
  }

  if (postalCode.trim().length < 2) {
    return { field: 'postal_code', message: 'Postal/Zip code is too short' };
  }

  return null;
}

/**
 * Validates all form fields
 */
export interface FormInput {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(input: FormInput): ValidationResult {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredError = validateRequired(input.firstName, 'First name');
  if (requiredError) errors.push(requiredError);

  const requiredError2 = validateRequired(input.lastName, 'Last name');
  if (requiredError2) errors.push(requiredError2);

  const requiredError3 = validateRequired(input.streetAddress, 'Street address');
  if (requiredError3) errors.push(requiredError3);

  const requiredError4 = validateRequired(input.city, 'City');
  if (requiredError4) errors.push(requiredError4);

  const requiredError5 = validateRequired(input.stateProvince, 'State/Province/Region');
  if (requiredError5) errors.push(requiredError5);

  const requiredError6 = validateRequired(input.country, 'Country');
  if (requiredError6) errors.push(requiredError6);

  // Email validation
  const emailError = validateEmail(input.email);
  if (emailError) errors.push(emailError);

  // Phone validation
  const phoneError = validatePhone(input.phone);
  if (phoneError) errors.push(phoneError);

  // Postal code validation
  const postalError = validatePostalCode(input.postalCode);
  if (postalError) errors.push(postalError);

  return {
    valid: errors.length === 0,
    errors
  };
}
