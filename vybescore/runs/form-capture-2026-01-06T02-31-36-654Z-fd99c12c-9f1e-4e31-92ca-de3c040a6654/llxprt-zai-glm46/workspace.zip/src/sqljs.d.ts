/**
 * Type declarations for sql.js
 * These declarations provide TypeScript types for the sql.js library
 */

declare module 'sql.js' {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export type SqlValue = any;

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export interface Database {
    run(sql: string, params?: SqlValue[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: SqlValue[][];
  }

  export interface Statement {
    bind(values?: SqlValue[]): boolean;
    step(): boolean;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    getAsObject(params?: any[]): Record<string, unknown>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    get(params?: any[]): unknown[];
    getColumnNames(): string[];
    free(): boolean;
  }

  export default function initSqlJs(config?: {
    locateFile?: (filename: string) => string;
  }): Promise<SqlJsStatic>;
}
