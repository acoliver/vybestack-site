/**
 * Database service using sql.js (WASM build)
 * Handles SQLite database initialization, inserts, and persistence
 */

import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_DIR = join(__dirname, '..', 'data');
const DB_PATH = join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = join(__dirname, '..', 'db', 'schema.sql');

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseService {
  private db: Database | null = null;
  private SQL: SqlJsStatic | null = null;

  /**
   * Initialize the database - load from disk or create new
   */
  async initialize(): Promise<void> {
    // Ensure data directory exists
    if (!existsSync(DB_DIR)) {
      mkdirSync(DB_DIR, { recursive: true });
    }

    // Initialize sql.js
    this.SQL = await initSqlJs();

    // Load existing database or create new one
    if (existsSync(DB_PATH)) {
      const buffer = readFileSync(DB_PATH);
      this.db = new this.SQL.Database(buffer);
    } else {
      this.db = new this.SQL.Database();
      await this.initializeSchema();
    }
  }

  /**
   * Initialize database schema from schema.sql
   */
  private async initializeSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = readFileSync(SCHEMA_PATH, 'utf-8');
    this.db.run(schema);
  }

  /**
   * Insert a form submission into the database
   */
  async insertSubmission(data: SubmissionData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.step();
    stmt.free();

    // Get the last inserted row ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    const lastId = result[0]?.values[0]?.[0] as number ?? 0;

    // Persist changes to disk
    this.persist();

    return lastId;
  }

  /**
   * Save the database to disk
   */
  persist(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    writeFileSync(DB_PATH, data);
  }

  /**
   * Close the database connection
   */
  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  /**
   * Check if database is initialized
   */
  isInitialized(): boolean {
    return this.db !== null;
  }
}

// Singleton instance
export const dbService = new DatabaseService();
