import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || '3535';
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
let db: Database | null = null;

// Middleware
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();
  const fs = await import('node:fs');

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load or create database
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow international formats: + followed by digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s()]+$/;
  return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces and dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCode.length > 0 && postalRegex.test(postalCode);
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  } else if (!validatePostalCode(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, and spaces' });
  }

  if (!data.country || data.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number (e.g., +44 20 7946 0958)' });
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('index', { 
    errors: [], 
    formData: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('index', { errors, formData });
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]
    );
    saveDatabase();
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  await initDatabase();
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export default app;
