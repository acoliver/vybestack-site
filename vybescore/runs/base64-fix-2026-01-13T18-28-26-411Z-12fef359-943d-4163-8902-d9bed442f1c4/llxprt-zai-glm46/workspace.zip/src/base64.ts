const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate a Base64 string to ensure it contains only valid characters.
 * Throws an error if the string contains invalid characters.
 */
function validateBase64(input: string): void {
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for padding in the middle of the string (invalid)
  const withoutTrailingPadding = input.replace(/=+$/, '');
  if (withoutTrailingPadding.includes('=')) {
    throw new Error('Invalid Base64 input: padding characters must only appear at the end');
  }

  // When there's no padding, the input can be any length that's a multiple of 4
  // OR any length that would be valid with padding added
  // However, for simplicity and to reject clearly invalid inputs, we require
  // that unpadded inputs have a length that is at least 4 and could be valid
  // We'll be more lenient: unpadded inputs can be any length >= 4
  // Only check the multiple-of-4 constraint if there IS padding
  const paddingCount = input.length - withoutTrailingPadding.length;
  if (paddingCount > 0 && input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: length must be a multiple of 4');
  }

  // Check padding count (should be 0, 1, or 2)
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }

  // For unpadded input, ensure it's not too short to be valid
  // The minimum valid base64 string (without padding) is 2 characters (which decodes to 1 byte)
  // But we'll allow any reasonable length >= 2 for unpadded
  if (paddingCount === 0 && input.length < 2) {
    throw new Error('Invalid Base64 input: too short');
  }
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) when required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads (invalid characters, malformed padding).
 */
export function decode(input: string): string {
  // Validate the input before attempting to decode
  validateBase64(input);

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
