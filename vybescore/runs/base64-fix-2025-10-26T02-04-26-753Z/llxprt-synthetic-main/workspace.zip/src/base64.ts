/**
 * Encode plain text to Base64.
 * Uses standard RFC 4648 Base64 alphabet with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard RFC 4648 Base64 alphabet and validates input.
 */
export function decode(input: string): string {
  // Validate Base64 input: only allow A-Z, a-z, 0-9, +, /, and = (padding)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // The canonical length of a Base64 string should be a multiple of 4
  // But we need to handle cases with no padding too
  const paddingLength = (input.match(/=/g) || []).length;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // All padding must be at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding is present, everything after the first = must be padding
    if (!input.slice(paddingIndex).match(/^=+$/)) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
  }

  let normalizedInput = input.trim();
  
  // Remove existing padding to be able to add the correct amount
  normalizedInput = normalizedInput.replace(/=+$/, '');
  
  // Add the correct amount of padding to make the length a multiple of 4
  // This is required for proper Base64 validation
  const paddingNeeded = (4 - (normalizedInput.length % 4)) % 4;
  normalizedInput += '='.repeat(paddingNeeded);

  try {
    // Only proceed if the length is now a multiple of 4
    if (normalizedInput.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
    
    // Try with standard base64 decoding
    const buffer = Buffer.from(normalizedInput, 'base64');
    
    // Double-check if the string was valid by trying to encode it back
    // and comparing with a canonical version
    const reEncoded = Buffer.from(buffer.toString('utf8'), 'utf8').toString('base64');
    
    // Remove padding from both for comparison
    const originalWithoutPadding = input.replace(/=+$/, '');
    const reEncodedWithoutPadding = reEncoded.replace(/=+$/, '');
    
    // If the base64 strings don't match, the input was invalid
    if (originalWithoutPadding !== reEncodedWithoutPadding) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
