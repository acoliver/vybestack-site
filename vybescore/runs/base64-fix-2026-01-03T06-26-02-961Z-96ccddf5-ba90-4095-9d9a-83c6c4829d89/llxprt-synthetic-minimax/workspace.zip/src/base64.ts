/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Normalize input by removing whitespace and checking for valid characters
  const normalized = input.trim();

  // Basic validation: check for invalid Base64 characters
  // Valid Base64 characters: A-Z, a-z, 0-9, +, /, = (padding only at the end)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains disallowed characters');
  }

  try {
    // Handle missing padding for better compatibility
    let paddedInput = normalized;
    const missingPadding = (4 - (normalized.length % 4)) % 4;
    if (missingPadding > 0 && !normalized.endsWith('=')) {
      paddedInput = normalized + '='.repeat(missingPadding);
    }

    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
