import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import express from 'express';
import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { load } from 'cheerio';

let server: import('http').Server | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Set up a minimal test app
beforeAll(async () => {
  // Initialize sql.js
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const SQL = await initSqlJs();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (global as any).SQL_DB = SQL.Database;
  
  // Import server after setting up global SQL
  const serverModule = await import('../../src/server.ts');
  const serverApp = serverModule.default;
  
  server = serverApp.listen(0); // Use random port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }
    
    const response = await request(server)
      .get('/')
      .expect(200);
      
    expect(response.text).toContain('form');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone');
  });

  it('persists submission and redirects', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    // Try form submission with different content types
    console.log('Testing with form data...');
    let response = await request(server)
      .post('/submit')
      .type('form')
      .send(formData);
      
    console.log('First attempt - Response status:', response.status);
    
    if (response.status !== 302) {
      console.log('Trying with JSON...');
      response = await request(server)
        .post('/submit')
        .send(formData);
        
      console.log('Second attempt - Response status:', response.status);
    }
      
    // Expect a redirect on successful form submission
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
      
    // Verify the database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
