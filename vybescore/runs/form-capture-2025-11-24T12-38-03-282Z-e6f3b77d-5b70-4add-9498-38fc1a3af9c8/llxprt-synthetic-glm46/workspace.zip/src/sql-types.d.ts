declare module 'sql.js' {
  export default function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJs>;

  interface SqlJs {
    Database: new (data?: Uint8Array) => Database;
  }

  export interface Database {
    run(query: string, params?: unknown[]): unknown;
    export(): Uint8Array;
    close(): void;
    prepare(query: string): Statement;
  }

  interface Statement {
    run(params?: unknown[]): unknown;
    step(): unknown[];
    free(): void;
  }
}