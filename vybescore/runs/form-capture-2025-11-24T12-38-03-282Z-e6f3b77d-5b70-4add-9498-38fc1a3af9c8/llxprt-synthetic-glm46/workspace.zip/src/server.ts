import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // Add JSON parser for debugging
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;
let server: import('http').Server | null = null;
let isShuttingDown = false;

function initializeDatabase(): unknown {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
const SqlJsDatabaseClass = (global as unknown as { SQL_DB: any }).SQL_DB;
    let dataBuffer: Uint8Array;
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      dataBuffer = fs.readFileSync(dbPath);
    } else {
      dataBuffer = new Uint8Array(0);
    }
    
    const database = new SqlJsDatabaseClass(dataBuffer);
    
    // Initialize schema if needed
    const schema = fs.readFileSync(schemaPath, 'utf8');
    database.run(schema);
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase() {
  if (db && !isShuttingDown) {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  [key: string]: string | undefined;
}

// Validation functions
function validateForm(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 
    'city', 'stateProvince', 'postalCode', 
    'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push(`${getFieldName(field)} is required`);
    }
  }
  
  // Email validation
  if (formData.email && formData.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push('Please enter a valid email address');
    }
  }
  
  // Phone validation
  if (formData.phone && formData.phone.trim() !== '') {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
    }
  }
  
  // Postal code validation (alphanumeric allowed)
  if (formData.postalCode && formData.postalCode.trim() !== '') {
    const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalCodeRegex.test(formData.postalCode)) {
      errors.push('Postal code can only contain letters, numbers, spaces, and dashes');
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

function getFieldName(fieldName: string): string {
  const fieldNames: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State/Province/Region',
    postalCode: 'Postal/Zip code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone number'
  };
  return fieldNames[fieldName] || fieldName;
}

// Helper function to safely run database queries
function queryDatabase(query: string, params: (string | number)[] = []) {
  if (!db) {
    throw new Error('Database not initialized');
  }
  const result = db.run(query, params);
  // Save database after any write operation
  saveDatabase();
  return result;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body;
  
  console.log('Form submitted:', formData);
  const validation = validateForm(formData);
  console.log('Validation result:', validation);
  
  if (!validation.isValid) {
    console.log('Form invalid, re-rendering with errors:', validation.errors);
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  try {
    // Insert form data into database
    queryDatabase(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
    // Extract firstName from the most recent submission if possible
  let firstName = 'friend';
  try {
// eslint-disable-next-line @typescript-eslint/no-explicit-any
    if (db) {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      stmt.step();
      const result = stmt.get();
      firstName = (result && result[0]) ? result[0] as string : 'Friend';
      stmt.free();
    }
  } catch (error) {
    console.error('Error fetching last submission:', error);
  }
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  isShuttingDown = true;
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      if (db) {
        db.close();
        console.log('Database connection closed');
        process.exit(0);
      }
    });
  }
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  isShuttingDown = true;
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      if (db) {
        db.close();
        console.log('Database connection closed');
        process.exit(0);
      }
    });
  }
});

// Initialize database
db = initializeDatabase();

// Start the server if running in standalone mode
if (import.meta.url === `file://${process.argv[1]}`) {
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

// Export for testing
export default app;