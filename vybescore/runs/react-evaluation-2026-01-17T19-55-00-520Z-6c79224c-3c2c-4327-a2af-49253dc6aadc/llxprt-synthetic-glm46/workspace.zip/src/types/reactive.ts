/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<any>
  try {
    observer.value = observer.updateFn()
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<any>): void {
  subject.observers.forEach(observer => {
    updateObserver(observer)
  })
}

let trackCallbackDependency: ((activeObserver: Observer<any>, subject: Subject<any>) => void) | null = null

export function setCallbackTracker(tracker: (activeObserver: Observer<any>, subject: Subject<any>) => void) {
  trackCallbackDependency = tracker
}

export function addObserver(subject: Subject<any>, observer: Observer<any>): void {
  subject.observers.add(observer)
  
  // If another observer is active, track this subject for it if it's a callback
  const activeObserver = getActiveObserver()
  if (activeObserver && activeObserver !== observer && trackCallbackDependency) {
    // This observer is being added while another observer is active
    // Use tracking function to determine if activeObserver is a callback
    trackCallbackDependency(activeObserver, subject)
  }
}

export function removeObserver(subject: Subject<any>, observer: Observer<any>): void {
  subject.observers.delete(observer)
}
