/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  Subject,
  Observer,
  addObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equal to proper equality function
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  // Create subject for this computed value
  const subject: Subject<T> = {
    name: _options?.name,
    observers: new Set(),
    value: value as T,
    equalFn
  }

  let isComputing = false

  // Create observer for this computed
  const observer: Observer<T> = {
    name: _options?.name,
    updateFn: () => updateFn(value as T),
    value: value as T
  }

  // Initial computation
  updateObserver(observer)
  subject.value = observer.value as T

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // When this computed is read by another observer, register this observer
      addObserver(subject, observer)
    }

    // For initial access without dependencies, just compute and return
    if (subject.observers.size === 0) {
      const computedValue = updateFn(value)
      subject.value = computedValue
      return subject.value
    }

    // Only recompute if we're not already computing
    if (!isComputing) {
      isComputing = true
      const prevActiveObserver = getActiveObserver()
      try {
        setActiveObserver(observer)
        
        const newValue = updateFn(observer.value)
        
        // Update subject value and notify observers if changed
        if (!subject.equalFn || !subject.equalFn(subject.value, newValue)) {
          subject.value = newValue
          notifyObservers(subject)
        }
      } finally {
        isComputing = false
        setActiveObserver(prevActiveObserver)
      }
    }

    return subject.value
  }

  // Set up the observer to update this computed when dependencies change
  observer.updateFn = (): T => {
    // Prevent re-entrant computations
    if (isComputing) {
      return subject.value
    }
    
    const prevActiveObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      isComputing = true
      const newValue = updateFn(value as T)
      return newValue as T
    } finally {
      isComputing = false
      setActiveObserver(prevActiveObserver)
    }
  }

  // Update subject when observer updates
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (): T => {
    // Prevent re-entrant computations
    if (isComputing) {
      return subject.value
    }
    
    isComputing = true
    try {
      const newValue = originalUpdateFn()
      
      // Update subject value and notify observers if changed
      if (!subject.equalFn || !subject.equalFn(subject.value, newValue)) {
        subject.value = newValue
        notifyObservers(subject)
      }
      
      return newValue
    } finally {
      isComputing = false
    }
  }

  return getter
}
