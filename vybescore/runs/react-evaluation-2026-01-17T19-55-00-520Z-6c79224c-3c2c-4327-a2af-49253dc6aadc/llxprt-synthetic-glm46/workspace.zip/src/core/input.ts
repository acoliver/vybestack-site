/**
 * Input closure implementation for reactive primitives.
 */

import { 
  EqualFn, 
  GetterFn, 
  SetterFn, 
  Options, 
  InputPair,
  getActiveObserver,
  Subject,
  addObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Convert boolean equal to proper equality function
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  // Create subject for this input
  const subject: Subject<T> = {
    name: _options?.name,
    observers: new Set(),
    value,
    equalFn
  }
  
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addObserver(subject, activeObserver)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value should be updated
    if (subject.equalFn && subject.equalFn(subject.value, nextValue)) {
      return subject.value
    }
    
    const prevValue = subject.value
    subject.value = nextValue
    
    // Notify all observers if value changed
    if (!subject.equalFn || !subject.equalFn(prevValue, nextValue)) {
      notifyObservers(subject)
    }
    
    return nextValue
  }

  return [read, write]
}
