/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  getActiveObserver,
  setActiveObserver,
  Observer,
  Subject,
  removeObserver,
  setCallbackTracker
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: () => T, value?: T): UnsubscribeFn {
  let disposed = false
  const subjects = new Set<Subject<any>>()
  
  // Create observer for this callback
  const observer: Observer<T> = {
    updateFn: () => updateFn(),
    value: value
  }
  
  // Store link to observer on the subjects set for tracking
  ;(subjects as any).__observer = observer
  
  const execute = () => {
    if (disposed) return
    
    // Clear previous subjects
    subjects.clear()
    
    // Set this callback as the active observer to track dependencies
    const prevActiveObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      observer.value = updateFn()
    } finally {
      // Restore the previous observer
      setActiveObserver(prevActiveObserver)
    }
  }
  
  // Override the observer's updateFn with execute
  observer.updateFn = (): T => {
    execute()
    return observer.value as T
  }
  
  // Execute immediately to register dependencies
  execute()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all tracked subjects
    subjects.forEach(subject => {
      removeObserver(subject, observer)
    })
    
    // Clear the callback to stop further updates
    subjects.clear()
  }
}

// Register callback dependency tracking function
setCallbackTracker(function trackCallbackDependency(activeObserver: Observer<any>, subject: Subject<any>) {
  if (!activeObserver) return
  
  // Check all properties of the active observer to find the subjects set
  for (const key in activeObserver) {
    const val = (activeObserver as any)[key]
    if (val && typeof val === 'object' && val.__observer === activeObserver) {
      // This is the subjects set for this callback
      val.add(subject)
      break
    }
  }
})
