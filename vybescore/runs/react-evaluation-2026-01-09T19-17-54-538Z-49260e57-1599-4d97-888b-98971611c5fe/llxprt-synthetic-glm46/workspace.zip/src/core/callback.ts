/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getComputedDependencies, clearComputedDependencies, sourceToObservers } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Execute the callback function once to track its dependencies
  updateObserver(observer)
  
  // Get dependencies and register this observer with each dependency and maintain reverse mapping
  const deps = getComputedDependencies(observer)
  if (deps) {
    // For each dependency, add this observer to its observers
    for (const subject of deps) {
      subject.observers.add(observer)
      
      // Also add to the sourceToObservers mapping
      const dependentObservers = sourceToObservers.get(subject)
      if (dependentObservers) {
        dependentObservers.add(observer)
      }
    }
  }
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects' observers
    const deps = getComputedDependencies(observer)
    if (deps) {
      for (const subject of deps) {
        subject.observers.delete(observer)
        
        // Also remove from the sourceToObservers mapping
        const dependentObservers = sourceToObservers.get(subject)
        if (dependentObservers) {
          dependentObservers.delete(observer)
        }
      }
    }
    
    // Clear dependencies
    clearComputedDependencies(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
