/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  clearComputedDependencies
} from '../types/reactive.js'



/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  

  const getter: GetterFn<T> = (): T => {
    // Always clear dependencies when accessed
    clearComputedDependencies(o)
    
    // Check if we're being called as part of a dependency tracking operation
    const currentObserver = getActiveObserver()
    
    if (currentObserver) {
      // Use existing system function to compute value and track dependencies
      return updateObserver(o)!
    } else {
      // Direct access without dependency tracking, but still compute if needed
      return updateObserver(o)!
    }
  }

  return getter
}
