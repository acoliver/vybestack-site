/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  registerComputedDependency,
  addComputedToSubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  sourceToObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
function getDefaultEqual<T>(): EqualFn<T> {
  return (lhs: T, rhs: T) => lhs === rhs
}

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? getDefaultEqual<T>() : 
    equal === false ? undefined : 
    typeof equal === 'function' ? equal : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // If this observer is a computed observer, register this dependency
      registerComputedDependency(observer as Observer<T>, s)
      // Also add this computed to the subject's observers for notifications
      addComputedToSubject(observer as Observer<T>, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = equalFn ? !equalFn(s.value, nextValue) : true
    if (shouldUpdate) {
      s.value = nextValue
    }
    
    // Update all observers that depend on this input directly
    // This also handles cascading updates for computed values and callbacks
    for (const observer of s.observers) {
      if (observer.updateFn) {
        updateObserver(observer as Observer<T>)
      }
    }
    
    // Also manually notify all observers through sourceToObservers mapping
    // This ensures callbacks are properly triggered
    const directObservers = sourceToObservers.get(s)
    if (directObservers) {
      for (const dependentObserver of directObservers) {
        updateObserver(dependentObserver as Observer<T>)
      }
    }
    
    return s.value
  }

  // Clear current subject after reading
  return [read, write]
}
