/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

// Global stack to track call context for recomputation
const observerStack: Observer<any>[] = []

export function pushObserver(observer: Observer<any>): void {
  observerStack.push(observer)
}

export function popObserver(): Observer<any> | undefined {
  return observerStack.pop()
}

export function isOnStack(observer: Observer<any>): boolean {
  return observerStack.includes(observer)
}

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  updateFn?: UpdateFn<any>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let currentSubject: Subject<any> | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function getCurrentSubject(): Subject<any> | undefined {
  return currentSubject
}

export function setCurrentSubject(subject: Subject<any>): void {
  currentSubject = subject
}

export function updateObserver<T>(observer: Observer<T>): T | undefined {
  // Prevent circular dependencies
  if (isOnStack(observer)) {
    return observer.value
  }
  
  const previous = activeObserver
  activeObserver = observer
  pushObserver(observer)
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    
    // For simple observers like inputs that don't have their own dependencies, 
    // always handle notifications through the input update mechanism
    // For computed/callback observers, notify through standard mechanism
    if (hasDependencies(observer)) {
      notifyDependentObservers(observer as Observer<any>)
    }
    
    return observer.value
  } finally {
    popObserver()
    activeObserver = previous
  }
}

function hasDependencies(observer: Observer<any>): boolean {
  return computedDependencies.has(observer)
}

// Helper function to notify all dependent observers
function notifyDependentObservers(observer: Observer<any>): void {
  // Get all subjects this observer depends on
  const deps = computedDependencies.get(observer)
  if (deps) {
    for (const subject of deps) {
      // For each subject, notify all its dependent observers
      const dependentObservers = sourceToObservers.get(subject)
      if (dependentObservers) {
        for (const dependentObserver of dependentObservers) {
          // Update the dependent observer directly
          updateObserver(dependentObserver as Observer<any>)
        }
      }
    }
  }
}

// Global registry for computed values to track their dependencies
const computedDependencies = new WeakMap<Observer<any>, Set<Subject<any>>>()
const sourceToObservers = new WeakMap<Subject<any>, Set<Observer<any>>>()

export function registerComputedDependency(computed: Observer<any>, subject: Subject<any>): void {
  let deps = computedDependencies.get(computed)
  if (!deps) {
    deps = new Set()
    computedDependencies.set(computed, deps)
  }
  deps.add(subject)
}

export function addComputedToSubject(computed: Observer<any>, subject: Subject<any>): void {
  // Add this computed observer to the subject's observers so it gets notified
  subject.observers.add(computed)
  
  // Track which observers depend on this subject
  // This allows us to notify them when this subject value changes
  let dependentObservers = sourceToObservers.get(subject)
  if (!dependentObservers) {
    dependentObservers = new Set()
    sourceToObservers.set(subject, dependentObservers)
  }
  dependentObservers.add(computed)
}

export function getComputedDependencies(computed: Observer<any>): Set<Subject<any>> | undefined {
  return computedDependencies.get(computed)
}

export function clearComputedDependencies(computed: Observer<any>): void {
  const deps = computedDependencies.get(computed)
  if (deps) {
    // Remove this computed observer from all its dependent subjects
    for (const subject of deps) {
      subject.observers.delete(computed)
      
      // Also remove from the sourceToObservers mapping
      const dependentObservers = sourceToObservers.get(subject)
      if (dependentObservers) {
        dependentObservers.delete(computed)
      }
    }
  }
  computedDependencies.delete(computed)
}

export function getSourceToObservers(): typeof sourceToObservers {
  return sourceToObservers
}

// Export the maps for use in other modules
export { sourceToObservers, computedDependencies }
