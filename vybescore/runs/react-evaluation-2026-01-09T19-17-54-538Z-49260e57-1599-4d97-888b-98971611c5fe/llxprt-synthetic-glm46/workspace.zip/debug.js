import { createInput, createComputed, createCallback } from './src/index.js';

// First test case
console.log('=== Testing compute cells fire callbacks ===');
const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);
let value = 0;
createCallback(() => {
  console.log(`Callback triggered: output()=${output()}, setting value to ${output()}`);
  value = output();
});
console.log(`Before setInput(3): input=${input()}, output=${output()}, value=${value}`);
setInput(3);
console.log(`After setInput(3): input=${input()}, output=${output()}, value=${value}`);
console.log(`Expected value=4, actual value=${value}, equal=${value === 4}`);

// Second test case
console.log('\n=== Testing callbacks can be added and removed ===');
const [input2, setInput2] = createInput(11);
const output2 = createComputed(() => input2() + 1);

const values1 = [];
const unsubscribe1 = createCallback(() => {
  values1.push(output2());
  console.log(`Callback1 triggered: values1 now ${JSON.stringify(values1)}`);
});

const values2 = [];
createCallback(() => {
  values2.push(output2());
  console.log(`Callback2 triggered: values2 now ${JSON.stringify(values2)}`);
});

console.log(`Before setInput2(31): input2=${input2()}, output2=${output2()}`);
setInput2(31);
console.log(`After setInput2(31): input2=${input2()}, output2=${output2()}`);

console.log('Calling unsubscribe1...');
unsubscribe1();
console.log('unsubscribe1 called');

console.log(`Before setInput2(41): input2=${input2()}, output2=${output2()}`);
setInput2(41);
console.log(`After setInput2(41): input2=${input2()}, output2=${output2()}`);

console.log(`values1=${JSON.stringify(values1)}, length=${values1.length}`);
console.log(`values2=${JSON.stringify(values2)}, length=${values2.length}`);
console.log(`values2.length > values1.length? ${values2.length > values1.length}`);