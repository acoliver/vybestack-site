// Simple test to debug the callback issue
import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Testing callback mechanism:")

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log("Initial input:", input())
console.log("Initial output:", output())

let value = 0
createCallback(() => {
  console.log("Callback called, input:", input(), "output:", output())
  value = output()
})

console.log("After creating callback, value:", value)

setInput(3)
console.log("After setInput(3), value:", value)
console.log("Expected: 4, Got:", value)