/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  EqualFn,
  ObserverR,
  getActiveObserver,
  setActiveObserver,
  subscribe
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  let isInitialized = false
  
  // Create a subject that represents this computed value
  const subject = {
    name: options?.name,
    subscribers: new Set<ObserverR>(),
    value: undefined as T | undefined,
    equalFn: undefined
  }
  
  const computeValue = () => {
    // Set this computed as active to track dependencies
    const previousObserver = getActiveObserver()
    try {
      // Calculate new value
      const newValue = updateFn(computedValue)
      computedValue = newValue
      subject.value = newValue
      return newValue
    } finally {
      // Restore previous observer
      if (previousObserver) {
        setActiveObserver(previousObserver)
      }
    }
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a subscriber to any active observer
      // This allows dependency tracking
      subscribe(subject, observer)
    }
    
    if (!isInitialized) {
      // First time - compute the value
      computeValue()
      isInitialized = true
    } else {
      // Re-compute value on every access to ensure it's up to date
      computeValue()
    }
    return computedValue!
  }
  
  return getter
}
