/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let isDisposed = false
  let callbackValue = value
  
  const observer: Observer<T> = {
    value: callbackValue,
    updateFn: () => {
      if (isDisposed) return callbackValue!
      
      // Execute the callback function to perform side effects
      callbackValue = updateFn(callbackValue)
      return callbackValue!
    }
  }
  
  // Set this callback as the active observer to track dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute the callback to set up dependencies and run once
    updateObserver(observer)
  } finally {
    // Restore previous observer
    setActiveObserver(previousObserver)
  }
  
  return () => {
    if (isDisposed) return
    isDisposed = true
    
    // Clean up the observer
    observer.value = undefined
    observer.updateFn = () => undefined as T
  }
}
