import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3000', 10);
    this.dbPath = path.resolve('data', 'submissions.sqlite');
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '../public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const SQL = await initSqlJs();
      
      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(fileBuffer);
      } else {
        this.db = new SQL.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    this.db.run(schema);
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field]?.trim();
      if (!value || value.length === 0) {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email && data.email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation - international format
    if (data.phone && data.phone.trim()) {
      const phoneRegex = /^[+]?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({
          field: 'phone',
          message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +'
        });
      }
    }

    // Postal code validation - alphanumeric
    if (data.postalCode && data.postalCode.trim()) {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({
          field: 'postalCode',
          message: 'Postal code can only contain letters, numbers, spaces, and dashes'
        });
      }
    }

    return errors;
  }

  private getFieldDisplayName(field: string): string {
    const displayNames: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return displayNames[field] || field;
  }

  private setupRoutes(): void {
    // GET / - render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        return res.render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
      }

      // Insert into database
      try {
        if (!this.db) throw new Error('Database not initialized');
        
        const stmt = this.db.prepare(`
          INSERT INTO submissions 
          (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          formData.firstName.trim(),
          formData.lastName.trim(),
          formData.streetAddress.trim(),
          formData.city.trim(),
          formData.stateProvince.trim(),
          formData.postalCode.trim(),
          formData.country.trim(),
          formData.email.trim(),
          formData.phone.trim()
        ]);
        
        stmt.free();
        await this.saveDatabase();

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Failed to save submission:', error);
        res.render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    // GET /thank-you - render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // Get the latest submission to extract the first name
      let firstName = 'friend';
      try {
        if (this.db) {
          const result = this.db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
          if (result[0] && result[0].values[0]) {
            firstName = result[0].values[0][0] as string;
          }
        }
      } catch (error) {
        console.error('Failed to get latest submission:', error);
      }

      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    this.setupRoutes();

    return new Promise((resolve) => {
      this.server = this.app.listen(this.port, () => {
        console.log(`Server running on port ${this.port}`);
        resolve();
      });
    });
  }

  // Expose the Express app for testing
  public getApp(): express.Application {
    return this.app;
  }

  public async stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          console.log('Server closed');
          if (this.db) {
            this.db.close();
            this.db = null;
          }
          resolve();
        });
      } else {
        if (this.db) {
          this.db.close();
          this.db = null;
        }
        resolve();
      }
    });
  }

  private server: import('http').Server | null = null;
}

// Export the server class for use in tests and when running directly
export { FormServer };

// Only start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const formServer = new FormServer();

  // Handle graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully');
    await formServer.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully');
    await formServer.stop();
    process.exit(0);
  });

  // Start the server
  formServer.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}