import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { FormServer } from '../../src/server';

let server: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server for testing
  server = new FormServer();
  await server.start();
  
  // Get the Express app for testing
  app = server.getApp();
});

afterAll(async () => {
  // Clean up database and stop server
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  if (server) {
    await server.stop();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check that all required form fields exist
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check that labels are properly associated
    expect($('label[for="firstName"]').text()).toContain('First name');
    expect($('label[for="email"]').text()).toContain('Email');
  });

  it('persists submission and redirects', async () => {
    // Ensure database doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Submit valid form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify thank-you page works and contains the first name
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain('John');
    expect($('body').text()).toContain('Thank you');
    expect($('a').attr('href')).toBe('/');
  });

  it('validates required fields', async () => {
    // Submit empty form
    const response = await request(app)
      .post('/submit')
      .send({})
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Should show error messages
    expect($('.error-list').length).toBeGreaterThan(0);
    expect($('body').text()).toContain('is required');
    
    // Should not redirect
    expect(response.headers.location).toBeUndefined();
  });

  it('validates email format', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'invalid-email',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(200);
    
    const $ = cheerio.load(response.text);
    expect($('body').text()).toContain('valid email address');
  });

  it('accepts international postal codes and phone numbers', async () => {
    // Ensure database doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1000',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'B1675', // Argentine postal code
      country: 'Argentina',
      email: 'maria@example.com',
      phone: '+54 9 11 1234-5678' // Argentine phone format
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect successfully
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});