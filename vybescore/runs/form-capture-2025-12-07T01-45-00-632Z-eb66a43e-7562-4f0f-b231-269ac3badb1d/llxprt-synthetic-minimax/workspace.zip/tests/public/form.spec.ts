import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load as cheerioLoad } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';

const dbPath = path.resolve('data', 'submissions.sqlite');

// Import the built server
let app: Express;

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import the server (after building)
  const serverModule = await import('../../dist/server.js');
  app = serverModule.app;
});

afterAll(() => {
  if (app) {
    app.locals.closeDatabase?.();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerioLoad(response.text);
    
    // Check for all required form fields
    expect($('input[name="first_name"]').length).toBe(1);
    expect($('input[name="last_name"]').length).toBe(1);
    expect($('input[name="street_address"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="state_province"]').length).toBe(1);
    expect($('input[name="postal_code"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check for form submission
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('form[method="post"]').length).toBe(1);
  });

  it('persists submission and redirects to thank-you page', async () => {
    const submissionData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'CA',
      postal_code: '90210',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302); // Should redirect

    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for missing required fields', async () => {
    const incompleteData = {
      first_name: 'John',
      // Missing other required fields
    };

    const response = await request(app)
      .post('/submit')
      .send(incompleteData)
      .expect(400); // Should return error status

    const $ = cheerioLoad(response.text);
    
    // Should show error messages
    expect($('.error-message').length).toBeGreaterThan(0);
  });

  it('shows validation error for invalid email', async () => {
    const invalidEmailData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'CA',
      postal_code: '90210',
      country: 'United States',
      email: 'not-an-email',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidEmailData)
      .expect(400);

    const $ = cheerioLoad(response.text);
    
    // Should show email validation error
    expect($('.error-message').text()).toContain('email');
  });

  it('accepts international phone numbers', async () => {
    const phoneData = {
      first_name: 'Jane',
      last_name: 'Smith',
      street_address: '456 Oak Ave',
      city: 'London',
      state_province: 'England',
      postal_code: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.co.uk',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(phoneData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts Argentine postal codes', async () => {
    const argentinaData = {
      first_name: 'Carlos',
      last_name: 'Rodriguez',
      street_address: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      state_province: 'CABA',
      postal_code: 'C1000',
      country: 'Argentina',
      email: 'carlos@ejemplo.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .send(argentinaData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });
});