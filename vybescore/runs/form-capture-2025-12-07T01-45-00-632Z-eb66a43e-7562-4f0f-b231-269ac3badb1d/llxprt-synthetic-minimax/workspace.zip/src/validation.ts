export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationErrors {
  [key: string]: string;
}

export class FormValidator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhoneNumber(phone: string): boolean {
    // Accept digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  static validatePostalCode(postalCode: string): boolean {
    // Accept alphanumeric strings (handles UK "SW1A 1AA", Argentine formats like "C1000" or "B1675")
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
  }

  static validateRequired(field: string): boolean {
    return field.trim().length > 0;
  }

  static validateForm(data: FormData): { isValid: boolean; errors: ValidationErrors } {
    const errors: ValidationErrors = {};

    // Validate required fields and map to snake_case keys
    const requiredFields: { camel: keyof FormData; snake: string }[] = [
      { camel: 'firstName', snake: 'first_name' },
      { camel: 'lastName', snake: 'last_name' },
      { camel: 'streetAddress', snake: 'street_address' },
      { camel: 'city', snake: 'city' },
      { camel: 'stateProvinceRegion', snake: 'state_province' },
      { camel: 'postalCode', snake: 'postal_code' },
      { camel: 'country', snake: 'country' },
      { camel: 'email', snake: 'email' },
      { camel: 'phoneNumber', snake: 'phone' }
    ];

    requiredFields.forEach(({ camel, snake }) => {
      const value = data[camel];
      if (!this.validateRequired(value)) {
        errors[snake] = 'This field is required';
      }
    });

    // Validate email
    if (data.email && !this.validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Validate phone number
    if (data.phoneNumber && !this.validatePhoneNumber(data.phoneNumber)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Validate postal code
    if (data.postalCode && !this.validatePostalCode(data.postalCode)) {
      errors.postal_code = 'Please enter a valid postal code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }
}