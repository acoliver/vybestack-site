import express, { Request, Response } from 'express';
import path from 'path';
import { dbManager } from './database.js';
import { FormValidator, FormData } from './validation.js';

export const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// Store database manager on app for testing access
app.locals.dbManager = dbManager;
app.locals.closeDatabase = async () => {
  await dbManager.close();
};

// GET / - Display the form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: {}, 
    errors: {},
    pageTitle: 'Contact Form'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.first_name || '',
      lastName: req.body.last_name || '',
      streetAddress: req.body.street_address || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.state_province || '',
      postalCode: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phone || ''
    };

    const validation = FormValidator.validateForm(formData);

    if (!validation.isValid) {
      // Re-render form with errors and previous values
      // Convert camelCase to snake_case for form field names
      const snakeCaseData = {
        first_name: formData.firstName,
        last_name: formData.lastName,
        street_address: formData.streetAddress,
        city: formData.city,
        state_province: formData.stateProvinceRegion,
        postal_code: formData.postalCode,
        country: formData.country,
        email: formData.email,
        phone: formData.phoneNumber
      };
      
      return res.status(400).render('form', {
        data: snakeCaseData,
        errors: validation.errors,
        pageTitle: 'Contact Form - Please Correct Errors'
      });
    }

    // Save to database
    await dbManager.saveSubmission(formData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('error', {
      message: 'Sorry, there was an error processing your submission. Please try again.',
      pageTitle: 'Error'
    });
  }
});

// GET /thank-you - Display thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    pageTitle: 'Thank You!'
  });
});

// GET /health - Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((error: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', error);
  res.status(500).render('error', {
    message: 'An unexpected error occurred. Please try again later.',
    pageTitle: 'Error'
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).render('error', {
    message: 'Page not found',
    pageTitle: '404 - Not Found'
  });
});

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await dbManager.initialize();
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the application`);
    });

// Store server reference for graceful shutdown
    (globalThis as typeof globalThis & { server?: import('http').Server }).server = server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();