import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

class DatabaseManager {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any = null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private sqlJs: any = null;

  async initialize(): Promise<void> {
    try {
      if (this.db) {
        console.log('Database already initialized');
        return;
      }

      // Initialize sql.js
      this.sqlJs = await initSqlJs({
        locateFile: () => {
          // This should point to the sql-wasm.wasm file in node_modules
          return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm');
        }
      });

      // Load existing database or create new one
      if (fs.existsSync(DB_FILE_PATH)) {
        const filebuffer = fs.readFileSync(DB_FILE_PATH);
        this.db = new this.sqlJs.Database(filebuffer);
      } else {
        this.db = new this.sqlJs.Database();
        await this.createSchema();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    try {
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf-8');
        this.db.exec(schema);
        console.log('Database schema created successfully');
      } else {
        throw new Error('Schema file not found');
      }
    } catch (error) {
      console.error('Error creating schema:', error);
      throw error;
    }
  }

  async saveSubmission(submission: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvinceRegion: string;
    postalCode: string;
    country: string;
    email: string;
    phoneNumber: string;
  }): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    stmt.free();
    
    // Export and save to file
    await this.exportToFile();
  }

  private async exportToFile(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Ensure data directory exists
      const dataDir = path.dirname(DB_FILE_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const data = this.db.export();
      fs.writeFileSync(DB_FILE_PATH, data);
    } catch (error) {
      console.error('Failed to export database to file:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database closed successfully');
    }
  }
}

export const dbManager = new DatabaseManager();
export type { DatabaseManager };