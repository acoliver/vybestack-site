const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate that a string is valid Base64.
 * Throws an error if the input contains invalid characters.
 */
function validateBase64(input: string): void {
  // Empty string is valid (decodes to empty string)
  if (input.length === 0) {
    return;
  }

  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check that padding is only at the end and properly formatted
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only occur at the end
    const afterPadding = input.slice(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: padding in the middle');
    }
    // Maximum 2 padding characters allowed
    if (afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: invalid padding length');
    }
  }

  // Base64 encoded string length must be a multiple of 4,
  // but we allow unpadded strings which may have length % 4 == 2 or 3
  if (paddingIndex === -1 && input.length % 4 === 1) {
    // Unpadded strings with length % 4 == 1 are invalid
    throw new Error('Invalid Base64 input: incorrect length');
  }
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  validateBase64(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
