// src/validators.ts
// TODO: Implement email validation with support for name+tag@domain.co.uk format
// - Reject double dots, trailing dots, domains with underscores
export function isValidEmail(value: string): boolean {
  // Implement email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(value);
}

// TODO: Implement US phone validation with format support
// - Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
// - Reject area codes starting with 0 or 1
export function isValidUSPhone(value: string, options?: { allowExtension?: boolean }): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +1 (11 digits) or just 10 digits
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    const areaCode = digitsOnly.substring(1, 4);
    return areaCode[0] !== '0' && areaCode[0] !== '1';
  } else if (digitsOnly.length === 10) {
    const areaCode = digitsOnly.substring(0, 3);
    return areaCode[0] !== '0' && areaCode[0] !== '1';
  }
  
  return false;
}

// TODO: Implement Argentine phone validation
// - Optional +54 country code
// - Optional trunk prefix 0 before area code
// - Optional mobile indicator 9 between country/trunk and area code
// - Area code: 2-4 digits (leading digit 1-9)
// - Subscriber number: 6-8 digits total
// - Allow spaces/hyphens as separators
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters temporarily to validate structure
  const digitsOnly = value.replace(/\D/g, '');
  
  // Pattern matching Argentine phone number structure
  const phoneRegex = /^(\+54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  const match = phoneRegex.exec(digitsOnly);
  
  if (!match) return false;
  
  const [, hasCountryCode, hasTrunkPrefix, hasMobileIndicator, areaCode, subscriber] = match;
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // If has mobile indicator, must have either country code or trunk prefix
  if (hasMobileIndicator && !hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

// TODO: Implement name validation with Unicode support
// - Allow unicode letters, accents, apostrophes, hyphens, spaces
// - Reject digits, symbols, and "X Æ A-12" style names
export function isValidName(value: string): boolean {
  // Allow letters (including Unicode), spaces, hyphens, apostrophes
  // Reject if contains digits or other symbols
  const nameRegex = /^[\p{L}\s'\-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must have at least one letter
  return /\p{L}/u.test(value);
}

// TODO: Implement credit card validation with Luhn checksum
// - Support Visa/Mastercard/AmEx prefixes and lengths
// - Run Luhn checksum algorithm
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check card type and length
  const visaRegex = /^4\d{12}(\d{3})?$/; // 16 or 19 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  let isValidType = visaRegex.test(digitsOnly) || 
                   mastercardRegex.test(digitsOnly) || 
                   amexRegex.test(digitsOnly);
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

// Helper function for Luhn checksum
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}