// src/puzzles.ts

// TODO: Find words beginning with the prefix but excluding the listed exceptions
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // but excluding the exception words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(exc => 
    exc.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  );
  
  const exceptionPattern = escapedExceptions.length > 0 
    ? `(?!${escapedExceptions.join('|')})`
    : '';
  
  const regex = new RegExp(`\\b${escapedPrefix}${exceptionPattern}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exact matches of exception words
  return matches.filter(match => 
    !exceptions.some(exc => match.toLowerCase() === exc.toLowerCase())
  );
}

// TODO: Return occurrences where the token appears after a digit and not at the start of the string
// Use lookaheads/lookbehinds
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to ensure there's a digit before the token
  // and the token is not at the start of the string
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'gi');
  
  return text.match(regex) || [];
}

// TODO: Validate strong password requirements
// - At least 10 characters
// - One uppercase, one lowercase, one digit, one symbol
// - No whitespace
// - No immediate repeated sequences (e.g., abab should fail)
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, cdcd, etc.)
  // This regex looks for patterns that repeat immediately
  const repeatedPattern = /(..+)\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

// TODO: Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // 1. Standard IPv6: 8 groups of 4 hex digits separated by colons
  // 2. IPv6 with :: shorthand for consecutive zeros
  // 3. Mixed IPv6/IPv4 representation (not required but common)
  
  // Remove brackets if present (IPv6 in URLs like [::1])
  const cleanValue = value.replace(/[\[\]]/g, '');
  
  // Full IPv6: 8 groups of 1-4 hex digits
  const fullIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: shorthand (this is complex due to various positions)
  const ipv6WithShorthand = new RegExp(
    // Start with some groups, then ::
    `^(?:[0-9a-fA-F]{1,4}:){0,6}::` + 
    // OR :: followed by some groups
    `(?:[0-9a-fA-F]{1,4}:){0,6}$` +
    // This is a simplified version that handles most common cases
    `|^(?:[0-9a-fA-F]{1,4}:)+::(?:[0-9a-fA-F]{1,4}:)+[0-9a-fA-F]{0,4}$`,
    'i'
  );
  
  // More comprehensive IPv6 regex that handles :: shorthand in various positions
  const ipv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4})?(?:::[0-9a-fA-F]{1,4})*(?::[0-9a-fA-F]{1,4})*$/;
  
  // Test against various IPv6 formats
  if (fullIPv6.test(cleanValue) || ipv6Regex.test(cleanValue)) {
    return true;
  }
  
  // Also check for IPv6 addresses in text (not at start/end)
  const ipv6InText = /(?:^|[^0-9a-fA-F:])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:$|[^0-9a-fA-F:])/;
  const ipv6ShorthandInText = /(?:^|[^0-9a-fA-F:])(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4})?(?:::[0-9a-fA-F]{1,4})*(?::[0-9a-fA-F]{1,4})*(?:$|[^0-9a-fA-F:])/;
  
  return ipv6InText.test(cleanValue) || ipv6ShorthandInText.test(cleanValue);
}