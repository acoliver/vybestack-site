// src/transformations.ts

// TODO: Capitalize the first character of each sentence (after .?!)
// - Insert exactly one space between sentences
// - Collapse extra spaces while leaving abbreviations intact when possible
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split into sentences by looking for .?! followed by whitespace or end of string
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  const capitalizedSentences = sentences.map((sentence, index) => {
    if (!sentence.trim()) return sentence;
    
    // For the first sentence, just capitalize the first letter
    // For subsequent sentences, capitalize the first letter after whitespace
    return sentence.replace(/^(\s*)([a-zA-Z])/, (match, whitespace, letter) => {
      return whitespace + letter.toUpperCase();
    });
  });
  
  // Join sentences with exactly one space
  return capitalizedSentences.join(' ');
}

// TODO: Return all URLs detected in the text without trailing punctuation
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s.,;:!?)\]\}>"']+/gi;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    // Remove any trailing punctuation
    return url.replace(/[.,;:!?)\]\}>"']+$/, '');
  });
}

// TODO: Replace http:// schemes with https:// while leaving existing secure URLs untouched
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't affect https://
  return text.replace(/http:\/\//g, 'https://');
}

// TODO: For URLs http://example.com/...
// - Always upgrade scheme to https://
// - When path begins with /docs/, rewrite host to docs.example.com
// - Skip host rewrite when path contains dynamic hints or legacy extensions
export function rewriteDocsUrls(text: string): string {
  const urlRegex = /http:\/\/([^\/\s]+)(\/docs\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, host, path) => {
    // Check for dynamic hints or legacy extensions in the path
    const dynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    if (dynamicHints.test(path)) {
      // Just upgrade to https without changing host
      return `https://${host}${path}`;
    } else {
      // Upgrade to https and rewrite host to docs.hostname
      const newHost = `docs.${host}`;
      return `https://${newHost}${path}`;
    }
  });
}

// TODO: Return the four-digit year for mm/dd/yyyy format
// - If format doesn't match or month/day are invalid, return N/A
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr);
  const day = parseInt(dayStr);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) return 'N/A';
  
  // Return the year
  return year;
}