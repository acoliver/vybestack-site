/**
 * Regular expression to validate Base64 strings.
 * - Allows standard Base64 characters: A-Z, a-z, 0-9, +, /
 * - Allows optional padding (one or two = at the end)
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Check if a string is a valid Base64 string.
 * - Only contains valid Base64 characters
 * - Padding is only at the end and valid (0, 1, or 2 = characters)
 * - Must have at least 2 characters (representing at least 1 byte)
 */
function isValidBase64(input: string): boolean {
  // Check for valid characters and padding placement
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }

  // Check that padding is only 0, 1, or 2 characters
  const paddingMatch = input.match(/=+$/);
  const hasValidPadding = !paddingMatch || paddingMatch[0].length <= 2;

  // Additional validation: check for invalid character sequences
  // that would cause decoding to fail or produce unexpected results
  const withoutPadding = input.replace(/=+$/, '');
  const hasMinimumLength = withoutPadding.length >= 2;

  return hasValidPadding && hasMinimumLength;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding (=) characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the Base64 input before attempting to decode
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
