#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions, Format } from '../types.js';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';

function parseArguments(): { filePath: string; format: Format; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const formatValue = args[formatIndex + 1] as Format;
  const outputPathIndex = args.indexOf('--output');
  const outputPath = outputPathIndex !== -1 && outputPathIndex + 1 < args.length ? args[outputPathIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    console.error(`Error: Unsupported format "${formatValue}". Supported formats: markdown, text`);
    process.exit(1);
  }
  
  return {
    filePath,
    format: formatValue,
    outputPath,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1} has missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1} has missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}"`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const { filePath, format, outputPath, includeTotals } = parseArguments();
  const data = loadReportData(filePath);
  const options: ReportOptions = { includeTotals };
  
  const renderer = format === 'markdown' 
    ? new MarkdownRenderer() 
    : new TextRenderer();
  
  const output = renderer.render(data, options);
  
  if (outputPath) {
    try {
      writeFileSync(outputPath, output, 'utf-8');
      console.log(`Report generated: ${outputPath}`);
    } catch (error) {
      console.error(`Error writing to file "${outputPath}": ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
