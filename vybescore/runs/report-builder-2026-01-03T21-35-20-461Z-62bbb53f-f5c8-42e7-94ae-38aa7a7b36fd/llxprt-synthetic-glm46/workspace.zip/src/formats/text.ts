import { ReportData, ReportOptions, ReportRenderer } from '../types.js';

export class TextRenderer implements ReportRenderer {
  render(data: ReportData, options: ReportOptions): string {
    let output = `${data.title}\n`;
    output += `${data.summary}\n`;
    output += `Entries:\n`;
    
    for (const entry of data.entries) {
      output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
    }
    
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `Total: $${total.toFixed(2)}`;
    }
    
    return output;
  }
}