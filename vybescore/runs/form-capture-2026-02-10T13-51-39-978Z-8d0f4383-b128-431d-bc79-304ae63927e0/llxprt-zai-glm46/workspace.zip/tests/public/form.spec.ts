import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
// @ts-expect-error - cheerio types may not be properly imported
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from '../../src/server';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let app: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await createServer();
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields with proper labels
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('label[for="firstName"]').text().toLowerCase()).toContain('first');
    
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('label[for="lastName"]').text().toLowerCase()).toContain('last');
    
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('label[for="streetAddress"]').text().toLowerCase()).toContain('street');
    
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('label[for="city"]').text().toLowerCase()).toContain('city');
    
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('label[for="stateProvince"]').text().toLowerCase()).toContain('state');
    
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('label[for="postalCode"]').text().toLowerCase()).toContain('postal');
    
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('label[for="country"]').text().toLowerCase()).toContain('country');
    
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('label[for="email"]').text().toLowerCase()).toContain('email');
    
    expect($('input[name="phone"]')).toHaveLength(1);
    expect($('label[for="phone"]').text().toLowerCase()).toContain('phone');
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: 'invalid-email',
        phone: '',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check for error messages
    expect($('.error-list').length).toBeGreaterThan(0);
    expect($('.error-list').text()).toMatch(/required/i);
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'not-an-email',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toMatch(/email/i);
  });

  it('validates international phone formats', async () => {
    // Test with invalid phone characters
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'john@example.com',
        phone: 'phone-with-letters',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toMatch(/phone/i);
  });

  it('accepts UK postal code format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts Argentine postal code format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'García',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('persists submission and redirects', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test Ave',
        city: 'Sydney',
        stateProvince: 'NSW',
        postalCode: '2000',
        country: 'Australia',
        email: 'test@example.com',
        phone: '+61 2 9876 5432',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank you page', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for humorous text about spam/identity theft
    const pageText = $('.thankyou-card').text().toLowerCase();
    expect(pageText).toMatch(/stranger|internet|spam|data|emails/);
    
    // Check for link back to form
    expect($('a[href="/"]')).toHaveLength(1);
  });
});
