import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(projectRoot, 'public')));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(projectRoot, 'src', 'views'));

// Database
let db: Database | null = null;
const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
const schemaPath = path.join(projectRoot, 'db', 'schema.sql');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const buffer = fs.readFileSync(dbPath);
      db = new SQL.Database(buffer);
    } else {
      db = new SQL.Database();
      // Run schema
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf-8');
        db.run(schema);
        saveDatabase();
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function isNotEmpty(value: string): boolean {
  return value.trim().length > 0;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[\d\s()+-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric with spaces (UK, Argentine, US formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!isNotEmpty(formData.firstName)) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!isNotEmpty(formData.lastName)) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!isNotEmpty(formData.streetAddress)) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!isNotEmpty(formData.city)) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!isNotEmpty(formData.stateProvince)) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!isNotEmpty(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!isValidPostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code contains invalid characters' });
  }

  if (!isNotEmpty(formData.country)) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!isNotEmpty(formData.email)) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!isValidEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!isNotEmpty(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!isValidPhone(formData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and +',
    });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: [],
    formData: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Render form with errors
    res.status(400).render('index', {
      errors,
      formData,
    });
    return;
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();

    // Save database to disk
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    res.status(500).render('index', {
      errors: [{ field: 'general', message: 'Failed to save submission. Please try again.' }],
      formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Start server
async function startServer() {
  await initializeDatabase();
  const server = app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });
  
  // Setup graceful shutdown
  const shutdown = (signal: string) => {
    console.log(`\nReceived ${signal}, closing server gracefully...`);
    server.close(() => {
      console.log('Server closed.');
      
      // Close database
      if (db) {
        db.close();
        db = null;
      }
      
      process.exit(0);
    });

    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  
  return server;
}

// Export for testing
export async function createServer() {
  await initializeDatabase();
  return app;
}

// Start the server if this is the main module (not when imported for testing)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
