/* eslint-disable @typescript-eslint/no-explicit-any */
declare module 'sql.js' {
  export interface SqlValue {
    [key: string]: unknown;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
    getRowsModified(): number;
  }

  export interface Statement {
    run(params?: unknown[]): StatementResultSet;
    step(): boolean;
    get(): unknown[] | null;
    getAsObject(params?: unknown[]): Record<string, unknown>;
    getColumns(): ColumnDefinition[];
    bind(params?: unknown[]): void;
    free(): void;
  }

  export interface StatementResultSet {
    changes: number;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface ColumnDefinition {
    name: string;
    type: string;
  }

  export interface SqlJsConfig {
    locateFile?: (filename: string) => string;
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export default function initSqlJs(config?: SqlJsConfig): Promise<SqlJsStatic>;
}
