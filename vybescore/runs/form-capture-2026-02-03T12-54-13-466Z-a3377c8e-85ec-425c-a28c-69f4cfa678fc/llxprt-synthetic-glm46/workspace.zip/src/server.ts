import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database configuration
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
let db: Database | null = null;

// Initialize database
async function initializeDatabase() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    let fileBuffer;
    if (fs.existsSync(dbPath)) {
      fileBuffer = fs.readFileSync(dbPath);
    }
    
    const SQL = await initSqlJs();
    db = new SQL.Database(fileBuffer);
    
    // Create table schema if not exists
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.exec(schema);
    
    console.log('Database initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Function to save database to disk
function saveDatabase() {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+\s\d\-()]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(code: string): boolean {
  const postalRegex = /^[a-zA-Z0-9\s-]*$/;
  return postalRegex.test(code);
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body as Record<string, string>;
  
  const errors: string[] = [];
  
  // Validation
  if (!firstName || firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!lastName || lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!streetAddress || streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!city || city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!stateProvince || stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }
  
  if (!postalCode || postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  } else if (!validatePostalCode(postalCode)) {
    errors.push('Postal code must contain only alphanumeric characters, spaces, and dashes');
  }
  
  if (!country || country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!email || email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (!phone || phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: {
        firstName,
        lastName,
        streetAddress,
        city,
        stateProvince,
        postalCode,
        country,
        email,
        phone
      }
    });
  }
  
  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    return res.status(500).render('form', {
      errors,
      values: {
        firstName,
        lastName,
        streetAddress,
        city,
        stateProvince,
        postalCode,
        country,
        email,
        phone
      }
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'friend' });
});

// Graceful shutdown
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

function shutdown() {
  console.log('Shutting down server...');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

// Start server
async function startServer() {
  await initializeDatabase();
  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
