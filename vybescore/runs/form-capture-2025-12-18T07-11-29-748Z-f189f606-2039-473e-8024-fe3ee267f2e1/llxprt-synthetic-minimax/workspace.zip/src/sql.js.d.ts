declare module 'sql.js' {
  export interface Database {
    run(sql: string): void;
    prepare(sql: string): Statement;
    exec(sql: string): Result[];
    close(): void;
    export(): Uint8Array;
  }

  export interface Statement {
    bind(params: unknown[]): void;
    step(): boolean;
    getColumnNames(): string[];
    get(params?: unknown[]): unknown[];
    free(): void;
    run(params: unknown[]): void;
  }

  export interface Result {
    columns: string[];
    values: unknown[][];
  }

  export interface SqlJsStatic {
    Database: new (buffer?: Uint8Array) => Database;
  }

  export default function initSqlJs(config?: {
    locateFile?: (file: string) => string;
  }): Promise<SqlJsStatic>;
}