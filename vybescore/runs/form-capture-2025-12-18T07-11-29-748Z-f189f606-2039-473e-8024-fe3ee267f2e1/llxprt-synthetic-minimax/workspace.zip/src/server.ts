import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { dbManager } from './database.js';
import { validateForm, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Static files
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Body parsing middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Make form data available to all templates
app.use((req: Request, res: Response, next: NextFunction) => {
  res.locals.formData = req.body || {};
  res.locals.errors = {};
  next();
});

// GET / - Show contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Us',
    errors: {},
    formData: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);

    if (!validation.isValid) {
      // Re-render form with errors
      return res.status(400).render('form', {
        title: 'Contact Us',
        errors: validation.errors,
        formData
      });
    }

    // Insert into database
    await dbManager.insertSubmission(formData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      title: 'Contact Us',
      errors: { general: 'An error occurred. Please try again.' },
      formData: req.body || {}
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).send('Page not found');
});

// Error handler
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully');
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();