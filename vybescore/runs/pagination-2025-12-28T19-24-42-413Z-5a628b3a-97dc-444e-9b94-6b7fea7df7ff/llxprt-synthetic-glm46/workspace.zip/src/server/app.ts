import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function validateQueryParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } | { error: string; status: 400 } {
  // Parse and validate page
  let page = DEFAULT_PAGE;
  if (pageParam !== undefined) {
    if (pageParam === '') {
      return { error: 'Page parameter cannot be empty', status: 400 };
    }
    
    if (!/^\d+$/.test(pageParam)) {
      return { error: 'Page parameter must be a positive integer', status: 400 };
    }
    
    const parsedPage = Number(pageParam);
    if (isNaN(parsedPage) || parsedPage <= 0) {
      return { error: 'Page parameter must be a positive integer', status: 400 };
    }
    
    page = parsedPage;
  }

  // Parse and validate limit
  let limit = DEFAULT_LIMIT;
  if (limitParam !== undefined) {
    if (limitParam === '') {
      return { error: 'Limit parameter cannot be empty', status: 400 };
    }
    
    if (!/^\d+$/.test(limitParam)) {
      return { error: 'Limit parameter must be a positive integer', status: 400 };
    }
    
    const parsedLimit = Number(limitParam);
    if (isNaN(parsedLimit) || parsedLimit <= 0) {
      return { error: 'Limit parameter must be a positive integer', status: 400 };
    }
    
    if (parsedLimit > MAX_LIMIT) {
      return { error: `Limit parameter cannot exceed ${MAX_LIMIT}`, status: 400 };
    }
    
    limit = parsedLimit;
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validateQueryParams(pageParam, limitParam);
    if ('error' in validation) {
      return res.status(validation.status).json({ error: validation.error });
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
