import type { CliOptions, ReportData } from './types.js';

export function parseCliArguments(): CliOptions {
  const args = process.argv.slice(2);
  const options: CliOptions = {
    format: 'markdown',
  };

  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let dataFileProvided = false;

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i + 1] as 'markdown' | 'text';
      if (format !== 'markdown' && format !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      options.format = format;
      i++;
    } else if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
    } else if (!args[i].startsWith('--') && !dataFileProvided) {
      dataFileProvided = true;
    } else if (args[i].startsWith('--')) {
      console.error(`Error: Unknown option ${args[i]}`);
      process.exit(1);
    }
  }

  if (!dataFileProvided) {
    console.error('Error: Data file path must be provided');
    process.exit(1);
  }

  return options;
}

export function getDataFilePath(): string {
  const args = process.argv.slice(2);
  for (const arg of args) {
    if (!arg.startsWith('--')) {
      return arg;
    }
  }
  console.error('Error: Data file path must be provided');
  process.exit(1);
}

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: expected object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }

  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: each entry must be an object');
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: each entry must have a string label');
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: each entry must have a number amount');
    }
  }

  return data as ReportData;
}