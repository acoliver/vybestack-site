import type { FormatRenderer } from '../types.js';

export const renderText: FormatRenderer = (data, includeTotals = false) => {
  const { title, summary, entries } = data;
  
  let output = `${title}\n${summary}\nEntries:\n`;
  
  for (const entry of entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `Total: $${total.toFixed(2)}`;
  }
  
  return output;
};