import type { FormatRenderer } from '../types.js';

export const renderMarkdown: FormatRenderer = (data, includeTotals = false) => {
  const { title, summary, entries } = data;
  
  let output = `# ${title}\n\n${summary}\n\n## Entries\n`;
  
  for (const entry of entries) {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }
  
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** $${total.toFixed(2)}`;
  }
  
  return output;
};