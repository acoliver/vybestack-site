#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { parseCliArguments, getDataFilePath, validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function main(): void {
  try {
    const options = parseCliArguments();
    const dataFilePath = getDataFilePath();
    
    const rawData = readFileSync(dataFilePath, 'utf-8');
    let jsonData: unknown;
    
    try {
      jsonData = JSON.parse(rawData);
    } catch (error) {
      console.error(`Error parsing JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
    
    const reportData = validateReportData(jsonData);
    
    let output: string;
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options.includeTotals);
        break;
      case 'text':
        output = renderText(reportData, options.includeTotals);
        break;
      default:
        console.error('Error: Unsupported format');
        process.exit(1);
    }
    
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
