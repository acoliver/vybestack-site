import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Express } from 'express';
import type { Database } from 'sql.js';

describe('inventory API (pagination tests)', () => {
  let db: Database;
  let app: Express;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns default pagination with page 1 and limit 5', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    
    // Verify items are ordered correctly
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[4].id).toBe(5);
  });

  it('returns page 2 with correct items', async () => {
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    
    // Verify items are the next 5 items
    expect(response.body.items[0].id).toBe(6);
    expect(response.body.items[4].id).toBe(10);
  });

  it('returns last page (page 3) with remaining items', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
    
    // Verify items are the last 5 items
    expect(response.body.items[0].id).toBe(11);
    expect(response.body.items[4].id).toBe(15);
  });

  it('returns empty page when page exceeds available data', async () => {
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.page).toBe(10);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });

  it('validates invalid page parameter (non-numeric)', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates invalid page parameter (negative)', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates invalid page parameter (zero)', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates invalid limit parameter (non-numeric)', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('validates invalid limit parameter (negative)', async () => {
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('validates invalid limit parameter (zero)', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('validates excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=1000');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
    expect(response.body.error).toContain('not exceeding 100');
  });

  it('handles custom valid limit parameter', async () => {
    const response = await request(app).get('/inventory?page=1&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(3);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    
    // Verify first 3 items
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[2].id).toBe(3);
  });
});
