export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern breakdown:
  // - Local part: letters, numbers, and certain special chars including + for tags
  // - No double dots or trailing dots
  // - Domain: letters, numbers, hyphens (not starting/ending with hyphen)
  // - TLD: at least 2 letters
  // Support: name+tag@example.co.uk
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9!#$%&'*+/=?^_`{|}-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9!#$%&'*+/=?^_`{|}-]*[a-zA-Z0-9])?)*@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Must not have double dots
  if (value.includes('..')) return false;
  
  // Must not end with a dot
  if (value.endsWith('.')) return false;
  
  // Domain must not contain underscores
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  if (parts[1].includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  
  // Check for extension if allowExtensions is true
  let mainNumber = cleaned;
  if (options?.allowExtensions && /\b(ext|x)\s*\d+/i.test(cleaned)) {
    mainNumber = cleaned.replace(/\b(ext|x)\s*\d+/i, '');
  }
  
  // Remove all non-digit characters except leading +
  const digits = mainNumber.replace(/[^\d+]/g, '');
  
  // Optional +1 prefix
  const phoneRegex = /^\+?1?([2-9]\d{2}[2-9]\d{2}\d{4})$/;
  
  // Must have 11 digits (with +1) or 10 digits (without)
  const digitCount = digits.replace(/\D/g, '').length;
  if (digitCount !== 10 && digitCount !== 11) return false;
  
  // If 11 digits, must start with 1
  if (digitCount === 11 && !digits.startsWith('1') && !digits.startsWith('+1')) return false;
  
  // Extract the actual phone number for area code validation
  const phoneNumber = digitCount === 11 && digits.startsWith('+') ? digits.slice(2) :
                      digitCount === 11 && digits.startsWith('1') ? digits.slice(1) :
                      digits;
  
  // Area code (first 3 digits) must be 2-9 (no 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  const firstDigit = areaCode.charAt(0);
  if (firstDigit === '0' || firstDigit === '1') return false;
  
  return phoneRegex.test(phoneNumber);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space, non-hyphen characters for parsing
  const cleaned = value.trim();
  
  // Extract pure digits
  const digits = cleaned.replace(/[^\d]/g, '');
  
  // Pattern analysis:
  // Optional +54
  // Optional 9 for mobile
  // Optional 0 for trunk
  // Area code: 2-4 digits (first digit 1-9)
  // Subscriber: 6-8 digits total
  
  // Case 1: With country code +54
  if (cleaned.startsWith('+54')) {
    // +54 9 11 1234 5678 (mobile with 9)
    // +54 11 1234 5678 (landline without 9)
    // +54 341 123 4567 (area code 341)
    
    const afterCountry = cleaned.slice(4).trim();
    const afterDigits = afterCountry.replace(/[^\d]/g, '');
    
    // Check for mobile indicator (9)
    if (afterDigits.startsWith('9')) {
      // Mobile: +54 9 XX XXXXXXXX (area code + subscriber)
      const remaining = afterDigits.slice(1);
      
      // Area code: 2-4 digits, first digit 1-9
      // Subscriber: remaining digits, total 6-8 digits
      if (remaining.length < 8 || remaining.length > 12) return false;
      
      // Extract area code (first 2-4 digits)
      for (let len = 2; len <= 4; len++) {
        if (remaining.length - len >= 6 && remaining.length - len <= 8) {
          const areaCode = remaining.substring(0, len);
          const subscriber = remaining.substring(len);
          
          // Validate area code
          if (areaCode.length >= 2 && areaCode.length <= 4) {
            const firstDigit = areaCode.charAt(0);
            if (firstDigit >= '1' && firstDigit <= '9' && /^\d+$/.test(areaCode)) {
              // Validate subscriber number
              if (subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber)) {
                return true;
              }
            }
          }
        }
      }
    } else {
      // Landline: +54 XX XXXXXXXX
      if (remaining.length >= 8 && remaining.length <= 12) {
        // Extract area code (first 2-4 digits)
        for (let len = 2; len <= 4; len++) {
          if (remaining.length - len >= 6 && remaining.length - len <= 8) {
            const areaCode = remaining.substring(0, len);
            const subscriber = remaining.substring(len);
            
            // Validate area code
            if (areaCode.length >= 2 && areaCode.length <= 4) {
              const firstDigit = areaCode.charAt(0);
              if (firstDigit >= '1' && firstDigit <= '9' && /^\d+$/.test(areaCode)) {
                // Validate subscriber number
                if (subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber)) {
                  return true;
                }
              }
            }
          }
        }
      }
    }
  }
  
  // Case 2: Without country code, must start with trunk prefix 0
  if (!cleaned.startsWith('0')) return false;
  
  const afterTrunk = cleaned.slice(1).trim();
  const afterDigits = afterTrunk.replace(/[^\d]/g, '');
  
  // Check for mobile indicator (9)
  if (afterDigits.startsWith('9')) {
    // Mobile: 0 9 XX XXXXXXXX
    const remaining = afterDigits.slice(1);
    
    if (remaining.length >= 8 && remaining.length <= 12) {
      // Extract area code (first 2-4 digits)
      for (let len = 2; len <= 4; len++) {
        if (remaining.length - len >= 6 && remaining.length - len <= 8) {
          const areaCode = remaining.substring(0, len);
          const subscriber = remaining.substring(len);
          
          // Validate area code
          if (areaCode.length >= 2 && areaCode.length <= 4) {
            const firstDigit = areaCode.charAt(0);
            if (firstDigit >= '1' && firstDigit <= '9' && /^\d+$/.test(areaCode)) {
              // Validate subscriber number
              if (subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber)) {
                return true;
              }
            }
          }
        }
      }
    }
  } else {
    // Landline: 0 XX XXXXXXXX
    if (afterDigits.length >= 8 && afterDigits.length <= 12) {
      // Extract area code (first 2-4 digits)
      for (let len = 2; len <= 4; len++) {
        if (afterDigits.length - len >= 6 && afterDigits.length - len <= 8) {
          const areaCode = afterDigits.substring(0, len);
          const subscriber = afterDigits.substring(len);
          
          // Validate area code
          if (areaCode.length >= 2 && areaCode.length <= 4) {
            const firstDigit = areaCode.charAt(0);
            if (firstDigit >= '1' && firstDigit <= '9' && /^\d+$/.test(areaCode)) {
              // Validate subscriber number
              if (subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber)) {
                return true;
              }
            }
          }
        }
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols except apostrophes and hyphens
  // Reject X Æ A-12 style names
  const nameRegex = /^[\p{L}][\p{L}'\-\s]*[\p{L}]$/u;
  
  // Must start and end with a letter
  if (!nameRegex.test(value.trim())) return false;
  
  // Reject if contains digits
  if (/\d/.test(value)) return false;
  
  // Reject X Æ A-12 style (contains Æ or multiple consecutive capitals with numbers)
  if (value.includes('Æ')) return false;
  
  // Reject if contains obvious sci-fi names
  if (/[0-9]/.test(value) && /[A-Z]{2,}/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) return false;
  
  // Check for common credit card patterns:
  // Visa: starts with 4, length 13-19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  
  let isValidType = false;
  
  // Visa
  if (digits.startsWith('4') && digits.length >= 13 && digits.length <= 19) {
    isValidType = true;
  }
  // Mastercard
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
            digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16) {
    isValidType = true;
  }
  // Mastercard (2221-2720 range)
  else if (digits.length === 16) {
    const firstFour = parseInt(digits.substring(0, 4), 10);
    if (firstFour >= 2221 && firstFour <= 2720) {
      isValidType = true;
    }
  }
  // American Express
  else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}