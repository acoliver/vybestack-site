/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spaces between sentences
  // Look for sentence endings (.!?) followed by any amount of whitespace
  // and replace with the punctuation followed by exactly one space
  let result = text.replace(/([.!?])(?:\s*)/g, '$1 ');
  
  // Now capitalize first letter after sentence endings
  // Use a callback to capitalize the first letter after sentence terminators
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize the first character of the entire text if it's a letter
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Collapse multiple spaces within sentences but preserve single spaces
  result = result.replace(/[ \t]{2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urls: string[] = [];
  
  // Pattern for matching URLs (http/https/ftp)
  const urlRegex = /\bhttps?:\/\/[^\s<>"')\]]+/gi;
  
  const matches = text.match(urlRegex);
  
  if (matches) {
    for (let match of matches) {
      // Remove trailing punctuation
      while (match.length > 0 && /[.,;:!?)]/.test(match[match.length - 1])) {
        match = match.slice(0, -1);
      }
      urls.push(match);
    }
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)?/g, (match, host, path = '') => {
    // Always upgrade to https
    let result = 'https://';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = path.includes('cgi-bin') || 
                             path.includes('?') || 
                             path.includes('&') || 
                             path.includes('=');
      
      const hasLegacyExtension = path.match(/\.(jsp|php|asp|aspx|cgi|pl|py)(\/|$)/);
      
      if (!hasDynamicHints && !hasLegacyExtension) {
        // Rewrite host to docs.host
        result += 'docs.' + host + path;
      } else {
        // Keep original host
        result += host + path;
      }
    } else {
      // Keep original host for non-docs paths
      result += host + path;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) return 'N/A';
  
  // Additional validation for months with fewer days
  const daysInMonth = new Date(parseInt(year, 10), month, 0).getDate();
  if (day > daysInMonth) return 'N/A';
  
  return year;
}