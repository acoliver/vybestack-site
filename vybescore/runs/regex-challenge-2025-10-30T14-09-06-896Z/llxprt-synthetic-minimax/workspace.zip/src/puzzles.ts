/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const results: string[] = [];
  
  if (!text || !prefix || prefix.length === 0) return results;
  
  // Create a regex pattern that matches words starting with the prefix
  // Word boundaries ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern);
  
  if (matches) {
    // Filter out exceptions (case-insensitive)
    for (let match of matches) {
      const isException = exceptions.some(exc => 
        exc.toLowerCase() === match.toLowerCase()
      );
      
      if (!isException) {
        results.push(match);
      }
    }
  }
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  if (!text || !token || token.length === 0) return results;
  
  // Use regex with positive lookbehind to find tokens preceded by a digit
  // and negative lookbehind to ensure not at the start of string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Positive lookbehind: preceded by a digit
  // Negative lookbehind: not at position 0 (start of string)
  const pattern = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'gi');
  
  // Actually, let's use a simpler approach with capturing the full match
  // Find digits followed by the token
  const fullPattern = new RegExp(`(\\d${escapedToken})`, 'gi');
  
  const matches = text.match(fullPattern);
  
  if (matches) {
    for (let match of matches) {
      results.push(match);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for no immediate repeated sequences like "abab"
  // This pattern looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, check if IPv4 is present - if so, immediately return false
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 pattern that includes shorthand notation (::)
  // IPv6 consists of 8 groups of hex digits separated by colons
  // Allow :: shorthand for consecutive zeros
  
  // Full IPv6 (no shorthand): 8 groups of 1-4 hex digits
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand
  // Cases:
  // - :: at the beginning
  // - :: at the end
  // - :: in the middle
  const shorthandIPv6 = new RegExp(
    '\\b(' +
    '(?:[0-9a-fA-F]{1,4}:){0,6}::(?:[0-9a-fA-F]{1,4}:){0,6}' +  // :: anywhere in the middle/end
    '|' +
    '::[0-9a-fA-F]{0,4}' +  // :: at beginning followed by fewer than 8 groups
    '|' +
    '[0-9a-fA-F]{0,4}::(?:[0-9a-fA-F]{1,4}:){0,6}' +  // :: at end
    ')\\b',
    'i'
  );
  
  // More comprehensive IPv6 pattern that handles all cases
  // This is tricky because we need to match valid IPv6 including :: shorthand
  // but exclude IPv4
  const ipv6Pattern = /\b((?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4})(?:::)?((?::[0-9a-fA-F]{1,4}){0,7})?\b/;
  
  // Actually, let's use a more standard approach
  // IPv6 can be:
  // - Full form: 8 groups of 1-4 hex digits
  // - With :: shorthand (representing one or more groups of zeros)
  const ipv6Full = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // With :: (must compress at least one group)
  // Use multiple patterns to handle different shorthand positions
  const patterns = [
    /\b::(?::[0-9a-fA-F]{1,4}){1,7}\b/i,  // Starts with ::
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}::(?::[0-9a-fA-F]{1,4}){0,7}\b/i,  // Ends with ::
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}::\b/i,  // :: in middle (not at start/end)
  ];
  
  if (fullIPv6.test(value)) return true;
  
  for (const pattern of patterns) {
    if (pattern.test(value)) return true;
  }
  
  // Also check for compressed forms more comprehensively
  // Match IPv6 addresses (including various shorthand notations)
  const compressedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*(?::[0-9a-fA-F]{1,4})*(?:::[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4})?\b/;
  
  // But this might match too much, so let's be more careful
  // Check for valid IPv6 by ensuring we have at least some colons and hex digits
  
  // Better approach: Look for patterns that are definitely IPv6
  // - At least 2 colons (needed for ::)
  // - Can have 0-7 full colons for groups
  
  // Final pattern: IPv6 with optional :: shorthand
  const finalIPv6 = /\b(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){0,7}:(?::[0-9a-fA-F]{1,4}){0,7}|(?:[0-9a-fA-F]{1,4}:){1,7}:)\b/i;
  
  return finalIPv6.test(value);
}