const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if input contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  return VALID_BASE64_REGEX.test(input);
}

/**
 * Encode plain text to Base64 using the canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  const cleanInput = input.trim();
  
  if (!isValidBase64(cleanInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Add padding if missing
  const paddedInput = cleanInput.padEnd(Math.ceil(cleanInput.length / 4) * 4, '=');
  
  try {
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Verify the result by round-tripping
    const roundTrip = Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '');
    const originalNoPadding = cleanInput.replace(/=+$/, '');
    
    if (roundTrip !== originalNoPadding) {
      throw new Error('Invalid Base64 input: failed round-trip validation');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
