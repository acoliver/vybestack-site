/**
 * Capitalize the first character of each sentence while handling punctuation and spacing.
 * Handles .?! as sentence terminators, ensures one space between sentences,
 * and collapses extra spaces while preserving common abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Common abbreviations to avoid incorrect sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K'];
  
  // First, normalize spaces: collapse multiple spaces but preserve line breaks
  let result = text.replace(/[ \t]+/g, ' ').replace(/\n[ \t]+/g, '\n');
  
  // Ensure proper spacing after sentence terminators (. ? !)
  // Add a space after sentence terminators if followed by a letter (case insensitive)
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Capitalize the first letter after sentence terminators or at the beginning
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
  
  // Special handling for abbreviations: don't capitalize after them
  abbreviations.forEach(abbr => {
    const regex = new RegExp(`(\\b${abbr}\\.)\\s+([a-z])`, 'g');
    result = result.replace(regex, (match, p1, p2) => {
      return p1 + ' ' + p2.toLowerCase();
    });
  });
  
  return result;
}

/**
 * Extract all URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string' || text.trim() === '') {
    return [];
  }

  // Regex to match URLs (common patterns)
  // Matches protocols (http, https, ftp, etc.), www., and domain patterns
  // Handles TLDs, subdomains, paths, query strings, fragments, etc.
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+|(?:(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})(?:\/[^\s<>"']*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove common trailing punctuation characters
    return url.replace(/[.,;:!?")'\]}]+$/g, '');
  });
}

/**
 * Replace all http:// URL schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs with special rules:
 * - Always upgrade http:// to https://
 * - For URLs with /docs/ path, change host to docs.example.com
 * - Skip host rewrite for URLs with dynamic hints (cgi-bin, query strings, certain extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Regex to match URLs with http:// scheme
  // Captures: (1) protocol, (2) hostname, (3) path
  const httpUrlRegex = /(http:\/\/)([^/]+)(\/.*)?/gi;
  
  // Patterns that should prevent host rewrite
  const excludedPatterns = [
    /\/cgi-bin\//,
    /[?&=]/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?.*)?$/i
  ];

  return text.replace(httpUrlRegex, (match, protocol, hostname, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';
    let newHostname = hostname;
    
    // Default to keeping the hostname
    if (path.startsWith('/docs/')) {
      // Check if path contains excluded patterns
      const shouldExclude = excludedPatterns.some(pattern => pattern.test(path));
      
      if (!shouldExclude) {
        // Change hostname to docs.example.com
        newHostname = 'docs.' + hostname;
      }
    }
    
    return newProtocol + newHostname + path;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') {
    return 'N/A';
  }

  // Regex to capture month, day, and year from mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate that day makes sense for the month (simplified validation)
  // April, June, September, November have 30 days
  if ([4, 6, 9, 11].includes(monthNum) && dayNum > 30) {
    return 'N/A';
  }
  
  // February has 28 or 29 days (simplified, not checking leap years)
  if (monthNum === 2 && dayNum > 29) {
    return 'N/A';
  }
  
  // All other months have 31 days
  if (![4, 6, 9, 11, 2].includes(monthNum) && dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}