export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to common formatting rules.
 * Supports typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Basic email regex with additional checks for double dots, trailing dots, etc.
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for common invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Domain shouldn't contain underscores
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) {
    return false;
  }

  if (domain.includes('_')) {
    return false;
  }

  // Check if domain has valid structure
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts.some(part => part.length === 0)) {
    return false;
  }

  // TLD should not start or end with a hyphen
  const tld = domainParts[domainParts.length - 1];
  if (tld.startsWith('-') || tld.endsWith('-')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Remove all common formatting characters except + for validation
  const cleaned = value.replace(/[^\d+]/g, '');

  // Must start with either +1 or digits only
  if (!cleaned.match(/^(\+1)?\d+$/)) {
    return false;
  }

  // Remove optional country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }

  // Must have exactly 10 digits (area code + 7-digit number)
  if (digits.length !== 10) {
    return false;
  }

  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }

  // Validate overall format using regex
  const phoneRegex = /^(?:(?:\+1\s?)?(?:\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?[2-9]\d{2}[\s.-]?\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Clean the input: remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Argentine phone regex:
  // ^(?:\+54)?  - Optional country code +54
  // 0?          - Optional trunk prefix 0
  // 9?          - Optional mobile indicator 9
  // [1-9]\d{1,3} - Area code: 2-4 digits, starting with 1-9
  // \d{6,8}$    - Subscriber number: 6-8 digits
  
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;

  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }

  // Additional validation rules:
  let digits = cleaned;
  
  // If country code is present, remove it for further validation
  if (digits.startsWith('+54')) {
    digits = digits.substring(3);
  }
  
  // If trunk prefix is present, remove it
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // If mobile indicator is present, remove it
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Now we should have: area code (2-4 digits) + subscriber number (6-8 digits)
  // Total should be between 8 and 12 digits
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }

  // Extract area code (2-4 digits) and subscriber number (6-8 digits)
  // We need to find the split point based on total length
  let areaCodeLength;
  if (digits.length === 8) {
    areaCodeLength = 2;
  } else if (digits.length === 9) {
    areaCodeLength = 3;
  } else if (digits.length === 10) {
    areaCodeLength = 3;
  } else if (digits.length === 11) {
    areaCodeLength = 3;
  } else if (digits.length === 12) {
    areaCodeLength = 4;
  } else {
    return false;
  }

  const areaCode = digits.substring(0, areaCodeLength);
  const subscriberNumber = digits.substring(areaCodeLength);
  
  // Validate area code starts with 1-9 and has valid length
  if (!areaCode.match(/^[1-9]\d{1,3}$/)) {
    return false;
  }
  
  // Validate subscriber number has 6-8 digits
  if (!subscriberNumber.match(/^\d{6,8}$/)) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Check for digits
  if (/\\d/.test(value)) {
    return false;
  }

// Should not contain certain symbols that are typically not in names
  const forbiddenSymbols = /[@#$%^&*()_+=\[\]{}|:;<>,.?~/`]/;
  if (forbiddenSymbols.test(value)) {
    return false;
  }

  return true;
}
function runLuhnCheck(value: string): boolean {
  if (!value || !/^\d+$/.test(value)) {
    return false;
  }

  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value[i], 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  // The number is valid if the sum is a multiple of 10
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers based on known formats and Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and appropriate lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check for valid credit card formats:
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55, 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;  // 13, 16, or 19 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;  // 16 digits
  const amexRegex = /^3[47]\d{13}$/;  // 15 digits

  const isValidFormat = visaRegex.test(cleaned) || 
                       mastercardRegex.test(cleaned) || 
                       amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum validation
  return runLuhnCheck(cleaned);
}
