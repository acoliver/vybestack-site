/**
 * Find words beginning with the specified prefix but excluding the listed exceptions.
 * Returns an array of matched word strings.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }

  // Escape the prefix for regex and ensure it matches word boundaries
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words at word boundaries that start with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exception words (case sensitive)
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token when it appears after a digit and not at the start of the string.
 * Returns the digit followed by the token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
  
  // Match a digit followed by the token (captures digit+token)
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const results = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Push the full match (digit + token)
    results.push(match[0]);
  }
  
  return results;
}

/**
 * Validate password strength according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  if (!/[A-Z]/.test(value)) {
    return false; // Uppercase
  }
  if (!/[a-z]/.test(value)) {
    return false; // Lowercase
  }
  if (!/\d/.test(value)) {
    return false; // Digit
  }
  if (!/[!@#$%^&*()_+=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false; // Symbol
  }

  // Check for immediate repeated sequences like "abab" or "123123"
  // This regex looks for patterns where a character sequence of length 2-4
  // repeats immediately
  if (/(.{2,4})\1/.test(value)) {
    return false;
  }

  // Check for keyboard patterns like "qwerty" or "asdf"
  const keyboardPatterns = [
    /qwerty/i, /asdf/i, /123456/i, /password/i
  ];
  
  for (const pattern of keyboardPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand with ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // IPv4 pattern to make sure we don't match plain IPv4
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;

  // Check if it's a pure IPv4 address - if so, return false
  if (ipv4Pattern.test(value)) {
    return false;
  }

  // IPv6 pattern that includes:
  // - Full IPv6 notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand with :: for zero sequences
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::/;

  return ipv6Pattern.test(value);
}