import { ReportData, Formatter } from '../types/report.js';

export const renderText: Formatter = {
  format(data: ReportData, includeTotals: boolean): string {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    
    let output = `${data.title}

${data.summary}

Entries:

`;
    
    // Add entries
    for (const entry of data.entries) {
      const amount = `$${entry.amount.toFixed(2)}`;
      output += `- ${entry.label}: ${amount}
`;
    }
    
    // Add total if requested
    if (includeTotals) {
      const totalFormatted = `$${total.toFixed(2)}`;
      output += `
Total: ${totalFormatted}
`;
    }
    
    return output;
  }
};