import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): CLIOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format': {
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        const formatValue = args[i + 1];
        if (formatValue !== 'markdown' && formatValue !== 'text') {
          console.error(`Error: Unsupported format '${formatValue}'. Supported formats: markdown, text`);
          process.exit(1);
        }
        format = formatValue;
        i++; // Skip the next argument since it's the value
        break;
      }
        
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = args[i + 1];
        i++; // Skip the next argument since it's the value
        break;
        
      case '--includeTotals':
        includeTotals = true;
        break;
        
      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown option '${arg}'`);
          process.exit(1);
        }
        // Positional arguments are handled elsewhere
        break;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const data = JSON.parse(readFileSync(filePath, 'utf8'));
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else if (error instanceof Error && error.message.startsWith('Error:')) {
      console.error(error.message);
    } else {
      console.error(`Error: Failed to load data file - ${error}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const options = parseArgs();
  const data = loadReportData(options.dataFile);
  
  let output: string;
  switch (options.format) {
    case 'markdown':
      output = renderMarkdown.format(data, options.includeTotals);
      break;
    case 'text':
      output = renderText.format(data, options.includeTotals);
      break;
    default:
      console.error(`Unsupported format '${options.format}'. Supported formats: markdown, text`);
      process.exit(1);
  }
  
  if (options.outputPath) {
    writeFileSync(options.outputPath, output);
  } else {
    console.log(output);
  }
}

main();