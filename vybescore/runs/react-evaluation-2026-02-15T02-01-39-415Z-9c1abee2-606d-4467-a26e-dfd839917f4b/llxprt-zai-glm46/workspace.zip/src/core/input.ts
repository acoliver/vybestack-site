/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  queueObserverUpdate,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via accessor and changed via
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers: Set<Observer<unknown>> = new Set()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<unknown>)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers
    for (const observer of observers) {
      queueObserverUpdate(observer)
    }
    return s.value
  }

  return [read, write]
}
