/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  queueObserverUpdate,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with
 * supplied function which computes current value
 * of closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: Set<Observer<unknown>> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Wrap updateFn to notify dependent observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    // Notify all observers that depend on this computed
    for (const observer of observers) {
      queueObserverUpdate(observer)
    }
    return result
  }
  
  // Initial computation
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<unknown>)
    }
    return o.value!
  }
  
  return read
}
