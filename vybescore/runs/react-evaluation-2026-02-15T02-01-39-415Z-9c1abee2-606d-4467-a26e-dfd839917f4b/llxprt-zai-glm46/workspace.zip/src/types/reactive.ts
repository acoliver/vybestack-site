/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updateDepth = 0
const pendingUpdates: Array<Observer<unknown>> = []

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  updateDepth++
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    updateDepth--
    // When we return to depth 0, process any pending updates
    if (updateDepth === 0 && pendingUpdates.length > 0) {
      const updates = pendingUpdates.splice(0)
      for (const obs of updates) {
        updateObserver(obs)
      }
    }
  }
}

export function queueObserverUpdate(observer: Observer<unknown>): void {
  if (updateDepth > 0) {
    // We're in an update cycle, queue this update
    pendingUpdates.push(observer)
  } else {
    // Not in an update cycle, update immediately
    updateObserver(observer)
  }
}
