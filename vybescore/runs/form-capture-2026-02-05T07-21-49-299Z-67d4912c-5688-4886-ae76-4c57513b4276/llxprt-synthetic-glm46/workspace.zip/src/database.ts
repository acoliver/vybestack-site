// @ts-ignore
import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';

interface Database {
  db: any;
  save: () => void;
  close: () => void;
}

let databaseInstance: Database | null = null;

export async function initDatabase(): Promise<Database> {
  if (databaseInstance) {
    return databaseInstance;
  }

  const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  
  // Initialize sql.js
  const SQL = await initSqlJs();
  
  // Try to load existing database or create new one
  let dbBytes: Uint8Array;
  try {
    dbBytes = readFileSync(dbPath);
  } catch (error) {
    // File doesn't exist, create new database
    dbBytes = new Uint8Array(0);
  }
  
  // Create SQL.js database instance
  const db = new SQL.Database(dbBytes);
  
  // Initialize schema if needed
  db.run(`
    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      street_address TEXT NOT NULL,
      city TEXT NOT NULL,
      state_province TEXT NOT NULL,
      postal_code TEXT NOT NULL,
      country TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
  
  // Save function to write database to disk
  const save = (): void => {
    const data = db.export();
    writeFileSync(dbPath, Buffer.from(data));
  };
  
  // Close function
  const close = (): void => {
    db.close();
    databaseInstance = null;
  };
  
  databaseInstance = { db, save, close };
  return databaseInstance;
}

export function getDatabase(): Database {
  if (!databaseInstance) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return databaseInstance;
}