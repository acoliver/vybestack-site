import express from 'express';
import { join } from 'path';
import { initDatabase, getDatabase } from './database.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

const app = express();
const PORT = process.env.PORT || '3535';

app.set('view engine', 'ejs');
app.set('views', join(process.cwd(), 'src', 'views'));
app.use(express.static(join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};

  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State/Province is required';
  }

  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal code is required';
  }

  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  const phoneRegex = /^[+()0-9 -]+$/;
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!phoneRegex.test(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }

  return errors;
}

app.get('/', (req, res) => {
  res.render('form', { 
    formData: {}, 
    errors: {},
    submitted: false 
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    return res.render('form', { 
      formData, 
      errors,
      submitted: false
    });
  }

  try {
    const database = getDatabase();
    (database.db as any).run(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    database.save();
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      formData,
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      submitted: false
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Received shutdown signal, closing server...');
  
  try {
    const database = getDatabase();
    database.close();
    console.log('Database connection closed.');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
}

// Initialize database and start server
function startServer(): void {
  try {
    initDatabase();
    console.log('Database initialized successfully.');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

startServer();
