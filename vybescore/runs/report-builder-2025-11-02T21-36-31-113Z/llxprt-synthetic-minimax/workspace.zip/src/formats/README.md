# Report Formatters

This directory contains formatter implementations for the Report Builder CLI.

## Available Formatters

### Markdown (`markdown.ts`)
Renders reports in Markdown format with:
- H1 title (`#`)
- Summary paragraph
- H2 entries section (`##`)
- Bullet list with bold labels and dollar amounts
- Optional total at the end

### Text (`text.ts`)
Renders reports in plain text format with:
- Plain text title
- Summary paragraph
- "Entries:" heading
- Bullet list with labels and dollar amounts
- Optional total at the end

## Adding New Formatters

To add a new formatter:

1. Create a new file (e.g., `html.ts`) in this directory
2. Export a `Formatter` implementation with a `render` method
3. Add it to the `formatters` registry in `src/cli/report.ts`

Example:
```typescript
import { Formatter, ReportData, RenderOptions } from '../types.js';

export const renderHtml: Formatter = {
  render: (data: ReportData, options: RenderOptions): string => {
    // Implementation
    return htmlString;
  }
};
```