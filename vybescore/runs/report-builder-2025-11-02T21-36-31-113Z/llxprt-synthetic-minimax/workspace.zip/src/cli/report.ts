import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Formatter registry
const formatters: Record<string, (data: ReportData, options: RenderOptions) => string> = {
  markdown: renderMarkdown.render,
  text: renderText.render,
};

function printError(message: string): void {
  process.stderr.write(`Error: ${message}\n`);
  process.exit(1);
}

function parseArguments(argv: string[]): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    printError('Usage: report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        printError('--format requires a value');
      }
      format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        printError('--output requires a value');
      }
      outputPath = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
      i += 1;
    } else {
      printError(`Unknown argument: ${arg}`);
    }
  }
  
  if (!format) {
    printError('--format is required');
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    printError('Invalid JSON: root must be an object');
  }
  
  const report = data as ReportData;
  
  if (typeof report.title !== 'string') {
    printError('Invalid JSON: "title" must be a string');
  }
  
  if (typeof report.summary !== 'string') {
    printError('Invalid JSON: "summary" must be a string');
  }
  
  if (!Array.isArray(report.entries)) {
    printError('Invalid JSON: "entries" must be an array');
  }
  
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      printError(`Invalid JSON: entries[${i}] must be an object`);
    }
    
    const typedEntry = entry as { label: unknown; amount: unknown };
    
    if (typeof typedEntry.label !== 'string') {
      printError(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof typedEntry.amount !== 'number') {
      printError(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
  
  return report;
}

function main(): void {
  const { dataFile, format, outputPath, includeTotals } = parseArguments(process.argv);
  
  const resolvedPath = resolve(dataFile);
  
  let content: string;
  try {
    content = readFileSync(resolvedPath, 'utf-8');
  } catch (error) {
    printError(`Cannot read file: ${resolvedPath}`);
    return;
  }
  
  let data: ReportData;
  try {
    const parsed = JSON.parse(content);
    data = validateReportData(parsed);
  } catch (error) {
    if (error instanceof SyntaxError) {
      printError(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
  
  if (!(format in formatters)) {
    printError(`Unsupported format`);
  }
  
  const render = formatters[format];
  const output = render(data, { includeTotals });
  
  if (outputPath) {
    try {
      writeFileSync(resolve(outputPath), output, 'utf-8');
    } catch (error) {
      printError(`Cannot write to file: ${outputPath}`);
    }
  } else {
    process.stdout.write(output);
  }
}

main();