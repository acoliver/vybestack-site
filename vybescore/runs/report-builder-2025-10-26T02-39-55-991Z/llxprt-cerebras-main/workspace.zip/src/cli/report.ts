#!/usr/bin/env node

import * as fs from 'fs';
import * as path from 'path';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
let dataFile: string | null = null;
let format: string | null = null;
let outputFile: string | null = null;
let includeTotals = false;

for (let i = 0; i < args.length; i++) {
  switch (args[i]) {
    case '--format':
      if (i + 1 < args.length) {
        format = args[i + 1];
        i++;
      } else {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      break;
    case '--output':
      if (i + 1 < args.length) {
        outputFile = args[i + 1];
        i++;
      } else {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      break;
    case '--includeTotals':
      includeTotals = true;
      break;
    default:
      if (!dataFile) {
        dataFile = args[i];
      } else {
        console.error(`Error: Unexpected argument "${args[i]}"`);
        process.exit(1);
      }
  }
}

// Validate arguments
if (!dataFile) {
  console.error('Error: Data file path is required');
  process.exit(1);
}

if (!format) {
  console.error('Error: Format option is required');
  process.exit(1);
}

if (!['markdown', 'text'].includes(format)) {
  console.error(`Error: Unsupported format "${format}"`);
  process.exit(1);
}

// Check if data file exists
if (!fs.existsSync(dataFile)) {
  console.error(`Error: Data file "${dataFile}" not found`);
  process.exit(1);
}

// Read and parse JSON data
let data: ReportData;
try {
  const jsonData = fs.readFileSync(dataFile, 'utf8');
  data = JSON.parse(jsonData);
} catch (error) {
  console.error(`Error: Failed to parse JSON data from "${dataFile}"`);
  process.exit(1);
}

// Validate data structure
if (!data.title || !data.summary || !Array.isArray(data.entries)) {
  console.error('Error: Invalid data structure in JSON file');
  process.exit(1);
}

for (const entry of data.entries) {
  if (!entry.label || typeof entry.amount !== 'number') {
    console.error('Error: Invalid entry structure in JSON file');
    process.exit(1);
  }
}

// Generate report based on format
let report: string;
switch (format) {
  case 'markdown':
    report = renderMarkdown(data, { includeTotals });
    break;
  case 'text':
    report = renderText(data, { includeTotals });
    break;
  default:
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
}

// Output report
if (outputFile) {
  fs.writeFileSync(outputFile, report);
  console.log(`Report written to ${path.resolve(outputFile)}`);
} else {
  console.log(report);
}