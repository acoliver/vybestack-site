import { describe, expect, it } from 'vitest';
import { execSync } from 'child_process';
import * as path from 'path';
import * as fs from 'fs';

const projectRoot = path.resolve(__dirname, '../../');

describe('report CLI (public smoke)', () => {
  it('should render markdown report with totals', () => {
    const result = execSync(
      'node dist/cli/report.js fixtures/data.json --format markdown --includeTotals',
      { cwd: projectRoot, encoding: 'utf8' }
    );
    
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('Highlights include record revenue');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('- **South Region** — $23456.78');
    expect(result).toContain('- **West Region** — $34567.89');
    expect(result).toContain('**Total:** $70370.34');
  });

  it('should render text report with totals', () => {
    const result = execSync(
      'node dist/cli/report.js fixtures/data.json --format text --includeTotals',
      { cwd: projectRoot, encoding: 'utf8' }
    );
    
    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Highlights include record revenue');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('- South Region: $23456.78');
    expect(result).toContain('- West Region: $34567.89');
    expect(result).toContain('Total: $70370.34');
  });

  it('should render markdown report without totals', () => {
    const result = execSync(
      'node dist/cli/report.js fixtures/data.json --format markdown',
      { cwd: projectRoot, encoding: 'utf8' }
    );
    
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('Highlights include record revenue');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('- **South Region** — $23456.78');
    expect(result).toContain('- **West Region** — $34567.89');
    expect(result).not.toContain('**Total:**');
  });

  it('should render text report without totals', () => {
    const result = execSync(
      'node dist/cli/report.js fixtures/data.json --format text',
      { cwd: projectRoot, encoding: 'utf8' }
    );
    
    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Highlights include record revenue');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('- South Region: $23456.78');
    expect(result).toContain('- West Region: $34567.89');
    expect(result).not.toContain('Total:');
  });

  it('should reject unknown format with error', () => {
    expect(() => {
      execSync('node dist/cli/report.js fixtures/data.json --format xml', {
        cwd: projectRoot,
        encoding: 'utf8'
      });
    }).toThrow('Unsupported format');
  });

  it('should output to file when --output is specified', () => {
    const outputPath = path.join(projectRoot, 'test-output.txt');
    
    try {
      execSync(
        `node dist/cli/report.js fixtures/data.json --format text --output ${outputPath}`,
        { cwd: projectRoot, encoding: 'utf8' }
      );
      
      const outputFileContent = fs.readFileSync(outputPath, 'utf8');
      expect(outputFileContent).toContain('Quarterly Financial Summary');
      expect(outputFileContent).toContain('Entries:');
      
      fs.unlinkSync(outputPath);
    } catch (error) {
      if (fs.existsSync(outputPath)) {
        fs.unlinkSync(outputPath);
      }
      throw error;
    }
  });
});