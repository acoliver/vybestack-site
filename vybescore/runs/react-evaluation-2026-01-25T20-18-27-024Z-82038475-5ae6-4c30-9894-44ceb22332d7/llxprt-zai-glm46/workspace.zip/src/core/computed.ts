/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserverAny,
  getActiveObserver,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed
  const dependentObservers: Set<Observer<unknown>> = new Set()

  const o: Observer<T> & { _sourceSubjects?: Set<Subject<unknown>> } = {
    name: options?.name,
    value,
    _sourceSubjects: new Set(),
    updateFn: (prev) => {
      return updateFn(prev)
    },
  }

  // Create a Subject wrapper for this computed so other computeds can depend on it
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: o as Observer<unknown>,
    value: value as T,
    equalFn: undefined,
    _dependentObservers: dependentObservers,
  }

  const getter: GetterFn<T> = (): T => {
    const activeObserver = getActiveObserver()

    // If someone is observing this computed (e.g., another computed or callback),
    // register this computed as a dependency
    if (activeObserver) {
      const activeObs = activeObserver as Observer<unknown> & {
        _sources?: Set<Observer<unknown>>
        _sourceSubjects?: Set<Subject<unknown>>
      }

      // Track which observers this observer depends on
      if (!activeObs._sources) {
        activeObs._sources = new Set<Observer<unknown>>()
      }
      // @ts-expect-error - Type compatibility with generics
      activeObs._sources.add(o)

      // Track which subjects this observer depends on
      if (!activeObs._sourceSubjects) {
        activeObs._sourceSubjects = new Set<Subject<unknown>>()
      }
      // @ts-expect-error - Type compatibility with generics
      activeObs._sourceSubjects.add(computedSubject)

      // Add this observer to our dependent observers
      dependentObservers.add(activeObs)
      
      // When being observed, trigger recalculation
      const result = o.updateFn(o.value)
      o.value = result
      computedSubject.value = result as T
    }

    // Always return the current value from the observer
    return o.value as T
  }

  // Store metadata on the getter for cleanup
  const getterExt = getter as GetterFn<T> & {
    _observer: Observer<T>
    _subject: Subject<T>
  }
  getterExt._observer = o
  getterExt._subject = computedSubject as Subject<T>

  // Perform initial computation to establish dependencies
  updateObserverAny(o as Observer<unknown>)

  return getter
}
