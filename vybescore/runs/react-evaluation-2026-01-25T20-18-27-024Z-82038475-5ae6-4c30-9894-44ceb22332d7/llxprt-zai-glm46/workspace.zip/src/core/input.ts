/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserverAny,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Track all observers that depend on this input
  const dependentObservers: Set<Observer<unknown>> = new Set()

  const s: Subject<T> & { _dependentObservers?: Set<Observer<unknown>> } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    _dependentObservers: dependentObservers,
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this observer as dependent on this input
      dependentObservers.add(activeObserver as Observer<unknown>)
      s.observer = activeObserver

      // Track this subject as a source for the active observer
      const obsWithSources = activeObserver as Observer<unknown> & { _sourceSubjects?: Set<Subject<unknown>> }
      if (!obsWithSources._sourceSubjects) {
        obsWithSources._sourceSubjects = new Set()
      }
      // @ts-expect-error - Type compatibility issue with generics
      obsWithSources._sourceSubjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue

    // Notify all dependent observers
    const notified = new Set<Observer<unknown>>()
    const queue: Observer<unknown>[] = [...dependentObservers]

    while (queue.length > 0) {
      const obs = queue.shift()!
      if (notified.has(obs)) continue

      notified.add(obs)
      updateObserverAny(obs)

      // Add all observers that depend on this observer
      const obsWithSources = obs as Observer<unknown> & { _sourceSubjects?: Set<Subject<unknown>> }
      if (obsWithSources._sourceSubjects) {
        for (const subj of obsWithSources._sourceSubjects) {
          const subjWithDeps = subj as Subject<unknown> & { _dependentObservers?: Set<Observer<unknown>> }
          if (subjWithDeps._dependentObservers) {
            for (const depObs of subjWithDeps._dependentObservers) {
              if (!notified.has(depObs)) {
                queue.push(depObs)
              }
            }
          }
        }
      }
    }

    return s.value
  }

  return [read, write]
}
