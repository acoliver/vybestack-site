// Debug to see what happens during cascade
import { createInput, createComputed, createCallback } from './src/index.ts'

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum())

// @ts-ignore
const sumObserver = sum._observer

console.log('\n=== Before setInput ===')
// @ts-ignore
console.log('sumObserver._sourceSubjects size:', sumObserver._sourceSubjects.size)

// @ts-ignore
for (const subj of sumObserver._sourceSubjects) {
  console.log('  Subject value:', subj.value, ', observer value:', subj.observer?.value)
  console.log('    Subject _dependentObservers size:', subj._dependentObservers.size)
  // @ts-ignore
  for (const obs of subj._dependentObservers) {
    console.log('      - Dependent observer value:', obs.value)
    console.log('        Is this sumObserver?', obs === sumObserver)
  }
}

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After setInput ===')
// @ts-ignore
console.log('timesTwo observer value:', timesTwo._observer?.value)
// @ts-ignore
console.log('timesThirty observer value:', timesThirty._observer?.value)
console.log('sum observer value:', sumObserver?.value)
console.log('sum():', sum())
