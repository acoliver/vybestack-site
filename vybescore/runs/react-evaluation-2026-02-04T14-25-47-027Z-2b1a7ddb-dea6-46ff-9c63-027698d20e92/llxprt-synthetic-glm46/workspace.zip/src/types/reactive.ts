/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  running?: boolean // to prevent circular dependencies
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers?: Observer<unknown>[]
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.running) return // prevent circular dependencies
  
  const previous = activeObserver
  activeObserver = observer
  observer.running = true

  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    observer.running = false
  }
}

export function addObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (!subject.observers) {
    subject.observers = []
  }
  subject.observers.push(observer)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  for (const observer of subject.observers) {
    updateObserver(observer as Observer<unknown>)
  }
}
