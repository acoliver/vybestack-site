/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    running: false
  }

  // Create a subject-like structure to hold the computed value and its observers
  const subject: Subject<T> = {
    name: options?.name,
    value: value as T,
    equalFn
  }

  // Override the observer's update function to notify subject observers
  const wrappedUpdateFn: UpdateFn<T> = (prevValue) => {
    const newValue = updateFn(prevValue as T)
    
    // Update subject's value and notify observers
    const prevSubjectValue = subject.value
    const shouldUpdate = !subject.equalFn || !subject.equalFn(prevSubjectValue, newValue)
    if (shouldUpdate) {
      subject.value = newValue
      // Notify all observers of this computed value
      if (subject.observers) {
        for (const observerToNotify of subject.observers) {
          updateObserver(observerToNotify as Observer<unknown>)
        }
      }
    }
    
    return newValue
  }

  observer.updateFn = wrappedUpdateFn

  // Compute initial value
  updateObserver(observer)

  return (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Register the current observer as dependent on this computed value
      // Add it to the subject's observers list
      if (!subject.observers) {
        subject.observers = []
      }
      subject.observers.push(currentObserver as Observer<unknown>)
    }
    
    return subject.value
  }
}
