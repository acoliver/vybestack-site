import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): CLIOptions {
  if (argv.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = argv[2];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format' && i + 1 < argv.length) {
      format = argv[i + 1] as 'markdown' | 'text';
      i++;
    } else if (arg === '--output' && i + 1 < argv.length) {
      outputPath = argv[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('Format is required: --format <markdown|text>');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadReportData(dataPath: string): ReportData {
  try {
    const rawData = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(rawData);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }

    // Validate each entry
    data.entries.forEach((entry: unknown, index: number) => {
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid data: entry ${index + 1} is not a valid object`);
      }
      
      const typedEntry = entry as { label?: unknown; amount?: unknown };
      
      if (!typedEntry.label || typeof typedEntry.label !== 'string') {
        throw new Error(`Invalid data: entry ${index + 1} missing or invalid "label" field`);
      }
      
      if (typeof typedEntry.amount !== 'number') {
        throw new Error(`Invalid data: entry ${index + 1} missing or invalid "amount" field`);
      }
    });

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${dataPath}`);
      }
      if (error.message.includes('JSON.parse')) {
        throw new Error(`Invalid JSON: cannot parse ${dataPath}`);
      }
      throw error;
    }
    throw new Error(`Failed to load data from ${dataPath}: unknown error`);
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  if (format === 'markdown') {
    return renderMarkdown(data, includeTotals);
  } else {
    return renderText(data, includeTotals);
  }
}

function main(): void {
  try {
    const options = parseArgs(process.argv);
    const reportData = loadReportData(options.dataPath);
    const reportOutput = renderReport(reportData, options.format, options.includeTotals);
    
    if (options.outputPath) {
      // Write to file using Node standard library
      writeFileSync(options.outputPath, reportOutput);
    } else {
      // Write to stdout
      process.stdout.write(reportOutput);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
