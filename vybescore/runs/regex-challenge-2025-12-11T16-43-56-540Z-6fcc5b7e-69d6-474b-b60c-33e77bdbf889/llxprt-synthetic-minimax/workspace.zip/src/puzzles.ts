/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Word boundary pattern to find whole words starting with prefix
  // Using \b for word boundaries to avoid partial matches
  const pattern = new RegExp(`\\b${prefix}[\\w-]*`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowerMatch === exception.toLowerCase()
    );
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple pattern: find digit followed by token
  // This ensures the token comes after a digit and is not at the start
  const pattern = new RegExp(`\\d${escapeRegExp(token)}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

// Helper function to escape special regex characters in token
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // Pattern: any 2+ character sequence repeated immediately
  const repeatedPattern = /(..+)\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, let's check if there are any IPv4 patterns - if so, we need to be careful
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If the entire string is just an IPv4 address (no colons), return false
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false; // Pure IPv4 address
  }
  
  // IPv6 patterns (simplified but effective):
  // 1. Pattern with :: (compressed zeros)
  // 2. Pattern with full hex groups
  
  // Check for :: (double colon) - the most distinctive IPv6 feature
  if (value.includes('::')) {
    // Count hex groups around the ::
    const beforeColon = value.split('::')[0];
    const afterColon = value.split('::')[1] || '';
    
    // Extract hex parts
    const beforeParts = beforeColon.split(':').filter(part => part.length > 0);
    const afterParts = afterColon.split(':').filter(part => part.length > 0);
    
    // Valid IPv6 should have at most 8 total groups
    if (beforeParts.length + afterParts.length <= 8) {
      return true;
    }
  }
  
  // Check for patterns like 2001:db8:... with colons and hex digits
  const hexColonPattern = /^[A-Fa-f0-9:]+$/;
  if (hexColonPattern.test(value) && value.includes(':')) {
    const parts = value.split(':').filter(part => part.length > 0);
    if (parts.length >= 3 && parts.length <= 8) {
      // All parts should be valid hex (max 4 digits)
      const allValidHex = parts.every(part => part.length <= 4);
      if (allValidHex) {
        return true;
      }
    }
  }
  
  // Look for IPv6 addresses embedded in text
  const ipv6InTextPattern = /[A-Fa-f0-9:]{3,}::[A-Fa-f0-9:]+|[A-Fa-f0-9:]+::/;
  if (ipv6InTextPattern.test(value)) {
    return true;
  }
  
  return false;
}