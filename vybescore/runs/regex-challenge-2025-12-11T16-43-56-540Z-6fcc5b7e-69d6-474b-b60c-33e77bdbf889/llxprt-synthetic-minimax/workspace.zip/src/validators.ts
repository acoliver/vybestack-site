export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern breakdown:
  // - Local part: letters, digits, dots, plus, underscores (but not double dots or trailing)
  // - Domain: letters, digits, dots, hyphens (but not double dots, trailing, or underscores)
  const emailPattern = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Basic format check
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional validation: no double dots, no trailing dots
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const local = parts[0];
  const domain = parts[1];
  
  // No double dots anywhere, no trailing dots
  if (local.includes('..') || domain.includes('..') || 
      local.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Domain cannot have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with flexible formatting.
 * Accept formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Reject area codes starting with 0 or 1, and too short inputs
 */
export function isValidUSPhone(value: string /* options?: PhoneValidationOptions */): boolean {
  // Remove all non-digit characters except leading +
  let cleaned = value.trim();
  
  // Allow optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2).trim();
  }
  
  // Remove all separators (spaces, hyphens, parentheses, dots)
  const phoneNumber = cleaned.replace(/[\s- .()]/g, '');
  
  // Check if we now have only digits
  if (!/^\d+$/.test(phoneNumber)) {
    return false;
  }
  
  // Check length (should be 10 digits)
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate exchange code (digits 4-6) - cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2–4 digits (leading digit 1–9)
 * - Subscriber number (after the area code) must contain 6–8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+?54(9)?(0)?([1-9]\d{1,3})(\d{6,8})$
  // - Optional country code +54
  // - Optional mobile indicator 9
  // - Optional trunk prefix 0
  // - Area code: 2-4 digits starting with 1-9
  // - Subscriber number: 6-8 digits
  const pattern = /^\+?54(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!pattern.test(cleaned)) {
    return false;
  }
  
  const matches = cleaned.match(pattern);
  if (!matches) return false;
  
  // Extract components
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  const hasTrunkPrefix = matches[3] === '0';
  
  // When country code is omitted, the number must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Validate area code length and leading digit
  const areaCode = matches[3];
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  // Validate subscriber number length
  const subscriberNumber = matches[4];
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Pattern: Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and symbols like X Æ A-12
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  const trimmed = value.trim();
  
  // Cannot start or end with apostrophe or hyphen
  if (trimmed.startsWith("'") || trimmed.startsWith('-') || 
      trimmed.endsWith("'") || trimmed.endsWith('-')) {
    return false;
  }
  
  // Cannot have consecutive apostrophes or hyphens
  if (/''|--+/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers using the Luhn algorithm.
 * Accept common card types with correct lengths: Visa (16), Mastercard (16), AmEx (15), Discover (16).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check basic length requirements
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Validate card type and length
  let isValidType = false;
  
  // Visa: starts with 4, length 13 or 16
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16)) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55, length 16
  else if (cleaned.startsWith('51') || cleaned.startsWith('52') || 
           cleaned.startsWith('53') || cleaned.startsWith('54') || 
           cleaned.startsWith('55') && cleaned.length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidType = true;
  }
  // Discover: starts with 6011, 644-649, or 65, length 16
  else if ((cleaned.startsWith('6011') || cleaned.startsWith('644') || 
            cleaned.startsWith('645') || cleaned.startsWith('646') || 
            cleaned.startsWith('647') || cleaned.startsWith('648') || 
            cleaned.startsWith('649') || cleaned.startsWith('65')) 
           && cleaned.length === 16) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}