/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace by collapsing multiple spaces
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to match sentence boundaries: . ? !
  // We need to find sentence endings and capitalize the next letter
  const sentencePattern = /([.!?])\s*(\S)/g;
  
  // Replace: capitalize the first letter after sentence ending
  let result = normalized.replace(sentencePattern, (match, punct, nextChar) => {
    return punct + nextChar.toUpperCase();
  });
  
  // Capitalize the very first character if it's a letter
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Ensure exactly one space between sentences by handling edge cases
  // This regex ensures space normalization around sentence punctuation
  result = result.replace(/\s*([.!?])\s*/g, '$1 ');
  result = result.replace(/([.!?])\s*([A-Z])/g, '$1 $2');
  
  return result.trim();
}

/**
 * Return all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlPattern = /\bhttps?:\/\/[^\s<>"')]+(?<![.,;!?])/gi;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.,;!?]+$/, ''));
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  const httpPattern = /http:\/\/[^\s<>"')]+/gi;
  
  return text.replace(httpPattern, (match) => {
    return match.replace(/^http:\/\//i, 'https://');
  });
}

/**
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/...
 * - Skip the **host** rewrite when the path contains dynamic hints such as cgi-bin, query strings, or legacy extensions, but still upgrade the scheme to https://.
 * - Preserve nested paths (e.g., /docs/api/v1).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs - capture host and path separately
  const httpPattern = /\bhttp:\/\/([^/\s]+)([^]*)/gi;
  
  // Dynamic file extensions to skip host rewrite
  const dynamicExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  
  return text.replace(httpPattern, (match, host, path) => {
    let newUrl = 'https://' + host + path;
    
    // Check if path begins with /docs/ and doesn't contain dynamic elements
    if (path.startsWith('/docs/') && !path.includes('?') && !path.includes('&') && !path.includes('=')) {
      // Check for legacy extensions
      const hasDynamicExtension = dynamicExtensions.some(ext => path.includes(ext));
      
      if (!hasDynamicExtension) {
        // Rewrite host to docs.hostname
        newUrl = 'https://docs.' + host + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Return the four-digit year for mm/dd/yyyy. If the string doesn't match that format or month/day are invalid, return N/A.
 */
export function extractYear(value: string): string {
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return match[3];
}