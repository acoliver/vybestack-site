import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns correct pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page', 1);
    expect(response.body).toHaveProperty('limit', 5);
    expect(response.body).toHaveProperty('total', 15);
    expect(response.body).toHaveProperty('hasNext', true);
  });

  it('honors custom limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(3);
    expect(response.body.limit).toBe(3);
    expect(response.body.page).toBe(1);
    expect(response.body.hasNext).toBe(true);
  });

  it('honors page parameter', async () => {
    const response = await request(app).get('/inventory?page=2');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(2);
    expect(response.body.hasNext).toBe(true);
    
    // Ensure we get different items on page 2
    const firstPageResponse = await request(app).get('/inventory?page=1');
    const firstPageIds = firstPageResponse.body.items.map((item: { id: number }) => item.id);
    const secondPageIds = response.body.items.map((item: { id: number }) => item.id);
    expect(firstPageIds).not.toEqual(secondPageIds);
  });

  it('returns empty items on page beyond available data', async () => {
    const response = await request(app).get('/inventory?page=4&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.page).toBe(4);
    expect(response.body.hasNext).toBe(false);
  });

  it('rejects invalid page parameter', async () => {
    const response = await request(app).get('/inventory?page=invalid');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('rejects negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('rejects zero page parameter', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('rejects invalid limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=invalid');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('rejects zero limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('rejects excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=200');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('correctly calculates hasNext for last page', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(3);
    expect(response.body.hasNext).toBe(false);
  });
});
