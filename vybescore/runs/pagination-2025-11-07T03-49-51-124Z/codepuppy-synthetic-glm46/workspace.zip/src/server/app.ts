import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParam(param: string | undefined, paramName: string): number | null {
  if (param === undefined) {
    return null;
  }
  
  const num = Number(param);
  
  if (isNaN(num)) {
    return null;
  }
  
  if (num <= 0) {
    return null;
  }
  
  if (!Number.isInteger(num)) {
    return null;
  }
  
  // Reasonable upper bounds to prevent abuse
  if (paramName === 'page' && num > 1000) {
    return null;
  }
  
  if (paramName === 'limit' && num > 100) {
    return null;
  }
  
  return num;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const page = validatePaginationParam(pageParam, 'page');
    const limit = validatePaginationParam(limitParam, 'limit');

    if (pageParam !== undefined && page === null) {
      return res.status(400).json({ 
        error: 'Invalid page parameter. Must be a positive integer <= 1000.' 
      });
    }

    if (limitParam !== undefined && limit === null) {
      return res.status(400).json({ 
        error: 'Invalid limit parameter. Must be a positive integer <= 100.' 
      });
    }

    try {
      const payload = listInventory(db, { page: page || undefined, limit: limit || undefined });
      res.json(payload);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
