import initSqlJs from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

class DatabaseManager {
  // sql.js runtime instance - using any to handle dynamic nature of sql.js module
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private sqlJs: any = null;
  // Database instance from sql.js - using any for same reason
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = process.env.DB_PATH || path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = process.env.SCHEMA_PATH || path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    if (!fs.existsSync(path.dirname(this.dbPath))) {
      fs.mkdirSync(path.dirname(this.dbPath), { recursive: true });
    }

    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file),
    });

    if (fs.existsSync(this.dbPath)) {
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.exec(schema);
  }

  insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): number {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    return this.db!.getRowsModified();
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
    }
  }
}

export const dbManager = new DatabaseManager();