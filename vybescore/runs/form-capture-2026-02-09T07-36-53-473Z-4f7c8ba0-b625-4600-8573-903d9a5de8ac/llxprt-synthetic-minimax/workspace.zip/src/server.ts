import express from 'express';
import * as path from 'path';
import { dbManager } from './db.js';
import { validateFormData, sanitizeFormData, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Initialize database
let dbInitialized = false;

async function initializeApp(): Promise<void> {
  try {
    await dbManager.initialize();
    dbInitialized = true;
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
  }
}

// Routes
app.get('/', (req, res) => {
  res.status(200).render('form', {
    errors: [],
    data: {} as FormData,
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateFormData(formData);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        data: formData,
        title: 'Please correct the errors'
      });
    }

    if (!dbInitialized) {
      return res.status(500).render('form', {
        errors: [{ field: 'system', message: 'Database not available. Please try again later.' }],
        data: formData,
        title: 'System Error'
      });
    }

    const sanitizedData = sanitizeFormData(formData);
    dbManager.insertSubmission(sanitizedData);
    await dbManager.saveToDisk();

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'system', message: 'An error occurred. Please try again.' }],
      data: req.body as FormData,
      title: 'System Error'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.status(200).render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  server.close(async () => {
    console.log('HTTP server closed');
    
    try {
      dbManager.close();
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
    
    process.exit(0);
  });

  // Force close server after 10 seconds
  setTimeout(() => {
    console.error('Could not close connections in time, forcefully shutting down');
    process.exit(1);
  }, 10000);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
const server = app.listen(PORT, async () => {
  await initializeApp();
  console.log(`Server running on port ${PORT}`);
  console.log(`Visit http://localhost:${PORT} to see the form`);
});
