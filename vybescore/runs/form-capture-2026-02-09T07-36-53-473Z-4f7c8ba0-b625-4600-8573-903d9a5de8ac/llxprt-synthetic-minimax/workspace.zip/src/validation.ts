export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data: FormData;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\+?[\d\s\-()]+$/;
const POSTAL_REGEX = /^[A-Za-z0-9\s-]+$/;

export function validateFormData(formData: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Check required fields
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const value = formData[field]?.trim();
    if (!value) {
      errors.push({
        field,
        message: `${field.replace('_', ' ')} is required`
      });
    }
  }

  // Validate email format
  if (formData.email && !EMAIL_REGEX.test(formData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Validate phone format
  if (formData.phone && !PHONE_REGEX.test(formData.phone.trim())) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Validate postal code format
  if (formData.postal_code && !POSTAL_REGEX.test(formData.postal_code)) {
    errors.push({
      field: 'postal_code',
      message: 'Please enter a valid postal/zip code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: formData
  };
}

export function sanitizeFormData(formData: FormData): FormData {
  return {
    first_name: formData.first_name.trim(),
    last_name: formData.last_name.trim(),
    street_address: formData.street_address.trim(),
    city: formData.city.trim(),
    state_province: formData.state_province.trim(),
    postal_code: formData.postal_code.trim(),
    country: formData.country.trim(),
    email: formData.email.trim(),
    phone: formData.phone.trim()
  };
}