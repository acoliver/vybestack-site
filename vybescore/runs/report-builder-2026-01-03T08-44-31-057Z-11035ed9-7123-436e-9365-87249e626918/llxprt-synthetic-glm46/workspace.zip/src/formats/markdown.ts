import type { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options?: RenderOptions): string {
  const { title, summary, entries } = data;
  const includeTotals = options?.includeTotals || false;
  
  // Calculate total if needed
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  // Format amounts to two decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };
  
  // Build markdown output
  let output = `# ${title}\n\n`;
  output += `${summary}\n\n`;
  output += `## Entries\n`;
  
  for (const entry of entries) {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    output += `\n**Total:** ${formatAmount(total)}`;
  }
  
  return output;
}