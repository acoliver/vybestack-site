import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { ReportData, RenderOptions } from '../types.js';

export type FormatType = 'markdown' | 'text';

export interface FormatRenderer {
  (data: ReportData, options?: RenderOptions): string;
}

export const formatters: Record<FormatType, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};