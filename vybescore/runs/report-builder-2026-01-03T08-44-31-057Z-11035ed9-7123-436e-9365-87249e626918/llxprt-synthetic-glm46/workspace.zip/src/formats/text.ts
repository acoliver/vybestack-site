import type { ReportData, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options?: RenderOptions): string {
  const { title, summary, entries } = data;
  const includeTotals = options?.includeTotals || false;
  
  // Calculate total if needed
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  // Format amounts to two decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };
  
  // Build text output
  let output = `${title}\n`;
  output += `${summary}\n`;
  output += `Entries:\n`;
  
  for (const entry of entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    output += `Total: ${formatAmount(total)}`;
  }
  
  return output;
}