#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { formatters, type FormatType } from '../formats/index.js';
import type { ReportData } from '../types.js';

function parseArguments(): {
  dataPath: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Find format argument
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Missing --format argument');
    process.exit(1);
  }
  const format = args[formatIndex + 1] as FormatType;
  
  // Find output argument (optional)
  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length 
    ? args[outputIndex + 1] 
    : undefined;
    
  // Check if totals flag is set
  const includeTotals = args.includes('--includeTotals');
  
  // Validate format
  if (!['markdown', 'text'].includes(format)) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: Expected an object');
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }
  
  for (const entry of report.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: each entry must have a string label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: each entry must have a number amount');
    }
  }
}

async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();
    
    // Validate and read data file
    const absolutePath = path.resolve(dataPath);
    
    if (!fs.existsSync(absolutePath)) {
      console.error(`Error: File not found: ${absolutePath}`);
      process.exit(1);
    }
    
    const fileContent = fs.readFileSync(absolutePath, 'utf8');
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error('Error: Invalid JSON format');
      if (error instanceof Error) {
        console.error(error.message);
      }
      process.exit(1);
    }
    
    // Validate data structure
    validateReportData(data);
    
    // Render report
    const formatter = formatters[format];
    const output = formatter(data, { includeTotals });
    
    // Write output
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf8');
      console.log(`Report generated and saved to: ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
