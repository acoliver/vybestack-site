import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || 3535;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

type ValidationResult = {
  isValid: boolean;
  errors: Record<keyof FormData, string>;
  values: Partial<FormData>;
};

async function initializeDatabase(): Promise<Database> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  
  try {
    const existingDb = await fs.readFile(DB_PATH);
    const SQL = await initSqlJs();
    const db = new SQL.Database(existingDb);
    return db;
  } catch (error) {
    const SQL = await initSqlJs();
    const db = new SQL.Database();
    
    const schema = await fs.readFile(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.exec(schema);
    
    const data = db.export();
    await fs.writeFile(DB_PATH, Buffer.from(data));

    return db;
  }
}

function saveDatabase(db: Database): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const data = db.export();
      fs.writeFile(DB_PATH, Buffer.from(data))
        .then(resolve)
        .catch(reject);
    } catch (error) {
      reject(error);
    }
  });
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors = {} as Record<keyof FormData, string>;
  const values = data as Partial<FormData>;
  
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^\+?[0-9\s()-]+$/.test(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    values
  };
}

async function insertSubmission(db: Database, formData: FormData): Promise<void> {
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
  } finally {
    stmt.free();
  }
  
  await saveDatabase(db);
}

async function createApp(): Promise<express.Application> {
  const app = express();
  const db = await initializeDatabase();
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));
  
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(process.cwd(), 'public')));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: {}, 
      values: {},
      title: 'Friendly Contact Form'
    });
  });
  
  app.post('/submit', async (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      res.status(400);
      return res.render('form', {
        errors: validation.errors,
        values: validation.values,
        title: 'Friendly Contact Form'
      });
    }
    
    try {
      await insertSubmission(db, formData);
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error inserting submission:', error);
      res.status(500);
      res.render('form', {
        errors: { lastName: 'An unexpected error occurred. Please try again.' },
        values: validation.values,
        title: 'Friendly Contact Form'
      });
    }
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  });
  
  return new Promise<express.Application>((resolve) => {
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      resolve(app);
    });
    
    process.on('SIGTERM', () => {
      console.log('Received SIGTERM, shutting down gracefully');
      server.close(() => {
        db.close();
        console.log('Server shut down complete');
        process.exit(0);
      });
    });
  });
}

createApp().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});