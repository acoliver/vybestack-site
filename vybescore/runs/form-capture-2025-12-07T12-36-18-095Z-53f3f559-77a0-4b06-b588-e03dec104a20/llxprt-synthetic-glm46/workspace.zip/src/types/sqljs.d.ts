declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...args: unknown[]): void;
    free(): void;
  }

  export interface SqlJsStatic {
    Database: {
      new(data?: ArrayBuffer | Uint8Array): Database;
    };
  }

  function initSqlJs(config?: unknown): Promise<SqlJsStatic>;
  export default initSqlJs;
  export { Database, Statement, initSqlJs };
}