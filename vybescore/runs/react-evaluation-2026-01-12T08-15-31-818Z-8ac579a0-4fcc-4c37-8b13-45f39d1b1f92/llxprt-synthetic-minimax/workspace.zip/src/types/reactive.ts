/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  // Track dependencies
  dependencies?: Set<Subject<unknown>>
  // Dirty flag for re-evaluation
  dirty?: boolean
  // Callbacks to trigger
  callbacks?: Set<() => void>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  // Observers that depend on this subject
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global state for tracking active observer during evaluation
let activeObserver: ObserverR | undefined = undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Track dependency relationship
export function subscribeSubject<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.add(observer)
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject as Subject<unknown>)
}

// Notify all observers of a subject change
export function notifySubject<T>(subject: Subject<T>): void {
  const observers = Array.from(subject.observers)
  
  for (const observer of observers) {
    updateObserver(observer as Observer<unknown>)
  }
}

// Update an observer by evaluating its function
export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  try {
    setActiveObserver(observer)
    
    // Clear dependencies to track new ones
    if (observer.dependencies) {
      observer.dependencies.clear()
    }
    
    // Re-evaluate the observer
    observer.value = observer.updateFn(observer.value)
    
    // Trigger callbacks
    if (observer.callbacks) {
      const callbacks = Array.from(observer.callbacks)
      for (const callback of callbacks) {
        try {
          callback()
        } catch (error) {
          console.error('Callback error:', error)
        }
      }
    }
  } finally {
    setActiveObserver(previous)
  }
}
