/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  Subject,
  getActiveObserver,
  setActiveObserver,
  subscribeSubject,
  notifySubject
} from '../types/reactive.js'

type UpdateFn<T> = (value?: T) => T

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
    dirty: true,
    callbacks: new Set()
  }
  
  let disposed = false
  
  // Create the callback function
  const callbackFn = () => {
    if (disposed) return undefined as T | undefined
    
    const previous = getActiveObserver()
    try {
      setActiveObserver(observer)
      const result = observer.updateFn(observer.value)
      observer.dirty = false
      return result
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Evaluate immediately to establish dependencies
  callbackFn()
  
  const unsubscribe = () => {
    disposed = true
    
    // Remove callback from active observer
    if (active && active.callbacks) {
      active.callbacks.delete(callbackFn)
    }
    
    // Clean up observer state
    observer.updateFn = () => undefined as T
    observer.value = undefined
    if (observer.dependencies) {
      observer.dependencies.clear()
    }
  }
  
  return unsubscribe
}
