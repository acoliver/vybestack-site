/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  notifySubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
    dirty: true
  }

  const computed: GetterFn<T> = () => {
    const previous = getActiveObserver()
    try {
      setActiveObserver(observer)
      
      // Clear dependencies to track new ones
      if (observer.dependencies) {
        observer.dependencies.clear()
      }
      
      // Always evaluate to ensure dependencies are tracked and default params work
      const newValue = observer.updateFn(observer.value)
      observer.value = newValue
      observer.dirty = false
      
      // Trigger callbacks for dependent observers
      if (observer.callbacks) {
        const callbacks = Array.from(observer.callbacks)
        for (const callback of callbacks) {
          callback()
        }
      }
      
      return observer.value!
    } finally {
      setActiveObserver(previous)
    }
  }

  return computed
}
