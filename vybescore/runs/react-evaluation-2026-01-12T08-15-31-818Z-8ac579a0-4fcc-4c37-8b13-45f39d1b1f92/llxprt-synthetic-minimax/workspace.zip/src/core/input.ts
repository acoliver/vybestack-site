/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  subscribeSubject,
  notifySubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Track dependency when accessed during reactive evaluation
    const observer = getActiveObserver()
    if (observer) {
      subscribeSubject(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Update value
    subject.value = nextValue
    // Mark all observers as dirty first
    const observers = Array.from(subject.observers)
    for (const observer of observers) {
      observer.dirty = true
    }
    // Then trigger update through the standard observer system
    notifySubject(subject)
    return subject.value
  }

  return [read, write]
}
