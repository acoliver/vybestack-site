/**
 * Capitalize the first character of each sentence, preserving spacing rules
 * - Capitalize first character after . ? !
 * - Insert exactly one space between sentences
 * - Collapse extra spaces while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }

  // First, normalize multiple spaces to single spaces (but preserve intentional spacing around sentences)
  // Split by sentence endings while keeping track of them
  const sentences = [];
  let currentSentence = '';
  let i = 0;

  while (i < text.length) {
    const char = text[i];
    
    // Check for sentence ending
    if (char === '.' || char === '!' || char === '?') {
      currentSentence += char;
      i++;
      
      // Check if this is an abbreviation (like "Mr." or "U.S.A.")
      // Look ahead to see if next non-space character is a lowercase letter
      let j = i;
      while (j < text.length && text[j] === ' ') j++;
      
      // If next char exists and is lowercase, this is likely an abbreviation
      if (j < text.length && /[a-z]/.test(text[j])) {
        // This is an abbreviation, continue the current sentence
        currentSentence += text.substring(i, j);
        i = j;
      } else {
        // This is a sentence ending
        sentences.push(currentSentence);
        currentSentence = '';
        
        // Skip spaces after sentence ending
        while (i < text.length && text[i] === ' ') i++;
      }
    } else {
      currentSentence += char;
      i++;
    }
  }
  
  // Add the last sentence
  if (currentSentence) {
    sentences.push(currentSentence);
  }

  // If no sentence endings found, just capitalize the first letter
  if (sentences.length === 0) {
    return text.charAt(0).toUpperCase() + text.substring(1);
  }

  // Capitalize each sentence
  const capitalizedSentences = sentences.map((sentence, index) => {
    // Find first non-space character
    let firstCharIndex = 0;
    while (firstCharIndex < sentence.length && sentence[firstCharIndex] === ' ') {
      firstCharIndex++;
    }
    
    if (firstCharIndex < sentence.length) {
      // Capitalize the first letter
      const before = sentence.substring(0, firstCharIndex);
      const firstChar = sentence[firstCharIndex];
      const after = sentence.substring(firstCharIndex + 1);
      return before + firstChar.toUpperCase() + after;
    }
    
    return sentence;
  });

  return capitalizedSentences.join(' ');
}

/**
 * Extract URLs from text
 * Return all detected URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // URL regex pattern
  // Matches http:// or https:// URLs
  const urlPattern = /\bhttps?:\/\/[^\s<>"')\]]+/gi;
  
  const matches = text.match(urlPattern);
  
  if (!matches) {
    return [];
  }

  // Remove trailing punctuation from URLs
  const urls = matches.map(url => {
    // Remove trailing punctuation: . , ; ! ? : ) ] }
    let cleanUrl = url.replace(/[.,;:!?)\]\}]+$/, '');
    return cleanUrl;
  });

  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https://
  // Use word boundary to avoid matching inside longer URLs or text
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite URLs:
 * - Upgrade http to https
 * - For /docs/ paths, move to docs.example.com subdomain
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Match URLs with http protocol and capture host and path
  const urlPattern = /\bhttp:\/\/([^\/\s<>"')\]]+)(\/[^\s<>"')\]]*)/gi;

  return text.replace(urlPattern, (match, host, path) => {
    // Always upgrade to https
    let newUrl = 'https://' + host;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or query strings
      const hasDynamicHints = 
        path.includes('cgi-bin') ||
        path.includes('?') ||
        path.includes('&') ||
        path.includes('=') ||
        path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$)/i);
      
      // If no dynamic hints, rewrite host
      if (!hasDynamicHints) {
        const docsHost = 'docs.' + host;
        newUrl = 'https://' + docsHost + path;
      } else {
        newUrl = 'https://' + host + path;
      }
    } else {
      newUrl = 'https://' + host + path;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings
 * Return 'N/A' when the format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day (1-31, with basic checks for month validity)
  if (day < 1 || day > 31) {
    return 'N/A';
  }

  // Basic month/day validation
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}