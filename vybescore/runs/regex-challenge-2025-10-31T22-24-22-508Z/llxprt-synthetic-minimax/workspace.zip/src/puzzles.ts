/**
 * Find words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Create a pattern to match words starting with prefix
  // \b ensures we match whole words
  const pattern = new RegExp(`\\b${escapeRegExp(prefix)}[a-zA-Z0-9_-]*\\b`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => lowerMatch === exception.toLowerCase());
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning
 * Use lookaheads/lookbehinds
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Use regex to find token preceded by a digit but not at start
  // Lookbehind: (?<=\d) - preceded by a digit
  // We also need to ensure it's not at the very beginning
  // Use a capture group to get the token
  
  // For each match, we need to check it's not at the start
  const results: string[] = [];
  
  // Create pattern with lookbehind for digit before token
  const pattern = new RegExp(`(?<=\\d)${escapeRegExp(token)}`, 'g');
  
  let match;
  while ((match = pattern.exec(text)) !== null) {
    // Check if the match position is not 0 (not at the start)
    if (match.index > 0) {
      results.push(match[0]);
    }
  }
  
  return results;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }

  const length = value.length;

  // Must be at least 10 characters
  if (length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must have at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences like "abab"
  // This means we shouldn't have patterns where two characters repeat
  // We need to check for sequences like "xyxy" where x and y are different
  for (let i = 0; i < length - 3; i++) {
    const seq = value.substring(i, i + 4);
    const firstTwo = seq.substring(0, 2);
    const lastTwo = seq.substring(2);
    
    // Check if it's a repetition like "xyxy" where x != y
    if (firstTwo === lastTwo && firstTwo[0] !== firstTwo[1]) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // Match IPv6 addresses
  // IPv6 format examples:
  // - x:x:x:x:x:x:x:x (full form)
  // - x::x (compressed with ::)
  // - ::x (starts with ::)
  // - x:: (ends with ::)
  // - :: (all zeros)
  
  // IPv6 addresses can have:
  // - 8 groups of 1-4 hex digits separated by :
  // - :: can compress one or more consecutive groups of zeros
  
  // Pattern explanation:
  // Start with optional hex digits, then optional ::, then more hex groups
  
  // This regex attempts to match IPv6 patterns while avoiding IPv4
  // We'll check for the :: shorthand and ensure it's not just IPv4
  
  const ipv6Pattern = /(^|[^a-zA-Z0-9])([a-f0-9:]+::[a-f0-9:]+)(?![0-9.])|(^|[^a-zA-Z0-9])([a-f0-9:]+::)(?![0-9.])|(^|[^a-zA-Z0-9])(::[a-f0-9:]+)(?![0-9.])|(^|[^a-zA-Z0-9])(::)(?![0-9.])|(^|[^a-zA-Z0-9])([a-f0-9]{1,4}:){7}[a-f0-9]{1,4}(?![0-9.])/gi;
  
  // Check for patterns with ::
  if (value.includes('::')) {
    // Make sure it's not an IPv4 address (contains .)
    if (value.includes('.')) {
      return false;
    }
    
    // Check for valid IPv6 format with ::
    const doubleColonPattern = /^[a-f0-9:]+::[a-f0-9:]*$/i;
    if (doubleColonPattern.test(value)) {
      return true;
    }
  }
  
  // Check for full 8-group IPv6 format
  // Format: x:x:x:x:x:x:x:x where each x is 1-4 hex digits
  const fullPattern = /^[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}$/i;
  
  // If it's all hex digits and colons and matches the pattern, it's IPv6
  if (/^[a-f0-9:]+$/i.test(value) && fullPattern.test(value)) {
    return true;
  }
  
  return false;
}

/**
 * Helper function to escape special regex characters
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}