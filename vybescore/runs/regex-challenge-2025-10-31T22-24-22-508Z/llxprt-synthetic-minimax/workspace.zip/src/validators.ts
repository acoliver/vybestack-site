export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses
 * Accept typical addresses such as name+tag@example.co.uk
 * Reject double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic structure check: must have @ and not start/end with @
  if (!email.includes('@') || email.startsWith('@') || email.endsWith('@')) {
    return false;
  }
  
  // Split local and domain parts
  const [localPart, domainPart] = email.split('@');
  
  // Local part cannot be empty
  if (!localPart || !domainPart) {
    return false;
  }
  
  // Check for double dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in local part
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Check for double dots in domain part
  if (domainPart.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in domain part
  if (domainPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Check domain structure - must have at least one dot
  if (!domainPart.includes('.')) {
    return false;
  }
  
  // Validate local part: allow letters, digits, and certain special chars
  const localRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~.-]+$/;
  if (!localRegex.test(localPart)) {
    return false;
  }
  
  // Validate domain part: allow letters, digits, dots, and hyphens
  // Must start and end with alphanumeric
  const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  if (!domainRegex.test(domainPart)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers
 * Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallow impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const phone = value.trim();
  
  // Check for extension if option is enabled
  let cleanPhone = phone;
  if (options?.allowExtensions) {
    const extMatch = phone.match(/(?:ext|ext\.?|extension)\s*(\d{1,5})$/i);
    if (extMatch) {
      cleanPhone = phone.substring(0, phone.lastIndexOf(extMatch[0])).trim();
    }
  }
  
  // Remove all non-digit characters except leading +
  const digits = phone.replace(/[^\d+]/g, '');
  
  // Handle +1 prefix
  let startIndex = 0;
  if (digits.startsWith('+1')) {
    startIndex = 2;
  } else if (digits.startsWith('1') && digits.length === 11) {
    startIndex = 1;
  }
  
  const number = digits.substring(startIndex);
  
  // Check length (must be exactly 10 digits)
  if (number.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check that all characters are digits
  if (!/^\d{10}$/.test(number)) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers
 * Handle landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space/hyphen characters for initial cleaning
  let phone = value.trim();
  
  // Remove common separators (spaces and hyphens)
  const cleaned = phone.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 (country code)
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Check for trunk prefix '0'
  let hasTrunkPrefix = false;
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.substring(1);
  }
  
  // Check for mobile indicator '9'
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // At this point, we should have area code + subscriber number
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }
  
  // Extract area code (first 2-4 digits, first digit must be 1-9)
  let areaCodeLength = 0;
  for (let i = 1; i <= Math.min(4, remaining.length - 6); i++) {
    const potentialAreaCode = remaining.substring(0, i);
    if (potentialAreaCode.length >= 2 && potentialAreaCode.length <= 4) {
      const firstDigit = potentialAreaCode.charAt(0);
      if (firstDigit >= '1' && firstDigit <= '9') {
        // Check remaining length for subscriber number
        const subscriberLength = remaining.length - i;
        if (subscriberLength >= 6 && subscriberLength <= 8) {
          areaCodeLength = i;
          break;
        }
      }
    }
  }
  
  if (areaCodeLength === 0) {
    return false;
  }
  
  // Validation rules:
  // - If no country code, must have trunk prefix
  // - If no mobile indicator and no country code, this is likely a landline
  // - If mobile indicator, it's a mobile
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // If has country code but no mobile indicator, it's ambiguous - need to check context
  // Landline: typically 2-4 digit area code + 6-8 digit subscriber
  // Mobile: 2-4 digit area code + 8 digit subscriber
  
  return true;
}

/**
 * Validate personal names
 * Allow unicode letters, accents, apostrophes, hyphens, spaces
 * Reject digits, symbols, and strange patterns
 */
export function isValidName(value: string): boolean {
  const trimmed = value.trim();
  
  // Cannot be empty
  if (!trimmed) {
    return false;
  }
  
  // Allow: unicode letters (including accents), apostrophes, hyphens, spaces
  // Pattern explanation:
  // ^ start of string
  // [^\d\s] any character except digits and whitespace - this is the base
  // Actually, we need to allow spaces, so let's use a different approach
  
  // Match pattern: start with a letter (with possible preceding marks/spaces for accents)
  // Allow apostrophes and hyphens within the name
  const nameRegex = /^[\p{L}\p{M}]+(?:[\s'-][\p{L}\p{M}]+)*$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Check for obviously invalid patterns
  // No digits
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // No consecutive special characters (like apostrophe-apostrophe or hyphen-hyphen)
  if (/['-]{2,}/.test(trimmed)) {
    return false;
  }
  
  // Cannot start or end with apostrophe or hyphen
  if (trimmed.startsWith("'") || trimmed.startsWith('-') || 
      trimmed.endsWith("'") || trimmed.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers
 * Check Visa/Mastercard/AmEx prefixes and lengths, run Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if empty
  if (!digits) {
    return false;
  }
  
  const length = digits.length;
  
  // Check valid lengths for major card types
  // Visa: 13, 16, 19
  // Mastercard: 16
  // AmEx: 15
  const isValidLength = 
    (length === 13 || length === 16 || length === 19) || // Visa
    (length === 16) || // Mastercard
    (length === 15); // AmEx
  
  if (!isValidLength) {
    return false;
  }
  
  // Check prefixes
  let isValidPrefix = false;
  
  // Visa: starts with 4
  if (digits.startsWith('4')) {
    isValidPrefix = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720
  else if ((length === 16) && (digits.startsWith('51') || digits.startsWith('52') || 
             digits.startsWith('53') || digits.startsWith('54') || digits.startsWith('55'))) {
    isValidPrefix = true;
  }
  else if (length === 16 && digits.length >= 4) {
    const first4 = parseInt(digits.substring(0, 4), 10);
    if (first4 >= 2221 && first4 <= 2720) {
      isValidPrefix = true;
    }
  }
  // AmEx: starts with 34 or 37
  else if (digits.startsWith('34') || digits.startsWith('37')) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Run Luhn checksum algorithm
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}