#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { ReportFormat, ReportOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: ReportFormat = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      format = formatValue as ReportFormat;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  return { dataFile, format, outputPath, includeTotals };
}

async function loadJsonData(filePath: string): Promise<unknown> {
  try {
    const fileContent = await readFile(filePath, 'utf-8');
    return JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.includes('JSON')) {
        console.error(`Error: Invalid JSON in file: ${filePath} - ${error.message}`);
      } else {
        console.error(`Error reading file: ${filePath} - ${error.message}`);
      }
    } else {
      console.error(`Error reading file: ${filePath}`);
    }
    process.exit(1);
  }
}

function renderReport(data: unknown, format: ReportFormat, options: ReportOptions): string {
  try {
    validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Invalid report data');
    }
    process.exit(1);
  }

  switch (format) {
    case 'markdown':
      return renderMarkdown.render(data, options);
    case 'text':
      return renderText.render(data, options);
    default:
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
  }
}

async function main(): Promise<void> {
  const { dataFile, format, outputPath, includeTotals } = parseArguments();
  
  const data = await loadJsonData(dataFile);
  const options: ReportOptions = { includeTotals };
  const output = renderReport(data, format, options);

  if (outputPath) {
    try {
      await writeFile(outputPath, output, 'utf-8');
      console.log(`Report saved to: ${outputPath}`);
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing to file: ${error.message}`);
      } else {
        console.error(`Error writing to file: ${outputPath}`);
      }
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

function writeFile(filePath: string, content: string, encoding: BufferEncoding): Promise<void> {
  return new Promise((resolve, reject) => {
    import('fs').then(fs => {
      fs.writeFile(filePath, content, encoding, (error) => {
        if (error) {
          reject(error);
        } else {
          resolve();
        }
      });
    }).catch(reject);
  });
}

main().catch((error) => {
  if (error instanceof Error) {
    console.error(`Unexpected error: ${error.message}`);
  } else {
    console.error('Unexpected error occurred');
  }
  process.exit(1);
});
