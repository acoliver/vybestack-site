import { ReportEntry } from './types.js';

export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function validateReportData(data: unknown): asserts data is import('./types.js').ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const { title, summary, entries } = data as Record<string, unknown>;

  if (typeof title !== 'string' || title.trim() === '') {
    throw new Error('Invalid report data: title must be a non-empty string');
  }

  if (typeof summary !== 'string' || summary.trim() === '') {
    throw new Error('Invalid report data: summary must be a non-empty string');
  }

  if (!Array.isArray(entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  if (entries.length === 0) {
    throw new Error('Invalid report data: entries cannot be empty');
  }

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i] as Record<string, unknown>;
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} must be an object`);
    }

    if (typeof entry.label !== 'string' || (entry.label as string).trim() === '') {
      throw new Error(`Invalid report data: entry at index ${i} must have a non-empty label`);
    }

    if (typeof entry.amount !== 'number' || isNaN(entry.amount as number)) {
      throw new Error(`Invalid report data: entry at index ${i} must have a valid number amount`);
    }

    if ((entry.amount as number) < 0) {
      throw new Error(`Invalid report data: entry at index ${i} must have a non-negative amount`);
    }
  }
}