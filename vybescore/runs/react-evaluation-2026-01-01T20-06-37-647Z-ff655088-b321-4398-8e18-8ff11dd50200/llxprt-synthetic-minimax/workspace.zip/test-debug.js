import { createInput, createComputed } from './src/index.js'

console.log('Testing reactive chain...')

const [input, setInput] = createInput(1)
console.log('Input set to 1')

const timesTwo = createComputed(() => {
  const result = input() * 2
  console.log(`timesTwo computed: ${result}`)
  return result
})
console.log('timesTwo computed created')

const timesThirty = createComputed(() => {
  const result = input() * 30
  console.log(`timesThirty computed: ${result}`)
  return result
})
console.log('timesThirty computed created')

const sum = createComputed(() => {
  const result = timesTwo() + timesThirty()
  console.log(`sum computed: ${result} (${timesTwo()} + ${timesThirty()})`)
  return result
})
console.log('sum computed created')

console.log('Initial sum:', sum())
console.log('Setting input to 3...')
setInput(3)
console.log('Final sum:', sum())