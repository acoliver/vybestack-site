/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Simple reactive core implementation
let currentComputation: object | null = null
let currentDependencies: Set<object> | null = null

export interface Signal<T> {
  value: T
  listeners: Set<() => void>
  equals?: EqualFn<T>
  dependents?: Set<object>
}

export interface Computed<T> {
  fn: () => T
  value: T
  dirty: boolean
  listeners: Set<() => void>
  dependencies: Set<Signal<object>>
  listener?: () => void
  dependents?: Set<object>
}

export interface Effect<T> {
  fn: () => T
  disposed: boolean
  dependencies: Set<object>
  currentValue?: T
  listener?: () => void
  dependents?: Set<object>
}

export function createSignal<T>(initialValue: T, equals?: EqualFn<T>): Signal<T> {
  return {
    value: initialValue,
    listeners: new Set(),
    equals,
    dependents: new Set()
  }
}

export function readSignal<T>(signal: Signal<T>): T {
  // Track dependency
  if (currentComputation && currentDependencies) {
    currentDependencies.add(signal)
    
    // Add current computation to signal's dependents
    signal.dependents!.add(currentComputation)
    
    // Add listener to mark computation as dirty
    const markDirtyListener = () => {
      if (currentComputation && typeof currentComputation.dirty === 'boolean') {
        currentComputation.dirty = true
      }
    }
    signal.listeners.add(markDirtyListener)
  }
  return signal.value
}

export function writeSignal<T>(signal: Signal<T>, newValue: T): void {
  const prevValue = signal.value
  
  if (signal.equals && signal.equals(prevValue, newValue)) {
    return
  }

  signal.value = newValue
  
  // Notify all dependent computations
  if (signal.dependents) {
    const dependents = Array.from(signal.dependents)
    for (const dependent of dependents) {
      if (dependent && typeof dependent.dirty === 'boolean') {
        dependent.dirty = true
      }
    }
  }
  
  // Create a copy of listeners to avoid issues with modifications during iteration
  const listeners = Array.from(signal.listeners)
  
  // Notify all dependent computations by calling their listeners
  for (const listener of listeners) {
    if (typeof listener === 'function') {
      try {
        listener()
      } catch {
        // Ignore errors
      }
    }
  }
}

export function createComputedSignal<T>(fn: () => T, initialValue?: T): Computed<T> {
  const computed: Computed<T> = {
    fn,
    value: initialValue as T,
    dirty: true,
    listeners: new Set(),
    dependencies: new Set(),
    dependents: new Set()
  }

  // Set up listener for computed signal
  const computedListener = () => {
    if (computed.dirty) {
      const prevComputation = currentComputation
      const prevDependencies = currentDependencies
      
      try {
        currentComputation = computed
        currentDependencies = computed.dependencies
        computed.value = computed.fn()
        computed.dirty = false
      } finally {
        currentComputation = prevComputation
        currentDependencies = prevDependencies
      }
      
      // Notify listeners of this computed value
      const listeners = Array.from(computed.listeners)
      for (const listener of listeners) {
        if (typeof listener === 'function') {
          try {
            listener()
          } catch {
            // Ignore errors
          }
        }
      }
    }
  }
  
  computed.listener = computedListener

  // Initial evaluation
  const prevComputation = currentComputation
  const prevDependencies = currentDependencies
  
  try {
    currentComputation = computed
    currentDependencies = computed.dependencies
    computed.value = fn()
    computed.dirty = false
  } finally {
    currentComputation = prevComputation
    currentDependencies = prevDependencies
  }

  // Register this computed signal as a dependent of all dependencies
  for (const dependency of computed.dependencies) {
    dependency.dependents!.add(computed)
    
    const markDirtyListener = () => {
      computed.dirty = true
    }
    dependency.listeners.add(markDirtyListener)
  }

  return computed
}

export function readComputedSignal<T>(computed: Computed<T>): T {
  // Re-evaluate if dirty
  if (computed.dirty && computed.listener) {
    computed.listener()
  }
  
  // Track as dependency
  if (currentComputation && currentDependencies) {
    currentDependencies.add(computed)
    computed.dependents!.add(currentComputation)
    computed.listeners.add(currentComputation)
  }

  return computed.value
}

export function createEffect<T>(effectFn: () => T): Effect<T> {
  const effect: Effect<T> = {
    fn: effectFn,
    disposed: false,
    dependencies: new Set(),
    currentValue: undefined,
    dependents: new Set()
  }

  const prevComputation = currentComputation
  const prevDependencies = currentDependencies

  try {
    currentComputation = effect
    currentDependencies = effect.dependencies
    effect.currentValue = effectFn()
  } finally {
    currentComputation = prevComputation
    currentDependencies = prevDependencies
  }

  // Subscribe to dependencies and make them trigger re-evaluation
  const effectListener = () => {
    if (effect.disposed) return
    try {
      effect.currentValue = effectFn()
    } catch {
      // Ignore errors
    }
  }
  
  effect.listener = effectListener
  
  for (const signal of effect.dependencies) {
    if (signal.dependents) {
      signal.dependents.add(effect)
    }
    signal.listeners.add(effectListener)
  }

  return effect
}

export function disposeEffect(effect: Effect<object>): void {
  effect.disposed = true
  effect.dependencies.clear()
  
  // Remove listeners from dependencies
  if (effect.listener) {
    for (const signal of effect.dependencies) {
      signal.listeners.delete(effect.listener)
      if (signal.dependents) {
        signal.dependents.delete(effect)
      }
    }
  }
}

// Main API functions
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const signal = createSignal(value, typeof equal === 'function' ? equal : undefined)

  const read: GetterFn<T> = () => {
    return readSignal(signal)
  }

  const write: SetterFn<T> = (nextValue) => {
    writeSignal(signal, nextValue)
    return nextValue
  }

  return [read, write]
}

export function createComputed<T>(
  updateFn: () => T,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const computed = createComputedSignal(updateFn, value)

  const computedFn: GetterFn<T> = () => {
    const result = readComputedSignal(computed)
    return result
  }

  return computedFn
}

export function createCallback<T>(updateFn: () => T, _value?: T): UnsubscribeFn {
  const effect = createEffect(() => {
    updateFn()
    return _value
  })

  return () => {
    disposeEffect(effect)
  }
}

// Legacy compatibility
export type SubjectR = { name?: string; observer: Effect<object> | undefined }
export type SubjectV<T> = { value: T; equalFn?: EqualFn<T> }
export type SubjectLegacy<T> = SubjectR & SubjectV<T> & Signal<T>
export type Subject<T> = SubjectLegacy<T>
export type ObserverR = { name?: string }
export type ObserverV<T> = { value?: T; updateFn: UpdateFn<T> }
export type ObserverLegacy<T> = ObserverR & ObserverV<T> & Effect<T>
export type Observer = Effect<object>
