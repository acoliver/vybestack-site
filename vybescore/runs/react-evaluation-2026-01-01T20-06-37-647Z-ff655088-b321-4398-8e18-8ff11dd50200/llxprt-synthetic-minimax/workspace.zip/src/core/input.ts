/**
 * Input closure implementation for reactive primitives.
 */

import {
  createInput
} from '../types/reactive.js'

export { createInput }
