/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: () => T, _value?: T): UnsubscribeFn {
  let disposed = false
  
  // Simple effect that executes the callback function
  const executeCallback = () => {
    if (disposed) return
    try {
      updateFn()
    } catch {
      // Ignore errors in callbacks
    }
  }
  
  // Execute initially
  executeCallback()
  
  return () => {
    if (disposed) return
    disposed = true
  }
}
