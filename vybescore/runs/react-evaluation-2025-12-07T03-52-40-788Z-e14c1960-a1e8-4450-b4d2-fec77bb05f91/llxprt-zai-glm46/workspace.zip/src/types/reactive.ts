/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  deps?: Set<Subject<unknown>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global tracking state
let activeObserver: Observer<unknown> | undefined
let shouldTrack = true

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function pauseTracking(): void {
  shouldTrack = false
}

export function enableTracking(): void {
  shouldTrack = true
}

export function track(subject: Subject<unknown>): void {
  if (!shouldTrack || activeObserver === undefined) {
    return
  }
  
  if (!activeObserver.deps) {
    activeObserver.deps = new Set()
  }
  
  activeObserver.deps.add(subject)
  subject.observers.add(activeObserver)
}

export function updateObserver<T>(observer: Observer<T>): void {
  observer.value = observer.updateFn(observer.value)
}

export function trigger<T>(subject: Subject<T>): void {
  // Create a copy to avoid issues with observers being added/removed during iteration
  const observers = Array.from(subject.observers)
  
  for (const observer of observers) {
    // Check if observer is still in the subject (might have been removed during iteration)
    // And also check if observer has been disposed (for callbacks)
    if (subject.observers.has(observer) && !isDisposed(observer)) {
      pauseTracking()
      try {
        // Try-catch around observer updateFn to handle errors gracefully
        try {
          observer.value = observer.updateFn(observer.value)
        } catch (error) {
          console.error('Error in observer update function:', error)
        }
      } finally {
        enableTracking()
      }
    }
  }
}

// Helper function to check if an observer has been disposed
function isDisposed(observer: Observer<unknown>): boolean {
  // Check if observer has a disposed property (added to callback observers)
  const callbackObserver = observer as Observer<unknown> & { disposed?: boolean }
  if (callbackObserver.disposed === true) {
    return true
  }
  
  // Fallback: check if observer has no dependencies (indicates cleanup)
  return !observer.deps || observer.deps.size === 0
}

export function addObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers.add(observer)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  trigger(subject)
}