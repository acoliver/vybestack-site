/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  track,
  trigger,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { registerSubject } from './callback.js'

function getDefaultEqualFn<T>(equal: boolean | EqualFn<T> | undefined): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'function') return equal
  return equal ? (lhs: T, rhs: T) => lhs === rhs : undefined
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = getDefaultEqualFn(_equal)
  
  const s: Subject<unknown> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: equalFn as ((lhs: unknown, rhs: unknown) => boolean) | undefined,
  }
  
  // Register this subject for callback cleanup
  registerSubject(s)

  const read: GetterFn<T> = () => {
    track(s)
    return s.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.value === undefined || !equalFn || !equalFn(s.value as T, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      trigger(s)
    }
    return s.value as T
  }

  return [read, write]
}