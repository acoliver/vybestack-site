/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, Subject } from '../types/reactive.js'

// Global registry to track all active subjects for cleanup
const allSubjects = new Set<Subject<unknown>>()

// Function to register a subject for tracking
export function registerSubject(subject: Subject<unknown>): void {
  allSubjects.add(subject)
}

// Function to unregister a subject
export function unregisterSubject(subject: Subject<unknown>): void {
  allSubjects.delete(subject)
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Use unknown Observer for compatibility
  const observer: Observer<unknown> & { disposed: boolean } = {
    value,
    deps: new Set(),
    updateFn: (prevValue?: unknown) => {
      // Check if disposed before executing
      if (disposed) {
        return prevValue
      }
      
      // Clear previous dependencies
      if (observer.deps) {
        observer.deps.forEach(dep => {
          dep.observers.delete(observer)
        })
        observer.deps.clear()
      }
      
      // Set this callback as active observer to track dependencies
      setActiveObserver(observer)
      try {
        const newValue = updateFn(prevValue as T)
        return newValue
      } catch (error) {
        console.error('Error in callback update function:', error)
        return prevValue
      } finally {
        setActiveObserver(undefined)
      }
    },
    disposed: false
  }
  
  const execute = () => {
    if (disposed) return
    try {
      observer.value = observer.updateFn(observer.value)
    } catch (error) {
      console.error('Error executing callback:', error)
    }
  }
  
  // Execute the callback immediately to track dependencies
  execute()
  
  const unsubscribe: UnsubscribeFn = () => {
    disposed = true
    observer.disposed = true
    
    // Clean up dependencies - remove this observer from all dependency subjects
    if (observer.deps) {
      observer.deps.forEach(dep => {
        dep.observers.delete(observer)
      })
      observer.deps.clear()
    }
    
    // Also search through all registered subjects to remove this observer
    allSubjects.forEach(subject => {
      if (subject.observers.has(observer)) {
        subject.observers.delete(observer)
      }
    })
  }
  
  return unsubscribe
}