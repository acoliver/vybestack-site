/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  getActiveObserver,
  setActiveObserver,
  track,
  trigger,
  Options
} from '../types/reactive.js'
import { registerSubject } from './callback.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean) | undefined,
  options?: Options
): GetterFn<T> {
  // Compute values ignore equalFn for reactive consistency
  let currentValue: T | undefined = value
  
  // Create a subject to track observers of this computed value
  const subject: Subject<unknown> = {
    name: options?.name,
    observers: new Set(),
    value: currentValue as unknown,
    equalFn: undefined, // Computed values should always trigger their observers
  }
  
  // Register this subject for callback cleanup
  registerSubject(subject)
  
  // Create an observer that represents this computed value
  const observer: Observer<unknown> = {
    value: currentValue as unknown,
    deps: new Set(),
    updateFn: () => {
      // When dependencies change, recompute
      const newValue = recompute()
      
      // Only trigger if we have observers
      if (subject.observers.size > 0) {
        trigger(subject)
      }
      
      return newValue as unknown
    },
  }

  // Function to recompute the value
  const recompute = (): T => {
    // Clear previous dependencies
    if (observer.deps) {
      observer.deps.forEach(dep => {
        dep.observers.delete(observer)
      })
      observer.deps.clear()
    }
    
    // Set this computed as active to track new dependencies
    setActiveObserver(observer)
    try {
      const newValue = updateFn(currentValue)
      
      // Update internal values
      currentValue = newValue
      observer.value = newValue as unknown
      subject.value = newValue as unknown
      
      return currentValue
    } finally {
      setActiveObserver(undefined)
    }
  }

  const compute = (): T => {
    // First track this computed as a dependency for any active observer
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      track(subject)
    }
    
    // Always recompute to get the latest value from dependencies
    return recompute()
  }

  return compute
}