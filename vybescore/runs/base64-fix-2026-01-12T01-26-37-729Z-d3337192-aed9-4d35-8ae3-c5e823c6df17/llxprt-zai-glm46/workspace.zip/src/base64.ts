
/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}


/**
 * Regular expression to validate Base64 input.
 * Matches strings containing only valid Base64 characters: A-Z, a-z, 0-9, +, /, and = (for padding)
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding).
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Empty input is invalid
  if (trimmed.length === 0) {
    throw new Error('Invalid Base64 input: empty input');
  }

  // Check if input contains only valid Base64 characters and valid padding
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check if padding appears in the middle (only allowed at the end)
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Ensure all padding chars are at the end
    const afterPadding = trimmed.substring(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: padding in the middle');
    }
    // Max 2 padding chars allowed
    if (afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }

  // Check character count: without padding, must be multiple of 4
  // With padding, the non-padded part must still make sense
  // Actually, let's NOT enforce the length restriction since Node.js accepts unpadded base64
  // Instead, we'll rely on the decode attempt to catch truly invalid data

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // For invalid base64, Node.js often produces non-printable or unexpected output
    // We need to validate that the decoded bytes are valid UTF-8
    // First, check if we can get back the original by re-encoding
    // This is a good sanity check for valid base64
    
    const utf8String = buffer.toString('utf8');
    
    // Re-encode to verify the base64 was valid
    // If the re-encoded string doesn't match (normalized for padding), the input was likely invalid
    const normalizedInput = normalizePadding(trimmed);
    const reEncoded = Buffer.from(utf8String, 'utf8').toString('base64');
    const reEncodedNormalized = normalizePadding(reEncoded);
    
    if (normalizedInput !== reEncodedNormalized) {
      throw new Error('Invalid Base64 input: failed validation');
    }

    return utf8String;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Invalid Base64 input: failed to decode');
  }
}

/**
 * Normalize padding for comparison by removing it.
 */
function normalizePadding(base64: string): string {
  return base64.replace(/=+$/, '');
}
