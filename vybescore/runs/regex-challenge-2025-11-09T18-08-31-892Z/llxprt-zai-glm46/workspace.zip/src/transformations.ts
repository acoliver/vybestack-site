/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Split into sentences using sentence delimiters
  const sentences = result.split(/([.?!])/);
  
  let capitalizedText = '';
  let needsCapitalization = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (/[.?!]/.test(part)) {
      // This is a delimiter, add it and set flag to capitalize next part
      capitalizedText += part;
      needsCapitalization = true;
    } else if (part.trim()) {
      // This is content, capitalize if needed
      const trimmed = part.trim();
      if (needsCapitalization) {
        capitalizedText += trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        needsCapitalization = false;
      } else {
        capitalizedText += trimmed;
      }
    }
    
    // Add space after punctuation if there's more content
    if (i < sentences.length - 1) {
      const nextPart = sentences[i + 1];
      if (/[.?!]/.test(part) && nextPart && nextPart.trim()) {
        capitalizedText += ' ';
      }
    }
  }
  
  return capitalizedText;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex that matches http/https protocols and domain names
  // Also matches www URLs without explicit protocol
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/https?:\/\/([^\/]+)(\/[^\s]*)/g, (match, host, path) => {
    // Always upgrade to https
    let result = 'https://' + host;
    
    // Check if we should rewrite the host for docs paths
    if (path && path.startsWith('/docs/')) {
      // Skip host rewrite if path contains dynamic hints or legacy extensions
      const hasDynamicHints = /cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        result = 'https://docs.' + host;
      }
    }
    
    return result + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Basic validation for day/month combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified)
  const yearNum = parseInt(year, 10);
  const isLeapYear = yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0);
  if (isLeapYear) daysInMonth[1] = 29;
  
  // Validate day is within range for the month
  if (dayNum > daysInMonth[monthNum - 1]) return 'N/A';
  
  return year;
}
