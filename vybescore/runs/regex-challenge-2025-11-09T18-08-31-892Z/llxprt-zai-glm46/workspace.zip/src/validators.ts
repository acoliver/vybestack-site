export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject double dots, trailing dots, domains with underscores
  if (!value || /\.\.|_/.test(value.split('@')[1]) || value.endsWith('.')) {
    return false;
  }
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number) or 11 with country code
  if (digits.length < 10 || digits.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digits.length === 11 && !digits.startsWith('1')) return false;
  
  // Extract area code (first 3 digits after optional country code)
  const areaCodeStart = digits.length === 11 ? 1 : 0;
  const areaCode = digits.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Support common formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, starting 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, trunkPrefix, , areaCode, subscriber] = match;
  
  // If no country code, trunk prefix is required
  if (!countryCode && !trunkPrefix) return false;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;
  
  // Reject digits, symbols, and X Æ A-12 style names
  if (/\d|[@#$%^&*()_+=\[\]{}|\:";<>,.?/~`]/.test(value)) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and dashes
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if only digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d\d|7[01]\d|720)\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type
  const isValidLength = visaRegex.test(cleanNumber) || mastercardRegex.test(cleanNumber) || amexRegex.test(cleanNumber);
  
  if (!isValidLength) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}
