#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { exit, stderr } from 'node:process';
import type { ReportData, RenderOptions, ReportEntry } from '../types.js';
import { getFormatter } from '../formatters.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 3) {
    stderr.write('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]\n');
    exit(1);
  }

  let inputFilePath: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (i === 2 && !arg.startsWith('--')) {
      inputFilePath = arg;
    } else if (arg === '--format' && i + 1 < args.length) {
      format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!inputFilePath) {
    stderr.write('Error: Input file path is required\n');
    exit(1);
  }

  if (!format) {
    stderr.write('Error: --format is required\n');
    exit(1);
  }

  return {
    inputFile: inputFilePath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string' || !obj.title.trim()) {
    throw new Error('Invalid report data: Missing or empty "title" field');
  }

  if (typeof obj.summary !== 'string' || !obj.summary.trim()) {
    throw new Error('Invalid report data: Missing or empty "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: "entries" must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: Entry ${i + 1} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error(`Invalid report data: Entry ${i + 1} missing or empty "label" field`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid report data: Entry ${i + 1} has invalid "amount" field`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as ReportEntry[],
  };
}

function main() {
  try {
    const args = process.argv;
    const { inputFile, format, outputPath, includeTotals } = parseArguments(args);

    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = readFileSync(inputFile, 'utf8');
    } catch (error) {
      stderr.write(`Error: Could not read file "${inputFile}"\n`);
      exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      stderr.write(`Error: Invalid JSON in file "${inputFile}"\n`);
      stderr.write(`${(error as Error).message}\n`);
      exit(1);
    }

    // Validate data
    const reportData = validateReportData(jsonData);

    // Get formatter
    let formatter;
    try {
      formatter = getFormatter(format);
    } catch (error) {
      stderr.write(`Error: ${(error as Error).message}\n`);
      exit(1);
    }

    // Render report
    const options: RenderOptions = { includeTotals };
    const output = formatter.render(reportData, options);

    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf8');
      } catch (error) {
        stderr.write(`Error: Could not write to output file "${outputPath}"\n`);
        exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    stderr.write(`Error: ${(error as Error).message}\n`);
    exit(1);
  }
}

main();
