import type { Formatter } from './types.js';
import { markdownFormatter } from './formats/markdown.js';
import { textFormatter } from './formats/text.js';

export const formatters: Record<string, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export function getFormatter(format: string): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}