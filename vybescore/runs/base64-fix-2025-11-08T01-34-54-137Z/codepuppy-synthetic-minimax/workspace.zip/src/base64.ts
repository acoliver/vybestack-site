
/**
 * Validate if a string contains proper Base64 format according to RFC 4648
 */
function isValidBase64(input: string): boolean {
  // Check for valid characters only
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Length must be multiple of 4
  if (input.length % 4 !== 0) {
    return false;
  }
  
  // Padding rules: if present, must be at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be at the end
    if (paddingIndex < input.length - 2) {
      return false;
    }
    // Check for proper padding sequences
    const padding = input.slice(paddingIndex);
    return padding === '=' || padding === '==';
  }
  
  return true;
}

/**
 * Normalize padding by adding appropriate padding if missing
 */
function normalizePadding(input: string): string {
  // If input already has padding, return as-is
  if (input.includes('=')) {
    return input;
  }
  
  // Calculate needed padding
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  return input + '='.repeat(paddingNeeded);
}

/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Base64 input cannot be empty');
  }
  
  // Normalize padding: add padding if missing
  const normalized = normalizePadding(input);
  
  if (!isValidBase64(normalized)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}