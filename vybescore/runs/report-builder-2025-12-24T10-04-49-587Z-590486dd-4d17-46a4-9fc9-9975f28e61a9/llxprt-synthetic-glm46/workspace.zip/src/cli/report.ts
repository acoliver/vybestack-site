#!/usr/bin/env node

import { parseCliArgs } from '../utils/args.js';
import { validateAndParseJson } from '../utils/validation.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { writeFileSync } from 'node:fs';

const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText
};

function main(): void {
  try {
    const argv = process.argv.slice(2);
    const options = parseCliArgs(argv);
    
    const reportData = validateAndParseJson(options.inputFile);
    
    const renderer = formatRenderers[options.format as keyof typeof formatRenderers];
    if (!renderer) {
      console.error(`Unsupported format: ${options.format}`);
      process.exit(1);
      return;
    }
    
    const renderedOutput = renderer(reportData, { includeTotals: options.includeTotals });
    
    if (options.output) {
      writeFileSync(options.output, renderedOutput, 'utf8');
      console.log(`Report written to ${options.output}`);
    } else {
      console.log(renderedOutput);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { main };
