export interface CliOptions {
  format: string;
  output?: string;
  includeTotals?: boolean;
  inputFile: string;
}

export function parseCliArgs(argv: string[]): CliOptions {
  const result: CliOptions = {
    format: '',
    inputFile: ''
  };
  
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        throw new Error('Missing value for --format');
      }
      result.format = argv[++i];
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        throw new Error('Missing value for --output');
      }
      result.output = argv[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('-') && !result.inputFile) {
      result.inputFile = arg;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (result.inputFile) {
      throw new Error('Multiple input files specified');
    }
  }
  
  if (!result.inputFile) {
    throw new Error('Input file is required');
  }
  
  if (!result.format) {
    throw new Error('--format is required');
  }
  
  if (!['markdown', 'text'].includes(result.format)) {
    throw new Error(`Unsupported format: ${result.format}`);
  }
  
  return result;
}