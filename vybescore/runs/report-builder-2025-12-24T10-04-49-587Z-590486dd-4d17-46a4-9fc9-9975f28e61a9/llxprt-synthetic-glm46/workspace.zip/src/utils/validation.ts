import type { ReportData, ReportEntry } from '../types.js';
import { readFileSync } from 'node:fs';

export function validateAndParseJson(jsonPath: string): ReportData {
  let jsonContent: string;
  
  try {
    jsonContent = readFileSync(jsonPath, 'utf8');
  } catch (error) {
    throw new Error(`Failed to read file "${jsonPath}": ${(error as Error).message}`);
  }
  
  let data: unknown;
  
  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    throw new Error(`Failed to parse JSON in "${jsonPath}": ${(error as Error).message}`);
  }
  
  if (!data || typeof data !== 'object') {
    throw new Error(`Invalid JSON structure in "${jsonPath}": expected object`);
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string' || obj.title.trim() === '') {
    throw new Error(`Invalid or missing title in "${jsonPath}"`);
  }
  
  if (typeof obj.summary !== 'string' || obj.summary.trim() === '') {
    throw new Error(`Invalid or missing summary in "${jsonPath}"`);
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error(`Invalid or missing entries array in "${jsonPath}"`);
  }
  
  const entries = obj.entries as unknown[];
  if (entries.length === 0) {
    throw new Error(`Entries array cannot be empty in "${jsonPath}"`);
  }
  
  const validatedEntries: ReportEntry[] = [];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i} in "${jsonPath}": expected object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || entryObj.label.trim() === '') {
      throw new Error(`Invalid or missing label in entry at index ${i} in "${jsonPath}"`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid or missing amount in entry at index ${i} in "${jsonPath}"`);
    }
    
    validatedEntries.push({
      label: entryObj.label,
      amount: entryObj.amount
    });
  }
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries: validatedEntries
  };
}