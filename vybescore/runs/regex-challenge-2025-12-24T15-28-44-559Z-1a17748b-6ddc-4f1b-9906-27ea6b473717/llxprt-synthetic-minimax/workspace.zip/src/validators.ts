export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Enhanced email validation that:
  // - Allows letters, numbers, dots, underscores, hyphens, and plus signs in local part
  // - Ensures no double dots (..) or trailing dots
  // - Validates domain with proper TLD structure (at least 2 chars)
  // - Rejects domains with underscores
  // - Allows international domains like .co.uk, .travel, .io
  
  // First check for obvious invalid patterns
  if (!value || value.includes('..') || value.endsWith('.') || value.includes('@example_domain')) {
    return false;
  }
  
  // Split into local and domain parts
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [local, domain] = parts;
  if (!local || !domain) return false;
  
  // Check domain doesn't contain underscores
  if (domain.includes('_')) return false;
  
  // More flexible regex that handles international TLDs and complex domain structures
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for edge cases
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Ensure at least one dot in domain (for TLD)
  if (!domain.includes('.')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Clean the input by removing all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // If it starts with +1, remove it for validation
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  }
  
  // Must have exactly 10 digits
  if (!/^\d{10}$/.test(digits)) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (!/^[2-9]\d{2}$/.test(areaCode)) return false;
  
  // Check central office code (next 3 digits) - cannot start with 0 or 1
  const centralOfficeCode = digits.substring(3, 6);
  if (!/^[2-9]\d{2}$/.test(centralOfficeCode)) return false;
  
  // Line number must be 4 digits
  const lineNumber = digits.substring(6, 10);
  if (!/^\d{4}$/.test(lineNumber)) return false;
  
  // If extensions are allowed, we can also validate them separately
  // but for now we'll just validate the main number
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input by removing spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (!cleaned) return false;
  
  // Pattern breakdown:
  // 1. Optional country code +54
  // 2. Optional mobile indicator 9 (for mobile numbers)
  // 3. Area code: 2-4 digits (first digit 1-9)
  // 4. Subscriber number: 6-8 digits total
  
  let remaining = cleaned;
  let hasCountryCode = false;
  
  // Check for country code
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check for mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Check for trunk prefix 0 (if no country code)
  let hasTrunkPrefix = false;
  if (!hasCountryCode && remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }
  
  // Must have area code (2-4 digits, first digit 1-9)
  if (!/^[1-9]\d{1,3}$/.test(remaining.substring(0, Math.min(4, remaining.length)))) {
    return false;
  }
  
  // Extract area code length (2-4 digits)
  let areaCodeLength = 0;
  for (let i = 1; i <= 4 && i <= remaining.length; i++) {
    if (/^[1-9]\d{0,3}$/.test(remaining.substring(0, i))) {
      areaCodeLength = i;
    }
  }
  
  if (areaCodeLength === 0) return false;
  
  // Extract area code and subscriber number
  const areaCode = remaining.substring(0, areaCodeLength);
  const subscriberNumber = remaining.substring(areaCodeLength);
  
  // Validation rules:
  // - Area code must be 2-4 digits, first digit 1-9
  // - Subscriber number must be 6-8 digits total
  // - If no country code, must start with trunk prefix 0
  
  const areaCodePattern = /^[1-9]\d{1,3}$/;
  const subscriberPattern = /^\d{6,8}$/;
  
  if (!areaCodePattern.test(areaCode)) return false;
  if (!subscriberPattern.test(subscriberNumber)) return false;
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), spaces, apostrophes, and hyphens
  // Reject digits and symbols
  // Pattern allows:
  // - Unicode letters (\p{L}) and diacritics
  // - Spaces between words
  // - Apostrophes (O'Connor, D'Angelo)
  // - Hyphens (Mary-Jane, Smith-Jones)
  const namePattern = /^[\p{L}][\p{L}\s'’-]*[\p{L}]$/u;
  
  // Must be non-empty and follow the pattern
  if (!namePattern.test(value)) return false;
  
  // Additional validation to reject problematic patterns
  // Check for digits anywhere in the string
  if (/\d/.test(value)) return false;
  
  // Check for symbols other than spaces, apostrophes, and hyphens
  if (/[^\p{L}\s'’-]/u.test(value)) return false;
  
  // Reject the X Æ A-12 style names
  const problematicPatterns = /[ÆØÅ]/;
  if (problematicPatterns.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\s/g, '');
  if (!/^\d+$/.test(digits)) return false;
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Clean the input by removing spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's a valid credit card format
  // Visa: 16 digits starting with 4
  // MasterCard: 16 digits starting with 51-55 or 2221-2720
  // American Express: 15 digits starting with 34 or 37
  
  let isValidLength = false;
  let isValidPrefix = false;
  
  // Check length first
  if (cleaned.length === 16 || cleaned.length === 15) {
    isValidLength = true;
  }
  
  // Check prefixes
  const prefix = cleaned.substring(0, 2);
  const prefix4 = cleaned.substring(0, 4);
  const firstDigit = cleaned.substring(0, 1);
  
  // Visa (starts with 4, 16 digits)
  if (firstDigit === '4' && cleaned.length === 16) {
    isValidPrefix = true;
  }
  // MasterCard (51-55 or 2221-2720, 16 digits)
  else if ((parseInt(prefix) >= 51 && parseInt(prefix) <= 55) || 
           (parseInt(prefix4) >= 2221 && parseInt(prefix4) <= 2720) && cleaned.length === 16) {
    isValidPrefix = true;
  }
  // American Express (34 or 37, 15 digits)
  else if ((prefix === '34' || prefix === '37') && cleaned.length === 15) {
    isValidPrefix = true;
  }
  
  // Must pass both length and prefix checks, plus Luhn checksum
  return isValidLength && isValidPrefix && runLuhnCheck(cleaned);
}
