/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // Word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const lowercaseWord = word.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseWord === exception.toLowerCase()
    );
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use regex to find token that appears after a digit
  // Use lookbehind to ensure token is preceded by a digit
  const pattern = new RegExp(`(?<=\\d)${token}`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Find the position where the digit is (right before this match)
    const matchStart = match.index;
    const digitPos = matchStart - 1;
    
    // Make sure we're not at the start of string and the previous character is a digit
    if (digitPos >= 0 && /\d/.test(text.charAt(digitPos))) {
      // Extract from the digit to the end of the token
      const fullMatch = text.substring(digitPos, matchStart + token.length);
      matches.push(fullMatch);
    }
    
    // Move forward to avoid infinite loop with zero-width matches
    if (pattern.lastIndex === match.index) {
      pattern.lastIndex++;
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-={}[\]:|;"'<>.,?/]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab", "abcabc", etc.
  // This pattern looks for any sequence of 2+ characters that repeats immediately
  // but excludes single character repeats like "ss"
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses while ensuring IPv4-only strings return false
  
  // Check for any IPv4 pattern first - if found, we should not return true for pure IPv4
  const ipv4Pattern = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check for full 8-group IPv6 (8 groups of 1-4 hex digits separated by colons)
  const fullIpv6Pattern = /\b[a-fA-F0-9]{1,4}(:[a-fA-F0-9]{1,4}){7}\b/;
  
  // Check for compressed IPv6 with :: (shorthand notation)
  const compressedIpv6Pattern = /\b[a-fA-F0-9]{0,4}::(?:[a-fA-F0-9]{0,4}:){0,6}[a-fA-F0-9]{0,4}\b/;
  
  // Check for :: at start, middle, or end
  const doubleColonPattern = /::/;
  
  // Combined IPv6 detection
  const hasIpv6 = fullIpv6Pattern.test(value) || 
                  (doubleColonPattern.test(value) && compressedIpv6Pattern.test(value));
                  
  // If the string contains only IPv4, return false
  if (ipv4Pattern.test(value) && !hasIpv6) return false;
  
  return hasIpv6;
}
