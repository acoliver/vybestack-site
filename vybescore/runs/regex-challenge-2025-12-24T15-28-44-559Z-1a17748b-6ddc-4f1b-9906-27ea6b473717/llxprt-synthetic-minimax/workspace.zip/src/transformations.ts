/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize whitespace to single spaces
  const normalized = text.replace(/\s+/g, ' ');
  
  // Capitalize the first character of the entire text
  let result = normalized;
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
// Use regex to find sentence boundaries after punctuation (.!?), handling both spaced and unspaced cases
  // This pattern captures punctuation, optional whitespace, and the next letter to capitalize
  const sentencePattern = /([.!?])(\s*)([a-zà-ÿ])/gi;

  // Replace with: punctuation + (ensure at least one space) + capitalized letter
  return result.replace(sentencePattern, (match, punct, space, letter) => {
    // Ensure there's at least one space after punctuation
    const spaces = space.length > 0 ? space : ' ';
    return punct + spaces + letter.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  // This pattern matches:
  // - http:// or https://
  // - Domain name with optional subdomains
  // - Optional port
  // - Path, query string, and fragment
  
  const urlPattern = /\bhttps?:\/\/[^\s<>"')]+/gi;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
// Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation that might be attached
    return url.replace(/[.,!?;)\]]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but leave https:// unchanged
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match ALL http:// URLs
  // Capture groups: 1=protocol, 2=domain, 3=path
  const httpUrlPattern = /(http:\/\/)([^/\s]+)(\/[^\s]*)/gi;

  return text.replace(httpUrlPattern, (match, protocol, domain, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|=|&|cgi-bin)/.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)($|[?&=])/.test(path);
    
    // Check if this is a docs path that should get domain rewrite
    const isDocsPath = /^\/docs\//.test(path);

    if ((hasDynamicHints || hasLegacyExtensions) && !isDocsPath) {
      // Just upgrade to HTTPS, don't change the domain
      return 'https://' + domain + path;
    } else if (isDocsPath && !(hasDynamicHints || hasLegacyExtensions)) {
      // Host rewrite for docs paths: example.com -> docs.example.com
      const newDomain = 'docs.' + domain;
      return 'https://' + newDomain + path;
    } else {
      // For docs paths with dynamic hints, just upgrade to HTTPS without domain change
      return 'https://' + domain + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) return 'N/A';
  
  // Return the year if format and values are valid
  return year;
}
