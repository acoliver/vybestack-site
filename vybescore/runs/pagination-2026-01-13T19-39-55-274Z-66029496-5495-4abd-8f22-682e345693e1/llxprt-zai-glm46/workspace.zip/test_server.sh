#!/bin/bash
cd /home/runner/work/vybestack-site/vybestack-site/evals/outputs/pagination-2026-01-13T19-39-55-274Z-66029496-5495-4abd-8f22-682e345693e1
npm run dev:server &
SERVER_PID=$!
sleep 3

echo "Testing /inventory endpoint (default):"
curl -s "http://localhost:3333/inventory" | jq .

echo -e "\nTesting /inventory?page=1&limit=5:"
curl -s "http://localhost:3333/inventory?page=1&limit=5" | jq .

echo -e "\nTesting /inventory?page=2&limit=5:"
curl -s "http://localhost:3333/inventory?page=2&limit=5" | jq .

echo -e "\nTesting /inventory?page=3&limit=5:"
curl -s "http://localhost:3333/inventory?page=3&limit=5" | jq .

echo -e "\nTesting invalid page (negative):"
curl -s "http://localhost:3333/inventory?page=-1" | jq .

echo -e "\nTesting invalid page (zero):"
curl -s "http://localhost:3333/inventory?page=0" | jq .

echo -e "\nTesting invalid page (non-numeric):"
curl -s "http://localhost:3333/inventory?page=abc" | jq .

echo -e "\nTesting invalid limit (excessive):"
curl -s "http://localhost:3333/inventory?limit=101" | jq .

kill $SERVER_PID
