/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  subscribeObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
  }
  
  // Initial computation to establish dependencies and set value
  updateObserver(o)
  
  return (): T => {
    const activeObs = getActiveObserver()
    if (activeObs && activeObs !== o) {
      // Subscribe the active observer to this computed value
      subscribeObserver(o, activeObs as Observer<unknown>)
    }
    return o.value!
  }
}
