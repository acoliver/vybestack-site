/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  subscribeObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs && s.observer !== activeObs) {
      // Subscribe this observer to the input
      if (!s.observer) {
        s.observer = { name: `input:${options?.name || 'unnamed'}`, subscribers: new Set() }
      }
      subscribeObserver(s.observer, activeObs as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    if (s.observer) {
      notifyObservers(s.observer)
    }
    return s.value
  }

  return [read, write]
}
