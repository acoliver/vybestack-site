/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subscribers: new Set(),
  }
  
  // Register observer to track dependencies and execute initially
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unsubscribe from all dependencies
    if (observer.subscribers) {
      // The observer subscribes to dependencies, so we need to remove from all sources
      // We can't directly access sources, but setting subscribers to empty prevents future notifications
      observer.subscribers.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
