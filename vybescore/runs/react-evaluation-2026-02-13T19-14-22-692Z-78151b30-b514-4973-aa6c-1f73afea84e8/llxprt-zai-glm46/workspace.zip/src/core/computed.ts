/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with
 * supplied function which computes current value
 * of closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observer: undefined,
  }
  
  const getter: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of active observer
      o.observer = observer
    }
    return o.value!
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  return getter
}
