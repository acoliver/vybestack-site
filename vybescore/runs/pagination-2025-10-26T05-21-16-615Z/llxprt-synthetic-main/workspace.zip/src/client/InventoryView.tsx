import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  if (items.length === 0) {
    return <p>No items found in this page.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNextPage,
  onPageChange 
}: { 
  currentPage: number;
  hasNextPage: boolean;
  onPageChange: (page: number) => void;
}) {
  const hasPreviousPage = currentPage > 1;

  return (
    <div>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={!hasPreviousPage}
        aria-label="Previous page"
      >
        Previous
      </button>
      <span style={{ margin: '0 1rem' }}>Page {currentPage}</span>
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNextPage}
        aria-label="Next page"
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error') {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  // Handle empty state or no data
  if (!data || (data.items.length === 0 && currentPage > 1)) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No items found. <button onClick={() => setCurrentPage(1)}>Go to first page</button></p>
      </section>
    );
  }

  const handlePageChange = (newPage: number) => {
    if (newPage > 0) {
      setCurrentPage(newPage);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      {data.items.length > 0 && <InventoryList items={data.items} />}
      
      {/* Fixed: pagination controls implemented */}
      <PaginationControls 
        currentPage={data.page} 
        hasNextPage={data.hasNext}
        onPageChange={handlePageChange}
      />
      
      {/* Display pagination metadata for debugging */}
      <div style={{ fontSize: '0.875rem', color: '#666', marginTop: '1rem' }}>
        Showing {data.items.length} of {data.total} items (Page {data.page} of {Math.ceil(data.total / data.limit)})
      </div>
    </section>
  );
}
