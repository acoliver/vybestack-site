const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

function isValidBase64(input: string): boolean {
  // Check for valid characters first
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Empty input is invalid
  if (input.length === 0) {
    return false;
  }
  
  // Find padding position
  const paddingIndex = input.indexOf('=');
  
  // If there's padding, validate it
  if (paddingIndex !== -1) {
    // Padding can only be at the end
    const paddingOnly = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingOnly)) {
      return false;
    }
    // Max 2 padding characters
    if (paddingOnly.length > 2) {
      return false;
    }
    // Total length must be multiple of 4 when padding is present
    if (input.length % 4 !== 0) {
      return false;
    }
    // Padding must be correct amount
    const expectedPadding = (4 - (input.length % 4)) % 4;
    if (paddingOnly.length !== expectedPadding && input.length % 4 === 0) {
      // When length is already multiple of 4, padding should match expected
      // But we allow valid cases like "YWJj" (no padding) and "YWI=" (correct padding)
    }
  } else {
    // No padding: length when padded to multiple of 4 should work
    // For example: "YWJj" is 4 chars (valid), "YQ" is 2 chars (becomes "YQ==" = 4)
    const unpaddedLength = input.length;
    // Must be at least 2 characters for valid base64 without padding
    // (minimum represents 1 byte which needs 2 base64 chars)
    if (unpaddedLength < 2) {
      return false;
    }
  }
  
  // Check that non-padding portion only contains valid base64 chars
  const nonPadding = input.replace(/=+$/, '');
  return nonPadding.length > 0;
}

const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Encode plain text to Base64 using the standard alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate the input before attempting to decode
  if (!trimmed || !isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  try {
    // Add padding if needed for Node's Buffer.from
    const padded = trimmed.padEnd(Math.ceil(trimmed.length / 4) * 4, '=');
    const result = Buffer.from(padded, 'base64').toString('utf8');
    
    // Check if decoding produced valid UTF-8
    // If the input was invalid base64, Buffer.from may produce garbage
    // We check if the result contains replacement characters which indicates
    // invalid UTF-8 sequences
    if (result.includes('\uFFFD')) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return result;
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
