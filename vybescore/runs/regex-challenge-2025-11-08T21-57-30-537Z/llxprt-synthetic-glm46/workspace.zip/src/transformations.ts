/**
 * Capitalize the first character of each sentence, preserving spacing rules
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Common abbreviations to avoid splitting sentences
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Mt', 'etc', 'e.g', 'i.e', 'vs', 'approx'];
  
  // Split text by sentence-ending punctuation, but try to handle abbreviations
  // This regex matches sentence boundaries preceded by non-abbreviation contexts
  const sentenceRegex = new RegExp(`([^\.!?]*[\.!?])(?=(?:\s*(?!\b${abbreviations.join('\b|')}\b)[A-Z])|$)`);
  
  let result = text;
  let sentences = text.split(sentenceRegex);
  
  // Filter out empty strings and join with proper spacing
  sentences = sentences.filter(s => s.trim().length > 0);
  
  // Process each sentence
  result = sentences.map(sentence => {
    // Remove leading whitespace
    let trimmed = sentence.trim();
    
    // Capitalize the first character if it's a letter
    if (trimmed.length > 0 && /^[a-z]/.test(trimmed[0])) {
      trimmed = trimmed[0].toUpperCase() + trimmed.slice(1);
    }
    
    return trimmed;
  }).join(' ');
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regex to match URLs (http/https/ftp)
  // This pattern captures the URL but excludes trailing punctuation
  const urlRegex = /(?:https?:|ftp:)?\/\/[^\s/$.?#].[^\s]*[^.,;:!?)\]]/gi;
  
  const matches = text.match(urlRegex);
  
  // Trim any trailing whitespace
  return matches ? matches.map(match => match.trim()) : [];
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but ignore already https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Match example.com URLs
  // This is a complex regex to handle all the requirements
  const exampleUrlRegex = /(http:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(exampleUrlRegex, (match, protocol, host, path) => {
    // Always upgrade to HTTPS
    const newProtocol = 'https://';
    
    // Check if we should rewrite the host to docs.example.com
    // Don't rewrite if path contains cgi-bin, query strings, or legacy extensions
    const hasDynamicHint = /cgi-bin|[\?&=]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
    
    // Check if the path starts with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    // Rewrite host only if it's a docs path and doesn't have dynamic hints
    const newHost = (isDocsPath && !hasDynamicHint) ? 'docs.example.com' : host;
    
    return newProtocol + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  // Extract components
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate calendar dates (e.g., no February 30th)
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Adjust for leap years
  const isLeapYear = (year: string) => {
    return (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(year)) {
    if (day > 29) return 'N/A';
  } else if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
