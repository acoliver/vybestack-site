/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex to match words starting with the prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]+)\\b`, 'g');
  
  const matches = [];
  let match;
  
  // Reset RegExp.lastIndex to ensure we start from the beginning
  wordRegex.lastIndex = 0;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Check if the word is not in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Since lookbehind support is limited, use a different approach
  // Match digit followed by token and extract the digit+token combination
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  // Reset RegExp.lastIndex to ensure we start from the beginning
  tokenRegex.lastIndex = 0;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Check if the match is not at the beginning of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  const repeatedSequenceRegex = /(.{2,})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, check if there are any IPv4 addresses to exclude them
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    // This text contains IPv4, but we need to check if there are also IPv6 addresses
  }
  
  // IPv6 regex matching normal, shorthand, and mixed IPv6 addresses
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const ipv6FullRegex = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand IPv6 with :: (leading zeros)
  const ipv6ShorthandRegex = /\b([0-9a-fA-F]{1,4}:){0,7}:(:[0-9a-fA-F]{1,4}){1,7}\b/;
  
  // Mixed IPv6 with embedding IPv4, like ::ffff:192.0.2.128
  const ipv6MixedRegex = /\b([0-9a-fA-F]{1,4}:){1,5}:(\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if any IPv6 pattern matches in the text
  return ipv6FullRegex.test(value) || ipv6ShorthandRegex.test(value) || ipv6MixedRegex.test(value);
}
