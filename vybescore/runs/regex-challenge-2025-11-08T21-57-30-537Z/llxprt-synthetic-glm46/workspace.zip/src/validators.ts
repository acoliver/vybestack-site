export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with common requirements
 */
export function isValidEmail(value: string): boolean {
  // Email regex: local part (no consecutive dots, no trailing/leading dots, no underscores in domain)
  // Domain part: valid domain with at least one dot, no underscores
  // Special characters: +,.% in local part accepted
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?<!\.)@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for consecutive dots in entire email
  if (value.includes('..')) return false;
  
  // Check for underscore in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;
  
  return emailRegex.test(value.trim());
}

/**
 * Validate US phone numbers with common formats
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US format, 11 with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Extract the 10-digit phone number (without country code)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check for common US phone formats
  const usPhoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[-.\s]?)\d{3}[-.\s]?\d{4}$/;
  
  return usPhoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers including mobile and landline formats
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // ^(\+54)? - Optional +54 country code
  // 0? - Optional trunk prefix 0
  // 9? - Optional mobile indicator 9
  // \d{2,4} - Area code (2-4 digits, first digit 1-9)
  // \d{6,8} - Subscriber number (6-8 digits)
  // If no country code, must start with 0 (trunk prefix)
  const argentinePhoneRegex = /^(\+54)?0?9?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) return false;
  
  // Additional validation: if no country code, must start with 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation
 */
export function isValidName(value: string): boolean {
  // Names can contain:
  // - Unicode letters (including accented letters)
  // - Apostrophes
  // - Hyphens
  // - Spaces
  // Reject: digits, special symbols, and characters like "X Æ A-12" style names
  
  if (!value || value.trim().length === 0) return false;
  
  // This regex allows letters (including international), apostrophes, hyphens, and spaces
  // It rejects digits and most special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(value.trim()) && !/\d/.test(value);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens from the card number
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if the cleaned value contains only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check length of card number
  if (cleanValue.length < 13 || cleanValue.length > 19) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 2221-2720 or 51-55, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{13}|[3-6]\d{14}|7([01]\d{13}|20\d{12})))$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card matches any of the accepted card types
  const isValidFormat = visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue);
  
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
