import express from 'express';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH = join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = join(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(join(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// The templates are always in src/templates, even when running from dist
const templatesPath = join(process.cwd(), 'src', 'templates');
app.set('views', templatesPath);

// Initialize database
let dbInitialized = false;

async function ensureDbInitialized(): Promise<void> {
  if (!dbInitialized) {
    await initializeDatabase();
    dbInitialized = true;
  }
}

// Apply initialization middleware before routes
app.use(async (req, res, next) => {
  await ensureDbInitialized();
  next();
});

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, plus sign, and optional leading @
  const phoneRegex = /^@?[0-9\s()+-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(code: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(code);
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State / Province / Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal / Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Phone number may contain digits, spaces, parentheses, dashes, and optional leading @');
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Postal code may contain letters, digits, spaces, and dashes');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  // Create data directory if it doesn't exist
  const dataDir = join(process.cwd(), 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    // Load and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );
    saveDatabase();
  }

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

// Graceful shutdown
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
    dbInitialized = false;
  }
}

async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
}

// Export for testing
export default app;

// Start server if running directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
