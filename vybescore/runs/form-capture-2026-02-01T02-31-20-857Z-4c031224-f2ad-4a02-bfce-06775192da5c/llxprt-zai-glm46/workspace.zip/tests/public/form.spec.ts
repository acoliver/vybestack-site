import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the app after database initialization
  const module = await import('../../src/server.ts');
  app = module.default;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);

    // Check form action
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    
    expect(errorText).toContain('First name is required');
    expect(errorText).toContain('Last name is required');
    expect(errorText).toContain('Street address is required');
    expect(errorText).toContain('City is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Main St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 234 567 8900',
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    
    expect(errorText).toContain('valid email address');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Main St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: 'invalid-phone!',
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    
    expect(errorText).toContain('Phone number may contain');
  });

  it('allows international phone formats', async () => {
    const testPhones = [
      '+44 20 7946 0958',
      '@54 9 11 1234-5678',
      '+1 (555) 123-4567',
    ];

    for (const phone of testPhones) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Main St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: '12345',
          country: 'Test Country',
          email: `test-${Date.now()}@example.com`,
          phone,
        });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('allows international postal formats', async () => {
    const testPostalCodes = ['SW1A 1AA', 'C1000', 'B1675', '12345'];

    for (const postalCode of testPostalCodes) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Main St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode,
          country: 'Test Country',
          email: `test-${Date.now()}@example.com`,
          phone: '+1 234 567 8900',
        });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for humorous content about spam/identity theft
    const bodyText = $('body').text().toLowerCase();
    expect(bodyText).toContain('keep your details');
    expect(bodyText).toContain('stranger');
    
    // Check for link back to form
    expect($('a[href="/"]').length).toBe(1);
  });

  it('preserves form values on validation error', async () => {
    const testValues = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'invalid-email', // Will trigger validation error
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(testValues);

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]').val()).toBe(testValues.firstName);
    expect($('input[name="lastName"]').val()).toBe(testValues.lastName);
    expect($('input[name="city"]').val()).toBe(testValues.city);
    expect($('input[name="postalCode"]').val()).toBe(testValues.postalCode);
  });

  it('has proper label associations', async () => {
    const response = await request(app).get('/');
    const $ = cheerio.load(response.text);

    // Check that labels have proper for attributes
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);

    // Check that inputs have matching ids
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#email').length).toBe(1);
  });
});
