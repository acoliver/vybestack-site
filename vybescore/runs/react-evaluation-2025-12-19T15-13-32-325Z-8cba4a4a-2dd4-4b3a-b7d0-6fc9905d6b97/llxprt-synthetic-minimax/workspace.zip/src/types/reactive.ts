/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  isUpdating?: boolean // Prevent infinite loops
  dependencies?: Set<ObserverR> // Track dependencies this observer depends on
  dependents?: Set<ObserverR> // Track observers that depend on this one
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  const previousObserver = activeObserver
  activeObserver = observer
  
  // Establish dependency relationship
  if (observer && previousObserver && observer !== previousObserver) {
    // previousObserver depends on observer
    if (!observer.dependents) {
      observer.dependents = new Set()
    }
    observer.dependents.add(previousObserver)
    
    if (!previousObserver.dependencies) {
      previousObserver.dependencies = new Set()
    }
    previousObserver.dependencies.add(observer)
  }
}

export function updateObserver<T>(observer: Observer<T>): T {
  // Prevent infinite loops
  if (observer.isUpdating) {
    return observer.value as T
  }
  
  observer.isUpdating = true
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // Notify all dependents after updating the value
    const dependents = observer.dependents
    if (dependents) {
      // Create a copy to avoid modification during iteration
      const dependentsCopy = new Set(dependents)
      for (const dependent of dependentsCopy) {
        if ((dependent as Observer<unknown>).updateFn && !dependent.isUpdating) {
          updateObserver(dependent as Observer<unknown>)
        }
      }
    }
    
    return observer.value!
  } finally {
    activeObserver = previous
    observer.isUpdating = false
  }
}