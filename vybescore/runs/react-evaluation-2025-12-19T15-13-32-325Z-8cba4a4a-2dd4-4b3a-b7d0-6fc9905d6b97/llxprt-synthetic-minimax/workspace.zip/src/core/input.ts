/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process the equality parameter
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === true || _equal === undefined) {
    // Use default strict equality comparison
    equalFn = (lhs, rhs) => lhs === rhs
  } else {
    // _equal is false, so always update
    equalFn = () => false
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if values are actually different
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify the observer if one is registered
    if (s.observer) {
      const observer = s.observer as Observer<unknown>
      updateObserver(observer)
    }
    
    return s.value
  }

  return [read, write]
}