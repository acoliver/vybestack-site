/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create an observer to track dependencies and trigger updates
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      if (disposed) return (currentValue ?? value) as T
      
      // Execute the callback function, which may read reactive values
      updateFn(currentValue)
      
      return (currentValue ?? value) as T
    }
  }
  
  // Establish dependencies by executing the callback in an observer context
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    updateFn(value)
  } finally {
    setActiveObserver(previousObserver)
  }
  
  return () => {
    if (disposed) return
    disposed = true
  }
}