/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  let hasValue = value !== undefined

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue) => {
      const newValue = updateFn(currentValue)
      // Only update if the value has changed or we don't have a value yet
      if (!hasValue || newValue !== computedValue) {
        computedValue = newValue
        hasValue = true
      }
      return computedValue!
    }
  }

  const get: GetterFn<T> = () => {
    const previousObserver = getActiveObserver()
    
    // Set this as the active observer to track dependencies
    setActiveObserver(observer)
    
    try {
      const newValue = updateFn(computedValue)
      
      // Only update if the value has changed or we don't have a value yet
      if (!hasValue || newValue !== computedValue) {
        computedValue = newValue
        hasValue = true
      }
      
      return computedValue!
    } finally {
      // Restore the previous observer
      setActiveObserver(previousObserver)
    }
  }

  return get
}