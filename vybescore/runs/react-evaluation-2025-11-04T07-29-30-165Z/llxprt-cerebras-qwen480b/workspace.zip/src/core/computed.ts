/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the equal parameter - if it's a boolean, use Object.is, otherwise use the provided function
  const equalFn: EqualFn<T> = typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    (lhs: T, rhs: T) => lhs === rhs;

  let computedValue: T | undefined = value;
  let dependentObserver: Observer<T> | undefined;
  
  // Create the getter function that will be returned
  const getter: GetterFn<T> = () => {
    const active = getActiveObserver();
    
    // Register the active observer as dependent if not already registered
    if (active && !dependentObserver) {
      dependentObserver = active as Observer<T>;
    }
    
    // Compute value on first access
    if (computedValue === undefined) {
      computedValue = updateFn(value);
    }
    
    return computedValue as T;
  };

  // Create an observer that recomputes when dependencies change
  const observer: Observer<T> = {
    name: options?.name ? `${options.name}_observer` : undefined,
    value: computedValue as T,
    updateFn: (currentValue) => {
      const newValue = updateFn(currentValue);
      
      // Check if value has changed before notifying observers
      if (!equalFn(computedValue!, newValue)) {
        computedValue = newValue;
        // Notify any dependent observers
        if (dependentObserver) {
          updateObserver(dependentObserver);
        }
      }
      
      observer.value = newValue;
      return newValue;
    }
  };
  
  // Compute initial value
  computedValue = updateFn(value);
  observer.value = computedValue;
  
  // Set up dependency tracking
  updateObserver(observer);

  return getter;
}