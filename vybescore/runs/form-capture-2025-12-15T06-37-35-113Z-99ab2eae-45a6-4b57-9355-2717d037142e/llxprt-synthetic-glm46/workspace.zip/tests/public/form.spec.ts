import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { initializeDatabase } from '../../src/server.js';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize database first
  await initializeDatabase();
  
  // Manually start server with full initialization
  const http = await import('http');
  const { initializeDatabase: initDb, saveDatabase, default: appUninitialized } = await import('../../src/server.js');
  
  // Ensure templates are copied to expected location for tests
  const fs = await import('fs');
  const path = await import('path');
  const srcTemplatesPath = path.resolve('src', 'templates');
  const distTemplatesPath = path.resolve('dist', 'templates');
  
  if (fs.existsSync(srcTemplatesPath) && !fs.existsSync(distTemplatesPath)) {
    const { mkdirSync, copyFileSync, readdirSync } = fs;
    mkdirSync(distTemplatesPath, { recursive: true });
    const files = readdirSync(srcTemplatesPath);
    for (const file of files) {
      copyFileSync(
        path.join(srcTemplatesPath, file), 
        path.join(distTemplatesPath, file)
      );
    }
    console.log('Copied templates from src to dist for tests');
  }
  
  return new Promise<void>((resolve) => {
    server = http.createServer(appUninitialized);
    server.listen(0, () => {
      console.log(`Test server listening on port ${(server.address() as { port: number })?.port}`);
      resolve();
    });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const http = await import('http');
    
    const response = await new Promise<import('http').IncomingMessage>((resolve) => {
      const req = http.request({
        hostname: 'localhost',
        port: (server.address() as { port: number })?.port || 0,
        path: '/',
        method: 'GET'
      }, (res) => {
        resolve(res);
      });
      req.end();
    });
    
    expect(response.statusCode).toBe(200);
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', chunk => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    expect(body).toContain('<form action="/submit"');
    expect(body).toContain('firstName');
    expect(body).toContain('lastName');
    expect(body).toContain('streetAddress');
    expect(body).toContain('city');
    expect(body).toContain('state');
    expect(body).toContain('postalCode');
    expect(body).toContain('country');
    expect(body).toContain('email');
    expect(body).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    const http = await import('http');
    
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = new URLSearchParams({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      state: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john@example.com',
      phone: '+44 20 7946 0958'
    });
    
    const response = await new Promise<import('http').IncomingMessage>((resolve) => {
      const req = http.request({
        hostname: 'localhost',
        port: (server.address() as { port: number })?.port || 0,
        path: '/submit',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(formData.toString())
        }
      }, (res) => {
        resolve(res);
      });
      req.write(formData.toString());
      req.end();
    });
    
    expect(response.statusCode).toBe(302);
    
    // Check that database file exists
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});