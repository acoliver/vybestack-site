
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

// Type definitions for SQL.js
interface Database {
  run(sql: string, params?: unknown[]): unknown;
  exec(sql: string, params?: unknown[]): unknown;
  prepare(sql: string): unknown;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsType {
  Database: {
    new(data?: ArrayBuffer | Uint8Array): Database;
  };
}

export const initDatabase = async (SQL: SqlJsType): Promise<Database> => {
  try {
    // Load SQL.js
    // const SQL = await initSqlJs()
    
    let db: Database
    
    const __filename = fileURLToPath(import.meta.url)
    const __dirname = path.dirname(__filename)
    const dbPath = path.join(__dirname, '../data/submissions.sqlite')
    
    // Try to load existing database file
    try {
      if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath)
        db = new SQL.Database(fileBuffer)
        console.log('Loaded existing database')
      } else {
        // Create new database
        db = new SQL.Database()
        console.log('Created new database')
      }
    } catch (error) {
      console.warn('No existing database found, creating new one:', error)
      db = new SQL.Database()
    }
    
    // Read and execute schema
    const schemaPath = path.join(__dirname, '../db/schema.sql')
    const schema = fs.readFileSync(schemaPath, 'utf8')
    
    try {
      db.run(schema)
      console.log('Database schema initialized')
    } catch (error) {
      console.error('Error initializing schema:', error)
    }
    
    return db
  } catch (error) {
    console.error('Error initializing database:', error)
    throw error
  }
}