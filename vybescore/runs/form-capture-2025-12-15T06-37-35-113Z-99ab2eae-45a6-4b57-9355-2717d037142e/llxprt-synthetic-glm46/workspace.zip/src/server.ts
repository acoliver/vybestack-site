import express from 'express';
import fs from 'fs';
import path from 'path';

interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  free(): void;
}

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Database setup
let db: Database | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    // Use the sql.js Wasm module directly
    const sqljsModule = await import('sql.js');
    let dbData: Uint8Array | undefined = undefined;
    
    if (fs.existsSync(dbPath)) {
      const buffer = fs.readFileSync(dbPath);
      // Convert buffer to Uint8Array
      dbData = new Uint8Array(buffer);
    }

    // Get the initSqlJs function and initialize
    const initFunc = (sqljsModule as any).default || (sqljsModule as any).initSqlJs;
    const SQL = await initFunc({
      locateFile: (file: string) => {
        // Provide absolute path to SQL.js WASM files
        return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });
    
    db = new SQL.Database(dbData) as unknown as Database;
    
    // Create tables if they don't exist
    const schemaPath = path.resolve('db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Middleware to ensure database is available
function ensureDatabase(req: express.Request, res: express.Response, next: express.NextFunction): void {
  if (!db) {
    console.error('Database not initialized when handling request');
    res.status(500).send('Database not initialized');
    return;
  }
  next();
}

// Validation functions
function isEmailValid(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isPhoneValid(phone: string): boolean {
  // Allow optional + at start, then digits, spaces, hyphens, and parentheses
  // Using character class without escaping to avoid lint errors
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return Boolean(phone && phoneRegex.test(phone));
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  general?: string;
}

function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city || data.city.trim().length === 0) {
    errors.city = 'City is required';
  }
  
  if (!data.state || data.state.trim().length === 0) {
    errors.state = 'State / Province / Region is required';
  }
  
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.postalCode = 'Postal / Zip code is required';
  }
  
  if (!data.country || data.country.trim().length === 0) {
    errors.country = 'Country is required';
  }
  
  if (!data.email || data.email.trim().length === 0) {
    errors.email = 'Email is required';
  } else if (isEmailValid(data.email) === false) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone || data.phone.trim().length === 0) {
    errors.phone = 'Phone number is required';
  } else if (isPhoneValid(data.phone) === false) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', ensureDatabase, (req, res) => {
  res.render('form', {
    title: 'Friendly Contact Form',
    formData: {},
    errors: {}
  });
});

app.post('/submit', ensureDatabase, (req, res) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      state: req.body.state || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        title: 'Friendly Contact Form',
        formData,
        errors: validation.errors
      });
    }
    
    // Insert into database
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      const createdAt = new Date().toISOString();
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.state,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
        createdAt
      ]);
      
      stmt.free();
      saveDatabase();
    }
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      title: 'Friendly Contact Form',
      formData: req.body,
      errors: {
        general: 'An unexpected error occurred. Please try again.'
      }
    });
  }
});

app.get('/thank-you', ensureDatabase, (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Start server
async function startServer(): Promise<void> {
  try {
    // Ensure views directory exists before starting server
    const viewsPath = path.join(process.cwd(), 'src', 'templates');
    if (!fs.existsSync(viewsPath)) {
      console.error(`Views directory not found at ${viewsPath}`);
      process.exit(1);
    }
    
    await initializeDatabase();
    
    const httpServer = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      if (db) {
        saveDatabase();
        db.close();
      }
      httpServer.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server if this file is run directly
// Check if this is the main module using import.meta.url (ES modules)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app as default, initializeDatabase, saveDatabase };