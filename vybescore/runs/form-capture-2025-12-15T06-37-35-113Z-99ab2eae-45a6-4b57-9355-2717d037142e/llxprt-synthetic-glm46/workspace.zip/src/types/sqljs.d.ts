declare module 'sql.js' {
  export interface Database {
    export(): Uint8Array;
    close(): void;
    run(sql: string, params?: unknown[]): unknown;
    exec(sql: string, params?: unknown[]): unknown;
    prepare(sql: string): Statement;
  }

  export interface Statement {
    run(params?: unknown[]): unknown;
    get(params?: unknown[]): unknown;
    all(params?: unknown[]): unknown[];
    free(): void;
  }

  export default function SqlJs(): Promise<{
    Database: {
      new(data?: ArrayBuffer | Uint8Array): Database;
    };
  }>;
}