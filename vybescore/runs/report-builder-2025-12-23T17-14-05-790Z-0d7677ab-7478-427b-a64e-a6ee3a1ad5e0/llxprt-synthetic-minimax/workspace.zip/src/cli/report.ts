import { readFileSync } from 'node:fs';
import { ReportData, RenderOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  let i = 2; // Skip node and script name
  while (i < argv.length) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        throw new Error('Missing value for --format');
      }
      args.format = argv[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        throw new Error('Missing value for --output');
      }
      args.output = argv[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
      i += 1;
    } else if (!arg.startsWith('--')) {
      if (!args.dataFile) {
        args.dataFile = arg;
      }
      i += 1;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!args.dataFile) {
    throw new Error('Data file path is required');
  }

  if (!args.format) {
    throw new Error('--format option is required');
  }

  return args;
}

function validateFormat(format: string): void {
  const supportedFormats = ['markdown', 'text'];
  if (!supportedFormats.includes(format)) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${supportedFormats.join(', ')}`);
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    data.entries.forEach((entry: unknown, index: number) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Entry ${index + 1}: invalid entry format`);
      }
      
      const typedEntry = entry as { label?: unknown; amount?: unknown };
      
      if (!typedEntry.label || typeof typedEntry.label !== 'string') {
        throw new Error(`Entry ${index + 1}: missing or invalid "label" field`);
      }
      
      if (typeof typedEntry.amount !== 'number' || isNaN(typedEntry.amount)) {
        throw new Error(`Entry ${index + 1}: missing or invalid "amount" field`);
      }
    });
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to read or parse JSON: ${error.message}`);
    }
    throw new Error('Failed to read or parse JSON file');
  }
}

function getFormatter(format: string) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArguments(process.argv);
    validateFormat(args.format);
    
    const data = loadReportData(args.dataFile);
    const formatter = getFormatter(args.format);
    
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    const output = formatter.format(data, options);
    
    if (args.output) {
      // Write to file
      import('node:fs').then(fs => {
        fs.writeFileSync(args.output!, output);
      });
    } else {
      // Write to stdout
      process.stdout.write(output);
    }
    
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
