#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';
import { ReportData, CLIOptions, Formatter } from '../types.js';

/**
 * Parse command line arguments manually
 */
function parseArgs(argv: string[]): CLIOptions {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  // Parse remaining arguments
  let format: 'markdown' | 'text' | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        i++; // Skip to next argument
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[i] as 'markdown' | 'text';
        break;
      case '--output':
        i++; // Skip to next argument
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputFile = args[i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown argument: ${arg}`);
          process.exit(1);
        }
        break;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  return { dataFile, format, outputFile, includeTotals };
}

/**
 * Load and parse JSON data file
 */
function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(resolve(filePath), 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string' || !data.title.trim()) {
      throw new Error('Invalid or missing title field');
    }
    
    if (typeof data.summary !== 'string' || !data.summary.trim()) {
      throw new Error('Invalid or missing summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing entries field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string' || !entry.label.trim()) {
        throw new Error(`Invalid or missing label in entry at index ${i}`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid or missing amount in entry at index ${i}`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file: ${error.message}`);
    } else if (error instanceof Error && error.message.startsWith('Error:')) {
      console.error(error.message);
    } else {
      console.error(`Error: Failed to load data file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

/**
 * Get formatter based on format string
 */
function getFormatter(format: 'markdown' | 'text'): Formatter {
  switch (format) {
    case 'markdown':
      return new MarkdownFormatter();
    case 'text':
      return new TextFormatter();
    default:
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
  }
}

/**
 * Main CLI execution
 */
function main(): void {
  const options = parseArgs(process.argv);
  const data = loadReportData(options.dataFile);
  const formatter = getFormatter(options.format);
  
  const output = formatter.render(data, options.includeTotals);
  
  if (options.outputFile) {
    // Write to file
    try {
      writeFileSync(resolve(options.outputFile), output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    // Write to stdout
    console.log(output);
  }
}

// Run the CLI
main();
