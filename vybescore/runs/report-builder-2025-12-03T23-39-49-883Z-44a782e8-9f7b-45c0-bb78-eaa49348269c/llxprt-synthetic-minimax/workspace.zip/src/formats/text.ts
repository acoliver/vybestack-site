import { Formatter, ReportData } from '../types.js';

/**
 * Format a number as currency with exactly two decimal places and no thousands separators
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate the total amount from all entries
 */
function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Text formatter implementation
 */
export class TextFormatter implements Formatter {
  render(data: ReportData, includeTotals: boolean): string {
    let output = `${data.title}\n\n`;
    output += `${data.summary}\n\n`;
    output += `Entries:\n\n`;
    
    for (const entry of data.entries) {
      output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
    }
    
    if (includeTotals) {
      const total = calculateTotal(data.entries);
      output += `\nTotal: ${formatAmount(total)}\n`;
    }
    
    return output;
  }
}