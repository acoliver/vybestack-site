/**
 * Shared TypeScript interfaces for the report builder CLI
 */

/**
 * Represents a single entry in a report
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Represents the complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * CLI options and arguments
 */
export interface CLIOptions {
  dataFile: string;
  format: 'markdown' | 'text';
  outputFile?: string;
  includeTotals: boolean;
}

/**
 * Formatter interface that all format renderers must implement
 */
export interface Formatter {
  render(data: ReportData, includeTotals: boolean): string;
}