import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

let db: Database | null = null;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

async function initializeDatabase(): Promise<Database> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize sql.js
  const SQL = await initSqlJs();
  let database: Database;

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(fileBuffer);
  } else {
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    database.run(schema);
    
    // Save initial database
    const data = database.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }

  return database;
}

function saveDatabaseToFile(database: Database): void {
  const data = database.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function validateFormData(formData: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  // Required field validation
  if (!formData.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!formData.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!formData.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!formData.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!formData.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!formData.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!formData.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!formData.email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  if (!formData.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation: digits, spaces, parentheses, dashes, optional leading +
    const phoneRegex = /^\+?[\d\s()-]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation: alphanumeric with optional spaces
  if (formData.postalCode) {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(formData.postalCode)) {
      errors.postalCode = 'Please enter a valid postal/zip code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

async function createServer(): Promise<express.Application> {
  const app = express();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.resolve('public')));

  // Set EJS as template engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve('src', 'templates'));

  // Initialize database
  db = await initializeDatabase();

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      values: {},
      errors: []
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    // Debug logging
    console.log('Request body:', req.body);
    
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    console.log('Form data after processing:', formData);

    const validation = validateFormData(formData);
    console.log('Validation result:', validation);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        values: formData,
        errors: Object.values(validation.errors)
      });
    }

    try {
      if (!db) {
        throw new Error('Database not initialized');
      }

      // Insert into database
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      stmt.free();

      // Save database to file
      saveDatabaseToFile(db);

      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        values: formData,
        errors: ['An error occurred while saving your submission. Please try again.']
      });
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    // For this demo, we'll use a generic greeting. In a real app,
    // you might retrieve the name from the session or a recent submission.
    res.render('thank-you', {
      firstName: 'Friend'
    });
  });

  return app;
}

async function startServer(): Promise<void> {
  try {
    const app = await createServer();
    const PORT = process.env.PORT || 3000;
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Graceful shutdown
    const gracefulShutdown = (): void => {
      console.log('Shutting down gracefully...');
      
      server.close(() => {
        console.log('Express server closed');
        
        if (db) {
          db.close();
          console.log('Database connection closed');
        }
        
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { createServer };
