const { createServer } = require('./dist/server.js');
const request = require('supertest');

async function test() {
  try {
    const app = await createServer();
    
    console.log('Testing GET /');
    const getResponse = await request(app).get('/');
    console.log('GET / Status:', getResponse.status);
    console.log('Form content preview:', getResponse.text.substring(0, 200));
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    console.log('\nTesting POST /submit with data:', formData);
    const postResponse = await request(app)
      .post('/submit')
      .send(formData);
    
    console.log('POST /submit Status:', postResponse.status);
    console.log('Response headers:', postResponse.headers);
    if (postResponse.status === 400) {
      console.log('Error response:', postResponse.text);
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

test();