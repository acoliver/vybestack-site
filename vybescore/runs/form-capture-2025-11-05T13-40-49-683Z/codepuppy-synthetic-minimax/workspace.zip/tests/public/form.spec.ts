import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from '../../src/server';
import express from 'express';

let server: express.Server;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await createServer();
  server = app.listen(0); // Use random available port for testing
});

afterAll(() => {
  return new Promise<void>((resolve) => {
    if (server && server.close) {
      server.close(() => {
        resolve();
      });
    } else {
      resolve();
    }
  });
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check all required form fields exist
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check form submission button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };

    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302); // Redirect to thank-you page

    // Check redirect location
    expect(response.headers.location).toBe('/thank-you');

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('displays thank you page with personalized message', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check that thank you page contains expected content
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain('stranger on the internet');
  });

  it('validates international postal codes and phone numbers', async () => {
    const internationalData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oxford Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA', // UK postcode
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone: '+44 20 7946 0958' // UK phone number
    };

    const response = await request(app)
      .post('/submit')
      .send(internationalData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('rejects invalid email addresses', async () => {
    const invalidData = {
      firstName: 'Invalid',
      lastName: 'Email',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'invalid-email', // Invalid email
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Should show error message
    expect($('.error-list').text()).toContain('valid email');
  });
});
