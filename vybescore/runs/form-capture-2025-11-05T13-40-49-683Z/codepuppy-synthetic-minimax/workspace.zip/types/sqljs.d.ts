declare module 'sql.js' {
  export interface Database {
    prepare(sql: string): Statement;
    run(sql: string | string[]): void;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }

  export default function initSqlJs(): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
}