/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Returns a properly padded Base64 string with ASCII letters A-Z, a-z, digits 0-9, '+' and '/'.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input and validates the input format.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Validate the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check if padding is correct (if present)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding exists, verify it's at the end and not more than 2 characters
    const padding = input.substring(paddingIndex);
    if (!/^(={1,2})$/.test(padding) || input.length > 0 && input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
