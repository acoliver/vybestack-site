import { readFileSync, writeFileSync } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, RenderOptions } from '../types/report.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

const showErrorAndExit = (message: string): never => {
  console.error(message);
  process.exit(1);
  // This line is unreachable but required for TypeScript
  throw new Error('Unreachable');
};

const parseArguments = (args: string[]): ParsedArgs => {
  if (args.length < 4) {
    showErrorAndExit('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    showErrorAndExit('Missing required --format argument');
  }
  
  if (formatIndex + 1 >= args.length) {
    showErrorAndExit('Missing value for --format argument');
  }

  const format = args[formatIndex + 1];
  
  if (format !== 'markdown' && format !== 'text') {
    showErrorAndExit('Unsupported format. Supported formats: markdown, text');
  }

  let output: string | undefined;
  let includeTotals = false;

  // Parse optional flags
  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1) {
    if (outputIndex + 1 >= args.length) {
      showErrorAndExit('Missing value for --output argument');
    }
    output = args[outputIndex + 1];
  }

  if (args.includes('--includeTotals')) {
    includeTotals = true;
  }

  return { dataFile, format, output, includeTotals };
};

const loadAndValidateData = (filePath: string): ReportData => {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(rawData);

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      showErrorAndExit('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      showErrorAndExit('Invalid data: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      showErrorAndExit('Invalid data: missing or invalid "entries" field');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        showErrorAndExit(`Invalid data: entries[${i}] missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        showErrorAndExit(`Invalid data: entries[${i}] missing or invalid "amount" field`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        showErrorAndExit(`Error: File "${filePath}" not found`);
      }
      if (error.message.includes('JSON.parse')) {
        showErrorAndExit('Error: Invalid JSON in data file');
      }
      showErrorAndExit(`Error reading data file: ${error.message}`);
    }
    showErrorAndExit('Error reading data file');
    throw new Error('Unreachable');
  }
};

const main = (): void => {
  const args = parseArguments(process.argv);
  const data = loadAndValidateData(args.dataFile);
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals
  };

  let output: string = '';
  
  switch (args.format) {
    case 'markdown':
      output = renderMarkdown(data, options);
      break;
    case 'text':
      output = renderText(data, options);
      break;
    default:
      showErrorAndExit('Unsupported format. Supported formats: markdown, text');
  }

  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        showErrorAndExit(`Error writing to output file: ${error.message}`);
      }
      showErrorAndExit('Error writing to output file');
    }
  } else {
    console.log(output);
  }
};

main();