/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates that a string is valid Base64.
 * Base64 strings must contain only characters from the Base64 alphabet
 * (A-Z, a-z, 0-9, +, /) and optional padding (=).
 * For padded input, the total length must be a multiple of 4.
 * For unpadded input, we accept it and let Node's Buffer handle decoding.
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }

  // Check that padding is only at the end and at most 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
    // If there's padding, the total length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }

  // Remove any padding characters for character validation
  const withoutPadding = input.replace(/=+$/, '');

  // For very short unpadded strings (less than 2 chars), they're likely invalid
  // since they can't represent meaningful data
  if (withoutPadding.length < 2) {
    return false;
  }

  // Check that remaining characters are valid Base64 alphabet
  return /^[A-Za-z0-9+/]+$/.test(withoutPadding);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the decoding actually worked by checking if the buffer is empty
    // when the input isn't just padding
    const withoutPadding = trimmed.replace(/=+$/, '');
    if (withoutPadding.length > 0 && buffer.length === 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
