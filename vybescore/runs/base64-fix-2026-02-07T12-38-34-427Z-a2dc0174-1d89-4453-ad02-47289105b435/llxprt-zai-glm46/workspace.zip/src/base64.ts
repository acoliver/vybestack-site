/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates the input.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  if (trimmed.length === 0) {
    throw new Error('Failed to decode Base64 input: empty input');
  }

  // Validate Base64 format: should only contain valid Base64 characters
  // Valid characters: A-Z, a-z, 0-9, +, /, and = (only for padding at the end)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmed)) {
    throw new Error('Failed to decode Base64 input: invalid characters');
  }

  // Validate padding: if present, must be 1 or 2 = characters at the end
  const paddingMatch = trimmed.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Failed to decode Base64 input: invalid padding');
    }
    // Total length with padding must be a multiple of 4
    if (trimmed.length % 4 !== 0) {
      throw new Error('Failed to decode Base64 input: invalid padding length');
    }
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the buffer is empty (invalid Base64)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Failed to decode Base64 input: invalid payload');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
