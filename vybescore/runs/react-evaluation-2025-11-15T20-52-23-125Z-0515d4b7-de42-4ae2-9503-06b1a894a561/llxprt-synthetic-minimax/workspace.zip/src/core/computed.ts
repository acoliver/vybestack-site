/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  updateObserver,
  EqualFn,
  Subject,
  subscribeObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value!,
    equalFn: undefined,
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value: value,
    updateFn: (currentValue) => {
      const result = updateFn(currentValue)
      subject.value = result
      notifyObservers(subject)
      return result
    },
  }
  
  // Initial evaluation
  updateObserver(observer)
  
  const getter: GetterFn<T> = () => {
    // Establish dependency if we're being read by another observer
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      subscribeObserver(subject, currentObserver)
    }
    
    // If this is being called during evaluation (no active observer), 
    // or if we need to update, re-evaluate
    return subject.value
  }
  
  return getter
}
