import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import * as fs from 'fs';
import * as path from 'path';
import express, { Application } from 'express';
import { dbManager } from '../../src/database';
import { validateForm, FormData } from '../../src/validation';

let app: Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Setup test server
function createTestApp(): Application {
  const testApp = express();
  
  // Middleware
  testApp.use(express.urlencoded({ extended: true }));
  testApp.use(express.json());
  testApp.use('/public', express.static(path.join(__dirname, '..', '..', 'public')));
  testApp.set('view engine', 'ejs');
  testApp.set('views', path.join(__dirname, '..', '..', 'views'));

  // Routes
  testApp.get('/', (req, res) => {
    res.render('form', { 
      errors: {}, 
      formData: {} 
    });
  });

  testApp.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        formData
      });
    }

    res.redirect(302, '/thank-you');
  });

  testApp.get('/thank-you', (req, res) => {
    res.render('thank-you');
  });

  return testApp;
}

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize test app
  app = createTestApp();
  
  // Initialize database
  await dbManager.initialize();
});

afterAll(async () => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close database connection
  await dbManager.close();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvinceRegion').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
    
    // Check form structure
    expect($('form').attr('method')).toBe('POST');
    expect($('form').attr('action')).toBe('/submit');
    
    // Check that all labels have proper for attributes
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="stateProvinceRegion"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvinceRegion: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check for error messages
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('#firstName').hasClass('error')).toBe(true);
    expect($('#lastName').hasClass('error')).toBe(true);
  });

  it('accepts valid form data and redirects', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvinceRegion: 'State',
        postalCode: '12345',
        country: 'United States',
        email: 'john.doe@example.com',
        phone: '+1 555-123-4567'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvinceRegion: 'State',
        postalCode: '12345',
        country: 'United States',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('#email').hasClass('error')).toBe(true);
  });

  it('validates phone number format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvinceRegion: 'State',
        postalCode: '12345',
        country: 'United States',
        email: 'john.doe@example.com',
        phone: 'invalid-phone!'
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('#phone').hasClass('error')).toBe(true);
  });

  it('validates international phone numbers', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvinceRegion: 'State',
        postalCode: '12345',
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('validates international postal codes', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvinceRegion: 'State',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('shows thank you page after successful submission', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);

    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Thank You');
    expect($('.success-message').length).toBe(1);
    expect($('.back-btn').attr('href')).toBe('/');
  });
});
