export interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRegex = /^\+?[0-9\s\-()]+$/;
const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;

export function validateForm(data: FormData): ValidationResult {
  const errors: { [key: string]: string } = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvinceRegion',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field].trim();
    if (!value) {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && !emailRegex.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !phoneRegex.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postalCode && !postalCodeRegex.test(data.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}