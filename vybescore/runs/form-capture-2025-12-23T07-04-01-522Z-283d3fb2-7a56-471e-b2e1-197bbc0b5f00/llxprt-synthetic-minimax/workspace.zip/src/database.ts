import initSqlJs, { SqlJsStatic, Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    this.sqlJs = await initSqlJs();
    
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      this.db.exec(schema);
      
      this.save();
    }
  }

  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const data = this.db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  insertSubmission(submission: FormSubmission): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    this.save();
  }
}

export const dbManager = new DatabaseManager();