import express, { Request, Response } from 'express';
import * as path from 'path';
import { dbManager, FormSubmission } from './database';
import { validateForm, FormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// Routes

// GET / - Display the contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {} 
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    // Return to form with errors and previously entered values
    return res.status(400).render('form', {
      errors: validation.errors,
      formData
    });
  }

  // Convert to FormSubmission format for database
  const submission: FormSubmission = {
    firstName: formData.firstName.trim(),
    lastName: formData.lastName.trim(),
    streetAddress: formData.streetAddress.trim(),
    city: formData.city.trim(),
    stateProvinceRegion: formData.stateProvinceRegion.trim(),
    postalCode: formData.postalCode.trim(),
    country: formData.country.trim(),
    email: formData.email.trim(),
    phone: formData.phone.trim()
  };

  try {
    dbManager.insertSubmission(submission);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    return res.status(500).render('form', {
      errors: { submit: 'There was an error processing your submission. Please try again.' },
      formData
    });
  }
});

// GET /thank-you - Display thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      console.log('SIGTERM received, shutting down gracefully');
      server.close(async () => {
        await dbManager.close();
        process.exit(0);
      });
    });

    process.on('SIGINT', async () => {
      console.log('SIGINT received, shutting down gracefully');
      server.close(async () => {
        await dbManager.close();
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
