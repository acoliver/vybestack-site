export interface ValidationErrors {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // Remove common formatting characters
  const cleanPhone = phone.replace(/[\s\-()]/g, '');
  
  // Must start with + for international or digits for domestic
  if (cleanPhone.startsWith('+')) {
    // International format: +[country code][number]
    const intlRegex = /^\+\d{1,3}[\d\s-]{6,}$/;
    return intlRegex.test(phone);
  } else {
    // Domestic format: mostly digits, some formatting allowed
    const domesticRegex = /^[\d\s\-()+\\+]{7,}$/;
    return domesticRegex.test(phone) && /\d/.test(cleanPhone);
  }
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric, spaces, and common formats
  // Examples: "12345", "SW1A 1AA", "C1000", "B1675"
  const cleanCode = postalCode.replace(/\s/g, '');
  return /^[A-Za-z0-9]{3,10}$/.test(cleanCode);
}

export function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  }

  // Email validation
  if (data.email && data.email.trim() !== '') {
    if (!validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim() !== '') {
    if (!validatePhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation
  if (data.postal_code && data.postal_code.trim() !== '') {
    if (!validatePostalCode(data.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }
  }

  return errors;
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}