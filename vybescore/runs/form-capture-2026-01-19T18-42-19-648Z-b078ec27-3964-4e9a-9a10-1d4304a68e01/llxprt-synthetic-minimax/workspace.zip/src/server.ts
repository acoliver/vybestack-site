import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dbManager from './db.js';
import { validateFormData, hasErrors, type FormData, type ValidationErrors } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Types for request body
interface RequestWithFormData extends express.Request {
  formData?: FormData;
  validationErrors?: ValidationErrors;
}

// GET / - Render the contact form
app.get('/', (req: RequestWithFormData, res: express.Response) => {
  const { formData, validationErrors } = req;
  
  res.render('form', {
    title: 'Friendly Contact Form',
    formData: formData || {},
    validationErrors: validationErrors || {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: RequestWithFormData, res: express.Response) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validationErrors = validateFormData(formData);

  if (hasErrors(validationErrors)) {
    // Validation failed, re-render form with errors
    req.formData = formData;
    req.validationErrors = validationErrors;
    return res.status(400).render('form', {
      title: 'Friendly Contact Form',
      formData,
      validationErrors
    });
  }

  // Validation passed, insert into database
  dbManager.insertSubmission(formData)
    .then((id) => {
      console.log(`Form submission inserted with ID: ${id}`);
      res.redirect(302, '/thank-you');
    })
    .catch((error) => {
      console.error('Database error:', error);
      res.status(500).render('form', {
        title: 'Friendly Contact Form',
        formData,
        validationErrors: { general: 'Submission failed. Please try again.' }
      });
    });
});

// GET /thank-you - Thank you page
app.get('/thank-you', (_req: express.Request, res: express.Response) => {
  res.render('thank-you', {
    title: 'Thanks!'
  });
});

// Error handling middleware
app.use((err: Error, _req: express.Request, res: express.Response) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
