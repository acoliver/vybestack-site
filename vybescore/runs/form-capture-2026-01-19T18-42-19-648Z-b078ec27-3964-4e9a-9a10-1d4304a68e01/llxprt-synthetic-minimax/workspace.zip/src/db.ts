import initSqlJs from 'sql.js';
import { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

export interface FormSubmission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: import('sql.js').SqlJsStatic | null = null;
  private readonly dbPath = join(process.cwd(), 'data', 'submissions.sqlite');

  async initialize(): Promise<void> {
    if (!this.sqlJs) {
      this.sqlJs = await initSqlJs({
        locateFile: (file: string) => {
          return join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        }
      });
    }

    if (existsSync(this.dbPath)) {
      const dbFile = readFileSync(this.dbPath);
      this.db = new (this.sqlJs as import('sql.js').SqlJsStatic).Database(dbFile);
    } else {
      this.db = new (this.sqlJs as import('sql.js').SqlJsStatic).Database();
      this.createSchema();
    }
  }

  private createSchema(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = readFileSync(join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: Omit<FormSubmission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    const result = this.db.exec('SELECT last_insert_rowid() as id');
    const id = result[0]?.values[0]?.[0] as number;
    
    stmt.free();
    this.persistToFile();
    
    return id;
  }

  async getSubmission(id: number): Promise<FormSubmission | null> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      SELECT * FROM submissions WHERE id = ?
    `);

    stmt.run([id]);
    const row = stmt.getAsObject();
    
    stmt.free();
    
    if (row && Object.keys(row).length > 0) {
      return row as unknown as FormSubmission;
    }
    
    return null;
  }

  async getAllSubmissions(): Promise<FormSubmission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      SELECT * FROM submissions ORDER BY created_at DESC
    `);

    const submissions: FormSubmission[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      submissions.push(row as unknown as FormSubmission);
    }
    
    stmt.free();
    return submissions;
  }

  private persistToFile(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const binaryDb = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(binaryDb));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Singleton instance
const dbManager = new DatabaseManager();

export default dbManager;