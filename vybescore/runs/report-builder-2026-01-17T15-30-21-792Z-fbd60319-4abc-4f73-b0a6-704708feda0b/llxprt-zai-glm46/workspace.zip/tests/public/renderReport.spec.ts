import { describe, expect, it } from 'vitest';
import { execSync } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';

const cliPath = path.join(process.cwd(), 'dist', 'cli', 'report.js');
const dataPath = path.join(process.cwd(), 'fixtures', 'data.json');

function runCli(args: string[]): { stdout: string; stderr: string; exitCode: number | null } {
  try {
    const stdout = execSync(`node ${cliPath} ${args.join(' ')}`, {
      encoding: 'utf-8',
      stdio: 'pipe',
    });
    return { stdout, stderr: '', exitCode: 0 };
  } catch (error) {
    if (error instanceof Error && 'stdout' in error) {
      return {
        stdout: (error as { stdout: string; stderr: string; status: number }).stdout,
        stderr: (error as { stdout: string; stderr: string; status: number }).stderr,
        exitCode: (error as { stdout: string; stderr: string; status: number }).status,
      };
    }
    throw error;
  }
}

function normalizeWhitespace(str: string): string {
  return str.trim().replace(/\n\s*\n\s*\n/g, '\n\n');
}

describe('report CLI (public smoke)', () => {
  it('renders markdown format', () => {
    const { stdout } = runCli([dataPath, '--format', 'markdown']);
    const normalized = normalizeWhitespace(stdout);

    expect(normalized).toContain('# Quarterly Financial Summary');
    expect(normalized).toContain('## Entries');
    expect(normalized).toContain('- **North Region** — $12345.67');
    expect(normalized).toContain('- **South Region** — $23456.78');
    expect(normalized).toContain('- **West Region** — $34567.89');
    expect(normalized).not.toContain('Total:');
  });

  it('renders markdown format with totals', () => {
    const { stdout } = runCli([dataPath, '--format', 'markdown', '--includeTotals']);
    const normalized = normalizeWhitespace(stdout);

    expect(normalized).toContain('# Quarterly Financial Summary');
    expect(normalized).toContain('## Entries');
    expect(normalized).toContain('- **North Region** — $12345.67');
    expect(normalized).toContain('**Total:** $70370.34');
  });

  it('renders text format', () => {
    const { stdout } = runCli([dataPath, '--format', 'text']);
    const normalized = normalizeWhitespace(stdout);

    expect(normalized).toContain('Quarterly Financial Summary');
    expect(normalized).toContain('Entries:');
    expect(normalized).toContain('- North Region: $12345.67');
    expect(normalized).toContain('- South Region: $23456.78');
    expect(normalized).toContain('- West Region: $34567.89');
    expect(normalized).not.toContain('Total:');
  });

  it('renders text format with totals', () => {
    const { stdout } = runCli([dataPath, '--format', 'text', '--includeTotals']);
    const normalized = normalizeWhitespace(stdout);

    expect(normalized).toContain('Quarterly Financial Summary');
    expect(normalized).toContain('Entries:');
    expect(normalized).toContain('- North Region: $12345.67');
    expect(normalized).toContain('Total: $70370.34');
  });

  it('rejects unknown format', () => {
    const { stderr } = runCli([dataPath, '--format', 'unknown']);
    expect(stderr).toContain('Unsupported format');
  });

  it('errors on missing file', () => {
    const { stderr } = runCli(['nonexistent.json', '--format', 'markdown']);
    expect(stderr).toContain('File not found');
  });

  it('errors on malformed JSON', () => {
    const malformedPath = path.join(process.cwd(), 'fixtures', 'malformed.json');
    fs.writeFileSync(malformedPath, '{ invalid json }');

    try {
      const { stderr } = runCli([malformedPath, '--format', 'markdown']);
      expect(stderr).toContain('Failed to parse JSON');
    } finally {
      fs.unlinkSync(malformedPath);
    }
  });

  it('errors on missing required fields', () => {
    const invalidPath = path.join(process.cwd(), 'fixtures', 'invalid.json');
    fs.writeFileSync(invalidPath, '{"summary": "test"}');

    try {
      const { stderr } = runCli([invalidPath, '--format', 'markdown']);
      expect(stderr).toContain('Invalid report data');
    } finally {
      fs.unlinkSync(invalidPath);
    }
  });

  it('writes to output file when specified', () => {
    const outputPath = path.join(process.cwd(), 'test-output.txt');

    try {
      runCli([dataPath, '--format', 'text', '--output', outputPath]);
      expect(fs.existsSync(outputPath)).toBe(true);

      const content = fs.readFileSync(outputPath, 'utf-8');
      expect(content).toContain('Quarterly Financial Summary');
    } finally {
      if (fs.existsSync(outputPath)) {
        fs.unlinkSync(outputPath);
      }
    }
  });
});
