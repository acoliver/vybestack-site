import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate and parse query parameters
    const parseParam = (param: string | undefined, name: string): number => {
      if (!param) return 1; // Default
      const num = Number(param);
      if (isNaN(num) || !isFinite(num)) {
        res.status(400).json({ error: `${name} must be a valid number` });
        return -1;
      }
      if (num <= 0) {
        res.status(400).json({ error: `${name} must be greater than 0` });
        return -1;
      }
      if (num > 10000) {
        res.status(400).json({ error: `${name} must be 10000 or less` });
        return -1;
      }
      return Math.floor(num);
    };

    const page = parseParam(pageParam, 'page');
    if (page === -1) return;
    
    const limit = parseParam(limitParam, 'limit');
    if (limit === -1) return;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
