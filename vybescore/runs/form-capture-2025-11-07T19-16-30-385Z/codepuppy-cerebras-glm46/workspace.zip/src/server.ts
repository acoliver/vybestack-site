import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private port: number;
  private dataDir: string;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3000', 10);
    this.dataDir = path.join(process.cwd(), 'data');
    this.dbPath = path.join(this.dataDir, 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));
  }

  private validateForm(data: FormData): ValidationResult {
    const errors: string[] = [];

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push('First name is required');
    }
    if (!data.lastName?.trim()) {
      errors.push('Last name is required');
    }
    if (!data.streetAddress?.trim()) {
      errors.push('Street address is required');
    }
    if (!data.city?.trim()) {
      errors.push('City is required');
    }
    if (!data.stateProvince?.trim()) {
      errors.push('State / Province / Region is required');
    }
    if (!data.postalCode?.trim()) {
      errors.push('Postal / Zip code is required');
    }
    if (!data.country?.trim()) {
      errors.push('Country is required');
    }
    if (!data.email?.trim()) {
      errors.push('Email is required');
    }
    if (!data.phone?.trim()) {
      errors.push('Phone number is required');
    }

    // Email validation (simple regex)
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push('Please enter a valid email address');
    }

    // Phone validation (international format)
    if (data.phone && !/^[+]?[\d\s()]+$/.test(data.phone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push('Postal code can only contain letters, digits, spaces, and dashes');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Ensure data directory exists
      await fs.mkdir(this.dataDir, { recursive: true });

      // Initialize SQL.js
      const SQL = await initSqlJs();
      let dbData: Uint8Array | undefined = undefined;

      // Try to load existing database
      try {
        const existingDb = await fs.readFile(this.dbPath);
        dbData = new Uint8Array(existingDb);
      } catch (error) {
        // Database doesn't exist yet, will create new one
        console.log('Creating new database...');
      }

      this.db = new SQL.Database(dbData);

      // Initialize schema if needed
      const schemaContent = await fs.readFile(this.schemaPath, 'utf-8');
      this.db.run(schemaContent);

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data = this.db.export();
      await fs.writeFile(this.dbPath, Buffer.from(data));
      console.log('Database saved successfully');
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }
  
  private async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone
      ]);
    } finally {
      stmt.free();
    }

    await this.saveDatabase();
  }

  private setupRoutes(): void {
    // GET / - render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const validation = this.validateForm(formData);

        if (!validation.isValid) {
          return res.status(400).render('form', {
            errors: validation.errors,
            values: formData
          });
        }

        // Save to database
        await this.insertSubmission(formData);

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error handling form submission:', error);
        res.status(500).send('Internal Server Error');
      }
    });

    // GET /thank-you - render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // For simplicity, we'll use a generic name since we don't have session storage
      // In a real app, you'd pass the actual first name from the submission
      res.render('thank-you', {
        firstName: 'friend'
      });
    });

    // Error handling middleware
    this.app.use((err: Error, req: Request, res: Response) => {
      console.error('Unhandled error:', err);
      res.status(500).send('Internal Server Error');
    });
  }

  public async start(): Promise<void> {
    try {
      // Initialize database first
      await this.initializeDatabase();

      // Set up EJS view engine
      this.app.set('view engine', 'ejs');
      this.app.set('views', path.join(process.cwd(), 'src', 'templates'));

      // Start server
      this.app.listen(this.port, () => {
        console.log(`Server running on port ${this.port}`);
      });
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  public async stop(): Promise<void> {
    console.log('Shutting down server gracefully...');
    
    if (this.db) {
      try {
        // Save any pending changes
        await this.saveDatabase();
        this.db.close();
        console.log('Database closed successfully');
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }

    process.exit(0);
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});

// Handle graceful shutdown
process.on('SIGTERM', () => {
  server.stop();
});

process.on('SIGINT', () => {
  server.stop();
});