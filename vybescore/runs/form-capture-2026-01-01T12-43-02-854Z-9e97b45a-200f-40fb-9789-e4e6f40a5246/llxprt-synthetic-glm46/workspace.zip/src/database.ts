import fs from "fs";
import path from "path";
import initSqlJs from "sql.js";
import { FormData } from "./validation.js";

export class DatabaseWrapper {
  private db: any | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), "data", "submissions.sqlite");
  }

  async init(): Promise<void> {
    try {
      const fileSystem = await import("fs");
      let dbBuffer: Uint8Array;

      if (fileSystem.existsSync(this.dbPath)) {
        console.log("Loading existing database from", this.dbPath);
        dbBuffer = fs.readFileSync(this.dbPath);
      } else {
        console.log("Creating new database");
        
        const dataDir = path.dirname(this.dbPath);
        if (!fileSystem.existsSync(dataDir)) {
          fileSystem.mkdirSync(dataDir, { recursive: true });
          console.log("Created data directory:", dataDir);
        }
        
        dbBuffer = new Uint8Array(0);
      }

      const SQL = await initSqlJs({ locateFile: () => `${__dirname}/../node_modules/sql.js/dist/sql-wasm.wasm` });
      this.db = (SQL as any).Database(dbBuffer);
      
      if (dbBuffer.length === 0) {
        console.log("Initializing database with schema");
        const schema = fs.readFileSync(
          path.join(process.cwd(), "db", "schema.sql"), 
          "utf8"
        );
        this.db.exec(schema);
      }
    } catch (error) {
      console.error("Database initialization error:", error);
      throw error;
    }
  }

  async insertSubmission(formData: FormData): Promise<number> {
    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      if (!this.db) {
        throw new Error('Database not initialized');
      }
      const result = this.db.exec("SELECT last_insert_rowid() as id");
      const id = result[0].values[0][0] as number;
      
      this.saveToDisk();
      
      return id;
    } catch (error) {
      console.error("Error inserting submission:", error);
      throw error;
    }
  }

  saveToDisk(): void {
    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error("Error saving database to disk:", error);
      throw error;
    }
  }

  close(): void {
    if (this.db) {
      this.saveToDisk();
      this.db.close();
    }
  }

  getSubmissions(): Record<string, unknown>[] {
    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }
      const result = this.db.exec("SELECT * FROM submissions ORDER BY created_at DESC");
      if (!result[0]) return [];
      
      const rows = result[0].values as unknown[][];
      const columns = result[0].columns;
      
      return rows.map((row) => {
        const record: Record<string, unknown> = {};
        columns.forEach((col: string, index: number) => {
          record[col] = row[index];
        });
        return record;
      });
    } catch (error) {
      console.error("Error fetching submissions:", error);
      return [];
    }
  }
}
