declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    exec(sql: string): { columns: string[], values: unknown[][] }[];
    prepare(sql: string): {
      run(params?: unknown[]): void;
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  }
  
  export function initSqlJs(): Promise<typeof SQL>;
  const SQL: {
    Database: typeof Database;
  };
  
  export default SQL;
}