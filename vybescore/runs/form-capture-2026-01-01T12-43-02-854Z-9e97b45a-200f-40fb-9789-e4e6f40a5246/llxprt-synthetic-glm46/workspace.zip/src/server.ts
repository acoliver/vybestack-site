import express from 'express';
import path from 'path';
import { DatabaseWrapper } from './database.js';
import { FormData, validateForm } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;
const db = new DatabaseWrapper();

export let httpServer: ReturnType<typeof app.listen> | null = null;

async function startServer() {
  try {
    await db.init();
    console.log('Database initialized');
    
    // Middleware setup
    app.use(express.urlencoded({ extended: true }));
    app.use(express.static(path.join(__dirname, '../public')));
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, '../views'));
    
    // Routes
    app.get('/', (req, res) => {
      res.render('form', { 
        formData: {}, 
        errors: new Map(),
        hasErrors: false
      });
    });
    
    app.post('/submit', (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };
      
      const validationResult = validateForm(formData);
      
      if (!validationResult.isValid) {
        // Return to form with errors
        return res.status(400).render('form', {
          formData,
          errors: validationResult.errors,
          hasErrors: true
        });
      }
      
      // Insert into database
      db.insertSubmission(formData)
        .then((id: number) => {
          console.log(`Submission ${id} saved to database`);
          res.redirect('/thank-you');
        })
        .catch((error: unknown) => {
          console.error('Error saving submission:', error);
          res.status(500).render('form', {
            formData,
            errors: new Map([['general', 'Server error occurred. Please try again.']]),
            hasErrors: true
          });
        });
    });
    
    app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });
    
    httpServer = app.listen(port, () => {
      console.log(`Server running on http://localhost:${port}`);
    });
    
    // Handle graceful shutdown
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      if (httpServer) {
        httpServer.close(() => {
          console.log('HTTP server closed');
          db.close();
          process.exit(0);
        });
      } else {
        process.exit(0);
      }
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
