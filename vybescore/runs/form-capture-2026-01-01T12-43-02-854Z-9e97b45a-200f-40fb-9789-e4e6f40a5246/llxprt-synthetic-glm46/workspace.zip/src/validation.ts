export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Map<string, string>;
}

export const validateEmail = (email: string): string => {
  const simpleEmailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || email.trim() === '') {
    return 'Email is required';
  }
  if (!simpleEmailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return '';
};

export const validateRequired = (value: string, fieldName: string): string => {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return '';
};

export const validatePhone = (phone: string): string => {
  if (!phone || phone.trim() === '') {
    return 'Phone number is required';
  }
  const phoneRegex = /^\+?[0-9\s\-\(\)]+$/;
  if (!phoneRegex.test(phone)) {
    return 'Please enter a valid phone number';
  }
  return '';
};

export const validatePostalCode = (postalCode: string): string => {
  if (!postalCode || postalCode.trim() === '') {
    return 'Postal code is required';
  }
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (!postalCodeRegex.test(postalCode)) {
    return 'Postal code can only contain letters, numbers, spaces, and hyphens';
  }
  return '';
};

export const validateForm = (formData: FormData): ValidationResult => {
  const errors = new Map<string, string>();
  
  const firstNameError = validateRequired(formData.firstName, 'First name');
  if (firstNameError) errors.set('firstName', firstNameError);
  
  const lastNameError = validateRequired(formData.lastName, 'Last name');
  if (lastNameError) errors.set('lastName', lastNameError);
  
  const streetAddressError = validateRequired(formData.streetAddress, 'Street address');
  if (streetAddressError) errors.set('streetAddress', streetAddressError);
  
  const cityError = validateRequired(formData.city, 'City');
  if (cityError) errors.set('city', cityError);
  
  const stateProvinceError = validateRequired(formData.stateProvince, 'State/Province/Region');
  if (stateProvinceError) errors.set('stateProvince', stateProvinceError);
  
  const postalCodeError = validatePostalCode(formData.postalCode);
  if (postalCodeError) errors.set('postalCode', postalCodeError);
  
  const countryError = validateRequired(formData.country, 'Country');
  if (countryError) errors.set('country', countryError);
  
  const emailError = validateEmail(formData.email);
  if (emailError) errors.set('email', emailError);
  
  const phoneError = validatePhone(formData.phone);
  if (phoneError) errors.set('phone', phoneError);
  
  return {
    isValid: errors.size === 0,
    errors
  };
};