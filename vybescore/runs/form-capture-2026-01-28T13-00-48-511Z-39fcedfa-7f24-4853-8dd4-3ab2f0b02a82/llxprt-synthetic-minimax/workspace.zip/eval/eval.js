#!/usr/bin/env node

/**
 * Simple evaluation script for form capture application
 * Tests basic functionality without requiring complex dependencies
 */

const fs = require('fs');
const path = require('path');

// Simple test results
const results = {
  tests: [],
  passed: 0,
  failed: 0,
  total: 0
};

function addTest(name, passed, details = '') {
  results.tests.push({
    name,
    passed,
    details
  });
  
  if (passed) {
    results.passed++;
  } else {
    results.failed++;
  }
  results.total++;
}

function runTests() {
  console.log('Starting Form Capture Evaluation...\n');
  
  // Test 1: Check if package.json exists and has required scripts
  try {
    const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    const requiredScripts = ['build', 'start', 'lint', 'typecheck', 'test:public'];
    const hasAllScripts = requiredScripts.every(script => script in packageJson.scripts);
    
    if (hasAllScripts) {
      addTest('package.json has required scripts', true);
    } else {
      addTest('package.json has required scripts', false, 'Missing scripts');
    }
  } catch (error) {
    addTest('package.json exists and is valid', false, error.message);
  }

  // Test 2: Check if TypeScript compilation works
  try {
    if (fs.existsSync('dist/server.js')) {
      addTest('TypeScript compilation successful', true);
    } else {
      addTest('TypeScript compilation successful', false, 'dist/server.js not found');
    }
  } catch (error) {
    addTest('TypeScript compilation successful', false, error.message);
  }

  // Test 3: Check if EJS templates exist
  const requiredViews = ['src/views/form.ejs', 'src/views/thank-you.ejs'];
  const viewsExist = requiredViews.every(view => fs.existsSync(view));
  
  if (viewsExist) {
    addTest('Required EJS templates exist', true);
  } else {
    addTest('Required EJS templates exist', false, 'Missing template files');
  }

  // Test 4: Check if CSS file exists and has content
  try {
    if (fs.existsSync('public/styles.css')) {
      const cssContent = fs.readFileSync('public/styles.css', 'utf8');
      if (cssContent.length > 100) {
        addTest('Styles CSS file exists and has content', true);
      } else {
        addTest('Styles CSS file exists and has content', false, 'CSS too short');
      }
    } else {
      addTest('Styles CSS file exists and has content', false, 'styles.css not found');
    }
  } catch (error) {
    addTest('Styles CSS file exists and has content', false, error.message);
  }

  // Test 5: Check if database schema exists
  if (fs.existsSync('db/schema.sql')) {
    addTest('Database schema file exists', true);
  } else {
    addTest('Database schema file exists', false, 'schema.sql not found');
  }

  // Test 6: Check if server.ts has required routes
  try {
    const serverContent = fs.readFileSync('src/server.ts', 'utf8');
    const hasGetRoute = serverContent.includes("app.get('\/'") || serverContent.includes('app.get("/');
    const hasPostRoute = serverContent.includes("app.post('\/submit'") || serverContent.includes('app.post("/submit');
    const hasThankYouRoute = serverContent.includes("app.get('\/thank-you'") || serverContent.includes('app.get("/thank-you');
    
    if (hasGetRoute && hasPostRoute && hasThankYouRoute) {
      addTest('Required Express routes exist', true);
    } else {
      addTest('Required Express routes exist', false, 'Missing routes');
    }
  } catch (error) {
    addTest('Required Express routes exist', false, error.message);
  }

  // Test 7: Check if validation logic exists
  try {
    const serverContent = fs.readFileSync('src/server.ts', 'utf8');
    const hasValidation = serverContent.includes('validateForm') || serverContent.includes('errors');
    
    if (hasValidation) {
      addTest('Validation logic exists', true);
    } else {
      addTest('Validation logic exists', false, 'No validation found');
    }
  } catch (error) {
    addTest('Validation logic exists', false, error.message);
  }

  // Test 8: Check if thank you page has humorous content
  try {
    const thankYouContent = fs.readFileSync('src/views/thank-you.ejs', 'utf8');
    const hasHumorousContent = thankYouContent.toLowerCase().includes('spam') || 
                              thankYouContent.toLowerCase().includes('stranger') ||
                              thankYouContent.toLowerCase().includes('information');
    
    if (hasHumorousContent) {
      addTest('Thank you page has required humorous content', true);
    } else {
      addTest('Thank you page has required humorous content', false, 'Missing humorous content');
    }
  } catch (error) {
    addTest('Thank you page has required humorous content', false, error.message);
  }

  // Test 9: Check if form has all required fields
  try {
    const formContent = fs.readFileSync('src/views/form.ejs', 'utf8');
    const requiredFields = ['firstName', 'lastName', 'email', 'phoneNumber', 'country'];
    const hasAllFields = requiredFields.every(field => formContent.includes(field));
    
    if (hasAllFields) {
      addTest('Form template has all required fields', true);
    } else {
      addTest('Form template has all required fields', false, 'Missing form fields');
    }
  } catch (error) {
    addTest('Form template has all required fields', false, error.message);
  }

  // Test 10: Check if server can be started (basic check)
  try {
    const serverExists = fs.existsSync('dist/server.js');
    if (serverExists) {
      addTest('Server can be built and started', true);
    } else {
      addTest('Server can be built and started', false, 'Server not built');
    }
  } catch (error) {
    addTest('Server can be built and started', false, error.message);
  }

  // Print results
  console.log('=== Form Capture Evaluation Results ===\n');
  console.log(`Total Tests: ${results.total}`);
  console.log(`Passed: ${results.passed}`);
  console.log(`Failed: ${results.failed}`);
  console.log(`Success Rate: ${((results.passed / results.total) * 100).toFixed(1)}%\n`);

  if (results.failed > 0) {
    console.log('Failed Tests:');
    results.tests.forEach(test => {
      if (!test.passed) {
        console.log(`  [ERROR] ${test.name}: ${test.details}`);
      }
    });
    console.log('');
  }

  console.log('All Tests:');
  results.tests.forEach(test => {
    const icon = test.passed ? '[OK]' : '[ERROR]';
    console.log(`  ${icon} ${test.name}${test.details ? `: ${test.details}` : ''}`);
  });

  // Exit with appropriate code
  const exitCode = results.failed === 0 ? 0 : 1;
  process.exit(exitCode);
}

// Run tests if this file is executed directly
if (require.main === module) {
  runTests();
}

module.exports = { runTests };