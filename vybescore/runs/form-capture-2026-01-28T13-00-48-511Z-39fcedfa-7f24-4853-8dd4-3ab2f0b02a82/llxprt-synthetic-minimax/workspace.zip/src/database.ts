import initSqlJs, { Database } from 'sql.js';
import { readFileSync, existsSync, writeFileSync } from 'fs';
import { join } from 'path';

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const DB_PATH = join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = join(process.cwd(), 'db', 'schema.sql');

export async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
  });

  let dbBuffer: Uint8Array | null = null;
  
  if (existsSync(DB_PATH)) {
    const dbFile = readFileSync(DB_PATH);
    dbBuffer = new Uint8Array(dbFile);
  }

  db = new SQL.Database(dbBuffer);

  // Execute schema to create table if it doesn't exist
  const schemaSql = readFileSync(SCHEMA_PATH, 'utf8');
  db.exec(schemaSql);
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}

export async function storeSubmission(submission: Submission): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const sql = `
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  const values = [
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone
  ];

  db.run(sql, values);

  // Save database to file
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    writeFileSync(DB_PATH, buffer);
  }
}