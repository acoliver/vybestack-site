export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const REQUIRED_FIELDS = [
  'first_name',
  'last_name', 
  'street_address',
  'city',
  'state_province',
  'postal_code',
  'country',
  'email',
  'phone'
] as const;

export function validateFormData(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Check required fields
  for (const field of REQUIRED_FIELDS) {
    const value = data[field as keyof FormData]?.trim();
    if (!value) {
      errors[field] = `${formatFieldName(field)} is required`;
    }
  }

  // Validate email format
  const email = data.email.trim();
  if (email && !EMAIL_REGEX.test(email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Validate phone number format
  const phone = data.phone.trim();
  if (phone && !isValidPhone(phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Validate postal code format
  const postalCode = data.postal_code.trim();
  if (postalCode && !isValidPostalCode(postalCode)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings (handle UK "SW1A 1AA" and formats like "C1000")
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function formatFieldName(field: string): string {
  return field
    .replace(/_/g, ' ')
    .replace(/\b\w/g, l => l.toUpperCase());
}