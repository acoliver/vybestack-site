import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';

// Import sql.js at runtime to avoid TypeScript issues
const initSqlJs = require('sql.js').default || require('sql.js');

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

interface ValidationErrors {
  [key: string]: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Set EJS as view engine
const viewsDir = __dirname.includes('dist') ? path.join(__dirname, '../src/views') : path.join(__dirname, 'views');
app.set('views', viewsDir);
app.set('view engine', 'ejs');

// Database setup
let db: any = null;

async function initDatabase(): Promise<void> {
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  const schemaPath = path.join(__dirname, '../db/schema.sql');
  
  // Create data directory if it doesn't exist
  const dataDir = path.join(__dirname, '../data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  try {
    // Initialize sql.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        return path.join(__dirname, `../node_modules/sql.js/dist/${file}`);
      }
    });

    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read and execute schema
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db.exec(schema);
      }
      
      // Write initial database file
      const dbData = db.export();
      fs.writeFileSync(dbPath, dbData);
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (db !== null) {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const dbData = db.export();
    fs.writeFileSync(dbPath, dbData);
  }
}

function closeDatabase(): void {
  if (db !== null) {
    db.close();
    db = null;
  }
}

// Validation functions
function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phoneNumber'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (international formats)
  if (data.phoneNumber && data.phoneNumber.trim() !== '') {
    const phoneRegex = /^@?[+]?[0-9\s\-()@]{7,}$/;
    if (!phoneRegex.test(data.phoneNumber)) {
      errors.phoneNumber = 'Please enter a valid phone number';
    }
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    values: {},
    title: 'Contact Us - Friendly Form Capture'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalZipCode: req.body.postalZipCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phoneNumber: req.body.phoneNumber || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Validation failed, re-render form with errors
    res.status(400).render('form', {
      errors,
      values: formData,
      title: 'Contact Us - Please Fix Errors'
    });
    return;
  }

  // Validation passed, save to database
  if (db !== null) {
    try {
      db.run(
        `INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province_region, postal_zip_code, country, 
          email, phone_number
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvinceRegion,
          formData.postalZipCode,
          formData.country,
          formData.email,
          formData.phoneNumber
        ]
      );

      // Save database changes
      saveDatabase();

      // Redirect to thank you page
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        errors: { general: 'An error occurred. Please try again.' },
        values: formData,
        title: 'Contact Us - Error'
      });
    }
  } else {
    res.status(500).render('form', {
      errors: { general: 'Database error. Please try again later.' },
      values: formData,
      title: 'Contact Us - Database Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

// Initialize and start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to access the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
