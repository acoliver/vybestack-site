// Type definitions for sql.js
declare module 'sql.js' {
  export interface SqlValue {
    0: unknown;
  }

  export interface SqlRow {
    [key: string]: unknown;
    columns: string[];
    values: SqlValue[];
  }

  export interface SqlParamsType extends ArrayLike<unknown> {
    [index: number]: unknown;
  }

  export interface Database {
    exec(sql: string): SqlRow[];
    run(sql: string, params?: SqlParamsType): void;
    exec(sql: string, params?: SqlParamsType): SqlRow[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
    create_function(name: string, func: (...args: unknown[]) => unknown): void;
  }

  export interface Statement {
    run(values?: SqlParamsType): Statement;
    get(values?: SqlParamsType): Record<string, unknown> | null;
    getAsObject(values?: SqlParamsType, ...params: unknown[]): Record<string, unknown>;
    getColumnNames(): string[];
    getValues(): unknown[][];
    free(): boolean;
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer) => Database;
  }

  export interface SqlJsConfig {
    locateFile?: (filename: string) => string;
  }

  export default function initSqlJs(config?: SqlJsConfig): Promise<SqlJsStatic>;
}
