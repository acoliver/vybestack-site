import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';
import { createServer } from 'node:http';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;
let httpServer: ReturnType<typeof createServer> | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow leading @ or +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[@+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push('First name is required');
  }
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }
  if (!data.city || data.city.trim().length === 0) {
    errors.push('City is required');
  }
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  }
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, and spaces');
  }
  if (!data.country || data.country.trim().length === 0) {
    errors.push('Country is required');
  }
  if (!data.email || data.email.trim().length === 0) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!data.phone || data.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading @ or +');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();

    // Export database to disk
    try {
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_PATH, buffer);
    } catch (error) {
      console.error('Failed to write database:', error);
    }
  } else {
    console.error('Database not initialized - submission not saved');
  }

  // Redirect to thank-you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get first name from query param or use a default
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Server initialization and shutdown
async function initializeDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    try {
      const buffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buffer);
      console.log(`Database loaded from ${DB_PATH}`);
    } catch (error) {
      // If database is corrupted, create a new one
      console.warn('Failed to load existing database, creating new one');
      db = new SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      saveDatabase(db);
    }
  } else {
    db = new SQL.Database();
    // Create schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase(db);
  }

  console.log(`Database initialized at ${DB_PATH}`);
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function startServer(port: number = 3535): Promise<void> {
  await initializeDatabase();

  return new Promise((resolve) => {
    httpServer = createServer(app);
    httpServer.listen(port, () => {
      console.log(`Server listening on port ${port}`);
      resolve();
    });

    // Handle graceful shutdown
    const shutdown = () => {
      console.log('Shutting down server...');
      if (httpServer) {
        httpServer.close(() => {
          if (db) {
            db.close();
            db = null;
          }
          console.log('Server shut down gracefully');
          process.exit(0);
        });
      }

      // Force shutdown after 10 seconds
      setTimeout(() => {
        console.error('Forced shutdown after timeout');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  });
}

export function getServer(): ReturnType<typeof createServer> | null {
  return httpServer;
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  startServer(port).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default app;
