import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { Server } from 'node:http';

let server: Server;
let app: ReturnType<typeof request>;
let SQL: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');
const testPort = 3538;

beforeAll(async () => {
  // Import sql.js to create initial database
  const sqljsModule = await import('sql.js');
  SQL = sqljsModule.default || sqljsModule;

  // Ensure data directory exists and create an empty database
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize an empty database if it doesn't exist
  if (!fs.existsSync(dbPath)) {
    const sql = await SQL();
    const db = new sql.Database();
    const schema = fs.readFileSync(path.resolve(process.cwd(), 'db', 'schema.sql'), 'utf-8');
    db.run(schema);
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    db.close();
  }

  // Dynamically import and start the server
  const serverModule = await import('../../dist/server.js');

  // Start the server on a test port using the startServer function
  await serverModule.startServer(testPort);

  // Get the HTTP server instance
  server = serverModule.getServer();

  app = request(`http://localhost:${testPort}`);
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await app.get('/');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);

    const $ = cheerio.load(response.text);

    // Check for all form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]')).toHaveLength(1);

    // Check labels are properly associated with inputs
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
  });

  it('validates required fields and re-renders form with errors', async () => {
    // Submit empty form
    const response = await app.post('/submit').type('form').send({});

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    // Check for error messages
    expect($('.error-list li').length).toBeGreaterThan(0);

    // Check that form still exists with previous values (empty in this case)
    expect($('form')).toHaveLength(1);
  });

  it('validates email format', async () => {
    const response = await app
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'invalid-email',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    // Should have email validation error
    const errorText = $('.error-list').text();
    expect(errorText.toLowerCase()).toMatch(/email/);
  });

  it('accepts international phone formats', async () => {
    // First ensure we're starting fresh
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await app
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'jane@example.com',
        phone: '+54 9 11 1234-5678',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Create fresh database
    const sql = await SQL();
    const db = new sql.Database();
    const schema = fs.readFileSync(path.resolve(process.cwd(), 'db', 'schema.sql'), 'utf-8');
    db.run(schema);
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    db.close();

    // Wait a moment for the file system to sync
    await new Promise((resolve) => setTimeout(resolve, 100));

    const response = await app
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '456 Test Street',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '555-1234',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);

    // Wait for database write to complete
    await new Promise((resolve) => setTimeout(resolve, 200));

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page', async () => {
    const response = await app.get('/thank-you?firstName=Alice');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);

    const $ = cheerio.load(response.text);

    // Check for personalized content
    expect($('.thankyou-card').text()).toMatch(/Alice/);

    // Check for link back to form
    expect($('a[href="/"]')).toHaveLength(1);

    // Check for humorous/spam warning content
    const pageText = $('.thankyou-card').text().toLowerCase();
    expect(
      pageText.includes('spam') ||
      pageText.includes('identity') ||
      pageText.includes('stranger') ||
      pageText.includes('internet')
    ).toBe(true);
  });

  it('handles international postal codes', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Create fresh database
    const sql = await SQL();
    const db = new sql.Database();
    const schema = fs.readFileSync(path.resolve(process.cwd(), 'db', 'schema.sql'), 'utf-8');
    db.run(schema);
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    db.close();

    // Test UK postal code
    const response1 = await app
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Bob',
        lastName: 'Jones',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'bob@example.com',
        phone: '+44 20 7946 0958',
      });

    expect(response1.status).toBe(302);

    // Test Argentine postal code
    const response2 = await app
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Maria',
        lastName: 'Gonzalez',
        streetAddress: 'Calle Florida 100',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'B1675',
        country: 'Argentina',
        email: 'maria@example.com',
        phone: '+54 11 4567-8900',
      });

    expect(response2.status).toBe(302);
  });
});
