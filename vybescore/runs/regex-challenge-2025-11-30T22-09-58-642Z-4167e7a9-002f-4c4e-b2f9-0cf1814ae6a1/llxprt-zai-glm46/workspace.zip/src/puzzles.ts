/**
 * Finds words beginning with the specified prefix but excluding the listed exceptions.
 * Returns an array of matched words without duplicates.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  
  // Create a Set for efficient exception checking
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Regex to find words starting with the prefix
  // \b - word boundary
  // prefix - the specified prefix (escape special regex chars)
  // \w* - rest of the word
const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(wordRegex);
  if (!matches) return [];
  
  // Filter out exceptions and remove duplicates
  const uniqueWords = new Set<string>();
  matches.forEach(word => {
    const lowerWord = word.toLowerCase();
    if (!exceptionSet.has(lowerWord)) {
      uniqueWords.add(word);
    }
  });
  
  return Array.from(uniqueWords);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  // Escape the token for regex special characters
const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to match token that:
  // - Has a digit before it (lookbehind)
  // - Is not at the beginning of the string (negative lookbehind for ^)
  const tokenRegex = new RegExp(`\\d(${escapedToken})`, 'g');
  
  const matches = text.match(tokenRegex);
  return matches ? [...matches] : [];
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) return false;
  
  // Check for immediate repeated sequences (pattern repeated immediately)
  // Examples: abab, 123123, abcabc should fail
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) while ensuring IPv4 addresses do not trigger a positive result.
 * Returns true if an IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern for common formats  
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|::1|::/;
  
  return ipv6Regex.test(value);
}