/**
 * Capitalizes the first character of each sentence.
 * Handles sentence boundaries (.?!), inserts exactly one space between sentences,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, normalize multiple spaces to single spaces
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Find sentence boundaries and capitalize first letter of each sentence
  // This regex matches sentence endings followed by optional space(s) and first letter
  return normalized.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  }).replace(/^[a-z]/, (letter) => letter.toUpperCase()); // Capitalize first letter if it's lowercase
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern
  // https?:// - protocol (http or https)
  // (?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,} - domain with subdomains
  // (?:/[^\s]*)? - optional path
  // (?:\?[^\s]*)? - optional query string
  // (?:#[^\s]*)? - optional fragment
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?(?:\?[^\s]*)?(?:#[^\s]*)?/g;
  
  // Find all matches
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation characters but keep valid URL characters
    return url.replace(/[.,;:!?'"()[\]{}]+$/g, '');
  });
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// with https:// in the text.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace all http:// with https://, but don't touch existing https://
  // Use negative lookahead to avoid matching https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites docs URLs according to specific rules:
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
// URL regex to capture protocol, host, and path
const urlRegex = /(https?):\/\/([^\/]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if we should skip host rewrite
    const skipRewrite = shouldSkipHostRewrite(path);
    
    if (!skipRewrite && path.startsWith('/docs/')) {
      // Extract base domain from host (remove www, subdomains, etc.)
      const baseDomain = extractBaseDomain(host);
      return `${newProtocol}://docs.${baseDomain}${path}`;
    }
    
    // Just upgrade the protocol
    return `${newProtocol}://${host}${path}`;
  });
}

/**
 * Determines if host rewrite should be skipped based on path patterns
 */
function shouldSkipHostRewrite(path: string): boolean {
  // Skip if path contains dynamic hints
  const dynamicPatterns = [
    /\/cgi-bin\//,
    /\?/,
    /&/,
    /=/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/.*)?$/i
  ];
  
  return dynamicPatterns.some(pattern => pattern.test(path));
}

/**
 * Extracts the base domain from a host (e.g., www.example.com -> example.com)
 */
function extractBaseDomain(host: string): string {
  // Remove www. if present
  if (host.startsWith('www.')) {
    return host.substring(4);
  }
  return host;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const maxDays = getMaxDaysInMonth(month, parseInt(year, 10));
  if (day < 1 || day > maxDays) return 'N/A';
  
  return year;
}

/**
 * Helper function to get the maximum number of days in a month
 */
function getMaxDaysInMonth(month: number, year: number): number {
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    return isLeapYear ? 29 : 28;
  }
  
  return daysInMonth[month - 1];
}
