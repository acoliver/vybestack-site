export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex: local@domain
  // Local: allow letters, digits, +, -, . (no consecutive or trailing dots)
  // Domain: allow letters, digits, - (no underscores), subdomains separated by dots
  // TLD: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9]+(?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9]+)?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  // Check basic format first
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  if (value.includes('..')) return false; // No consecutive dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // No leading/trailing dots
  if (value.includes('@.') || value.includes('.@')) return false; // No dots adjacent to @
  if (value.includes('_')) return false; // No underscores allowed
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Handle extension option if provided in the future
  if (options?.allowExtensions) {
    // Future enhancement: handle phone extensions
    // For now, ignore this option to avoid ESLint warning
  }
  
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) return false;
  
  // If longer than 11 digits, reject
  if (digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) return false;
    
    // Extract the 10-digit number part
    const numberPart = digitsOnly.substring(1);
    return validateUSPhoneNumberDigits(numberPart);
}
  
  // If exactly 10 digits, validate as US number
  return validateUSPhoneNumberDigits(digitsOnly);
}

/**
 * Helper function to validate a 10-digit US phone number
 */
function validateUSPhoneNumberDigits(digits: string): boolean {
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, keep other separators for detection
  const normalized = value.replace(/[-\s]/g, '');
  
  // Full regex for Argentine phone numbers
  // ^(54)? - Optional country code (without +)
  // (9)? - Optional mobile indicator
  // 0? - Optional trunk prefix
  // ([2-9]\d{1,3}) - Area code: 2-4 digits, starting with 2-9
  // (\d{6,8})$ - Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(?:0)?([2-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, areaCode, subscriberNumber] = match;
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (!/^[1-9]\d*$/.test(areaCode)) return false;
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  if (!/^\d+$/.test(subscriberNumber)) return false;
  
  // If no country code present, must have trunk prefix
  const hasCountryCode = normalized.startsWith('+54') || normalized.startsWith('54');
  const hasTrunkPrefix = normalized.includes('0') && !normalized.startsWith('+54') && !normalized.startsWith('54');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    // Check if trunk prefix is immediately before area code
    const trunkPrefixRegex = /^0([2-9]\d{1,3})(\d{6,8})$/;
    if (!trunkPrefixRegex.test(normalized)) return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Name regex: allows unicode letters, accents, apostrophes, hyphens, and spaces
  // ^[\p{L}\p{M}]+ - Start with unicode letter (including accent marks)
  // (['\-\s][\p{L}\p{M}]+)* - Allow apostrophes, hyphens, and spaces followed by more letters
  // $ - End of string
  const nameRegex = /^[\p{L}\p{M}]+(?:['\-\s][\p{L}\p{M}]+)*$/u;
  
  // Basic format check
  if (!nameRegex.test(trimmed)) return false;
  
  // Additional validation rules
  // No consecutive spaces, hyphens, or apostrophes
  if (/\s{2,}/.test(trimmed)) return false;
  if (/-{2,}/.test(trimmed)) return false;
  if (/'{2,}/.test(trimmed)) return false;
  
  // No spaces next to punctuation
  if (/\s['-]|['-]\s/.test(trimmed)) return false;
  
  // Must contain at least one letter (we already ensured this with regex)
  // Minimum length: at least 2 characters after trimming
  if (trimmed.length < 2) return false;
  
  // Maximum reasonable length
  if (trimmed.length > 100) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using Luhn checksum.
 * Accepts appropriate prefixes and lengths for each card type.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[-\s]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digitsOnly)) return false;
  
  // Check length based on card type
  const visaRegex = /^4\d{12,15}$/; // 13-19 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-5]\d|72[0-9]|73[0-9]|74[0-9]|75[0-9]|76[0-9]|77[0-1]\d|78[0-8]\d|79[0-9]\d)\d{12}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if it matches any supported card type
  const isValidFormat = visaRegex.test(digitsOnly) || 
                       mastercardRegex.test(digitsOnly) || 
                       amexRegex.test(digitsOnly);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
