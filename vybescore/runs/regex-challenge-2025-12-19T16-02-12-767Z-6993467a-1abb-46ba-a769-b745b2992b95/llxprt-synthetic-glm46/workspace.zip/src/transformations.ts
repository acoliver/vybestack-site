/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!) 
  // Insert exactly one space between sentences even if the input omitted it
  // Collapse extra spaces sensibly while leaving abbreviations intact when possible
  
  // Return early if empty or null
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // First, handle spacing between sentences
  // Case 1: Ensure there's exactly one space after sentence delimiters (.?!)
  // Replace any non-space or multi-space scenario after .?! with a single space
  let result = text.replace(/([.!?])([^\s]|(\s{2,}))/g, '$1 ');
  
  // Remove extra spaces within each sentence
  result = result.replace(/\s{2,}/g, ' ');
  
  // Handle abbreviations by preserving them
  // Common abbreviations followed by a period but not ending a sentence
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K'];
  
  // Function to check if a word is an abbreviation
  const isAbbreviation = (word: string): boolean => {
    // Remove trailing period for checking
    const wordWithoutPeriod = word.replace(/\.$/, '');
    return abbreviations.includes(wordWithoutPeriod) || 
           // Check for single letter abbreviations like "A.", "B."
           /^[A-Z]\.$/.test(word) ||
           // Check for numeric abbreviations like "vol.", "no.", "ed."
           /^[a-z]{1,3}\.$/.test(word);
  };
  
  // Split into tokens to preserve original structure as much as possible
  const tokens = result.split(/(\s+[.!?]+\s*)/);
  const processedTokens = [];
  
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    
    // Check if this token contains punctuation that might end a sentence
    if (/^.+\s+[.!?]+$/.test(token)) {
      // This is a word/phrase followed by spaces and punctuation
      const wordPart = token.replace(/\s+[.!?]+$/, '');
      const punctuationMatch = token.match(/\s+[.!?]+$/);
      if (!punctuationMatch) {
        processedTokens.push(token);
        continue;
      }
      const punctuationPart = punctuationMatch[0];
      
      // Check if the word is an abbreviation
      if (isAbbreviation(wordPart)) {
        // Preserve as is
        processedTokens.push(token);
      } else {
        // Ensure proper spacing after punctuation
        processedTokens.push(wordPart + punctuationPart.replace(/\s+/, ' '));
      }
    } else {
      processedTokens.push(token);
    }
  }
  
  // Join tokens back together
  result = processedTokens.join('');
  
  // Now capitalize the first character of each sentence
  // First, capitalize the very first character
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Find sentence boundaries and capitalize the character after them
  // This regex matches sentence delimiters (.!?) that are not part of abbreviations
  const sentenceRegex = /([.!?])(?:\s+)(.)/g;
  
result = result.replace(sentenceRegex, (match, delimiter, nextChar) => {
    // Always capitalize the character after a sentence delimiter
    // For simplicity, we'll capitalize everything
    return `${delimiter} ${nextChar.toUpperCase()}`;
  });

  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Return all URLs detected in the text without trailing punctuation
  
  if (!text) {
    return [];
  }
  
  // Regex pattern for URLs
  // Supports http://, https:// protocols and protocol-relative URLs
  // Covers domain names, IP addresses, ports, query strings, fragments
const urlRegex = /\b((https?|ftp):\/\/)?([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(:[0-9]{1,5})?(\/[^\s)\}\\.,;:'"]+)?\b/g;

  // Alternative regex for detecting URLs in various formats including www.
  const wwwRegex = /\bwww(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+[a-zA-Z]{2,}(:[0-9]{1,5})?(\/[^\s)\}\\.,;:'"]+)?\b/g;
  const matches1 = text.match(urlRegex) || [];
  const matches2 = text.match(wwwRegex) || [];
  
  // Combine and deduplicate
const allMatches = [...matches1, ...matches2];
  const uniqueMatches = [...new Set(allMatches)];
  
  // Clean matches: remove trailing punctuation like .,); etc.
  return uniqueMatches.map(url => url.replace(/[.,;:'\"\)}]+$/, ''));
}
/**
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  
  if (!text) {
    return text;
  }
  
  // Regex to match http:// URLs but not https:// URLs
  // Using negative lookahead to ensure we don't match https:// URLs
  const httpUrlRegex = /\bhttp:\/\//g;
  
  // Replace all http:// with https://
  return text.replace(httpUrlRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // 1. Always upgrade the scheme to https
  // 2. When the path begins with /docs/, rewrite the host to docs.example.com
  // 3. Skip the host rewrite when the path contains dynamic hints, query strings, or legacy extensions
  // 4. Preserve nested paths (e.g., /docs/api/v1)
  
  if (!text) {
    return text;
  }
  
  // Check for URLs that should be upgraded to HTTPS
  const urlRegex = /https?:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, hostname, path = '') => {
    // Always upgrade to HTTPS
    const upgradedScheme = 'https://';
    
    // We're upgrading all URLs to HTTPS regardless
    
    // Determine if the path starts with /docs/ to trigger host rewrite
    const beginsWithDocs = path.startsWith('/docs/') || path === '/docs';
    
    // Determine if we should skip the host rewrite based on dynamic hints
    // Skip if path contains these patterns
    const skipRewritePatterns = [
      /\/cgi-bin\//,
      /[?&=]/,  // Query parameters
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i
    ];
    
    const shouldSkipRewrite = skipRewritePatterns.some(pattern => {
      // Check if the path matches any of the patterns
      return pattern.test(path);
    });
    
    // Decide on the final hostname
    let finalHostname = hostname;
    
    // If path begins with /docs/ and we shouldn't skip the rewrite
    if (beginsWithDocs && !shouldSkipRewrite) {
      // Extract the base domain from the hostname
      // Example: example.com -> docs.example.com
      // Example: sub.example.com -> docs.example.com (we preserve subdomains)
      
      // Split hostname by dots
      const parts = hostname.split('.');
      
      // If we have at least 2 parts (domain.tld), prefix with docs.
      if (parts.length >= 2) {
        // Move to the beginning and check if there's already a docs prefix
        if (parts[0] !== 'docs') {
          parts.unshift('docs');
          finalHostname = parts.join('.');
        }
      }
    }
    
    // Construct the final URL
    return upgradedScheme + finalHostname + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // If the string doesn't match that format or month/day are invalid, return 'N/A'
  
  if (!value) {
    return 'N/A';
  }
  
  // Regex to capture month, day, and year from mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Validate the date (account for months with specific numbers of days)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  if (yearNum % 400 === 0 || (yearNum % 100 !== 0 && yearNum % 4 === 0)) {
    daysInMonth[1] = 29; // February has 29 days in a leap year
  }
  
  // Validate day number against the month
  if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  // If everything is valid, return the year
  return year;
}
