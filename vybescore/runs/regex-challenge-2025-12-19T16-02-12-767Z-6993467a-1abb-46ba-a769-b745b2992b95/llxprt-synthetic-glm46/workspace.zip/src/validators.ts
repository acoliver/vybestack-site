export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that covers typical addresses while rejecting invalid forms
  // Supports: name+tag@example.co.uk, rejects double dots, trailing dots, underscores in domain
  
  // Basic structure: local@domain
  // Local part: letters, digits, underscores, hyphens, periods, plus signs
  // Domain part: letters, digits, hyphens, periods (no underscores)
  // Cannot have consecutive dots or leading/trailing dots in either part
  const emailRegex = /^(?!.*\.\.)[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*(\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*)+$/;
  
  // Check for exact match
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks:
  // 1. Ensure domain doesn't have underscores
  // 2. Ensure no section starts or ends with a dot
  // 3. Ensure no section has double dots (already checked by negative lookahead)
  
  const [localPart, domain] = value.split('@');
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Local part cannot start or end with a dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot start or end with a dot
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check valid TLD (at least 2 characters)
  const domainParts = domain.split('.');
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Support formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, 11 if includes +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  let nationalNumber = digitsOnly;
  
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
    nationalNumber = digitsOnly.substring(1);
  }
  
  // Now validate the 10-digit national number
  if (nationalNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = nationalNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the format with regex
  // This regex matches:
  // Optional +1 followed by space or hyphen
  // Optional parentheses around area code
  // Area code, exchange, and subscriber number with various separators
  const usPhoneRegex = /^(?:(?:\+1[\s-]?)|(?:1[\s-]?))?(\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4}))$/;
  
  if (!usPhoneRegex.test(value.trim())) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
*/
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles such as:
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  // Optional country code +54.
  // Optional trunk prefix 0 immediately before the area code.
  // Optional mobile indicator 9 between country/trunk and the area code.
  // Area code must be 2-4 digits (leading digit 1-9).
  // Subscriber number (after the area code) must contain 6-8 digits in total.
  // When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
  // Allow single spaces or hyphens as separators; ignore punctuation when validating.
  
  // Remove whitespace and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Try with country code +54 format
  // Pattern: +54[9][area_code][subscriber]
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  if (/^\+54(9?)([1-9]\d{1,3})(\d{6,8})$/.test(cleaned)) {
    return true;
  }
  
  // Try without country code (starts with trunk prefix 0)
  // Pattern: 0[area_code][subscriber]
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  if (/^0([1-9]\d{1,3})(\d{6,8})$/.test(cleaned)) {
    return true;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  
  // Check if string is empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Regex for valid names:
  // ^ and $ for start and end of string
  // [\p{L}\p{M}]+ for unicode letters and combining marks (accents)
  // [ \-' ] for spaces, hyphens, and apostrophes
  // (?:[\p{L}\p{M}]+|[ \-' ]+)* for the mix of letters and allowed separators
  // The name must contain at least one letter
  const nameRegex = /^(?=.*[\p{L}\p{M}])[\p{L}\p{M} \-'']+$|^[\p{L}\p{M}]$/u;
  
  // Check for invalid characters
  // First, match valid names
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Ensure no consecutive spaces, hyphens, or apostrophes
  if (/ {2,}|-{2,}|'{2,}/.test(value)) {
    return false;
  }
  
// Reject names with numbers or special symbols
  if (/[0-9@#$%^&*()_+=\[\]{}|;:<>?,./`~]/.test(value)) {
    return false;
  }
  
  // Name should not start or end with a space, hyphen, or apostrophe
  if (/^[' -]|[' -]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn algorithm checksum verification.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isSecond = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isSecond) {
      digit = digit * 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    isSecond = !isSecond;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Accept Visa/Mastercard/AmEx prefixes and lengths, run Luhn checksum
  
// Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if the cleaned value contains only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // We'll check length based on card type implicitly through the regex patterns
  
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card number matches any supported format
  let isValidFormat = false;
  if (visaRegex.test(cleaned)) {
    isValidFormat = true;
  } else if (mastercardRegex.test(cleaned)) {
    isValidFormat = true;
  } else if (amexRegex.test(cleaned)) {
    isValidFormat = true;
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}