/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern for words starting with the prefix
  // \b for word boundary, \w for word characters
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  // Find all words in the text that match the prefix
  const matches = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(match => {
    // Check if the word is in the exceptions list
    return !exceptions.includes(match);
  });
  
  // Remove duplicates and return
  return [...new Set(filteredMatches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string
  // Use lookaheads/lookbehinds
  
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern with lookbehind for a digit
  // We'll match the token including the digit that precedes it
  // Then extract just the token part
  
  // Find all occurrences of the token
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
  // no whitespace, no immediate repeated sequences (e.g., abab should fail)
  
  if (!value) {
    return false;
  }
  
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab should fail)
  // This regex detects any sequence of 2 characters that is immediately repeated
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  // All checks passed
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
  if (!value) {
    return false;
  }
  
  // IPv6 format patterns to match:
  // 1. Full IPv6: eight groups of four hexadecimal digits
  // 2. IPv6 with :: (compression)
  // 3. IPv6 with IPv4 embedded
  
  // Simplified IPv6 detection - look for basic IPv6 patterns with colons
  // Standard IPv6 addresses contain colons and hex digits
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  
  // Exclude IPv4 addresses first
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Ensure we're not matching an IPv4 address
  if (!ipv4Pattern.test(value)) {
    return ipv6Pattern.test(value);
  }
  
  // Contains both patterns - check for colons to identify IPv6
  return value.includes(':');
}