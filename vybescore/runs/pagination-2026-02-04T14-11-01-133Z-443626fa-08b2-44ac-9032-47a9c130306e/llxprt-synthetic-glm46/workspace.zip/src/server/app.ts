import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;
    
    // Validation helper function
    const validatePositiveInteger = (value: string | undefined, fieldName: string, defaultValue: number, max: number = 100): number => {
      if (value === undefined) return defaultValue;
      
      const num = Number(value);
      
      if (!Number.isInteger(num) || num <= 0) {
        throw new Error(`${fieldName} must be a positive integer`);
      }
      
      if (num > max) {
        throw new Error(`${fieldName} must not exceed ${max}`);
      }
      
      return num;
    };
    
    try {
      const page = validatePositiveInteger(pageParam, 'Page', 1, 1000); // page: 1-1000
      const limit = validatePositiveInteger(limitParam, 'Limit', 5, 100); // limit: 1-100
      
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
