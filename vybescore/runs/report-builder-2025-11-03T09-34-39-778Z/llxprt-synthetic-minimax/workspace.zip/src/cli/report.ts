#!/usr/bin/env node

import { readFileSync } from 'fs';
import { ReportData, FormatOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script name
  const flags = argv.slice(2);

  for (let i = 0; i < flags.length; i++) {
    const flag = flags[i];

    switch (flag) {
      case '--format':
        if (i + 1 >= flags.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        args.format = flags[i + 1];
        i++;
        break;

      case '--output':
        if (i + 1 >= flags.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        args.outputPath = flags[i + 1];
        i++;
        break;

      case '--includeTotals':
        args.includeTotals = true;
        break;

      default:
        // Non-flag argument is the data file
        if (!args.dataFile) {
          args.dataFile = flag;
        } else {
          console.error(`Error: Unknown argument '${flag}'`);
          process.exit(1);
        }
        break;
    }
  }

  // Validate required arguments
  if (!args.dataFile) {
    console.error('Error: Missing data file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing --format argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return args;
}

function parseReportData(jsonContent: string): ReportData {
  try {
    const data = JSON.parse(jsonContent);

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }

    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];

      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i}: Missing or invalid required field: label`);
      }

      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i}: Missing or invalid required field: amount`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function getFormatter(format: string) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
      process.exit(1);
  }
}

// Main execution
const args = parseArgs(process.argv);

// Read and parse data file
let jsonContent: string;
try {
  jsonContent = readFileSync(args.dataFile, 'utf-8');
} catch (error) {
  console.error(`Error: Cannot read file '${args.dataFile}'`);
  process.exit(1);
}

const reportData = parseReportData(jsonContent);
const options: FormatOptions = {
  includeTotals: args.includeTotals
};

const formatter = getFormatter(args.format);
const output = formatter.format(reportData, options);

// Write output
if (args.outputPath) {
  try {
    const { writeFileSync } = await import('fs');
    writeFileSync(args.outputPath, output, 'utf-8');
  } catch (error) {
    console.error(`Error: Cannot write to file '${args.outputPath}'`);
    process.exit(1);
  }
} else {
  process.stdout.write(output);
}