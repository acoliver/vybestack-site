/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!)
  // Insert exactly one space between sentences even if the input omitted it
  // Collapse extra spaces sensibly while leaving abbreviations intact when possible
  
  // Step 1: Replace multiple spaces with single spaces, but keep sentence terminators separate
  let processed = text.replace(/\s+/g, ' ');
  
  // Step 2: Ensure proper spacing after sentence terminators
  processed = processed.replace(/([.?!])([^\s])/g, '$1 $2');
  
  // Step 3: Capitalize first character after sentence terminators or at the beginning of the string
  // This uses a small list of common abbreviations to avoid capitalizing incorrectly
  const abbreviations = ['mr', 'mrs', 'dr', 'prof', 'sr', 'jr', 'ms', 'st', 'vs', 'etc', 'e.g', 'i.e'];
  const abbrevPattern = abbreviations.join('|');
  
  return processed.replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, letter) => {
    // Check if this might be an abbreviation
    const preceding = text.substring(0, text.indexOf(match) + match.length - letter.length);
    
    if (new RegExp(`\\b(${abbrevPattern})\\. *$`, 'i').test(preceding)) {
      return match;
    }
    
    return prefix + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL extraction regex that matches most common URL formats
  // Group 1: protocol (http, https, ftp, and others)
  // Group 2: domain with optional subdomains
  // Group 3: optional port
  // Group 4: optional path
  // The regex is designed to be fairly comprehensive while avoiding false positives
  
  const urlRegex = /((?:https?:\/\/|ftp:\/\/|www\.)[^\s'"()[\]<>]+)/g;
  const matches: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    const url = match[1];
    
    // Clean up trailing punctuation
    const cleanedUrl = url.replace(/[.,!?;:]+$/, '');
    
    if (cleanedUrl && !matches.includes(cleanedUrl)) {
      matches.push(cleanedUrl);
    }
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https:// while leaving http://localhost and other local URLs alone
  // This regex matches http:// that is not followed by localhost, 127.0.0.1, or machine name
  const httpToHttpsRegex = /\bhttp:\/\/(?!localhost|127\.0\.0\.1|192\.168\.[0-9]{1,3}\.[0-9]{1,3}|10\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})/g;
  
  return text.replace(httpToHttpsRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This regex matches URLs from example.com domain
  // It then applies the transformation rules:
  // 1. Always upgrade to HTTPS
  // 2. If path starts with /docs/ and doesn't contain dynamic hints, rewrite host to docs.example.com
  
  // First upgrade all http://example.com URLs to HTTPS
  text = text.replace(
    /http:\/\/example\.com(\/[^\s]*)?/g, 
    'https://example.com$1'
  );
  
  // Then rewrite docs URLs that don't have dynamic hints or legacy extensions
  const dynamicHints = ['cgi-bin', '?', '&', '='];
  const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  
  text = text.replace(
    /https:\/\/example\.com(\/docs\/[^\s]*)/g, 
    (match, path) => {
      // Check for dynamic hints in the path
      const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
      if (hasDynamicHint) return match;
      
      // Check for legacy extensions in the path
      const hasLegacyExtension = legacyExtensions.some(ext => path.includes(ext));
      if (hasLegacyExtension) return match;
      
      // If no dynamic hints, rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  );
  
  return text;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Extract year from mm/dd/yyyy format, validating that month and day are valid
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  // Extract month, day, and year from the groups
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Year is a string, no need to parse
  
  // Additional validation for days in specific months
  // February has 28 or 29 days (ignoring leap years for simplicity)
  if (month === 2 && day > 29) return 'N/A';
  
  // April, June, September, November have 30 days
  const shortMonths = [4, 6, 9, 11];
  if (shortMonths.includes(month) && day > 30) return 'N/A';
  
  return year;
}