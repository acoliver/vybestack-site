/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  // Use word boundaries to ensure we're matching complete words
  
  // Escape any special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  const prefixedWordRegex = new RegExp(`\\b(\\w*${escapedPrefix}\\w*\\b)`, 'g');
  const matches: string[] = [];
  let match;
  
  while ((match = prefixedWordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if the word is in exceptions
    if (exceptions.includes(word)) continue;
    
    // Only include if it hasn't been added already
    if (!matches.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences of a token after a digit and not at the start of the string
  
  // Split the input into individual tokens (words/number+token combinations)
  const allTokens = text.split(/\s+/);
  const matchingTokens: string[] = [];
  
  // Check each token for the pattern we're looking for
  for (const t of allTokens) {
    // Check if token matches our pattern: digit(s) + the target token
    const match = t.match(/^(\d+)(.+)$/);
    if (match && match[2] === token) {
      matchingTokens.push(match[1] + match[2]);  // Include the full token (digit + target)
    }
  }
  
  return matchingTokens;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password validation according to the following criteria:
  // - At least 10 characters
  // - One uppercase
  // - One lowercase
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., abab should fail)
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for character requirements
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol || hasWhitespace) return false;
  
  // Check for immediate repeated sequences 
  // This should detect patterns like abab, 123123, etc.
  for (let i = 0; i < value.length / 2; i++) {
    const segment = value.substring(i, i * 2 - i);
    if (segment.length > 1) {
      const potentialRepeat = value.substring(i * 2 - i, i * 4 - i * 2);
      if (segment === potentialRepeat) return false;
    }
  }
  
  // Check for immediate character repeating (like "aaa")
  if (/(.)\1{2,}/.test(value)) return false;
  
  // Check for keyboard sequences (asdf, qwerty, etc.)
  const keyboardSequences = ['qwerty', 'asdf', 'zxcv', '1234', '2345', '3456', '4567'];
  const lowerValue = value.toLowerCase();
  for (const seq of keyboardSequences) {
    if (lowerValue.includes(seq)) return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address detection (including shorthand ::) but not IPv4 addresses
  
  // IPv6 regular expression patterns
  // Supports standard formats, shorthand, IPv6 addresses with embedded IPv4
  // Negative lookahead to exclude IPv4-only
  
  // IPv4 pattern for exclusion
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?).){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check if this is just an IPv4 address
  if (ipv4Pattern.test(value) && !/::/.test(value) && !/:/.test(value)) return false;
  
  // IPv6 patterns
  const ipv6Patterns = [
    // Standard format with groups separated by colons
    /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // Format with :: shorthand (compressed zeros)
    /\b([0-9a-fA-F]{1,4}:){0,6}:[0-9a-fA-F]{1,4}\b/,
    /\b::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/,
    /\b[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/,
    
    // Special case: just :: 
    /\b::\b/,
    
    // IPv6 with embedded IPv4
    /\b([0-9a-fA-F]{1,4}:){5}[0-9a-fA-F]{1,4}:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}\b/
  ];
  
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}