export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex supporting typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores, and other invalid forms
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?<!\.)@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks to reject emails with consecutive dots or dots at beginning/end
  if (!emailRegex.test(value)) return false;
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  const [local, domain] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Extract digits from the input
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Basic validation for supported formats
  const phoneRegex = /^(\+?[1]\s?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) to get a clean string of digits and optional country code
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Argentine phone number regex patterns
  // Regex breakdown:
  // ^(?:\+54)? - Optional +54 country code
  // (?:9)? - Optional mobile indicator
  // (?:0)? - Optional trunk prefix
  // ([1-9]\d{1,3}) - Area code (2-4 digits, first digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if the pattern matches
  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) return false;
  
  // Extract area code and subscriber number
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // When country code is omitted, must have trunk prefix 0
  if (!cleanNumber.startsWith('+54') && !cleanNumber.startsWith('0')) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex supporting unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} - Unicode letter category (includes letters with accents)
  // \p{M} - Unicode combining marks (for accents that are separate)
  const nameRegex = /^[\p{L}\p{M}'][\p{L}\p{M}'\-\s]*[\p{L}\p{M}']$/u;
  
  // Check that the input matches the pattern
  if (!nameRegex.test(value)) return false;
  
  // Ensure there are no digits or symbols
  if (/[0-9]/.test(value)) return false;
  if (/[^a-zA-Z\u00C0-\u024F\u0400-\u04FF\u0370-\u03FF\u0590-\u05FF\u4E00-\u9FFF'\-\s]/.test(value)) return false;
  
  // Ensure it's not too short (at least 2 characters)
  if (value.trim().length < 2) return false;
  
  return true;
}

/**
 * Perform a Luhn checksum validation on a credit card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = parseInt(digits[i], 10);
    
    // Double every second digit, starting from the right
    if (i % 2 === digits.length % 2) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Basic format check: should be 13-19 digits
  if (!/^\d{13,19}$/.test(cleanNumber)) return false;
  
  // Card type prefixes
  const patterns = {
    visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
    mastercard: /^5[1-5][0-9]{14}$|^2[2-7][0-9]{14}$/,
    amex: /^3[47][0-9]{13}$/
  };
  
  // Check if the number matches any known card type
  const isValidCardType = patterns.visa.test(cleanNumber) || 
                         patterns.mastercard.test(cleanNumber) || 
                         patterns.amex.test(cleanNumber);
  
  if (!isValidCardType) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}
