import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

function getDirname(): string {
  const __filename = fileURLToPath(import.meta.url);
  return path.dirname(__filename);
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateForm(data: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Required fields validation
  if (!data.firstName.trim()) errors.push('First name is required');
  if (!data.lastName.trim()) errors.push('Last name is required');
  if (!data.streetAddress.trim()) errors.push('Street address is required');
  if (!data.city.trim()) errors.push('City is required');
  if (!data.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode.trim()) errors.push('Postal/Zip code is required');
  if (!data.country.trim()) errors.push('Country is required');
  if (!data.email.trim()) errors.push('Email is required');
  if (!data.phone.trim()) errors.push('Phone number is required');

  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation (international format)
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  // Postal code validation (alphanumeric)
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  if (data.postalCode && !postalRegex.test(data.postalCode)) {
    errors.push('Postal code can only contain letters, digits, spaces, and dashes');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  const dbPath = path.join(getDirname(), '..', 'data', 'submissions.sqlite');
  const schemaPath = path.join(getDirname(), '..', 'db', 'schema.sql');
  
  let db: Database;
  
  try {
    const dbFile = fs.readFileSync(dbPath);
    db = new SQL.Database(dbFile);
  } catch (error) {
    // Database doesn't exist, create new one
    db = new SQL.Database();
    
    // Read and execute schema
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
    
    // Save initial database
    saveDatabase(db);
  }
  
  return db;
}

function saveDatabase(db: Database): void {
  const dbPath = path.join(getDirname(), '..', 'data', 'submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

async function createApp(): Promise<express.Application> {
  const app = express();
  const db = await initializeDatabase();
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(getDirname(), '..', 'public')));
  
  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(getDirname(), '..', 'src', 'templates'));
  
  // Routes
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      }
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.render('form', {
        errors: validation.errors,
        values: formData
      });
    }
    
    // Insert into database
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database after insert
      saveDatabase(db);
      
      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      const errors = ['An error occurred while saving your submission. Please try again.'];
      return res.render('form', { errors, values: formData });
    }
  });
  
  app.get('/thank-you', (req, res) => {
    // Get the most recent submission to personalize the message
    try {
      const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const firstName = result[0] && result[0].values[0] ? result[0].values[0][0] : 'friend';
      res.render('thank-you', { firstName });
    } catch (error) {
      console.error('Database error:', error);
      res.render('thank-you', { firstName: 'friend' });
    }
  });
  
  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down gracefully...');
    db.close();
    process.exit(0);
  };
  
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
  
  return app;
}

// Start server
async function startServer() {
  const app = await createApp();
  const port = process.env.PORT || 3535;
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

startServer().catch(console.error);
