/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  setActiveObserver,
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set<Subject<unknown>>(),
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && o.subjects) {
      // Propagate observer subscription to dependencies
      for (const subject of o.subjects) {
        subject.observers.add(observer)
        // Also track this subject in the parent observer
        if (observer.subjects) {
          observer.subjects.add(subject)
        }
      }
    }
    return o.value!
  }

  // Initialize the computed value and track dependencies
  const prevObserver = getActiveObserver()
  setActiveObserver(o)
  try {
    o.value = updateFn(value)
  } finally {
    setActiveObserver(prevObserver)
  }

  return getter
}
