import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';
import { createRequire } from 'module';
import type { Server } from 'http';

const require = createRequire(import.meta.url);

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Types
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Global database instance
let db: Database | null = null;
let httpServer: Server | null = null;

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handles UK, Argentine formats, etc.)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Check required fields
  const requiredFields: (keyof FormData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }

  // Validate email
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Validate phone
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Validate postal code
  if (data.postal_code && !validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return errors;
}

// Database functions
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => require.resolve(`sql.js/dist/${file}`)
  });

  const dataDir = path.join(__dirname, '../data');
  const dbPath = path.join(dataDir, 'submissions.sqlite');

  try {
    // Ensure data directory exists
    await fs.mkdir(dataDir, { recursive: true });

    // Try to load existing database
    const dbBuffer = await fs.readFile(dbPath);
    db = new SQL.Database(new Uint8Array(dbBuffer));
  } catch (error) {
    // Create new database if file doesn't exist
    db = new SQL.Database();
    
    // Execute schema
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    db.run(schema);
    
    // Write initial database file
    await saveDatabase();
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const dataDir = path.join(__dirname, '../data');
  const dbPath = path.join(dataDir, 'submissions.sqlite');
  
  await fs.mkdir(dataDir, { recursive: true });
  await fs.writeFile(dbPath, Buffer.from(db.export()));
}

async function saveSubmission(data: FormData): Promise<void> {
  if (!db) throw new Error('Database not initialized');

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.first_name,
    data.last_name,
    data.street_address,
    data.city,
    data.state_province,
    data.postal_code,
    data.country,
    data.email,
    data.phone
  ]);

  stmt.free();
  await saveDatabase();
}

// Express app setup
const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    title: 'Contact Us',
    data: {},
    errors: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    first_name: req.body.first_name?.trim() || '',
    last_name: req.body.last_name?.trim() || '',
    street_address: req.body.street_address?.trim() || '',
    city: req.body.city?.trim() || '',
    state_province: req.body.state_province?.trim() || '',
    postal_code: req.body.postal_code?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Re-render form with errors
    return res.status(400).render('form', {
      title: 'Contact Us',
      data: formData,
      errors
    });
  }

  try {
    await saveSubmission(formData);
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      title: 'Contact Us',
      data: formData,
      errors: { _global: 'An error occurred. Please try again.' }
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // We can't easily get the first name from the previous submission here
  // since we used a redirect. In a real app, we'd use session storage.
  // For the humorous effect, we'll just render a generic message.
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    await saveDatabase();
    db.close();
    db = null;
  }
  
  if (httpServer) {
    httpServer.close();
  }
  
  process.exit(0);
}

// Setup signal handlers
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start() {
  try {
    await initDatabase();
    
    const port = parseInt(process.env.PORT || '3000', 10);
    
    httpServer = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();