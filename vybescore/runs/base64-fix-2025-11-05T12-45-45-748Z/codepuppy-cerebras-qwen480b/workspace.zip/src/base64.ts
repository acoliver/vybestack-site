/**
 * Encode plain text to Base64 using canonical RFC 4648 alphabet.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  // Use standard Base64 encoding which includes the canonical alphabet and padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using canonical RFC 4648.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }

  // Remove whitespace that might be present in the input
  const cleanedInput = input.replace(/\s/g, '');

  // Validate Base64 characters - allowed: A-Z, a-z, 0-9, +, /, =
  if (!/^[A-Za-z0-9+/=]*$/.test(cleanedInput)) {
    throw new Error('Invalid Base64: contains illegal characters');
  }

  // Check for padding correctness (padding can only appear at the end)
  const paddingIndex = cleanedInput.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingSection = cleanedInput.substring(paddingIndex);
    if (!/^=?=?$/.test(paddingSection)) {
      throw new Error('Invalid Base64: incorrect padding');
    }
    // No non-padding characters after padding starts
    if (!/^[=]*$/.test(paddingSection)) {
      throw new Error('Invalid Base64: padding characters in wrong position');
    }
  }

  try {
    const buffer = Buffer.from(cleanedInput, 'base64');
    
    // Check if decoding actually worked (Buffer will be empty for invalid input)
    if (buffer.length === 0 && cleanedInput.length > 0) {
      throw new Error('Invalid Base64: cannot decode input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
