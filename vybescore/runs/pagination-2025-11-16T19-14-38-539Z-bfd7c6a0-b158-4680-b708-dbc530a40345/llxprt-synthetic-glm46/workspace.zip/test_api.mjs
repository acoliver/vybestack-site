import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

// Test API with mock request/response
async function testAPI() {
  console.log('Testing API implementation...');
  
  try {
    // Create a new database
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test default values (page=1, limit=5)
    console.log('\n1. Testing default values:');
    
    const defaultReq = {
      query: {}
    };
    
    let responseData;
    const defaultRes = {
      json: (data) => {
        responseData = data;
      },
      status: (code) => ({ json: defaultRes.json })
    };
    
    // Find and call the inventory route handler
    app._router.stack.forEach((layer) => {
      if (layer.route && layer.route.path === '/inventory' && layer.route.methods.get) {
        layer.route.stack[0].handle(defaultReq, defaultRes);
      }
    });
    
    console.log('Default API response:', {
      page: responseData?.page,
      limit: responseData?.limit,
      total: responseData?.total,
      hasNext: responseData?.hasNext,
      itemsCount: responseData?.items?.length,
      firstItemId: responseData?.items?.[0]?.id,
      lastItemId: responseData?.items?.[responseData?.items?.length - 1]?.id
    });
    
    // Test page 2
    console.log('\n2. Testing page 2:');
    
    const page2Req = {
      query: { page: '2', limit: '5' }
    };
    
    let page2ResponseData;
    const page2Res = {
      json: (data) => {
        page2ResponseData = data;
      },
      status: (code) => ({ json: page2Res.json })
    };
    
    // Find and call the inventory route handler
    app._router.stack.forEach((layer) => {
      if (layer.route && layer.route.path === '/inventory' && layer.route.methods.get) {
        layer.route.stack[0].handle(page2Req, page2Res);
      }
    });
    
    console.log('Page 2 API response:', {
      page: page2ResponseData?.page,
      limit: page2ResponseData?.limit,
      total: page2ResponseData?.total,
      hasNext: page2ResponseData?.hasNext,
      itemsCount: page2ResponseData?.items?.length,
      firstItemId: page2ResponseData?.items?.[0]?.id,
      lastItemId: page2ResponseData?.items?.[page2ResponseData?.items?.length - 1]?.id
    });
    
    // Test invalid page parameter
    console.log('\n3. Testing invalid page parameter:');
    
    const invalidPageReq = {
      query: { page: '-1' }
    };
    
    let errorResponse;
    const errorRes = {
      status: (code) => {
        return {
          json: (data) => {
            errorResponse = { status: code, data };
          }
        };
      }
    };
    
    // Find and call the inventory route handler
    app._router.stack.forEach((layer) => {
      if (layer.route && layer.route.path === '/inventory' && layer.route.methods.get) {
        layer.route.stack[0].handle(invalidPageReq, errorRes);
      }
    });
    
    console.log('Invalid page API response:', errorResponse);
    
    console.log('\nAPI test completed successfully!');
  } catch (error) {
    console.error('Error during API test:', error);
  }
}

testAPI();