import { createDatabase } from './src/server/db.ts';
import { listInventory } from './src/server/inventoryRepository.ts';

async function test() {
  console.log('Testing pagination implementation...');
  
  try {
    // Create a new database
    const db = await createDatabase();
    
    // Test default values (page=1, limit=5)
    console.log('\n1. Testing default values:');
    const result1 = listInventory(db, {});
    console.log('Default result:', {
      page: result1.page,
      limit: result1.limit,
      total: result1.total,
      hasNext: result1.hasNext,
      itemsCount: result1.items.length,
      firstItemId: result1.items[0]?.id,
      lastItemId: result1.items[result1.items.length - 1]?.id
    });
    
    // Test page 2
    console.log('\n2. Testing page 2:');
    const result2 = listInventory(db, { page: 2, limit: 5 });
    console.log('Page 2 result:', {
      page: result2.page,
      limit: result2.limit,
      total: result2.total,
      hasNext: result2.hasNext,
      itemsCount: result2.items.length,
      firstItemId: result2.items[0]?.id,
      lastItemId: result2.items[result2.items.length - 1]?.id
    });
    
    // Test hasNext calculation
    console.log('\n3. Testing hasNext calculation:');
    const itemsPerPage = 5;
    const totalPages = Math.ceil(result1.total / itemsPerPage);
    console.log('Total items:', result1.total);
    console.log('Items per page:', itemsPerPage);
    console.log('Total pages:', totalPages);
    
    // Test last page
    console.log('\n4. Testing last page:');
    const lastPageResult = listInventory(db, { page: totalPages, limit: 5 });
    console.log('Last page result:', {
      page: lastPageResult.page,
      limit: lastPageResult.limit,
      total: lastPageResult.total,
      hasNext: lastPageResult.hasNext,
      itemsCount: lastPageResult.items.length
    });
    
    // Test invalid page (should default to 1)
    console.log('\n5. Testing invalid page (negative):');
    const invalidPageResult = listInventory(db, { page: -1, limit: 5 });
    console.log('Invalid page result:', {
      page: invalidPageResult.page,
      limit: invalidPageResult.limit
    });
    
    // Test invalid limit (should default to 5)
    console.log('\n6. Testing invalid limit (0):');
    const invalidLimitResult = listInventory(db, { page: 1, limit: 0 });
    console.log('Invalid limit result:', {
      page: invalidLimitResult.page,
      limit: invalidLimitResult.limit
    });
    
    console.log('\nPagination test completed successfully!');
  } catch (error) {
    console.error('Error during pagination test:', error);
  }
}

test();