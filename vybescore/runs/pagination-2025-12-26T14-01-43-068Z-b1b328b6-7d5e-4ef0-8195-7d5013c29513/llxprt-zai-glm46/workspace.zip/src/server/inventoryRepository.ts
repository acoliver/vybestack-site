import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export interface PaginationError {
  code: 'INVALID_PAGE' | 'INVALID_LIMIT';
  message: string;
}

export function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page?: number; limit?: number; error?: PaginationError } {
  let page: number | undefined = undefined;
  let limit: number | undefined = undefined;

  // Validate and parse page parameter
  if (pageParam !== undefined) {
    if (pageParam === '') {
      return { error: { code: 'INVALID_PAGE', message: 'page parameter cannot be empty' } };
    }
    const parsed = Number(pageParam);
    if (Number.isNaN(parsed)) {
      return { error: { code: 'INVALID_PAGE', message: 'page must be a valid number' } };
    }
    if (!Number.isInteger(parsed) || parsed < 1) {
      return { error: { code: 'INVALID_PAGE', message: 'page must be a positive integer' } };
    }
    page = parsed;
  }

  // Validate and parse limit parameter
  if (limitParam !== undefined) {
    if (limitParam === '') {
      return { error: { code: 'INVALID_LIMIT', message: 'limit parameter cannot be empty' } };
    }
    const parsed = Number(limitParam);
    if (Number.isNaN(parsed)) {
      return { error: { code: 'INVALID_LIMIT', message: 'limit must be a valid number' } };
    }
    if (!Number.isInteger(parsed) || parsed < 1) {
      return { error: { code: 'INVALID_LIMIT', message: 'limit must be a positive integer' } };
    }
    if (parsed > MAX_LIMIT) {
      return { error: { code: 'INVALID_LIMIT', message: `limit cannot exceed ${MAX_LIMIT}` } };
    }
    limit = parsed;
  }

  return { page, limit };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
