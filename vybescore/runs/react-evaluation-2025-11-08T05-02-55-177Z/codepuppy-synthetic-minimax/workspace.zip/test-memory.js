// Quick test to check memory management
const { createInput, createCallback } = require('./src/index.ts');

console.log('Testing memory management...');

const [getter, setter] = createInput(1);

let callbackCount = 0;
const unsubscribe1 = createCallback(() => callbackCount++);
const unsubscribe2 = createCallback(() => callbackCount++);
const unsubscribe3 = createCallback(() => callbackCount++);

console.log('Initial count:', callbackCount);

setter(2);
console.log('After change:', callbackCount);

unsubscribe1();
setter(3);
console.log('After unsubscribe and change:', callbackCount);

console.log('Expected: 2 callbacks should fire, not 3');
