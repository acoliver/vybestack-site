/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  disposed?: boolean
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Global registry to track which subjects have which observers
// This allows us to create cascading updates
const subjectObservers = new WeakMap<object, Set<ObserverR>>()

// Track which observers are currently updating to prevent infinite recursion
export const updatingObservers = new Set<ObserverR>()

export function addSubjectObserver(subject: object, observer: ObserverR): void {
  let observers = subjectObservers.get(subject)
  if (!observers) {
    observers = new Set()
    subjectObservers.set(subject, observers)
  }
  observers.add(observer)
}

export function getSubjectObservers(subject: object): Set<ObserverR> | undefined {
  return subjectObservers.get(subject)
}

export function removeSubjectObserver(subject: object, observer: ObserverR): void {
  const observers = subjectObservers.get(subject)
  if (observers) {
    observers.delete(observer)
    // Clean up empty sets to prevent memory leaks
    if (observers.size === 0) {
      subjectObservers.delete(subject)
    }
  }
}

export function removeAllSubjectObservers(subject: object): void {
  subjectObservers.delete(subject)
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip disposed observers
  if (observer.disposed) {
    return
  }
  
  // Prevent infinite recursion
  if (updatingObservers.has(observer)) {
    return
  }
  
  updatingObservers.add(observer)
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // After updating, notify any observers that depend on this observer
    const dependentObservers = getSubjectObservers(observer)
    if (dependentObservers) {
      for (const dependent of dependentObservers) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
  } finally {
    updatingObservers.delete(observer)
    activeObserver = previous
  }
}
