/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addSubjectObserver,
  getSubjectObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Default equality function
  const equalFn: EqualFn<T> = equal === true 
    ? (a, b) => a === b 
    : typeof equal === 'function' 
    ? equal 
    : (a, b) => a === b

  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer as a dependent of this input (subject)
      addSubjectObserver(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all registered observers
      const observers = getSubjectObservers(s)
      if (observers) {
        for (const observer of observers) {
          updateObserver(observer as Observer<unknown>)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
