/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addSubjectObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track if this is the first access to avoid double computation
  let isFirstAccess = true
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    // Register this computed as a subject that currentObserver depends on
    if (currentObserver) {
      addSubjectObserver(o, currentObserver)
    }
    
    // Recompute to get the latest value and refresh dependencies
    if (currentObserver || isFirstAccess) {
      updateObserver(o)
      if (isFirstAccess) isFirstAccess = false
    }
    
    return o.value!
  }

  return getter
}