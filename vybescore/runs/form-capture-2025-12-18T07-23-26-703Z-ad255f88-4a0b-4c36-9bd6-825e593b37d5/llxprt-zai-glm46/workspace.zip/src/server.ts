import express from 'express';
import path from 'path';
import DatabaseService from './database.js';
import ValidationService, { FormData, ValidationError } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;

// Initialize services
const database = new DatabaseService();
const validator = new ValidationService();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const validationResult = validator.validateFormData(formData);

    if (!validationResult.isValid) {
      // Return to form with errors and entered values
      return res.status(400).render('form', {
        errors: validationResult.errors,
        values: formData
      });
    }

    // Save to database
    await database.insertSubmission(formData);

    // Redirect to thank you page
    res.redirect('/thank-you');

  } catch (error) {
    console.error('Error processing form submission:', error);
    
    // Return a generic error
    const errors: ValidationError[] = [{
      field: 'general',
      message: 'An unexpected error occurred. Please try again.'
    }];
    
    res.status(500).render('form', {
      errors,
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    firstName: 'Friend'
  });
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: [{ field: 'general', message: 'Internal server error' }],
    values: {}
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).render('form', {
    errors: [{ field: 'general', message: 'Page not found' }],
    values: {}
  });
});

// Initialize database and start server
async function startServer() {
  try {
    await database.initialize();
    
    const server = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });

    // Graceful shutdown handling
    const gracefulShutdown = (signal: string) => {
      console.log(`
Received ${signal}. Closing server gracefully...`);
      
      server.close(() => {
        console.log('HTTP server closed');
        database.close();
        console.log('Database connection closed');
        process.exit(0);
      });

      // Force close after 10 seconds
      setTimeout(() => {
        console.error('Could not close connections in time, forcefully shutting down');
        database.close();
        process.exit(1);
      }, 10000);
    };

    // Handle SIGTERM and SIGINT
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
