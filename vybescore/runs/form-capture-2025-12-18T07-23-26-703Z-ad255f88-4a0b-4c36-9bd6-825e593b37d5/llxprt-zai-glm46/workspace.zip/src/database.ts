import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';
import { Database } from 'sql.js';

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface Submission extends FormData {
  id: number;
  created_at: string;
}

class DatabaseService {
  private db: Database | null = null;
  private SQL: { Database: new(data?: ArrayBuffer) => Database } | null = null;
  private dbPath: string = path.join(process.cwd(), 'data', 'submissions.sqlite');

  async initialize(): Promise<void> {
    try {
      this.SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

    // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileData = fs.readFileSync(this.dbPath);
        const arrayBuffer = fileData.buffer.slice(fileData.byteOffset, fileData.byteOffset + fileData.byteLength);
        this.db = new this.SQL!.Database(arrayBuffer);
        console.log('Loaded existing database from', this.dbPath);
      } else {
        this.db = new this.SQL!.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    try {
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (this.db as any).run(schema);
      this.saveToFile();
    } catch (error) {
      console.error('Failed to create schema:', error);
      throw error;
    }
  }

  private saveToFile(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    try {
      const data = this.db!.export();
      const buffer = Buffer.from(data.buffer, data.byteOffset, data.byteLength);
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async insertSubmission(formData: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Use run() instead of prepare() to avoid parameter binding issues
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (this.db as any).run(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        formData.first_name,
        formData.last_name,
        formData.street_address,
        formData.city,
        formData.state_province,
        formData.postal_code,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const result = (this.db as any).exec('SELECT last_insert_rowid() as id');
      const insertId = result[0].values[0][0] as number;
      
      this.saveToFile();
      return insertId;
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const result = (this.db as any).exec('SELECT * FROM submissions ORDER BY created_at DESC');
      
      if (result.length === 0) {
        return [];
      }

      const columns = result[0].columns;
      const values = result[0].values;

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return values.map((row: any) => {
        const submission: Partial<Submission> = {};
        columns.forEach((column: string, index: number) => {
          (submission as Record<string, unknown>)[column] = row[index];
        });
        return submission as Submission;
      });
    } catch (error) {
      console.error('Failed to get submissions:', error);
      throw error;
    }
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseService;
export type { FormData, Submission };