interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  sanitizedData?: FormData;
}

class ValidationService {
  private sanitizeString(str: string): string {
    return str.trim().replace(/\s+/g, ' ');
  }

  private validateRequired(value: string, fieldName: string): ValidationError | null {
    if (!value || value.trim().length === 0) {
      return {
        field: fieldName,
        message: `${fieldName.replace('_', ' ').charAt(0).toUpperCase() + fieldName.replace('_', ' ').slice(1)} is required`
      };
    }
    return null;
  }

  private validateEmail(email: string): ValidationError | null {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return {
        field: 'email',
        message: 'Please enter a valid email address'
      };
    }
    return null;
  }

  private validatePhone(phone: string): ValidationError | null {
    // Allow international formats with optional leading +
    const phoneRegex = /^\+?[0-9\s()-]+$/;
    if (!phoneRegex.test(phone)) {
      return {
        field: 'phone',
        message: 'Please enter a valid phone number (digits, spaces, dashes, parentheses, optional leading +)'
      };
    }
    
    // Ensure there are at least 6 digits for a reasonable phone number
    const digitCount = phone.replace(/\D/g, '').length;
    if (digitCount < 6) {
      return {
        field: 'phone',
        message: 'Phone number appears too short'
      };
    }
    
    return null;
  }

  private validatePostalCode(postalCode: string): ValidationError | null {
    // Allow alphanumeric postal codes (UK, Argentina, etc.)
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(postalCode)) {
      return {
        field: 'postal_code',
        message: 'Please enter a valid postal/zip code'
      };
    }
    return null;
  }

  private validateName(name: string, fieldName: string): ValidationError | null {
    // Allow letters, spaces, hyphens, and apostrophes
    const nameRegex = /^[a-zA-Z\s'-]+$/;
    if (!nameRegex.test(name)) {
      return {
        field: fieldName,
        message: `${fieldName.replace('_', ' ').charAt(0).toUpperCase() + fieldName.replace('_', ' ').slice(1)} can only contain letters, spaces, hyphens, and apostrophes`
      };
    }
    
    if (name.trim().length < 2) {
      return {
        field: fieldName,
        message: `${fieldName.replace('_', ' ').charAt(0).toUpperCase() + fieldName.replace('_', ' ').slice(1)} must be at least 2 characters long`
      };
    }
    
    return null;
  }

  validateFormData(data: Partial<FormData>): ValidationResult {
    const errors: ValidationError[] = [];
    const sanitizedData: Partial<FormData> = {};

    // Validate and sanitize each field
    const requiredFields: (keyof FormData)[] = [
      'first_name', 'last_name', 'street_address', 'city',
      'state_province', 'postal_code', 'country', 'email', 'phone'
    ];

    requiredFields.forEach((field) => {
      const value = data[field] || '';
      const sanitized = this.sanitizeString(value);
      sanitizedData[field] = sanitized;

      // Check if required
      const requiredError = this.validateRequired(sanitized, field);
      if (requiredError) {
        errors.push(requiredError);
        return;
      }

      // Field-specific validations
      switch (field) {
        case 'first_name':
        case 'last_name': {
          const nameError = this.validateName(sanitized, field);
          if (nameError) errors.push(nameError);
          break;
        }

        case 'email': {
          const emailError = this.validateEmail(sanitized);
          if (emailError) errors.push(emailError);
          break;
        }

        case 'phone': {
          const phoneError = this.validatePhone(sanitized);
          if (phoneError) errors.push(phoneError);
          break;
        }

        case 'postal_code': {
          const postalError = this.validatePostalCode(sanitized);
          if (postalError) errors.push(postalError);
          break;
        }

        case 'country':
        case 'state_province':
        case 'city':
        case 'street_address': {
          // Basic validation for text fields
          if (sanitized.length < 2) {
            errors.push({
              field,
              message: `${field.replace('_', ' ').charAt(0).toUpperCase() + field.replace('_', ' ').slice(1)} must be at least 2 characters long`
            });
          }
          break;
        }
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
      sanitizedData: errors.length === 0 ? sanitizedData as FormData : undefined
    };
  }

  // Helper method to get error message for a specific field
  getErrorForField(errors: ValidationError[], field: string): string | undefined {
    const error = errors.find(err => err.field === field);
    return error?.message;
  }
}

export default ValidationService;
export type { FormData, ValidationError, ValidationResult };