/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check if input length is valid for Base64 (with or without padding)
  const paddedLength = Math.ceil(input.length / 4) * 4;
  if (paddedLength !== input.length && (input.length % 4 === 1)) {
    throw new Error('Invalid Base64 input: length must be multiple of 4 or 2 when missing padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
