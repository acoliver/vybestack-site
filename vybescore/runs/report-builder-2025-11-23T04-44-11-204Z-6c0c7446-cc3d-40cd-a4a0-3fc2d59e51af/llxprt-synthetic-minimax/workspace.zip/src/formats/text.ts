import { ReportData } from '../types.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('Entries:');
  
  // Format each entry as bullet list
  for (const entry of data.entries) {
    const amount = formatAmount(entry.amount);
    lines.push(`- ${entry.label}: ${amount}`);
  }
  
  // Add total if requested
  if (includeTotals) {
    lines.push('');
    const total = calculateTotal(data.entries);
    const totalFormatted = formatAmount(total);
    lines.push(`Total: ${totalFormatted}`);
  }
  
  return lines.join('\n');
}

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}