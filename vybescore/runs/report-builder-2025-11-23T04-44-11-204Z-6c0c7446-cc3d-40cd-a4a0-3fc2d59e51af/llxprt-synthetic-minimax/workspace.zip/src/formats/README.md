# Report Formats

This directory contains formatters for the Report Builder CLI. Each formatter exports a function that renders report data into a specific format.

## Interface

All formatters must export a function with the following signature:

```typescript
import { ReportData } from '../types.js';

function render(data: ReportData, includeTotals: boolean): string
```

### Parameters

- `data`: The report data containing title, summary, and entries
- `includeTotals`: Whether to include a total amount in the output

### Returns

A formatted string representation of the report.

## Available Formats

### Markdown (`markdown.ts`)
Renders reports in Markdown format with:
- `#` prefix for title
- `##` prefix for entries section
- Bold formatting for labels: `**label**`
- Dollar amounts with two decimal places

### Text (`text.ts`)
Renders reports in plain text format with:
- Plain text title
- Plain text entries section
- Simple bullet points with colon separation
- Dollar amounts with two decimal places

## Adding New Formats

To add a new format:

1. Create a new file (e.g., `html.ts`)
2. Import the `ReportData` type from `../types.js`
3. Export a function matching the interface above
4. Implement your formatting logic
5. Update the CLI to import and use your new formatter

## Amount Formatting

All amounts should be formatted as `$12345.67` (two decimal places, no thousands separators) to ensure consistency across formats.