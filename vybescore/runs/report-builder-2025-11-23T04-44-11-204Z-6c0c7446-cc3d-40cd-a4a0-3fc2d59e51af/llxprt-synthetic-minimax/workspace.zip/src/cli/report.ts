#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { createWriteStream } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CLIOptions } from '../types.js';

function parseArgs(args: string[]): CLIOptions & { inputFile: string } {
  const options: CLIOptions = {
    format: 'markdown',
    output: undefined,
    includeTotals: false
  };
  
  let inputFile = '';
  let i = 2; // Skip node and script name
  
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing value for --format');
      }
      options.format = args[i] as 'markdown' | 'text';
      if (options.format !== 'markdown' && options.format !== 'text') {
        throw new Error(`Unsupported format: ${options.format}`);
      }
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing value for --output');
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (!inputFile) {
        inputFile = arg;
      } else {
        throw new Error('Multiple input files specified');
      }
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
    
    i++;
  }
  
  if (!inputFile) {
    throw new Error('Input file is required');
  }
  
  return { ...options, inputFile };
}

function readAndValidateJSON(filePath: string): ReportData {
  let content: string;
  
  try {
    content = readFileSync(filePath, 'utf8');
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw new Error(`Failed to read file: ${filePath}`);
  }
  
  let data: unknown;
  
  try {
    data = JSON.parse(content);
  } catch {
    throw new Error(`Invalid JSON in file: ${filePath}`);
  }
  
  if (!data || typeof data !== 'object') {
    throw new Error(`Invalid data structure in file: ${filePath}`);
  }
  
  const reportData = data as Partial<ReportData>;
  
  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid "title" field');
  }
  
  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid "entries" field');
  }
  
  for (const [index, entry] of reportData.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}`);
    }
    
    const typedEntry = entry as Partial<{ label: string; amount: number }>;
    
    if (!typedEntry.label || typeof typedEntry.label !== 'string') {
      throw new Error(`Missing or invalid "label" field in entry ${index}`);
    }
    
    if (typeof typedEntry.amount !== 'number') {
      throw new Error(`Missing or invalid "amount" field in entry ${index}`);
    }
  }
  
  return reportData as ReportData;
}

function renderReport(data: ReportData, options: CLIOptions): string {
  if (options.format === 'markdown') {
    return renderMarkdown(data, options.includeTotals);
  } else if (options.format === 'text') {
    return renderText(data, options.includeTotals);
  } else {
    throw new Error(`Unsupported format: ${options.format}`);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const options = parseArgs(args);
    const data = readAndValidateJSON(options.inputFile);
    const output = renderReport(data, options);
    
    if (options.output) {
      const stream = createWriteStream(options.output);
      stream.write(output);
      stream.end();
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();