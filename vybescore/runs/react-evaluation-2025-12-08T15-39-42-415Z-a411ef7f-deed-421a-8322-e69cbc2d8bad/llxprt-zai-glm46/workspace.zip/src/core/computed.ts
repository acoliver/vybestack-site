/**
 * Computed closure implementation for derived values.
 */

/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equal to proper EqualFn
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is :
    equal === false ? undefined :
    equal

  // Store all observers that depend on this computed value
  const dependents = new Set<ObserverR>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set()
  }
  
  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // When this computed value is accessed by another observer,
      // add that observer as a dependent
      dependents.add(currentObserver)
      // Also store the relationship for cleanup
      if (!currentObserver.dependents) {
        currentObserver.dependents = new Set()
      }
    }
    return observer.value!
  }
  
  // Override the observer's updateFn to handle equality checking
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (currentValue?: T) => {
    const newValue = originalUpdateFn(currentValue)
    
    // Only update if value changed or no equality function
    if (!equalFn || !equalFn(observer.value!, newValue)) {
      observer.value = newValue
      
      // Notify all dependent observers
      for (const dependent of dependents) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
    
    return observer.value!
  }
  
  // Initial computation
  updateObserver(observer)
  
  return read
}
