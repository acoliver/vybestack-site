/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equal to proper EqualFn
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is :
    equal === false ? undefined :
    equal

  // Store all observers that depend on this input
  const dependents = new Set<ObserverR>()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Add current observer as a dependent of this input
      dependents.add(observer)
      // Store dependents on the observer for cleanup
      if (!observer.dependents) {
        observer.dependents = new Set()
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value changed or no equality function
    if (!equalFn || !equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all dependent observers
      for (const dependent of dependents) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}
