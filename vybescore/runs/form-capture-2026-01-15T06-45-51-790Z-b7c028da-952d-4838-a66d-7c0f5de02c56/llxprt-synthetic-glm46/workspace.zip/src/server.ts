import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, closeDatabase, insertSubmission } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 3535;

const app = express();

// Set up EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

//middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

import { Request, Response } from 'express';

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData = req.body;
    const errors = validateForm(formData);
    
    if (Object.keys(errors).length > 0) {
      return res.status(400).render('form', { errors, formData });
    }
    
    await insertSubmission(formData);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', { 
      errors: { general: 'An error occurred while submitting your form. Please try again.' },
      formData: req.body 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

function validateForm(formData: Record<string, string>): Record<string, string> {
  const errors: Record<string, string> = {};
  
  if (!formData.first_name || formData.first_name.trim() === '') {
    errors.first_name = 'First name is required';
  }
  
  if (!formData.last_name || formData.last_name.trim() === '') {
    errors.last_name = 'Last name is required';
  }
  
  if (!formData.street_address || formData.street_address.trim() === '') {
    errors.street_address = 'Street address is required';
  }
  
  if (!formData.city || formData.city.trim() === '') {
    errors.city = 'City is required';
  }
  
  if (!formData.state_province || formData.state_province.trim() === '') {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!formData.postal_code || formData.postal_code.trim() === '') {
    errors.postal_code = 'Postal/Zip code is required';
  }
  
  if (!formData.country || formData.country.trim() === '') {
    errors.country = 'Country is required';
  }
  
  if (!formData.email || formData.email.trim() === '') {
    errors.email = 'Email is required';
  } else if (!isValidEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!formData.phone || formData.phone.trim() === '') {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  const phoneRegex = /^[\d\s+\-()]+$/;
  return phoneRegex.test(phone);
}

// Start server and initialize database
async function startServer() {
  await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    server.close(async () => {
      console.log('Express server closed');
      await closeDatabase();
      console.log('Database closed');
      process.exit(0);
    });
  });
  
  return server;
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
