import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't provide type definitions
import initSqlJs from 'sql.js';

interface Database {
  run: (sql: string) => void;
  prepare: (sql: string) => Statement;
  export: () => Uint8Array;
  close: () => void;
}

interface Statement {
  run: (params: unknown[]) => void;
  free: () => void;
}

let db: Database | null = null;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

export async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let fileBuffer: Uint8Array;
    
    // Try to load existing database
    if (fs.existsSync(DB_PATH)) {
      fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } else {
      // Create new database
      db = new SQL.Database();
      console.log('Created new database');
      
      // Read schema and create tables
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schemaSQL = fs.readFileSync(schemaPath, 'utf8');
      // Type assertion needed for sql.js API
      const database = db as Database;
      database.run(schemaSQL);
      console.log('Initialized database schema');
      
      // Save the new database
      saveDatabaseToFile();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export async function closeDatabase(): Promise<void> {
  if (db !== null) {
    try {
      saveDatabaseToFile();
      // Type assertion needed for sql.js API
      const database = db as Database;
      database.close();
      db = null;
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
      throw error;
    }
  }
}

export async function insertSubmission(formData: Record<string, string>): Promise<void> {
  try {
    if (db === null) {
      throw new Error('Database not initialized');
    }
    
    // Type assertion needed for sql.js API
    const database = db as Database;
    const stmt = database.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.first_name.trim(),
      formData.last_name.trim(),
      formData.street_address.trim(),
      formData.city.trim(),
      formData.state_province.trim(),
      formData.postal_code.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    ]);
    
    stmt.free();
    saveDatabaseToFile();
    console.log('Form submission saved to database');
  } catch (error) {
    console.error('Error inserting submission:', error);
    throw error;
  }
}

export function getDatabase(): unknown {
  return db;
}

function saveDatabaseToFile(): void {
  try {
    if (db === null) return;
    
    // Type assertion needed for sql.js API
    const database = db as Database;
    const data = database.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (error) {
    console.error('Error saving database to file:', error);
  }
}