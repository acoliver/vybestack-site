import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';



// Set up __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

// Validation errors type
interface ValidationError {
  field: string;
  message: string;
}

// Form data type
interface FormData {
  [key: string]: string | undefined;
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Initialize Express app
const app = express();
const port = process.env.PORT || 3535;

// Set up middleware
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
// eslint-disable-next-line @typescript-eslint/no-explicit-any
import { Database } from 'sql.js';
let db: Database;

async function initializeDB(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let data: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    }
    
    db = new SQL.Database(data!);
    
    // Ensure table exists by executing schema ifneeded
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database back to disk
function saveDB(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation helpers
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  if (!phoneRegex.test(phone)) {
    return { field: 'phone', message: 'Please enter a valid phone number' };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  if (!postalRegex.test(postalCode)) {
    return { field: 'postalCode', message: 'Please enter a valid postal code' };
  }
  return null;
}

// Validate form data
function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  Object.keys(formData).forEach(key => {
    if (key !== 'country') {  // Country is also required but handled separately
      const error = validateRequired(formData[key] || '', key.replace(/([A-Z])/g, ' $1').trim());
      if (error) errors.push(error);
    }
  });
  
  // Email validation
  if (formData.email) {
    const error = validateEmail(formData.email);
    if (error) errors.push(error);
  }
  
  // Phone validation
  if (formData.phone) {
    const error = validatePhone(formData.phone);
    if (error) errors.push(error);
  }
  
  // Postal code validation
  if (formData.postalCode) {
    const error = validatePostalCode(formData.postalCode);
    if (error) errors.push(error);
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    const errorMessages = errors.map(error => error.message);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName || '',
      formData.lastName || '',
      formData.streetAddress || '',
      formData.city || '',
      formData.stateProvince || '',
      formData.postalCode || '',
      formData.country || '',
      formData.email || '',
      formData.phone || ''
    ]);
    
    stmt.free();
    saveDB();
    
    // Redirect to thank you page
    return res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while submitting the form. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {}
  });
});

// Initialize database then start server
async function startServer(): Promise<void> {
  await initializeDB();
  
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
  
  // Graceful shutdown
  const shutdown = (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully`);
    server.close(() => {
      console.log('Server closed');
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
