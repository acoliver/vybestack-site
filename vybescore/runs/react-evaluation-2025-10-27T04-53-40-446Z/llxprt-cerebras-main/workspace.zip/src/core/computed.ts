/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  registerSetActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Dependencies tracking
  const dependencies = new Set<Observer<unknown>>()
  
  // Create enhanced update function that automatically tracks dependencies
  const enhancedUpdateFn: UpdateFn<T> = (prev?: T) => {
    // Save current dependencies before clearing
    const oldDependencies = new Set(dependencies)
    dependencies.clear()
    
    // Temporarily override setActiveObserver to capture dependencies
    const originalSetActiveObserver = registerSetActiveObserver
    
    // Register a function to capture dependencies during computation
    registerSetActiveObserver((observer: ObserverR | undefined) => {
      if (observer && observer !== o) {
        dependencies.add(observer as Observer<unknown>)
      }
    })
    
    try {
      const result = updateFn(prev)
      return result
    } finally {
      // Restore original function registration
      registerSetActiveObserver(undefined as any) // Reset to undefined to use default behavior
      
      // Clean up old dependencies that are no longer used
      oldDependencies.forEach(dep => {
        if (!dependencies.has(dep)) {
          // In a full implementation, we'd remove ourselves from dep's observers list
        }
      })
    }
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: enhancedUpdateFn,
  }

  // Update observer to compute initial value
  updateObserver(o)

  const read: GetterFn<T> = () => {
    // When this computed value is read, track it as a dependency of the current observer
    const observer = getActiveObserver()
    if (observer) {
      dependencies.add(observer)
    }
    return o.value!
  }

  return read
}