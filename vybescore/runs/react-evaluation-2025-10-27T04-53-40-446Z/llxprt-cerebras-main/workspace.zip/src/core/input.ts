/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle the equal parameter - if it's a boolean, use Object.is, otherwise use the provided function
  const equalFn = typeof equal === 'function' 
    ? equal 
    : equal === false 
      ? undefined 
      : Object.is

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track that this observer depends on this subject
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has actually changed
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      // Notify all observers of the change
      s.observers.forEach(obs => updateObserver(obs as Observer<unknown>))
    }
    return s.value
  }

  return [read, write]
}