declare module 'sql.js' {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    exec(sql: string): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): unknown;
    get(): unknown;
    all(): unknown[];
    free(): void;
  }

  export interface SqlJsOptions {
    locateFile?: (file: string) => string;
  }

  export function initSqlJs(options?: SqlJsOptions): Promise<SqlJsStatic>;

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }
}