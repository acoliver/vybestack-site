/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes padding characters as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Basic validation for Base64 format
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 format: contains characters outside the Base64 alphabet');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
