// Test padding edge cases
const { encode, decode } = require('./dist/src/base64.js');

// 1-character input should have 2 padding chars
console.log('1 char encode:', encode('a'));
console.log('Expected: YQ==');

// 2-character input should have 1 padding char
console.log('2 chars encode:', encode('ab'));
console.log('Expected: YWI=');

// 3-character input should have no padding
console.log('3 chars encode:', encode('abc'));
console.log('Expected: YWJj');

// Test that we can decode with or without padding
console.log('Decode with padding:', decode('YQ=='));
console.log('Decode without padding:', decode('YQ'));

// Test characters that produce + and / in Base64
console.log('Should contain +:', encode('anybody'));
console.log('Should contain /:', encode('question'));

console.log('Decode base64 with + and /:', decode('YW55Ym9keQ=='));
console.log('Decode base64 with + and /:', decode('cXVlc3Rpb24='));