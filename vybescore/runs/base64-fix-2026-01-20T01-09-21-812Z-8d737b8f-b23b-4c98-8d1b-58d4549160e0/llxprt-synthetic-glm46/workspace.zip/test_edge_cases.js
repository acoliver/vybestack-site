// Testing edge cases for Base64 implementation
import { encode, decode } from './dist/src/index.js';

console.log('Empty string encode:', encode(''));

console.log('Empty string decode:', decode(''));

console.log('Special chars encode:', encode('hello+world'));
console.log('Expected:', 'aGVsbG8rd29ybGQ=');

console.log('With padding decode:', decode('aGVsbG8='));

console.log('Without padding decode:', decode('aGVsbG8'));

console.log('Non-ASCII encode:', encode('café'));

console.log('Invalid Base64 test:');
try {
  decode('!!!invalid!!!');
} catch (e) {
  console.log('Rejected invalid input:', e.message);
}