/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function validateBase64Input(input: string): void {
  const trimmed = input.trim();
  
  // Basic validation: check for valid Base64 characters and padding rules
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding position
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    validatePadding(trimmed, paddingIndex);
  }
}

function validatePadding(trimmed: string, paddingIndex: number): void {
  const paddingPart = trimmed.substring(paddingIndex);
  
  // If there's padding, ensure it's only at the end and no more than 2 characters
  if (!/^=+$/.test(paddingPart) || paddingPart.length > 2) {
    throw new Error('Invalid Base64 input: invalid padding');
  }
  
  // Ensure no characters after padding
  if (paddingIndex < trimmed.length - paddingPart.length) {
    throw new Error('Invalid Base64 input: padding not at end');
  }
}

function validateDecodedResult(trimmed: string, result: string): void {
  if (trimmed.length === 0) return;
  
  const encoded = Buffer.from(result, 'utf8').toString('base64');
  // Remove padding from our encoded result for comparison if input has no padding
  const normalizedInput = trimmed.replace(/=+$/, '');
  const normalizedEncoded = encoded.replace(/=+$/, '');
  if (normalizedInput !== normalizedEncoded && trimmed !== encoded) {
    throw new Error('Invalid Base64 input: corrupted data');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  validateBase64Input(input);

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    validateDecodedResult(trimmed, result);
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
