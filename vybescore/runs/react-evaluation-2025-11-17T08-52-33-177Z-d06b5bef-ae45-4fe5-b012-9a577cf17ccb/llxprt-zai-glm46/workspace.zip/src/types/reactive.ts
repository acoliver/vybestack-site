/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T = any> = {
  update: () => void
  dependencies: Set<Signal<any>>
  dependents: Set<Observer<any>>
}

export type Signal<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<any>>
}

let currentObserver: Observer<any> | null = null

export function getCurrentObserver(): Observer<any> | null {
  return currentObserver
}

export function setCurrentObserver(observer: Observer<any> | null): void {
  currentObserver = observer
}

export function track(signal: Signal<any>): void {
  if (currentObserver) {
    currentObserver.dependencies.add(signal)
    signal.observers.add(currentObserver)
  }
}

export function trigger(signal: Signal<any>): void {
  for (const observer of signal.observers) {
    if (observer.dependencies.has(signal)) {
      observer.update()
    }
  }
}

export function cleanupObserver(observer: Observer<any>): void {
  for (const dependency of observer.dependencies) {
    dependency.observers.delete(observer)
  }
  observer.dependencies.clear()
  observer.dependents.clear()
}