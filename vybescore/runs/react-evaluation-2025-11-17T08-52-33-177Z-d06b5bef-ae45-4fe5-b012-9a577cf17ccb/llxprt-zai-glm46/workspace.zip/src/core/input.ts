import { EqualFn, GetterFn, InputPair, Options, SetterFn, Signal, getCurrentObserver, track, trigger } from '../types/reactive.ts'

/**
 * Creates a reactive input with getter/setter functionality
 * @param value Initial value
 * @param equal Optional equality function
 * @param options Optional configuration
 * @returns [getter, setter] pair
 */
export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  const signal: Signal<T> = {
    value,
    equalFn: equal,
    observers: new Set()
  }

  const getter: GetterFn<T> = () => {
    track(signal)
    return signal.value
  }

  const setter: SetterFn<T> = (newValue: T): T => {
    // Check if value actually changed using equality function or strict equality
    const hasChanged = signal.equalFn ? !signal.equalFn(signal.value, newValue) : signal.value !== newValue
    
    if (hasChanged) {
      signal.value = newValue
      trigger(signal)
    }
    
    return signal.value
  }

  return [getter, setter]
}