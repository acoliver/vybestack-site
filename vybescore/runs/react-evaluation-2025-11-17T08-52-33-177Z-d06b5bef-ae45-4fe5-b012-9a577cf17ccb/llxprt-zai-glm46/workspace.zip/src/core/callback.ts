import { UpdateFn, UnsubscribeFn, getCurrentObserver, setCurrentObserver, cleanupObserver, Observer } from '../types/reactive.ts'

/**
 * Creates a side-effect callback that reacts to dependency changes
 * @param updateFn Function that executes when dependencies change
 * @param value Optional initial value
 * @returns unsubscribe function
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>,
  value?: T
): UnsubscribeFn {
  const observer: Observer<T> = {
    dependencies: new Set(),
    dependents: new Set(),
    update: () => {
      // Clean up old dependencies
      cleanupObserver(observer)
      
      // Set current observer and execute callback
      const prevObserver = getCurrentObserver()
      setCurrentObserver(observer)
      try {
        updateFn()
      } finally {
        setCurrentObserver(prevObserver)
      }
    }
  }

  // Initial execution to establish dependencies
  observer.update()

  // Return unsubscribe function
  const unsubscribe: UnsubscribeFn = () => {
    cleanupObserver(observer)
  }

  return unsubscribe
}