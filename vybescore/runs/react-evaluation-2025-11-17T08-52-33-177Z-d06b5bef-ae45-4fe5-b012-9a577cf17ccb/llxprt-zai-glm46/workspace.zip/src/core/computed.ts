import { EqualFn, GetterFn, Options, UpdateFn, Signal, getCurrentObserver, setCurrentObserver, track, trigger, cleanupObserver, Observer } from '../types/reactive.ts'

/**
 * Creates a computed value that reacts to dependencies
 * @param updateFn Function that computes the value
 * @param value Optional initial value
 * @param equal Optional equality function
 * @param options Optional configuration
 * @returns getter function
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const signal: Signal<T> = {
    value: value as T,
    equalFn: equal,
    observers: new Set()
  }

  const observer: Observer<T> = {
    dependencies: new Set(),
    dependents: new Set(),
    update: () => {
      // Clean up old dependencies
      cleanupObserver(observer)
      
      // Set current observer and compute new value
      const prevObserver = getCurrentObserver()
      setCurrentObserver(observer)
      try {
        const newValue = updateFn()
        const hasChanged = signal.equalFn ? !signal.equalFn(signal.value, newValue) : signal.value !== newValue
        
        if (hasChanged) {
          signal.value = newValue
          // Trigger all observers of this computed signal
          trigger(signal)
        }
      } finally {
        setCurrentObserver(prevObserver)
      }
    }
  }

  // Initial computation
  observer.update()

  const getter: GetterFn<T> = () => {
    const currentObs = getCurrentObserver()
    if (currentObs) {
      // If accessed within another observer, establish dependency relationship
      track(signal)
    }
    return signal.value
  }

  return getter
}