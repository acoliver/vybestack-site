import { defineConfig } from 'vitest/config'

export default defineConfig({
  esbuild: {
    target: 'node18'
  },
  test: {
    include: ['tests/public/**/*.spec.ts'],
    environment: 'node',
    pool: 'forks',
    poolOptions: {
      forks: {
        singleFork: true
      }
    }
  }
})