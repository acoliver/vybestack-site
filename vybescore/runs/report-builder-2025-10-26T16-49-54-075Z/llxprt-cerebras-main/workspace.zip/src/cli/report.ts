import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions } from '../formats/interfaces.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Define format renderers
const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText
};

// Parse command line arguments
function parseArgs(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      format = args[++i];
    } else if (args[i] === '--output') {
      outputPath = args[++i];
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Missing required --format argument');
    process.exit(1);
  }

  if (!Object.keys(formatRenderers).includes(format)) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

// Validate and parse JSON data
function parseData(dataPath: string): ReportData {
  try {
    const data = JSON.parse(readFileSync(dataPath, 'utf-8'));
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return data;
  } catch (error) {
    console.error(`Error parsing JSON data: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

// Main function
function main() {
  const { dataPath, format, outputPath, includeTotals } = parseArgs();
  const data = parseData(dataPath);
  const options: ReportOptions = { includeTotals };
  
  const renderer = formatRenderers[format as keyof typeof formatRenderers];
  const output = renderer(data, options);
  
  if (outputPath) {
    // Write to file if output path is provided
    try {
      writeFileSync(outputPath, output);
      console.log(`Report written to ${outputPath}`);
    } catch (error) {
      console.error(`Error writing to file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    // Output to stdout
    console.log(output);
  }
}

main();