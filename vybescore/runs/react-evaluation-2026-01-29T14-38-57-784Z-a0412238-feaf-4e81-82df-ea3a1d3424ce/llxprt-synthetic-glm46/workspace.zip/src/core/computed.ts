/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let cached = false
  
  const getter = (): T => {
    if (!cached) {
      updateObserver(o)
      cached = true
    }
    return o.value!
  }
  
  // Mark as not cached when any dependency updates
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    cached = false
    return originalUpdateFn(prevValue)
  }
  
  // Initial computation
  getter()
  
  return getter
}
