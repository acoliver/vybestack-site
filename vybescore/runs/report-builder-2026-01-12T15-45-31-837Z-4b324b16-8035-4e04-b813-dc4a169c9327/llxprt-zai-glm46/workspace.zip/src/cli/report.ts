#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage:
 *   node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 *
 * Supported formats: markdown, text
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { FORMATS } from '../formats/index.js';
import { validateReportData, type RenderOptions } from '../types.js';

/**
 * Parses command line arguments.
 * Uses only Node's standard library (no third-party parsers).
 */
function parseArgs(args: string[]): {
  inputPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  let inputPath: string | null = null;
  let format: string | null = null;
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
      continue;
    }

    if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
      continue;
    }

    if (arg === '--includeTotals') {
      includeTotals = true;
      continue;
    }

    // Positional argument (input file)
    if (!arg.startsWith('-')) {
      if (inputPath !== null) {
        throw new Error(`Unexpected argument: ${arg}`);
      }
      inputPath = arg;
      continue;
    }

    throw new Error(`Unknown option: ${arg}`);
  }

  if (inputPath === null) {
    throw new Error('Input file path is required');
  }

  if (format === null) {
    throw new Error('--format is required (supported: markdown, text)');
  }

  return { inputPath, format, outputPath, includeTotals };
}

/**
 * Loads and parses the JSON input file.
 */
function loadInputData(path: string): unknown {
  const resolvedPath = resolve(path);
  const content = readFileSync(resolvedPath, 'utf-8');
  try {
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${path}: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Main CLI entry point.
 */
function main(): void {
  try {
    const args = process.argv.slice(2);
    const { inputPath, format, outputPath, includeTotals } = parseArgs(args);

    // Load and validate input data
    const rawData = loadInputData(inputPath);
    const data = validateReportData(rawData);

    // Get the renderer for the requested format
    const renderer = FORMATS[format];
    if (!renderer) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Render the report
    const options: RenderOptions = { includeTotals };
    const output = renderer(data, options);

    // Write to output file or stdout
    if (outputPath !== null) {
      const resolvedPath = resolve(outputPath);
      writeFileSync(resolvedPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
