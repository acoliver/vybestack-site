/**
 * Text report formatter.
 */

import type { ReportRenderer } from './types.js';
import { computeTotal, formatAmount, type ReportData, type RenderOptions } from '../types.js';

export const renderText: ReportRenderer = (data: ReportData, options: RenderOptions) => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Optional totals
  if (options.includeTotals) {
    lines.push('');
    lines.push(`Total: ${formatAmount(computeTotal(data.entries))}`);
  }

  return lines.join('\n');
};
