/**
 * Shared interface for report formatters.
 * Each format should export a render function with this signature.
 */

import type { ReportData, RenderOptions } from '../types.js';

export type ReportRenderer = (
  data: ReportData,
  options: RenderOptions
) => string;
