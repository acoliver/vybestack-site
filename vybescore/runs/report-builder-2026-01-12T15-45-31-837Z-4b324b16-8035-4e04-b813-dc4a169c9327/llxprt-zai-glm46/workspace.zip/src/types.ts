/**
 * Shared data model for report rendering.
 */

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Computes the total amount from all entries.
 */
export function computeTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Formats an amount with exactly two decimal places.
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Validates that the input data conforms to the ReportData schema.
 * Throws an error with a helpful message if validation fails.
 */
export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid input: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid input: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid input: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid input: missing or invalid "entries" field (expected array)');
  }

  const entries: ReportEntry[] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid input: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid input: entry at index ${i} has missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid input: entry at index ${i} has missing or invalid "amount" field (expected number)`
      );
    }

    entries.push({ label: entryObj.label, amount: entryObj.amount });
  }

  return { title: obj.title, summary: obj.summary, entries };
}
