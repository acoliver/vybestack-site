/// <reference path="./sqljs.d.ts" />
import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string | undefined;
}

const app = express();
const port = process.env.PORT || 3000;

let db: Database | null = null;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Ensure data directory exists
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const dbFile = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbFile);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db.run(schema);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateForm(data: FormData): FormErrors {
  const errors: FormErrors = {};

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`;
    }
  }

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
  if (data.phone && !/^\+?[\d\s()-]+$/.test(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }

  // Postal code validation - alphanumeric
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Postal code can only contain letters, digits, spaces, and dashes';
  }

  return errors;
}



// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);
  const errorMessages = Object.values(errors).filter(Boolean) as string[];

  if (errorMessages.length > 0) {
    res.render('form.ejs', {
      errors: errorMessages,
      values: formData
    });
    return;
  }

  // Save to database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run(
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      );
      
      stmt.free();
      saveDatabase();
    } catch (error) {
      console.error('Database error:', error);
      res.render('form.ejs', {
        errors: ['Database error occurred. Please try again.'],
        values: formData
      });
      return;
    }
  }

  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  let firstName = 'Friend';
  
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
      const result = stmt.getAsObject([]) as { first_name: string };
      stmt.free();
      
      if (result && result.first_name) {
        firstName = result.first_name;
      }
    } catch (error) {
      console.error('Error fetching latest submission:', error);
    }
  }
  
  res.render('thank-you.ejs', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;
