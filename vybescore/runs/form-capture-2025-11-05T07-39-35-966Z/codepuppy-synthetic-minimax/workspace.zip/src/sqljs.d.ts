declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): {
      run(...params: unknown[]): void;
      get(...params: unknown[]): unknown;
      getAsObject(params?: unknown[]): Record<string, unknown>;
      all(...params: unknown[]): unknown[];
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  }
  
  export function initSqlJs(config?: { locateFile?: (file: string) => string }): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
  
  export default initSqlJs;
}