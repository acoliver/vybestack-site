/**
 * Complete reactive programming system with comprehensive dependency tracking.
 */

import type {
  EqualFn,
  GetterFn,
  SetterFn,
  InputPair,
  Options,
  Subject,
  Observer
} from '../types/reactive.js'

import { getActiveObserver } from '../types/reactive.js'

// Global variable to track the currently executing observer
let currentObserverValue: Observer<unknown> | null = null

// Registry: subject -> set of observers
const subjectToObservers = new Map<object, Set<Observer<unknown>>>()

// Registry: observer -> set of subjects it depends on
const observerToSubjects = new Map<Observer<unknown>, Set<object>>()

// Functions to manage the current observer
export function getCurrentObserver<T>(): Observer<T> | null {
  const active = getActiveObserver()
  return (active as Observer<T>) || currentObserverValue as Observer<T> | null
}

export function setCurrentObserver<T>(observer: Observer<T> | null): Observer<T> | null {
  const previous = currentObserverValue as Observer<T> | null
  currentObserverValue = observer as Observer<unknown> | null
  return previous
}

// Function to register a dependency between observer and subject
export function registerDependency<T>(observer: Observer<T>, subject: Subject<T>): void {
  // Add subject to observer's dependencies
  if (!observerToSubjects.has(observer as Observer<unknown>)) {
    observerToSubjects.set(observer as Observer<unknown>, new Set())
  }
  observerToSubjects.get(observer as Observer<unknown>)!.add(subject as object)

  // Add observer to subject's observers
  if (!subjectToObservers.has(subject as object)) {
    subjectToObservers.set(subject as object, new Set())
  }
  subjectToObservers.get(subject as object)!.add(observer as Observer<unknown>)
}

// Function to notify observers when a subject changes
export function notifyObservers<T>(subject: Subject<T> | Observer<T>): void {
  const observers = subjectToObservers.get(subject as object)
  if (observers) {
    // Create a copy to avoid issues during iteration
    const observersCopy = new Set(observers)
    observersCopy.forEach(observer => {
      try {
        // Re-execute the observer's update function
        const previousObserver = currentObserverValue
        currentObserverValue = observer
        const result = observer.updateFn(observer.value)
        
        // Update observer value for computed values (not for callbacks)
        // For callbacks, we still execute the function to trigger side effects
        if (observer.name !== 'callback') {
          observer.value = result
          
          // If this observer is a computed value, it should also notify its own observers
          // Treat computed observers as subjects for notification
          notifyObservers(observer)
        }
        
        currentObserverValue = previousObserver
      } catch (error) {
        console.error('Error notifying observer:', error)
      }
    })
  }
}

// Function to unregister an observer completely
export function unregisterObserver<T>(observer: Observer<T>): void {
  // Remove this observer from all subjects it's observing
  const subjects = observerToSubjects.get(observer as Observer<unknown>)
  if (subjects) {
    subjects.forEach(subject => {
      const observers = subjectToObservers.get(subject)
      if (observers) {
        observers.delete(observer as Observer<unknown>)
        if (observers.size === 0) {
          subjectToObservers.delete(subject)
        }
      }
    })
  }
  observerToSubjects.delete(observer as Observer<unknown>)
}

export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create a subject to hold the reactive state
  const subject: Subject<T> = {
    name: options?.name,
    observer: getActiveObserver(),
    value,
    equalFn: equal
  }

  // Create getter function
  const getter: GetterFn<T> = () => {
    // If we're currently executing an observer, register this subject as a dependency
    if (currentObserverValue) {
      registerDependency(currentObserverValue as Observer<T>, subject)
    }
    return subject.value
  }

  // Create setter function
  const setter: SetterFn<T> = (newValue: T): T => {
    // Check if value has changed using equality function or reference equality
    const hasChanged = subject.equalFn 
      ? !subject.equalFn(subject.value, newValue)
      : subject.value !== newValue

    if (hasChanged) {
      subject.value = newValue
      // Notify all observers that depend on this subject
      notifyObservers(subject)
    }

    return subject.value
  }

  return [getter, setter]
}