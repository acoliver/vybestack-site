/**
 * Callback creation function for reactive programming system.
 * Creates side-effect callbacks that react to dependency changes.
 */

import type {
  UpdateFn,
  UnsubscribeFn,
  Observer
} from '../types/reactive.js'

import { updateObserver } from '../types/reactive.js'

import { setCurrentObserver, unregisterObserver } from './reactive-core.js'

export function createCallback<T>(
  updateFn: UpdateFn<T>,
  value?: T
): UnsubscribeFn {
  // Observer to track dependencies and manage callback execution
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: () => {
      // Execute the user's callback function to track dependencies and perform side effects
      updateFn()
      return value as T
    }
  }

  // Function to execute the callback and track dependencies
  const executeCallback = () => {
    // Set this observer as the current observer during execution
    const previousObserver = setCurrentObserver(observer)
    
    try {
      // Execute the update function to track dependencies and perform side effects
      updateObserver(observer)
    } finally {
      // Restore the previous observer
      setCurrentObserver(previousObserver)
    }
  }

  // Execute callback immediately to establish dependencies
  executeCallback()

  // Create unsubscribe function that properly cleans up dependencies
  return () => {
    // Remove this observer from all dependency tracking
    unregisterObserver(observer)
  }
}