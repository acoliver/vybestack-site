/**
 * Computed value creation function for reactive programming system.
 * Creates computed values that react to dependencies and automatically update.
 */

import type {
  EqualFn,
  GetterFn,
  UpdateFn,
  Options,
  Observer,
  Subject
} from '../types/reactive.js'

import { updateObserver } from '../types/reactive.js'

import { setCurrentObserver, registerDependency, getCurrentObserver } from './reactive-core.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: Options
): GetterFn<T> & { __observer?: Observer<T> } {
  // Observer to track dependencies and manage updates
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn
  }

  // Create getter function that computes the value and tracks dependencies
  const getter: GetterFn<T> = () => {
    // If we're currently executing an observer, register this computed as a dependency
    const currentObserver = getCurrentObserver()
    if (currentObserver) {
      registerDependency(currentObserver as unknown as Observer<unknown>, observer as unknown as Subject<unknown>)
    }

    // Set this observer as the current observer during computation
    const previousObserver = setCurrentObserver(observer)
    
    try {
      // Update the observer which will execute the updateFn and track dependencies
      updateObserver(observer)
      return observer.value as T
    } finally {
      // Restore the previous observer
      setCurrentObserver(previousObserver)
    }
  }

  // Mark this observer as something that can notify others when it changes
  ;(getter as GetterFn<T> & { __observer?: Observer<T> }).__observer = observer

  return getter
}