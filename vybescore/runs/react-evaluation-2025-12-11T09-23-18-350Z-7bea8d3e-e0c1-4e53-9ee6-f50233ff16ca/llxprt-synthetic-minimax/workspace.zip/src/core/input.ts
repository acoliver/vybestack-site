/**
 * Input creation function for reactive programming system.
 * Creates a reactive input with getter/setter functionality.
 */

import type {
  EqualFn,
  InputPair,
  Options
} from '../types/reactive.js'

import { createInput as createInputCore } from './reactive-core.js'

export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  return createInputCore(value, equal, options)
}