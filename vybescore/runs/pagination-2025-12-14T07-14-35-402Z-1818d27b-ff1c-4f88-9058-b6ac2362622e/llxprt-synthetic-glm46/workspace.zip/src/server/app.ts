import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse and validate page parameter
    let page: number | undefined;
    if (pageParam === undefined) {
      // Default will be handled by repository
    } else {
      const parsedPage = Number(pageParam);
      // Reject non-numeric, negative, zero values
      if (isNaN(parsedPage) || parsedPage <= 0) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      // Reject excessive values
      if (parsedPage > 1000) {
        return res.status(400).json({ error: 'Page exceeds maximum allowed value' });
      }
      page = parsedPage;
    }

    // Parse and validate limit parameter
    let limit: number | undefined;
    if (limitParam === undefined) {
      // Default will be handled by repository
    } else {
      const parsedLimit = Number(limitParam);
      // Reject non-numeric, negative, zero values
      if (isNaN(parsedLimit) || parsedLimit <= 0) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      // Reject excessive values
      if (parsedLimit > 100) {
        return res.status(400).json({ error: 'Limit exceeds maximum allowed value' });
      }
      limit = parsedLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
