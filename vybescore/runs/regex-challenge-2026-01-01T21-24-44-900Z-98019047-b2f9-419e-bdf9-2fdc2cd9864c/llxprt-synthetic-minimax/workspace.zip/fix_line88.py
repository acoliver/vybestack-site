#!/usr/bin/env python3
"""Fix the specific problematic line in transformations.ts"""

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the problematic line 88 specifically
# The issue is double-escaped backslashes in regex patterns
old_line = "  const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;"
new_line = "  const urlPattern = /http:\/\//([^/\s]+)(.*)/g;"

content = content.replace(old_line, new_line)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed line 88 regex pattern escaping")