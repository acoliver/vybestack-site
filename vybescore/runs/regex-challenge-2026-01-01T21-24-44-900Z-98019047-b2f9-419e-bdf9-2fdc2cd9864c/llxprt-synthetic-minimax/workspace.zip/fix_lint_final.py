#!/usr/bin/env python3
"""
Fix the lint issues by directly replacing problematic patterns
"""

def fix_lint_issues():
    # Fix transformations.ts
    with open('src/transformations.ts', 'r') as f:
        content = f.read()
    
    # Replace the problematic pattern /http:\\/\\/g with /http:\/\//g
    # This pattern appears on line 56
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if '/http:\\\\\\\\/\\\\\\\\/g' in line:
            lines[i] = line.replace('/http:\\\\\\\\/\\\\\\\\/g', '/http:\/\//g')
        elif '/http:\\\\/\\\\/g' in line:
            lines[i] = line.replace('/http:\\\\/\\\\/g', '/http:\/\//g')
    
    fixed_content = '\n'.join(lines)
    
    with open('src/transformations.ts', 'w') as f:
        f.write(fixed_content)
    
    print("Fixed transformations.ts")
    
    # Fix validators.ts
    with open('src/validators.ts', 'r') as f:
        content = f.read()
    
    # Replace the problematic character class pattern
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if '/[0-9@#$%^&*()_+=\\\\\\\\\\\\\\\\\[\\\\\\\\{}|:\\\\\\\\\"<>,.?\\\\\\\\/`~!]/g' in line:
            lines[i] = line.replace('/[0-9@#$%^&*()_+=\\\\\\\\\\\\\\\\\[\\\\\\\\{}|:\\\\\\\\\"<>,.?\\\\\\\\/`~!]/g', '/[0-9@#$%^&*()_+=\\\[\\]{}|:\\\"<>,.?\/`~!]/g')
        elif '/[0-9@#$%^&*()_+=\\\\\\\\\\\\\\\\\[\\\\\\\\{}|:\\\\\\\\\"<>,.?\\\\\\\\/`~!]/g' in line:
            lines[i] = line.replace('/[0-9@#$%^&*()_+=\\\\\\\\\\\\\\\\\[\\\\\\\\{}|:\\\\\\\\\"<>,.?\\\\\\\\/`~!]/g', '/[0-9@#$%^&*()_+=\\\[\\]{}|:\\\"<>,.?\/`~!]/g')
    
    fixed_content = '\n'.join(lines)
    
    with open('src/validators.ts', 'w') as f:
        f.write(fixed_content)
    
    print("Fixed validators.ts")

if __name__ == "__main__":
    fix_lint_issues()