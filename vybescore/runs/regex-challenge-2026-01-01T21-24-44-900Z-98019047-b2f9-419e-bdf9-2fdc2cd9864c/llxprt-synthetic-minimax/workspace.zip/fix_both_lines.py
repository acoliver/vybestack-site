#!/usr/bin/env python3
"""Fix double-escaped backslashes in regex patterns"""

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix line 80 - return statement
old_80 = "return text.replace(/http:\\\\/\\\\//g, 'https://');"
new_80 = "return text.replace(/http:\/\//g, 'https://');"

# Fix line 88 - const declaration  
old_88 = "const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;"
new_88 = "const urlPattern = /http:\/\//([^/\s]+)(.*)/g;"

content = content.replace(old_80, new_80)
content = content.replace(old_88, new_88)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed double-escaped backslashes in both lines 80 and 88")