#!/usr/bin/env python3
"""Fix double-escaped backslashes in http:// patterns"""

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the double-escaped backslashes in regex patterns
content = content.replace('/http:\\\\/\\\\//g', '/http:\/\//g')
content = content.replace('|www\\\\.)[^', '|www\\\\.)[^')  # keep other patterns intact

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed double-escaped backslashes in http:// regex patterns")