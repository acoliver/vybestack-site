#!/usr/bin/env python3
"""Fix the exact problematic regex patterns in transformations.ts"""

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the specific problematic patterns
# Replace quadruple-escaped backslashes with single-escaped
content = content.replace('/http:\\\\/\\\\//g', '/http:\/\//g')
content = content.replace('/http:\\\\/\\\\/\\([^/\\\\s]+\\)\\(.*\\)//g', '/http:\/\//([^/\s]+)(.*)/g')

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed regex patterns with proper escaping")