#!/usr/bin/env python3
"""Fix the regex escaping by understanding JavaScript regex literal syntax properly"""

# In JavaScript regex literals, forward slashes DON'T need to be escaped!
# So http:// should just be http:// without backslash escaping

content = """/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to identify sentence boundaries (.?!)
  // We need to capitalize the first letter after sentence endings while preserving spacing
  let result = '';
  let lastCharWasSentenceEnd = true; // Start by assuming we're at the beginning
  
  for (let i = 0; i < text.length; i++) {
    let char = text[i];
    const prevChar = i > 0 ? text[i - 1] : '';
    
    // Check if current position is after a sentence end
    if (i > 0 && /[.!?]/.test(prevChar)) {
      // Skip following whitespace/newlines 
      if (char === ' ' || char === '\\n' || char === '\\t') {
        lastCharWasSentenceEnd = true;
        result += char;
        continue;
      } else {
        // This character should be capitalized
        if (/[a-z]/.test(char)) {
          char = char.toUpperCase();
        }
        lastCharWasSentenceEnd = false;
        result += char;
        continue;
      }
    }
    
    // For non-sentence-boundary positions
    if (lastCharWasSentenceEnd && /[a-z]/.test(char)) {
      // Capitalize first letter at start of text or after sentence boundaries
      char = char.toUpperCase();
      lastCharWasSentenceEnd = false;
    }
    
    result += char;
  }
  
  // Fix spacing: ensure exactly one space after sentence endings
  result = result.replace(/([.!?])[ \\t\\n]*([A-Za-z])/g, '$1 $2');
  
  // Collapse multiple spaces but preserve sentence spacing
  result = result.replace(/[ \\t]{2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches common URL formats
  // Pattern: http(s)://[domain]/path or www.[domain]/path
  const urlPattern = /\\b(?:https?:\\/|www\\.)[^\\s<>\\"']+[^\\s<>\\"',.!?]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation that shouldn't be part of the URL
  return matches.map(url => {
    // Remove trailing punctuation
    let cleanedUrl = url.replace(/[.,!?;]+$/g, '');
    
    // Remove trailing quotes if they seem like formatting
    if (cleanedUrl.endsWith('"') || cleanedUrl.endsWith("'")) {
      cleanedUrl = cleanedUrl.slice(0, -1);
    }
    
    return cleanedUrl;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace only http:// with https://, leave https:// untouched
  // In JavaScript regex literals, forward slashes DON'T need to be escaped!
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  // In JavaScript regex literals, forward slashes DON'T need to be escaped!
  const urlPattern = /http:\/\//([^/\s]+)(.*)/g;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\\?|&|=|cgi-bin|\\.jsp|\\.php|\\.asp|\\.aspx|\\.do|\\.cgi|\\.pl|\\.py)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host for docs paths: example.com -> docs.example.com
      const docsHost = 'docs.' + host;
      newUrl += docsHost + path;
    } else {
      // Keep original host, just upgrade scheme
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\\d{1,2})\\/(\\d{1,2})\\/(\\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year in February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    // Leap year: divisible by 4, but not by 100 unless also divisible by 400
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  }
  
  // Check day validity for other months
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}"""

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed transformations.ts by using proper JavaScript regex literal syntax without unnecessary escaping")