#!/usr/bin/env python3
"""Fix the regex patterns by understanding TypeScript string vs regex literal escaping"""

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Fix lines by directly replacing the problematic content
for i, line in enumerate(lines):
    # Fix line 88 - the regex pattern doesn't need double backslashes in a regex literal
    if 'const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;' in line:
        lines[i] = "  const urlPattern = /http:\/\//([^/\s]+)(.*)/g;\n"
        print("Fixed line 88")
        break

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed line 88 regex pattern")