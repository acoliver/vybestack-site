#!/usr/bin/env python3
"""Fix double-escaped backslashes in http:// patterns"""

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Fix line 80 and 88 specifically
for i, line in enumerate(lines):
    if i == 79 and 'return text.replace(/http:\\\\/\\\\//g, \'https://\');' in line:
        lines[i] = lines[i].replace('/http:\\\\/\\\\//g, \'/https://\'', '/http:\/\//g, \'https://\'')  # line 80
    elif i == 87 and 'const urlPattern = /http:\\\\/\\\\/([^\\\\/\\\\s]+)(.*)/g;' in line:
        lines[i] = lines[i].replace('/http:\\\\/\\\\/([^\\\\/\\\\s]+)(.*)/g;', '/http:\/\//g;')  # line 88

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed http:// escape patterns in transformations.ts")