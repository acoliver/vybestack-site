export function capitalizeSentences(text: string): string {
  let result = '';
  let lastCharWasSentenceEnd = true;
  
  for (let i = 0; i < text.length; i++) {
    let char = text[i];
    const prevChar = i > 0 ? text[i - 1] : '';
    
    if (i > 0 && /[.!?]/.test(prevChar)) {
      if (char === ' ' || char === '\n' || char === '\t') {
        lastCharWasSentenceEnd = true;
        result += char;
        continue;
      } else {
        if (/[a-z]/.test(char)) {
          char = char.toUpperCase();
        }
        lastCharWasSentenceEnd = false;
        result += char;
        continue;
      }
    }
    
    if (lastCharWasSentenceEnd && /[a-z]/.test(char)) {
      char = char.toUpperCase();
      lastCharWasSentenceEnd = false;
    }
    
    result += char;
  }
  
  result = result.replace(/([.!?])[ \t\n]*([A-Za-z])/g, '$1 $2');
  result = result.replace(/[ \t]{2,}/g, ' ');
  
  return result;
}

export function extractUrls(text: string): string[] {
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>\"']+[^\s<>\"',.!?]/gi;
  const matches = text.match(urlPattern) || [];
  
  return matches.map(url => {
    let cleanedUrl = url.replace(/[.,!?;]+$/g, '');
    if (cleanedUrl.endsWith('"') || cleanedUrl.endsWith("'")) {
      cleanedUrl = cleanedUrl.slice(0, -1);
    }
    return cleanedUrl;
  });
}

export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  const urlPattern = /http:\/\/([^\/\s]+)(.*)/g;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    let newUrl = 'https://';
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      const docsHost = 'docs.' + host;
      newUrl += docsHost + path;
    } else {
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

export function extractYear(value: string): string {
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  }
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}