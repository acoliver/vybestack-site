/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary pattern for the prefix
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const normalizedExceptions = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(word => {
    const normalizedWord = word.toLowerCase();
    return !normalizedExceptions.includes(normalizedWord);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern: find token that appears after a digit and not at string start
  const pattern = new RegExp(`(?<!^)([0-9])(${token})`, 'gi');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Character type checks
  if (!/[A-Z]/.test(value)) {
    return false; // Missing uppercase
  }
  
  if (!/[a-z]/.test(value)) {
    return false; // Missing lowercase
  }
  
  if (!/[0-9]/.test(value)) {
    return false; // Missing digit
  }
  
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false; // Missing symbol
  }
  
  // Check for immediate repeated sequences (like "abab", "1212", "abcdabcd")
  for (let i = 0; i < value.length - 3; i++) {
    const current = value[i];
    const next = value[i + 1];
    
    // Check if the next two characters are a repeat of the current two
    if (i + 3 < value.length && 
        value[i + 2] === current && 
        value[i + 3] === next) {
      return false; // Found immediate repeated sequence
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if this looks like an IPv4 address and exclude it
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Pattern = /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/gi;
  
  // IPv6 with shorthand (::)
  const shorthandPattern = /\b(?:[a-f0-9]{1,4}:){0,7}[a-f0-9]{0,4}::(?:[a-f0-9]{1,4}:){0,7}[a-f0-9]{1,4}\b/gi;
  
  // IPv6 starting with ::
  const startShorthandPattern = /\b::(?:[a-f0-9]{1,4}:){0,7}[a-f0-9]{1,4}\b/gi;
  
  // IPv6 ending with ::
  const endShorthandPattern = /\b(?:[a-f0-9]{1,4}:){0,7}[a-f0-9]{1,4}::\b/gi;
  
  // Check for any IPv6 pattern
  if (fullIpv6Pattern.test(value) || 
      shorthandPattern.test(value) || 
      startShorthandPattern.test(value) || 
      endShorthandPattern.test(value)) {
    return true;
  }
  
  return false;
}
