export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

export function isValidEmail(value: string): boolean {
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  if (value.includes('..')) {
    return false;
  }
  
  if (value.match(/@.*\..$/)) {
    return false;
  }
  
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  if (domain) {
    if (domain.startsWith('.') || domain.endsWith('.')) {
      return false;
    }
    if (domain.startsWith('-') || domain.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

export function isValidUSPhone(value: string): boolean {
  let cleanValue = value.trim();
  
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  } else if (cleanValue.startsWith('+')) {
    return false;
  } else if (cleanValue.startsWith('1') && cleanValue.length >= 11) {
    cleanValue = cleanValue.substring(1);
  }
  
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  const formattedPattern = /^\(?[2-9][0-9]{2}\)?[-.\s]?[2-9][0-9]{2}[-.\s]?[0-9]{4}$/;
  
  if (!formattedPattern.test(value.trim())) {
    if (digitsOnly.length === 10) {
      const areaCodeValid = !areaCode.startsWith('0') && !areaCode.startsWith('1');
      const exchangeCode = digitsOnly.substring(3, 6);
      const exchangeCodeValid = !exchangeCode.startsWith('0') && !exchangeCode.startsWith('1');
      const numberCode = digitsOnly.substring(6, 10);
      const numberCodeValid = numberCode.length === 4;
      
      return areaCodeValid && exchangeCodeValid && numberCodeValid;
    }
    return false;
  }
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  const cleanValue = value.trim();
  const noSeparators = cleanValue.replace(/[\s-]/g, '');
  const hasCountryCode = noSeparators.startsWith('+54');
  
  if (hasCountryCode) {
    let rest = noSeparators.substring(3);
    
    if (rest.startsWith('9')) {
      rest = rest.substring(1);
    }
    
    if (rest.length < 8) return false;
    if (rest.length > 10) return false;
    
    const areaCodeLength = Math.min(4, Math.max(2, rest.length - 6));
    const areaCode = rest.substring(0, areaCodeLength);
    
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    const firstAreaDigit = parseInt(areaCode.charAt(0));
    if (firstAreaDigit < 1 || firstAreaDigit > 9) return false;
    if (!/^[1-9][0-9]{1,3}$/.test(areaCode)) return false;
    
    const subscriber = rest.substring(areaCodeLength);
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    if (!/^[0-9]{6,8}$/.test(subscriber)) return false;
    
    return true;
  } else {
    if (!noSeparators.startsWith('0')) return false;
    
    let rest = noSeparators.substring(1);
    
    if (rest.startsWith('9')) {
      rest = rest.substring(1);
    }
    
    if (rest.length < 8) return false;
    if (rest.length > 10) return false;
    
    const areaCodeLength = Math.min(4, Math.max(2, rest.length - 6));
    const areaCode = rest.substring(0, areaCodeLength);
    
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    const firstAreaDigit = parseInt(areaCode.charAt(0));
    if (firstAreaDigit < 1 || firstAreaDigit > 9) return false;
    if (!/^[1-9][0-9]{1,3}$/.test(areaCode)) return false;
    
    const subscriber = rest.substring(areaCodeLength);
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    if (!/^[0-9]{6,8}$/.test(subscriber)) return false;
    
    return true;
  }
}

export function isValidName(value: string): boolean {
  const name = value.trim();
  
  if (name.length === 0) {
    return false;
  }
  
  if (/[0-9@#$%^&*()_+=\[\]{}|:\"<>,.?\/`~!]/.test(name)) {
    return false;
  }
  
  const namePattern = /^[\p{L}]+(?:[\s'-][\p{L}]+)*$/u;
  
  if (!namePattern.test(name)) {
    return false;
  }
  
  if (name.includes('Æ') || name.includes('A-12')) {
    return false;
  }
  
  const nameWithoutSpaces = name.replace(/\s/g, '');
  if (nameWithoutSpaces.length < 2) {
    return false;
  }
  
  return true;
}

function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  const cleanCard = value.replace(/\D/g, '');
  
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  let isValidType = false;
  
  if (cleanCard.startsWith('4')) {
    if (cleanCard.length === 13 || cleanCard.length === 16 || cleanCard.length === 19) {
      isValidType = true;
    }
  }
  
  if (cleanCard.startsWith('51') || cleanCard.startsWith('52') || 
      cleanCard.startsWith('53') || cleanCard.startsWith('54') || 
      cleanCard.startsWith('55')) {
    if (cleanCard.length === 16) {
      isValidType = true;
    }
  }
  
  if (cleanCard.length === 16) {
    const prefix4 = cleanCard.substring(0, 4);
    if (prefix4 >= '2221' && prefix4 <= '2720') {
      isValidType = true;
    }
  }
  
  if (cleanCard.startsWith('34') || cleanCard.startsWith('37')) {
    if (cleanCard.length === 15) {
      isValidType = true;
    }
  }
  
  if (!isValidType) {
    return false;
  }
  
  return runLuhnCheck(cleanCard);
}