export function test() {
  const pattern = /http:\/\//g;
  return pattern;
}