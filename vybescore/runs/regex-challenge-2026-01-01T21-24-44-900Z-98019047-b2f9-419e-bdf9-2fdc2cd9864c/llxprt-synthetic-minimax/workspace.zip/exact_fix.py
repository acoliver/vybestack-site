#!/usr/bin/env python3
"""Fix the regex patterns by replacing the exact problematic content"""

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Fix by replacing the exact patterns with the correct ones
for i, line in enumerate(lines):
    # Fix line 88
    if 'const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;' in line:
        lines[i] = "  const urlPattern = /http:\/\//([^/\s]+)(.*)/g;\n"
    # Fix line 80  
    elif 'return text.replace(/http:\\\\/\\\\//g, \'https://\');' in line:
        lines[i] = "  return text.replace(/http:\/\//g, 'https://');\n"

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed regex patterns with correct escaping")