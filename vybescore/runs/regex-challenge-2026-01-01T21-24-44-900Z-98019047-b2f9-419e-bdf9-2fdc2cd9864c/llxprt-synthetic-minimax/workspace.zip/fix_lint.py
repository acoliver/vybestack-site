#!/usr/bin/env python3
"""
Fix lint issues by removing unnecessary escape characters
"""

def fix_file():
    # Read current content
    with open('src/transformations.ts', 'r') as f:
        content = f.read()
    
    # Fix the excessive backslashes in the patterns
    content = content.replace('/http:\\\\/\\\\/g', '/http:\/\//g')
    
    # Write fixed content
    with open('src/transformations.ts', 'w') as f:
        f.write(content)
    
    print("Fixed transformations.ts")

if __name__ == "__main__":
    fix_file()