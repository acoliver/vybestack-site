#!/usr/bin/env python3
"""Fix the regex patterns in transformations.ts by replacing double backslashes with single backslashes"""

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Process each line and fix double-escaped backslashes in regex patterns
fixed_lines = []
for line in lines:
    # Fix the problematic regex patterns where \\/ becomes \/
    # Pattern 1: http:\\\\/\\\\/ 
    # Pattern 2: \\s or \\s should become \s
    # Pattern 3: \\? should become \?
    # Pattern 4: \\. should become \.
    # Pattern 5: \\& should become \&
    # Pattern 6: \\= should become \=
    
    line = line.replace('http:\\\\/\\\\/', 'http:\/\/')
    line = line.replace('\\s', r'\s')
    line = line.replace('\\?', r'\?')
    line = line.replace('\\.', r'\.')
    line = line.replace('\\&', r'\&')
    line = line.replace('\\=', r'\=')
    line = line.replace('\\|', r'\|')
    
    fixed_lines.append(line)

with open('src/transformations.ts', 'w') as f:
    f.writelines(fixed_lines)

print("Fixed all double-escaped backslash patterns in transformations.ts")