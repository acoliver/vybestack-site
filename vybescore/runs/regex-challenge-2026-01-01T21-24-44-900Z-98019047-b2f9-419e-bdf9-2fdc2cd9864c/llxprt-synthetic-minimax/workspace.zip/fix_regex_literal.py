#!/usr/bin/env python3
"""Fix the regex pattern by understanding that forward slashes don't need escaping in regex literals"""

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Find the problematic line and fix it
for i, line in enumerate(lines):
    if 'const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;' in line:
        # In JavaScript regex literals, forward slashes don't need escaping
        lines[i] = 'const urlPattern = /http:\/\//([^/\s]+)(.*)/g;\n'
        print(f"Fixed line {i+1}")
        break

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed regex pattern by removing unnecessary escaping")