#!/usr/bin/env python3
"""Fix the regex pattern by understanding proper regex literal syntax"""

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Find the problematic line and fix it - forward slashes don't need escaping in regex literals
for i, line in enumerate(lines):
    if 'const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;' in line:
        # In regex literals, forward slashes don't need to be escaped - remove \\/\/
        lines[i] = 'const urlPattern = /http:\/\//([^/\s]+)(.*)/g;\n'
        print(f"Fixed line {i+1}")
        break

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed regex pattern by using proper JavaScript regex literal syntax")