#!/usr/bin/env python3
"""Fix the exact regex escaping issue by writing the correct pattern"""

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the specific regex patterns that are causing parsing errors
# The issue is double-escaped backslashes in regex literals
# In JavaScript regex literals, forward slashes should be \/ not \\/

# Fix the specific patterns:
content = content.replace('const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;', 'const urlPattern = /http:\/\//([^/\s]+)(.*)/g;')

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed the regex escaping issue by using correct single backslashes")