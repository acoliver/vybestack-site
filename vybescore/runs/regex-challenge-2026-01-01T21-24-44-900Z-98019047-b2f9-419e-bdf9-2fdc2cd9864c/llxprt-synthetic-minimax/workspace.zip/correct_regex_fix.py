#!/usr/bin/env python3
"""Fix the regex escaping patterns by understanding JavaScript regex literal syntax"""

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the specific problematic patterns that ESLint is complaining about
# In JavaScript regex literals, forward slashes don't need double backslash escaping
# Pattern 1: http:\\\\/\\\\/ should become http:\/\/
# Pattern 2: \\s should become \s  
# Pattern 3: \\? should become \?
# Pattern 4: \\. should become \.
# Pattern 5: \\& should become \&
# Pattern 6: \\= should become \=

# First, let's specifically fix the two lines that are causing parsing errors:
content = content.replace('const urlPattern = /http:\\\\/\\\\//([^/\\\\s]+)(.*)/g;', 'const urlPattern = /http:\/\//([^/\s]+)(.*)/g;')
content = content.replace('return text.replace(/http:\\\\/\\\\//g, \'https://\');', 'return text.replace(/http:\/\//g, \'https://\');')

# Now fix any other double-escaped patterns
content = content.replace('\\s', r'\s')
content = content.replace('\\?', r'\?')
content = content.replace('\\.', r'\.')
content = content.replace('\\&', r'\&')
content = content.replace('\\=', r'\=')

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed regex escaping patterns to use single backslashes where appropriate")