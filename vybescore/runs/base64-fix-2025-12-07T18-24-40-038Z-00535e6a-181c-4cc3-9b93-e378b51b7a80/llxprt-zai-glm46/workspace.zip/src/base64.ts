const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if a string is valid Base64 format.
 */
function isValidBase64(input: string): boolean {
  if (input.length % 4 !== 0) {
    return false;
  }
  return BASE64_REGEX.test(input);
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmed = input.trim();
  
  // Add padding if missing (required for Node.js Buffer)
  const padded = trimmed.padEnd(Math.ceil(trimmed.length / 4) * 4, '=');
  
  // Validate the input format
  if (!isValidBase64(padded)) {
    throw new Error('Invalid Base64 input: contains invalid characters or incorrect format');
  }

  try {
    const result = Buffer.from(padded, 'base64').toString('utf8');
    
    // Verify that the result can be properly re-encoded to match the input
    // This catches cases like padding-only inputs that decode to empty strings
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    const normalizedInput = trimmed.replace(/=+$/, '');
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: failed validation');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
