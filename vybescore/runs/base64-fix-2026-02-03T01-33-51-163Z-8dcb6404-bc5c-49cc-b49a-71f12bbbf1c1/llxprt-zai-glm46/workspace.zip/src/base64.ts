/**
 * Regular expression to match valid Base64 strings.
 * - Standard Base64 alphabet: A-Z, a-z, 0-9, +, /
 * - Optional padding: 0-2 '=' characters at the end
 * - Whitespace is not allowed in strict Base64
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Check if a string is valid Base64.
 * Validates:
 * - Only contains Base64 alphabet characters
 * - Has correct padding (0, 1, or 2 '=' characters at the end)
 * - Accepts both padded and unpadded Base64 (padding is optional per spec)
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (input.length === 0) {
    return false;
  }

  // Must match Base64 alphabet pattern
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }

  // Check padding correctness
  const paddingLength = input.endsWith('=') ? input.match(/=+$/)?.[0].length || 0 : 0;
  const unpaddedLength = input.length - paddingLength;

  // Padding can only be 0, 1, or 2 characters
  // If there's padding, we need at least 2 unpadded characters
  // If padding is present, total length must be multiple of 4
  return (
    paddingLength <= 2 &&
    !(paddingLength > 0 && unpaddedLength < 2) &&
    (paddingLength === 0 || input.length % 4 === 0)
  );
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * 
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 * 
 * @throws {Error} When the input is not valid Base64
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding actually worked (Node's Buffer.from may return empty buffer for invalid input)
    if (trimmed.length > 0 && buffer.length === 0 && !trimmed.match(/^A{0,2}=?=?$/)) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
