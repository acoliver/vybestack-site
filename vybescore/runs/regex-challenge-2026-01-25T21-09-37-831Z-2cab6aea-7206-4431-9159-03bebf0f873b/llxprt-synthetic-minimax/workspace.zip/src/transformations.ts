/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences using punctuation followed by space or end of string
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  // Capitalize first letter of each sentence
  const capitalized = sentences.map(sentence => {
    // Trim to handle spacing properly
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return sentence;
    
    // Capitalize first letter
    const firstChar = trimmed.charAt(0).toUpperCase();
    const rest = trimmed.slice(1);
    
    // Handle abbreviations by checking if previous char was lowercase
    // This is a simple approach - we'll capitalize most first letters
    return firstChar + rest;
  });
  
  // Join sentences back with single space
  return capitalized.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to find URLs with http/https protocols
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from URLs
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,;:!?)]*$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Regex to match URLs starting with http://example.com
  const urlRegex = /http:\/\/example\.com[^\s<>"']+/gi;
  
  return text.replace(urlRegex, (match) => {
    // Parse the URL components
    const urlParts = match.match(/http:\/\/example\.com([^?]*)(.*)/);
    
    if (!urlParts) {
      // If it doesn't match our pattern, just upgrade scheme
      return match.replace(/http:\/\//, 'https://');
    }
    
    const path = urlParts[1] || '';
    const query = urlParts[2] || '';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|[?&]|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(query) ||
                           /cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Transform to docs.example.com but keep the full path
      return `https://docs.example.com${path}${query}`;
    } else {
      // Just upgrade the scheme
      return match.replace(/http:\/\//, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic day validation (doesn't handle leap years perfectly but sufficient for this task)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
