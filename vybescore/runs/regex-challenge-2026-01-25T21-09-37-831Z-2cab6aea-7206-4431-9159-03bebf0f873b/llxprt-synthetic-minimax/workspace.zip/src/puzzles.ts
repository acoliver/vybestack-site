/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex that matches words starting with the prefix
  // Word boundaries to match whole words only
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordBoundary = '\\b';
  const prefixRegex = new RegExp(wordBoundary + escapedPrefix + '[\\w-]*', 'gi');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const filteredMatches = matches.filter(match => {
    return !exceptionSet.has(match.toLowerCase());
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find matches where digit is immediately followed by token
  // This captures the digit + token combination, not just the token
  const regex = new RegExp(`\\d${escapedToken}`, 'gi');
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length requirement (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace (should not contain)
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab" should fail)
  // Look for any 2-character sequence that repeats immediately
  const hasRepeatedSequence = /([A-Za-z0-9]{2})\1/.test(value);
  
  if (hasRepeatedSequence) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if there are any IPv4 addresses in the string
  // IPv4 pattern: 4 numbers separated by dots, each 0-255
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // More comprehensive IPv6 regex that handles various formats
  // This includes compressed notation and edge cases
  const ipv6Regex = new RegExp(
    // Full notation with 8 groups
    '(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})' + '|' +
    // Compressed notation with ::
    '(?:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?(?:::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?' + '|' +
    // Mixed compressed forms
    '(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4})*',
    'gi'
  );
  
  // Check for IPv6 first
  if (ipv6Regex.test(value)) {
    // But make sure it's not just an IPv4 address
    // If we find IPv4, it's not IPv6
    if (ipv4Regex.test(value)) {
      return false;
    }
    return true;
  }
  
  return false;
}
