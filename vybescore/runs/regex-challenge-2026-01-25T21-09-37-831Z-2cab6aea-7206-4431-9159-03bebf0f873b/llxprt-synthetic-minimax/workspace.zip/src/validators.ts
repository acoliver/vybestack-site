export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure: local@domain.tld
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for problematic patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@.')) {
    return false;
  }
  
  const [local, domain] = value.split('@');
  
  // Check domain doesn't have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Check local part doesn't have consecutive dots
  if (local.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters to normalize the number
  const digitsOnly = value.replace(/\D/g, '');
  
  // Too short if less than 10 digits
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Remove country code if present (assume +1)
  let tenDigitNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    tenDigitNumber = digitsOnly.slice(1);
  }
  
  // Must be exactly 10 digits after country code removal
  if (tenDigitNumber.length !== 10) {
    return false;
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = tenDigitNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if extensions are allowed and present
  if (!options?.allowExtensions && digitsOnly.length > 10) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters to normalize
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Check for country code +54 at the beginning
  let remainingDigits = digitsOnly;
  let hasCountryCode = false;
  
  if (remainingDigits.startsWith('54')) {
    hasCountryCode = true;
    remainingDigits = remainingDigits.slice(2);
    
    // Check for mobile indicator 9
    if (remainingDigits.startsWith('9')) {
      remainingDigits = remainingDigits.slice(1);
    }
  }
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode) {
    if (!remainingDigits.startsWith('0')) {
      return false;
    }
    remainingDigits = remainingDigits.slice(1);
  }
  
  // Area code must be 2-4 digits, first digit 1-9
  if (remainingDigits.length < 2) {
    return false;
  }
  
  const areaCodeLength = remainingDigits.length >= 8 ? 4 : remainingDigits.length >= 7 ? 3 : 2;
  const areaCode = remainingDigits.slice(0, areaCodeLength);
  
  // Area code first digit must be 1-9
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Remaining digits are the subscriber number
  const subscriberDigits = remainingDigits.slice(areaCodeLength);
  
  // Total subscriber number must be 6-8 digits
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if string contains digits or invalid symbols
  const hasInvalidChars = /[0-9@#$%^&*()_+=[\]{}|\\:";'<>?,./`~]/.test(value);
  
  // Reject obviously invalid names like "X Æ A-12" style
  if (hasInvalidChars) {
    return false;
  }
  
  // Must contain at least some valid name characters
  // Allow unicode letters, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least 2 characters and not be just spaces/symbols
  const trimmed = value.trim();
  if (trimmed.length < 2) {
    return false;
  }
  
  // Reject names that are just repeated symbols or single characters
  if (trimmed.match(/^[\s'-]+$/)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid card types and lengths
  let isValidType = false;
  let expectedLength = 0;
  
  // Visa: starts with 4, length 13, 16, 19
  if (digitsOnly.startsWith('4')) {
    if (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19) {
      isValidType = true;
      expectedLength = digitsOnly.length;
    }
  }
  // Mastercard: starts with 5 or 2, length 16
  else if (digitsOnly.startsWith('5') || digitsOnly.startsWith('2')) {
    if (digitsOnly.length === 16) {
      isValidType = true;
      expectedLength = 16;
    }
  }
  // AmEx: starts with 3, length 15
  else if (digitsOnly.startsWith('3')) {
    if (digitsOnly.length === 15) {
      isValidType = true;
      expectedLength = 15;
    }
  }
  
  if (!isValidType || digitsOnly.length !== expectedLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
