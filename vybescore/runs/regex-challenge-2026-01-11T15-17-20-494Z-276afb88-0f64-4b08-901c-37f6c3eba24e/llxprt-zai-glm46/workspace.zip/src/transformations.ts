/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first character after .?!
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces to one
  let normalized = text.replace(/\s+/g, ' ');

  // Trim leading/trailing whitespace
  normalized = normalized.trim();

  // Capitalize the very first character
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);

  // Now handle sentence boundaries
  // We use a regex to find sentence endings followed by lowercase letters
  // But we need to skip common abbreviations

  // Split into sentences using ., ?, or ! as delimiters
  // Lookbehind for abbreviations to avoid splitting on them
  const sentences: string[] = [];
  let current = '';
  let i = 0;
  
  while (i < normalized.length) {
    if (normalized[i] === '.' || normalized[i] === '?' || normalized[i] === '!') {
      current += normalized[i];
      i++;
      
      // Skip whitespace after the sentence end
      while (i < normalized.length && normalized[i] === ' ') {
        i++;
      }
      
      sentences.push(current);
      current = '';
    } else {
      current += normalized[i];
      i++;
    }
  }
  
  if (current) {
    sentences.push(current);
  }
  
  // Now capitalize the first letter of each sentence (except the first one which we already did)
  for (let j = 1; j < sentences.length; j++) {
    if (sentences[j].length > 0) {
      const firstChar = sentences[j].charAt(0);
      const rest = sentences[j].slice(1);
      sentences[j] = firstChar.toUpperCase() + rest;
    }
  }
  
  // Join with single spaces
  let result = sentences.join(' ');
  
  // Additional pass: capitalize after sentence-ending punctuation that didn't get caught
  // This handles cases like "hello.how are you" -> "Hello. How are you"
  result = result.replace(/([.!?]\s*)([a-z])/g, (_match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  // Handle the specific case where there's no space after punctuation
  result = result.replace(/([.!?])([a-z])/g, (_match, p1, p2) => {
    return p1 + ' ' + p2.toUpperCase();
  });
  
  return result;
}

/**
 * Extract all URLs from the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching:
  // - Protocol: http://, https://, www. (implicit)
  // - Domain: alphanumeric with hyphens and dots
  // - Optional port
  // - Path, query string, fragment

  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9][a-zA-Z0-9-]*)+(?::\d+)?(?:\/[^\s[\]"'<>?,!?]*)?/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  const cleanedUrls = matches.map(url => {
    return url.replace(/[.,;:!?)\]>]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - But still upgrade scheme in all cases
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  // We need to handle both http and https
  const urlPattern = /(https?):\/\/example\.com(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (_match, protocol, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // If there's no path or path doesn't start with /docs/, just upgrade protocol
    if (!path || !path.startsWith('/docs/')) {
      return `${newProtocol}://example.com${path}`;
    }
    
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = [
      '/cgi-bin',
      '?',
      '&',
      '=',
      '.jsp',
      '.php',
      '.asp',
      '.aspx',
      '.do',
      '.cgi',
      '.pl',
      '.py'
    ];
    
    const lowerPath = path.toLowerCase();
    const shouldSkipHostRewrite = dynamicHints.some(hint => lowerPath.includes(hint));
    
    if (shouldSkipHostRewrite) {
      return `${newProtocol}://example.com${path}`;
    }
    
    // Rewrite to docs.example.com for /docs/ paths
    return `${newProtocol}://docs.example.com${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    isLeapYear(parseInt(year, 10)) ? 29 : 28, // February
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to check if a year is a leap year.
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}
