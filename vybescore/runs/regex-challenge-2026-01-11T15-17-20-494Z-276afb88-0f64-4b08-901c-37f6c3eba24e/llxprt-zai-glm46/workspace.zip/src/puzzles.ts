/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create a set of exceptions for fast lookup
  const exceptionSet = new Set(exceptions);

  // Match whole words that start with the prefix
  // Word boundary \b ensures we match complete words
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w*)\\b`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions and return unique results
  return [...new Set(matches.filter(word => !exceptionSet.has(word.toLowerCase())))];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match the token only when preceded by a digit
  // We need to include the digit in the match
  // (?<!^) ensures we're not at the start of the string
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // This pattern captures any 2-4 character sequence and checks if it's immediately repeated
  for (const len of [2, 3, 4]) {
    const repeatPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatPattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that handles:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand with :: (zero compression): 2001:db8::1
  // - Mixed IPv4 notation (last two parts as IPv4): ::ffff:192.0.2.1
  // - Loopback: ::1
  // - Leading zeros can be omitted

  // First, define a pattern that matches IPv6 addresses
  // This uses negative lookahead to avoid matching IPv4 addresses that aren't part of IPv6

  // An IPv6 address consists of 8 groups of 1-4 hex digits separated by colons
  // The :: can replace one or more consecutive groups of zeros
  const ipv6Pattern = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(:0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}\d){0,1}\d)\.){3}(?:25[0-5]|(?:2[0-4]|1{0,1}\d){0,1}\d)|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}\d){0,1}\d)\.){3}(?:25[0-5]|(?:2[0-4]|1{0,1}\d){0,1}\d))(?=$|\s|[^\d:a-fA-F])/;

  return ipv6Pattern.test(value);
}
