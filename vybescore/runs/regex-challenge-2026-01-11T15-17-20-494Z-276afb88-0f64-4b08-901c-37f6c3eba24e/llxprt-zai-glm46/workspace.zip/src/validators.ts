export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects: double dots, trailing dots, domain underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Local part checks
  if (!localPart || localPart.length > 64) {
    return false;
  }
  
  // No consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // No trailing or leading dot in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain checks
  if (!domain || domain.length > 255) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // No consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // No trailing or leading dot in domain
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  // Check TLD is at least 2 chars and valid
  const tld = domain.split('.').pop() || '';
  if (tld.length < 2 || !/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.length === 11 && phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.slice(1);
  } else if (phoneNumber.length > 11) {
    return false;
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9
 * - Area code: 2-4 digits (leading 1-9)
 * - Subscriber: 6-8 digits
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  // Group 1: Optional +54 country code
  // Group 2: Optional 0 trunk prefix (required if no country code)
  // Group 3: Optional 9 mobile indicator
  // Group 4: Area code (2-4 digits, starting with 1-9)
  // Group 5: Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Alternative: When no country code, trunk prefix is required
  const withTrunkRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  const withCountryRegex = /^\+54(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Also handle optional mobile indicator 9
  const withMobileIndicator = /^(?:\+54)?(?:0)?9([1-9]\d{1,3})(\d{6,8})$/;
  const withMobileNoCountry = /^09([1-9]\d{1,3})(\d{6,8})$/;
  
  // Match against patterns
  let match: RegExpMatchArray | null = null;
  
  if (withMobileNoCountry.test(cleaned)) {
    match = cleaned.match(withMobileNoCountry);
  } else if (withMobileIndicator.test(cleaned)) {
    match = cleaned.match(withMobileIndicator);
  } else if (withTrunkRegex.test(cleaned)) {
    match = cleaned.match(withTrunkRegex);
  } else if (withCountryRegex.test(cleaned)) {
    match = cleaned.match(withCountryRegex);
  } else {
    // Try the general regex (for +54 without mobile indicator)
    const generalMatch = cleaned.match(argentinePhoneRegex);
    if (generalMatch) {
      // Need to verify if country code was present
      if (cleaned.startsWith('+54')) {
        match = generalMatch;
      } else if (cleaned.startsWith('0')) {
        match = cleaned.match(withTrunkRegex);
      }
    }
  }
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code validation: 2-4 digits, starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Must not start or end with space, apostrophe, or hyphen
  // No consecutive spaces
  // No digits or other symbols
  
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Allow letters (unicode), spaces, apostrophes, hyphens
  // Must contain at least one letter
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // No leading/trailing spaces
  if (value !== value.trim()) {
    return false;
  }
  
  // No consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // No leading/trailing apostrophes or hyphens
  if (/^['-]|['-]$/.test(value)) {
    return false;
  }

  // No consecutive apostrophes or hyphens
  if (/'{2,}/.test(value) || /-{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa (13, 16 digits starting with 4), Mastercard (16 digits starting with 51-55 or 2221-2720), AmEx (15 digits starting with 34 or 37)
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length based on card type
  const length = cleaned.length;
  const prefix = cleaned.substring(0, 2);
  const firstDigit = cleaned[0];

  // Visa: 13 or 16 digits, starts with 4
  const isVisa = (length === 13 || length === 16) && firstDigit === '4';
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const isOldMastercard = length === 16 && /^5[1-5]/.test(cleaned);
  const isNewMastercard = length === 16 && /^2[2-7][0-2][0-9]/.test(cleaned);
  const isMastercard = isOldMastercard || isNewMastercard;
  
  // AmEx: 15 digits, starts with 34 or 37
  const isAmEx = length === 15 && (prefix === '34' || prefix === '37');
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
