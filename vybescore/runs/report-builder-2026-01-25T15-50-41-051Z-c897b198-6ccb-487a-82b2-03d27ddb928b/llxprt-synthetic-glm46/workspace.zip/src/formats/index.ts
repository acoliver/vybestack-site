import { FormatMap } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatMap: FormatMap = {
  markdown: renderMarkdown,
  text: renderText,
};

export type SupportedFormat = keyof typeof formatMap;