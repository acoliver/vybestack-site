import { ReportData, RenderOptions } from '../types.js';

export const renderText = (data: ReportData, options: RenderOptions): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;
  
  const formatAmount = (amount: number): string => `$${amount.toFixed(2)}`;
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let result = `${title}\n`;
  result += `${summary}\n`;
  result += `Entries:\n`;
  
  for (const entry of entries) {
    result += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    result += `Total: ${formatAmount(total)}\n`;
  }
  
  return result;
};