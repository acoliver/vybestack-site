#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { formatMap, SupportedFormat } from '../formats/index.js';
import { ReportData } from '../types.js';

interface CliOptions {
  format: SupportedFormat;
  output?: string;
  includeTotals: boolean;
  inputFile: string;
}

function parseArguments(): CliOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: Partial<CliOptions> = {
    includeTotals: false,
    format: 'markdown',
  };
  
  result.inputFile = args[0];
  
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      const format = args[i + 1] as SupportedFormat;
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
        process.exit(1);
      }
      result.format = format;
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      result.output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      result.includeTotals = true;
    }
  }
  
  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return result as CliOptions;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const options = parseArguments();
    
    const fileContent = readFileSync(options.inputFile, 'utf8');
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Error parsing JSON file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    
    const reportData = validateReportData(data);
    const renderFunction = formatMap[options.format];
    const output = renderFunction(reportData, { includeTotals: options.includeTotals });
    
    if (options.output) {
      writeFileSync(options.output, output);
      process.stdout.write(`Report written to ${options.output}\n`);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
