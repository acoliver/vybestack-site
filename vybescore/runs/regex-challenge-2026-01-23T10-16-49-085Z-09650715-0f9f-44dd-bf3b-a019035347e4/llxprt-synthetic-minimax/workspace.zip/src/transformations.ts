/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First capitalize the very first character if it's a letter
  let result = text;
  
  // Capitalize first character if it's a lowercase letter
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Pattern to find sentence boundaries: .?! followed by any amount of whitespace
  // Then capture the first letter of the next sentence
  const sentencePattern = /([.!?])(\s*)([a-z])/g;
  
  return result.replace(sentencePattern, (match, punctuation, whitespace, letter) => {
    // Keep the punctuation, one space, and capitalize the letter
    return punctuation + ' ' + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs - http(s):// followed by domain/path
  // Non-greedy match to stop at punctuation/space
  const urlPattern = /\bhttps?:\/\/[^\s<>"'()]*[^\s<>"'(),.!?]/g;
  
  const matches = text.match(urlPattern);
  if (!matches) return [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation like .,!? from the end
    return url.replace(/[.,!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs and capture host/domain and path
  const urlPattern = /http:\/\/([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, domain, path = '') => {
    // Default to upgrading scheme
    let result = 'https://' + domain;
    
    // Add path if it exists
    if (path) {
      result += path;
    }
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|=|&)|(\.(jsp|php|asp|aspx|do|cgi|pl|py)$)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.domain
        result = 'https://docs.' + domain + path;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format with validation
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (01-12)
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  
  // Validate day based on month (simple validation)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[monthNum - 1];
  
  if (dayNum < 1 || dayNum > maxDay) return 'N/A';
  
  // Validate year format (4 digits assumed valid)
  if (year.length !== 4) return 'N/A';
  
  return year;
}
