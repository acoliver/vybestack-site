export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern allows typical email formats with proper validation
  // - Username: letters, numbers, dots, underscores, hyphens, plus
  // - Required @ symbol
  // - Domain: letters, numbers, dots, hyphens (no underscores)
  // - TLD: letters, 2+ chars
  // - Rejects double dots, trailing dots, domain underscores
  const emailPattern = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])*(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])*)+$/;
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* eslint-disable-line */ _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 or 1 prefix
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits for valid US numbers
  if (phoneNumber.length !== 10) return false;
  
  // Validate area code (first digit 2-9, remaining 0-9)
  const areaCode = phoneNumber.substring(0, 3);
  if (!/^[2-9][0-9]{2}$/.test(areaCode)) return false;
  
  // Validate exchange code (first digit 2-9)
  const exchangeCode = phoneNumber.substring(3, 6);
  if (!/^[2-9][0-9]{2}$/.test(exchangeCode)) return false;
  
  // Validate subscriber number (4 digits)
  const subscriberNumber = phoneNumber.substring(6);
  if (!/^[0-9]{4}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all punctuation and spaces for validation
  const cleaned = value.replace(/[\s-()]/g, '');
  
  // Pattern to match Argentine phone numbers
  // Group 1: Optional +54 country code
  // Group 2: Optional trunk 0 (when no country code)
  // Group 3: Optional mobile indicator 9
  // Group 4: Area code (2-4 digits, first 1-9)
  // Group 5: Subscriber number (remaining digits, total 6-8 digits)
  const argentinePattern = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{4,6})$/;
  
  const match = cleaned.match(argentinePattern);
  if (!match) return false;
  
  const [, countryCode, trunk, mobileIndicator, areaCode, subscriber] = match;
  
  // Validate total structure
  if (countryCode) {
    // With country code, mobile indicator 9 should be present for mobile
    const totalDigits = (countryCode + mobileIndicator + areaCode + subscriber).replace(/[^\d]/g, '');
    return totalDigits.length >= 8 && totalDigits.length <= 12;
  } else {
    // Without country code, trunk 0 should be present
    if (!trunk) return false;
    const totalDigits = (trunk + areaCode + subscriber).replace(/[^\d]/g, '');
    return totalDigits.length >= 7 && totalDigits.length <= 10;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern allows Unicode letters, spaces, apostrophes, and hyphens
  // Rejects digits and symbols (including X Æ A-12 style symbols)
  // Start with letter, end with letter or allowed punctuation
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  // Additional check to reject empty or whitespace-only names
  if (!value.trim()) return false;
  
  // Check for digits - reject if any found
  if (/\d/.test(value)) return false;
  
  // Check for problematic symbols (like X Æ A-12 style)
  // Only allow letters, spaces, apostrophes, and hyphens
  return namePattern.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Helper function to calculate Luhn checksum for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length - valid cards are typically 13-19 digits
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check prefixes for major card types
  let isValidPrefix = false;
  
  // Visa: starts with 4, length 13, 16, 19, or 23 digits
  if (/^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16 || 
      cleaned.length === 19 || cleaned.length === 23)) {
    isValidPrefix = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((/^5[1-5]/.test(cleaned) || /^2[2-7]\d{2}/.test(cleaned)) && 
      cleaned.length === 16) {
    isValidPrefix = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((/^34/.test(cleaned) || /^37/.test(cleaned)) && 
      cleaned.length === 15) {
    isValidPrefix = true;
  }
  
  // Must have valid prefix
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}
