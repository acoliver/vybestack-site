/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern for matching words starting with prefix
  // Use word boundary to match whole words only
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(word => {
    const cleanWord = word.toLowerCase();
    return !exceptionsLower.includes(cleanWord);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that appears after a digit and not at string start
  // We need to capture the digit followed by the token
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'gi');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10+ characters)
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (e.g., "abab")
  // Pattern looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it looks like an IPv4 address - if so, reject
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /^\d{1,3}(\.\d{1,3}){3}$/;
  if (ipv4Pattern.test(value)) {
    // Additional check that each group is 0-255
    const groups = value.split('.');
    if (groups.every(group => {
      const num = parseInt(group, 10);
      return num >= 0 && num <= 255;
    })) {
      return false; // It's a valid IPv4, not IPv6
    }
  }
  
  // IPv6 patterns to match (should be more permissive than current strict patterns)
  // Look for patterns that contain colons and hex digits (typical IPv6 indicators)
  const ipv6Patterns = [
    // Pattern that matches IPv6 with colons and hex digits
    /[0-9a-fA-F]*:[0-9a-fA-F]*:[0-9a-fA-F]*/,
    // Shorthand :: patterns
    /::/
  ];
  
  // If the value contains IPv6-like patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
