import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;

// Validation functions
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^@?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return { 
      field: 'phone', 
      message: 'Phone number can contain digits, spaces, parentheses, dashes, and a leading @' 
    };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  const postalRegex = /^[\w\s-]+$/;
  if (!postalRegex.test(postalCode)) {
    return { 
      field: 'postalCode', 
      message: 'Postal code can contain letters, digits, spaces, and dashes' 
    };
  }
  return null;
}

function validateSubmission(data: SubmissionData): ValidationError[] {
  const errors: ValidationError[] = [];

  const requiredError = validateRequired(data.firstName, 'First name');
  if (requiredError) errors.push(requiredError);

  const lastNameError = validateRequired(data.lastName, 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const streetError = validateRequired(data.streetAddress, 'Street address');
  if (streetError) errors.push(streetError);

  const cityError = validateRequired(data.city, 'City');
  if (cityError) errors.push(cityError);

  const stateError = validateRequired(data.stateProvince, 'State / Province / Region');
  if (stateError) errors.push(stateError);

  const postalError = validateRequired(data.postalCode, 'Postal / Zip code');
  if (postalError) errors.push(postalError);

  const countryError = validateRequired(data.country, 'Country');
  if (countryError) errors.push(countryError);

  const emailRequiredError = validateRequired(data.email, 'Email');
  if (emailRequiredError) {
    errors.push(emailRequiredError);
  } else {
    const emailError = validateEmail(data.email);
    if (emailError) errors.push(emailError);
  }

  const phoneRequiredError = validateRequired(data.phone, 'Phone number');
  if (phoneRequiredError) {
    errors.push(phoneRequiredError);
  } else {
    const phoneError = validatePhone(data.phone);
    if (phoneError) errors.push(phoneError);
  }

  if (data.postalCode && data.postalCode.trim()) {
    const postalCodeError = validatePostalCode(data.postalCode);
    if (postalCodeError) errors.push(postalCodeError);
  }

  return errors;
}

// Initialize database
async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  let dbInstance: Database;
  
  try {
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      dbInstance = new SQL.Database(buffer);
    } else {
      dbInstance = new SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      dbInstance.run(schema);
      
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      saveDatabase(dbInstance);
    }
  } catch (error) {
    console.error('Database initialization error:', error);
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }
  
  return dbInstance;
}

// Save database to disk
function saveDatabase(database: Database): void {
  try {
    const data = database.export();
    const buffer = Buffer.from(data);
    const dataDir = path.dirname(DB_PATH);
    
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(DB_PATH, buffer);
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Insert submission into database
function insertSubmission(database: Database, data: SubmissionData): void {
  const stmt = database.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone
  ]);
  
  stmt.free();
  saveDatabase(database);
}

// Create Express app
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const data: SubmissionData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateSubmission(data);
  
  if (errors.length > 0) {
    const errorMessages = errors.map(e => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: data
    });
    return;
  }
  
  // Insert into database
  if (db) {
    insertSubmission(db, data);
  }
  
  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(data.firstName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Set up EJS
app.set('view engine', 'ejs');
app.set("views", path.join(__dirname, "..", "src", "templates"));

// Start server
async function startServer(): Promise<void> {
  try {
    db = await initDatabase();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
  
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down server...');
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server closed');
      process.exit(0);
    });
    
    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, startServer };
