declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): unknown[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }
  export default function initSqlJs(config?: Record<string, unknown>): Promise<SqlJsStatic>;
}