import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  await startServer();
});

describe('friendly form (public smoke)', () => {
  it('renders form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    const response = await request(app).post('/submit').type('form').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SWA 1AA',
      country: 'United Kingdom',
      email: 'john@example.com',
      phone: '@44 20 7946 0958'
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles validation errors correctly', async () => {
    const response = await request(app).post('/submit').type('form').send({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: 'invalid-phone'
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('required');
    expect(response.text).toContain('valid email');
  });

  it('displays thank you page', async () => {
    const response = await request(app).get('/thank-you?firstName=John');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('John');
  });
});
