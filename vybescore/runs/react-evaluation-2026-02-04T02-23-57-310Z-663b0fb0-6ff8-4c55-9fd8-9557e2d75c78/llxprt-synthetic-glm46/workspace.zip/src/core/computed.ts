/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize computed value if not already set
  // NOTE: We don't initialize here because that would run the function outside of reactive context
  // The value will be computed on first access
  
  // Return the getter function that computes on demand
  return (): T => {
    // Re-compute to ensure all dependencies are tracked and values are current
    updateObserver(o)
    return o.value!
  }
}
