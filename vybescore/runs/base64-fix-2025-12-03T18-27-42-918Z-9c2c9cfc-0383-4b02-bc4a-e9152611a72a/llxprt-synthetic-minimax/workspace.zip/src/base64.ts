/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 * Returns properly padded Base64 string that is compatible with standard Base64 consumers.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding, and rejects invalid input.
 */
export function decode(input: string): string {
  // Validate Base64 input
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }
  
  // Validate padding is only at the end
  if (input.includes('=')) {
    const paddingStart = input.indexOf('=');
    if (paddingStart !== input.length - 1 && paddingStart !== input.length - 2) {
      throw new Error('Invalid Base64 input: padding must only appear at the end');
    }
    
    // Ensure no other characters after padding
    const afterPadding = input.slice(paddingStart);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: padding must only contain = characters');
    }
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}