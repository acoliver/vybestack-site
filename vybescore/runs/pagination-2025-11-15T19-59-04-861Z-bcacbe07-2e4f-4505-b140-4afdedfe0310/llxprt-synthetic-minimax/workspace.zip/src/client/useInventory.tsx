import { useState, useCallback } from 'react';
import type { InventoryPage } from '../shared/types';

interface UseInventoryReturn {
  data: InventoryPage | null;
  loading: boolean;
  error: string | null;
  currentPage: number;
  limit: number;
  fetchPage: (page: number, limit?: number) => Promise<void>;
  hasNext: boolean;
  hasPrevious: boolean;
}

export function useInventory(initialPage = 1, initialLimit = 5): UseInventoryReturn {
  const [data, setData] = useState<InventoryPage | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [limit, setLimit] = useState(initialLimit);

  const fetchPage = useCallback(async (page: number, newLimit?: number) => {
    setLoading(true);
    setError(null);
    
    try {
      const queryParams = new URLSearchParams();
      queryParams.set('page', page.toString());
      if (newLimit !== undefined) {
        queryParams.set('limit', newLimit.toString());
      } else {
        queryParams.set('limit', limit.toString());
      }

      const response = await fetch(`/inventory?${queryParams}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP ${response.status}`);
      }

      const result = await response.json();
      setData(result);
      setCurrentPage(page);
      if (newLimit !== undefined) {
        setLimit(newLimit);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [limit]);

  const hasNext = data?.hasNext ?? false;
  const hasPrevious = currentPage > 1;

  return {
    data,
    loading,
    error,
    currentPage,
    limit,
    fetchPage,
    hasNext,
    hasPrevious,
  };
}