import React from 'react';
import { useInventory } from './useInventory';
import type { InventoryItem } from '../shared/types';

interface InventoryViewProps {
  initialPage?: number;
  initialLimit?: number;
}

export function InventoryView({ initialPage = 1, initialLimit = 5 }: InventoryViewProps): JSX.Element {
  const {
    data,
    loading,
    error,
    currentPage,
    limit,
    fetchPage,
    hasNext,
    hasPrevious,
  } = useInventory(initialPage, initialLimit);

  React.useEffect((): void => {
    fetchPage(initialPage, initialLimit);
  }, [fetchPage, initialPage, initialLimit]);

  const handlePrevious = (): void => {
    if (hasPrevious) {
      fetchPage(currentPage - 1);
    }
  };

  const handleNext = (): void => {
    if (hasNext) {
      fetchPage(currentPage + 1);
    }
  };

  const handlePageChange = (page: number): void => {
    if (page >= 1 && page !== currentPage) {
      fetchPage(page);
    }
  };

  if (loading && !data) {
    return (
      <div className="inventory-view">
        <div className="loading">Loading inventory...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="inventory-view">
        <div className="error">
          <h3>Error loading inventory</h3>
          <p>{error}</p>
          <button onClick={() => fetchPage(currentPage)}>Retry</button>
        </div>
      </div>
    );
  }

  const { items, total } = data || { items: [], total: 0 };

  return (
    <div className="inventory-view">
      <header className="inventory-header">
        <h2>Inventory ({total} items total)</h2>
        <div className="page-info">
          Page {currentPage} of {Math.ceil(total / limit)} 
          ({limit} items per page)
        </div>
      </header>

      {items.length === 0 ? (
        <div className="empty-state">
          <p>No inventory items found.</p>
        </div>
      ) : (
        <div className="inventory-grid">
          {items.map((item: InventoryItem) => (
            <div key={item.id} className="inventory-item">
              <h3>{item.name}</h3>
              <p className="sku">SKU: {item.sku}</p>
              <p className="price">${(item.priceCents / 100).toFixed(2)}</p>
              <p className="created">Created: {new Date(item.createdAt).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      )}

      <div className="pagination-controls">
        <button
          onClick={handlePrevious}
          disabled={!hasPrevious || loading}
          className="nav-button prev"
        >
          Previous
        </button>

        <div className="page-buttons">
          {Array.from({ length: Math.min(5, Math.ceil(total / limit)) }, (_, i) => {
            const pageNum = i + Math.max(1, currentPage - 2);
            if (pageNum > Math.ceil(total / limit)) return null;
            
            return (
              <button
                key={pageNum}
                onClick={() => handlePageChange(pageNum)}
                disabled={loading || pageNum === currentPage}
                className={`page-button ${pageNum === currentPage ? 'active' : ''}`}
              >
                {pageNum}
              </button>
            );
          })}
        </div>

        <button
          onClick={handleNext}
          disabled={!hasNext || loading}
          className="nav-button next"
        >
          Next
        </button>
      </div>

      {loading && data && (
        <div className="loading-overlay">
          <div className="loading">Loading...</div>
        </div>
      )}
    </div>
  );
}