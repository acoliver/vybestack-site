import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (Number.isNaN(page) || page <= 0 || !Number.isInteger(page)) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      if (page > 10000) {
        return res.status(400).json({ error: 'Page number is too large' });
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (Number.isNaN(limit) || limit <= 0 || !Number.isInteger(limit)) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      if (limit > 100) {
        return res.status(400).json({ error: 'Limit cannot exceed 100' });
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
