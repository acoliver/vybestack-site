export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like name@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic email format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots (..)
  if (value.includes('..')) {
    return false;
  }
  
  // Check local part doesn't start or end with dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check domain part doesn't contain underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Domain cannot start or end with hyphen or dot
  if (domainPart && (domainPart.startsWith('-') || domainPart.startsWith('.') || 
      domainPart.endsWith('-') || domainPart.endsWith('.'))) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Remove optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    // 11 digits but doesn't start with 1
    return false;
  } else if (digitsOnly.length > 11) {
    // Too long
    return false;
  }
  
  // Check if we have exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the original format is valid
  // Accept formats like (212) 555-7890, 212-555-7890, 2125557890, etc.
  const validFormats = [
    /^\d{10}$/, // 1234567890
    /^\(\d{3}\) \d{3}-\d{4}$/, // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/, // 212-555-7890
    /^\d{3} \d{3} \d{4}$/, // 212 555 7890
    /^\+1\d{10}$/, // +11234567890
    /^\+1 \(\d{3}\) \d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1 \d{3}-\d{3}-\d{4}$/, // +1 212-555-7890
    /^\+1 \d{3} \d{3} \d{4}$/, // +1 212 555 7890
  ];
  
  return validFormats.some(format => format.test(value));
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Argentine phone validation regex
  // Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
  // Area code 2-4 digits (leading digit 1-9), subscriber number 6-8 digits
  const argentinePhoneRegex = /^\+54[ -]?(?:0[ -]?)?(?:9[ -]?)?[1-9]\d{0,3}[ -]?\d{3,4}[ -]?\d{3,4}$/;
  
  // First check basic format
  if (!argentinePhoneRegex.test(value)) {
    return false;
  }
  
  // Remove all separators to validate structure
  const digitsOnly = value.replace(/[ -]/g, '');
  
  // Check for optional +54 country code
  let phoneNumber = digitsOnly;
  let hasCountryCode = digitsOnly.startsWith('+54');
  
  if (hasCountryCode) {
    phoneNumber = digitsOnly.substring(3);
  }
  
  // Check for trunk prefix 0 (required if no country code)
  let hasTrunkPrefix = phoneNumber.startsWith('0');
  
  if (hasTrunkPrefix) {
    phoneNumber = phoneNumber.substring(1);
  } else if (!hasCountryCode) {
    // If no country code, trunk prefix is required
    return false;
  }
  
  // Check for mobile indicator 9
  let isMobile = phoneNumber.startsWith('9');
  
  if (isMobile) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode = '';
  let subscriberNumber = '';
  let validAreaCodeLength = false;
  
  // Try area code lengths from 2 to 4
  for (let i = 2; i <= 4; i++) {
    if (phoneNumber.length >= i) {
      const potentialAreaCode = phoneNumber.substring(0, i);
      if (/^[1-9]\d*$/.test(potentialAreaCode)) {
        areaCode = potentialAreaCode;
        subscriberNumber = phoneNumber.substring(i);
        // Check if subscriber number length is valid (6-8 digits)
        if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && /^\d+$/.test(subscriberNumber)) {
          validAreaCodeLength = true;
          break;
        }
      }
    }
  }
  
  return validAreaCodeLength;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least 2 and at most 50 characters
  if (value.trim().length < 2 || value.length > 50) {
    return false;
  }
  
// More specific regex that allows letters, accents, apostrophes, hyphens, and spaces
  const validNameChars = /^[\u00C0-\uFFFFa-zA-Z' -]+$/;
  
  // Check that the name contains valid characters and
  // doesn't contain any digits or symbols
  if (!validNameChars.test(value)) {
    return false;
  }
  
  // Name must contain at least one letter character
  const hasLetter = /[a-zA-Z\u00C0-\uFFFF]/.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum for additional validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (13-19 digits)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for known card patterns
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const visaPattern = /^4\d{12,18}$/;
  const mastercardPattern1 = /^5[1-5]\d{14}$/;
  const mastercardPattern2 = /^2(2[2-9]|[3-6]\d|7([01]|20))\d{12}$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  return (visaPattern.test(digitsOnly) || 
          mastercardPattern1.test(digitsOnly) || 
          mastercardPattern2.test(digitsOnly) || 
          amexPattern.test(digitsOnly)) && 
          runLuhnCheck(digitsOnly);
}

/**
 * Performs the Luhn algorithm checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
