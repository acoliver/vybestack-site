/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex to match words starting with the prefix (case-insensitive)
  // \b ensures word boundary, \w+ matches word characters
  const prefixRegex = new RegExp(`\\b(${prefix}\\w+)`, 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  // Convert exceptions to lower case for case-insensitive comparison
  const lowerCaseExceptions = exceptions.map(exception => exception.toLowerCase());
  
  // Filter out exceptions (case-insensitive)
  const filteredWords = matches.filter(word => 
    !lowerCaseExceptions.includes(word.toLowerCase())
  );
  
  // Deduplicate and return
  return [...new Set(filteredWords)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create regex to find the token preceded by a digit but not at the start of the string
  // Using lookbehind to check for a digit, and negative lookahead to ensure token is not at start
  const tokenRegex = new RegExp(`(\\d${token})(?=[^a-zA-Z]|$)`, 'g');
  
  const matches = [];
  let match;
  
  // Execute the regex to find all matches
  while ((match = tokenRegex.exec(text)) !== null) {
    // Extract the matched token itself (including the preceding digit)
    matches.push(match[1]);
  }
  
  return matches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (pattern repeated twice)
  // This checks for patterns like abab, 123123, etc.
  for (let i = 2; i <= value.length / 2; i++) {
    const pattern = value.substring(0, i);
    if (value.startsWith(pattern) && value.substring(i, 2 * i) === pattern) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  const ipv6Patterns = [
    // General IPv6 pattern with shorthand support
    /([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|::[0-9a-fA-F]{1,4}|::/,
    // IPv6 with port: [::]:8080
    /^\[([0-9a-fA-F:]+)\](:\d+)?$/,
    // IPv4-mapped IPv6: ::ffff:192.0.2.128
    /^::ffff:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
    // IPv6 with shorthand and optional IPv4 part: 2001:db8::192.0.2.33
    /^[0-9a-fA-F:]*:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/
  ];
  
  // IPv4 regex patterns to exclude
  const ipv4Patterns = [
    // Standard IPv4: 192.168.1.1
    /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
    // IPv4 with port: 192.168.1.1:8080
    /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$/
  ];
  
  // First check if it looks like an IPv4 address
  const looksLikeIPv4 = ipv4Patterns.some(pattern => pattern.test(value));
  if (looksLikeIPv4) {
    return false;
  }
  
  // Check for IPv6 patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
