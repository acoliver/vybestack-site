/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces sensibly
 * while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Common abbreviations to avoid breaking after them
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Jr', 'Sr', 'Ph.D', 'i.e', 'e.g', 'etc', 'vs', 'al'];
  
  // First, replace multiple spaces with a single space
  text = text.replace(/\s+/g, ' ');
  
  // Split into sentences using sentence-ending punctuation (.?!)
  // But look ahead to ensure we're not at an abbreviation
  const sentenceSplitRegex = new RegExp(`(?<![${abbreviations.join('|')}])\\s*([.!?]+)\\s+`);
  const sentences = text.split(sentenceSplitRegex);
  
  // Process and rebuild
  let result = '';
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i];
    
    // If it's a sentence-ending punctuation and not the last element,
    // it needs to be added to the next sentence start
    if (/[.!?]/.test(sentence) && i < sentences.length - 1) {
      result += sentence + ' ';
      continue;
    }
    
    // Skip empty strings
    if (!sentence) continue;
    
    // Capitalize first character
    sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    
    result += sentence;
    
    // Add space if not at the end and next element is not punctuation
    if (i < sentences.length - 1 && !/[.!?]/.test(sentences[i + 1])) {
      result += ' ';
    }
  }
  
  return result.trim();
}

/**
 * Finds all URLs in the text and returns them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern that matches most common URL formats
  const urlRegex = /(https?:\/\/|www\.)[^\s]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up each match by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation: .,;:!?) and others but preserve domain punctuation
    return url.replace(/[.,;:!?)\]]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https:// but not https://
  // Using negative lookahead to ensure https:// is not affected
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrites URLs for http://example.com/...:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints like cgi-bin, query strings, or legacy extensions
 * - Preserves nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // Patterns to identify URLs that should not have host rewritten
  const skipHostRewritePatterns = [
    'cgi-bin',
    /[?&]/,  // Query parameters
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i  // Legacy extensions
  ];
  
  // Regular expression to match URLs
  const urlRegex = /(https?):\/\/(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if host should be rewritten
    let shouldRewriteHost = path.startsWith('/docs/');
    
    // Check for skip patterns
    for (const pattern of skipHostRewritePatterns) {
      if (typeof pattern === 'string') {
        if (path.includes(pattern)) {
          shouldRewriteHost = false;
          break;
        }
      } else if (pattern instanceof RegExp) {
        if (pattern.test(path)) {
          shouldRewriteHost = false;
          break;
        }
      }
    }
    
    const newDomain = shouldRewriteHost ? 'docs.example.com' : domain;
    
    return `${newProtocol}://${newDomain}${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Regex to match mm/dd/yyyy format and extract month, day, year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const maxDayByMonth: Record<number, number> = {
    1: 31,  // January
    2: 29,  // February (simplified - not checking leap years)
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31
  };
  
  if (day > maxDayByMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
