/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: ObserverR
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Update observer with new value based on update function
export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Track dependencies for reactive updates
const dependencies = new Map<ObserverR, Set<Subject<unknown>>>()
export const subjectToDependents = new Map<Subject<unknown>, Set<ObserverR>>()
const observerToSubjects = new Map<ObserverR, Set<Subject<unknown>>>()
const computedSubjectMap = new Map<ObserverR, Subject<unknown>>()

// Register a computed subject for an observer
export function registerComputedSubject(observer: ObserverR, subject: Subject<unknown>): void {
  computedSubjectMap.set(observer, subject)
}

// Get the computed subject for an observer
export function getComputedSubject(observer: ObserverR): Subject<unknown> | undefined {
  return computedSubjectMap.get(observer)
}

export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    let subjectSet = dependencies.get(observer)
    if (!subjectSet) {
      subjectSet = new Set()
      dependencies.set(observer, subjectSet)
    }
    subjectSet.add(subject as Subject<unknown>)
    
    // Track which observers depend on this subject
    let dependentSet = subjectToDependents.get(subject as Subject<unknown>)
    if (!dependentSet) {
      dependentSet = new Set()
      subjectToDependents.set(subject as Subject<unknown>, dependentSet)
    }
    dependentSet.add(observer)
    
    // Track which subjects this observer depends on
    let observerSet = observerToSubjects.get(observer)
    if (!observerSet) {
      observerSet = new Set()
      observerToSubjects.set(observer, observerSet)
    }
    observerSet.add(subject as Subject<unknown>)
  }
}

export function clearDependencies(observer: ObserverR): void {
  const subjectSet = observerToSubjects.get(observer)
  if (subjectSet) {
    for (const subject of subjectSet) {
      const dependentSet = subjectToDependents.get(subject)
      if (dependentSet) {
        dependentSet.delete(observer)
        if (dependentSet.size === 0) {
          subjectToDependents.delete(subject)
        }
      }
    }
    observerToSubjects.delete(observer)
  }
  dependencies.delete(observer)
  computedSubjectMap.delete(observer)
}

// Notify all observers that depend on this subject
export function notifyDependents<T>(subject: Subject<T>): void {
  // Find all observers that depend on this subject
  const dependents = Array.from(subjectToDependents.get(subject as Subject<unknown>) || [])
  
  // Update all dependent observers
  for (const observer of dependents) {
    const oldValue = (observer as Observer<unknown>).value
    updateObserver(observer as Observer<unknown>)
    
    // Check if value actually changed and notify if needed
    const newValue = (observer as Observer<unknown>).value
    if (oldValue !== newValue) {
      // Find this observer's computed subject to continue the notification chain
      const computedSubject = getComputedSubject(observer)
      if (computedSubject) {
        // Update the subject's value
        computedSubject.value = newValue
        // Notify dependents of this computed value
        notifyDependents(computedSubject)
      }
    }
  }
}