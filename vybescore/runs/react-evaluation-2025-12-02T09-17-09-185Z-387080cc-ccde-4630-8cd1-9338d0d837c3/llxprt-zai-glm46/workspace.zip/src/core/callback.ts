/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, clearDependencies } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }
  
  // Execute the callback once to establish dependencies and get initial value
  updateObserver(observer)
  
  const unsubscribe = () => {
    // Clear all dependencies for this observer to stop further updates
    clearDependencies(observer)
  }
  
  return unsubscribe
}