/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  trackDependency,
  Subject,
  registerComputedSubject
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Create a subject interface for this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: o,
    value: o.value!,
    equalFn
  }
  
  // Register this computed subject for the observer
  registerComputedSubject(o, computedSubject as Subject<unknown>)
  
  // Initialize the computed value
  updateObserver(o)
  
  const compute: GetterFn<T> = () => {
    trackDependency(computedSubject)
    return o.value!
  }

  return compute
}