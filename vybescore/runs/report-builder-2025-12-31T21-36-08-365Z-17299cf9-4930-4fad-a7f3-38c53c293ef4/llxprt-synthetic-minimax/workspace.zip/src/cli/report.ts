#!/usr/bin/env node

/**
 * Report Builder CLI
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import { readFileSync } from 'node:fs';
import { ReportData, CliOptions, OutputFormat } from '../types/report.js';
import { formatters } from '../formats/index.js';

// Load formatters (this ensures they register themselves)
import '../formats/markdown.js';
import '../formats/text.js';

// Parse command line arguments using Node's standard library
function parseArgs(argv: string[]): CliOptions {
  const args = argv.slice(2); // Skip node and script name
  
  if (args.length < 2) {
    printErrorAndExit('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  let inputFile: string = '';
  let format: OutputFormat = 'markdown'; // default
  let outputFile: string | undefined;
  let includeTotals = false;
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      // This should be the input file
      if (!inputFile) {
        inputFile = arg;
      } else {
        printErrorAndExit('Multiple input files specified');
      }
    } else {
      // Parse flags
      switch (arg) {
        case '--format':
          if (i + 1 >= args.length) {
            printErrorAndExit('--format requires a value');
          }
          format = args[i + 1] as OutputFormat;
          if (format !== 'markdown' && format !== 'text') {
            printErrorAndExit(`Unsupported format: ${format}. Supported formats: markdown, text`);
          }
          i++; // Skip the value
          break;
        case '--output':
          if (i + 1 >= args.length) {
            printErrorAndExit('--output requires a value');
          }
          outputFile = args[i + 1];
          i++; // Skip the value
          break;
        case '--includeTotals':
          includeTotals = true;
          break;
        default:
          printErrorAndExit(`Unknown option: ${arg}`);
      }
    }
    
    i++;
  }
  
  if (!inputFile) {
    printErrorAndExit('Input file is required');
  }
  
  if (!format) {
    printErrorAndExit('--format is required');
  }
  
  return {
    inputFile,
    format,
    outputFile,
    includeTotals
  };
}

// Print error message and exit with code 1
function printErrorAndExit(message: string): never {
  console.error(message);
  process.exit(1);
}

// Load and parse JSON file
function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Invalid or missing "entries" field - must be a non-empty array');
    }
    
    // Validate entries structure
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Invalid or missing "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: Invalid or missing "amount" field - must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        printErrorAndExit(`Input file not found: ${filePath}`);
      } else if (error.message.includes('JSON')) {
        printErrorAndExit('Invalid JSON file - please check file syntax');
      } else {
        printErrorAndExit(`Error loading data: ${error.message}`);
      }
    } else {
      printErrorAndExit('Unknown error loading data file');
    }
  }
}

// Main execution
function main(): void {
  try {
    const options = parseArgs(process.argv);
    const data = loadReportData(options.inputFile);
    
    // Get the formatter
    const formatter = formatters[options.format];
    if (!formatter) {
      printErrorAndExit(`Unsupported format: ${options.format}. Supported formats: markdown, text`);
    }
    
    // Render the report
    const output = formatter(data, { includeTotals: options.includeTotals });
    
    // Write output
    if (options.outputFile) {
      // Import fs dynamically to avoid circular dependencies
      import('node:fs').then(({ writeFileSync }) => {
        writeFileSync(options.outputFile!, output);
      }).catch(() => {
        // Fallback to writeFileSync with dynamic import
        try {
          // eslint-disable-next-line @typescript-eslint/no-var-requires
          const fs = require('node:fs');
          fs.writeFileSync(options.outputFile!, output);
        } catch {
          printErrorAndExit('Error writing output file');
        }
      });
    } else {
      // Write to stdout
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      printErrorAndExit(error.message);
    } else {
      printErrorAndExit('Unknown error occurred');
    }
  }
}

// Run the CLI
main();
