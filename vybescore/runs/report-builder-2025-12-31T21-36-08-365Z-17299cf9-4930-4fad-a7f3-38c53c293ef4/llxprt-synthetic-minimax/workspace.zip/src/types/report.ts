/**
 * Shared types for the report builder CLI
 */

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface RenderOptions {
  includeTotals: boolean;
}

export type OutputFormat = 'markdown' | 'text';

export interface CliOptions {
  inputFile: string;
  format: OutputFormat;
  outputFile?: string;
  includeTotals: boolean;
}