/**
 * Formatter interface and registry
 */

import { ReportData, RenderOptions } from '../types/report.js';

// Formatter function signature
export interface Formatter {
  (data: ReportData, options: RenderOptions): string;
}

// Registry of available formatters
export const formatters: Record<string, Formatter> = {};