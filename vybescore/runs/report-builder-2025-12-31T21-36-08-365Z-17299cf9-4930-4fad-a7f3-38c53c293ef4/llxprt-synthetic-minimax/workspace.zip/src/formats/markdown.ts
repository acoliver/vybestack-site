/**
 * Markdown format renderer
 */

import { ReportData, RenderOptions } from '../types/report.js';
import { formatters } from './index.js';

// Format amount exactly as required: $12345.67 (two decimal places, no thousands separators)
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

// Calculate total from entries
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries section
  lines.push('## Entries');
  
  // Bullet list for entries
  data.entries.forEach(entry => {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  });
  
  // Include total if requested
  if (options.includeTotals) {
    lines.push(''); // blank line before total
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }
  
  return lines.join('\n');
}

// Register the formatter
formatters.markdown = renderMarkdown;