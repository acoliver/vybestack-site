export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Check for basic format: local@domain.tld
  // Support typical characters including +, -, _, ., but reject invalid patterns
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;
  
  // Must match the basic regex
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  // Reject double dots anywhere
  if (trimmed.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in domain
  if (trimmed.endsWith('.')) {
    return false;
  }
  
  // Reject domain with underscores
  const domainPart = trimmed.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace and separators for digit count validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 10 digits, at most 11 (with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCodeStart = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeStart, areaCodeStart + 3);
  
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate format using regex patterns
  const patterns = [
    /^\+?1?[\s-]?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/, // Standard US format
  ];
  
  // Test against multiple patterns
  return patterns.some(pattern => {
    const match = value.match(pattern);
    if (!match) return false;
    
    // Extract area code from match for validation
    const matchedDigits = value.replace(/\D/g, '');
    const areaCodeIndex = matchedDigits.length === 11 ? 1 : 0;
    const areaCodeFromMatch = matchedDigits.substring(areaCodeIndex, areaCodeIndex + 3);
    
    // Area code cannot start with 0 or 1
    return !areaCodeFromMatch.startsWith('0') && !areaCodeFromMatch.startsWith('1');
  });
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace, hyphens, and punctuation except + and digits
  const cleaned = value.replace(/[\s-().]/g, '');
  
  // Must have at least some reasonable length
  if (cleaned.length < 8) {
    return false;
  }
  
  // Comprehensive regex for Argentine phone validation
  const patterns = [
    // With country code and mobile: +54 9 11 1234 5678 or +54 341 123 4567
    /^\+54\s*9?\s*([1-9]\d{1,3})\s*(\d{3,4})\s*(\d{3,4})$/,
    // With country code only: +54 11 1234 5678 or +54 341 123 4567  
    /^\+54\s*([1-9]\d{1,3})\s*(\d{3,4})\s*(\d{3,4})$/,
    // With trunk prefix: 011 1234 5678 or 011 123 4567
    /^0\s*([1-9]\d{1,3})\s*(\d{3,4})\s*(\d{3,4})$/,
    // Direct mobile format: 9 341 123 4567
    /^9\s*([1-9]\d{1,3})\s*(\d{3,4})\s*(\d{3,4})$/,
    // Direct area code with trunk prefix: 0341 4234567 (no spaces)
    /^0([1-9]\d{1,3})\s*(\d{6,8})$/,
    // Alternative: area code with subscriber as single group: +54 11 12345678
    /^\+54\s*([1-9]\d{1,3})\s*(\d{6,8})$/,
    // Alternative: with trunk prefix and single subscriber group: 011 12345678
    /^0\s*([1-9]\d{1,3})\s*(\d{6,8})$/
  ];
  
  // Validate using patterns
  return patterns.some(pattern => {
    const match = value.match(pattern);
    if (!match) return false;
    
    // Extract area code and subscriber parts
    const areaCode = match[1];
    const subscriber = pattern.source.includes('\\d{3,4}') && match[3] 
      ? match[2] + match[3]  // Combined subscriber parts
      : match[2];           // Single subscriber part
    
    // Validate area code
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    if (!areaCode.match(/^[1-9]\d{1,3}$/)) {
      return false;
    }
    
    // Validate subscriber total length
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    return true;
  });
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Must not be empty
  if (trimmed.length === 0) {
    return false;
  }
  
  // Must not contain digits
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Must not contain symbols except apostrophe, hyphen, and spaces
  if (/[!@#$%^&*()_+=[\]{};':",.<>?`~]/.test(trimmed)) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Pattern allows: letters (including unicode), apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Reject obviously fake names like "X Æ A-12"
  // These patterns suggest fictional/format names
  const suspiciousPatterns = [
    /^X\s*Æ\s*A/,  // "X Æ A-12" style
    /^\d+[\s-]*[A-Z]/i,        // Names starting with numbers
  ];
  
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(trimmed)) {
      return false;
    }
  }
  
  // Must have reasonable length (at least 2 characters)
  if (trimmed.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have reasonable length for credit cards (13-19 digits)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid card type prefixes and lengths
  const cardTypes = [
    // Visa: starts with 4, length 13, 16, or 19
    { prefix: /^4/, length: [13, 16, 19] },
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    { prefix: /^(5[1-5]|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)/, length: [16] },
    // American Express: starts with 34 or 37, length 15
    { prefix: /^(34|37)/, length: [15] },
    // Discover: starts with 6011, 622126-622925, 644-649, or 65, length 16, 19
    { prefix: /^(6011|622[1-9][2-5]\d|6[4-9]\d|[2-8]\d{3}|9\d{2}|65\d{2}|64[4-9]\d)/, length: [16, 19] },
  ];
  
  // Validate card type and length
  let isValidCardType = false;
  for (const cardType of cardTypes) {
    if (cardType.prefix.test(digitsOnly) && cardType.length.includes(digitsOnly.length)) {
      isValidCardType = true;
      break;
    }
  }
  
  if (!isValidCardType) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

// Helper function to perform Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
