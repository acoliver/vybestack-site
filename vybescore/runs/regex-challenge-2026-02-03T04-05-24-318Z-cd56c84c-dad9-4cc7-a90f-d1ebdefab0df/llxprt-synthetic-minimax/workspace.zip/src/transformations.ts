/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spaces - collapse multiple spaces into single spaces
  const normalized = text.replace(/\s+/g, ' ');
  
  // Pattern to match sentence boundaries (after .?!)
  // Need to be careful about abbreviations like "U.S.A." or "Dr."
  const sentences: string[] = [];
  
  // Use a more sophisticated approach to handle sentence splitting
  const sentencePattern = /([.!?]+\s*|[.!?]+$)/g;
  let lastIndex = 0;
  let match;
  
  while ((match = sentencePattern.exec(normalized)) !== null) {
    const endIndex = match.index + match[0].length;
    const sentence = normalized.substring(lastIndex, endIndex).trim();
    
    if (sentence.length > 0) {
      sentences.push(sentence);
    }
    
    lastIndex = endIndex;
  }
  
  // Handle case where no sentence endings were found
  if (sentences.length === 0 && normalized.trim()) {
    sentences.push(normalized.trim());
  }
  
  // Capitalize each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    
    // Find the first letter that should be capitalized
    const firstLetterMatch = sentence.match(/[a-zA-Z]/);
    if (firstLetterMatch) {
      const index = firstLetterMatch.index!;
      return sentence.substring(0, index) + 
             firstLetterMatch[0].toUpperCase() + 
             sentence.substring(index + 1);
    }
    
    return sentence;
  });
  
  // Join sentences with exactly one space
  return capitalizedSentences.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Pattern to match URLs with various schemes
  // Allow dots and stop at word boundaries
  const urlPattern = /\b(?:https?:\/\/|www\.)[\w\-.,/#?+&%=~]*\b/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation that isn't part of the URL
    while (url.length > 0 && /[.,;!?]$/.test(url)) {
      url = url.substring(0, url.length - 1);
    }
    
    // Also handle trailing closing parentheses
    while (url.length > 0 && /\)$/.test(url)) {
      url = url.substring(0, url.length - 1);
    }
    
    if (url.length > 0) {
      urls.push(url);
    }
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// using global replacement
  // Use word boundary to avoid replacing in non-URL contexts
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http URLs
  // Capture the scheme, host, path, and query
  const httpUrlPattern = /\bhttp:\/\/([^\s/]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlPattern, (fullUrl, host, path = '') => {
    let newUrl = fullUrl;
    
    // Always upgrade scheme from http to https
    newUrl = fullUrl.replace(/^http:\/\//i, 'https://');
    
    // Check if path starts with /docs/ and handle host rewriting
    if (path.startsWith('/docs/')) {
      // Skip host rewriting if path contains dynamic hints
      const hasDynamicHints = /(\?.*)|(.*\b(cgi-bin|query|param)\b)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (!hasDynamicHints) {
        // Extract the original domain (without subdomain)
        const hostParts = host.split('.');
        if (hostParts.length >= 2) {
          const domain = hostParts.slice(-2).join('.');
          const newHost = `docs.${domain}`;
          newUrl = newUrl.replace(/\/\/([^/]+)/, `//${newHost}`);
        }
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (with basic leap year handling)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for Feb to handle leap years
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Special case for February 29 - check leap year
  if (month === 2 && day === 29) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  // Return the year as string
  return year.toString();
}
