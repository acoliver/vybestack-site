/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create word boundary pattern to match whole words
  // Use word boundaries to ensure we match complete words
  const escapedPrefix = escapeRegex(prefix);
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0].toLowerCase();
    
    // Check if the matched word is in the exceptions list
    if (!exceptions.some(exception => word.includes(exception.toLowerCase()))) {
      matches.push(match[0]);
    }
  }
  
  // Remove duplicates while preserving order
  return [...new Set(matches)];
}

// Helper function to escape special regex characters
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create regex pattern using lookaheads and lookbehinds
  // Negative lookbehind: not at start of string (positive lookbehind for any character OR start)
  // Positive lookbehind: must be preceded by a digit
  const tokenEscaped = escapeRegex(token);
  
  // Pattern explanation:
  // (?<!^): Not at the beginning of the string
  // (?<=\d): Must be preceded by a digit
  // token: The token to find
  const pattern = new RegExp(`(?<!^)(?<=\\d)${tokenEscaped}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Need to include the digit in the match
    const digitIndex = match.index - 1;
    if (digitIndex >= 0 && /\d/.test(text[digitIndex])) {
      const fullMatch = text.substring(digitIndex, match.index + token.length);
      matches.push(fullMatch);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"\\|,.<>?`~]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab", "1212", etc.
  // This checks for patterns that repeat immediately (length 2 minimum, 4+ for sequence)
  for (let i = 0; i < value.length - 3; i++) {
    const sequence = value.substring(i, i + 4);
    if (sequence.length >= 4) {
      // Check if it's a repetition of a 2-character pattern
      const pattern = sequence.substring(0, 2);
      const remainder = sequence.substring(2);
      
      if (remainder === pattern) {
        return false;
      }
      
      // Check if it's a repetition of a single character
      if (remainder === remainder.charAt(0).repeat(remainder.length)) {
        return false;
      }
    }
  }
  
  // Check for more obvious immediate repetitions
  const repetitionPatterns = [
    /(.)\1{2,}/, // Three or more identical consecutive characters
    /(..)\1/,     // Immediate repetition of 2-character pattern
    /(.{2,})\1/, // Any immediate repetition of 2+ characters
  ];
  
  for (const pattern of repetitionPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, exclude any IPv4 addresses using word boundary
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Comprehensive IPv6 pattern
  // This handles:
  // - Full form: 2001:0db8:0000:0000:0000:ff00:0042:8329
  // - Compressed: 2001:db8::ff00:42:8329
  // - Dual-stack: 2001:db8::1.2.3.4 (mixed notation, but we exclude IPv4 parts)
  // - Localhost: ::1
  // - All zeros: ::
  // - Various formats with leading zeros, case-insensitive
  
  const ipv6Patterns = [
    // Full IPv6 with 8 groups
    /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/gi,
    
    // IPv6 with compression (::)
    /\b(?:[a-f0-9]{1,4}:)*::(?:[a-f0-9]{1,4}:)*[a-f0-9]{1,4}\b/gi,
    
    // Mixed notation (IPv6 with embedded IPv4) - but we'll check separately
    /\b(?:[a-f0-9]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/gi,
    
    // Additional compressed formats
    /\b[a-f0-9]{0,4}::(?:[a-f0-9]{1,4}:){0,6}[a-f0-9]{0,4}\b/gi,
    
    // Shortened local addresses
    /\b::1\b/gi,
    
    // All zeros
    /\b::\b/gi,
    
    // IPv6 loopback
    /\b0{0,3}:0{0,3}:0{0,3}:0{0,3}:0{0,3}:0{0,3}:0{0,3}:0{1}\b/gi,
  ];
  
  // Test against all IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Double-check it's not an IPv4 address
      // If the match contains dots, it's likely mixed notation with IPv4
      // In that case, we should NOT count it as pure IPv6
      const matches = value.match(pattern);
      if (matches) {
        for (const match of matches) {
          if (match.includes('.')) {
            // This is mixed notation containing IPv4 - exclude
            continue;
          }
          return true;
        }
      }
    }
  }
  
  return false;
}
