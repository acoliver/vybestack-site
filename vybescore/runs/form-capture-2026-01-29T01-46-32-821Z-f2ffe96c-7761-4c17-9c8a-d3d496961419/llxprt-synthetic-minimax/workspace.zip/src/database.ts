import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
  created_at?: string;
}

interface SqlJsDatabase {
  run(sql: string, params?: unknown[]): void;
  exec(sql: string): Array<{values: unknown[][]}>;
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatement {
  bind(params: unknown[]): void;
  step(): boolean;
  free(): void;
}

interface SqlJsStatic {
  Database: new(dbBuffer?: Uint8Array) => SqlJsDatabase;
}

export class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private sqlJs: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    // Initialize sql.js
    this.sqlJs = await initSqlJs({
      locateFile: () => {
        // Load the wasm file from node_modules using absolute path
        return path.resolve('node_modules/sql.js/dist/sql-wasm.wasm');
      }
    });

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaSql = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    const statements = schemaSql.split(';').filter(stmt => stmt.trim());
    
    for (const statement of statements) {
      if (statement.trim()) {
        this.db.run(statement);
      }
    }
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const sql = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const stmt = this.db.prepare(sql);
    stmt.bind([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province_region,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone_number
    ]);
    stmt.step();
    stmt.free();

    // Get the last inserted ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0]?.values[0][0] as number;

    await this.save();
    return id;
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const binaryDb = this.db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(binaryDb));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}