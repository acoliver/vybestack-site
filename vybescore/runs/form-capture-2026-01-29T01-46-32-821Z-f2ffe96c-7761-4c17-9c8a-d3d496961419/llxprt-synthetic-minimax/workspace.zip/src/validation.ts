export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province_region',
    'postal_code',
    'country',
    'email',
    'phone_number'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = `${field.replace(/_/g, ' ')} is required`;
    }
  }

  // Email validation (simple but effective regex)
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone number validation (accepts international formats)
  if (data.phone_number && data.phone_number.trim() !== '') {
    const phoneRegex = /^\+?[\d\s()-]+$/;
    if (!phoneRegex.test(data.phone_number)) {
      errors.phone_number = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (alphanumeric, supports various international formats)
  if (data.postal_code && data.postal_code.trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}