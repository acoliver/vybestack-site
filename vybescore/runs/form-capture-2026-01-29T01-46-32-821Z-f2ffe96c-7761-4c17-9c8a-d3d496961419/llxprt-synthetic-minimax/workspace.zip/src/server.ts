import express, { Request, Response } from 'express';
import path from 'node:path';
import { DatabaseManager, Submission } from './database.js';
import { validateForm, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database manager
const dbManager = new DatabaseManager();

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.resolve('views'));
app.use(express.static(path.resolve('public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Routes

// GET / - Show contact form
app.get('/', async (req: Request, res: Response) => {
  try {
    await dbManager.initialize();
    res.render('form', { 
      title: 'Friendly Contact Form',
      errors: {},
      formData: {}
    });
  } catch (error) {
    console.error('Error loading form:', error);
    res.status(500).send('Internal server error');
  }
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name?.trim() || '',
      last_name: req.body.last_name?.trim() || '',
      street_address: req.body.street_address?.trim() || '',
      city: req.body.city?.trim() || '',
      state_province_region: req.body.state_province_region?.trim() || '',
      postal_code: req.body.postal_code?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone_number: req.body.phone_number?.trim() || ''
    };

    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        title: 'Friendly Contact Form - Please Fix Errors',
        errors: validation.errors,
        formData
      });
    }

    // Insert submission into database
    await dbManager.initialize();
    const submission: Omit<Submission, 'id' | 'created_at'> = {
      first_name: formData.first_name,
      last_name: formData.last_name,
      street_address: formData.street_address,
      city: formData.city,
      state_province_region: formData.state_province_region,
      postal_code: formData.postal_code,
      country: formData.country,
      email: formData.email,
      phone_number: formData.phone_number
    };

    await dbManager.insertSubmission(submission);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).send('Internal server error');
  }
});

// GET /thank-you - Show thank you page
app.get('/thank-you', async (req: Request, res: Response) => {
  try {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  } catch (error) {
    console.error('Error loading thank you page:', error);
    res.status(500).send('Internal server error');
  }
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  if (res && typeof res.status === 'function') {
    res.status(500).send('Internal server error');
  } else {
    console.error('Response object not available for error handling');
  }
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await dbManager.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      console.log('Press Ctrl+C to stop the server');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export app for testing
export { app, dbManager };

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
