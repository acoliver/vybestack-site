declare module 'sql.js' {
  interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): Array<{values: unknown[][]}>;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  interface Statement {
    bind(params: unknown[]): void;
    step(): boolean;
    free(): void;
  }
  
  interface SqlJsResult {
    Database: new(dbBuffer?: Uint8Array) => Database;
  }

  function initSqlJs(options?: {
    locateFile?: (file: string) => string;
  }): Promise<SqlJsResult>;
  
  export default initSqlJs;
  export { Database, Statement, SqlJsResult };
}