import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../../dist/server.js';
import { createServer } from 'node:http';

let server: ReturnType<typeof createServer>;
let testPort: number = 0;

beforeAll(async () => {
  // Clean up any existing database
  const dbPath = path.resolve('data', 'submissions.sqlite');
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Start the server on a random port
  const { createServer } = await import('node:http');
  server = createServer(app);
  
  return new Promise((resolve, reject) => {
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      testPort = address.port;
      console.log(`Test server running on port ${testPort}`);
      resolve(null);
    });
    server.on('error', reject);
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  // Clean up database after tests
  const dbPath = path.resolve('data', 'submissions.sqlite');
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await fetch(`http://127.0.0.1:${testPort}/`);
    const html = await response.text();
    
    expect(response.status).toBe(200);
    expect(html).toContain('Friendly Contact Form');
    expect(html).toContain('First Name');
    expect(html).toContain('Last Name');
    expect(html).toContain('Street Address');
    expect(html).toContain('City');
    expect(html).toContain('State/Province/Region');
    expect(html).toContain('Postal/Zip Code');
    expect(html).toContain('Country');
    expect(html).toContain('Email Address');
    expect(html).toContain('Phone Number');
    expect(html).toContain('action="/submit"');
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = new URLSearchParams({
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province_region: 'State',
      postal_code: '12345',
      country: 'Country',
      email: 'john@example.com',
      phone_number: '+1234567890'
    });

    const response = await fetch(`http://127.0.0.1:${testPort}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData,
      redirect: 'manual'
    });

    expect(response.status).toBe(302);
    expect(response.headers.get('location')).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
