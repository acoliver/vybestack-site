import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({
  currentPage,
  hasNext,
  totalItems,
  itemsPerPage,
  onPageChange
}: {
  currentPage: number;
  hasNext: boolean;
  totalItems: number;
  itemsPerPage: number;
  onPageChange: (page: number) => void;
}): JSX.Element {
  const hasPrevious = currentPage > 1;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  return (
    <nav aria-label="Pagination controls">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' }}>
        <div>
          <button
            onClick={() => onPageChange(currentPage - 1)}
            disabled={!hasPrevious}
            aria-label="Previous page"
            style={{
              padding: '0.5rem 1rem',
              cursor: hasPrevious ? 'pointer' : 'not-allowed',
              opacity: hasPrevious ? 1 : 0.5
            }}
          >
            Previous
          </button>
        </div>
        
        <div>
          <span>
            Page {currentPage} of {totalPages || 1} ({totalItems} total items)
          </span>
        </div>
        
        <div>
          <button
            onClick={() => onPageChange(currentPage + 1)}
            disabled={!hasNext}
            aria-label="Next page"
            style={{
              padding: '0.5rem 1rem',
              cursor: hasNext ? 'pointer' : 'not-allowed',
              opacity: hasNext ? 1 : 0.5
            }}
          >
            Next
          </button>
        </div>
      </div>
    </nav>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={data.page}
        hasNext={data.hasNext}
        totalItems={data.total}
        itemsPerPage={data.limit}
        onPageChange={setCurrentPage}
      />
    </section>
  );
}
