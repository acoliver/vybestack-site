const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function isValidBase64(input: string): boolean {
  // Check length is a multiple of 4
  if (input.length % 4 !== 0) {
    return false;
  }
  
  // Check characters and padding
  if (!BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Check padding rules
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be at the end
    const padding = input.slice(paddingIndex);
    if (padding.length > 2) {
      return false;
    }
    // If padding is present, it must be one or two '=' characters
    if (!/^={1,2}$/.test(padding)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Add padding if missing
  const paddedInput = input.length % 4 === 0 ? input : input + '='.repeat(4 - (input.length % 4));
  
  // Validate the Base64 input
  if (!isValidBase64(paddedInput)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
