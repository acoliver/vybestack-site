/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!)
  // Insert exactly one space between sentences even if the input omitted it
  // Collapse extra spaces sensibly while leaving abbreviations intact when possible
  
  if (!text) {
    return text;
  }
  
  // Split into sentences - look for . ? ! followed by space or end of string
  // Use regex to capture sentence endings
  const sentences = text.match(/[^.!?]+[.!?]*(?:\s+|$)/g) || [text];
  
  let result = '';
  
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i].trim();
    
    if (sentence.length === 0) {
      continue;
    }
    
    // Capitalize first letter
    sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    
    // Add back appropriate spacing
    if (i < sentences.length - 1 && sentences[i + 1].trim().length > 0) {
      // Ensure exactly one space between sentences
      sentence = sentence.replace(/\s+$/, '') + ' ';
    }
    
    result += sentence;
  }
  
  // Clean up multiple spaces but preserve single spaces
  result = result.replace(/\s{2,}/g, ' ').trim();
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Return all URLs detected in the text without trailing punctuation
  
  if (!text) {
    return [];
  }
  
  // Pattern to match URLs, capturing the main URL without trailing punctuation
  const urlPattern = /\b(?:https?|ftp):\/\/[^\s<>"']+[^\s<>"',.!?)]*/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up any trailing punctuation that might have been captured
  return matches.map(url => {
    // Remove trailing punctuation carefully
    return url.replace(/[.,!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// but leave https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://.
  // - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/...
  // - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://.
  // - Preserve nested paths (e.g., /docs/api/v1).
  
  if (!text) {
    return text;
  }
  
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)/gi, (match, host, path) => {
    // For docs URLs, rewrite the host to docs.<original-domain>
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /[?&]|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      if (hasDynamicHints) {
        // Skip host rewrite, just upgrade scheme
        return `https://${host}${path}`;
      } else {
        // Rewrite host to docs.<original-domain>
        const newHost = `docs.${host}`;
        return `https://${newHost}${path}`;
      }
    } else {
      // Not a docs path, just upgrade scheme
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy. If the string doesn't match that format or month/day are invalid, return N/A.
  
  if (!value) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1]);
  const day = parseInt(dateMatch[2]);
  const year = dateMatch[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for days in months (simple check)
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  if ([4, 6, 9, 11].includes(month) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
