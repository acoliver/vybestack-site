/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  if (!text || !prefix) {
    return [];
  }
  
  // Create regex pattern for words starting with prefix
  // Use word boundaries to match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowercaseMatch
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string
  // Use lookaheads/lookbehinds
  
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find occurrences where token appears after a digit (not at start of string)
  // This should find patterns like "1foo", "2bar", etc. and return the full match
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'gi');
  
  const matches = [];
  let match;
  
  // Find all matches and return the full match (digit + token)
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]); // This includes the digit and token
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
  // no whitespace, no immediate repeated sequences (e.g., abab should fail)
  
  if (!value) {
    return false;
  }
  
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 123123, etc.)
  // This regex looks for any 2-character sequence that repeats immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
  
  if (!value) {
    return false;
  }
  
  // First, ensure this is not an IPv4 address to avoid false positives
  const ipv4Pattern = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Check if this is specifically an IPv4 address format
    const cleanValue = value.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g);
    if (cleanValue) {
      for (const ip of cleanValue) {
        const parts = ip.split('.');
        if (parts.length === 4 && parts.every(part => {
          const num = parseInt(part);
          return num >= 0 && num <= 255;
        })) {
          return false; // This is an IPv4 address, not IPv6
        }
      }
    }
  }
  
  // IPv6 pattern matching
  // This pattern covers:
  // - Standard 8 groups of 4 hex digits: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed zeros with ::: 2001:db8::8a2e:370:7334
  // - Various hexadecimal characters (case insensitive)
  // - Leading zeros are allowed but not required
  
  const ipv6Pattern = new RegExp(
    // Option 1: Standard IPv6 format with 8 groups
    '\\b(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}\\b|' +
    // Option 2: IPv6 with :: (compressed zeros)
    '\\b(?:[A-Fa-f0-9]{1,4}:){0,7}:[A-Fa-f0-9]{0,4}\\b|' +
    // Option 3: Start with :: 
    '\\b::[A-Fa-f0-9]{0,4}(?::[A-Fa-f0-9]{1,4}){0,7}\\b|' +
    // Option 4: End with ::
    '\\b(?:[A-Fa-f0-9]{1,4}:){0,7}::\\b|' +
    // Option 5: Middle compression (partial)
    '\\b(?:[A-Fa-f0-9]{1,4}:)+(?::[A-Fa-f0-9]{1,4}){1,7}\\b',
    'gi'
  );
  
  return ipv6Pattern.test(value);
}
