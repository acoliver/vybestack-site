export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Accept typical addresses like name@tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const domainMatch = value.match(/@(.+)$/);
  if (domainMatch && domainMatch[1].includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Remove all non-digit characters except the leading +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  const hasPlusOne = cleanValue.startsWith('+1');
  const phoneDigits = hasPlusOne ? cleanValue.substring(2) : cleanValue;
  
  // Must be 10 digits for US phone (without country code)
  if (phoneDigits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits)
  const areaCode = parseInt(phoneDigits.substring(0, 3));
  
  // Area codes cannot start with 0 or 1
  if (phoneDigits.charAt(0) === '0' || phoneDigits.charAt(0) === '1') {
    return false;
  }
  
  // Also check the first digit of area code specifically
  if (areaCode < 200) {
    return false;
  }
  
  // Check for valid format pattern (allowing common separators)
  const usPhoneRegex = /^(?:\+1[\s.-]?)?\(?([2-9][0-8][0-9])\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  
  // Remove all separators and punctuation, keep digits, +, 0
  const cleanValue = value.replace(/[^\d+0]/g, '');
  
  let index = 0;
  
  // Check for optional country code +54
  let hasCountryCode = false;
  if (cleanValue.startsWith('+54')) {
    hasCountryCode = true;
    index = 3;
  }
  
  // Check for optional mobile indicator 9
  if (cleanValue.charAt(index) === '9') {
    index++;
  }
  
  // Check for optional trunk prefix 0 immediately before area code
  let hasTrunkPrefix = false;
  if (cleanValue.charAt(index) === '0') {
    hasTrunkPrefix = true;
    index++;
  }
  
  // When country code is omitted, must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Extract area code (next 2-4 digits, leading digit 1-9)
  const areaCodeMatch = cleanValue.substring(index).match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  index += areaCode.length;
  
  // Extract remaining subscriber number
  const remainingDigits = cleanValue.substring(index).match(/^(\d{6,8})$/);
  if (!remainingDigits) {
    return false;
  }
  
  const subscriberNumber = remainingDigits[1];
  
  // Total subscriber number (after area code) must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  
  if (!value || value.length === 0) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject if contains symbols except apostrophes and hyphens
  // Use a more compatible regex pattern without Unicode escapes
  if (/[^A-Za-zÀ-ÿÿ\s'-]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[A-Za-zÀ-ÿ]/.test(value)) {
    return false;
  }
  
  // Reject obviously fake names like "X Æ A-12"
  if (/^[^\s]*[Ææ][^\s]*$/.test(value)) {
    return false;
  }
  
  // Basic pattern check - should start with a letter
  const nameRegex = /^[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s'-]*[A-Za-zÀ-ÿ]$/;
  return nameRegex.test(value.trim());
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
  
  // Remove all non-digits
  const cleanValue = value.replace(/\D/g, '');
  
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check for valid card prefixes
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cleanValue)) {
    if (cleanValue.length !== 13 && cleanValue.length !== 16 && cleanValue.length !== 19) {
      return false;
    }
  }
  // Mastercard: starts with 51-55, length 16
  else if (/^5[1-5]/.test(cleanValue)) {
    if (cleanValue.length !== 16) {
      return false;
    }
  }
  // American Express: starts with 34 or 37, length 15
  else if (/^3[47]/.test(cleanValue)) {
    if (cleanValue.length !== 15) {
      return false;
    }
  }
  else {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
