// Observer management system for tracking and notifying reactive dependencies

let activeObserver: any = null
const observers: Set<any> = new Set()

export function getActiveObserver(): any {
  return activeObserver
}

export function setActiveObserver(observer: any): void {
  activeObserver = observer
}

export function registerObserver(observer: any): void {
  observers.add(observer)
}

export function unregisterObserver(observer: void): void {
  observers.delete(observer)
}

export function notifyObservers(): void {
  observers.forEach((observer) => {
    observer.update()
  })
}

export function clearObservers(): void {
  observers.clear()
}