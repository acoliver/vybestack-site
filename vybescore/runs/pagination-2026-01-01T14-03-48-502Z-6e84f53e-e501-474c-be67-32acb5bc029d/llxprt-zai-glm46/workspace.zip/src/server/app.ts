import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    function validateNumber(param: string | undefined, paramName: string): number | undefined {
      if (param === undefined) {
        return undefined;
      }

      if (param === '') {
        return undefined;
      }

      const num = Number(param);

      if (isNaN(num)) {
        res.status(400).json({ error: `Invalid ${paramName}: must be a number` });
        return undefined;
      }

      if (!Number.isInteger(num)) {
        res.status(400).json({ error: `Invalid ${paramName}: must be an integer` });
        return undefined;
      }

      if (num <= 0) {
        res.status(400).json({ error: `Invalid ${paramName}: must be greater than 0` });
        return undefined;
      }

      if (num > 1000) {
        res.status(400).json({ error: `Invalid ${paramName}: must not exceed 1000` });
        return undefined;
      }

      return num;
    }

    const page = validateNumber(pageParam, 'page');
    if (page === undefined && pageParam !== undefined) {
      return;
    }

    const limit = validateNumber(limitParam, 'limit');
    if (limit === undefined && limitParam !== undefined) {
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
