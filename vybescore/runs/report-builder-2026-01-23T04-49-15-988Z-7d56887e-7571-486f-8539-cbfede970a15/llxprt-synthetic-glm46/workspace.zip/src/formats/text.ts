import type { ReportData, RenderOptions, RenderFunction } from '../types.js';

export const renderText: RenderFunction['render'] = (
  data: ReportData,
  options: RenderOptions,
): string => {
  const { title, summary, entries } = data;

  const lines: string[] = [title, '', summary, '', 'Entries:', ''];

  for (const entry of entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }

  if (options.includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(``);
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
};