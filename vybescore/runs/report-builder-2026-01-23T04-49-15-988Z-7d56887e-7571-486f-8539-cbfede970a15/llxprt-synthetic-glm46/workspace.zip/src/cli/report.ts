#!/usr/bin/env node

import { promises as fs } from 'node:fs';
import type { CLIParsedArgs, FormatType } from '../types.js';
import { parseArgs } from '../utils/parseArgs.js';
import { validateReportData } from '../utils/validateData.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<FormatType, (data: unknown, options: { includeTotals: boolean }) => string> = {
  markdown: renderMarkdown as (data: unknown, options: { includeTotals: boolean }) => string,
  text: renderText as (data: unknown, options: { includeTotals: boolean }) => string,
};

async function loadJsonFile(path: string): Promise<unknown> {
  try {
    const content = await fs.readFile(path, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${path}`);
    }
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${path}`);
    }
    throw error;
  }
}

async function run(): Promise<void> {
  try {
    const parsedArgs: CLIParsedArgs = parseArgs(process.argv.slice(2));
    const data = await loadJsonFile(parsedArgs.inputPath);
    const validatedData = validateReportData(data);
    const formatter = formatters[parsedArgs.format];
    
    const rendered = formatter(validatedData, {
      includeTotals: parsedArgs.includeTotals,
    });

    if (parsedArgs.outputPath) {
      await fs.writeFile(parsedArgs.outputPath, rendered, 'utf8');
    } else {
      process.stdout.write(rendered);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

run();
