import type { CLIParsedArgs, FormatType } from '../types.js';

function parseFormatType(value: string): FormatType {
  if (value === 'markdown' || value === 'text') {
    return value;
  }
  throw new Error(`Unsupported format: ${value}`);
}

export function parseArgs(args: string[]): CLIParsedArgs {
  const parsedArgs: CLIParsedArgs = {
    inputPath: '',
    format: 'markdown',
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      parsedArgs.format = parseFormatType(args[i]);
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      parsedArgs.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      parsedArgs.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      if (parsedArgs.inputPath) {
        throw new Error('Multiple input files provided');
      }
      parsedArgs.inputPath = arg;
    }
    i++;
  }

  if (!parsedArgs.inputPath) {
    throw new Error('Input file path is required');
  }

  return parsedArgs;
}