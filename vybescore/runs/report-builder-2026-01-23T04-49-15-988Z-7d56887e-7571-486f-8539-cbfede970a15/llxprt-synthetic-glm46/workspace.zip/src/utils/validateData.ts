import type { ReportData } from '../types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field (expected array)');
  }

  const entries = obj.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid label (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid amount (expected number)`);
    }
  }

  return data as ReportData;
}