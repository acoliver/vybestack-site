/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addDependency,
  notify,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    disposed: false,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Register dependency if we're being accessed within a reactive context
    const observer = getActiveObserver()
    if (observer) {
      addDependency(observer, s)
    }
    return s.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all subscribers when value changes
    notify(s)
    return nextValue
  }

  return [read, write]
}
