/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, addDependency } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create observer that tracks dependencies
  const observer: Observer<T> = {
    disposed: false,
    value,
    updateFn: (value?: unknown) => {
      const typedValue = value as T | undefined
      const result = updateFn(typedValue)
      return result as unknown
    },
  }
  
  // Temporarily set this observer as active so it can establish dependencies
  const previousActive = getActiveObserver()
  try {
    // Make this observer active so computed values can register dependencies
    updateObserver(observer)
  } finally {
    // activeObserver will be restored by updateObserver's finally block
  }
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark observer as disposed so it stops receiving updates
    observer.disposed = true
  }
}
