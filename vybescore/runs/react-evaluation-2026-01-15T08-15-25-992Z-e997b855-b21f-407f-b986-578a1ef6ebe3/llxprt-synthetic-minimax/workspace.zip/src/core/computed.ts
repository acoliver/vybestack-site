/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addDependency,
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    disposed: false,
    value: undefined,
    updateFn: (value?: unknown) => {
      const typedValue = value as T | undefined
      const result = updateFn(typedValue)
      return result as unknown
    },
  }
  
  const subject: Subject<T> = {
    name: options?.name,
    disposed: false,
    value: value,
    equalFn: undefined,
  }
  
  const computed: GetterFn<T> = () => {
    // Register dependency if we're being accessed within a reactive context
    const activeObs = getActiveObserver()
    if (activeObs) {
      addDependency(activeObs, subject)
    }
    
    // Run the computation with current dependencies
    updateObserver(observer)
    
    return observer.value as T
  }
  
  return computed
}
