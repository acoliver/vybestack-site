/**
 * Type definitions for the reactive programming system.
 */

export type UpdateFn<T> = (value?: T) => T

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  disposed?: boolean
  updateFn: (value?: unknown) => unknown
  value?: unknown
}

export interface SubjectR {
  name?: string
  disposed?: boolean
  value?: unknown
}

export interface ObserverV<T> {
  value?: T
  updateFn: (value?: unknown) => unknown
}

export interface Observer<T> extends ObserverR {
  value?: T
  updateFn: (value?: unknown) => unknown
}

export interface SubjectV<T> {
  value?: T
  equalFn?: EqualFn<T>
}

export interface Subject<T> extends SubjectR {
  value?: T
  equalFn?: EqualFn<T>
}

// Global reactive state management
let activeObserver: ObserverR | undefined = undefined
const observers = new Map<ObserverR, Set<SubjectR>>()
const subjects = new Map<SubjectR, Set<ObserverR>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue as T
  } finally {
    activeObserver = previous
  }
}

export function addDependency(observer: ObserverR, subject: SubjectR): void {
  // Track observer's dependencies
  if (!observers.has(observer)) {
    observers.set(observer, new Set())
  }
  observers.get(observer)!.add(subject)

  // Track subject's observers
  if (!subjects.has(subject)) {
    subjects.set(subject, new Set())
  }
  subjects.get(subject)!.add(observer)
}

export function removeDependencies(observer: ObserverR): void {
  observer.disposed = true
  
  // Clean up observer from all subjects
  const observerSubjects = observers.get(observer)
  if (observerSubjects) {
    for (const subject of observerSubjects) {
      const subjectObservers = subjects.get(subject)
      if (subjectObservers) {
        subjectObservers.delete(observer)
        if (subjectObservers.size === 0) {
          subjects.delete(subject)
        }
      }
    }
  }
  
  // Clean up observer
  observers.delete(observer)
}

export function notify(subject: SubjectR): void {
  if (subject.disposed) return
  
  const subjectObservers = subjects.get(subject)
  if (subjectObservers) {
    // Create a copy to avoid modification during iteration
    const observersCopy = new Set(subjectObservers)
    for (const observer of observersCopy) {
      if (observer.disposed) continue
      
      try {
        updateObserver(observer as Observer<unknown>)
      } catch (error) {
        console.error('Error updating observer:', error)
      }
    }
  }
}
