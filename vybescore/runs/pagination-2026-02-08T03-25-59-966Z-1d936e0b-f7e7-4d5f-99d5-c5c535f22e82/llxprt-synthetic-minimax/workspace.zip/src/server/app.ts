import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || !Number.isFinite(parsedPage) || parsedPage <= 0 || parsedPage > 1000) {
        return res.status(400).json({ error: 'Invalid page parameter. Page must be a number between 1 and 1000.' });
      }
      page = Math.floor(parsedPage);
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || !Number.isFinite(parsedLimit) || parsedLimit <= 0 || parsedLimit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Limit must be a number between 1 and 100.' });
      }
      limit = Math.floor(parsedLimit);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
