#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  const outputIndex = args.indexOf('--output');
  const includeTotalsIndex = args.indexOf('--includeTotals');

  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1] as 'markdown' | 'text';
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  let outputPath: string | undefined;
  if (outputIndex !== -1 && outputIndex !== args.length - 1) {
    outputPath = args[outputIndex + 1];
  }

  const includeTotals = includeTotalsIndex !== -1;

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    throw new Error('Invalid report data: missing required fields');
  }

  const reportData = data as Record<string, unknown>;

  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string' ||
    !Array.isArray(reportData.entries)
  ) {
    throw new Error('Invalid report data: incorrect field types');
  }

  const entries = reportData.entries;
  for (const entry of entries) {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      !('label' in entry) ||
      !('amount' in entry) ||
      typeof (entry as Record<string, unknown>).label !== 'string' ||
      typeof (entry as Record<string, unknown>).amount !== 'number'
    ) {
      throw new Error('Invalid report data: invalid entry format');
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      console.error(`Error reading or parsing ${args.dataFile}:`);
      if (error instanceof Error) {
        console.error(error.message);
      }
      process.exit(1);
    }

    // Validate data structure
    let reportData: ReportData;
    try {
      reportData = validateReportData(jsonData);
    } catch (error) {
      console.error('Error validating report data:');
      if (error instanceof Error) {
        console.error(error.message);
      }
      process.exit(1);
    }

    // Prepare options
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    // Render report
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
    }

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to ${args.outputPath}:`);
        if (error instanceof Error) {
          console.error(error.message);
        }
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Unexpected error:');
    if (error instanceof Error) {
      console.error(error.message);
    }
    process.exit(1);
  }
}

main();
