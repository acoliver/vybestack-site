import type { FormatRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Registry of available format renderers
 */
export const formatRenderers: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Get a format renderer by name
 */
export function getRenderer(format: string): FormatRenderer {
  const renderer = formatRenderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}

/**
 * Get list of supported formats
 */
export function getSupportedFormats(): string[] {
  return Object.keys(formatRenderers);
}
