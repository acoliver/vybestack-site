import type { ReportData, ReportEntry } from './types.js';
import { readFileSync } from 'node:fs';

/**
 * Validate and parse report data from JSON
 */
export function parseReportData(jsonPath: string): ReportData {
  let content: string;
  try {
    content = readFileSync(jsonPath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${jsonPath}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error('Invalid JSON: Failed to parse input file');
  }

  return validateReportData(data);
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  // Validate title
  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "title" field (expected string)');
  }

  // Validate summary
  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "summary" field (expected string)');
  }

  // Validate entries
  if (!obj.entries || !Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: Missing or invalid "entries" field (expected array)');
  }

  if (obj.entries.length === 0) {
    throw new Error('Invalid report data: "entries" array must not be empty');
  }

  const validatedEntries: ReportEntry[] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];

    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: Entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: Entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (entryObj.amount === undefined || typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: Entry at index ${i} missing or invalid "amount" field (expected number)`);
    }

    validatedEntries.push({
      label: entryObj.label,
      amount: entryObj.amount,
    });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: validatedEntries,
  };
}
