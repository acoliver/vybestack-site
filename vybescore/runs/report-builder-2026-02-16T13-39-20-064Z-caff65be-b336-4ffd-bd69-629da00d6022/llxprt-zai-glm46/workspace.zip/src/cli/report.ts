#!/usr/bin/env node

import { parseReportData } from '../validators.js';
import { getRenderer } from '../formats/index.js';
import { writeFileSync } from 'node:fs';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parse CLI arguments using Node's standard library
 */
function parseArgs(args: string[]): CliArgs {
  const dataPath = args[0];
  if (!dataPath) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let format: string | null = null;
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Main CLI entry point
 */
function main(): void {
  try {
    // Parse command line arguments
    const args = parseArgs(process.argv.slice(2));

    // Validate and parse input data
    const data = parseReportData(args.dataPath);

    // Get appropriate renderer
    const renderer = getRenderer(args.format);

    // Render report
    const output = renderer(data, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

// Execute CLI
main();
