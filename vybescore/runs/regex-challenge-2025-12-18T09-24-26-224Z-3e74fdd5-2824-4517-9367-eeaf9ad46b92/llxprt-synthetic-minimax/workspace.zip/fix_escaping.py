#!/usr/bin/env python3

import re

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the URL pattern - remove unnecessary escaping for forward slashes and brackets
content = content.replace(r"https?:\\\/\\/[^\s<>\"{}|\\^`\[\]]+", r"https?:\/\/[^\s<>\"{}|\\^`[\]]+")

# Fix the rewriteDocsUrls line - remove unnecessary escaping for forward slashes  
content = content.replace(r"http:\\/\\/([^\\/]+)(\\/docs\\/[^\\s]*)", r"http:\/\/([^/]+)(\/docs\/[^\\s]*)")

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print('Fixed escaping issues in transformations.ts')