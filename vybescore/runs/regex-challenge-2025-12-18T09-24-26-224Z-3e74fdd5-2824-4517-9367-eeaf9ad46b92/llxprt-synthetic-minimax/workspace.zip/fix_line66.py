#!/usr/bin/env python3

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the rewriteDocsUrls function - replace escaped forward slashes
old_pattern = r"return text.replace(/http:\\/\\/([^\\/]+)(\\/docs\\/[^\\s]*)/gi, (match, host, path) => {"
new_pattern = "return text.replace(/http:\\/\\/([^/]+)(\\/docs\\/[^\\s]*)/gi, (match, host, path) => {"

content = content.replace(old_pattern, new_pattern)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print('Fixed the escape character issue')