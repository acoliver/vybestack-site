#!/usr/bin/env python3

# Read the file
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the specific problematic line - this is the exact line that's causing the lint error
old_line = 'return text.replace(/http:\\\\/\\\\/([^\\\\/]+)(\\\\/docs\\\\/[^\\\\s]*)/gi, (match, host, path) => {'
new_line = 'return text.replace(/http:\/\/([^\/]+)(\/docs\/[^\s]*)/gi, (match, host, path) => {'

# Replace it
content = content.replace(old_line, new_line)

# Also fix the dynamic hints regex
old_dynamic = 'const dynamicHints = /(\\\\?|&|=|\\\\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;'
new_dynamic = 'const dynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;'

content = content.replace(old_dynamic, new_dynamic)

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed the regex patterns")