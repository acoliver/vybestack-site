export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for valid email addresses
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional checks for double dots, trailing dots, domains with underscores
  if (value.includes('..') || value.endsWith('.') || value.includes('@_.') || value.includes('@.') || value.includes('_@')) {
    return false;
  }
  
  // Check domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to normalize
  const cleaned = value.replace(/\D/g, '');
  
  // Check for optional +1 prefix
  if (cleaned.startsWith('1')) {
    if (cleaned.length !== 11) return false;
    // Check area code (next 3 digits after +1)
    const areaCode = parseInt(cleaned.substring(1, 4));
    if (areaCode <= 100 || areaCode >= 1000) return false;
    return true;
  } else {
    if (cleaned.length !== 10) return false;
    // Check area code (first 3 digits)
    const areaCode = parseInt(cleaned.substring(0, 3));
    if (areaCode <= 100 || areaCode >= 1000) return false;
    return true;
  }
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize by removing spaces and hyphens for easier processing
  const normalized = value.replace(/[\s-]/g, '');
  
  let phonePattern: RegExp;
  
  if (normalized.startsWith('+54')) {
    // Pattern with country code +54
    // +54[9]? XX..(2-4 digits) XXXX(6-8 digits total remaining)
    phonePattern = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
  } else if (normalized.startsWith('0')) {
    // Pattern without country code - must start with 0
    // 0[9]? XX..(2-4 digits) XXXX(6-8 digits total remaining)
    phonePattern = /^0(9)?([1-9]\d{1,3})(\d{6,8})$/;
  } else {
    return false; // Must start with +54 or 0
  }
  
  const match = normalized.match(phonePattern);
  if (!match) return false;
  
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  // Area code must be 2-4 digits (first digit is 1-9, already ensured by regex)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for invalid characters: digits or symbols other than apostrophe, hyphen, space
  if (/[0-9]/.test(value)) return false;
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) return false;
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject strings that start with X Æ A-12 style patterns
  if (/^x\s*[ææa]\s*-?\s*\d+/i.test(value)) return false;
  
  // Must not be empty or only spaces/punctuation
  const cleanValue = value.trim();
  if (cleanValue.length === 0 || /^['\-\s]+$/.test(cleanValue)) return false;
  
  return true;
}

/**
 * Helper function to validate credit card numbers using the Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers using Luhn checksum and card type validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Must be between 13-19 digits for major card types
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check card type and valid prefixes/lengths
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
           cleaned.startsWith('54') || cleaned.startsWith('55') || 
           (cleaned.startsWith('222') && parseInt(cleaned.substring(0, 4)) >= 2221 && parseInt(cleaned.substring(0, 4)) <= 2720)) 
           && cleaned.length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}