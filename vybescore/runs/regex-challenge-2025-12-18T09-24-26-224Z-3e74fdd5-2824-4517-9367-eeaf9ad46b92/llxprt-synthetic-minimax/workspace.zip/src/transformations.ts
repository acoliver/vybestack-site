/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to find sentence boundaries with their punctuation
  const pattern = /([.!?])\s*/g;
  let match;
  let result = '';
  let lastIndex = 0;
  let sentenceNum = 0;

  while ((match = pattern.exec(text)) !== null) {
    const sentence = text.substring(lastIndex, match.index);
    const punctuation = match[1];

    if (sentenceNum === 0) {
      // First sentence - capitalize and add as-is
      result += sentence.charAt(0).toUpperCase() + sentence.slice(1) + punctuation;
    } else {
      // Subsequent sentences - add space, capitalize, then add punctuation
      result += ' ' + sentence.charAt(0).toUpperCase() + sentence.slice(1) + punctuation;
    }

    lastIndex = match.index + match[0].length;
    sentenceNum++;
  }

  // Handle text that doesn't end with punctuation
  if (lastIndex < text.length) {
    const remaining = text.substring(lastIndex);
    if (sentenceNum === 0) {
      result += remaining.charAt(0).toUpperCase() + remaining.slice(1);
    } else {
      result += ' ' + remaining.charAt(0).toUpperCase() + remaining.slice(1);
    }
  }

  return result;
}

/**
 * TODO: Extract all URLs from the given text.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+/gi;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => {
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Replace http:// schemes with https://.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite documentation URLs to use docs subdomain and https.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/docs\/[^\s]*)/gi, (match, host, path) => {
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    const hasDynamicHints = dynamicHints.test(path);
    const containsCgiBin = /cgi-bin/i.test(path);
    
    if (!hasDynamicHints && !containsCgiBin && path.startsWith('/docs/')) {
      // Rewrite host to docs.host and upgrade to https
      return `https://docs.${host}${path}`;
    } else {
      // Just upgrade to https
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract year from mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const pattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(pattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}