/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern for words starting with prefix
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    const lowercaseWord = word.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseWord === exception.toLowerCase()
    );
  });
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that appears after a digit and not at the start
  // Use negative lookbehind to ensure it's not at the start of string
  const pattern = new RegExp(`(?<!^)\\d+${token}`, 'gi');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab"
  // This pattern looks for any sequence of 2+ characters that repeats immediately
  const repeatedPattern = /(..+)\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes shorthand :: and excludes pure IPv4
  // This pattern matches:
  // - Standard 8 groups: [0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:... (8 groups)
  // - Shortened forms with :: for consecutive zeros
  // - IPv4-mapped IPv6 (::ffff:192.168.1.1)
  // - Mixed notation
  
  const ipv6Pattern = /(?<![\w:])(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6}|:)|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?!\d)/;
  
  return ipv6Pattern.test(value);
}