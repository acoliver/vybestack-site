#!/usr/bin/env node

import { readFileSync } from 'fs';
import { parseAndValidateJson } from '../validation.js';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  options: CliOptions;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[++i];
      if (formatValue === 'markdown' || formatValue === 'text') {
        format = formatValue;
      } else {
        console.error(`Error: Unsupported format '${formatValue}'. Supported formats: markdown, text`);
        process.exit(1);
      }
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format parameter is required');
    process.exit(1);
  }

  return {
    dataPath,
    options: { format, output, includeTotals }
  };
}

function main(): void {
  try {
    const { dataPath, options } = parseArgs(process.argv);
    
    // Read and parse JSON file
    const jsonContent = readFileSync(dataPath, 'utf8');
    const reportData: ReportData = parseAndValidateJson(jsonContent);

    // Render based on format
    let output: string;
    
    if (options.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }

    // Output to file or stdout
    if (options.output) {
      import('fs').then(fs => {
        fs.writeFileSync(options.output!, output);
      }).catch(error => {
        console.error(`Error writing output file: ${error instanceof Error ? error.message : 'unknown error'}`);
        process.exit(1);
      });
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'unknown error';
    console.error(message);
    process.exit(1);
  }
}

main();
