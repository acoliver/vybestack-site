import { ReportData, CliOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../validation.js';

export function renderText(data: ReportData, options: CliOptions): string {
  let output = `${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `Entries:\n`;

  // Add entries
  data.entries.forEach(entry => {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  });

  // Add total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    output += `Total: ${formatAmount(total)}\n`;
  }

  return output;
}