import { ReportData } from './types.js';

export function parseAndValidateJson(filePath: string): ReportData {
  try {
    const data = JSON.parse(filePath);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON: malformed JSON input');
    }
    throw new Error(`Failed to parse input: ${error instanceof Error ? error.message : 'unknown error'}`);
  }
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const report = data as Record<string, unknown>;

  // Check required fields
  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  // Validate entries
  const validatedEntries = report.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }

    const typedEntry = entry as Record<string, unknown>;

    if (typeof typedEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "label" field`);
    }

    if (typeof typedEntry.amount !== 'number' || !isFinite(typedEntry.amount)) {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "amount" field`);
    }

    return {
      label: typedEntry.label,
      amount: typedEntry.amount
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries: validatedEntries
  };
}

export function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}