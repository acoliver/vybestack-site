import fs from 'node:fs';
import path from 'node:path';
import { Database } from 'sql.js';
import { FormData } from './types.js';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

// Global database instance
let db: Database = null as unknown as Database;

/**
 * Load database file if it exists, create a new one if it doesn't.
 * Returns a Database instance initialized with the schema.
 */
export async function initializeDatabase(): Promise<Database> {
  try {
    // Load sql.js
    const SQL = await import('sql.js');
    
    // Initialize sql.js
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const initSqlJs = (SQL.default as any).default;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sqlJs = await initSqlJs({ locateFile: () => 'dist/sql-wasm.wasm' });
    
    let dbData: Uint8Array;
    
    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      dbData = fs.readFileSync(DB_PATH);
      db = new sqlJs.Database(dbData);
    } else {
      db = new sqlJs.Database();
      
      // Read and execute schema
      if (fs.existsSync(SCHEMA_PATH)) {
        const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
        db.exec(schema);
      }
    }
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

/**
 * Save the current state of the database to disk.
 */
export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Save database to file
  const dbData = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(dbData));
}

/**
 * Insert form data into the database.
 * Returns the ID of the new row.
 */
export function insertSubmission(formData: FormData): number {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
stmt.free();
 
  const result = db.exec('SELECT last_insert_rowid() as id')[0];
  return result.values[0][0] as number;
}

/**
 * Close the database connection.
 */
export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null as unknown as Database;
  }
}