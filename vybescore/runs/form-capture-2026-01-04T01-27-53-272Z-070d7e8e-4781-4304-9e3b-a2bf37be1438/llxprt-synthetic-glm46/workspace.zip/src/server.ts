import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, saveDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, hasFormErrors, getErrorMessages } from './validation.js';
import { FormData } from './types.js';

// Extended Response type for compatibility
declare module 'express-serve-static-core' {
  interface Response {
    status(code: number): Response;
  }
}

// Setup __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
(async () => {
  try {
    await initializeDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
})();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Error handling middleware
function handleError(err: Error, req: Request, res: Response): void {
  console.error('Error:', err);
  if (res.status) {
    res.status(500).send('Internal Server Error');
  }
}

// Route: GET /
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

// Route: POST /submit
app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (hasFormErrors(errors)) {
    res.status(400).render('form', {
      errors: getErrorMessages(errors),
      values: formData
    });
    return;
  }
  
  // Save to database
  try {
    insertSubmission(formData);
    saveDatabase();
    res.redirect('/thank-you');
  } catch (err) {
    console.error('Failed to save submission:', err);
    res.status(500).render('form', {
      errors: ['Failed to save your submission. Please try again.'],
      values: formData
    });
  }
});

// Route: GET /thank-you
app.get('/thank-you', (req, res) => {
  // We don't have access to the form data after redirect
  // Just render the thank you page with a generic message
  res.render('thank-you', {
    firstName: 'Friend' // Generic fallback
  });
});

// Error handling
app.use(handleError);

// Start server
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Handle graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  server.close(() => {
    closeDatabase();
    console.log('Server closed');
    process.exit(0);
  });
}

// Handle SIGTERM
process.on('SIGTERM', gracefulShutdown);

// Handle SIGINT (Ctrl+C)
process.on('SIGINT', gracefulShutdown);

// Export server for testing
export { app, server };
