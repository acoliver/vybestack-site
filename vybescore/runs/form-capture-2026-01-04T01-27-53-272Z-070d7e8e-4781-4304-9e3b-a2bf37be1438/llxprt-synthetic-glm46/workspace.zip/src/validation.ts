import { FormData, FormErrors } from './types.js';

export function validateForm(formData: FormData): FormErrors {
  const errors: FormErrors = {};
  
  // Required fields validation
  if (!formData.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!formData.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!formData.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.stateProvince.trim()) {
    errors.stateProvince = 'State/Province is required';
  }
  
  if (!formData.postalCode.trim()) {
    errors.postalCode = 'Postal code is required';
  }
  
  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }
  
  // Email validation (simple regex)
  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Please enter a valid email';
  }
  
  // Phone validation
  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+]?[\d\s()-]+$/.test(formData.phone) || formData.phone.trim().length < 7) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return errors;
}

export function hasFormErrors(errors: FormErrors): boolean {
  return Object.keys(errors).length > 0;
}

export function getErrorMessages(errors: FormErrors): string[] {
  return Object.values(errors);
}