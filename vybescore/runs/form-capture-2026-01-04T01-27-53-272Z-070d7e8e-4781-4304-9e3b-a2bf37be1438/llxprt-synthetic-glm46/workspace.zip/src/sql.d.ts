// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare module 'sql.js' {
  export interface Database {
    exec(sql: string): QueryResult[];
    prepare(sql: string): Statement;
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params: unknown[]): unknown;
    free(): void;
  }

  export interface QueryResult {
    columns: string[];
    values: unknown[][];
  }
}

declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    exec(sql: string): QueryResult[];
    prepare(sql: string): Statement;
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  export default {
    Database: typeof Database,
  };
}