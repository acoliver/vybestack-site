import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'page parameter must be a valid number' });
      }
      page = Number(pageParam);
      if (page < 1) {
        return res.status(400).json({ error: 'page parameter must be greater than 0' });
      }
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'limit parameter must be a valid number' });
      }
      limit = Number(limitParam);
      if (limit < 1) {
        return res.status(400).json({ error: 'limit parameter must be greater than 0' });
      }
      if (limit > MAX_LIMIT) {
        return res.status(400).json({ error: `limit parameter cannot exceed ${MAX_LIMIT}` });
      }
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
