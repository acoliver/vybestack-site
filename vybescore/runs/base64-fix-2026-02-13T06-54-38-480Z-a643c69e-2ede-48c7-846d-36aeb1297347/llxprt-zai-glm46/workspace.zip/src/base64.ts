/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  const normalized = normalizeInput(input);

  try {
    const buffer = Buffer.from(normalized, 'base64');
    if (buffer.length === 0 && normalized.length > 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}

/**
 * Normalize Base64 input by adding padding if needed.
 * Base64 strings should be a multiple of 4 characters.
 */
function normalizeInput(input: string): string {
  const trimmed = input.trim();
  const paddingNeeded = (4 - (trimmed.length % 4)) % 4;
  return trimmed + '='.repeat(paddingNeeded);
}

/**
 * Validate that a string is valid Base64.
 * Checks for valid characters and correct padding.
 */
function isValidBase64(input: string): boolean {
  const trimmed = input.trim();

  if (trimmed.length === 0) {
    return true;
  }

  // Check that the string only contains valid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!validBase64Regex.test(trimmed)) {
    return false;
  }

  // Check that padding only appears at the end and is at most 2 characters
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = trimmed.slice(paddingIndex);
    // Padding must be all '=' and at most 2 characters
    if (!/^={1,2}$/.test(paddingPart)) {
      return false;
    }
    // When padding is present, total length must be multiple of 4
    if (trimmed.length % 4 !== 0) {
      return false;
    }
  }

  // Try to decode and check if it produces valid UTF-8
  try {
    const normalized = normalizeInput(trimmed);
    // Attempt to decode - if Buffer.from throws or produces invalid data,
    // the input is not valid base64
    Buffer.from(normalized, 'base64');
    return true;
  } catch (error) {
    return false;
  }
}
