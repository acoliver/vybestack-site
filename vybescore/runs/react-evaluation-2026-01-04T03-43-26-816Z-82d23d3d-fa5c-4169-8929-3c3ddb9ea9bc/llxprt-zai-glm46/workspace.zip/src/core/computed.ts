/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed value
  const observers = new Set<Observer<unknown>>()

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initial computation
  updateObserver(o)

  const getter = (): T => {
    // Register this computed as a dependent if there's an active observer
    const observer = getActiveObserver()
    if (observer) {
      // Track the observer so we can notify it when this computed updates
      observers.add(observer as Observer<unknown>)
    }
    return o.value!
  }

  // Wrap updateObserver to track when this computed is being updated
  // and propagate changes to observers
  const enhancedUpdateFn = (prevValue?: T) => {
    // Mark this computed as active so dependencies can register it
    const previousActive = getActiveObserver()
    setActiveObserver(o)

    try {
      // Compute the new value
      const result = updateFn(prevValue)
      o.value = result

      // After computing new value, notify all observers that depend on this computed
      if (observers.size > 0) {
        for (const obs of observers) {
          updateObserver(obs)
        }
      }

      return result
    } finally {
      setActiveObserver(previousActive)
    }
  }

  // Replace the updateFn with our enhanced version
  o.updateFn = enhancedUpdateFn as UpdateFn<T>

  return getter
}
