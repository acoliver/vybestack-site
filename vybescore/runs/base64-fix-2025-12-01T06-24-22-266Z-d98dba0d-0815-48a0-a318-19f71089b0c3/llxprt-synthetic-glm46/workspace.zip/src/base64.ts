/**
 * Encode plain text to Base64 using the standard Base64 alphabet and correct padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded valid Base64 inputs.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Strip whitespace from input
  const cleanedInput = input.replace(/\s+/g, '');
  
  // Validate that input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleanedInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for invalid padding
  const paddingCount = (cleanedInput.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // Ensure padding is only at the end
  if (cleanedInput.includes('=') && !cleanedInput.match(/={1,2}$/)) {
    throw new Error('Invalid Base64 input: padding is not at the end');
  }
  
  // Ensure proper length for padding (must be multiple of 4 when padded)
  if (paddingCount > 0 && cleanedInput.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect padding length');
  }
  
  // Try to decode, adding padding if needed
  let inputToDecode = cleanedInput;
  if (cleanedInput.length % 4 !== 0) {
    const paddingNeeded = 4 - (cleanedInput.length % 4);
    inputToDecode = cleanedInput + '='.repeat(paddingNeeded);
  }
  
  try {
    return Buffer.from(inputToDecode, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
