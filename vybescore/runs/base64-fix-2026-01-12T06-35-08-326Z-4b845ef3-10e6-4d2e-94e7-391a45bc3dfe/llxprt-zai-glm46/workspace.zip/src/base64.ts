const STANDARD_BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate that a string is a valid Base64 string.
 * Throws an error if the input contains characters outside the Base64 alphabet.
 */
function validateBase64(input: string): void {
  if (!STANDARD_BASE64_PATTERN.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the standard Base64 alphabet');
  }
}

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  validateBase64(trimmed);
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the decoding was successful by verifying the buffer is not empty
    // for non-empty input, or by ensuring the encoded length is valid
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
