import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validateQueryParam(value: string | undefined, paramName: string): number | undefined {
  if (value === undefined) {
    return undefined;
  }
  
  const num = Number(value);
  
  if (isNaN(num)) {
    throw new Error(`${paramName} must be a number`);
  }
  
  if (!Number.isInteger(num)) {
    throw new Error(`${paramName} must be an integer`);
  }
  
  if (num <= 0) {
    throw new Error(`${paramName} must be greater than 0`);
  }
  
  if (paramName === 'limit' && num > 100) {
    throw new Error(`${paramName} must be less than or equal to 100`);
  }
  
  if (paramName === 'page' && num > 10000) {
    throw new Error(`${paramName} must be less than or equal to 10000`);
  }
  
  return num;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const page = validateQueryParam(pageParam, 'page') || 1;
      const limit = validateQueryParam(limitParam, 'limit') || 5;

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
