import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No items found in inventory.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({
  currentPage,
  hasNext,
  onPageChange
}: {
  currentPage: number;
  hasNext: boolean;
  onPageChange: (newPage: number) => void;
}): JSX.Element {
  return (
    <nav aria-label="Inventory pagination">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage <= 1}
        aria-label="Previous page"
        aria-disabled={currentPage <= 1}
      >
        Previous
      </button>
      <span style={{ margin: '0 1rem' }}>
        Page {currentPage}
      </span>
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext}
        aria-label="Next page"
        aria-disabled={!hasNext}
      >
        Next
      </button>
    </nav>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error') {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
      </section>
    );
  }

  if (!data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory data available.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={currentPage}
        hasNext={data.hasNext}
        onPageChange={setCurrentPage}
      />
      <p style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: '#666' }}>
        Showing {data.items.length} of {data.total} items
      </p>
    </section>
  );
}
