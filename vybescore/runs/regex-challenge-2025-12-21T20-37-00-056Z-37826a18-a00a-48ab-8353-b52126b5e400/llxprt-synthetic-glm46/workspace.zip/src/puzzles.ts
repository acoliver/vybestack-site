/**
 * Finds words beginning with a specific prefix while excluding provided exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a case-insensitive pattern for words starting with the prefix
  const wordBoundary = '\\b';
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(wordBoundary + escapedPrefix + '[a-zA-Z]+', 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerCaseExceptions = exceptions.map(e => e.toLowerCase());
  
  // Filter out exceptions and remove duplicates
  const results: Record<string, string> = {}; // Using object as a map to preserve first occurrence
  
  matches.forEach(match => {
    const lowerCaseMatch = match.toLowerCase();
    const isException = lowerCaseExceptions.includes(lowerCaseMatch);
    
    if (!isException && !results[lowerCaseMatch]) {
      // Store the first occurrence of each word (lowercased as key for dedup)
      results[lowerCaseMatch] = match;
    }
  });
  
  // Return only the values (preserving original case of first occurrence)
  return Object.values(results);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to identify valid matches.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern: token preceded by a digit but not at the start of string
  // Since lookbehind isn't supported in all environments, use a different approach
  // First, find all occurrences of the token
  const allMatches = [];
  let index = text.indexOf(token);
  while (index !== -1) {
    allMatches.push(index);
    index = text.indexOf(token, index + 1);
  }
  
  // Filter to only include those preceded by a digit and not at the start
  const result = [];
  for (const matchIndex of allMatches) {
    // Check if not at the start and preceded by a digit
    if (matchIndex > 0 && /\d/.test(text.charAt(matchIndex - 1))) {
      result.push(text.substring(matchIndex - 1, matchIndex + token.length));
    }
  }
  
  return result;
}

/**
 * Validates a password according to specific security requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Basic length requirement: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (aa, abab, abcabc, etc.)
  for (let i = 0; i < value.length - 3; i++) {
    // Check for repeating 2-char patterns (ab, cd, etc.)
    if (value.substring(i, i + 2) === value.substring(i + 2, i + 4)) {
      return false;
    }
  }
  
  // Check for 3-char repeated patterns
  for (let i = 0; i < value.length - 5; i++) {
    if (value.substring(i, i + 3) === value.substring(i + 3, i + 6)) {
      return false;
    }
  }
  
  // Check for 4-char repeated patterns
  for (let i = 0; i < value.length - 7; i++) {
    if (value.substring(i, i + 4) === value.substring(i + 4, i + 8)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) while ensuring IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /\b(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Special patterns for specific IPv6 forms
  const loopbackPattern = /^::1\b/;
  const allZerosPattern = /^::$/;
  const ipv4EmbeddedPattern = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if this is an IPv4 address (not IPv4-embedded)
  if (ipv4Pattern.test(value) && !ipv4EmbeddedPattern.test(value)) {
    return false;
  }
  
  // Check for special IPv6 patterns
  if (loopbackPattern.test(value) || allZerosPattern.test(value) || ipv4EmbeddedPattern.test(value)) {
    return true;
  }
  
  // Check for invalid IPv6 patterns (multiple ::)
  const doubleColonCount = (value.match(/::/g) || []).length;
  if (doubleColonCount > 1) {
    return false;
  }
  
  // Check for too many segments (more than 8 segments without ::)
  if (!value.includes('::')) {
    const segments = value.split(':');
    if (segments.length > 8) {
      return false;
    }
  }
  
  // IPv6 address patterns - we need a comprehensive pattern that covers all IPv6 forms
  const ipv6Pattern = new RegExp(
    [
      '\\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\\b',                                   // standard form
      '\\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4})?\\b',                           // :: at the end
      '\\b:(?:(?:[0-9a-fA-F]{1,4}:){1,7})\\b',                                            // :: at the beginning
      '\\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\\b',                              // :: in the middle (6:1)
      '\\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\\b',                    // :: in the middle (5:1:1, 5:2)
      '\\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\\b',                    // :: in the middle (4:1:1:1, 4:2:1, 4:3)
      '\\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\\b',                    // :: in the middle (3:1:1:1:1, 3:2:1:1, 3:3:1, 3:4)
      '\\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\\b',                    // :: in the middle (2:1:1:1:1:1, 2:2:1:1:1, ... 2:5)
      '\\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\\b',                         // :: in the middle (1:1:1:1:1:1:1, 1:2:1:1:1:1, ... 1:6)
      '\\b:(?:[0-9a-fA-F]{1,4}:){1,7}\\b',                                               // :: in the middle with no start
      '\\b::(?:ffff:(?:\\d{1,3}\\.){3}\\d{1,3})\\b',                                        // IPv4-mapped IPv6 with ::ffff
      '\\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\\d{1,3}\\.){3}\\d{1,3}\\b',                         // IPv4-mapped IPv6 addresses
    ].join('|')
  );
  
  // Then check if it's a valid IPv6 address
  return ipv6Pattern.test(value);
}
