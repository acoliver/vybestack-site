/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * - Capitalizes the first character after sentence-ending punctuation (.?!)
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces appropriately
 * - Attempts to preserve abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, ensure proper spacing between sentences
  let processedText = text.replace(/([.?!])([a-zA-Z])/g, '$1 $2');
  
  // Remove leading/trailing whitespace and collapse multiple spaces to single spaces
  processedText = processedText.trim().replace(/\s+/g, ' ');
  
  // The abbreviation detection is commented out for now but could be implemented future
  // // Common abbreviations to handle (case-insensitive)
  // const abbreviations = ['mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'st', 'ave', 'blvd', 'rd', 'etc', 'e.g', 'i.e'];
  // const abbrevRegex = new RegExp(`\\b(${abbreviations.join('|')})\\.?\\s+[a-z]`, 'gi');
  
  // Find text segments between delimiters including the delimiters
  let result = '';
  let index = 0;
  let sentenceStart = true;
  
  while (index < processedText.length) {
    // Find the next sentence-ending punctuation
    const nextPuncIndex = processedText.substring(index).search(/[.?!]/);
    
    if (nextPuncIndex === -1) {
      // No more punctuation, add the rest of the string
      if (sentenceStart) {
        result += processedText.substring(index).charAt(0).toUpperCase() + 
                  processedText.substring(index).slice(1);
      } else {
        result += processedText.substring(index);
      }
      break;
    }
    
    // Extract the segment up to and including the punctuation
    const segmentEnd = index + nextPuncIndex + 1;
    let segment = processedText.substring(index, segmentEnd);
    
    // Capitalize if this is the start of a sentence
    if (sentenceStart) {
      const leadingWhitespaceMatch = segment.match(/^(\s*)([\S\s]*)$/);
      if (leadingWhitespaceMatch) {
        segment = leadingWhitespaceMatch[1] + 
                  leadingWhitespaceMatch[2].charAt(0).toUpperCase() + 
                  leadingWhitespaceMatch[2].slice(1);
      }
      sentenceStart = false;
    }
    
    result += segment;
    index = segmentEnd;
    
    // Skip any whitespace after the punctuation
    while (index < processedText.length && /\s/.test(processedText[index])) {
      result += processedText[index];
      index++;
    }
    
    // Next segment will be the start of a new sentence
    sentenceStart = true;
  }
  
  return result;
}

/**
 * Extracts URLs from the given text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Pattern breakdown:
  // https?:// - http:// or https:// protocol
  // (?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,} - Domain and subdomains
  // (?:\/[^\s]*)? - Optional path
  const urlPattern = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const urls = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return urls.map(url => {
    // Remove common trailing characters that are likely punctuation
    return url.replace(/[.,;:!?()\s]+$/, '');
  });
}

/**
 * Replaces all http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// globally, but only at the beginning of URLs
  // This matches http:// at the start of a string or after whitespace
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrades the scheme to https://
 * - When the path begins with /docs/, rewrites the host to docs.example.com
 * - Skips the host rewrite for dynamic hints (cgi-bin, query strings, or legacy extensions)
 * - Preserves nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  // Match any http:// or https:// URL for example.com
  return text.replace(/\bhttps?:\/\/example\.com([^\s]*)/g, (match, path) => {
    // Always upgrade to https
    // Check if the path begins with /docs/
    const isDocsPath = /^\/docs\/.*/.test(path);
    
    if (isDocsPath) {
      // Check if the path contains dynamic hints that should skip the host rewrite
      const hasQuery = path.includes('?');
      const hasAmpersand = path.includes('&');
      const hasEquals = path.includes('=');
      const hasCgiBin = path.includes('/cgi-bin');
      const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      const hasDynamicHints = hasQuery || hasAmpersand || hasEquals || hasCgiBin || hasLegacyExtension;
      
      if (hasDynamicHints) {
        // Keep the host as example.com but upgrade to https
        return 'https://example.com' + path;
      } else {
        // Rewrite the host to docs.example.com
        return 'https://docs.example.com' + path;
      }
    } else {
      // Non-docs path: just upgrade to https
      return 'https://example.com' + path;
    }
  });
}

/**
 * Extracts the four-digit year from a date in mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day are impossible.
 */
export function extractYear(value: string): string {
  // Pattern breakdown:
  // ^(0[1-9]|1[0-2]) - Month: 01-12
  // \/(0[1-9]|[12][0-9]|3[01]) - Day: 01-09, 10-29, 30-31
  // \/(\d{4})$ - Year: exactly 4 digits
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  if (!datePattern.test(value)) {
    return 'N/A';
  }
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Additional validation for impossible date combinations
  // Check for February - need to handle leap years correctly
  if (month === 2) {
    // Check if it's a leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    if (isLeapYear && day > 29) {
      return 'N/A';
    }
    if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  }
  
  // Check for months with only 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  return year.toString();
}