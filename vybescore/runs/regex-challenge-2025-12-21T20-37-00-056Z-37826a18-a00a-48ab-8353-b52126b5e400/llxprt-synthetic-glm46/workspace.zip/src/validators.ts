export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address according to common standards.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic regex pattern for email validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject if the format doesn't match the basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domainPart] = value.split('@');
  
  // Reject domains with underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in domain
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject consecutive dots in domain
  if (domainPart.includes('..')) {
    return false;
  }
  
  // Reject consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Valid email
  return true;
}

/**
 * Validates a US phone number supporting common formats and separators.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Note: options parameter is kept for compatibility but not used in current validation
  void options;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Extract area code and check if it starts with 0 or 1 (invalid)
  let areaCode: string;
  if (digitsOnly.length === 11) {
    // If 11 digits, must start with country code 1
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
    // Format: +1 (XXX) XXX-XXXX
    areaCode = digitsOnly.substring(1, 4);
  } else if (digitsOnly.length === 10) {
    // Format: (XXX) XXX-XXXX
    areaCode = digitsOnly.substring(0, 3);
  } else {
    return false;
  }
  
  // Area codes cannot start with 0 or 1
  if (/^[01]/.test(areaCode)) {
    return false;
  }
  
  // Check common patterns with proper formatting
  const usPhonePattern = /^(\+1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return usPhonePattern.test(value);
}

/**
 * Validates an Argentine phone number supporting both landlines and mobiles.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Handles optional country code +54, optional trunk prefix 0, and optional mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check if it starts with country code +54
  const hasCountryCode = normalized.startsWith('+54');
  
  // Check if it starts with trunk prefix 0
  const hasTrunkPrefix = !hasCountryCode && value.startsWith('0');
  
  // Remove country code for further processing if present
  const withoutCountryCode = hasCountryCode ? normalized.substring(3) : normalized;
  
  // Regex pattern for Argentine phone numbers
  // Pattern breakdown:
  // ^(?:0)? - Optional trunk prefix 0 (only if no country code)
  // (?:9)? - Optional mobile indicator 9
  // ([1-9]\d{1,3}) - Area code (2-4 digits, starting with 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhonePattern = hasCountryCode 
    ? /^(?:9)?([1-9]\d{1,3})(\d{6,8})$/
    : /^0(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhonePattern.test(withoutCountryCode)) {
    return false;
  }
  
  const match = withoutCountryCode.match(argentinePhonePattern);
  if (!match) {
    return false;
  }
  
  // Area code validation: must be 2-4 digits (already enforced by regex pattern)
  // Leading digit must be 1-9 (already enforced by regex pattern)
  
  // Subscriber number validation: must be 6-8 digits (already enforced by regex pattern)
  
  // If country code is omitted, must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Don't allow both country code and trunk prefix
  if (hasCountryCode && withoutCountryCode.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates a personal name allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and overly stylized names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Pattern breakdown:
  // ^[a-zA-Z\u00C0-\u024F] - Start with a letter (including extended latin unicode for accents)
  // [a-zA-Z\u00C0-\u024F\s'\-]*$ - Followed by letters, spaces, apostrophes, or hyphens
  const namePattern = /^[a-zA-Z\u00C0-\u024F][a-zA-Z\u00C0-\u024F\s'-]*$/;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with symbols (except apostrophes and hyphens)
  const symbolsPattern = /[!"#$%&()*+,./:;<=>?@[\]^_`{|}~]/;
  if (symbolsPattern.test(value)) {
    return false;
  }
  
  // Reject overly stylized names with multiple special characters or unusual symbols
  // Filter out names like "X Æ A-12" with unusual characters
  if (/[Æ®©™]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates a credit card number based on format and Luhn checksum.
 * Accepts Visa, Mastercard, and American Express numbers with correct prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check length and prefix patterns for different card types
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starting with 4
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[5-9]\d{3})\d{12}$/; // 16 digits
  const amexPattern = /^3[47]\d{13}$/; // 15 digits, starting with 34 or 37
  
  if (!visaPattern.test(digitsOnly) && 
      !mastercardPattern.test(digitsOnly) && 
      !amexPattern.test(digitsOnly)) {
    return false;
  }
  
  // Luhn algorithm check
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform the Luhn checksum algorithm.
 */
function runLuhnCheck(number: string): boolean {
  const digits = number.split('').map(d => parseInt(d, 10));
  
  // Double every second digit from the right
  for (let i = digits.length - 2; i >= 0; i -= 2) {
    let doubled = digits[i] * 2;
    if (doubled > 9) {
      doubled = doubled - 9;
    }
    digits[i] = doubled;
  }
  
  // Sum all digits
  const sum = digits.reduce((acc, digit) => acc + digit, 0);
  
  // Valid if divisible by 10
  return sum % 10 === 0;
}
