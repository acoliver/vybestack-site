declare module 'sql.js' {
  function initSqlJs(config?: Record<string, unknown>): Promise<unknown>;
  export default initSqlJs;
}