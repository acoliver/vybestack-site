import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

// Setup ES module __dirname equivalent
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  data?: FormData;
}

class FormServer {
  private app: express.Application;
  private db: unknown;
  private SQL: unknown;
  private dbPath: string;
  private server: unknown;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Body parsing middleware
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());

    // Serve static files from public directory
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));

    // Set view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
      });
      this.SQL = SQL as { Database: new (data?: Uint8Array) => unknown };

      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        this.db = new (this.SQL as { Database: new (data?: Uint8Array) => unknown }).Database(fileBuffer);
      } else {
        this.db = new (this.SQL as { Database: new (data?: Uint8Array) => unknown }).Database();
        await this.createTables();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    (this.db as { run: (sql: string) => void }).run(schema);
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    try {
      const data = (this.db as { export: () => Uint8Array }).export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateForm(body: Record<string, string>): ValidationResult {
    const errors: string[] = [];
    const data: Partial<FormData> = {};

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city',
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = body[field]?.trim();
      if (!value) {
        errors.push(`${this.getFieldLabel(field)} is required`);
      } else {
        data[field] = value;
      }
    }

    // Email validation
    if (data.email && !this.isValidEmail(data.email)) {
      errors.push('Please enter a valid email address');
    }

    // Phone validation
    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.push('Please enter a valid phone number');
    }

    // Postal code validation
    if (data.postalCode && !this.isValidPostalCode(data.postalCode)) {
      errors.push('Please enter a valid postal code');
    }

    return {
      isValid: errors.length === 0,
      errors,
      data: data as FormData
    };
  }

  private getFieldLabel(field: keyof FormData): string {
    const labels: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field];
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    // Accept international formats: digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^[+]?[\d\s()-]+$/;
    return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
  }

  private isValidPostalCode(postalCode: string): boolean {
    // Accept alphanumeric postal codes (UK, Argentine, etc.)
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode.trim());
  }

  private setupRoutes(): void {
    // GET / - Display form
    this.app.get('/', (_req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Process form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const validation = this.validateForm(req.body);

      if (!validation.isValid) {
        return res.status(400).render('form', {
          errors: validation.errors,
          values: req.body
        });
      }

      try {
        // Insert into database
        if (!this.db) throw new Error('Database not initialized');

        const stmt = (this.db as { prepare: (sql: string) => unknown }).prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city,
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        (stmt as { run: (...params: unknown[]) => void }).run([
          validation.data!.firstName,
          validation.data!.lastName,
          validation.data!.streetAddress,
          validation.data!.city,
          validation.data!.stateProvince,
          validation.data!.postalCode,
          validation.data!.country,
          validation.data!.email,
          validation.data!.phone
        ]);

        (stmt as { free: () => void }).free();
        await this.saveDatabase();

        // Redirect to thank you page
        res.redirect(`/thank-you?firstName=${encodeURIComponent(validation.data!.firstName)}`);
      } catch (error) {
        console.error('Failed to save submission:', error);
        res.status(500).render('form', {
          errors: ['Failed to save your submission. Please try again.'],
          values: req.body
        });
      }
    });

    // GET /thank-you - Display thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(port: number = 3000): Promise<void> {
    await this.initializeDatabase();
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  // Expose the Express app for testing
  public get expressApp(): express.Application {
    return this.app;
  }

  public async stop(): Promise<void> {
    if (this.server) {
      return new Promise<void>((resolve) => {
        (this.server as { close: (callback: () => void) => void }).close(() => {
          console.log('Server closed');
          if (this.db) {
            (this.db as { close: () => void }).close();
          }
          resolve();
        });
      });
    }
  }
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  const port = parseInt(process.env.PORT || '3000', 10);

  // Graceful shutdown handling
  const shutdown = async (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    await server.stop();
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  server.start(port).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default FormServer;