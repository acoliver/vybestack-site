import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import FormServer from '../../src/server.js';

let server: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start server on a different port for testing
  server = new FormServer();
  await server.start(3001);
  
  // Get the express app for testing
  app = server.expressApp;
});

afterAll(async () => {
  if (server) {
    await server.stop();
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check form has correct action and method
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check submit button
    expect($('.submit')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const testSubmission = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(testSubmission);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=John/);
    
    // Follow redirect
    const thankYouResponse = await request(app)
      .get(response.headers.location);
    
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John!');
    
    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify database contains our submission
    const initSqlJs = await import('sql.js');
    const SQL = await initSqlJs.default();
    const dbBuffer = fs.readFileSync(dbPath);
    const db = new SQL.Database(dbBuffer);
    
    const stmt = db.prepare('SELECT * FROM submissions ORDER BY id DESC LIMIT 1');
    const result = stmt.getAsObject([]);
    stmt.free();
    db.close();
    
    expect(result.first_name).toBe('John');
    expect(result.last_name).toBe('Doe');
    expect(result.email).toBe('john.doe@example.com');
    expect(result.country).toBe('Argentina');
  });

  it('validates required fields and shows errors', async () => {
    const invalidSubmission = {
      firstName: '',
      lastName: '',
      email: 'invalid-email',
      phone: '123' // too short
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidSubmission);
    
    // Should re-render form with errors
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Should have error list
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
    
    // Should maintain entered values
    expect($('#email').val()).toBe('invalid-email');
    expect($('#phone').val()).toBe('123');
  });

  it('accepts international postal codes and phone numbers', async () => {
    const internationalSubmission = {
      firstName: 'Maria',
      lastName: 'Garcia',
      streetAddress: 'Buckingham Palace',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA', // UK postal code
      country: 'United Kingdom',
      email: 'maria@example.com',
      phone: '+44 20 7946 0958' // UK phone number
    };

    const response = await request(app)
      .post('/submit')
      .send(internationalSubmission);
    
    // Should succeed
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=Maria/);
  });
});