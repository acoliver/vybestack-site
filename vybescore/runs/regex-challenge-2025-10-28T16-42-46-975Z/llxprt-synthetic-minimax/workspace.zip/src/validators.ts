export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  if (cleaned.startsWith('+1')) {
    const rest = cleaned.slice(2);
    return /^[2-9]\d{2}[2-9]\d{6}$/.test(rest);
  }
  
  // Check for 10 digits without country code
  if (/^\d{10}$/.test(cleaned)) {
    // Area code (first 3 digits) cannot start with 0 or 1
    const areaCode = cleaned.slice(0, 3);
    return /^[2-9]/.test(areaCode);
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space/hyphen characters first
  const cleaned = value.replace(/[^\d\s-]/g, '');
  
  // Remove spaces and hyphens to get just digits
  const digits = cleaned.replace(/[\s-]/g, '');
  
  // Check if it starts with +54
  let remaining = digits;
  if (remaining.startsWith('54')) {
    remaining = remaining.slice(2);
  }
  
  // Pattern for Argentine phone numbers
  // Optional mobile indicator '9' after country code but before area code
  // Trunk prefix '0' before area code (required if no country code)
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits total
  const argentinaPhoneRegex = /^(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = remaining.match(argentinaPhoneRegex);
  if (!match) {
    // If no match and no country code, check if it starts with 0 (trunk prefix)
    if (digits.startsWith('0')) {
      const withoutTrunk = digits.slice(1);
      return argentinaPhoneRegex.test(withoutTrunk);
    }
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  const totalDigits = areaCode.length + subscriber.length;
  
  // Validate total length: area code (2-4) + subscriber (6-8) = 8-12 total
  return totalDigits >= 8 && totalDigits <= 12;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols
  // Pattern: starts with letter, contains letters/spaces/apostrophes/hyphens, no digits
  const nameRegex = /^[\p{L}]([\p{L}\p{M}\s'\-]*[\p{L}\p{M}])?$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Explicitly reject if contains any digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject "X Æ A-12" style names with special symbols
  if (/[^\p{L}\p{M}\s'\-]/u.test(value)) {
    return false;
  }
  
  return value.length >= 1 && value.length <= 100;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card type and length
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cleaned)) {
    if (!/^(13|16|19)$/.test(cleaned.length.toString())) {
      return false;
    }
  }
  // Mastercard: starts with 5[1-5] or 2[2-7], length 16
  else if (/^(5[1-5]|2[2-7])/.test(cleaned)) {
    if (cleaned.length !== 16) {
      return false;
    }
  }
  // American Express: starts with 34 or 37, length 15
  else if (/^(34|37)/.test(cleaned)) {
    if (cleaned.length !== 15) {
      return false;
    }
  }
  // If no known prefix but valid length, still check Luhn
  else {
    if (!/^(13|14|15|16|17|18|19)$/.test(cleaned.length.toString())) {
      return false;
    }
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum algorithm
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
