#!/usr/bin/env node
import { writeFileSync } from 'node:fs';
import { loadAndValidateReportData } from '../validator.js';
import { formatRenderers, supportedFormats } from '../formats/index.js';
import type { Format, RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 1) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (supportedFormats.includes(formatValue as Format)) {
        format = formatValue as Format;
      } else {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  return { dataFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const data = loadAndValidateReportData(args.dataFile);

    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const renderer = formatRenderers[args.format];
    const output = renderer(data, options);

    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('Error: An unknown error occurred');
      process.exit(1);
    }
  }
}

main();
