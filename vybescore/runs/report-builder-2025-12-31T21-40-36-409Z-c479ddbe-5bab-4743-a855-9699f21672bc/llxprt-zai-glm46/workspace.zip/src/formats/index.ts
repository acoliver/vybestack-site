import type { Format, Renderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatRenderers: Record<Format, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats: Format[] = ['markdown', 'text'];
