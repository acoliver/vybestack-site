import type { ReportData, RenderOptions, Renderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: Renderer = (data: ReportData, options: RenderOptions): string => {
  const lines: string[] = [];

  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};
