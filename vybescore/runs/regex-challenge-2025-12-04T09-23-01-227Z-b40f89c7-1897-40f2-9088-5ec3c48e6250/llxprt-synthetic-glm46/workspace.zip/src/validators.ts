export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive regex.
 * Accepts typical addresses like name+tag@example.co.uk, rejects invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that accepts most valid forms while rejecting common invalid patterns
  // eslint-disable-next-line no-useless-escape
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific rejection patterns
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject trailing dots in local or domain part
  if (value.endsWith('.')) return false;
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  
  // Reject consecutive special characters
  if (/[@.]{2,}/.test(value)) return false;
  
  // Accept typical addresses such as name+tag@example.co.uk
  return true;
}

/**
 * Validates US phone numbers with multiple format support.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check if it starts with country code 1 (optional)
  const phoneNumber = digits.startsWith('1') ? digits.substring(1) : digits;
  
  // Valid US phone numbers should have exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format with regex to ensure proper structure
  const phoneRegex = /^(\+1[-.\s]?)?(\([2-9]\d{2}\)[-.\s]?|[2-9]\d{2}[-.\s]?)?\d{3}[-.\s]?\d{4}$/;
  if (!phoneRegex.test(value)) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering both mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize by removing all whitespace and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Optional country code +54
  // Optional trunk prefix 0 immediately before area code
  // Optional mobile indicator 9 between country/trunk and area code
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits
  
  const argentinePhoneRegex = /^(\+54)?(0)?([1-9]\d{0,3})(9)?(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(normalized)) return false;
  
  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, trunkPrefix, areaCode, , subscriberNumber] = match;
  
  // When country code is omitted, trunk prefix is required
  if (!countryCode && !trunkPrefix) return false;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unnatural names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Check for empty string
  if (!value || value.trim() === '') return false;
  
  // Name should contain only unicode letters, spaces, apostrophes, and hyphens
  // This regex allows letters from any language, including accented characters
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject consecutive special characters (more than one apostrophe or hyphen in a row)
  if (/[-']{2,}/.test(value)) return false;
  
  // Reject names with numbers or unusual symbols
  // eslint-disable-next-line no-useless-escape
  if (/[0-9@#$%^&*()_+=<>\[{}|/`~]/.test(value)) return false;
  
  // Reject names that are too short (at least one character is valid)
  const cleanName = value.replace(/[-'\s]/g, '');
  if (cleanName.length < 1) return false;
  
  // Reject patterns that look like artificial names (e.g., "X Æ A-12")
  if (/\d/.test(value)) return false;
  
  // Reject names with excessive special characters
  const specialCharCount = (value.match(/[-']/g) || []).length;
  const letterCount = (value.match(/\p{L}/gu) || []).length;
  
  // Special characters shouldn't make up more than 30% of the name
  if (specialCharCount > 0 && letterCount > 0 && (specialCharCount / letterCount) > 0.3) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn checksum and format validation.
 * Accepts Visa, Mastercard, and AmEx prefixes and appropriate lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check basic length requirements (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Luhn checksum validation
  if (!runLuhnCheck(digits)) return false;
  
  // Card format validation for major brands
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[6-9]\d{3})\d{10}))$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3(4|7)\d{13}$/;
  
  return visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}