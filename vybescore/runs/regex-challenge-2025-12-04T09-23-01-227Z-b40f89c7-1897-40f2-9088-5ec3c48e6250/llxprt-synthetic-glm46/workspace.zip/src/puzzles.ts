/**
 * Finds words in text that start with the given prefix, excluding specified exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary regex to find words starting with the prefix
  const prefixRegex = new RegExp(`\\b${escapeRegex(prefix)}\\w*`, 'gi');
  const matches = [...text.matchAll(prefixRegex)];
  
  // Filter out exceptions (case-insensitive)
  return matches
    .map(match => match[0])
    .filter(word => !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    ));
}

/**
 * Escapes special regex characters in a string.
 */
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses positive lookahead to ensure the token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookahead to match token only when preceded by a digit
  // This looks for tokens that immediately follow a digit character
  const tokenRegex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = [...text.matchAll(tokenRegex)];
  return matches.map(match => {
    // Return the digit + token as one match as expected by the test
    const index = match.index || 0;
    // Get the preceding digit
    const precedingChar = text[index - 1];
    return precedingChar + match[0];
  });
}

/**
 * Validates password strength according to security policy.
 * Requires at least 10 chars, uppercase, lowercase, digit, symbol, no whitespace, no immediate repeats.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Require at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Require at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Require at least one digit
  if (!/\d/.test(value)) return false;
  
  // Require at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeating sequences (e.g., abab)
  // This regex looks for any character sequence of 2-4 characters that repeats immediately
  const repeatPattern = /(.{2,4})\1/;
  if (repeatPattern.test(value)) return false;
  
  // Additional check for immediate character repetition (like aaa, bbb)
  const immediateRepeatPattern = /(\w)\1{2,}/;
  if (immediateRepeatPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 * Returns true if the string contains a valid IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regular expression pattern that covers standard IPv6 formats
  // including shorthand notation with :: (zero compression)
  // and excludes IPv4 addresses (e.g., 192.168.1.1)
  
  // First check for IPv4 patterns to exclude them
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Remove IPv4 addresses from the string before checking for IPv6
    value = value.replace(ipv4Pattern, '');
  }
  
  // Simplified IPv6 pattern that handles most common formats
  // Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const fullForm = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Ends with :: (zero compression)
  const endsWithCompressed = /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/;
  
  // IPv4-mapped: ::ffff:192.168.1.1
  const ipv4Mapped = /\b::\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Loopback: ::1
  const loopback = /\b::1\b/;
  
  // Unspecified: ::
  const unspecified = /\b::\b/;
  
  // Single :: in middle
  const singleCompressed = /\b[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}\b/;
  
  // Starts with ::
  const startsWithCompressed = /\b[0-9a-fA-F]{1,4}::\b/;
  
  // Ends with ::
  const endsWithCompressedOnly = /\b::[0-9a-fA-F]{1,4}\b/;
  
  return fullForm.test(value) || 
         endsWithCompressed.test(value) || 
         ipv4Mapped.test(value) || 
         loopback.test(value) || 
         unspecified.test(value) || 
         singleCompressed.test(value) || 
         startsWithCompressed.test(value) || 
         endsWithCompressedOnly.test(value);
}