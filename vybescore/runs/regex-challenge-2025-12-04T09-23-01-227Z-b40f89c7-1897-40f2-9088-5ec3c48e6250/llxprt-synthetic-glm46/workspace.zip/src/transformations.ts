/**
 * Capitalizes the first character of each sentence.
 * Insert exactly one space between sentences and collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure proper punctuation: add space after sentence endings if missing
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Common abbreviations that shouldn't start a new sentence
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Rd', 'Blvd', 'Inc', 'Ltd', 'Co', 'etc', 'e.g', 'i.e'];
  
  // Split text by sentence endings and rebuild with proper capitalization
  // This is simpler than using complex regex with lookbehind which might not be supported
  const sentences = [];
  let start = 0;
  let i = 0;
  
  while (i < result.length) {
    const char = result[i];
    if (char === '.' || char === '!' || char === '?') {
      // Check if this is likely the end of a sentence, not an abbreviation
      let isAbbreviation = false;
      for ( const abbrev of abbreviations ) {
        if (i >= abbrev.length && 
            result.substring(i - abbrev.length, i) === abbrev && 
            char === '.') {
          isAbbreviation = true;
          break;
        }
      }
      
      if (!isAbbreviation) {
        // Add the sentence up to this punctuation
        sentences.push(result.substring(start, i + 1).trim());
        
        // Skip the punctuation and any whitespace
        i++;
        while (i < result.length && result[i] === ' ') i++;
        start = i;
        continue;
      }
    }
    i++;
  }
  
  // Add any remaining text
  if (start < result.length) {
    sentences.push(result.substring(start).trim());
  }
  
  // Capitalize the first letter of each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return '';
    return sentence[0].toUpperCase() + sentence.substring(1);
  });
  
  // Join with single spaces
  const finalResult = capitalizedSentences.join(' ').replace(/\s{2,}/g, ' ');
  
  return finalResult.trim();
}

/**
 * Extracts URLs from the given text without trailing punctuation.
 * Returns an array of URL strings found in the text.
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs with http/https protocol
  const urlRegex = /(https?:\/\/[^\s/$.?#].[^\s]*)/gi;
  
  const matches = [...text.matchAll(urlRegex)];
  
  return matches.map(match => {
    let url = match[0];
    
    // Remove trailing punctuation characters
    // eslint-disable-next-line no-useless-escape
    url = url.replace(/[.,;:!?)}]+$/, '');
    
    return url;
  });
}

/**
 * Replaces http:// URLs with https:// while leaving existing https URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch https:// URLs
  // eslint-disable-next-line no-useless-escape
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs to upgrade scheme to HTTPS and move docs paths to docs subdomain.
 * For URLs like http://example.com/..., upgrades to HTTPS and rewrites docs paths to docs.example.com.
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs with http(s)://example.com format
  // eslint-disable-next-line no-useless-escape
  const urlRegex = /(https?):\/\/([^\/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade to HTTPS
    const newProtocol = 'https';
    let newDomain = domain;
    const newPath = path || '/';
    
    // Check if this is a docs path and doesn't contain excluded patterns
    if (path && path.startsWith('/docs/')) {
      // Check for excluded patterns: cgi-bin, query strings, or legacy extensions
      const excludedPatterns = [
        /\/cgi-bin\//i,
        /[?&=]/,  // Query strings
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i  // Legacy extensions
      ];
      
      const shouldExclude = excludedPatterns.some(pattern => pattern.test(path));
      
      if (!shouldExclude) {
        newDomain = `docs.${domain}`;
      }
    }
    
    return `${newProtocol}://${newDomain}${newPath}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns the four-digit year or 'N/A' if the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and extract year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const year = match[3];
  return year;
}