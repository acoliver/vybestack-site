import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('manual pagination tests', () => {
  it('should handle default pagination correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5); // Default limit 5
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items[0].id).toBe(1); // First item should be ID 1
  });

  it('should handle specific page and limit', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items[0].id).toBe(4); // Fourth item (page 2, limit 3)
  });

  it('should validate page parameter (reject page 0)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('should validate limit parameter (reject limit 101)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('should validate non-numeric page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('should handle last page correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(3);
    expect(response.body.hasNext).toBe(false); // No next page
  });

  it('should return empty items for page beyond total', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    const response = await request(app).get('/inventory?page=4&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.page).toBe(4);
    expect(response.body.hasNext).toBe(false);
  });
});