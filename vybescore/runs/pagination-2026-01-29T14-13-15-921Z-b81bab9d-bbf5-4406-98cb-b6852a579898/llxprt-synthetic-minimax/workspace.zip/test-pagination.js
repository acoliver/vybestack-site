import { createApp } from './dist/server/app.js';
import { createDatabase } from './dist/server/db.js';
import http from 'http';

async function testApi() {
  try {
    console.log('Creating database and app...');
    const db = await createDatabase();
    const app = await createApp(db);
    
    console.log('Testing API endpoints...');
    
    // Test 1: Default pagination
    console.log('\n=== Test 1: Default pagination (page=1, limit=5) ===');
    await makeRequest('/inventory');
    
    // Test 2: Page 2
    console.log('\n=== Test 2: Page 2, limit 3 ===');
    await makeRequest('/inventory?page=2&limit=3');
    
    // Test 3: Invalid page parameter
    console.log('\n=== Test 3: Invalid page parameter (page=0) ===');
    await makeRequest('/inventory?page=0');
    
    // Test 4: Invalid limit parameter
    console.log('\n=== Test 4: Invalid limit parameter (limit=101) ===');
    await makeRequest('/inventory?limit=101');
    
    // Test 5: Last page
    console.log('\n=== Test 5: Last page (page=3, limit=5) ===');
    await makeRequest('/inventory?page=3&limit=5');
    
    // Test 6: Beyond last page
    console.log('\n=== Test 6: Beyond last page (page=4, limit=5) ===');
    await makeRequest('/inventory?page=4&limit=5');
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

async function makeRequest(path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`http://localhost:3333${path}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const response = JSON.parse(data);
          console.log(`Status: ${res.statusCode}`);
          console.log(`Response: ${JSON.stringify(response, null, 2)}`);
          resolve(response);
        } catch (e) {
          console.log(`Status: ${res.statusCode}`);
          console.log(`Response (raw): ${data}`);
          resolve({ raw: data });
        }
      });
    });
    req.on('error', (err) => {
      console.error(`Request failed for ${path}:`, err.message);
      reject(err);
    });
    req.setTimeout(5000, () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
  });
}

testApi();