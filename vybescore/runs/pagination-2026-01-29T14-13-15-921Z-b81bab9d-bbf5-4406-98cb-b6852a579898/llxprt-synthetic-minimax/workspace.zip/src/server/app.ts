import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Default values
    let page = 1;
    let limit = 5;

    // Validation and parsing
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!Number.isInteger(pageNum) || pageNum < 1 || pageNum > 1000000) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer <= 1000000' });
      }
      page = pageNum;
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!Number.isInteger(limitNum) || limitNum < 1 || limitNum > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer <= 100' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
