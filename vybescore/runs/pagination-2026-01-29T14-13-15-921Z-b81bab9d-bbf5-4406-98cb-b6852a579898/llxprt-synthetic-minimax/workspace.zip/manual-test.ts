// Manual API test script to verify pagination functionality
import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from './src/server/app';
import { createDatabase } from './src/server/db';

async function testPagination() {
  console.log('Testing pagination functionality...\n');

  try {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test 1: Default pagination (page 1, limit 5)
    console.log('Test 1: Default pagination (page 1, limit 5)');
    const response1 = await request(app).get('/inventory');
    console.log('Status:', response1.status);
    console.log('Items:', response1.body.items.length);
    console.log('Page:', response1.body.page);
    console.log('Limit:', response1.body.limit);
    console.log('Total:', response1.body.total);
    console.log('Has next:', response1.body.hasNext);
    console.log('First item ID:', response1.body.items[0]?.id);
    console.log('');

    // Test 2: Page 2 with limit 3
    console.log('Test 2: Page 2 with limit 3');
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    console.log('Status:', response2.status);
    console.log('Items:', response2.body.items.length);
    console.log('Page:', response2.body.page);
    console.log('First item ID:', response2.body.items[0]?.id);
    console.log('');

    // Test 3: Last page (page 3, limit 5)
    console.log('Test 3: Last page (page 3, limit 5)');
    const response3 = await request(app).get('/inventory?page=3&limit=5');
    console.log('Status:', response3.status);
    console.log('Items:', response3.body.items.length);
    console.log('Page:', response3.body.page);
    console.log('Has next:', response3.body.hasNext);
    console.log('');

    // Test 4: Invalid page parameter (page 0 - should return 400)
    console.log('Test 4: Invalid page parameter (page 0 - should return 400)');
    const response4 = await request(app).get('/inventory?page=0');
    console.log('Status:', response4.status);
    console.log('Error:', response4.body.error);
    console.log('');

    // Test 5: Invalid limit parameter (limit 101 - should return 400)
    console.log('Test 5: Invalid limit parameter (limit 101 - should return 400)');
    const response5 = await request(app).get('/inventory?limit=101');
    console.log('Status:', response5.status);
    console.log('Error:', response5.body.error);
    console.log('');

    // Test 6: Non-numeric page parameter
    console.log('Test 6: Non-numeric page parameter (page=abc - should return 400)');
    const response6 = await request(app).get('/inventory?page=abc');
    console.log('Status:', response6.status);
    console.log('Error:', response6.body.error);
    console.log('');

    // Test 7: Negative page parameter
    console.log('Test 7: Negative page parameter (page=-1 - should return 400)');
    const response7 = await request(app).get('/inventory?page=-1');
    console.log('Status:', response7.status);
    console.log('Error:', response7.body.error);
    console.log('');

    console.log('All manual tests completed!');

  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();