// Manual API test script to verify pagination functionality
import request from 'supertest';
import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';

async function testPagination() {
  console.log('Testing pagination functionality...\n');

  try {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test 1: Default pagination (page 1, limit 5)
    console.log('Test 1: Default pagination (page 1, limit 5)');
    const response1 = await request(app).get('/inventory');
    console.log('Status:', response1.status);
    console.log('Body:', JSON.stringify(response1.body, null, 2));
    console.log('');

    // Test 2: Specific page and limit
    console.log('Test 2: Specific page and limit (page 2, limit 3)');
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    console.log('Status:', response2.status);
    console.log('Body:', JSON.stringify(response2.body, null, 2));
    console.log('');

    // Test 3: Invalid page parameter (should return 400)
    console.log('Test 3: Invalid page parameter (page 0 - should return 400)');
    const response3 = await request(app).get('/inventory?page=0');
    console.log('Status:', response3.status);
    console.log('Body:', JSON.stringify(response3.body, null, 2));
    console.log('');

    // Test 4: Invalid limit parameter (should return 400)
    console.log('Test 4: Invalid limit parameter (limit 101 - should return 400)');
    const response4 = await request(app).get('/inventory?limit=101');
    console.log('Status:', response4.status);
    console.log('Body:', JSON.stringify(response4.body, null, 2));
    console.log('');

    // Test 5: Non-numeric parameters (should return 400)
    console.log('Test 5: Non-numeric page parameter (page=abc - should return 400)');
    const response5 = await request(app).get('/inventory?page=abc');
    console.log('Status:', response5.status);
    console.log('Body:', JSON.stringify(response5.body, null, 2));
    console.log('');

    console.log('All tests completed successfully!');

  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();