-- Create inventory table
CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sku TEXT NOT NULL UNIQUE,
  price_cents INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Insert 15 inventory items
INSERT INTO inventory (id, name, sku, price_cents) VALUES
(1, 'Wireless Mouse', 'WM-001', 2999),
(2, 'USB Keyboard', 'KB-002', 4599),
(3, 'Monitor Stand', 'MS-003', 8999),
(4, 'HDMI Cable', 'HD-004', 1299),
(5, 'Webcam HD', 'WC-005', 5499),
(6, 'Laptop Stand', 'LS-006', 3999),
(7, 'Headset USB', 'HS-007', 6999),
(8, 'USB Hub 4-Port', 'UH-008', 2499),
(9, 'Desk Lamp LED', 'DL-009', 3499),
(10, 'Ergonomic Mouse Pad', 'MP-010', 1999),
(11, 'Cable Organizer', 'CO-011', 1499),
(12, 'Wireless Charger', 'WC-012', 2799),
(13, 'Portable SSD 1TB', 'SSD-013', 8999),
(14, 'USB-C Hub', 'UH-014', 5999),
(15, 'Blue Light Glasses', 'BG-015', 2499);
