/**
 * Encode plain text to Base64 using the standard RFC 4648 alphabet.
 * Includes proper padding with "=" characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded valid Base64 inputs.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input is proper Base64 format (only allows A-Z, a-z, 0-9, +, /, and padding =)
  if (!BASE64_REGEX.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  // Normalize padding by adding required '=' characters if missing
  const normalized = input.trim();
  let paddedInput = normalized;
  
  // Add padding if needed for proper decoding
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  if (paddingNeeded && !normalized.includes('=')) {
    paddedInput = normalized + '='.repeat(paddingNeeded);
  }

  try {
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Verify the result is valid UTF-8
    if (result.length === 0 && normalized.length > 0) {
      throw new Error('Invalid Base64 input: could not decode to valid UTF-8');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: decoding failed');
  }
}
