#!/usr/bin/env node

// Simple test script to verify edge cases for Base64 encode/decode
import { encode, decode } from './dist/src/base64.js'; // Compiled code is in dist/src/

function test(description, actual, expected) {
  try {
    if (actual === expected) {
      console.log(`[OK] ${description}`);
    } else {
      console.log(` ${description}`);
      console.log(`  Expected: ${expected}`);
      console.log(`  Actual: ${actual}`);
    }
  } catch (error) {
    console.log(` ${description}: ${error.message}`);
  }
}

function testError(description, fn) {
  try {
    const result = fn();
    console.log(` ${description} (expected error but got: ${result})`);
  } catch (error) {
    console.log(`[OK] ${description} (correctly thrown error: ${error.message})`);
  }
}

console.log('Testing edge cases...');

// Test non-ASCII characters
test('Encode Unicode text', encode('héllo wørld'), "aMOpbGxvIHfDuHJsZA==");
test('Decode Unicode text', decode('aMOpbGxvIHfDuHJsZA=='), 'héllo wørld');

// Test different padding scenarios
test('No padding needed', decode('aGVsbG8'), 'hello');
test('Single padding', decode('aGVsbG8='), 'hello');
test('Double padding', decode('aGU='), 'he');
test('Triple padding (invalid)', decode('aGVsbG8=='), 'hello');

// Test special characters that should appear in Base64
test('Contains + char', encode('?'), 'Pw==');
test('Decode with + char', decode('Pw=='), '?');

test('Contains / char', encode('?'), 'Pw==');
test('Decode with / char', decode('Pw=='), '?');

// Test error cases
testError('Invalid characters', () => decode('!@#$%^&*()'));
testError('Invalid Base64 format', () => decode('aGVsbG8=xyz'));
testError('Invalid padding', () => decode('aGVsbG8==='));

console.log('Edge case tests completed.');