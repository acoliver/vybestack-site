import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';

console.log('=== REGEX CHALLENGE VERIFICATION ===\n');

// Test emails
console.log('EMAIL VALIDATION:');
const emails = [
  'user@example.com',
  'name+tag@example.co.uk', 
  'user@@example..com',
  'user@example_.com',
  'user@example.com.',
  'user..name@example.com'
];

emails.forEach(email => {
  console.log(`  ${email.padEnd(25)} -> ${isValidEmail(email)}`);
});

// Test US phones
console.log('\nUS PHONE VALIDATION:');
const usPhones = [
  '(212) 555-7890',
  '212-555-7890', 
  '2125557890',
  '+1 212-555-7890',
  '012-555-7890', // invalid area code (starts with 0)
  '123-555-789',  // too short
  '+2 212-555-7890' // invalid country code
];

usPhones.forEach(phone => {
  console.log(`  ${phone.padEnd(20)} -> ${isValidUSPhone(phone)}`);
});

// Test Argentine phones
console.log('\nARGENTINE PHONE VALIDATION:');
const argPhones = [
  '+54 9 11 1234 5678',
  '011 1234 5678',
  '+54 341 123 4567',
  '0341 4234567',
  '+54 11 1234 5678',  // Buenos Aires mobile
  '011 1234567',      // Buenos Aires landline
  '54 11 1234 5678',  // invalid - missing +
  '11 1234 5678'      // invalid - missing 0 prefix when no country code
];

argPhones.forEach(phone => {
  console.log(`  ${phone.padEnd(25)} -> ${isValidArgentinePhone(phone)}`);
});

// Test names
console.log('\nNAME VALIDATION:');
const names = [
  'Jane Doe',
  'José María',
  "O'Connor",
  'Jean-Luc',
  'X Æ A-12',
  'John123',
  'Mary-Kate',
  '张伟'
];

names.forEach(name => {
  console.log(`  ${name.padEnd(15)} -> ${isValidName(name)}`);
});

// Test credit cards
console.log('\nCREDIT CARD VALIDATION:');
const cards = [
  '4111111111111111', // Visa valid
  '5500000000000004', // Mastercard valid
  '340000000000009',  // AmEx valid
  '4111111111111112', // Visa invalid (Luhn)
  '1234567890123456', // Invalid prefix
  '411111111111'      // Too short
];

cards.forEach(card => {
  console.log(`  ${card.padEnd(20)} -> ${isValidCreditCard(card)}`);
});

console.log('\n=== All verification tests completed ===');