import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';

console.log('=== TRANSFORMATION FUNCTIONS VERIFICATION ===\n');

// Test capitalizeSentences
console.log('CAPITALIZE SENTENCES:');
const texts = [
  'hello world. how are you?i am fine!',
  'this is a test.another sentence here.',
  'no punctuation here just some text',
  'Dr. Smith went home. the end.'
];

texts.forEach(text => {
  console.log(`  Input:  "${text}"`);
  console.log(`  Output: "${capitalizeSentences(text)}"`);
  console.log();
});

// Test extractUrls
console.log('EXTRACT URLS:');
const urlTexts = [
  'Visit https://example.com and http://test.org for info',
  'Check out www.google.com (search) and https://github.com/user/repo.',
  'No URLs here!',
  'Multiple: http://site1.com, https://site2.org/path?query=1, and www.site3.net.'
];

urlTexts.forEach(text => {
  console.log(`  Input:  "${text}"`);
  console.log(`  URLs:   [${extractUrls(text).join(', ')}]`);
  console.log();
});

// Test enforceHttps
console.log('ENFORCE HTTPS:');
const httpsTexts = [
  'Visit http://example.com for info',
  'Secure site: https://secure.com',
  'Mixed: http://insecure.com and https://secure.com',
  'No URLs here'
];

httpsTexts.forEach(text => {
  console.log(`  Input:  "${text}"`);
  console.log(`  Output: "${enforceHttps(text)}"`);
  console.log();
});

// Test rewriteDocsUrls
console.log('REWRITE DOCS URLS:');
const docsTexts = [
  'Check http://example.com/docs/api for documentation',
  'Visit http://example.com/docs for guides',
  'Dynamic: http://example.com/docs/view.php?id=123',
  'Other: http://example.com/about',
  'Mixed: http://example.com/docs/intro and http://example.com/cgi-bin/script'
];

docsTexts.forEach(text => {
  console.log(`  Input:  "${text}"`);
  console.log(`  Output: "${rewriteDocsUrls(text)}"`);
  console.log();
});

// Test extractYear
console.log('EXTRACT YEAR:');
const dateInputs = [
  '12/25/2023',
  '01/01/2024',
  '13/01/2024',    // invalid month
  '02/30/2024',    // invalid day
  '02/29/2024',    // valid leap year
  '02/29/2023',    // invalid (not leap year)
  '12-25-2023',    // wrong format
  'abc/def/ghij'   // invalid
];

dateInputs.forEach(input => {
  console.log(`  Input:  "${input}"`);
  console.log(`  Output: "${extractYear(input)}"`);
  console.log();
});

console.log('=== All transformation verification tests completed ===');