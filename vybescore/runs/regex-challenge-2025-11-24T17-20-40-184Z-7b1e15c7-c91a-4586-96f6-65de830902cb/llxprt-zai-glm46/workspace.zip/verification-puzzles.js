import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== PUZZLE FUNCTIONS VERIFICATION ===\n');

// Test findPrefixedWords
console.log('FIND PREFIXED WORDS:');
const prefixTests = [
  { text: 'The quick brown fox jumps over the lazy dog', prefix: 'qu', exceptions: [] },
  { text: 'Prefix test with preposition and prefixing words', prefix: 'pre', exceptions: ['preposition'] },
  { text: 'Testing words with test and testing and testimony', prefix: 'test', exceptions: ['testing'] }
];

prefixTests.forEach(({text, prefix, exceptions}, index) => {
  console.log(`  Test ${index + 1}:`);
  console.log(`    Text:       "${text}"`);
  console.log(`    Prefix:     "${prefix}"`);
  console.log(`    Exceptions: [${exceptions.join(', ')}]`);
  console.log(`    Found:      [${findPrefixedWords(text, prefix, exceptions).join(', ')}]`);
  console.log();
});

// Test findEmbeddedToken
console.log('FIND EMBEDDED TOKEN:');
const tokenTests = [
  { text: '123abc456abc789', token: 'abc' },
  { text: 'abc123abc456', token: 'abc' }, 
  { text: '123456', token: 'abc' },
  { text: 'start123abcend', token: 'abc' },
  { text: '123123abc123', token: 'abc' }
];

tokenTests.forEach(({text, token}, index) => {
  console.log(`  Test ${index + 1}:`);
  console.log(`    Text:  "${text}"`);
  console.log(`    Token: "${token}"`);
  console.log(`    Found: [${findEmbeddedToken(text, token).join(', ')}]`);
  console.log();
});

// Test isStrongPassword
console.log('STRONG PASSWORD VALIDATION:');
const passwords = [
  'StrongPass123!',
  'weakpass',
  'NoDigits!',
  'NoSymbols123',
  'nouppercase123!',
  'NOLOWERCASE123!',
  'TooShort1!',
  'ValidPassword123!',
  'ababValid123!',
  'abcabcValid123!',
  'RepeatedAAA123!',
  'Contains whitespace 123!',
  'SpecialChars#$%^&*()123Aa'
];

passwords.forEach(password => {
  console.log(`  "${password.padEnd(25)}" -> ${isStrongPassword(password)}`);
});

console.log();

// Test containsIPv6
console.log('IPV6 DETECTION:');
const ipv6Tests = [
  '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
  '2001:db8::8a2e:370:7334',
  '::1',
  'fe80::1',
  '192.168.1.1',
  '10.0.0.1',
  'Here is an IPv6: 2001:db8::1 and IPv4: 192.168.1.1',
  'Just text with no IPs',
  'Invalid IPv6: 2001:db8:::1'
];

ipv6Tests.forEach(ip => {
  console.log(`  "${ip.padEnd(50)}" -> ${containsIPv6(ip)}`);
});

console.log('\n=== All puzzle verification tests completed ===');