/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words with the prefix (case insensitive)
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and duplicates
  return matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index);
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to find token that follows a digit and return the full match including the digit
  const tokenRegex = new RegExp('\\d' + escapedToken, 'g');
  
  return text.match(tokenRegex) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, ababab, etc.)
  // Check for repeated 2-character sequences
  if (/(..).*\1/.test(value)) return false;
  
  // No repeated 3-character sequences
  if (/(...).*\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern including shorthand :: notation
  // This pattern matches valid IPv6 addresses but excludes IPv4
  
  // First, exclude obvious IPv4 addresses
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(value.trim())) {
    return false;
  }
  
  // IPv6 regex pattern (simplified to avoid parsing errors)
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|::/g;
  
  // Look for IPv6 patterns, excluding those that contain IPv4 patterns
  const matches = value.match(ipv6Regex);
  if (!matches) return false;
  
  // Filter out any matches that contain IPv4-like patterns
  return matches.some(match => {
    // Exclude patterns that look like IPv4 addresses embedded
    return !/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(match);
  });
}
