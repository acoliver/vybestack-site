export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject emails with newlines or control characters
  if (/[\r\n\t]/.test(value)) return false;
  
  // Reject emails with spaces (common injection attempts)
  if (/\s/.test(value)) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject trailing dots in local or domain part
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Reject domains with underscores
  if (value.includes('_')) return false;
  
  // Email regex - more restrictive for security
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be either 10 digits (without country code) or 11 digits (with +1)
  if (digits.length === 10) {
    // No country code - check area code
    const areaCode = digits.slice(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    return true;
  } else if (digits.length === 11) {
    // Has country code - must start with 1
    if (digits[0] !== '1') return false;
    const areaCode = digits.slice(1, 4);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Allow single spaces or hyphens as separators, ignore them for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // If no country code, must start with 0 trunk prefix
  if (!normalized.startsWith('+54') && !normalized.startsWith('0')) {
    return false;
  }
  
  // Remove the 0 trunk prefix if present (to check pattern)
  const withoutTrunkPrefix = normalized.startsWith('0') && !normalized.startsWith('+54') 
    ? normalized.substring(1) 
    : normalized;
  
  // Pattern for Argentine phone numbers:
  // Optional +54 country code (already handled above)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(withoutTrunkPrefix)) {
    return false;
  }
  
  const match = withoutTrunkPrefix.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}
  

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and emoji-style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  // Should not contain only special characters
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letterCount === 0) return false;
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits starting with 4
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  // AmEx: 15 digits starting with 34 or 37
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|\d{3,4})\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  return runLuhnCheck(digits);
}

/**
 * Helper: Run Luhn checksum on card number.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    const digit = parseInt(digits[i], 10);
    
    if (isEven) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
