/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence boundaries (.?!), keeping the delimiters
  return text.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    // Add exactly one space between sentences
    return punctuation + ' ' + letter.toUpperCase();
  }).replace(/^[a-z]/, (match) => match.toUpperCase());
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs with http/https protocol or www
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const urlPattern = /(http:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to HTTPS
    const newProtocol = 'https://';
    
    // Check if we should rewrite host (docs path without dynamic elements)
    const hasDocsPath = path.startsWith('/docs/');
    const hasDynamicElements = /[?&=]|\/(cgi-bin|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    if (hasDocsPath && !hasDynamicElements) {
      // Rewrite host to docs.example.com
      return newProtocol + 'docs.' + host + path;
    } else {
      // Just upgrade the protocol
      return newProtocol + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Basic validation for days per month
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Days in each month (index 1-based)
  const daysInMonth = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > daysInMonth[monthNum as keyof typeof daysInMonth]) {
    return 'N/A';
  }
  
  return year;
}
