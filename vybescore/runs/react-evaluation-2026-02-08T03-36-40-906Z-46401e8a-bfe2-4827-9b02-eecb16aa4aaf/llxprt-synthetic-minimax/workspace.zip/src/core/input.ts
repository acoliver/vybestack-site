/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  addDependency,
  notifyDependencies,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Always register dependency if there's an active observer
    const observer = getActiveObserver()
    if (observer) {
      // Type assertion needed since activeObserver has ObserverR type but we need Observer<unknown>
      addDependency(s, observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Only notify if value actually changed
    if (oldValue !== nextValue) {
      notifyDependencies(s)
    }
    
    return s.value
  }

  return [read, write]
}
