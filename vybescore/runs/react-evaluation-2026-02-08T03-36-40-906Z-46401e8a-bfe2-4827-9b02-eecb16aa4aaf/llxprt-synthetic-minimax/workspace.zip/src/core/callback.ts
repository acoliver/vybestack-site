/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Immediately evaluate to register dependencies
  try {
    observer.updateFn(observer.value)
  } catch (error) {
    // Swallow errors during initial setup
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // No-op cleanup for now since we're using the observer pattern
    // The reactive system will handle cleanup through normal GC
  }
}
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the update function to stop future updates
    observer.updateFn = () => value!
  }
}
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the update function to stop future updates
    observer.updateFn = () => value!
  }
}
