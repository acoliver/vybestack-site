/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<unknown>> | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
export let trackingDepth = 0

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  const previousDepth = trackingDepth
  activeObserver = observer
  trackingDepth = previousDepth + 1
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    trackingDepth = previousDepth
  }
}

export function addDependency<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function removeDependency<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (subject.observers) {
    subject.observers.delete(observer)
    if (subject.observers.size === 0) {
      subject.observers = undefined
    }
  }
}

export function notifyDependencies<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  // Create a copy to avoid issues if observers are modified during notification
  const observers = Array.from(subject.observers)
  
  for (const observer of observers) {
    try {
      const o = observer as Observer<unknown>
      // Force re-computation of dependent observers through the observer system
      updateObserver(o)
    } catch (error) {
      // Swallow errors in notifications to prevent breaking the chain
    }
  }
}
