#!/usr/bin/env node

import { createWriteStream, existsSync, readFileSync } from 'node:fs';
import { exit } from 'node:process';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportFormat, CliArgs } from '../types.js';

const VALID_FORMATS: ReportFormat[] = ['markdown', 'text'];

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const dataFile = args[0];
  
  // Parse --format
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    exit(1);
  }

  const formatValue = args[formatIndex + 1] as ReportFormat;
  if (!VALID_FORMATS.includes(formatValue)) {
    console.error(`Error: Unsupported format: ${formatValue}`);
    exit(1);
  }
  const format = formatValue;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse --output
  const outputIndex = args.indexOf('--output');
  if (outputIndex !== -1 && outputIndex + 1 < args.length) {
    outputPath = args[outputIndex + 1];
  }

  // Parse --includeTotals
  if (args.includes('--includeTotals')) {
    includeTotals = true;
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  const entries = obj.entries as unknown[];
  for (const [index, entry] of entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${index} has missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${index} has missing or invalid "amount" field`);
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArguments();

    // Check if data file exists
    if (!existsSync(args.dataFile)) {
      console.error(`Error: File not found: ${args.dataFile}`);
      exit(1);
    }

    // Read and parse JSON file
    let data: ReportData;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf-8');
      const parsedData = JSON.parse(fileContent);
      data = validateReportData(parsedData);
    } catch (error) {
      console.error(`Error parsing JSON file: ${error instanceof Error ? error.message : String(error)}`);
      exit(1);
    }

    // Render report
    let report: string;
    switch (args.format) {
      case 'markdown':
        report = renderMarkdown(data, { includeTotals: args.includeTotals });
        break;
      case 'text':
        report = renderText(data, { includeTotals: args.includeTotals });
        break;
      default:
        console.error(`Unsupported format: ${args.format}`);
        exit(1);
    }

    // Output report
    if (args.outputPath) {
      try {
        const outputStream = createWriteStream(args.outputPath, 'utf-8');
        outputStream.write(report);
        outputStream.end();
      } catch (error) {
        console.error(`Error writing to file: ${error instanceof Error ? error.message : String(error)}`);
        exit(1);
      }
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
