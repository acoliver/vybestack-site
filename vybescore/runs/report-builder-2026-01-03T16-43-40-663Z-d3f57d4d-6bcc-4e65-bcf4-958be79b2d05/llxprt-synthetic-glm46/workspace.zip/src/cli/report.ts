#!/usr/bin/env node

import fs from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { Report, Format, RenderOptions } from '../types.js';

function parseArguments(args: string[]): {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    console.error(
      'Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const dataFile = args[2];
  let outputPath: string | undefined;
  let includeTotals = false;

  // Find --format argument
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required and must specify a format');
    process.exit(1);
  }
  const formatValue = args[formatIndex + 1];
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    console.error(`Error: Unsupported format "${formatValue}"`);
    process.exit(1);
  }
  const format: Format = formatValue as Format;

  // Find --output argument
  const outputIndex = args.findIndex(arg => arg === '--output');
  if (outputIndex !== -1 && outputIndex < args.length - 1) {
    outputPath = args[outputIndex + 1];
  }

  // Check for --includeTotals flag
  if (args.includes('--includeTotals')) {
    includeTotals = true;
  }

  return { dataFile, format, outputPath, includeTotals };
}

function parseJsonFile(filePath: string): Report {
  if (!fs.existsSync(filePath)) {
    console.error(`Error: File "${filePath}" does not exist`);
    process.exit(1);
  }

  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const data: Report = JSON.parse(fileContent);
    
    // Validate the structure
    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Invalid format: missing or invalid "title" field');
      process.exit(1);
    }
    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Invalid format: missing or invalid "summary" field');
      process.exit(1);
    }
    if (!Array.isArray(data.entries)) {
      console.error('Error: Invalid format: "entries" must be an array');
      process.exit(1);
    }
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        console.error('Error: Invalid format: each entry must have a "label" field');
        process.exit(1);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        console.error('Error: Invalid format: each entry must have a numeric "amount" field');
        process.exit(1);
      }
    }
    
    return data;
  } catch (error) {
    console.error(`Error parsing JSON file: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

function getRenderer(format: Format) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const { dataFile, format, outputPath, includeTotals } = parseArguments(args);

  const data = parseJsonFile(dataFile);
  const renderer = getRenderer(format);
  const options: RenderOptions = { includeTotals };
  const output = renderer(data, options);

  if (outputPath) {
    fs.writeFileSync(outputPath, output, 'utf8');
    console.log(`Report written to ${outputPath}`);
  } else {
    console.log(output);
  }
}

main();
