import type { Report, RenderOptions } from '../types.js';

export function renderMarkdown(data: Report, options: RenderOptions): string {
  const lines: string[] = [];
  
  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  data.entries.forEach(entry => {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  });

  if (options.includeTotals) {
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}