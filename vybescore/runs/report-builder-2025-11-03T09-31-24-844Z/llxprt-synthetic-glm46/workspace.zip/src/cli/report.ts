#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { CliOptions, ReportData, ReportRenderer, ReportEntry } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map of format names to renderer functions
const formatRenderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parse command line arguments using Node's standard library
 */
function parseArgs(): CliOptions {
  const args = process.argv.slice(2);
  const options: CliOptions = {
    dataFile: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  // Parse options
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        i++;
        if (i >= args.length) {
          throw new Error('Missing value for --format');
        }
        options.format = args[i];
        break;
      case '--output':
        i++;
        if (i >= args.length) {
          throw new Error('Missing value for --output');
        }
        options.outputPath = args[i];
        break;
      case '--includeTotals':
        options.includeTotals = true;
        break;
      default:
        if (args[i].startsWith('--')) {
          throw new Error(`Unknown option: ${args[i]}`);
        } else if (!options.dataFile) {
          // First non-option argument is the data file
          options.dataFile = args[i];
        } else {
          throw new Error(`Unexpected argument: ${args[i]}`);
        }
    }
  }

  // Validate required arguments
  if (!options.dataFile) {
    throw new Error('Data file path is required');
  }
  if (!options.format) {
    throw new Error('Format is required');
  }

  return options;
}

/**
 * Load and validate JSON data from file
 */
function loadData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, { encoding: 'utf8' });
    const data = JSON.parse(fileContent) as unknown;

    // Validate data structure
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected object');
    }
    const reportData = data as Partial<ReportData>;
    if (!reportData.title || typeof reportData.title !== 'string') {
      throw new Error('Invalid data: missing or invalid title');
    }
    if (!reportData.summary || typeof reportData.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid summary');
    }
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid data: missing or invalid entries array');
    }

    // Validate entries
    reportData.entries.forEach((entry, index) => {
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${index}: expected object`);
      }
      const entryObj = entry as Partial<ReportEntry>;
      if (!entryObj.label || typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid label`);
      }
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid amount`);
      }
    });

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (
      error instanceof Error &&
      (error as NodeJS.ErrnoException).code === 'ENOENT'
    ) {
      throw new Error(`File not found: ${filePath}`);
    }
    if (
      error instanceof Error &&
      (error as NodeJS.ErrnoException).code === 'EACCES'
    ) {
      throw new Error(`Permission denied reading file: ${filePath}`);
    }
    throw error;
  }
}

/**
 * Main CLI function
 */
function main(): void {
  try {
    // Parse command line arguments
    const options = parseArgs();

    // Load data
    const data = loadData(options.dataFile);

    // Get renderer for requested format
    const renderer = formatRenderers[options.format];
    if (!renderer) {
      throw new Error(`Unsupported format: ${options.format}`);
    }

    // Render report
    const report = renderer(data, {
      includeTotals: options.includeTotals,
    });

    // Output report
    if (options.outputPath) {
      writeFileSync(options.outputPath, report);
    } else {
      process.stdout.write(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

// Run the CLI if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}