/**
 * Find words starting with the given prefix but excluding banned exception words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Build regex to match words starting with prefix
  // Word boundary at start to ensure we match whole words
  const pattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));

  return matches
    .map(word => word)
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookbehind to ensure token follows a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use positive lookbehind to match token only when preceded by a digit
  // \d(?=token) - a digit followed by the token
  // Then we capture digit+token together
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must contain at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (like abab, abcabc)
  // Look for patterns of 2+ characters that repeat immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + 2 * len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // First, let's verify it's not an IPv4 address
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Simpler IPv6 detection using multiple patterns
  // Check for colon-separated hex groups with optional ::
  const hasIPv6Format =
    /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}/.test(value) || // Full format
    /([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:*)*/.test(value) || // Compressed with ::
    /^::[0-9a-fA-F]+$/.test(value) || // Starts with ::
    /[0-9a-fA-F]+::$/.test(value); // Ends with ::

  if (!hasIPv6Format) {
    return false;
  }

  // Additional check: must have at least 2 colons for IPv6 (excluding IPv4 mapped addresses)
  const colonCount = (value.match(/:/g) || []).length;
  if (colonCount < 2) {
    return false;
  }

  // Ensure it's not an IPv4-mapped IPv6 address (::ffff:192.168.1.1)
  if (/\d+\.\d+\.\d+\.\d+/.test(value)) {
    return false;
  }

  return hasIPv6Format;
}
