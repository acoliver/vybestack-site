export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper format checking.
 * Accepts standard formats like user@tag@example.co.uk, user@example.com, etc.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic checks that are hard to do in a single regex
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // RFC 5322 compliant email regex
  // Accepts:
  // - Standard format: local@domain
  // - Plus addressing/tagging: user+tag@domain
  // - Quoted local parts with @ and special chars: "user@tag"@domain
  // Local part: alphanumeric plus special chars OR quoted strings
  // Domain: alphanumeric labels separated by dots, no underscores, valid TLD
  // eslint-disable-next-line no-control-regex
  const emailRegex = /^(?:[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?!-)(?:[A-Za-z0-9-]+\.)*[A-Za-z0-9-]+\.[A-Za-z]{2,}$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks
  // Extract domain (everything after the last @ that's not in quotes)
  const lastAt = value.lastIndexOf('@');
  const localPart = value.substring(0, lastAt);
  const domain = value.substring(lastAt + 1);

  // No underscores in domain
  if (domain.includes('_')) return false;

  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;

  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;

  // Check for consecutive dots or dots at start/end of domain parts
  for (const part of domainParts) {
    if (!part.length) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }

  // Check local part doesn't start or end with dot (unless quoted)
  if (!localPart.startsWith('"') && (localPart.startsWith('.') || localPart.endsWith('.'))) {
    return false;
  }

  // Check for consecutive dots in local part (unless quoted)
  if (!localPart.startsWith('"') && localPart.includes('..')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    // If it starts with 1 and is 11 digits, treat 1 as country code
    digits = digits.slice(1);
  }

  // US phone numbers must have exactly 10 digits (without country code)
  if (digits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens for validation, but keep structure in mind
  const normalized = value.replace(/[\s-]/g, '');

  // Extract country code, mobile prefix, area code, and subscriber number
  // Formats to match:
  // +54[9]XXXXXXXX (with country code, optional 9 for mobile)
  // 0[9]XXXXXXXX (without country code, must have 0 trunk prefix, optional 9)

  let hasCountryCode = false;
  let areaCode = '';
  let subscriberNumber = '';

  let workingCopy = normalized;

  // Check for +54 country code
  if (workingCopy.startsWith('+54')) {
    hasCountryCode = true;
    workingCopy = workingCopy.slice(3);
  }

  // If no country code, must have trunk prefix 0
  if (!hasCountryCode) {
    if (workingCopy.startsWith('0')) {
      workingCopy = workingCopy.slice(1);
    } else {
      return false;
    }
  }

  // Check for mobile prefix 9
  if (workingCopy.startsWith('9')) {
    workingCopy = workingCopy.slice(1);
  }

  // Area code is 2-4 digits, leading digit 1-9
  const areaCodeMatch = workingCopy.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }

  areaCode = areaCodeMatch[1];
  subscriberNumber = areaCodeMatch[2];

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // Validate that original format used only allowed separators (spaces or hyphens)
  const separatorsOnly = value.replace(/[\d+]/g, '');
  if (separatorsOnly && !/^[-\s]+$/.test(separatorsOnly)) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }

  // Regex explanation:
  // ^\p{L}+ - starts with one or more unicode letters
  // [\p{L}\s'\-\.]* - followed by zero or more unicode letters, spaces, apostrophes, hyphens, or dots
  // \p{L}$ - ends with a unicode letter
  // u flag enables unicode property escapes
  const nameRegex = /^\p{L}[\p{L}\s'\-._]*\p{L}$/u;

  if (!nameRegex.test(trimmed)) {
    return false;
  }

  // Additional check: ensure at least two letters (for first and last name)
  const letterCount = (trimmed.match(/\p{L}/gu) || []).length;
  if (letterCount < 2) {
    return false;
  }

  return true;
}

/**
 * Helper function to run Luhn checksum on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express.
 * Checks length/prefix and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check length: 13-19 digits for Visa/Mastercard, 15 digits for AmEx
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }

  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7]\d{2})\d{12}$/;
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat =
    (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19) && visaRegex.test(cleaned) ||
    cleaned.length === 16 && mastercardRegex.test(cleaned) ||
    cleaned.length === 15 && amexRegex.test(cleaned);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
