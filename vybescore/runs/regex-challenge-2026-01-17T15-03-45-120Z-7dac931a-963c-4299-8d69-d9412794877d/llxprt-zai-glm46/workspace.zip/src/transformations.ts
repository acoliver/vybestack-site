/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // First, normalize whitespace - collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ');

  // Ensure exactly one space after sentence endings (., !, ?)
  // Look for cases where there's no space after punctuation
  normalized = normalized.replace(/([.!?])([A-Za-z])/g, '$1 $2');

  // Now capitalize first letter of sentences
  // Also capitalize the very first character of the text
  const capitalizeAfter = /(^|[.!?]\s+)([a-z])/g;

  normalized = normalized.replace(capitalizeAfter, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  // Special case: capitalize very first character if lowercase
  if (normalized.length > 0 && /^[a-z]/.test(normalized)) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }

  return normalized;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // Comprehensive URL regex that matches:
  // - http:// or https:// protocol
  // - www. without protocol (common shorthand)
  // - Domain names
  // - Paths, query strings, fragments
  // But excludes trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(?::\d+)?(?:\/[^\s.,!?;:(){}[\]"']*)?[^\s.,!?;:(){}[\]"']?/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation from matches
  return matches.map(url => {
    return url.replace(/[.,!?;:(){}[\]"']+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Pattern to match http://example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if we should skip the host rewrite
    // Skip conditions: cgi-bin, query strings, legacy extensions
    const skipHostRewrite = /\/cgi-bin\/|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))(\/|\?|$)/i.test(path);

    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');

    if (isDocsPath && !skipHostRewrite) {
      // Rewrite host to docs.example.com
      return newProtocol + 'docs.example.com' + path;
    } else {
      // Only upgrade protocol, keep original host
      return newProtocol + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Using 29 for Feb to be lenient
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
