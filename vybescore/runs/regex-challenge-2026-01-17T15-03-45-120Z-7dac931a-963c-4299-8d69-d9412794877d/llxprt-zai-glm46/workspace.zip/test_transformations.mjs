import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

console.log('=== capitalizeSentences ===');
console.log('Input: "hello world. how are you?"');
console.log('Output:', capitalizeSentences('hello world. how are you?'));
console.log('Input: "hello world.how are you?"');
console.log('Output:', capitalizeSentences('hello world.how are you?'));

console.log('\n=== extractUrls ===');
console.log('Input: "Visit http://example.com today"');
console.log('Output:', extractUrls('Visit http://example.com today'));
console.log('Input: "See http://example.com."');
console.log('Output:', extractUrls('See http://example.com.'));

console.log('\n=== enforceHttps ===');
console.log('Input: "http://example.com"');
console.log('Output:', enforceHttps('http://example.com'));
console.log('Input: "https://example.com"');
console.log('Output:', enforceHttps('https://example.com'));

console.log('\n=== rewriteDocsUrls ===');
console.log('Input: "See http://example.com/docs/guide"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/guide'));
console.log('Input: "See http://example.com/docs/api/v1"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/api/v1'));
console.log('Input: "See http://example.com/cgi-bin/script"');
console.log('Output:', rewriteDocsUrls('See http://example.com/cgi-bin/script'));
console.log('Input: "See http://example.com/docs/guide?param=1"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/guide?param=1'));
console.log('Input: "See http://example.com/path/page.jsp"');
console.log('Output:', rewriteDocsUrls('See http://example.com/path/page.jsp'));

console.log('\n=== extractYear ===');
console.log('Input: "01/31/2024"');
console.log('Output:', extractYear('01/31/2024'));
console.log('Input: "13/01/2024"');
console.log('Output:', extractYear('13/01/2024'));
console.log('Input: "01/32/2024"');
console.log('Output:', extractYear('01/32/2024'));
console.log('Input: "not-a-date"');
console.log('Output:', extractYear('not-a-date'));
