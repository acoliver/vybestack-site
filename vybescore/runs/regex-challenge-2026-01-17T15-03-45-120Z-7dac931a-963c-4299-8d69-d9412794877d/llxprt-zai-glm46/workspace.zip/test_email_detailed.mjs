import { isValidEmail } from './dist/src/validators.js';

const testEmails = [
  'user@example.com',
  'user+tag@example.com',
  '"user@tag"@example.co.uk',
  'user.tag@example.co.uk',
  'user@tag@example.co.uk',
  'name+tag@example.co.uk',
  'first.last@example.com',
  '"first.last"@example.com',
];

console.log('Testing email formats:');
testEmails.forEach(email => {
  console.log(`${email.padEnd(35)} : ${isValidEmail(email)}`);
});
