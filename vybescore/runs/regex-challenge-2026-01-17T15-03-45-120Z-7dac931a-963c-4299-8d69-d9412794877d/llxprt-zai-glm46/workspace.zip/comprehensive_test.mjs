import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== COMPREHENSIVE TEST RESULTS ===\n');

// Edge case emails
console.log('Email Edge Cases:');
const edgeEmails = [
  ['user@example.com', true],
  ['user+tag@example.com', true],
  ['"user@tag"@example.co.uk', true],
  ['user@example..com', false],
  ['.user@example.com', false],
  ['user.@example.com', false],
  ['user@example_.com', false],
  ['user@example', false],
  ['@example.com', false],
];
edgeEmails.forEach(([email, expected]) => {
  const result = isValidEmail(email);
  const status = result === expected ? '✓' : '✗';
  console.log(`  ${status} ${email.padEnd(35)} expected: ${expected}, got: ${result}`);
});

// Edge case US phones
console.log('\nUS Phone Edge Cases:');
const edgePhones = [
  ['(212) 555-7890', true],
  ['212-555-7890', true],
  ['2125557890', true],
  ['+1 212-555-7890', true],
  ['012-555-7890', false],
  ['212-555-789', false],
  ['212-155-7890', false],
];
edgePhones.forEach(([phone, expected]) => {
  const result = isValidUSPhone(phone);
  const status = result === expected ? '✓' : '✗';
  console.log(`  ${status} ${phone.padEnd(25)} expected: ${expected}, got: ${result}`);
});

// Edge case Argentine phones
console.log('\nArgentine Phone Edge Cases:');
const argPhones = [
  ['+54 9 11 1234 5678', true],
  ['011 1234 5678', true],
  ['+54 341 123 4567', true],
  ['0341 4234567', true],
  ['54 9 11 1234 5678', false], // Missing +
  ['11 1234 5678', false], // Missing 0 when no country code
];
argPhones.forEach(([phone, expected]) => {
  const result = isValidArgentinePhone(phone);
  const status = result === expected ? '✓' : '✗';
  console.log(`  ${status} ${phone.padEnd(30)} expected: ${expected}, got: ${result}`);
});

// Edge case names
console.log('\nName Edge Cases:');
const edgeNames = [
  ['Jane Doe', true],
  ['José María', true],
  ['O\'Connor', true],
  ['Mary-Jane Watson', true],
  ['X Æ A-12', false],
  ['John123', false],
  ['Test@Name', false],
];
edgeNames.forEach(([name, expected]) => {
  const result = isValidName(name);
  const status = result === expected ? '✓' : '✗';
  console.log(`  ${status} ${name.padEnd(25)} expected: ${expected}, got: ${result}`);
});

// Credit cards
console.log('\nCredit Card Edge Cases:');
const cards = [
  ['4111111111111111', true], // Valid Visa
  ['4111-1111-1111-1111', true], // Valid Visa with dashes
  ['4111111111111112', false], // Fails Luhn
  ['378282246310005', true], // Valid AmEx
  ['5555555555554444', true], // Valid Mastercard
];
cards.forEach(([card, expected]) => {
  const result = isValidCreditCard(card);
  const status = result === expected ? '✓' : '✗';
  console.log(`  ${status} ${card.padEnd(25)} expected: ${expected}, got: ${result}`);
});

// Transformations
console.log('\nTransformation Tests:');
console.log(`  capitalizeSentences: "${capitalizeSentences('hello.how are you?')}"`);
console.log(`  extractUrls: ${JSON.stringify(extractUrls('Visit https://example.com/docs/.'))}`);
console.log(`  rewriteDocsUrls: "${rewriteDocsUrls('See http://example.com/docs/guide')}"`);
console.log(`  extractYear '02/30/2024': "${extractYear('02/30/2024')}"`);

// Puzzles
console.log('\nPuzzle Tests:');
console.log(`  findPrefixedWords: ${JSON.stringify(findPrefixedWords('preview prevent prefix', 'pre', ['prevent']))}`);
console.log(`  findEmbeddedToken: ${JSON.stringify(findEmbeddedToken('xfoo 1foo foo', 'foo'))}`);
console.log(`  isStrongPassword 'Abcabc!123': ${isStrongPassword('Abcabc!123')}`);
console.log(`  containsIPv6 '2001:db8::1': ${containsIPv6('2001:db8::1')}`);
console.log(`  containsIPv6 '192.168.1.1': ${containsIPv6('192.168.1.1')}`);

console.log('\n=== ALL TESTS COMPLETE ===');
