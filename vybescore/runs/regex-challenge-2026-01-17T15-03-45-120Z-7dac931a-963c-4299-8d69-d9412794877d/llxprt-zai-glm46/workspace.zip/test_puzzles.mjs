import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== findPrefixedWords ===');
console.log('Input: "preview prevent prefix", prefix: "pre", exceptions: ["prevent"]');
console.log('Output:', findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));

console.log('\n=== findEmbeddedToken ===');
console.log('Input: "xfoo 1foo foo", token: "foo"');
console.log('Output:', findEmbeddedToken('xfoo 1foo foo', 'foo'));

console.log('\n=== isStrongPassword ===');
const testPasswords = [
  'Abcdef!234',
  'weak',
  'abcdefghij',
  'ABCDEFGHIJ!',
  '1234567890!',
  'Abcdefghij',
  'Abcdef!23',
  'Abc def!234',
  'ababABAB!1',
];
testPasswords.forEach(pwd => {
  console.log(`${pwd.padEnd(20)} : ${isStrongPassword(pwd)}`);
});

console.log('\n=== containsIPv6 ===');
const testAddresses = [
  '2001:db8::1',
  '::1',
  'fe80::1',
  '192.168.1.1',
  '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
  '::ffff:192.168.1.1',
  'not an address',
];
testAddresses.forEach(addr => {
  console.log(`${addr.padEnd(40)} : ${containsIPv6(addr)}`);
});
