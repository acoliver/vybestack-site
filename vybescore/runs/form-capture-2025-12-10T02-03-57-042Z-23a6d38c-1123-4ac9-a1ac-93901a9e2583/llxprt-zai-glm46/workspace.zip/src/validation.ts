import type { FormData, FormErrors } from './types.js';

export function validateFormData(data: FormData): FormErrors {
  const errors: FormErrors = {};

  // First name validation
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.firstName = 'First name is required';
  }

  // Last name validation
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.lastName = 'Last name is required';
  }

  // Street address validation
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.streetAddress = 'Street address is required';
  }

  // City validation
  if (!data.city || data.city.trim().length === 0) {
    errors.city = 'City is required';
  }

  // State/Province validation
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.stateProvince = 'State/Province/Region is required';
  }

// Postal code validation (alphanumeric support)
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.postalCode = 'Postal/Zip code is required';
  } else {
    const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalCodeRegex.test(data.postalCode.trim())) {
      errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and hyphens';
    }
  }

  // Country validation
  if (!data.country || data.country.trim().length === 0) {
    errors.country = 'Country is required';
  }

  // Email validation
  if (!data.email || data.email.trim().length === 0) {
    errors.email = 'Email is required';
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (international formats)
  if (!data.phone || data.phone.trim().length === 0) {
    errors.phone = 'Phone number is required';
} else {
    const phoneRegex = /^\+?[\d\s()-]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +';
    }
  }

  return errors;
}