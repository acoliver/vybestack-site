declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    exec(sql: string): QueryResult[];
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  export interface QueryResult {
    columns: string[];
    values: unknown[][];
  }

  export interface SqlJsStatic {
    Database: { new(data?: Uint8Array): Database };
  }

  export default function initSqlJs(): Promise<SqlJsStatic>;
}

export interface SqlJsDatabase {
  run(sql: string, params?: unknown[]): void;
  prepare(sql: string): SqlJsStatement;
  exec(sql: string): QueryResult[];
  export(): Uint8Array;
  close(): void;
}

export interface SqlJsStatement {
  run(params?: unknown[]): void;
  free(): void;
}

export interface QueryResult {
  columns: string[];
  values: unknown[][];
}