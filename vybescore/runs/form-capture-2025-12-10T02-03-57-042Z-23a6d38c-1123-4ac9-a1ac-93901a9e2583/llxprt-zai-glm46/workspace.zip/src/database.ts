import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';
import type { FormData, DatabaseSubmission } from './types.js';

let db: import('sql.js').Database | null = null;
const DB_PATH = path.resolve('data', 'submissions.sqlite');

export async function initializeDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();
    
    // Check if database file exists
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read and execute schema
      const schemaPath = path.resolve('db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      db.run(schema);
      
      // Save the new database
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export function insertSubmission(formData: FormData): number {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  try {
    stmt.run([
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    ]);
    const results = db.exec('SELECT last_insert_rowid() as id');
    return results[0].values[0][0] as number;
  } finally {
    stmt.free();
  }
}

export function getSubmissions(): DatabaseSubmission[] {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const results = db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
  
  if (results.length === 0) {
    return [];
  }

  const result = results[0];
  const columns = result.columns;
  const values = result.values;

  return values.map((row: unknown[]) => {
    const submission: Partial<DatabaseSubmission> = {};
    columns.forEach((col: string, index: number) => {
      const value = row[index];
      if (value !== undefined && value !== null) {
        submission[col as keyof DatabaseSubmission] = value as never;
      }
    });
    return submission as DatabaseSubmission;
  });
}

export function closeDatabase(): void {
  if (db) {
    try {
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    } finally {
      db = null;
    }
  }
}