const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Empty input is not valid Base64');
  }

  // Add padding if missing
  const paddedInput = addPadding(input);
  
  // Validate the input format
  if (!VALID_BASE64_REGEX.test(paddedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters or format');
  }

  try {
    const buffer = Buffer.from(paddedInput, 'base64');
    
    // Check if the input was actually valid Base64 by verifying buffer length
    const testEncode = buffer.toString('base64');
    const normalizedTest = testEncode.replace(/=+$/, '');
    const normalizedInput = paddedInput.replace(/=+$/, '');
    
    if (normalizedTest !== normalizedInput) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Add padding to Base64 input if it's missing.
 */
function addPadding(input: string): string {
  // Remove any existing padding first
  const withoutPadding = input.replace(/=+$/, '');
  
  // Calculate required padding
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  return withoutPadding + '='.repeat(paddingLength);
}
