import { ReportData, RenderOptions, Formatter } from '../types.js';

export const renderText: Formatter = {
  format(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Each entry as bullet point
    for (const entry of data.entries) {
      const amount = entry.amount.toFixed(2);
      lines.push(`- ${entry.label}: $${amount}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      lines.push('');
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      const totalStr = total.toFixed(2);
      lines.push(`Total: $${totalStr}`);
    }
    
    return lines.join('\n');
  }
};