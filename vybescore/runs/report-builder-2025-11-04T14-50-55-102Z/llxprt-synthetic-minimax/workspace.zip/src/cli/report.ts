import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);

// Validate minimum arguments
if (args.length < 2) {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  process.exit(1);
}

// Extract data file path (first argument)
const dataFile = args[0];

// Parse remaining arguments
let format = '';
let outputPath: string | null = null;
let includeTotals = false;

for (let i = 1; i < args.length; i++) {
  const arg = args[i];
  
  if (arg === '--format' && i + 1 < args.length) {
    format = args[i + 1];
    i++; // Skip next argument as it's the format value
  } else if (arg === '--output' && i + 1 < args.length) {
    outputPath = args[i + 1];
    i++; // Skip next argument as it's the output path
  } else if (arg === '--includeTotals') {
    includeTotals = true;
  }
}

// Validate required arguments
if (!format) {
  console.error('Error: --format parameter is required');
  process.exit(1);
}

if (!['markdown', 'text'].includes(format)) {
  console.error('Unsupported format');
  process.exit(1);
}

// Read and parse JSON data
let data: ReportData;
try {
  const jsonContent = readFileSync(dataFile, 'utf-8');
  data = JSON.parse(jsonContent);
} catch (error) {
  if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
    console.error(`Error: Cannot read file '${dataFile}'`);
  } else {
    console.error('Error: Invalid JSON in input file');
  }
  process.exit(1);
}

// Validate data structure
if (!data.title || typeof data.title !== 'string') {
  console.error('Error: Missing or invalid "title" field in JSON data');
  process.exit(1);
}

if (!data.summary || typeof data.summary !== 'string') {
  console.error('Error: Missing or invalid "summary" field in JSON data');
  process.exit(1);
}

if (!Array.isArray(data.entries)) {
  console.error('Error: Missing or invalid "entries" field in JSON data');
  process.exit(1);
}

// Validate entries
for (let i = 0; i < data.entries.length; i++) {
  const entry = data.entries[i];
  if (!entry.label || typeof entry.label !== 'string') {
    console.error(`Error: Entry ${i} is missing or has invalid "label" field`);
    process.exit(1);
  }
  if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
    console.error(`Error: Entry ${i} is missing or has invalid "amount" field`);
    process.exit(1);
  }
}

// Render report based on format
const renderOptions = { includeTotals };
let output: string;

try {
  if (format === 'markdown') {
    output = renderMarkdown.format(data, renderOptions);
  } else if (format === 'text') {
    output = renderText.format(data, renderOptions);
  } else {
    console.error('Unsupported format');
    process.exit(1);
  }
} catch (error) {
  console.error('Error: Failed to render report');
  process.exit(1);
}

// Write output
try {
  if (outputPath) {
    writeFileSync(outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
} catch (error) {
  if (error instanceof Error && 'code' in error && error.code === 'EACCES') {
    console.error(`Error: Cannot write to file '${outputPath}'`);
  } else {
    console.error('Error: Failed to write output');
  }
  process.exit(1);
}