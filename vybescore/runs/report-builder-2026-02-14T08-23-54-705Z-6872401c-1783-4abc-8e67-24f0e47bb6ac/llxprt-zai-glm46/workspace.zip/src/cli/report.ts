#!/usr/bin/env node
import * as fs from 'fs';
import { formatters } from '../formatters.js';
import { validateReportData } from '../utils/validation.js';
import type { ReportData } from '../types.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): { dataFile: string; options: CliOptions } {
  if (args.length === 0) {
    console.error('Error: Data file path is required');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const options: CliOptions = {
    format: '',
    includeTotals: false,
  };

  // Find data file (first argument that doesn't start with --)
  let dataFile = '';
  const flagArgs: string[] = [];

  for (const arg of args) {
    if (arg.startsWith('--')) {
      flagArgs.push(arg);
    } else if (!dataFile) {
      dataFile = arg;
    } else {
      flagArgs.push(arg);
    }
  }

  if (!dataFile) {
    console.error('Error: Data file path is required');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  // Process flags
  for (let i = 0; i < flagArgs.length; i++) {
    const arg = flagArgs[i];

    if (arg === '--format') {
      const format = flagArgs[++i];
      if (!format) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = format;
    } else if (arg === '--output') {
      const output = flagArgs[++i];
      if (!output) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = output;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { dataFile, options };
}

function readDataFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);

    if (!validateReportData(data)) {
      console.error(`Error: Invalid report data in ${filePath}`);
      console.error('Expected format: { title: string, summary: string, entries: [{ label: string, amount: number }] }');
      process.exit(1);
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${filePath}`);
      console.error(error.message);
      process.exit(1);
    }

    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${filePath}`);
      process.exit(1);
    }

    throw error;
  }
}

function main() {
  const args = process.argv.slice(2);
  const { dataFile, options } = parseArgs(args);

  if (!(options.format in formatters)) {
    console.error(`Error: Unsupported format "${options.format}"`);
    console.error(`Supported formats: ${Object.keys(formatters).join(', ')}`);
    process.exit(1);
  }

  const data = readDataFile(dataFile);
  const formatter = formatters[options.format];
  const output = formatter(data, options);

  if (options.output) {
    fs.writeFileSync(options.output, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();
