import type { FormatRenderer } from '../types.js';
import { formatAmount } from '../utils/formatAmount.js';

export const renderText: FormatRenderer = (data, options) => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);

  // Summary
  lines.push(data.summary);

  // Entries heading
  lines.push('Entries:');

  // Entries
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
