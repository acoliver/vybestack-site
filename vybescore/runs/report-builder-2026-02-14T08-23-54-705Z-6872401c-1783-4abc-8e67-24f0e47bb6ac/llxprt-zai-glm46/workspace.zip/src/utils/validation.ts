import type { ReportData } from '../types.js';

export function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    return false;
  }

  if (typeof obj.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    return false;
  }

  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      return false;
    }
  }

  return true;
}
