/**
 * Capitalizes the first character of each sentence.
 * Handles sentence boundaries (.?!), inserts exactly one space between sentences,
 * collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spaces - collapse multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence endings if missing
  result = result.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Capitalize first character of each sentence
  result = result.replace(/(?:^|[.!?]\s+)([a-z])/g, (match) => {
    return match.toUpperCase();
  });
  
  // Handle special cases for common abbreviations to avoid incorrect sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'vs', 'ie', 'eg'];
  abbreviations.forEach(abbr => {
    const pattern = new RegExp(`\b${abbr}\.\s+([a-z])`, 'gi');
    result = result.replace(pattern, (match, nextChar) => {
      return match.slice(0, -1) + nextChar.toLowerCase();
    });
  });
  
  // Final cleanup of extra spaces around punctuation
  result = result.replace(/\s+([.!?])/g, '$1');
  
  return result;
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Supports http/https protocols and www domains.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  const urlRegex = /\b(?:https?:\/\/|www\.)[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[\w\-.~:/?#\[\]@!$&'()*+,;=%]*)?(?:\?[\w\-.~:/?#\[\]@!$&'()*+,;=%]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation (.,!?;:) but keep it if it's part of the URL
  return matches.map(url => url.replace(/[.,!?;:]+$/g, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// for any URL
  // Only replace when it's not already https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade http://example.com/... to https://example.com/...
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    // Match URLs from example.com
    /\bhttps?:\/\/example\.com(\/[^\s]*)?/g,
    (match, path = '') => {
      // Always upgrade to https
      const upgraded = match.replace(/^http:\/\//, 'https://');
      
      // Check if we should skip host rewrite
      const hasDynamicHints = /(?:cgi-bin|\?|&|=)|(?:\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)(?:\?|$)/.test(path);
      
      // If path starts with /docs/ and no dynamic hints, rewrite host
      if (path.startsWith('/docs/') && !hasDynamicHints) {
        return `https://docs.example.com${path}`;
      }
      
      // Otherwise, just return the upgraded URL
      return upgraded;
    }
  );
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' if the format doesn't match or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation)
  const maxDays = {
    '01': 31, '02': 29, '03': 31, '04': 30, '05': 31, '06': 30,
    '07': 31, '08': 31, '09': 30, '10': 31, '11': 30, '12': 31
  };
  
  if (dayNum > maxDays[month as keyof typeof maxDays]) {
    return 'N/A';
  }
  
  return year;
}
