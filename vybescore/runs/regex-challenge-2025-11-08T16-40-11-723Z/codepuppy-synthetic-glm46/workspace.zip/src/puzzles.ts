/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple prefix matching without special regex characters escape for now
  const words = text.split(/\s+/);
  const result: string[] = [];
  
  for (const word of words) {
    if (word.toLowerCase().startsWith(prefix.toLowerCase())) {
      const cleanWord = word.replace(/[^a-zA-Z]/g, '');
      if (cleanWord && !exceptions.some(ex => ex.toLowerCase() === cleanWord.toLowerCase())) {
        result.push(cleanWord);
      }
    }
  }
  
  return result;
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses simpler approach without lookbehind for wider compatibility.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const matches: string[] = [];
  
  // Simple string split and check approach
  const parts = text.split(/\s+/);
  
  for (const part of parts) {
    // Check if part contains digit followed by token
    const digitTokenMatch = part.match(/(\d+)([a-zA-Z]+)/);
    if (digitTokenMatch && digitTokenMatch[2] === token) {
      matches.push(digitTokenMatch[1] + digitTokenMatch[2]);
    }
  }
  
  return matches;
}

/**
 * Validates passwords according to strong security policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns of length 2-4 that repeat immediately
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Use a simpler approach - look for repeated 2-character patterns
  if (/(..)\1/.test(value)) {
    return false;
  }
  if (/(...)\1/.test(value)) {
    return false;
  }
  if (/(....)\1/.test(value)) {
    return false;
  }
  
  // Additional check for keyboard patterns like qwerty, asdf, etc.
  const keyboardPatterns = [
    'qwerty', 'asdf', 'zxcv', '1234', '9876'
  ];
  
  for (const pattern of keyboardPatterns) {
    if (value.toLowerCase().includes(pattern)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns - comprehensive coverage including shorthand
  const ipv6Patterns = [
    // Full IPv6: eight groups of four hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // :: compression (2 or more colon groups)
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    // Leading or trailing ::
    /\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/,
    // Standalone ::
    /\b::\b/,
    // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  // First check if any IPv6 pattern matches
  const hasIPv6 = ipv6Patterns.some(pattern => pattern.test(value));
  
  if (!hasIPv6) {
    return false;
  }
  
  // Make sure it's not just an IPv4 address
  // IPv4 pattern: four groups of 1-3 digits, each 0-255
  const ipv4Pattern = /\b^(?:\d{1,3}\.){3}\d{1,3}$\b/;
  
  // If the entire string is just an IPv4 address, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Additional check: ensure at least one IPv6-specific feature is present
  // (colon groups, :: compression, or hex digits beyond what IPv4 would have)
  const hasIPv6Features = /:|::|[a-fA-F]/.test(value);
  
  return hasIPv6Features;
}
