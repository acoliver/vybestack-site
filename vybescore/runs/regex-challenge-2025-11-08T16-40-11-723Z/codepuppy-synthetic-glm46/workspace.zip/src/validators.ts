export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Supports typical formats like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles the requirements
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for edge cases
  // Reject double dots anywhere in email
  if (value.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain starting or ending with hyphen or dot
  if (domain.startsWith('-') || domain.endsWith('-') || 
      domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length (10 digits for US number)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits now
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format patterns
  const patterns = [
    /^\+?1?\s*\(?(\d{3})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})$/, // (123) 456-7890 or 123-456-7890
    /^\+?1?\s*(\d{10})$/, // 1234567890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone patterns
  // Pattern 1: +54 341 123 4567 format
  const patternWithCountry = /^\+54(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  // Pattern 2: 0341 4234567 format (with trunk prefix 0)
  const patternWithTrunk = /^0[1-9]\d{1,3}\d{6,8}$/;
  
  if (patternWithCountry.test(cleaned)) {
    return true;
  }
  
  if (patternWithTrunk.test(cleaned)) {
    return true;
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Regex for valid names:
  // \p{L} - any unicode letter
  // \u0300-\u036F - combining diacritical marks
  // [\s'-] - spaces, apostrophes, hyphens
  // At least 2 characters, max 50
  const nameRegex = /^[\p{L}\u0300-\u036F]+(?:[\p{L}\u0300-\u036F\s'-]*[\p{L}\u0300-\u036F]+)?$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Length validation
  const trimmed = value.trim();
  if (trimmed.length < 2 || trimmed.length > 50) {
    return false;
  }
  
  // Reject digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject unusual symbols (except allowed apostrophes and hyphens)
  const allowedSymbols = ["'", '-'];
  for (const char of value) {
    if (!/[\p{L}\u0300-\u036F\s]/u.test(char) && !allowedSymbols.includes(char)) {
      return false;
    }
  }
  
  // Reject names that are just symbols or have consecutive symbols
  if (/['-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject names starting or ending with apostrophe or hyphen
  if (value.startsWith("'") || value.startsWith('-') || 
      value.endsWith("'") || value.endsWith('-')) {
    return false;
  }
  
  // Reject names with too many spaces/symbols (suggests malformed input)
  const symbolCount = (value.match(/[\s'-]/g) || []).length;
  if (symbolCount > value.length / 2) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) with prefix validation and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length (13-19 digits typical)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  let isValidPrefix = false;
  if (visaRegex.test(cleaned)) {
    isValidPrefix = true;
  } else if (mastercardRegex.test(cleaned)) {
    isValidPrefix = true;
  } else if (amexRegex.test(cleaned)) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}
