/**
 * Validate Base64 input string.
 * Uses canonical Base64 alphabet: A-Z, a-z, 0-9, +, /, and = for padding.
 * URL-safe variants (- and _) are NOT accepted per RFC 4648.
 */
const INVALID_BASE64 = 'Invalid Base64 input';

function isValidBase64(input: string): boolean {
  // Remove whitespace for validation
  const trimmed = input.replace(/\s/g, '');
  
  // Empty string is invalid
  if (trimmed.length === 0) {
    return false;
  }
  
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, =)
  // Explicitly reject URL-safe variants (- and _)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmed)) {
    return false;
  }
  
  // Ensure we have at least one valid character (not just padding)
  if (!/^[A-Za-z0-9+/]/.test(trimmed)) {
    return false;
  }
  
  // Check padding placement (only at the end, max 2 chars)
  const paddingIndex = trimmed.indexOf('=');
  const hasInvalidPadding = paddingIndex !== -1 && (
    !/^={1,2}$/.test(trimmed.slice(paddingIndex)) || paddingIndex < trimmed.length - 2
  );
  if (hasInvalidPadding) {
    return false;
  }
  
  // Check length is valid:
  // - With padding: must be multiple of 4
  // - Without padding: can be any length except 1 mod 4
  if (trimmed.includes('=')) {
    // Padded input must have length divisible by 4
    if (trimmed.length % 4 !== 0) {
      return false;
    }
  } else {
    // Unpadded input can have any length except 1 mod 4
    // (a single Base64 character cannot represent valid data)
    if (trimmed.length % 4 === 1) {
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 * Uses standard Base64 with padding (=) as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  const trimmed = input.replace(/\s/g, '');
  
  // Validate input before attempting decode
  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64);
  }
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Verify the decode was successful by checking if we got valid data
    // A valid Base64 decode should produce bytes that re-encode consistently
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error(INVALID_BASE64);
    }
    
    // Check for invalid bit sequences by re-encoding and comparing
    // Normalize both for comparison (strip padding)
    const reEncoded = buffer.toString('base64').replace(/=+$/, '');
    const normalizedInput = trimmed.replace(/=+$/, '');
    if (reEncoded !== normalizedInput) {
      throw new Error(INVALID_BASE64);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message === INVALID_BASE64) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
