import { createInput, createComputed, createCallback } from './src/index.ts'

// Test with logging to understand what's happening
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})
const sum = createComputed(() => {
  console.log('  Computing sum, timesTwo =', timesTwo(), 'timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial state:')
console.log('  sum() =', sum())

console.log('\nCalling setInput(3):')
setInput(3)

console.log('\nAfter setInput(3):')
console.log('  sum() =', sum())
console.log('  timesTwo() =', timesTwo())
console.log('  timesThirty() =', timesThirty())
