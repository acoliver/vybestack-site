/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: Set<Subject<unknown>>
  observers?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Clear previous dependencies before recomputing
    const oldSubjects = observer.subjects || new Set()
    observer.subjects = new Set()
    
    // Recompute the value
    observer.value = observer.updateFn(observer.value)
    
    // Unregister from subjects that are no longer accessed
    for (const subject of oldSubjects) {
      if (!observer.subjects!.has(subject)) {
        subject.observers?.delete(observer)
      }
    }
    
    // Register with new subjects (only if not already registered)
    for (const subject of observer.subjects) {
      if (!subject.observers) {
        subject.observers = new Set()
      }
      // Avoid double-registration
      if (!subject.observers.has(observer)) {
        subject.observers.add(observer)
      }
    }
    
    // Notify observers of this computed value (if any)
    // This ensures that dependent computed values and callbacks are updated
    if (observer.observers && observer.observers.size > 0) {
      // Only notify if we're in the top-level update (previous is undefined or different)
      // This prevents re-entrancy issues during initialization
      if (!previous || !previous.subjects?.has(observer as Subject<unknown>)) {
        // Create a copy to avoid issues if the set is modified during notification
        const observers = Array.from(observer.observers)
        for (const obs of observers) {
          // Check that the observer is still registered and hasn't been disposed
          if (observer.observers.has(obs) && 'updateFn' in obs) {
            updateObserver(obs as Observer<unknown>)
          }
        }
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (!subject.observers) return
  // Create a copy of the observers set to avoid issues if the set is modified during iteration
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    // Only update if the observer is still registered and not disposed
    if (subject.observers.has(observer) && 'updateFn' in observer) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
