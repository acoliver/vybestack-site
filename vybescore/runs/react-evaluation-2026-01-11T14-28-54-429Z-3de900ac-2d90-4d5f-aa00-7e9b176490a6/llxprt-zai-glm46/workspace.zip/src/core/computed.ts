/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set(),
    observers: new Set(),
  }
  
  // Track if this computed has been initialized
  let initialized = false
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      // Track dependency: add this computed to current observer's subjects
      observer.subjects.add(o as Subject<unknown>)
      // Also register the observer with this computed
      if (!o.observers) {
        o.observers = new Set()
      }
      // Avoid double-registration
      if (!o.observers.has(observer)) {
        o.observers.add(observer)
      }
    }
    
    // Initialize the computed value if not already done
    if (!initialized) {
      initialized = true
      updateObserver(o)
    }
    
    return o.value!
  }

  return getter
}
