/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // If disposed, return previous value without executing
      if (disposed) return prevValue as T
      return updateFn(prevValue)
    },
    subjects: new Set(),
    observers: new Set(),
  }
  
  // Initialize the callback and track dependencies
  updateObserver(observer)
  
  const cleanup = () => {
    disposed = true
    
    // Remove this observer from all subjects it's registered with
    if (observer.subjects) {
      for (const subject of observer.subjects) {
        subject.observers?.delete(observer)
      }
    }
    observer.subjects?.clear()
    observer.observers?.clear()
    observer.value = undefined
  }
  
  const unsubscribe = () => {
    if (disposed) return
    cleanup()
  }
  
  return unsubscribe
}
