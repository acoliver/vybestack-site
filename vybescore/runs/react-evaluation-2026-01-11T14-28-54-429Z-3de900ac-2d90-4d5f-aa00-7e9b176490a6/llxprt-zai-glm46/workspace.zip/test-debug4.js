import { createInput, createComputed, createCallback } from './src/index.ts'

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output()))
const values2 = []
createCallback(() => values2.push(output()))

setInput(31)
unsubscribe1()
setInput(41)

console.log('values1:', values1)
console.log('values2:', values2)
console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)
