import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum())

// Access internal state for debugging
const timesTwoObs = timesTwo.__observer
const timesThirtyObs = timesThirty.__observer
const sumObs = sum.__observer

console.log('timesTwo.subjects size:', timesTwoObs.subjects?.size)
console.log('timesThirty.subjects size:', timesThirtyObs.subjects?.size)
console.log('sum.subjects size:', sumObs.subjects?.size)

console.log('input.__observers size:', input.__observers?.size)

console.log('\nCalling setInput(3)')
setInput(3)

console.log('After setInput(3):')
console.log('  sum():', sum())
console.log('  timesTwo():', timesTwo())
console.log('  timesThirty():', timesThirty())
