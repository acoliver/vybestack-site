// Debug test for callback
import { createInput, createComputed, createCallback } from './src/index.js'

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output()))
const values2 = []
createCallback(() => values2.push(output()))

console.log('Initial: values1.length =', values1.length, 'values2.length =', values2.length)

setInput(31)
console.log('After setInput(31): values1.length =', values1.length, 'values2.length =', values2.length)
console.log('values1:', values1)
console.log('values2:', values2)

unsubscribe1()
console.log('After unsubscribe1')

setInput(41)
console.log('After setInput(41): values1.length =', values1.length, 'values2.length =', values2.length)
console.log('values1:', values1)
console.log('values2:', values2)

console.log('Test: values2.length > values1.length ?', values2.length > values1.length)
