import { createInput, createComputed, createCallback } from './src/index.ts'

// Test 1: compute cells can depend on other compute cells
console.log('Test 1: compute cells can depend on other compute cells')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())
console.log('  sum() =', sum()) // Should be 32
console.log('  timesTwo() =', timesTwo())
console.log('  timesThirty() =', timesThirty())
console.log('  input() =', input())
setInput(3)
console.log('  after setInput(3):')
console.log('  sum() =', sum()) // Should be 96
console.log('  timesTwo() =', timesTwo())
console.log('  timesThirty() =', timesThirty())
console.log('  input() =', input())

// Test 2: compute cells fire callbacks
console.log('\nTest 2: compute cells fire callbacks')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => { value = output() })
console.log('  value =', value) // Should be 2
setInput2(3)
console.log('  after setInput2(3), value =', value) // Should be 4
