import { createInput, createComputed, createCallback } from './src/index.ts'

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 called, output =', output())
  values1.push(output())
})

const values2 = []
createCallback(() => {
  console.log('Callback 2 called, output =', output())
  values2.push(output())
})

console.log('Calling setInput(31)')
setInput(31)
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nCalling unsubscribe1()')
unsubscribe1()

console.log('\nCalling setInput(41)')
setInput(41)
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nFinal results:')
console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)
