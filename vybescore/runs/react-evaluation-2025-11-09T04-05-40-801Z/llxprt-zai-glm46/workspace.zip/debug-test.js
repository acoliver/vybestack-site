import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing reactive programming ===')

// Test 1: Basic computed dependency
console.log('\n--- Test 1: Basic computed dependency ---')
const [input, setInput] = createInput(1)
console.log('input() =', input())

const timesTwo = createComputed(() => {
  console.log('  computing timesTwo, input() =', input())
  return input() * 2
})
console.log('timesTwo() =', timesTwo())

const timesThirty = createComputed(() => {
  console.log('  computing timesThirty, input() =', input())
  return input() * 30
})
console.log('timesThirty() =', timesThirty())

const sum = createComputed(() => {
  console.log('  computing sum, timesTwo() =', timesTwo(), 'timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
})
console.log('sum() =', sum())

console.log('\nChanging input to 3...')
setInput(3)
console.log('After change:')
console.log('input() =', input())
console.log('timesTwo() =', timesTwo())
console.log('timesThirty() =', timesThirty())
console.log('sum() =', sum())

// Test 2: Callback functionality
console.log('\n--- Test 2: Callback functionality ---')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
console.log('input2() =', input2(), 'output() =', output())

let value = 0
const unsubscribe = createCallback(() => {
  console.log('  callback triggered: output() =', output())
  value = output()
})

console.log('Changing input2 to 3...')
setInput2(3)
console.log('After change: value =', value)

unsubscribe()

// Test 3: Multiple callbacks
console.log('\n--- Test 3: Multiple callbacks ---')
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log('  callback1 triggered: output3() =', output3())
  values1.push(output3())
})

const values2 = []
createCallback(() => {
  console.log('  callback2 triggered: output3() =', output3())
  values2.push(output3())
})

console.log('Changing input3 to 31...')
setInput3(31)
console.log('values1 =', values1)
console.log('values2 =', values2)

console.log('Unsubscribing callback1 and changing input3 to 41...')
unsubscribe1()
setInput3(41)
console.log('values1 =', values1)
console.log('values2 =', values2)