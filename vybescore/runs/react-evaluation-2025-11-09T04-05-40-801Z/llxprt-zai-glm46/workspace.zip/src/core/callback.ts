/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserver, hasDependencies } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Register observer to track dependencies
  const initialize = () => {
    const previousObserver = getActiveObserver()
    
    // Clear old dependencies
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        if (subject.observers) {
          subject.observers.delete(observer as any)
        }
      })
      observer.dependencies.clear()
    }
    
    // This observer becomes the active one to track dependencies
    setActiveObserver(observer)
    
    // Execute the update function to establish dependencies
    try {
      observer.updateFn()
    } finally {
      // Restore the previous active observer
      setActiveObserver(previousObserver)
    }
  }
  
  // Initialize dependencies
  initialize()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to stop further updates
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        if (subject.observers) {
          subject.observers.delete(observer as any)
        }
      })
      observer.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}