/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? (a, b) => a === b : 
    undefined

  let currentValue = value
  let needsUpdate = true
  
  const observer: Observer<T> = {
    name: options?.name,
    value: currentValue,
    dependencies: new Set(),
    updateFn: (prevValue?: T): T => {
      const previousActive = getActiveObserver()
      setActiveObserver(observer)
      try {
        // Clear old dependencies
        if (observer.dependencies) {
          observer.dependencies.forEach(subject => {
            if (subject.observers) {
              subject.observers.delete(observer as any)
            }
          })
          observer.dependencies.clear()
        }
        
        // Compute new value and track dependencies
        const newValue = updateFn(prevValue)
        
        // Add this observer as dependent to all accessed subjects
        if (observer.dependencies) {
          observer.dependencies.forEach(subject => {
            if (subject.observers) {
              subject.observers.add(observer as any)
            }
          })
        }
        
        currentValue = newValue
        needsUpdate = false
        return currentValue
      } finally {
        setActiveObserver(previousActive)
      }
    },
  }
  
  const compute = (): T => {
    if (!needsUpdate && currentValue !== undefined) {
      return currentValue
    }
    
    // Clear old dependencies
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        if (subject.observers) {
          subject.observers.delete(observer as any)
        }
      })
      observer.dependencies.clear()
    }
    
    // Set this observer as active to track dependencies
    const previousActive = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      // Register observer and compute new value
      const previousValue = currentValue
      currentValue = updateFn(previousValue)
      needsUpdate = false
      
      // Add this observer as dependent to all accessed subjects
      if (observer.dependencies) {
        observer.dependencies.forEach(subject => {
          if (subject.observers) {
            subject.observers.add(observer as any)
          }
        })
      }
      
      return currentValue
    } finally {
      // Restore previous active observer
      setActiveObserver(previousActive)
    }
  }
  
  const getter: GetterFn<T> = (): T => {
    const active = getActiveObserver()
    if (active && 'dependencies' in active && active.dependencies) {
      // This getter is being accessed by another observer, register this computed as a dependency
      (active.dependencies as any).add({ name: options?.name, observers: new Set([observer]) } as any)
    }
    return compute()
  }
  
  // Initial computation
  compute()
  
  return getter
}