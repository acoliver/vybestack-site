/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T = unknown> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T = unknown> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T = unknown> = {
  name?: string
  value?: T
  updateFn: UpdateFn<unknown>
  disposed?: boolean
  dependencies?: Set<Subject<unknown>>
  isCallback?: boolean // Flag to identify callback observers
}

export type Subject<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<unknown>>
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver(observer: Observer<unknown>): void {
  observer.disposed = false
  
  // Clear old dependencies
  if (observer.dependencies) {
    const oldDeps = Array.from(observer.dependencies)
    oldDeps.forEach(subject => {
      removeObserver(subject, observer)
    })
    observer.dependencies.clear()
  }
}

// Global update tracking
let updateDepth = 0
const queuedUpdates = new Set<Subject<unknown>>()

export function beginUpdate(): void {
  updateDepth++
}

export function endUpdate(): void {
  updateDepth--
  if (updateDepth === 0) {
    processQueuedUpdates()
  }
}

function processQueuedUpdates(): void {
  if (queuedUpdates.size === 0) return
  
  const subjects = Array.from(queuedUpdates)
  queuedUpdates.clear()
  
  // Process all queued updates
  subjects.forEach(subject => {
    if (subject.observers.size > 0) {
      notifyObserversDirect(subject)
    }
  })
  
  // If new updates were queued during processing, process them too
  if (queuedUpdates.size > 0) {
    processQueuedUpdates()
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (updateDepth > 0) {
    queuedUpdates.add(subject as Subject<unknown>)
  } else {
    notifyObserversDirect(subject as Subject<unknown>)
  }
}

function notifyObserversDirect(subject: Subject<unknown>): void {
  beginUpdate()
  try {
    // Create a copy of observers to avoid issues with observers being added/removed during notification
    const observers = Array.from(subject.observers)
    
    // First pass: update computed values
    const computedObservers = observers.filter(obs => !obs.isCallback)
    computedObservers.forEach(observer => {
      if (!observer.disposed) {
        updateObserver(observer)
      }
    })
    
    // Second pass: trigger callbacks
    const callbackObservers = observers.filter(obs => obs.isCallback)
    callbackObservers.forEach(observer => {
      if (!observer.disposed) {
        updateObserver(observer)
      }
    })
  } finally {
    endUpdate()
  }
}

export function addObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers.add(observer)
  
  // Track dependencies for cleanup
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject as Subject<unknown>)
}

export function removeObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers.delete(observer)
  
  // Remove from dependencies
  if (observer.dependencies) {
    observer.dependencies.delete(subject as Subject<unknown>)
  }
}

export function disposeObserver(observer: Observer<unknown>): void {
  observer.disposed = true
  
  // Remove from all subjects we observe
  if (observer.dependencies) {
    observer.dependencies.forEach(subject => {
      removeObserver(subject, observer)
    })
    observer.dependencies.clear()
  }
}