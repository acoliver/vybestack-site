/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, getActiveObserver, setActiveObserver, updateObserver, disposeObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<unknown> = {
    value,
    updateFn: (prevValue) => {
      // Run as active observer to capture dependencies
      const previous = getActiveObserver()
      setActiveObserver(observer)
      try {
        return updateFn(prevValue as T)
      } finally {
        setActiveObserver(previous)
      }
    },
    isCallback: true
  }
  
  // Initial execution to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Dispose the observer (this handles cleanup of all dependencies)
    disposeObserver(observer)
  }
  
  return unsubscribe
}
