/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    equalFn = undefined
  } else {
    // Default equality function (strict equality)
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      // Initialize dependencies if not already done
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      s.observers.add(observer)
      observer.dependencies.add(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!equalFn || !equalFn(s.value, nextValue)) {
      s.value = nextValue
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}