/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    equalFn = undefined
  } else {
    // Default equality function (strict equality)
    equalFn = (a, b) => a === b
  }

  // Create a subject to manage observers of this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }

  // Track dependencies for this computed value
  const dependencies = new Set<Subject<unknown>>()

  // Create observer for the computed value
  const observer: Observer<T> = {
    name: options?.name,
    value: subject.value,
    updateFn: (prevValue) => {
      // Clear existing dependencies before recomputing
      dependencies.forEach(dep => {
        dep.observers.delete(observer)
      })
      dependencies.clear()
      
      // Run as active observer to track new dependencies
      const previous = getActiveObserver()
      setActiveObserver(observer)
      try {
        const newValue = updateFn(prevValue as T)
        
        // Update subject value and notify observers
        if (!subject.equalFn || !subject.equalFn(subject.value, newValue)) {
          subject.value = newValue
          observer.value = newValue
          notifyObservers(subject)
        }
        
        return newValue
      } finally {
        setActiveObserver(previous)
      }
    },
    dependencies,
    disposed: false
  }

  // Force dependency tracking for initial computation
  const computeInitial = () => {
    const previous = getActiveObserver()
    setActiveObserver(observer)
    try {
      return updateFn()
    } finally {
      setActiveObserver(previous)
    }
  }

  // Set initial value
  const initialValue = computeInitial()
  subject.value = initialValue
  observer.value = initialValue

  const read: GetterFn<T> = () => {
    // If there's an active observer, add this computed as a dependency
    const currentObserver = getActiveObserver()
    if (currentObserver && !currentObserver.disposed) {
      // Initialize dependencies if not already done
      if (!currentObserver.dependencies) {
        currentObserver.dependencies = new Set()
      }
      subject.observers.add(currentObserver)
      currentObserver.dependencies.add(subject as Subject<unknown>)
    }
    
    return subject.value
  }

  return read
}