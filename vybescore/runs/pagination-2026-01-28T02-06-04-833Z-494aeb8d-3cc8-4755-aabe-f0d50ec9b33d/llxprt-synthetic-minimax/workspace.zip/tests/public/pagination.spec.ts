import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory pagination API', () => {
  it('handles default pagination (page=1, limit=5)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('handles page 2 correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(2);
    expect(response.body.items[0].id).toBe(6); // Should skip first 5 items
  });

  it('handles page 3 correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(3);
    expect(response.body.hasNext).toBe(false);
  });

  it('handles last page (page 3)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(false);
    expect(response.body.total).toBe(15);
  });

  it('validates page parameter (negative)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('page');
  });

  it('validates page parameter (zero)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('page');
  });

  it('validates page parameter (non-numeric)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('page');
  });

  it('validates limit parameter (excessive)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=101');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('limit');
  });

  it('handles custom limit', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=10');
    
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(10);
    expect(response.body.limit).toBe(10);
  });
});