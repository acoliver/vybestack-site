      json(data) {
        this.body = data;
        return this;
      },
      status(code) {
        this.statusCode = code;
        return this;
      }
    };
    return res;
  }
  
  // Test 1: Default parameters
  console.log('Test 1: Default parameters (page=1, limit=5)');
  let req = mockRequest({});
  let res = mockResponse();
  await app._router.handle(req, res);
  console.log('Response:', JSON.stringify(res.body, null, 2));
  console.log('[OK] Items count:', res.body.items.length, 'Page:', res.body.page, 'Has next:', res.body.hasNext);
  
  // Test 2: Explicit page 1
  console.log('\nTest 2: Explicit page 1');
  req = mockRequest({ page: '1', limit: '5' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Response:', JSON.stringify(res.body, null, 2));
  console.log('[OK] Items count:', res.body.items.length, 'Page:', res.body.page, 'Has next:', res.body.hasNext);
  
  // Test 3: Page 2
  console.log('\nTest 3: Page 2');
  req = mockRequest({ page: '2', limit: '5' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Response:', JSON.stringify(res.body, null, 2));
  console.log('[OK] Items count:', res.body.items.length, 'Page:', res.body.page, 'Has next:', res.body.hasNext);
  
  // Test 4: Page 3
  console.log('\nTest 4: Page 3');
  req = mockRequest({ page: '3', limit: '5' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Response:', JSON.stringify(res.body, null, 2));
  console.log('[OK] Items count:', res.body.items.length, 'Page:', res.body.page, 'Has next:', res.body.hasNext);
  
  // Test 5: Invalid page (negative)
  console.log('\nTest 5: Invalid page (negative)');
  req = mockRequest({ page: '-1' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Status:', res.statusCode, 'Response:', res.body);
  
  // Test 6: Invalid page (zero)
  console.log('\nTest 6: Invalid page (zero)');
  req = mockRequest({ page: '0' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Status:', res.statusCode, 'Response:', res.body);
  
  // Test 7: Non-numeric page
  console.log('\nTest 7: Non-numeric page');
  req = mockRequest({ page: 'abc' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Status:', res.statusCode, 'Response:', res.body);
  
  // Test 8: Valid custom limit
  console.log('\nTest 8: Valid custom limit (limit=10)');
  req = mockRequest({ page: '1', limit: '10' });
  res = mockResponse();
  await app._router.handle(req, res);
  console.log('Response:', JSON.stringify(res.body, null, 2));
  console.log('[OK] Items count:', res.body.items.length, 'Page:', res.body.page, 'Has next:', res.body.hasNext);
  
  console.log('\n[OK] All pagination tests completed!');
}

testPagination().catch(console.error);