import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const { status, data, error, page, reloadPage } = useInventory(1, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasNext = data.hasNext;
  const isFirstPage = page === 1;

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem' }}>
        <button 
          onClick={() => reloadPage(page - 1)}
          disabled={isFirstPage}
        >
          Previous
        </button>
        <span>Page {page}</span>
        <button 
          onClick={() => reloadPage(page + 1)}
          disabled={!hasNext}
        >
          Next
        </button>
      </div>
      {data.items.length === 0 && (
        <p>No inventory items found.</p>
      )}
    </section>
  );
}
