/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // When this computed is accessed inside another reactive context,
      // we need to establish the dependency relationship
      updateObserver(o)
      return o.value!
    }
    // If not in a reactive context, return current value
    return o.value!
  }
  
  return getter
}
