// Simple debug script to understand reactivity flow
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())

console.log('Setting input to 3...')
setInput(3)

console.log('After update:')
console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())