import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationParams(page: unknown, limit: unknown): { page: number; limit: number } {
  const parsedPage = page !== undefined && page !== null && page !== '' ? Number(page) : 1;
  const parsedLimit = limit !== undefined && limit !== null && limit !== '' ? Number(limit) : DEFAULT_LIMIT;

  if (isNaN(parsedPage) || parsedPage <= 0) {
    throw new ValidationError('page must be a positive number');
  }

  if (!Number.isInteger(parsedPage)) {
    throw new ValidationError('page must be an integer');
  }

  if (isNaN(parsedLimit) || parsedLimit <= 0) {
    throw new ValidationError('limit must be a positive number');
  }

  if (!Number.isInteger(parsedLimit)) {
    throw new ValidationError('limit must be an integer');
  }

  if (parsedLimit > MAX_LIMIT) {
    throw new ValidationError(`limit cannot exceed ${MAX_LIMIT}`);
  }

  return { page: parsedPage, limit: parsedLimit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const { page, limit } = validatePaginationParams(options.page, options.limit);

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
