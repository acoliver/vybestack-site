/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Track all observers that need to be updated
const allObservers = new Set<Observer<unknown>>()

// Add an observer to the global tracking
export function trackObserver<T>(observer: Observer<T>): void {
  allObservers.add(observer as Observer<unknown>)
}

// Remove an observer from global tracking
export function untrackObserver<T>(observer: Observer<T>): void {
  allObservers.delete(observer as Observer<unknown>)
}

// Update all observers (they will re-run and track their dependencies)
export function updateAllObservers(): void {
  // Create a copy to avoid issues if the set is modified during iteration
  const observers = Array.from(allObservers)
  for (const observer of observers) {
    if (allObservers.has(observer)) {
      observer.value = observer.updateFn(observer.value)
    }
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Trigger update of all tracked observers
    updateAllObservers()
    return s.value
  }

  return [read, write]
}
