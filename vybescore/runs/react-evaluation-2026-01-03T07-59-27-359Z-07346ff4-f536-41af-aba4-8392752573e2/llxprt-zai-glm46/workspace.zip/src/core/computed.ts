/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver
} from '../types/reactive.js'
import { trackObserver, untrackObserver } from './input.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Track this observer globally
  trackObserver(o)

  // Initial computation to establish dependencies and set value
  updateObserver(o)

  const getter = (): T => o.value!

  // Mark the getter with a dispose method for cleanup
  ;(getter as GetterFn<T> & { dispose: () => void }).dispose = () => {
    untrackObserver(o)
  }

  return getter
}
