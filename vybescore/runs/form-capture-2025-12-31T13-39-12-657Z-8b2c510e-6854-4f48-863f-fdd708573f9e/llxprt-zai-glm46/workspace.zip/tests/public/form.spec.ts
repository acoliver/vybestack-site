import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { createServer, initializeDatabase } from '../../src/server.js';

let server: Awaited<ReturnType<typeof createServer>>;
const dbPath = path.resolve('data', 'submissions.sqlite');
const TEST_PORT = 3536;

beforeAll(async () => {
  const database = await initializeDatabase();
  server = await createServer(database, TEST_PORT);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await fetch(`http://localhost:${TEST_PORT}/`);
    const html = await response.text();

    expect(response.status).toBe(200);
    expect(response.headers.get('content-type')).toContain('text/html');

    // Check for form elements
    expect(html).toContain('<form');
    expect(html).toContain('method="post"');
    expect(html).toContain('action="/submit"');

    // Check for all required fields with proper labels
    expect(html).toContain('First name');
    expect(html).toContain('Last name');
    expect(html).toContain('Street address');
    expect(html).toContain('City');
    expect(html).toContain('State / Province / Region');
    expect(html).toContain('Postal / Zip code');
    expect(html).toContain('Country');
    expect(html).toContain('Email');
    expect(html).toContain('Phone number');

    // Check for proper label/input associations
    expect(html).toMatch(/for="firstName"/);
    expect(html).toMatch(/id="firstName"/);
    expect(html).toMatch(/name="firstName"/);

    expect(html).toMatch(/for="lastName"/);
    expect(html).toMatch(/id="lastName"/);
    expect(html).toMatch(/name="lastName"/);

    expect(html).toMatch(/for="email"/);
    expect(html).toMatch(/id="email"/);
    expect(html).toMatch(/name="email"/);

    // Check for stylesheet link
    expect(html).toContain('/public/styles.css');
  });

  it('persists submission and redirects', async () => {
    // Remove existing database if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Small delay to ensure the file system is ready
    await new Promise(resolve => setTimeout(resolve, 100));

    const formData = new URLSearchParams({
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '123 Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'NW1 6XE',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958',
    });

    const response = await fetch(`http://localhost:${TEST_PORT}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
      redirect: 'manual',
    });

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.get('location')).toBe('/thank-you');

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Check that we can access the thank-you page
    const thankYouResponse = await fetch(`http://localhost:${TEST_PORT}/thank-you`);
    const thankYouHtml = await thankYouResponse.text();

    expect(thankYouResponse.status).toBe(200);
    expect(thankYouHtml).toContain('Thank you');
    expect(thankYouHtml).toContain('stranger');
    expect(thankYouHtml).toContain('href="/"');
  });

  it('shows validation errors for invalid data', async () => {
    const formData = new URLSearchParams({
      firstName: '', // Empty - should fail
      lastName: 'Doe',
      streetAddress: '456 Elm Street',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'USA',
      email: 'not-a-valid-email', // Invalid email
      phone: 'phone!', // Invalid characters
    });

    const response = await fetch(`http://localhost:${TEST_PORT}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    });

    // Should re-render the form with errors
    expect(response.status).toBe(400);
    const html = await response.text();

    // Should contain error messages
    expect(html).toMatch(/error/i);

    // Should preserve entered values
    expect(html).toContain('Doe');
    expect(html).toContain('456 Elm Street');
    expect(html).toContain('Springfield');
  });

  it('accepts international phone and postal formats', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testCases = [
      {
        firstName: 'Carlos',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com.ar',
        phone: '+54 9 11 1234-5678',
      },
      {
        firstName: 'Marie',
        lastName: 'Dupont',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'marie@example.co.uk',
        phone: '+44 20 7946 0958',
      },
    ];

    for (const formData of testCases) {
      const response = await fetch(`http://localhost:${TEST_PORT}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(formData).toString(),
        redirect: 'manual',
      });

      expect(response.status).toBe(302);
      expect(response.headers.get('location')).toBe('/thank-you');
    }
  });
});
