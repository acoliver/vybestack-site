import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

function validatePhone(phone: string): boolean {
  const regex = /^[\d\s+()-]+$/;
  return regex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const regex = /^[\dA-Za-z\s-]+$/;
  return regex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): { errors: string[]; values: Partial<FormData> } {
  const errors: string[] = [];
  const values: Partial<FormData> = {
    firstName: data.firstName?.trim() || '',
    lastName: data.lastName?.trim() || '',
    streetAddress: data.streetAddress?.trim() || '',
    city: data.city?.trim() || '',
    stateProvince: data.stateProvince?.trim() || '',
    postalCode: data.postalCode?.trim() || '',
    country: data.country?.trim() || '',
    email: data.email?.trim() || '',
    phone: data.phone?.trim() || '',
  };

  if (!values.firstName) errors.push('First name is required');
  if (!values.lastName) errors.push('Last name is required');
  if (!values.streetAddress) errors.push('Street address is required');
  if (!values.city) errors.push('City is required');
  if (!values.stateProvince) errors.push('State / Province / Region is required');
  if (!values.postalCode) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(values.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens');
  }
  if (!values.country) errors.push('Country is required');
  if (!values.email) {
    errors.push('Email is required');
  } else if (!validateEmail(values.email)) {
    errors.push('Email must be a valid email address');
  }
  if (!values.phone) {
    errors.push('Phone number is required');
  } else if (!validatePhone(values.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return { errors, values };
}

async function createServer(database: Database, port: number) {
  const app = express();

  // Set the database parameter as the db for this server instance
  db = database;

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  app.set('view engine', 'ejs');
  // Use src/templates for views even when running from dist
  app.set('views', path.join(process.cwd(), 'src', 'templates'));

  // Serve static files from public directory
  app.use('/public', express.static(path.join(process.cwd(), 'public')));

  app.get('/', (_req, res) => {
    res.render('form', { errors: [], values: {} });
  });

  app.post('/submit', (req, res) => {
    const { errors, values } = validateFormData(req.body);

    if (errors.length > 0) {
      res.status(400);
      return res.render('form', { errors, values });
    }

    if (!db) {
      errors.push('Database not available');
      res.status(500);
      return res.render('form', { errors, values: {} });
    }

    try {
      // At this point, all required fields are guaranteed to be non-empty strings
      const params: string[] = [
        values.firstName!,
        values.lastName!,
        values.streetAddress!,
        values.city!,
        values.stateProvince!,
        values.postalCode!,
        values.country!,
        values.email!,
        values.phone!,
      ];
      db.run(
        `INSERT INTO submissions
         (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        params
      );
      saveDatabase(db);
    } catch (err) {
      console.error('Database error:', err);
      const newErrors = [...errors, 'Failed to save submission'];
      res.status(500);
      return res.render('form', { errors: newErrors, values: {} });
    }

    return res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (_req, res) => {
    res.render('thank-you', { firstName: 'Friend' });
  });

  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  return server;
}

async function startServer() {
  try {
    const database = await initializeDatabase();
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
    const server = await createServer(database, port);

    const shutdown = async () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        process.exit(0);
      });

      setTimeout(() => {
        console.error('Forced shutdown after timeout');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { createServer, initializeDatabase, saveDatabase };
export default startServer;
