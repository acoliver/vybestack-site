import { describe, expect, it } from 'vitest';
import { markdownFormatter } from '../../src/formats/markdown.js';
import { textFormatter } from '../../src/formats/text.js';
import { ReportData } from '../../src/types.js';

const sampleData: ReportData = {
  title: "Quarterly Financial Summary",
  summary: "Highlights include record revenue across regions and a healthy outlook for the next quarter.",
  entries: [
    { label: "North Region", amount: 12345.67 },
    { label: "South Region", amount: 23456.78 },
    { label: "West Region", amount: 34567.89 }
  ]
};

describe('report formatters', () => {
  it('renders markdown without totals', () => {
    const result = markdownFormatter.render(sampleData, { includeTotals: false });
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('- **South Region** — $23456.78');
    expect(result).toContain('- **West Region** — $34567.89');
    expect(result).not.toContain('**Total:**');
  });

  it('renders markdown with totals', () => {
    const result = markdownFormatter.render(sampleData, { includeTotals: true });
    expect(result).toContain('**Total:** $70370.34');
  });

  it('renders text without totals', () => {
    const result = textFormatter.render(sampleData, { includeTotals: false });
    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('- South Region: $23456.78');
    expect(result).toContain('- West Region: $34567.89');
    expect(result).not.toContain('Total:');
  });

  it('renders text with totals', () => {
    const result = textFormatter.render(sampleData, { includeTotals: true });
    expect(result).toContain('Total: $70370.34');
  });
});
