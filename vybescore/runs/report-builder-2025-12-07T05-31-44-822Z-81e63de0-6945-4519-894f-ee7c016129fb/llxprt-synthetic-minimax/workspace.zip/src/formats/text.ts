import { ReportData, RenderOptions, Formatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const textFormatter: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // List each entry
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }
    
    // Add total if requested
    if (options.includeTotals) {
      lines.push('');
      lines.push(`Total: ${formatAmount(calculateTotal(data))}`);
    }
    
    return lines.join('\n');
  }
};