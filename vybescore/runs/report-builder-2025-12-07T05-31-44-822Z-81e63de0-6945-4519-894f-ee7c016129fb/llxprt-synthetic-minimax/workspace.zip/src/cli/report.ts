import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, ReportFormat, RenderOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 5) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  
  // Find --format flag and its value
  let formatIndex = -1;
  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--format') {
      formatIndex = i;
      break;
    }
  }
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('Missing required --format argument');
  }
  
  const format = args[formatIndex + 1] as ReportFormat;
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
  }

  const parsedArgs: ParsedArgs = {
    dataFile,
    format,
    includeTotals: false
  };

  // Parse remaining optional arguments
  for (let i = formatIndex + 2; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a path argument');
      }
      parsedArgs.outputPath = args[i + 1];
      i++; // Skip the next argument as it's the path
    } else if (arg === '--includeTotals') {
      parsedArgs.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return parsedArgs;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;
  const { title, summary, entries } = obj;

  if (typeof title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!Array.isArray(entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const { label, amount } = entry;

    if (typeof label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }

    if (typeof amount !== 'number' || isNaN(amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }

  return { title, summary, entries };
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf8');
    const jsonData = JSON.parse(rawData);
    return validateReportData(jsonData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    throw new Error(`Error reading file "${filePath}": ${error instanceof Error ? error.message : String(error)}`);
  }
}

function renderReport(data: ReportData, format: ReportFormat, options: RenderOptions): string {
  const formatter = format === 'markdown' ? markdownFormatter : textFormatter;
  return formatter.render(data, options);
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf8');
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const parsedArgs = parseArgs(args);
    
    const reportData = loadReportData(parsedArgs.dataFile);
    const options: RenderOptions = { includeTotals: parsedArgs.includeTotals };
    
    const renderedContent = renderReport(reportData, parsedArgs.format, options);
    writeOutput(renderedContent, parsedArgs.outputPath);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}