import type { ReportData, RenderOptions, Renderer } from '../types.js';

/**
 * Formats amounts as currency with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates total amount from report entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Markdown renderer for reports
 */
export const renderMarkdown: Renderer = {
  render(data: ReportData, options?: RenderOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('## Entries');
    
    // Entry list
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }
    
    // Add total if requested
    if (options?.includeTotals) {
      const total = calculateTotal(data);
      lines.push('');
      lines.push(`**Total:** ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  },
};