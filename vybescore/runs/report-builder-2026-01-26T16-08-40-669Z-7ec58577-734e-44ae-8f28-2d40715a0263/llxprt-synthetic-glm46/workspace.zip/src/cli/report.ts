import fs from 'node:fs';
import { parseArguments } from '../utils/arguments.js';
import type { ReportData, RenderOptions, Renderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Registry of available renderers
 */
const RENDERERS: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Validates the report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string' || !reportData.title.trim()) {
    throw new Error('Invalid data: title is required and must be a non-empty string');
  }

  if (typeof reportData.summary !== 'string' || !reportData.summary.trim()) {
    throw new Error('Invalid data: summary is required and must be a non-empty string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }

  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: each entry must be an object');
    }

    const entryRecord = entry as Record<string, unknown>;

    if (typeof entryRecord.label !== 'string' || !entryRecord.label.trim()) {
      throw new Error('Invalid data: each entry requires a non-empty label');
    }

    if (typeof entryRecord.amount !== 'number' || isNaN(entryRecord.amount)) {
      throw new Error('Invalid data: each entry requires a valid amount');
    }
  }

  return reportData as unknown as ReportData;
}

/**
 * Main CLI entry point
 */
function main(): void {
  try {
    const args = parseArguments();

    // Validate format
    if (!RENDERERS[args.format]) {
      console.error(`Error: Unsupported format '${args.format}'. Supported formats: ${Object.keys(RENDERERS).join(', ')}`);
      process.exit(1);
    }

    // Read and parse JSON file
    if (!fs.existsSync(args.dataFile)) {
      console.error(`Error: File not found: ${args.dataFile}`);
      process.exit(1);
    }

    const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
    let parsedData: unknown;

    try {
      parsedData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file ${args.dataFile}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(parsedData);

    // Render report
    const renderer = RENDERERS[args.format];
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = renderer.render(reportData, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.log(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

// Run the CLI
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { main };
