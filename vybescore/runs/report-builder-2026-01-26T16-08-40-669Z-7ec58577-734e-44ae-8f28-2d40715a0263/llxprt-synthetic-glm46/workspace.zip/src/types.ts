/**
 * Report data structure matching the JSON schema
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Common interface for renderers
 */
export interface RenderOptions {
  includeTotals?: boolean;
}

export interface Renderer {
  render(data: ReportData, options?: RenderOptions): string;
}