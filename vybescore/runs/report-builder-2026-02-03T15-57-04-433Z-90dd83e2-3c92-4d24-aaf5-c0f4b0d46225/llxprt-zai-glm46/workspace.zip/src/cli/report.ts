#!/usr/bin/env node

import * as fs from 'node:fs';
import { getFormatter } from '../formatters.js';
import { validateReportData } from '../utils.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let positionalIdx = 0;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (positionalIdx === 0) {
        result.inputFile = arg;
      } else {
        throw new Error(`Unexpected positional argument: ${arg}`);
      }
      positionalIdx++;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const fileContent = fs.readFileSync(args.inputFile, 'utf-8');

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (parseError) {
      throw new Error(`Failed to parse JSON: ${parseError instanceof Error ? parseError.message : String(parseError)}`);
    }

    const reportData = validateReportData(jsonData);

    const formatter = getFormatter(args.format);

    const output = formatter(reportData, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(message);
    process.exit(1);
  }
}

main();
