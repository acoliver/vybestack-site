/**
 * Base64 encode/decode implementation using standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with proper padding and validation.
 */

const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_CHAR_REGEX = /[^A-Za-z0-9+/=]/;

/**
 * Encode plain text to Base64 using standard alphabet with padding.
 */
export function encode(input: string): string {
  // Convert UTF-8 string to Buffer, then to standard Base64
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input format and characters.
 */
function validateBase64Format(input: string): void {
  // Check for invalid characters
  if (INVALID_CHAR_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Validate that string matches Base64 pattern
  if (!BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: malformed format');
  }
}

/**
 * Validate Base64 padding.
 */
function validatePadding(input: string): void {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return;
  }

  // Padding must only appear at end
  if (paddingIndex !== input.length - 1 && input[paddingIndex + 1] !== '=') {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }

  // Maximum 2 padding characters allowed
  if (input.length - paddingIndex > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Empty string is valid
  if (trimmed === '' || trimmed === '=') {
    return '';
  }

  validateBase64Format(trimmed);
  validatePadding(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // If decoding resulted in an empty buffer but we had input, that's suspicious
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
