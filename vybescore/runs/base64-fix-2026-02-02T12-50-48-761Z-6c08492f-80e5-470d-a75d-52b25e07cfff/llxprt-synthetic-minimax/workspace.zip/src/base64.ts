/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8, validating input and handling padding.
 */
export function decode(input: string): string {
  // Remove any whitespace
  const normalized = input.replace(/\s+/g, '');

  // Check for invalid characters (only allow standard Base64 alphabet)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Validate padding - only check for proper location (padding at end only)
  const paddingRegex = /=+$/;
  const paddingMatch = normalized.match(paddingRegex);
  
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    
    // Check for proper padding position
    const contentLength = normalized.length - paddingLength;
    const expectedPadding = (4 - (contentLength % 4)) % 4;
    
    if (paddingLength !== expectedPadding) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }
  // Accept Base64 without padding - no strict length requirement

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
