import type { FormatRenderer, ReportData, RenderOptions } from '../types.js';

/**
 * Format amount as currency with exactly two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total from entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report in Markdown format
 */
export const renderMarkdown: FormatRenderer['render'] = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  data.entries.forEach((entry) => {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  });

  // Total if requested
  if (options.includeTotals) {
    lines.push(`**Total:** ${formatAmount(calculateTotal(data))}`);
  }

  return lines.join('\n');
};
