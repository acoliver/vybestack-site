/**
 * Report data structure matching the JSON schema from fixtures/data.json
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering reports
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Format renderer interface
 */
export interface FormatRenderer {
  render(data: ReportData, options: RenderOptions): string;
}
