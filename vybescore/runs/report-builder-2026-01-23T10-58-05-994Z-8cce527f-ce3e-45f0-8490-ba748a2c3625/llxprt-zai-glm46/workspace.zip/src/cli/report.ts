#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions } from '../types.js';

/**
 * Parse CLI arguments
 */
function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const dataFile = args[0];
  if (!dataFile) {
    console.error('Error: Missing data file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      format = args[++i] ?? '';
    } else if (arg === '--output') {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: Missing required --format argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Invalid data - expected an object');
    return false;
  }

  const reportData = data as Partial<ReportData>;

  if (typeof reportData.title !== 'string') {
    console.error('Error: Missing or invalid "title" field (expected string)');
    return false;
  }

  if (typeof reportData.summary !== 'string') {
    console.error('Error: Missing or invalid "summary" field (expected string)');
    return false;
  }

  if (!Array.isArray(reportData.entries)) {
    console.error('Error: Missing or invalid "entries" field (expected array)');
    return false;
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} is not an object`);
      return false;
    }

    if (typeof entry.label !== 'string') {
      console.error(`Error: Entry at index ${i} has missing or invalid "label" field`);
      return false;
    }

    if (typeof entry.amount !== 'number') {
      console.error(`Error: Entry at index ${i} has missing or invalid "amount" field`);
      return false;
    }
  }

  return true;
}

/**
 * Main CLI logic
 */
function main(): void {
  const args = process.argv.slice(2);
  const { dataFile, format, outputPath, includeTotals } = parseArgs(args);

  // Resolve data file path
  const resolvedPath = path.resolve(dataFile);

  // Read and parse JSON file
  let jsonData: unknown;
  try {
    const fileContent = fs.readFileSync(resolvedPath, 'utf-8');
    jsonData = JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON in file "${dataFile}": ${error.message}`);
    } else if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: "${dataFile}"`);
    } else {
      console.error(`Error: Failed to read file "${dataFile}": ${(error as Error).message}`);
    }
    process.exit(1);
  }

  // Validate data structure
  if (!validateReportData(jsonData)) {
    process.exit(1);
  }

  const data: ReportData = jsonData;

  // Select renderer based on format
  const options: RenderOptions = { includeTotals };
  let output: string;

  switch (format) {
    case 'markdown':
      output = renderMarkdown(data, options);
      break;
    case 'text':
      output = renderText(data, options);
      break;
    default:
      console.error(`Error: Unsupported format "${format}"`);
      console.error('Supported formats: markdown, text');
      process.exit(1);
  }

  // Write output
  if (outputPath) {
    try {
      fs.writeFileSync(path.resolve(outputPath), output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file "${outputPath}": ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
