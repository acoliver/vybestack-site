#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): [string, CliOptions] {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const inputFile = args[0];

  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--') && i === 1) {
      // Allow positional format argument
      format = arg;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return [inputFile, { format, outputPath, includeTotals }];
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data structure');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string' || !obj.title) {
    throw new Error('Report data must have a non-empty title string');
  }

  if (typeof obj.summary !== 'string' || !obj.summary) {
    throw new Error('Report data must have a non-empty summary string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Report data must have an entries array');
  }

  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || !entryObj.label) {
      throw new Error('Each entry must have a non-empty label string');
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error('Each entry must have a valid number amount');
    }
  }

  return data as ReportData;
}

async function main(): Promise<void> {
  try {
    const [inputFile, options] = parseArguments();

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(inputFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${inputFile}`);
      } else {
        console.error(`Error: Could not read file ${inputFile}: ${error}`);
      }
      process.exit(1);
    }

    // Validate report data structure
    const reportData = validateReportData(jsonData);

    // Get renderer based on format
    const renderOptions: RenderOptions = { includeTotals: options.includeTotals };
    let output: string;

    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(reportData, renderOptions);
        break;
      case 'text':
        output = renderText(reportData, renderOptions);
        break;
      default:
        console.error(`Error: Unsupported format "${options.format}"`);
        process.exit(1);
    }

    // Output result
    if (options.outputPath) {
      try {
        await writeFile(options.outputPath, output);
      } catch (error) {
        console.error(`Error: Could not write to file ${options.outputPath}: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();