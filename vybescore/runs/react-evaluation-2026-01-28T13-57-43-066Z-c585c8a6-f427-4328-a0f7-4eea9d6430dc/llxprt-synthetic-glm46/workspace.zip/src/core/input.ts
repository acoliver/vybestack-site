/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyCallbacks,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// @ts-ignore - Suppress type errors for notifyCallbacks with generic Subject<T>

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const observerWithId = observer as Observer<T>
      s.observer = observerWithId
      // Add this subject to the observer's dependencies
      if (!observerWithId.subjects) observerWithId.subjects = []
      observerWithId.subjects.push(s)
      
      // Register this observer with the subject
      if (!s.observers) s.observers = new Set()
      s.observers.add(observerWithId as Observer<any>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = (!_equal || !s.equalFn) || 
      (typeof _equal === 'boolean' ? _equal : s.equalFn!(s.value, nextValue) === false)
    
    if (hasChanged) {
      s.value = nextValue
      
      // Notify all dependent observers
      if (s.observers) {
        for (const observer of s.observers) {
          updateObserver(observer as Observer<any>)
        }
      }
      
      // For backwards compatibility, notify old style observer
      if (s.observer as Observer<T>) {
        updateObserver(s.observer as Observer<any>)
      }
      
      // Notify all callbacks
      notifyCallbacks()
    }
    return s.value
  }

  return [read, write]
}
