/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerCallback, unregisterCallback } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: []
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Register this callback in the global set
  ;(registerCallback as (o: Observer<T>) => void)(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unregister from global callbacks
    ;(unregisterCallback as (o: Observer<T>) => void)(observer)
    
    // Remove this observer from all subjects it was subscribed to
    if (observer.subjects) {
      for (const subject of observer.subjects) {
        if (subject.observers) {
          subject.observers.delete(observer as Observer<any>)
        }
      }
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
