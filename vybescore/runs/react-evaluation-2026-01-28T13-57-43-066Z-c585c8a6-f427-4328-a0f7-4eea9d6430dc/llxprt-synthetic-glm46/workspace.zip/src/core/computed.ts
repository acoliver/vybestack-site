/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: []
  }

  const getter = (): T => {
    // Clear current dependencies before recomputing
    if (o.subjects) {
      for (const subject of o.subjects) {
        if (subject.observers) {
          subject.observers.delete(o as Observer<any>)
        }
      }
      o.subjects = []
    }

    // Set this observer as the active one
    updateObserver(o)
    return o.value!
  }

  // Don't perform initial evaluation. First call will compute correctly
  return getter
}
