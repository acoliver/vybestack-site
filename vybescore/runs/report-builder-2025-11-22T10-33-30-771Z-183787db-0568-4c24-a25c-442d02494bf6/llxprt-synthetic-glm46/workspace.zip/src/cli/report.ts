#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): ReportOptions & { dataPath: string } {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];

  if (args[1] !== '--format' || !args[2]) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  const format = args[2];
  const options: { dataPath: string; format: string; output?: string; includeTotals?: boolean } = {
    dataPath,
    format,
  };

  // Parse remaining options
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.output = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown option ${arg}`);
      process.exit(1);
    }
  }

  return options;
}

function getRenderer(format: string): ReportRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  let data: ReportData;

  try {
    const commandLineArgs = parseArguments();

    // Read and parse the JSON file
    const fileContent = readFileSync(commandLineArgs.dataPath, 'utf8');
    const parsedData = JSON.parse(fileContent);

    data = validateReportData(parsedData);

    // Get the appropriate renderer
    try {
      const renderer = getRenderer(commandLineArgs.format);
      const reportOutput = renderer(data, commandLineArgs);

      // Output the report
      if (commandLineArgs.output) {
        writeFileSync(commandLineArgs.output, reportOutput, 'utf8');
        console.log(`Report written to ${commandLineArgs.output}`);
      } else {
        process.stdout.write(reportOutput);
      }
    } catch (error) {
      if (error instanceof Error && error.message.includes('Unsupported format')) {
        console.error(error.message);
        process.exit(1);
      }
      throw error;
    }
  } catch (error) {
    const err = error as Error;

    // Try to extract file path from error message if commandLineArgs is not available
    let filePath = 'unknown file';
    try {
      const args = process.argv.slice(2);
      if (args.length > 0) {
        filePath = args[0];
      }
    } catch {
      // Use default value
    }

    console.error(`Invalid JSON in ${filePath}: ${err.message}`);
    process.exit(1);
  }
}

main();