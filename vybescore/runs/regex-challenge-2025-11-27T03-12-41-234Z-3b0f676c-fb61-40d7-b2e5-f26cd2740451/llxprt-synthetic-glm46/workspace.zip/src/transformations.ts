/**
 * Capitalize the first character of each sentence
 * Insert exactly one space between sentences
 * Collapse extra spaces while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple sentence terminators with single one
  let result = text.replace(/([.?!]){2,}/g, '$1');
  
  // Insert space after sentence terminators if missing
  result = result.replace(/([.?!])(?=[A-Za-zÀ-ÖØ-öø-ÿ])/g, '$1 ');
  
  // Collapse multiple spaces into single space
  result = result.replace(/\s+/g, ' ');
  
  // Process each sentence to capitalize first character
  return result.replace(/(^|[.?!]\s+)([a-zà-öø-ÿ])/g, (match, sep, letter) => {
    return sep + letter.toUpperCase();
  });
}

/**
 * Return all URLs detected in the text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s?]*)?(?:\?[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;!?'"\()\[\]{}]+$/g, ''));
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/(?=[^\s])/, 'https://');
}

/**
 * Rewrite docs URLs according to specific rules
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)/g, (match, host, path) => {
    // Always upgrade to HTTPS
    let newUrl = `https://${host}${path}`;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check if path contains dynamic hints to skip host rewrite
      const skipPatterns = [
        /cgi-bin/, /\?/, /&/, /=/, /\.jsp$/, /\.php$/, 
        /\.asp$/, /\.aspx$/, /\.do$/, /\.cgi$/, /\.pl$/, /\.py$/
      ];
      
      // Only rewrite host to docs.example.com if no skip patterns found
      if (!skipPatterns.some(pattern => pattern.test(path))) {
        newUrl = `https://docs.example.com${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Return the four-digit year for mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    const [, month, day, year] = match;
    
    // Additional validation for month/day combinations
    const monthNum = parseInt(month, 10);
    const dayNum = parseInt(day, 10);
    
    // Simple validation - check for impossible dates
    if (
      (monthNum === 2 && dayNum > 29) || // February
      (monthNum === 4 && dayNum > 30) || // April
      (monthNum === 6 && dayNum > 30) || // June
      (monthNum === 9 && dayNum > 30) || // September
      (monthNum === 11 && dayNum > 30)   // November
    ) {
      return 'N/A';
    }
    
    return year;
  }
  
  return 'N/A';
}