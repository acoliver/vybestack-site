/**
 * Find words beginning with the prefix but excluding listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern for words starting with the prefix
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * Return occurrences where token appears after a digit and not at start of string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to match token preceded by digit
  // and negative lookbehind to ensure not at start of string
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');
  
  return (text.match(pattern) || []) as string[];
}

/**
 * Check if password meets strength requirements
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Length check
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (abab, abcabc, etc.)
  for (let i = 0; i < value.length / 2; i++) {
    const firstHalf = value.substring(0, value.length / 2);
    const secondHalf = value.substring(value.length / 2);
    
    if (firstHalf === secondHalf) return false;
  }
  
  // Check for pattern repetition like abab
  const patternRegex = /(.{2,})\1/;
  if (patternRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) 
 * Ensure IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 detection: must contain colons and valid IPv6 patterns
  // but not be an IPv4 address
  if (!value.includes(':')) return false;
  
  // IPv6 regex pattern (simplified but covers most common cases)
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b|\b::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/;
  
  // Check if IPv6 pattern exists
  const ipv6Match = value.match(ipv6Regex);
  if (!ipv6Match) return false;
  
  // Make sure it's not an IPv4 address
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  const ipv4Match = value.match(ipv4Regex);
  
  // If both patterns match, check if the IPv6 match is truly IPv6 and not IPv4
  if (ipv6Match && ipv4Match) {
    // The IPv6 match should contain colons, and not be part of IPv4
    const ipv6Text = ipv6Match[0];
    const ipv4Text = ipv4Match[0];
    
    // If they're identical, it's an IPv4 address detected as IPv6
    if (ipv6Text === ipv4Text) return false;
    
    // If the IPv6 match doesn't contain colons, it's not a true IPv6
    if (!ipv6Text.includes(':')) return false;
  }
  
  return true;
}