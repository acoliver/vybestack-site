/**
 * Email validation
 * Accept typical addresses such as name+tag@example.co.uk
 * Reject double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  if (!emailRegex.test(value)) return false;
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@.') || value.includes('.@')) return false;
  if (value.substring(value.indexOf('@')).includes('_')) return false;
  
  return true;
}

/**
 * US Phone Number validation
 * Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallow impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: { allowCountryCode?: boolean }): boolean {
  // Remove spaces, hyphens, and parentheses
  const digits = value.replace(/[^\d]/g, '');
  
  // Check if country code is present (optional)
  if (digits.startsWith('1')) {
    if (!options?.allowCountryCode && !value.startsWith('+1')) {
      return false; // Country code present but not allowed
    }
  }
  
  // Clean up digits for validation
  const cleanDigits = digits.startsWith('1') ? digits.substring(1) : digits;
  
  // Must be exactly 10 digits
  if (cleanDigits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  if (cleanDigits[0] === '0' || cleanDigits[0] === '1') return false;
  
  // Check valid format
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)?\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Argentine Phone Number validation
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentina phone numbers must be at least 8 digits
  if (cleaned.length < 8) return false;
  
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  let remaining = cleaned;
  
  // Check for country code (+54)
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Check for mobile prefix (9)
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Check for trunk prefix (0)
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.substring(1);
  }
  
  // Trunk prefix is required if no country code
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // Try to split remaining digits into area code and subscriber number
  // Area code: 2-4 digits (not starting with 0)
  // Subscriber: 6-8 digits
  for (let areaCodeLen = 2; areaCodeLen <= 4; areaCodeLen++) {
    if (remaining.length >= areaCodeLen + 6 && remaining.length <= areaCodeLen + 8) {
      const possibleAreaCode = remaining.substring(0, areaCodeLen);
      
      // Area code cannot start with 0
      if (possibleAreaCode[0] !== '0') {
        // Valid pattern found
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Name validation
 * Permit unicode letters, accents, apostrophes, hyphens, spaces
 * Reject digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Regex for valid names: unicode letters (including accented), apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}''-]+(?:[\s][\p{L}\p{M}''-]+)*$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Ensure we have at least one letter
  const containsLetter = /[\p{L}\p{M}]/u.test(value);
  if (!containsLetter) return false;
  
  // X Æ A-12 type names contain digits, which we already reject
  return true;
}

/**
 * Credit Card validation
 * Accept Visa/Mastercard/AmEx prefixes and lengths
 * Run a Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(digits)) return false;
  
  // Check Visa (13 or 16 digits, starts with 4)
  if (/^4\d{12}(?:\d{3})?$/.test(digits)) {
    return luhnCheck(digits);
  }
  
  // Check Mastercard (16 digits, starts with 51-55 or 2221-2720)
  if (/^(5[1-5]\d{14}|2[2-7]2\d{13}|2[3-6]3\d{13}|2[4-7]4\d{13}|2[5-7]5\d{13}|262\d{12}|27[01]\d{12}|2720\d{11})$/.test(digits)) {
    return luhnCheck(digits);
  }
  
  // Check AmEx (15 digits, starts with 34 or 37)
  if (/^3[47]\d{13}$/.test(digits)) {
    return luhnCheck(digits);
  }
  
  return false;
}

/**
 * Luhn algorithm helper for credit card validation
 */
function luhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return (sum % 10) === 0;
}