#!/usr/bin/env node

import { writeFile } from 'node:fs/promises';
import { createMarkdownFormatter, createTextFormatter } from '../formats/index.js';
import { parseArgs } from '../args.js';
import { readReportData } from '../utils.js';

/**
 * Main CLI entry point
 */
async function main() {
  try {
    // Process arguments (skip the first two: node and script path)
    const args = process.argv.slice(2);
    
    // Get the JSON file path (first non-flag argument)
    const filePath = args.find(arg => !arg.startsWith('--'));
    if (!filePath) {
      console.error('Error: Missing JSON file path');
      process.exit(1);
    }

    // Parse CLI options
    const options = parseArgs(args);
    
    // Validate format
    if (options.format !== 'markdown' && options.format !== 'text') {
      console.error('Error: Unsupported format. Supported formats: markdown, text');
      process.exit(1);
    }
    
    // Read and validate report data
    const reportData = await readReportData(filePath);
    
    // Select formatter
    const formatter = options.format === 'markdown' 
      ? createMarkdownFormatter() 
      : createTextFormatter();
    
    // Generate report
    const output = formatter.render(reportData, { includeTotals: !!options.includeTotals });
    
    // Write output
    if (options.output) {
      await writeFile(options.output, output, 'utf-8');
      console.log(`Report written to ${options.output}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

// Run the CLI
await main();
