import { readFile } from 'node:fs/promises';
import { ReportData } from './types.js';

/**
 * Reads and validates JSON data from a file path.
 */
export async function readReportData(filePath: string): Promise<ReportData> {
  try {
    const fileContent = await readFile(filePath, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Basic validation
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON data: not an object');
    }
    
    const reportData = data as ReportData;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid title');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid summary');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid entries array');
    }
    
    // Validate each entry
    for (const entry of reportData.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid report data: entry missing label');
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error('Invalid report data: entry missing valid amount');
      }
    }
    
    return reportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Malformed JSON in file: ${filePath}`);
    }
    throw error;
  }
}

/**
 * Calculate the total of all amounts in the report entries.
 */
export function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

/**
 * Format a number as currency with two decimal places.
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}