import { CliOptions } from './types.js';

/**
 * Parse CLI arguments using Node's standard library
 */
export function parseArgs(args: string[]): CliOptions {
  const options: CliOptions = {
    format: '',
  };

  // Parse flags
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg || nextArg.startsWith('--')) {
        throw new Error('Missing format value after --format');
      }
      options.format = nextArg;
      i++; // Skip the next argument since we processed it
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg || nextArg.startsWith('--')) {
        throw new Error('Missing output path after --output');
      }
      options.output = nextArg;
      i++; // Skip the next argument since we processed it
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  if (!options.format) {
    throw new Error('Missing required --format option');
  }
  
  return options;
}