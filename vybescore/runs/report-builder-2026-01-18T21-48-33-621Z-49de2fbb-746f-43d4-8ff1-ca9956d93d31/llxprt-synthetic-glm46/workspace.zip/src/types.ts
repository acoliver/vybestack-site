/**
 * Defines the structure for report data and CLI options
 */

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CliOptions {
  format: string;
  output?: string;
  includeTotals?: boolean;
}