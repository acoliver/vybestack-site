import { ReportData } from '../types.js';
import { formatCurrency, calculateTotal } from '../utils.js';

export interface Formatter {
  render: (data: ReportData, options: { includeTotals: boolean }) => string;
}

export function createMarkdownFormatter(): Formatter {
  return {
    render(data, options) {
      let output = '';
      
      // Title
      output += `# ${data.title}\n\n`;
      
      // Summary
      output += `${data.summary}\n\n`;
      
      // Entries
      output += `## Entries\n`;
      for (const entry of data.entries) {
        output += `- **${entry.label}** — ${formatCurrency(entry.amount)}\n`;
      }
      
      // Total if requested
      if (options.includeTotals) {
        const total = calculateTotal(data.entries);
        output += `\n**Total:** ${formatCurrency(total)}\n`;
      }
      
      return output;
    }
  };
}

export function createTextFormatter(): Formatter {
  return {
    render(data, options) {
      let output = '';
      
      // Title
      output += `${data.title}\n`;
      
      // Summary
      output += `${data.summary}\n`;
      
      // Entries
      output += `Entries:\n`;
      for (const entry of data.entries) {
        output += `- ${entry.label}: ${formatCurrency(entry.amount)}\n`;
      }
      
      // Total if requested
      if (options.includeTotals) {
        const total = calculateTotal(data.entries);
        output += `Total: ${formatCurrency(total)}\n`;
      }
      
      return output;
    }
  };
}