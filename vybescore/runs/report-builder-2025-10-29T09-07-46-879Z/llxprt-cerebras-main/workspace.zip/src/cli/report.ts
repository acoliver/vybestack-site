#!/usr/bin/env node

import { readFileSync } from 'fs';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Import formatters
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(): { dataFile: string; options: ReportOptions } {
  const args = process.argv.slice(2);
  const options: ReportOptions = {
    format: 'text',
    includeTotals: false,
  };

  let dataFile: string | null = null;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      if (dataFile) {
        throw new Error('Only one data file can be specified');
      }
      dataFile = arg;
      continue;
    }

    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('Missing format value');
        }
        const format = args[++i] as 'markdown' | 'text';
        if (!['markdown', 'text'].includes(format)) {
          throw new Error(`Unsupported format: ${format}`);
        }
        options.format = format;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('Missing output value');
        }
        options.output = args[++i];
        break;
      case '--includeTotals':
        options.includeTotals = true;
        break;
      default:
        throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!dataFile) {
    throw new Error('Data file must be specified');
  }

  return { dataFile, options };
}

function validateData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON structure');
  }

  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid title field');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid summary field');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid entries field');
  }
  
  for (const [index, entry] of reportData.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}`);
    }
    
    const reportEntry = entry as Record<string, unknown>;
    
    if (typeof reportEntry.label !== 'string') {
      throw new Error(`Missing or invalid label in entry at index ${index}`);
    }
    
    if (typeof reportEntry.amount !== 'number') {
      throw new Error(`Missing or invalid amount in entry at index ${index}`);
    }
  }
}

function main() {
  try {
    const { dataFile, options } = parseArgs();
    
    // Read data file
    const rawData = readFileSync(dataFile, 'utf-8');
    const data: unknown = JSON.parse(rawData);
    
    // Validate data
    validateData(data);
    
    // Render report
    const formatter = formatters[options.format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${options.format}`);
    }
    
    const output = formatter(data, options);
    
    // Write output
    if (options.output) {
      // In a real implementation we'd write to the file
      // For now we'll just print to stdout as specified in the requirements
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('An unexpected error occurred');
      process.exit(1);
    }
  }
}

main();