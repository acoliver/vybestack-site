import type { Formatter } from '../types.js';
import { calculateTotal, formatCurrency, type ReportData, type RenderOptions } from '../types.js';

/**
 * Renders a report in Markdown format
 *
 * Format:
 * # <title>
 * <blank line>
 * <summary>
 * <blank line>
 * ## Entries
 * - **<label>** — $<amount>
 * ...
 * **Total:** $<amount> (if includeTotals is true)
 */
export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatCurrency(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatCurrency(total)}`);
  }

  return lines.join('\n');
}

// Export the formatter implementation
export const markdownFormatter: Formatter = {
  render: renderMarkdown,
};
