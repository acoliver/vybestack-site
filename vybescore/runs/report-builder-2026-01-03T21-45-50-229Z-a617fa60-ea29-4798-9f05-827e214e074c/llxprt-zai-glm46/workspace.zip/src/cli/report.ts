#!/usr/bin/env node

import * as fs from 'node:fs';

import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import { type RenderOptions, type ReportData, validateReportData } from '../types.js';

/**
 * CLI argument parsing result
 */
interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parses CLI arguments from process.argv
 * Expected format: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 3) {
    printUsage();
    process.exit(1);
  }

  // Skip node executable and script path
  const positional: string[] = [];
  const flags: Record<string, string | boolean> = {};

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];

    if (arg.startsWith('--')) {
      const flagName = arg.slice(2);
      const nextArg = args[i + 1];

      // Check if this is a flag with a value (next arg doesn't start with --)
      if (nextArg !== undefined && !nextArg.startsWith('--')) {
        flags[flagName] = nextArg;
        i++; // Skip next arg as we consumed it
      } else {
        // Boolean flag
        flags[flagName] = true;
      }
    } else {
      positional.push(arg);
    }
  }

  // First positional argument should be the input file
  const inputFile = positional[0];
  if (!inputFile) {
    console.error('Error: Missing input file path');
    printUsage();
    process.exit(1);
  }

  // Required flags
  const format = flags.format;
  if (typeof format !== 'string') {
    console.error('Error: --format flag is required and must specify a format');
    printUsage();
    process.exit(1);
  }

  // Optional flags
  const outputPath = typeof flags.output === 'string' ? flags.output : null;
  const includeTotals = flags.includeTotals === true;

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Prints usage information
 */
function printUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [options]');
  console.error('');
  console.error('Arguments:');
  console.error('  data.json       Path to the JSON file containing report data');
  console.error('');
  console.error('Options:');
  console.error('  --format <fmt>  Output format (required): markdown, text');
  console.error('  --output <path> Write output to file instead of stdout (optional)');
  console.error('  --includeTotals Include total sum of all entries (optional)');
  console.error('');
  console.error('Example:');
  console.error('  node dist/cli/report.js fixtures/data.json --format markdown --includeTotals');
}

/**
 * Gets the formatter for the specified format
 */
function getFormatter(format: string) {
  const formatters: Record<string, { render: (data: ReportData, options: RenderOptions) => string }> =
    {
      markdown: markdownFormatter,
      text: textFormatter,
    };

  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return formatter;
}

/**
 * Main CLI entry point
 */
function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Read and parse the input file
    let inputData: unknown;
    try {
      const inputContent = fs.readFileSync(args.inputFile, 'utf-8');
      inputData = JSON.parse(inputContent);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        console.error(`Error: Input file not found: ${args.inputFile}`);
        process.exit(1);
      }
      if ((error as SyntaxError).name === 'SyntaxError') {
        console.error(`Error: Invalid JSON in input file: ${args.inputFile}`);
        console.error((error as SyntaxError).message);
        process.exit(1);
      }
      throw error;
    }

    // Validate the report data
    let reportData: ReportData;
    try {
      reportData = validateReportData(inputData);
    } catch (error) {
      console.error(`Error: ${(error as Error).message}`);
      process.exit(1);
    }

    // Get the appropriate formatter
    let formatter: { render: (data: ReportData, options: RenderOptions) => string };
    try {
      formatter = getFormatter(args.format);
    } catch (error) {
      console.error(`Error: ${(error as Error).message}`);
      process.exit(1);
    }

    // Render the report
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter.render(reportData, options);

    // Write output
    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Failed to write output to ${args.outputPath}`);
        console.error((error as Error).message);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Unexpected error: ${(error as Error).message}`);
    process.exit(1);
  }
}

// Run the CLI
main();
