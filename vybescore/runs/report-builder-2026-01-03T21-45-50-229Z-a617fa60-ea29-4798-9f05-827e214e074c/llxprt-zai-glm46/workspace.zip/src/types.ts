/**
 * Report data model matching the JSON schema from fixtures/data.json
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering reports
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Formatter interface - all formatters must implement this
 */
export interface Formatter {
  render(data: ReportData, options: RenderOptions): string;
}

/**
 * Validates and parses report data from a JSON object
 */
export function validateReportData(obj: unknown): ReportData {
  if (typeof obj !== 'object' || obj === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const data = obj as Record<string, unknown>;

  if (typeof data.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof data.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(data.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  const entries: ReportEntry[] = [];
  for (const [index, entry] of data.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid entry at index ${index}: missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid entry at index ${index}: missing or invalid "amount" field (expected number)`
      );
    }

    entries.push({ label: entryObj.label, amount: entryObj.amount });
  }

  return { title: data.title, summary: data.summary, entries };
}

/**
 * Formats a number as currency with exactly 2 decimal places
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total sum of all entry amounts
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}
