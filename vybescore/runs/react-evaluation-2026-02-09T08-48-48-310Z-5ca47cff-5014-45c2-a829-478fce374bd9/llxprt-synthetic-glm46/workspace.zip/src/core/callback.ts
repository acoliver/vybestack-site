/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  function disposeObserver(observer: Observer<T>) {
    observer._disposed = true
    // Clear all dependencies
    if (observer.subjects) {
      for (const dep of observer.subjects) {
        dep.observers.delete(observer)
      }
    }
  }
  
  const observer: Observer<T> = {
    value,
    dependencies: new Set(),
    subjects: new Set(),
    updateFn: (prevValue?: T) => {
      if (observer._disposed) return prevValue as T
      return updateFn(prevValue)
    },
    _disposed: false
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (observer._disposed) return
    disposeObserver(observer)
  }
}
