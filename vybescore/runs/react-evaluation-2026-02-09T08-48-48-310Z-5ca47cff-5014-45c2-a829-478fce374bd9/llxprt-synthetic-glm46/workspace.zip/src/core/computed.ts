/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  trackDependency,
  createSubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is :
    equal === false ? undefined :
    equal === undefined ? undefined :
    typeof equal === 'function' ? equal : undefined

  const o: Observer<T> = {
    name: options?.name,
    dependencies: new Set(),
    subjects: new Set(),
    value,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue)
      
      if (equalFn && o.value !== undefined && equalFn(o.value, newValue)) {
        return o.value
      }
      
      o.value = newValue
      return newValue
    },
    _disposed: false
  }
  
  // Create a subject wrapper for the computed value to manage observers  
  const computedSubject = createSubject(o.value!, equalFn)
  
  // Perform initial computation to establish dependencies
  updateObserver(o)
  
  // Return getter function
  const getter: GetterFn<T> = () => {
    // Track this computed value as a dependency of the active observer
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      trackDependency(computedSubject)
      
      // Add this observer to the computed subject's observers
      computedSubject.observers.add(activeObserver)
      
      // Link the computed observer to its dependencies
      o.subjects.forEach(subject => {
        if (subject !== computedSubject) {
          activeObserver.subjects.add(subject)
          subject.observers.add(activeObserver)
        }
      })
    }
    
    return o.value!
  }
  
  // When the computed value updates, notify its observers and recompute
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    
    // Update the subject's value
    computedSubject.value = o.value!
    
    // Notify all dependent observers
    for (const obs of computedSubject.observers) {
      if (!obs._disposed) {
        // Update the observer's dependencies to include the computed value's dependencies
        o.subjects.forEach(subject => {
          obs.subjects.add(subject)
          subject.observers.add(obs)
        })
      }
    }
    
    return result
  }
  
  return getter
}
