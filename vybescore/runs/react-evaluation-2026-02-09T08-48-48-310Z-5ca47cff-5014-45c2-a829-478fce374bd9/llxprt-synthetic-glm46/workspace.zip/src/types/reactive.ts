/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _disposed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies: Set<Subject<any>>
  subjects: Set<Subject<any>> // Subjects that this observer depends on
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined
let runningUpdates = false

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function createSubject<T>(value: T, equalFn?: EqualFn<T>): Subject<T> {
  return {
    name: undefined,
    observers: new Set(),
    value,
    equalFn
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (runningUpdates || observer._disposed) return
  runningUpdates = true
  
  // Clear previous subjects this observer depends on
  if (observer.subjects) {
    const previousSubjects = new Set(observer.subjects)
    for (const subject of previousSubjects) {
      subject.observers.delete(observer)
    }
    observer.subjects.clear()
  }
  
  const previous = activeObserver
  activeObserver = observer
  
  try {
    // Update dependency tracking will happen through trackDependency calls
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    runningUpdates = false
  }
}

export function trackDependency(subject: Subject<any>): void {
  if (activeObserver && !activeObserver.subjects.has(subject)) {
    activeObserver.subjects.add(subject)
    subject.observers.add(activeObserver)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (runningUpdates) return
  
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    if (!observer._disposed) {
      updateObserver(observer)
    }
  }
}
