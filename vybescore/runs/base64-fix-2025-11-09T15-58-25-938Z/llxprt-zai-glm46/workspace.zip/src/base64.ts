/**
 * Encode plain text to Base64 using standard RFC 4648 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace characters from the input
  const cleanedInput = input.replace(/\s/g, '');
  
  // Check for valid Base64 characters only
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleanedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check that padding is correct if present
  const paddingCount = (cleanedInput.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Check that padding only appears at the end
  if (cleanedInput.includes('=') && !cleanedInput.match(/=+$/)) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }
  
  // Check that the total length is valid
  if (cleanedInput.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    return Buffer.from(cleanedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
