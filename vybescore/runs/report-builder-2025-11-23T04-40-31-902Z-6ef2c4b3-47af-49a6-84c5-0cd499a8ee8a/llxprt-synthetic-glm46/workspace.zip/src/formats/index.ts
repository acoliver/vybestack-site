import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type { ReportData, RenderOptions };

export interface Formatter {
  render: (data: ReportData, options?: RenderOptions) => string;
}

export const formatters: Record<string, Formatter> = {
  markdown: { render: renderMarkdown },
  text: { render: renderText },
};

export function isValidFormat(format: string): boolean {
  return format in formatters;
}

export function renderReport(
  data: ReportData,
  format: string,
  options: RenderOptions = {}
): string {
  if (!isValidFormat(format)) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return formatters[format].render(data, options);
}