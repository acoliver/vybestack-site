#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, CLIOptions } from '../types.js';
import { renderReport } from '../formats/index.js';

// Parse command line arguments
function parseArguments(): { dataPath: string; options: CLIOptions } {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  const options: CLIOptions = {
    format: '',
    output: undefined,
    includeTotals: false,
  };

  // Parse options
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown option: ${arg}`);
      process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, options };
}

// Read and parse JSON data
function readDataFile(path: string): ReportData {
  try {
    const fileContent = readFileSync(path, 'utf8');
    const data = JSON.parse(fileContent);

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field (must be a string)');
    }

    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field (must be a string)');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field (must be an array)');
    }

    // Validate entries
    data.entries.forEach((entry: unknown, index: number) => {
      const entryObj = entry as Record<string, unknown>;

      if (typeof entryObj.label !== 'string') {
        throw new Error(`Entry ${index}: Missing or invalid "label" field (must be a string)`);
      }

      if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
        throw new Error(`Entry ${index}: Missing or invalid "amount" field (must be a number)`);
      }
    });

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: ${String(error)}`);
    }
    process.exit(1);
  }
}

// Main execution
function main(): void {
  const { dataPath, options } = parseArguments();

  const data = readDataFile(dataPath);

  try {
    const report = renderReport(data, options.format, {
      includeTotals: options.includeTotals,
    });

    if (options.output) {
      writeFileSync(options.output, report);
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    }
  }
}

main();