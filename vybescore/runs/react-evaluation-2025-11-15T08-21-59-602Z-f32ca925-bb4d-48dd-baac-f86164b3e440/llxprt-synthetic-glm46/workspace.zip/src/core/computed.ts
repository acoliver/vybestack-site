/**
 * Computed closure implementation for derived values.
 */

import { 
  Subject,
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  addObserverToSubject,
  EqualFn
} from '../types/reactive.js'

// Set to track which observers are currently recomputeing to prevent infinite recursion 
const recomputeStack = new Set<string>();

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const name = options?.name || `computed_${Math.random().toString(36).substr(2, 9)}`
  
  const s: Subject<T> = {
    name,
    observers: new Set(),
    value: value as T,
    equalFn: typeof equal === 'function' ? equal 
            : equal === false ? undefined
            : equal === true ? ((a: T, b: T) => a === b)
            : undefined,
  }
  
  const observer: Observer<T> = {
    name,
    value,
    updateFn,
    subjects: new Set(),
  }

  const computeValue = (): T => {
    // Skip recomputation if already in recompute stack to prevent infinite recursion
    if (recomputeStack.has(name)) {
      return s.value
    }

    recomputeStack.add(name)
    try {
      const previous = getActiveObserver()
      setActiveObserver(observer as Observer<unknown>)
      
      // Clear current dependencies
      observer.subjects!.clear()
      
      try {
        const newValue = updateFn(observer.value as T)
        
        // Update if changed
        if (!s.equalFn || !s.equalFn(s.value, newValue)) {
          s.value = newValue
          observer.value = newValue
          
          // When computed value changes, notify observers (callbacks, etc.)
          notifyObservers(s as Subject<unknown>)
        }
        
        return s.value
      } finally {
        setActiveObserver(previous)
      }
    } finally {
      recomputeStack.delete(name)
    }
  }

  // Initial computation if needed
  if (s.value === undefined) {
    computeValue()
  }

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addObserverToSubject(s as Subject<unknown>, activeObserver)
    }
    
    // Always recompute on access
    return computeValue()
  }

  return getter
}