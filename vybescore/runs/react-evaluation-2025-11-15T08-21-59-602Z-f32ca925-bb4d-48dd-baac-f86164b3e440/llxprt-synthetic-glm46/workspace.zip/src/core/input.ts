/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  addObserverToSubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal 
            : equal === false ? undefined
            : equal === true ? ((a: T, b: T) => a === b)
            : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserverToSubject(s as Subject<unknown>, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue: T): T => {
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      notifyObservers(s as Subject<unknown>)
    }
    return nextValue
  }

  return [read, write]
}