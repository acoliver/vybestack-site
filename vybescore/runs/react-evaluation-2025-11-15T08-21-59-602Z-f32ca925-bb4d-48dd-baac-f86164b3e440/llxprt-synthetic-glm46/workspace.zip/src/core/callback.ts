/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set(),
  }
  
  let disposed = false
  
  const runCallback = () => {
    if (disposed) return
    
    // Clear current dependencies
    observer.subjects!.clear()
    
    const previous = getActiveObserver()
    setActiveObserver(observer as Observer<unknown>)
    
    try {
      observer.value = updateFn(observer.value as T) as T
      
      // During execution, other reactive primitives accessed will register this observer
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Execute immediately to establish dependencies
  runCallback()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it was observing
    if (observer.subjects) {
      for (const subject of observer.subjects) {
        subject.observers.delete(observer as Observer<unknown>)
      }
      observer.subjects.clear()
    }
  }
}