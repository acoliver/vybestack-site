/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: Set<Subject<unknown>> // Track subjects this observer depends on
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value) as T
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  // Create a copy to avoid issues with observers being added/removed during iteration
  const observersCopy = Array.from(subject.observers)
  for (const observer of observersCopy) {
    // Only notify if active observer is not this observer (prevent infinite loops)
    if (getActiveObserver() !== observer) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}

export function addObserverToSubject(subject: Subject<unknown>, observer: Observer<unknown>): void {
  subject.observers.add(observer)
  if (!observer.subjects) {
    observer.subjects = new Set()
  }
  observer.subjects.add(subject)
}