#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { Format, ReportData, ReportOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseCliArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: Format = 'markdown';
  let output: string | undefined = undefined;
  let includeTotals = false;

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatArg = args[i];
      if (formatArg === 'markdown' || formatArg === 'text') {
        format = formatArg;
      } else {
        console.error(`Unsupported format: ${formatArg}`);
        process.exit(1);
      }
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return { dataFile, format, output, includeTotals };
}

function main() {
  try {
    const { dataFile, format, output, includeTotals } = parseCliArgs();

    // Read and validate data file
    let data: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing file ${dataFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }

    // Validate report data
    const reportData: ReportData = validateReportData(data);

    // Setup format renderers
    const renderers = {
      markdown: renderMarkdown,
      text: renderText,
    };

    // Generate report
    const renderer = renderers[format];
    const options: ReportOptions = { includeTotals };
    const reportOutput = renderer.render(reportData, options);

    // Output report
    if (output) {
      try {
        writeFileSync(output, reportOutput, 'utf-8');
      } catch (error) {
        console.error(`Error writing to file ${output}: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(reportOutput);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
