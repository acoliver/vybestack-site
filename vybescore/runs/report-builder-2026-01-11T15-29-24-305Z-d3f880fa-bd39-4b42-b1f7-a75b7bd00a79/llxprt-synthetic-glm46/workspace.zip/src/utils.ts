import type { ReportData } from './types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string' || !obj.title) {
    throw new Error('Invalid report data: missing or invalid title');
  }

  if (typeof obj.summary !== 'string' || !obj.summary) {
    throw new Error('Invalid report data: missing or invalid summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i] as Record<string, unknown>;
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }

    if (typeof entry.label !== 'string' || !entry.label) {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
    }

    if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
    }
  }

  return data as ReportData;
}