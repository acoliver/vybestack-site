import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

export const renderMarkdown: ReportRenderer = {
  render(data: ReportData, options: ReportOptions): string {
    const lines: string[] = [];

    // Add title
    lines.push(`# ${data.title}`);

    // Add blank line
    lines.push('');

    // Add summary
    lines.push(data.summary);

    // Add blank line
    lines.push('');

    // Add entries heading
    lines.push('## Entries');

    // Add entries list
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
    }

    // Add total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`**Total:** $${total.toFixed(2)}`);
    }

    return lines.join('\n');
  },
};