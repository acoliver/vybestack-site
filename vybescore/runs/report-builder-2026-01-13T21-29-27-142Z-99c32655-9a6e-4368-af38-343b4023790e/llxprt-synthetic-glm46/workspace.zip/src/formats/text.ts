import type { ReportData, RenderOptions, RenderResult } from '../types/index.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function renderText(data: ReportData, options: RenderOptions = {}): RenderResult {
  const { includeTotals = false } = options;
  
  const lines: string[] = [];
  
  lines.push(data.title);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('Entries:');
  
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: ${formatAmount(total)}`);
  }
  
  return {
    content: lines.join('\n'),
    total: includeTotals ? data.entries.reduce((sum, entry) => sum + entry.amount, 0) : undefined
  };
}