#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportFormat, RenderOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): { dataFile: string; format: ReportFormat; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as ReportFormat;
  
  if (!['markdown', 'text'].includes(format)) {
    console.error('Unsupported format');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    return false;
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments();
    
    let fileContent: string;
    try {
      fileContent = readFileSync(dataFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file '${dataFile}'`);
      process.exit(1);
    }
    
    let parsedData: unknown;
    try {
      parsedData = JSON.parse(fileContent);
    } catch (error) {
      console.error('Error: Invalid JSON format');
      process.exit(1);
    }
    
    if (!validateReportData(parsedData)) {
      console.error('Error: Invalid report data structure');
      process.exit(1);
    }
    
    const options: RenderOptions = { includeTotals };
    let result;
    
    switch (format) {
      case 'markdown':
        result = renderMarkdown(parsedData, options);
        break;
      case 'text':
        result = renderText(parsedData, options);
        break;
    }
    
    if (outputPath) {
      writeFileSync(outputPath, result.content);
    } else {
      console.log(result.content);
    }
  } catch (error) {
    console.error('An unexpected error occurred:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
