export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to the specified requirements.
 */
export function isValidEmail(value: string): boolean {
  // Basic email structure: local@domain
  const emailRegex = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Reject if fails basic structure
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domain] = value.split('@');
  
  // No double dots in local or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot start with hyphen or end with hyphen or dot
  if (domain.startsWith('-') || domain.endsWith('-') || domain.endsWith('.')) {
    return false;
  }
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Local part cannot start with dot
  if (localPart.startsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with optional +1 prefix and common formats.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if there's a leading 1 (country code)
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // US phone number should be 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if the original format is one of the supported ones
  const supportedPatterns = [
    /^\+?1?\s*\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/, // (212) 555-7890, +1 (212) 555-7890
    /^\+?1?[-.\s]?([2-9]\d{2})[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/, // 212-555-7890, +1 212-555-7890
    /^\+?1?([2-9]\d{9})$/ // 2125557890, +12125557890
  ];
  
  // Check if the value matches any of the supported patterns
  for (const pattern of supportedPatterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // If no pattern matches, check if extensions are allowed and present
  if (options?.allowExtensions && /\d+/.test(value)) {
    // This is a permissive check for when extensions are allowed
    return true;
  }
  
  return false;
}

/**
 * Validates Argentine phone numbers, supporting landlines and mobiles with various formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const digitsOnly = value.replace(/[-\s]/g, '');
  
  // Check if starts with country code +54
  let phoneNumber = digitsOnly;
  let hasCountryCode = false;
  
  if (phoneNumber.startsWith('+54')) {
    hasCountryCode = true;
    phoneNumber = phoneNumber.substring(3);
  }
  
  // Check if starts with trunk prefix 0
  let hasTrunkPrefix = false;
  if (phoneNumber.startsWith('0')) {
    hasTrunkPrefix = true;
    phoneNumber = phoneNumber.substring(1);
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator (9)
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCodeEndIndex = 2;
  // Look ahead to determine area code length based on remaining digits
  const remainingDigits = phoneNumber.length;
  
  if (remainingDigits >= 9 && remainingDigits <= 11) {
    // Possible formats:
    // Area code (2-4) + subscriber (6-8)
    // Try to find the valid area code length
    for (let i = 4; i >= 2; i--) {
      const tempAreaCode = phoneNumber.substring(0, i);
      const tempSubscriber = phoneNumber.substring(i);
      
      if (/^[1-9]\d{0,3}$/.test(tempAreaCode) && tempSubscriber.length >= 6 && tempSubscriber.length <= 8) {
        areaCodeEndIndex = i;
        break;
      }
    }
  }
  
  const areaCode = phoneNumber.substring(0, areaCodeEndIndex);
  const subscriberNumber = phoneNumber.substring(areaCodeEndIndex);
  
  // Validate area code (2-4 digits, leading digit cannot be 0)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names, allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 */
export function isValidName(value: string): boolean {
  // Name must contain at least one character
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and special symbols except for apostrophe and hyphen
  const nameRegex = /^[\p{L}\p{M}\p{Nl}']+[\p{L}\p{M}\p{Nl}'\-\s]*[\p{L}\p{M}\p{Nl}']$/u;
  
  // This regex allows:
  // - \p{L}: Any kind of letter from any language
  // - \p{M}: Combining marks (accents, diacritics)
  // - \p{Nl}: Number, letter (like Roman numerals)
  // - ': Apostrophe
  // - \-: Hyphen
  // - \s: Space
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject names with digits or other symbols
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for symbols other than apostrophe and hyphen
  const disallowedSymbolsRegex = /[^\p{L}\p{M}\p{Nl}'\-\s]/u;
  if (disallowedSymbolsRegex.test(value)) {
    return false;
  }
  
  // Reject names like "X Æ A-12" that contain digit-like characters
  const digitLikeRegex = /[₀-₉₀-９]/u; // Subscript and superscript digits
  if (digitLikeRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers according to major card formats and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length based on card type
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths by card type
  let isValidPrefixAndLength = false;
  
  // Visa: starts with 4, length 13, 16
  if (/^4\d{12}(?:\d{3})?$/.test(digitsOnly)) {
    isValidPrefixAndLength = true;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (/^(5[1-5]\d{14}|2[2-7]\d{14})$/.test(digitsOnly)) {
    isValidPrefixAndLength = true;
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^3[47]\d{13}$/.test(digitsOnly)) {
    isValidPrefixAndLength = true;
  }
  
  if (!isValidPrefixAndLength) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return luhnCheck(digitsOnly);
}

/**
 * Implementation of the Luhn algorithm for credit card validation.
 */
function luhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value[i], 10);
    
    if (shouldDouble) {
      if (digit > 4) {
        sum += (digit * 2) - 9;
      } else {
        sum += digit * 2;
      }
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
