/**
 * Capitalizes the first character of each sentence, with proper spacing between sentences.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence-ending punctuation
  // Replace patterns like "word. word" or "word!word" with "word. word"
  result = result.replace(/([.!?])(?=[A-Za-z0-9])/g, '$1 ');
  
  // Now handle sentence capitalization
  // Split the text into potential sentences
  const sentences: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < result.length; i++) {
    const char = result[i];
    
    currentSentence += char;
    
    // Check if this character ends a sentence
    if (char === '.' || char === '!' || char === '?') {
      // Look ahead to see if this is really the end of a sentence
      // If the next character is a space or end of string, it's likely a sentence end
      const nextChar = result[i + 1];
      if (!nextChar || nextChar === ' ') {
        // Handle abbreviations like "Mr.", "Dr.", "e.g.", "i.e."
        const wordsInSentence = currentSentence.split(' ');
        const lastWord = wordsInSentence[wordsInSentence.length - 1];
        
        // Common abbreviations (not exhaustive)
        const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'e.g.', 'i.e.', 'etc.', 'vs.', 'al.'];
        
        // If it doesn't look like an abbreviation, it's likely a sentence end
        if (!abbreviations.includes(lastWord) || wordsInSentence.length > 1) {
          sentences.push(currentSentence);
          currentSentence = '';
          
          // Skip any space after the punctuation
          while (result[i + 1] === ' ') {
            i++;
            currentSentence += result[i];
          }
        }
      }
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence);
  }
  
  // Capitalize each sentence and rejoin them
  result = sentences.map(sentence => {
    if (!sentence.trim()) return sentence;
    
    // Find the first alphabetical character and capitalize it
    for (let i = 0; i < sentence.length; i++) {
      if (/[a-zA-Z]/.test(sentence[i])) {
        return sentence.substring(0, i) + sentence[i].toUpperCase() + sentence.substring(i + 1);
      }
    }
    return sentence;
  }).join('');
  
  // Clean up any remaining spacing issues
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  const urlRegex = /(?:https?:\/\/)?(?:[\w-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  // Array to store the extracted URLs
  const urls: string[] = [];
  
  // Find all URL matches in the text
  let match;
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // If no protocol is specified, add http:// as default
    if (!url.match(/^https?:\/\//)) {
      url = 'http://' + url;
    }
    
    // Remove trailing punctuation but keep valid URL characters
    url = url.replace(/[.,;:!?)\]\}]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Regular expression to match http:// URLs (but not https://)
  const httpUrlRegex = /http:\/\/(?:[\w-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  // Replace each http URL with https version
  return text.replace(httpUrlRegex, (match) => match.replace('http://', 'https://'));
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Regular expression to match http://example.com URLs with capturing groups
  const urlRegex = /(http:\/\/(example\.com)(\/[^\s]*))/g;
  
  return text.replace(urlRegex, (match, urlProtocol, hostname, path) => {
    // Always upgrade to HTTPS
    let newUrl = match.replace('http://', 'https://');
    
    // Check if the path starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Skip the host rewrite if path contains dynamic hints or legacy extensions
      const dynamicHints = /(cgi-bin|\?|\&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
      if (!dynamicHints.test(path)) {
        // Rewrite the host to docs.example.com
        newUrl = `https://docs.${hostname}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regular expression to match the date format mm/dd/yyyy
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  // Test if the value matches the expected format
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  // Extract month, day, and year
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string to preserve leading zeros if any
  
  // Additional validation for day based on month
  const validDays: Record<number, number> = {
    1: 31, // January
    2: isLeapYear(parseInt(year, 10)) ? 29 : 28, // February
    3: 31, // March
    4: 30, // April
    5: 31, // May
    6: 30, // June
    7: 31, // July
    8: 31, // August
    9: 30, // September
    10: 31, // October
    11: 30, // November
    12: 31  // December
  };
  
  // Check if the day is valid for the month
  if (day > validDays[month]) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to check if a year is a leap year.
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
