/**
 * Finds words starting with the given prefix, excluding the provided exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regular expression to find words starting with the prefix
  // \b ensures we start at a word boundary
  const prefixRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches in the text
  const matches = text.match(prefixRegex);
  
  if (!matches) {
    return [];
  }
  
  // Convert exceptions to lowercase and create a Set for efficient lookup
  const exceptionsSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Filter out the exceptions and return unique words
  const result = new Set<string>();
  
  for (const word of matches) {
    const wordLower = word.toLowerCase();
    if (!exceptionsSet.has(wordLower)) {
      result.add(word);
    }
  }
  
  return Array.from(result);
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all matches in the text
  const digitTokens: string[] = [];
  
  // Find all tokens that match pattern with preceding digit
  const regex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  let match;
  while ((match = regex.exec(text)) !== null) {
    // Add the match with the preceding digit
    digitTokens.push(match[1]);
  }
  
  return digitTokens;
}

/**
 * Validates passwords according to the policy: at least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length requirement (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-word character)
  if (!/[^\w]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // We'll use a backreference to detect sequences of 2+ characters that repeat immediately
  for (let i = 2; i <= value.length / 2; i++) {
    const repeatedPattern = new RegExp(`(.{${i}})\\1`);
    if (repeatedPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if the string contains an IPv4 address
  // IPv4 pattern: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  const isIPv4 = ipv4Pattern.test(value);
  
  // IPv6 pattern - check for various IPv6 formats including shorthand
  // This pattern handles:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed zeros: 2001:db8:85a3::8a2e:370:7334
  // - Shorthand: ::1
  // - IPv4 mapped IPv6: ::ffff:192.168.1.1
  
  // Look for IPv6-specific delimiters (:) that aren't part of time stamps or other constructs
  const ipv6Pattern = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|:([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|::/;
  
  // Check if the string contains an IPv6 address
  const hasIPv6 = ipv6Pattern.test(value);
  
  // Return true if it contains IPv6 but not IPv4
  return hasIPv6 && !isIPv4;
}