/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  scheduleUpdate
} from '../types/reactive.js'

import { registerObserverDependency } from './input.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed value
  const dependentObservers = new Set<Observer<T>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Wrap the updateFn to schedule dependent updates after computation
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    // Execute the update function
    const newValue = updateFn(prevValue)
    
    // Schedule all dependent observers for update (will be queued if in batch)
    dependentObservers.forEach(depObs => {
      scheduleUpdate(depObs)
    })
    
    return newValue
  }
  
  o.updateFn = wrappedUpdateFn
  
  // Initial computation
  updateObserver(o)
  
  const getter = (): T => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      const obs = activeObs as Observer<T>
      // Register the active observer as dependent on this computed
      if (!dependentObservers.has(obs)) {
        dependentObservers.add(obs)
        // Register this dependency so the observer can clean up later
        registerObserverDependency(obs, () => dependentObservers.delete(obs))
      }
    }
    return o.value!
  }
  
  return getter
}

