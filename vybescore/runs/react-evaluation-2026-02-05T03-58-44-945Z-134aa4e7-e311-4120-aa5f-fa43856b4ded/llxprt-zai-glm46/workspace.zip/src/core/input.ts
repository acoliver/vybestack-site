/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  beginUpdate,
  endUpdate
} from '../types/reactive.js'

// Registry to track which observers are registered with which inputs
// This allows callbacks to properly unsubscribe
const observerRegistry = new WeakMap<Observer<unknown>, Set<{
  remove: () => void
}>>()

export function registerObserverDependency<T>(
  observer: Observer<T>,
  removeFn: () => void
) {
  if (!observerRegistry.has(observer as Observer<unknown>)) {
    observerRegistry.set(observer as Observer<unknown>, new Set())
  }
  observerRegistry.get(observer as Observer<unknown>)!.add({ remove: removeFn })
}

export function unregisterAllObserverDependencies<T>(observer: Observer<T>) {
  const dependencies = observerRegistry.get(observer as Observer<unknown>)
  if (dependencies) {
    dependencies.forEach(dep => dep.remove())
    dependencies.clear()
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Track multiple observers using a Set
  const observers = new Set<Observer<T>>()
  
  const read: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      const obs = activeObs as Observer<T>
      if (!observers.has(obs)) {
        observers.add(obs)
        // Register this dependency so the observer can clean up later
        registerObserverDependency(obs, () => observers.delete(obs))
      }
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    value = nextValue
    // Begin a batch update
    beginUpdate()
    try {
      // Update all direct observers
      observers.forEach(obs => updateObserver(obs))
    } finally {
      // End batch update, which will trigger any pending dependent updates
      endUpdate()
    }
    return value
  }

  return [read, write]
}
