#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { formatters } from '../formats/index.js';

function parseArgs(argv: string[]): { dataFile: string; options: CliOptions } {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  const args = argv.slice(3);

  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      format = args[i + 1] as 'markdown' | 'text';
      if (!format || (format !== 'markdown' && format !== 'text')) {
        console.error(`Unsupported format`);
        process.exit(1);
      }
      i++; // Skip next argument since it's the format value
    } else if (arg === '--output') {
      output = args[i + 1];
      if (!output) {
        console.error('Error: --output requires a path argument');
        process.exit(1);
      }
      i++; // Skip next argument since it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format <format> is required');
    process.exit(1);
  }

  return { dataFile, options: { format, output, includeTotals } };
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (typeof data.title !== 'string' || !data.title.trim()) {
      throw new Error('Invalid or missing "title" field (must be non-empty string)');
    }

    if (typeof data.summary !== 'string' || !data.summary.trim()) {
      throw new Error('Invalid or missing "summary" field (must be non-empty string)');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing "entries" field (must be an array)');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string' || !entry.label.trim()) {
        throw new Error(`Invalid entry at index ${i}: "label" must be a non-empty string`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: "amount" must be a number`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found - ${filePath}`);
      } else if (error.message.includes('JSON.parse')) {
        console.error('Error: Invalid JSON file - malformed JSON');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load and validate data file');
    }
    process.exit(1);
  }
}

function main(): void {
  const { dataFile, options } = parseArgs(process.argv);
  const data = loadAndValidateData(dataFile);

  const formatter = formatters[options.format];
  const output = formatter(data, options);

  if (options.output) {
    try {
      writeFileSync(options.output, output);
    } catch (error) {
      console.error(`Error: Failed to write output file - ${options.output}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();