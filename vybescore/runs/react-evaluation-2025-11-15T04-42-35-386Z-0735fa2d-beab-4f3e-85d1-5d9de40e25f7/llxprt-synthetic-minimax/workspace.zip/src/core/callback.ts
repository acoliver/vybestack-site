/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create an observer that will execute the callback
  const observer: Observer<T> = {
    value,
    dependents: new Set(),
    updateFn: () => {
      if (disposed) return observer.value!
      
      // Execute the callback function and capture result
      // This will also track any dependencies accessed during execution
      const result = updateFn(observer.value)
      observer.value = result
      return result
    },
  }
  
  // Execute the callback once to set up dependencies and run the initial effect
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.updateFn = () => observer.value!
  }
}
