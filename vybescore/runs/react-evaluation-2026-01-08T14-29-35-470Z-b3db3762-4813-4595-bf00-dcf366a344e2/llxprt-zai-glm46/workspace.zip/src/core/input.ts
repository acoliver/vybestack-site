/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const dependentObservers: Observer<unknown>[] = []
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const obs = observer as Observer<unknown>
      // Track this observer so we can notify it when the value changes
      if (!dependentObservers.includes(obs)) {
        dependentObservers.push(obs)
      }
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = value !== nextValue
    value = nextValue
    
    // Notify all dependent observers by re-running their update functions
    if (hasChanged) {
      // Create a copy to avoid issues if the array is modified during iteration
      const toNotify = [...dependentObservers]
      for (const obs of toNotify) {
        updateObserver(obs)
      }
      
      // Also notify any observers of observers (transitive dependencies)
      for (const obs of toNotify) {
        const nestedObservers = obs.dependentObservers || []
        if (nestedObservers.length > 0) {
          const nestedToNotify = [...nestedObservers]
          for (const nestedObs of nestedToNotify) {
            updateObserver(nestedObs)
          }
        }
      }
    }
    
    return value
  }

  return [read, write]
}
