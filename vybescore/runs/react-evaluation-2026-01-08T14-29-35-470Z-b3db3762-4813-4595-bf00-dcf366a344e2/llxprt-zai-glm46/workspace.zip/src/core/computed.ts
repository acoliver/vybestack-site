/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store whether we're currently computing to avoid infinite recursion
  let computing = false
  let hasComputed = false
  const dependentObservers: Observer<unknown>[] = []
  
  const getter = (): T => {
    // Register as observer for inputs we depend on
    const activeObserver = getActiveObserver()
    if (activeObserver && !computing) {
      const obs = activeObserver as Observer<unknown>
      if (!dependentObservers.includes(obs)) {
        dependentObservers.push(obs)
      }
    }
    
    // Avoid infinite recursion
    if (computing) {
      return o.value!
    }
    
    computing = true
    
    try {
      // If we haven't computed yet, do the initial computation
      if (!hasComputed) {
        hasComputed = true
        updateObserver(o)
      } else {
        // Re-compute when called
        updateObserver(o)
      }
    } finally {
      computing = false
    }
    
    return o.value!
  }
  
  // Store observers on the observer object so inputs can notify us
  o.dependentObservers = dependentObservers
  o.getDependentObservers = () => dependentObservers
  
  return getter
}
