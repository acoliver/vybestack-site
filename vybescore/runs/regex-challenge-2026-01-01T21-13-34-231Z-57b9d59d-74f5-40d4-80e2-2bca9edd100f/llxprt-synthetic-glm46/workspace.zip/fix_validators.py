content = open('src/validators.ts', 'r').read()
lines = content.split('\n')
lines[53] = '  const cleaned = value.replace(/[\\s-\\(\\)]/g, "");'
lines[140] = '  const forbiddenPattern = /[0-9_!@#$%^&*()+=\\[\\]{};:"\\|,.<>\\/?]/;'
open('src/validators.ts', 'w').write('\n'.join(lines))