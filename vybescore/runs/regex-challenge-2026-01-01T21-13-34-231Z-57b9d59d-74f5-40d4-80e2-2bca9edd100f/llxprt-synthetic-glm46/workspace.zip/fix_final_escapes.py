# Final fixes for character class escapes

# Fix puzzles.ts line 34 (around line 33-35)
content_puzzles = open('src/puzzles.ts', 'r').read()
content_puzzles = content_puzzles.replace(
    'const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};:"\\\\|,.<>\\/?]/.test(value);',
    'const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};:"\\\\|,.<>\\/?]/.test(value);'
)
open('src/puzzles.ts', 'w').write(content_puzzles)

# Fix validators.ts
content_validators = open('src/validators.ts', 'r').read()
# Fix line 54
content_validators = content_validators.replace(
    'const cleaned = value.replace(/[\\s-\\(\\)]/g, "");',
    'const cleaned = value.replace(/[\\s-\\(\\)]/g, "");'
)
# Fix line 141
content_validators = content_validators.replace(
    'const forbiddenPattern = /[0-9_!@#$%^&*()+=\\[\\]{};:"\\|,.<>\\/?]/;',
    'const forbiddenPattern = /[0-9_!@#$%^&*()+=\\[\\]{};:"\\|,.<>\\/?]/;'
)
open('src/validators.ts', 'w').write(content_validators)

print("Final fixed all escapes")