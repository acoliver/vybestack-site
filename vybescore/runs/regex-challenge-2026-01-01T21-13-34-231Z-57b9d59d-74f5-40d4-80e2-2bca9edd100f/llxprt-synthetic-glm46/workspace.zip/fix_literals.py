# Fix regex literal escapes
content_puzzles = open('src/puzzles.ts', 'r').read()
# Fix line 18 - the regex with backslash-d
content_puzzles = content_puzzles.replace(
    'const pattern = new RegExp(`(?<=\\d)${token}`, "g");',
    'const pattern = new RegExp(`(?<=\\\\d)${token}`, "g");'
)
# Fix character class escapes in password symbol check
content_puzzles = content_puzzles.replace(
    'const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};:"\\\\|,.<>\\/?]/.test(value);',
    'const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};:"\\\\|,.<>\\/?]/.test(value);'
)

# Fix ipv4 pattern in puzzles as well
content_puzzles = content_puzzles.replace(
    'const ipv4Pattern = /(?:^|[^0-9])(?:\\d{1,3}\\.){3}\\d{1,3}(?:$|[^0-9])/;',
    'const ipv4Pattern = /(?:^|[^0-9])(?:\\d{1,3}\\.){3}\\d{1,3}(?:$|[^0-9])/;'
)

open('src/puzzles.ts', 'w').write(content_puzzles)

# Fix validators.ts
content_validators = open('src/validators.ts', 'r').read()
# Fix line 54 - parentheses in character class
content_validators = content_validators.replace(
    'const cleaned = value.replace(/[\\s-\\(\\)]/g, "");',
    'const cleaned = value.replace(/[\\s-\\(\\)]/g, "");'
)
# Fix line 141 - character class with special chars
content_validators = content_validators.replace(
    'const forbiddenPattern = /[0-9_!@#$%^&*()+=\\[\\]{};:"\\|,.<>\\/?]/;',
    'const forbiddenPattern = /[0-9_!@#$%^&*()+=\\[\\]{};:"\\|,.<>\\/?]/;'
)

open('src/validators.ts', 'w').write(content_validators)
print("Fixed")