content = open('src/puzzles.ts', 'r').read()
lines = content.split('\n')
lines[17] = '  const pattern = new RegExp(`(?<=\\d)${token}`, "g");'
lines[33] = '  const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};:"\\|,.<>\\/?]/.test(value);'
open('src/puzzles.ts', 'w').write('\n'.join(lines))