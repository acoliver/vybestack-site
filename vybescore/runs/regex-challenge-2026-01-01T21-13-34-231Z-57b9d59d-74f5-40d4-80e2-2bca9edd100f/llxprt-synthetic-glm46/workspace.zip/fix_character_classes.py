# Fix character class escapes in source files
import re

# Fix puzzles.ts
content = open('src/puzzles.ts', 'r').read()
# Fix line 18 - the regex literal with \\d
content = re.sub(r'\(\?<=\\\d\)', r'(?<=\\d)', content)
# Fix line 33-34 - character class with []
content = re.sub(r'\\/\\? \/\] ', r'/\\?]/', content)
print(content)
open('src/puzzles.ts', 'w').write(content)

# Fix validators.ts
content = open('src/validators.ts', 'r').read()
# Fix line 54 - parentheses
content = re.sub(r'\[\\s-\(\)\]', r'[\s-\(\)]', content)
# Fix line 141 - character class
content = re.sub(r'\/\?', r'/\?', content)
print(content)
open('src/validators.ts', 'w').write(content)