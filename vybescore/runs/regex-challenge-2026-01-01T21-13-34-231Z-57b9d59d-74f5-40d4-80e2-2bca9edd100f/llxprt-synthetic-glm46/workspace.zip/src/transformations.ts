/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize sentences after .?!, ensuring single space and handling abbreviations
  return text.replace(/([.!?]+)[\s]*([a-z])/g, (match, punc, letter) => {
    return punc + ' ' + letter.toUpperCase();
  }).replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: protocol, domain, optional path and query
  const urlPattern = /https?:\/\/([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?/g;
  const matches = text.match(urlPattern) || [];
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then, specific rule for example.com/docs/ paths
  // but exclude dynamic paths with cgi-bin, query strings, or legacy extensions
  const docsUrlPattern = /https:\/\/example.com\/docs\/([^\s?.&#;]*)([^?\s&#;]*)?/g;
  
  result = result.replace(docsUrlPattern, (match, path, afterPath) => {
    // Skip if has dynamic hints
    if (/\?(.+)/.test(afterPath) || /cgi-bin|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/.test(afterPath)) {
      return match;
    }
    return `https://docs.example.com/docs/${path}${afterPath}`;
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate day based on month
  const maxDays: Record<number, number> = {
    1: 31, 2: (isLeapYear(year) ? 29 : 28), 3: 31, 4: 30,
    5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31,
    11: 30, 12: 31
  };
  
  if (day > maxDays[month]) {
    return 'N/A';
  }
  
  return year.toString();
}

// Helper function to check for leap year
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}
