/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Word boundary, followed by prefix and rest of word
  const wordPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and ensure words actually contain letters after the prefix
  return matches.filter(word => !exceptions.includes(word) && word.length > prefix.length);
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Using lookbehind to match token preceded by a digit
  const pattern = new RegExp(`\\d${token}`, "g");
  const matches = [...text.matchAll(pattern)];
  
  // Return the full matched substring (digit+coken)
  return matches.map(match => match[0]);
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace
  const minLength = 10;
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
const hasSymbol = /[!@#$%^&*()_+=\[\]{};:"\\|,.<>\\?]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (value.length < minLength || !hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (like 'abab')
  for (let i = 0; i < value.length - 3; i++) {
    const substr = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === substr) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (including shorthand like ::)
  const ipv6Pattern = /[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,7}(?:::)?(?:[0-9a-fA-F]{1,4})?/;
  
  // IPv4 pattern (to exclude these)
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  
  return ipv6Pattern.test(value) && !ipv4Pattern.test(value);
}