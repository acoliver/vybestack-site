export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address according to RFC 5322 with additional constraints.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern with strict validation
  // Local part: letters, numbers, +, ., -, %, _, '
  // Domain part: letters, numbers, hyphens, dots
  // No consecutive dots, no leading/trailing dots in local part
  // No underscores in domain
  const emailPattern = /^[a-zA-Z0-9]+([._%+-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Check for consecutive dots
  if (/\.\./.test(value)) {
    return false;
  }
  
  // Check for dots at start or end of local part
  const [local, domain] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Check for underscore in domain
  if (/_/.test(domain)) {
    return false;
  }
  
  // Check for domain starting or ending with dot or hyphen
  if (domain.startsWith('.') || domain.startsWith('-') || domain.endsWith('.') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats:
 * (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove whitespace and common separators for validation
  const cleaned = value.replace(/[\s-()]/g, "");
  
  // Optional country code +1
  const phonePattern = /^\+?1?([2-9]\d{2})([2-9]\d{2})(\d{4})$/;
  
  // Check basic format and length
  if (!phonePattern.test(cleaned)) {
    return false;
  }
  
  // Extract area code and verify it doesn't start with 0 or 1
  const match = cleaned.match(phonePattern);
  if (match && match[1]) {
    const areaCode = match[1];
    // Area code shouldn't start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
  }
  
  // Ensure the input is long enough (minimum 10 digits without country code)
  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle extensions if allowed
  if (options?.allowExtensions) {
    // This is a placeholder for potential extension handling
    // For now, we just allow extensions in the format
    const withExtPattern = /^\+?1?([2-9]\d{2})([2-9]\d{2})(\d{4})( ext\.? \d+)?/;
    return withExtPattern.test(value.replace(/\s/g, ''));
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with support for landlines and mobiles.
 * Formats like "+54 9 11 1234 5678", "011 1234 5678", "+54 341 123 4567", "0341 4234567".
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits (leading digit 1-9)
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must start with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // With country code pattern: +54 [9] area_code subscriber
  const codeWithCountry = /^54(9?)([1-9]\d{0,3})(\d{6,8})$/;
  
  // Without country code pattern: 0[9] area_code subscriber
  const codeWithoutCountry = /^0(9?)([1-9]\d{0,3})(\d{6,8})$/;
  
  // Check if it matches either pattern
  const withCountryMatch = digitsOnly.match(codeWithCountry);
  const withoutCountryMatch = digitsOnly.match(codeWithoutCountry);
  
  if (withCountryMatch) {
    return true;
  }
  
  if (withoutCountryMatch) {
    return true;
  }
  
  // Check for the pattern with separators
  const withSeparatorsPattern = /^\+?54\s?9?\s?\d{2,4}\s?\d{3,4}\s?\d{4}$/;
  const withoutSeparatorsPattern = /^0\s?9?\s?\d{2,4}\s?\d{3,4}\s?\d{4}$/;
  
  return withSeparatorsPattern.test(value) || withoutSeparatorsPattern.test(value);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and unusual characters
  const namePattern = /^[\p{L}'][\p{L}'\s-]*[\p{L}']+$/u;
  
  // Reject digits and most symbols
const forbiddenPattern = /[0-9_!@#$%^&*()+=\[\]{};:"\\|,.<>\/?]/;
  
  return namePattern.test(value) && !forbiddenPattern.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for common credit card patterns
  // Visa: 4xxx, length 13 or 16
  // Mastercard: 51-55 or 2221-2720, length 16
  // AmEx: 34 or 37, length 15
  const visaPattern = /^4\d{12}(\d{3})?$/;
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d{2}|20\d))\d{12}$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum algorithm
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
