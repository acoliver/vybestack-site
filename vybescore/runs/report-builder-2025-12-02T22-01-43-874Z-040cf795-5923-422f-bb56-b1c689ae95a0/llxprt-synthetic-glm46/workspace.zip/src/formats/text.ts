import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: FormatRenderer = (
  data: ReportData,
  options: ReportOptions,
): string => {
  let output = `${data.title}\n${data.summary}\n\nEntries:\n`;

  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }

  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    output += `Total: ${formatAmount(total)}`;
  }

  return output;
};