#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { exit } from 'node:process';
import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

const FORMATS: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(): CliArgs {
  const processArgs = process.argv.slice(2);
  
  if (processArgs.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const args: CliArgs = {
    dataFile: processArgs[0],
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  for (let i = 1; i < processArgs.length; i++) {
    switch (processArgs[i]) {
      case '--format':
        if (i + 1 >= processArgs.length) {
          console.error('Error: --format requires a value');
          exit(1);
        }
        args.format = processArgs[++i];
        break;
      case '--output':
        if (i + 1 >= processArgs.length) {
          console.error('Error: --output requires a value');
          exit(1);
        }
        args.outputPath = processArgs[++i];
        break;
      case '--includeTotals':
        args.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${processArgs[i]}`);
        exit(1);
    }
  }

  if (!args.format) {
    console.error('Error: --format is required');
    exit(1);
  }

  if (!FORMATS[args.format]) {
    console.error(`Error: Unsupported format: ${args.format}`);
    exit(1);
  }

  return args;
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }

  const reportData = data as Record<string, unknown>;
  
  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string' ||
    !Array.isArray(reportData.entries)
  ) {
    return false;
  }

  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      return false;
    }

    const reportEntry = entry as Record<string, unknown>;
    
    if (
      typeof reportEntry.label !== 'string' ||
      typeof reportEntry.amount !== 'number'
    ) {
      return false;
    }
  }

  return true;
}

function readAndValidateReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, { encoding: 'utf8' });
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      console.error('Error: Invalid report data. Expected format: {title: string, summary: string, entries: Array<{label: string, amount: number}>}');
      exit(1);
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in file ${filePath}`);
    } else {
      console.error(`Error reading file ${filePath}: ${(error as Error).message}`);
    }
    exit(1);
  }
}

function main(): void {
  const args = parseArgs();
  const data = readAndValidateReportData(args.dataFile);
  
  const options: ReportOptions = {
    includeTotals: args.includeTotals,
  };

  const renderer = FORMATS[args.format];
  const output = renderer(data, options);

  if (args.outputPath) {
    try {
      writeFileSync(args.outputPath, output, { encoding: 'utf8' });
      console.log(`Report written to ${args.outputPath}`);
    } catch (error) {
      console.error(`Error writing to file ${args.outputPath}: ${(error as Error).message}`);
      exit(1);
    }
  } else {
    console.log(output);
  }
}

main();