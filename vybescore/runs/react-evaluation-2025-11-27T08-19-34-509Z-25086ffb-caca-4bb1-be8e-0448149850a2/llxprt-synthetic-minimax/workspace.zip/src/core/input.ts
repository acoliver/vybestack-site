/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = !subject.equalFn || !subject.equalFn(subject.value, nextValue)
    
    subject.value = nextValue
    
    if (shouldNotify) {
      notifyObservers(subject)
    }
    
    return subject.value
  }

  return [read, write]
}
