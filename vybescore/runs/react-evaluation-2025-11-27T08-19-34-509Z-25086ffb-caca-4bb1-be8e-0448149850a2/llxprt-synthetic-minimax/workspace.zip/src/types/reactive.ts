/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type ComputedSubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type ComputedSubjectV<T> = {
  value: T
  updateFn: UpdateFn<T>
  observers: Set<ObserverR>
}

export type ComputedSubject<T> = ComputedSubjectR & ComputedSubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    return observer.value
  } finally {
    activeObserver = previous
  }
}

export function addObserver<T>(subject: Subject<T> | Observer<T>, observer: ObserverR): void {
  // If it's a Subject (has observers property), add to its set
  if ('observers' in subject && 'observers' in subject) {
    const subj = subject as Subject<T>
    subj.observers.add(observer)
  } else if ('observers' in observer && 'updateFn' in observer) {
    // If the observer itself has observers (is a computed value), don't modify
    // This is just a regular observer
  }
}

export function removeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.delete(observer)
}

export function notifyObservers<T>(subjectOrObserver: Observer<T> | Subject<T>): void {
  // Check if this is a Subject (has observers property) or an Observer
  if ('observers' in subjectOrObserver) {
    // It's a Subject - notify all registered observers
    const subject = subjectOrObserver as Subject<T>
    subject.observers.forEach(observer => {
      if (observer !== activeObserver) {
        updateObserver(observer as Observer<unknown>)
      }
    })
  } else {
    // It's a single Observer - update it directly
    const observer = subjectOrObserver as Observer<T>
    if (observer !== activeObserver) {
      updateObserver(observer)
    }
  }
}
