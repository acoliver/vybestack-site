/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that a string is valid Base64.
 * Checks for valid characters, length, and padding.
 */
function isValidBase64(input: string): boolean {
  // Remove whitespace
  const trimmed = input.trim();
  
  // Empty string is invalid
  if (trimmed.length === 0) {
    return false;
  }
  
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, =)
  // Padding can only appear at the end
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmed)) {
    return false;
  }
  
  // Check padding rules
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be at the end
    const afterPadding = trimmed.slice(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      return false;
    }
    
    // Total length must be multiple of 4 when padded
    if (trimmed.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, length must be multiple of 4 with optional remainder
    // (unpadded Base64 can have any length)
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding).
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate input format
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    // Add padding if missing (Node.js Buffer requires proper padding)
    let padded = trimmed;
    const paddingNeeded = (4 - (trimmed.length % 4)) % 4;
    if (paddingNeeded > 0 && !trimmed.includes('=')) {
      padded = trimmed + '='.repeat(paddingNeeded);
    }
    
    const result = Buffer.from(padded, 'base64').toString('utf8');
    
    // Check if decoding produced valid UTF-8
    // If the input was invalid, Buffer might produce empty or garbage output
    if (trimmed.length > 0 && result === '' && !trimmed.startsWith('AQA=')) {
      throw new Error('Failed to decode Base64 input');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
