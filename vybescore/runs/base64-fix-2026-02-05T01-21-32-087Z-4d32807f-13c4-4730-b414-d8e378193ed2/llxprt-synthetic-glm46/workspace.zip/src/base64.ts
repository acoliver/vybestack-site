/**
 * Encode plain text to standard Base64 using canonical alphabet and proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function isValidBase64(input: string): boolean {
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /
  // Optional padding with '=' characters at the end
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check if input matches standard Base64 pattern
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check for correct padding length if present
  const paddingLength = input.length - input.replace(/=/g, '').length;
  return paddingLength <= 2;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate the input format first
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input format');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
