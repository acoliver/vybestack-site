import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam === undefined) {
      page = 1; // Default value
    } else {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || parsedPage <= 0 || !Number.isInteger(parsedPage)) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      if (parsedPage > 1000) { // Prevent excessive values
        return res.status(400).json({ error: 'Page number is too large' });
      }
      page = parsedPage;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam === undefined) {
      limit = 5; // Default value
    } else {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || parsedLimit <= 0 || !Number.isInteger(parsedLimit)) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      if (parsedLimit > 100) { // Prevent excessive values
        return res.status(400).json({ error: 'Limit is too large (max 100)' });
      }
      limit = parsedLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
