import type { ReportData, ReportEntry } from '../types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid title');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: Missing or invalid entries array');
  }

  const entries = obj.entries as unknown[];
  const validatedEntries: ReportEntry[] = [];

  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: Expected an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: Missing or invalid label');
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error('Invalid entry: Missing or invalid amount');
    }

    validatedEntries.push({
      label: entryObj.label,
      amount: entryObj.amount,
    });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: validatedEntries,
  };
}