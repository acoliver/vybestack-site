export interface CliOptions {
  format: string;
  output?: string;
  includeTotals?: boolean;
}

export interface ParsedArgs {
  filePath: string;
  options: CliOptions;
}

/**
 * Parse command line arguments using Node's process.argv
 */
export function parseArgs(args: string[]): ParsedArgs {
  // Skip first two elements (node executable and script path)
  const argList = args.slice(2);

  if (argList.length === 0) {
    throw new Error('Missing required data file path and format');
  }

  const filePath = argList[0];

  if (!filePath) {
    throw new Error('Missing required data file path');
  }

  // Find required format flag
  const formatIndex = argList.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= argList.length) {
    throw new Error('Missing required --format flag');
  }

  const format = argList[formatIndex + 1];

  // Find optional flags
  const outputIndex = argList.indexOf('--output');
  const output = outputIndex !== -1 && outputIndex + 1 < argList.length 
    ? argList[outputIndex + 1] 
    : undefined;

  const includeTotals = argList.includes('--includeTotals');

  return {
    filePath,
    options: {
      format,
      output,
      includeTotals,
    },
  };
}