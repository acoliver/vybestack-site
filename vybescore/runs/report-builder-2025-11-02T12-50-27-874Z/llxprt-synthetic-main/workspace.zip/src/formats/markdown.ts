import type { ReportData, ReportOptions, RenderFunction } from '../types.js';

export const renderMarkdown: RenderFunction = (
  data: ReportData,
  options?: ReportOptions,
): string => {
  const { title, summary, entries } = data;
  const { includeTotals = false } = options || {};

  // Format amount with two decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  // Calculate total if needed
  const total = includeTotals
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : undefined;

  // Build the markdown content
  let output = `# ${title}\n\n${summary}\n\n## Entries\n`;

  entries.forEach((entry) => {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  });

  if (includeTotals && total !== undefined) {
    output += `\n**Total:** ${formatAmount(total)}\n`;
  }

  return output;
};