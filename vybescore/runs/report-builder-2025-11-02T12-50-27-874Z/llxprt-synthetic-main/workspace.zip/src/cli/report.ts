#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { RenderFunction } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseArgs } from '../utils/args.js';
import { validateReportData } from '../utils/validation.js';

// Map of format names to renderer functions
const formatters: Record<string, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};

function main(): void {
  try {
    const { filePath, options } = parseArgs(process.argv);

    // Check if the format is supported
    if (!formatters[options.format]) {
      console.error(`Unsupported format: ${options.format}`);
      process.exit(1);
    }

    // Read and parse the JSON file
    let data: unknown;
    try {
      const fileContent = readFileSync(filePath, 'utf8');
      data = JSON.parse(fileContent);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Error reading or parsing file ${filePath}: ${errorMessage}`);
      process.exit(1);
    }

    // Validate the data structure
    let reportData;
    try {
      reportData = validateReportData(data);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Error validating report data: ${errorMessage}`);
      process.exit(1);
    }

    // Render the report using the selected format
    const formatter = formatters[options.format];
    const output = formatter(reportData, { includeTotals: options.includeTotals });

    // Write to stdout or file
    if (options.output) {
      try {
        writeFileSync(options.output, output, 'utf8');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        console.error(`Error writing to file ${options.output}: ${errorMessage}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }
}

// Only run main if this file is being executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}