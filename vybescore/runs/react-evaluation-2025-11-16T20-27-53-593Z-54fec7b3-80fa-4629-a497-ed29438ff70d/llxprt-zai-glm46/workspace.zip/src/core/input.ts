/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Observer,
  getCurrentObserver,
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === false) {
    // Always trigger updates
    equalFn = () => false
  } else if (equal === true || equal === undefined) {
    // Use strict equality by default
    equalFn = (a, b) => a === b
  } else {
    // Custom equality function provided
    equalFn = equal
  }

  const observers = new Set<Observer>()

  const read: GetterFn<T> = () => {
    const observer = getCurrentObserver()
    if (observer) {
      observers.add(observer)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (equalFn && equalFn(value, nextValue)) {
      return value
    }
    
    value = nextValue
    
    // Notify all observers of the change
    for (const observer of observers) {
      observer.update()
    }
    
    return value
  }

  return [read, write]
}