/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getCurrentObserver,
  setCurrentObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const observers = new Set<Observer>()
  let dirty = true
  
  const computedObserver: Observer = {
    update: () => {
      dirty = true
      // Notify all observers that depend on this computed value
      for (const observer of observers) {
        observer.update()
      }
    }
  }

  const compute = (): T => {
    if (dirty) {
      const previousObserver = getCurrentObserver()
      setCurrentObserver(computedObserver)
      
      try {
        // Execute the computation function and track dependencies
        const result = updateFn(value)
        value = result
        dirty = false
      } finally {
        setCurrentObserver(previousObserver)
      }
    }
    return value!
  }

  // Initial computation to establish dependencies
  compute()

  return () => {
    const observer = getCurrentObserver()
    if (observer) {
      observers.add(observer)
    }
    return compute()
  }
}