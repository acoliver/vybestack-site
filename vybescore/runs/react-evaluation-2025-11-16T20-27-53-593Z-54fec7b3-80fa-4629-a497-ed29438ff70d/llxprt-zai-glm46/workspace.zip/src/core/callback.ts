/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn, Observer, getCurrentObserver, setCurrentObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const callbackObserver: Observer = {
    update: () => {
      if (disposed) return
      
      const previousObserver = getCurrentObserver()
      setCurrentObserver(callbackObserver)
      
      try {
        // Execute the effect function and track dependencies
        updateFn(value)
      } finally {
        setCurrentObserver(previousObserver)
      }
    }
  }

  // Execute the effect initially
  callbackObserver.update()
  
  return () => {
    disposed = true
  }
}