/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Legacy types for backward compatibility
export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Simple observer pattern for reactive updates
export interface Observer {
  update(): void
}

// Reactive value interface
export interface Reactive<T> {
  get(): T
  subscribe(observer: Observer): UnsubscribeFn
}

// Global tracking for dependency collection
let currentObserver: Observer | null = null

export function getCurrentObserver(): Observer | null {
  return currentObserver
}

export function setCurrentObserver(observer: Observer | null): void {
  currentObserver = observer
}