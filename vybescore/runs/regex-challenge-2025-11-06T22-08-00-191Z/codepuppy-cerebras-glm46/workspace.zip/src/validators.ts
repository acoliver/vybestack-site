export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive regex rules.
 * Supports typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex: local-part@domain
  // Local part:允许字母、数字、.、_、%、+、-，但不能.开头/结尾，不能..
  // Domain: 字母、数字、-，但不能_，不能.开头/结尾，标签之间不能..
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // More specific checks for common issues
  if (!emailRegex.test(value)) return false;
  
  // No consecutive dots in local part or domain
  if (value.includes('..')) return false;
  
  // Local part shouldn't start or end with dot
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain part shouldn't have underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, maybe 11 with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    // Must start with 1 for US country code
    if (!digitsOnly.startsWith('1')) return false;
    phoneNumber = digitsOnly.slice(1);
  }
  
  // Now we should have exactly 10 digits
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format with optional country code and various separators
  const phoneRegex = /^\+?1?[\s.-]?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation but keep track of structure
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriber] = match;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (!subscriber || subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix 0
  if (!countryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like 'X Æ A-12'
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for forbidden characters (digits, most symbols)
  if (/\d/.test(value)) return false;
  
  // Allow Unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject most other symbols but allow common name punctuation
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional checks to reject obviously invalid names
  // Reject names with too many consecutive special characters
  if (/[']{2,}/.test(value) || /[-]{2,}/.test(value)) return false;
  
  // Reject names that are just spaces or special characters
  const trimmed = value.trim();
  if (trimmed.length === 0) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(trimmed)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx with Luhn checksum.
 * Checks prefix, length, and runs Luhn algorithm validation
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14}|222[1-9]\d{12}|22[3-9]\d{13}|2[3-6]\d{14}|27[01]\d{13}|2720\d{12})$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type
  const validPrefix = visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue);
  
  if (!validPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = digit.toString().split('').map(Number).reduce((a, b) => a + b, 0);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
