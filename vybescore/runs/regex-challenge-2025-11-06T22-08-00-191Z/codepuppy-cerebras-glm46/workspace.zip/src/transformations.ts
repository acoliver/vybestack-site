/**
 * Capitalizes the first character of each sentence after .!? separators.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, normalize spacing around sentence endings
  // Replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence endings
  normalized = normalized.replace(/([.!?])\s*/g, '$1 ');
  
  // Capitalize first letter of each sentence
  const sentences = normalized.split(/([.!?]\s)/);
  
  for (let i = 0; i < sentences.length; i++) {
    if (i === 0 || sentences[i - 1]?.match(/[.!?]\s/)) {
      // This is the start of a sentence
      if (sentences[i].length > 0) {
        sentences[i] = sentences[i][0].toUpperCase() + sentences[i].slice(1);
      }
    }
  }
  
  // Join sentences back together
  const result = sentences.join('');
  
  // Remove trailing space if exists
  return result.trim();
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern - captures http/https/ftp protocols and domain names
  // Also handles www. without protocol and common TLDs
  const urlRegex = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<"]+(?=[\s.)>\]",]|$)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:)>\]\}]*$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 * Returns the modified text string.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but be careful not to match https://
  // Using negative lookbehind to avoid replacing https://
  return text.replace(/(?<!s)http:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... to https://...
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * But always upgrades scheme to https://
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Rewrite example.com URLs with docs paths
  // Pattern captures: https://example.com/docs/...
  const docsUrlRegex = /(https:\/\/example\.com)(\/docs\/.*?)$/gm;
  
  result = result.replace(docsUrlRegex, (match, domain, path) => {
    // Check for dynamic indicators that should prevent host rewrite
    const dynamicIndicators = [/(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i];
    
    const hasDynamicIndicator = dynamicIndicators.some(pattern => pattern.test(path));
    
    if (hasDynamicIndicator) {
      // Only upgrade scheme, keep host as example.com
      return `https://example.com${path}`;
    } else {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Additional validation for day based on month
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for invalid days (February 30, April 31, etc.)
  const maxDays = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > (maxDays[monthNum as keyof typeof maxDays] || 31)) {
    return 'N/A';
  }
  
  return year;
}
