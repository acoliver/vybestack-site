/**
 * Finds words beginning with the given prefix but excluding listed exceptions.
 * Uses word boundaries to match complete words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Split text into words and filter manually
  const words = text.split(/\s+/);
  
  const filtered = words
    .filter(word => word.toLowerCase().startsWith(prefix.toLowerCase()))
    .filter(word => !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    ))
    .filter((word, index, arr) => arr.indexOf(word) === index); // unique
  
  return filtered;
}

/**
 * Returns occurrences of token when it appears after a digit and not at string start.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Simple approach: find token occurrences and check if preceded by digit
  const result: string[] = [];
  let index = 0;
  
  while (true) {
    const tokenIndex = text.indexOf(token, index);
    if (tokenIndex === -1) break;
    
    // Check if it's not at the start
    if (tokenIndex > 0) {
      // Check if preceded by digit
      const prevChar = text[tokenIndex - 1];
      if (/\d/.test(prevChar)) {
        result.push(prevChar + token);
      }
    }
    
    index = tokenIndex + 1;
  }
  
  return result;
}

/**
 * Helper function to escape special regex characters
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\[\]]/g, '\$&');
}

/**
 * Validates password strength:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences like 'abab', '123123', etc.
  // This looks for patterns of 2+ characters that repeat immediately
  if (/(.{2,})\1/.test(value)) return false;
  
  // Also check for character repeated 3+ times in a row
  if (/(.)\1{2,}/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand :: but excludes IPv4 addresses.
 * Returns true if IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Or with :: shorthand (can replace one or more groups of zeros)
  // - Excludes IPv4 patterns (a.b.c.d format)
  
  // First check if there's an IPv4 pattern - if so, this might be IPv4-mapped IPv6
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 1-4 hex digits
  const fullIpv6Pattern = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand
  const shorthandIpv6Pattern = /\b([0-9a-fA-F]{1,4}:){1,7}:([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 starting or ending with ::
  const edgeShorthandPattern = /\b::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b|\b([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}::\b/;
  
  // Single ::
  const doubleColonPattern = /\b::\b/;
  
  // Check if any IPv6 pattern exists
  const hasFullIPv6 = fullIpv6Pattern.test(value);
  const hasShorthandIPv6 = shorthandIpv6Pattern.test(value);
  const hasEdgeShorthand = edgeShorthandPattern.test(value);
  const hasDoubleColon = doubleColonPattern.test(value);
  
  // If we found IPv6, but also found IPv4, this might be IPv4-mapped IPv6
  // We should verify it's actually IPv6 by checking for colons
  const hasColon = /:/.test(value);
  const hasIpv4 = ipv4Pattern.test(value);
  
  if (hasIpv4 && !hasColon) {
    return false; // This is just IPv4
  }
  
  return hasFullIPv6 || hasShorthandIPv6 || hasEdgeShorthand || hasDoubleColon;
}