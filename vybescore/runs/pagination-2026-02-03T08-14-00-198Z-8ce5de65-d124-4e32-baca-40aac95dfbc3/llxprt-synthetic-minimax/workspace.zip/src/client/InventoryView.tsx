import type { InventoryItem } from '../shared/types';
import { useState } from 'react';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const handlePrevious = (): void => {
    if (page > 1) {
      setPage(page - 1);
    }
  };

  const handleNext = (): void => {
    if (data.hasNext) {
      setPage(page + 1);
    }
  };

  // Handle empty states
  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
        <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
          <button 
            onClick={handlePrevious} 
            disabled={page <= 1}
            aria-label="Previous page"
          >
            Previous
          </button>
          <span>Page {page}</span>
          <button 
            onClick={handleNext} 
            disabled={!data.hasNext}
            aria-label="Next page"
          >
            Next
          </button>
        </div>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
        <button 
          onClick={handlePrevious} 
          disabled={page <= 1}
          aria-label="Previous page"
        >
          Previous
        </button>
        <span>Page {page}</span>
        <button 
          onClick={handleNext} 
          disabled={!data.hasNext}
          aria-label="Next page"
        >
          Next
        </button>
      </div>
    </section>
  );
}
