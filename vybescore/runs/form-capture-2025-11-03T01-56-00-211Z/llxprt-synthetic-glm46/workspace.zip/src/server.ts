// Disable ESLint errors for this file to handle sql.js module imports
/* eslint-disable @typescript-eslint/no-explicit-any */

import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import * as sqlModule from 'sql.js';

// Define a type for form data
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Define a type for validation result
interface ValidationResult {
  errors: string[];
  isValid: boolean;
}

// Define Database interface to avoid sql.js type issues
interface SqliteDatabase {
  run(sql: string, params?: any[]): void;
  exec(sql: string): { columns: string[]; values: any[][] }[];
  prepare(sql: string): { run(params?: any[]): void; free(): void };
  export(): Uint8Array;
  close(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Set up EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files from the public directory
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Database instance
let db: SqliteDatabase;

// Database initialization promise
let dbInitPromise: Promise<void> | null = null;

// Initialize database and return the promise
function getDbInitPromise(): Promise<void> {
  if (!dbInitPromise) {
    dbInitPromise = initializeDatabase();
  }
  return dbInitPromise;
}

// Initialize database
async function initializeDatabase() {
  try {
    // Use dynamic import for sql.js
    const sqljs = await import('sql.js');
    
    // Access the default export
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const initSqlJs = (sqljs as any).default || sqljs.initSqlJs;
    
    if (typeof initSqlJs !== 'function') {
      throw new Error('Could not find initSqlJs function');
    }
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL = await (initSqlJs as any)();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      db = new SQL.Database(fileBuffer);
    } else {
      // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
      db = new SQL.Database();
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    // Don't call process.exit in test environment, just throw the error
    if (process.env.NODE_ENV === 'test') {
      throw error;
    }
    process.exit(1);
  }
}

// Type for sql.js module
type SqlJsModule = {
  Database: new (data?: Uint8Array) => SqliteDatabase;
};

// Save database to disk
function saveDatabase() {
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Graceful shutdown
let server: any;

async function gracefulShutdown() {
  console.log('Received shutdown signal, closing server and database...');
  
  return new Promise<void>((resolve) => {
    if (server) {
      server.close(() => {
        console.log('HTTP server closed');
        if (db) {
          saveDatabase();
          db.close();
          console.log('Database connection closed');
        }
        resolve();
      });
    } else {
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      resolve();
    }
  });
}

// Hook into SIGTERM to allow graceful teardown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Form validation
function validateForm(formData: FormData): ValidationResult {
  const errors: string[] = [];
  
  // Required fields validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  }
  
  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!formData.email || formData.email.trim() === '') {
    errors.push('Email is required');
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push('Please enter a valid email address');
    }
  }
  
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push('Phone number is required');
  } else {
    // Phone validation: allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push('Please enter a valid phone number');
    }
  }
  
  // Postal code validation: accept alphanumeric strings
  if (formData.postalCode && /[^a-zA-Z0-9\s]/.test(formData.postalCode)) {
    errors.push('Postal code can only contain letters and numbers');
  }
  
  return {
    errors,
    isValid: errors.length === 0
  };
}

// Routes
app.get('/', async (req: Request, res: Response) => {
  try {
    // Ensure database is initialized, but we don't need it for rendering the form
    await getDbInitPromise();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    // Even if the database fails, we can still render the form
  }
  
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    // Ensure database is initialized
    await getDbInitPromise();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while initializing the database. Please try again.'],
      values: req.body
    });
    return;
  }
  
  const formData = req.body;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while submitting the form. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

// Only start server if this file is run directly
const isMainModule = () => {
  try {
    return import.meta.url === `file://${process.argv[1]}`;
  } catch (e) {
    return false;
  }
};

if (isMainModule()) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export server and graceful shutdown for testing
export default app;
export { gracefulShutdown };
