// Disable ESLint errors for this file
/* eslint-disable @typescript-eslint/no-explicit-any */

// Type definitions for sql.js
declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: any[]): void;
    exec(sql: string): { columns: string[]; values: any[][] }[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: any[]): void;
    step(): boolean;
    get(): any;
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  export function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
}