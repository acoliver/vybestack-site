import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Copy templates to dist folder after build
function copyTemplates() {
  const srcTemplatesPath = path.join(__dirname, 'src', 'templates');
  const distTemplatesPath = path.join(__dirname, 'dist', 'templates');
  
  // Ensure directory exists
  if (!fs.existsSync(distTemplatesPath)) {
    fs.mkdirSync(distTemplatesPath, { recursive: true });
  }
  
  // Copy all template files
  if (fs.existsSync(srcTemplatesPath)) {
    const templateFiles = fs.readdirSync(srcTemplatesPath);
    templateFiles.forEach(file => {
      const srcFile = path.join(srcTemplatesPath, file);
      const destFile = path.join(distTemplatesPath, file);
      fs.copyFileSync(srcFile, destFile);
    });
    console.log('Templates copied to dist folder');
  }
}

// Copy schema to dist folder
function copySchema() {
  const srcSchemaPath = path.join(__dirname, 'db', 'schema.sql');
  const distSchemaPath = path.join(__dirname, 'dist', 'db', 'schema.sql');
  
  // Ensure directory exists
  const distDbPath = path.dirname(distSchemaPath);
  if (!fs.existsSync(distDbPath)) {
    fs.mkdirSync(distDbPath, { recursive: true });
  }
  
  if (fs.existsSync(srcSchemaPath)) {
    fs.copyFileSync(srcSchemaPath, distSchemaPath);
    console.log('Schema copied to dist folder');
  }
}

// Run the script
copyTemplates();
copySchema();