export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regex patterns
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure first
  if (!value || typeof value !== 'string') return false;
  
  // Pattern explanation:
  // - Local part (before @): 
  //   * Starts with alphanumeric/dot/hyphen/plus/underscore
  //   * No consecutive dots, no leading/trailing dots
  // - Domain part (after @):
  //   * Only alphanumeric, dots, and hyphens allowed
  //   * No underscores in domain
  //   * No consecutive dots
  //   * Must end with at least one valid TLD part (no trailing dot)
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9.+_-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for underscores in domain part
  const [, domain] = value.split('@');
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers in various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +1 and remove it for further validation
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length > 11) {
    // If there are more than 11 digits including 1, it's invalid unless extensions are allowed
    if (!options?.allowExtensions) {
      return false;
    }
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) return false;
  
  // Area code can't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers in various formats
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for easier processing
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check patterns with country code
  if (cleanValue.startsWith('+54')) {
    const withoutCountryCode = cleanValue.substring(3);
    
    // Check for mobile indicator '9'
    if (withoutCountryCode.startsWith('9')) {
      const withoutMobileIndicator = withoutCountryCode.substring(1);
      
      // Area code should be 2-4 digits starting with 1-9
      const areaCodeMatch = withoutMobileIndicator.match(/^([1-9]\d{1,3})(\d{6,8})$/);
      if (areaCodeMatch) {
        const areaCode = areaCodeMatch[1];
        const subscriberNumber = areaCodeMatch[2];
        
        // Validate area code length (2-4 digits)
        if (areaCode.length < 2 || areaCode.length > 4) return false;
        
        // Validate subscriber number length (6-8 digits)
        if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
        
        return true;
      }
    } else {
      // Without mobile indicator, validate area code and subscriber number directly
      const areaCodeMatch = withoutCountryCode.match(/^([1-9]\d{1,3})(\d{6,8})$/);
      if (areaCodeMatch) {
        const areaCode = areaCodeMatch[1];
        const subscriberNumber = areaCodeMatch[2];
        
        // Validate area code length (2-4 digits)
        if (areaCode.length < 2 || areaCode.length > 4) return false;
        
        // Validate subscriber number length (6-8 digits)
        if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
        
        return true;
      }
    }
  } 
  // Check patterns without country code (must start with trunk prefix '0')
  else if (cleanValue.startsWith('0')) {
    const withoutTrunkCode = cleanValue.substring(1);
    
    // Area code should be 2-4 digits starting with 1-9
    const areaCodeMatch = withoutTrunkCode.match(/^([1-9]\d{1,3})(\d{6,8})$/);
    if (areaCodeMatch) {
      const areaCode = areaCodeMatch[1];
      const subscriberNumber = areaCodeMatch[2];
      
      // Validate area code length (2-4 digits)
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      // Validate subscriber number length (6-8 digits)
      if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
      
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for forbidden patterns like "X Æ A-12"
  if (value.match(/[Xx]\s*[Ææ]\s*[Aa]-12/)) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and other symbols
  return /^[^\d\W][\w\s'-]*[^\d\W]$/.test(value) && 
         !/[^\w\s'-]/.test(value.replace(/[\w\s'-]/g, '')) &&
         !/\d/.test(value);
}

/**
 * Helper function to run the Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum)
 * Accepts Visa/Mastercard/AmEx prefixes and lengths
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Visa: starts with 4, 13 or 16 digits
  // Mastercard: starts with 5, 16 digits
  // Amex: starts with 3, 15 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;  // 13 or 16 digits
  const mastercardRegex = /^5\d{15}$/;    // 16 digits
  const amexRegex = /^3\d{14}$/;          // 15 digits
  
  // Check if it matches any of the card patterns
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanValue);
}