/**
 * Capitalizes the first character of each sentence, preserving spacing rules
 * Inserts exactly one space between sentences even if the input omitted it
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Split text by sentence-ending punctuation followed by optional whitespace
  // We preserve abbreviations like "U.S." by not treating dots in the middle of words as sentence breaks
  return text
    .replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
      // p1 is the sentence ending (with possible whitespace)
      // p2 is the first letter of the next sentence
      return p1 + p2.toUpperCase();
    })
    // Collapse multiple spaces to single spaces except for intentional spacing in abbreviations
    .replace(/\s+/g, ' ')
    // Ensure there's exactly one space after sentence-ending punctuation
    .replace(/([.?!])(\S)/g, '$1 $2');
}

/**
 * Extract URLs from text, excluding trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Match URLs starting with http:// or https://
  // Include domain, path, query parameters, and fragments
  // Exclude trailing punctuation like .,!,? etc.
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*)?(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.!?]+$/, ''));
}

/**
 * Convert all HTTP URLs to HTTPS, leaving existing HTTPS URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Replace all http:// with https://, but not https:// (to avoid duplicating 's')
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http URLs to https and move docs paths to docs subdomain
 * Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Match http URLs with any host and any path starting with /docs/
  // But exclude URLs with dynamic indicators in the path
  return text.replace(/http:\/\/([a-zA-Z0-9.-]+)(\/docs\/(?:[^\s?&=#]+\.?[a-zA-Z0-9]*))/g, (match, host, path) => {
    // Check if path contains dynamic indicators
    if (path.includes('cgi-bin') || 
        path.includes('.jsp') || 
        path.includes('.php') || 
        path.includes('.asp') || 
        path.includes('.aspx') || 
        path.includes('.do') || 
        path.includes('.cgi') || 
        path.includes('.pl') || 
        path.includes('.py')) {
      // Only upgrade scheme to https
      return `https://${host}${path}`;
    }
    
    // Rewrite host to docs subdomain
    return `https://docs.${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings
 * Return 'N/A' when the format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}