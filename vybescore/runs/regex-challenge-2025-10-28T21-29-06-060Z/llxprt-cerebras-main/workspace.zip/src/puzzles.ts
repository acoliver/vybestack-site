/**
 * Match words starting with the prefix but excluding banned words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create a regex that matches words starting with the prefix but not in exceptions
  // Use word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  
  // Create negative lookahead for exceptions
  const negativeLookahead = escapedExceptions.length > 0 
    ? `(?!${escapedExceptions.join('|')})` 
    : '';
  
  const regex = new RegExp(`\\b${negativeLookahead}${escapedPrefix}\\w*`, 'g');
  
  return text.match(regex) || [];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string
 * Use lookaheads/lookbehinds for precise matching
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Create a regex that matches the token only when preceded by a digit
  // and not at the start of the string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind for a digit
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(regex);
  return matches ? matches : [];
}

/**
 * Validate passwords according to the policy
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for repeated sequences (like abab)
  // This regex looks for any sequence of 2 or more characters that repeats immediately
  if (/(\w{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that handles standard and shorthand formats
  // This includes patterns like 2001:db8::1 and 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // Explanation:
  // - An IPv6 address consists of 8 groups of 1-4 hex digits separated by colons
  // - It can have a double colon (::) representing one or more groups of zeros (only once in an address)
  // - It should not match IPv4 addresses which have a different pattern
  const ipv6SimpleRegex = 
    /(?:(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  
  // IPv4 regex to make sure we don't match IPv4 addresses
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Return true if it matches IPv6 pattern and doesn't match IPv4 pattern
  return ipv6SimpleRegex.test(value) && !ipv4Regex.test(value);
}