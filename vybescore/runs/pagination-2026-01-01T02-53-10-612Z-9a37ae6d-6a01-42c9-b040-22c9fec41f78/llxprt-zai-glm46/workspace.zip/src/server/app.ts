import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (isNaN(page) || page <= 0) {
        res.status(400).json({ error: 'Invalid page parameter: must be a positive number' });
        return;
      }
    }

    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (isNaN(limit) || limit <= 0) {
        res.status(400).json({ error: 'Invalid limit parameter: must be a positive number' });
        return;
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
