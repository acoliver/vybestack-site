import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { SqlJsStatic, Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3535', 10);

// Validation interfaces and functions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s()\\-]+$/;
  return phoneRegex.test(phone) && /\d/.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes like UK "SW1A 1AA" and formats like "C1000", "B1675"
  const postalRegex = /^[A-Za-z0-9\s\\-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!data.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!data.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  if (!data.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/ZIP code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal/ZIP code' });
  }
  
  return errors;
}

// Database class
class DatabaseManager {
  private sql: SqlJsStatic | null = null;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  }

  async init(): Promise<void> {
    this.sql = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    try {
      // Try to load existing database
      const fs = await import('fs');
      const buffer = fs.readFileSync(this.dbPath);
      this.db = new this.sql.Database(buffer);
    } catch (error) {
      // Create new database if file doesn't exist
      this.db = new this.sql.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const fs = await import('fs');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    this.db!.run(schema);
  }

  async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.bind([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    stmt.step();
    stmt.free();
    
    await this.save();
  }

  private async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const fs = await import('fs');
    const data = this.db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(this.dbPath, buffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

async function main(): Promise<void> {
  const app = express();
  const dbManager = new DatabaseManager();
  
  await dbManager.init();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use(express.static(path.join(__dirname, '..', 'public')));
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [], 
      formData: {},
      title: 'Contact Us - Friendly Form (Definitely Not A Scam)'
    });
  });

  app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = validateForm(formData);

      if (errors.length > 0) {
        return res.status(400).render('form', {
          errors,
          formData,
          title: 'Contact Us - Please Fix Errors'
        });
      }

      await dbManager.insertSubmission(formData);
      
      // Redirect after successful submission
      res.redirect(302, '/thank-you');
    } catch (error) {
      next(error);
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', { 
      title: 'Thank You - We will be in touch!'
    });
  });

  // Error handling middleware
  app.use((err: Error, req: Request, res: Response) => {
    console.error(err);
    res.status(500).send('Something went wrong!');
  });

  // Graceful shutdown
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  const gracefulShutdown = async (signal: string) => {
    console.log(`Received ${signal}. Shutting down gracefully...`);
    
    server.close(async () => {
      console.log('HTTP server closed');
      await dbManager.close();
      console.log('Database closed');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

main().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
