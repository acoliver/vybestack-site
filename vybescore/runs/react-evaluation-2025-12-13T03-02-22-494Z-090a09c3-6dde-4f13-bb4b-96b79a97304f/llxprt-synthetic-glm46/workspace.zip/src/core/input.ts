/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Registry of all inputs for computed dependency tracking  
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const allSubjects = new Set<Subject<any>>()

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Set up equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }
  
  // Register for dependency tracking
  allSubjects.add(s)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = !s.equalFn || !s.equalFn(s.value, nextValue)
    s.value = nextValue
    if (shouldNotify && s.observer) {
      // Direct update for observers
      updateObserver(s.observer as Observer<T>)
    }
    return s.value
  }

  return [read, write]
}
