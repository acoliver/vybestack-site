/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

// Registry to track dependent relationships  
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const dependentMap = new Map<Observer<any>, Set<Observer<any>>>()
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const allComputeds: Observer<any>[] = []

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function notifyDependents(changedComputed: Observer<any>) {
  for (const [dependent, deps] of dependentMap.entries()) {
    if (deps.has(changedComputed)) {
      updateObserver(dependent)
    }
  }
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Set up equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Store the initial value if provided
  if (value !== undefined) {
    o.value = value
  }

  // Track dependencies that this computed depends on
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let dependencies: Observer<any>[] = []
  let isComputing = false

  const getter = (): T => {
    const activeObserver = getActiveObserver()
    
    // If someone is accessing this computed value, register as dependent 
    if (activeObserver && 'updateFn' in activeObserver) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const fullObserver = activeObserver as Observer<any>
      let deps = dependentMap.get(fullObserver)
      if (!deps) {
        deps = new Set()
        dependentMap.set(fullObserver, deps)
      }
      deps.add(o)
    }
    
    // Prevent recomputation during computation to avoid cycles
    if (isComputing) {
      return o.value!
    }
    
    // Clear previous dependencies before recomputing
    dependencies = []
    
    isComputing = true
    try {
      // Compute value (this tracks dependencies through activeObserver pattern)
      updateObserver(o)
    } finally {
      isComputing = false
    }
    
    return o.value!
  }

  // Override updateFunction to track dependencies during computation
  const originalUpdate = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Track what this computed depends on during evaluation
    const activeObserver = getActiveObserver()
if (activeObserver && 'updateFn' in activeObserver) {
      // Type assertion needed since we're working with the Observer interface
      dependencies = [...dependencies, activeObserver as Observer<unknown>];
    }
    const oldValue = o.value
    
    // First compute the new value
    const result = originalUpdate(prevValue)
    
    // If value changed, notify all dependents
    const shouldNotify = !equalFn || !oldValue || !equalFn(oldValue, result)
    if (shouldNotify) {
      // For simplicity, just store a global list of computed values and update them all
      // In a real implementation, this would be more targeted
      notifyDependents(o)
    }
    
    return result
  }

  // Register this computed value in the global list
  allComputeds.push(o)
  
  return getter
}