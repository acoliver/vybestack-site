import { createInput, createComputed } from './src/index.js'

const [getter, setter] = createInput(5)
const double = createComputed(() => getter() * 2)
console.log('Initial double:', double())
setter(10)
console.log('After change double:', double())