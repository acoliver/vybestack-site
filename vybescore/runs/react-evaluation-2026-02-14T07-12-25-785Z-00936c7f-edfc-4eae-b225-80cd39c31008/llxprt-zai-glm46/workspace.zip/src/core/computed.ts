/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  ObserverR
} from '../types/reactive.js'

// Extend Observer to track its observers
interface ReactiveObserver<T> extends Observer<T> {
  observers: Set<ObserverR>
}

/**
 * Creates a computed (derived) closure with
 * supplied function which computes current value
 * of closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: ReactiveObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: [],
    observers: new Set(),
  }
  
  // Initial computation to track dependencies
  updateObserver(observer)
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    // When accessed by another computed value, register as dependency
    if (activeObserver) {
      const activeWithSubjects = activeObserver as { subjects?: Observer<unknown>[] }
      
      // Add this computed value to active observer's subjects
      if (activeWithSubjects.subjects && !activeWithSubjects.subjects.includes(observer as Observer<unknown>)) {
        activeWithSubjects.subjects.push(observer as Observer<unknown>)
      }
      
      // Add active observer to this computed value's observers
      if (!observer.observers.has(activeObserver)) {
        observer.observers.add(activeObserver)
      }
    }
    return observer.value!
  }
  
  return getter
}
