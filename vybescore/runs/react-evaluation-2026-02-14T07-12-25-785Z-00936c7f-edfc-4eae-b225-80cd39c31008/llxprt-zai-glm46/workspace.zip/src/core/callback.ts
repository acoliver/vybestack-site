/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: [],
  }
  
  // Initial execution to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to stop updates
    if (observer.subjects) {
      observer.subjects.forEach(subject => {
        const s = subject as { observers?: Set<Observer<T>> }
        if (s.observers && s.observers.has(observer)) {
          s.observers.delete(observer)
        }
      })
    }
    
    // Clear observer references
    observer.value = undefined
    observer.updateFn = () => value!
    observer.subjects = []
  }
}
