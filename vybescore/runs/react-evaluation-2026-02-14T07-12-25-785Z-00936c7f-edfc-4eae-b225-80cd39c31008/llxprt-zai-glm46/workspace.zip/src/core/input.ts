/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

// Extend Subject to track observers
interface ReactiveSubject<T> extends Subject<T> {
  observers: Set<ObserverR>
}

// Helper to recursively update observers in two phases
// Phase 1: Update all observers at this level
// Phase 2: Recursively update observers of observers
function updateObserversRecursive(observers: ObserverR[], visited = new Set<ObserverR>()): void {
  // Phase 1: Update all observers at current level first
  observers.forEach(observer => {
    if (visited.has(observer)) return
    visited.add(observer)
    
    // Clear subjects to allow re-tracking dependencies
    const observerWithSubjects = observer as { subjects?: Subject<unknown>[] }
    observerWithSubjects.subjects = undefined
    
    // Update observer by calling updateObserver
    // This will set observer as active and call its update function
    // which will re-track dependencies
    updateObserver(observer as Parameters<typeof updateObserver>[0])
  })
  
  // Phase 2: Recursively update observers of observers
  observers.forEach(observer => {
    const observerWithObservers = observer as { observers?: Set<ObserverR> }
    if (observerWithObservers.observers) {
      updateObserversRecursive(Array.from(observerWithObservers.observers), visited)
    }
  })
}

/**
 * Creates an input closure. The value is accessed
 * via accessor and changed via
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers = new Set<ObserverR>()  
  const s: ReactiveSubject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    observers,
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      const fullObserver = activeObserver as { subjects?: Subject<T>[] }
      // Register this observer as dependent on this subject
      if (!observers.has(activeObserver)) {
        observers.add(activeObserver)
      }
      // Track this subject in observer's dependencies
      if (!fullObserver.subjects) {
        fullObserver.subjects = []
      }
      if (!fullObserver.subjects.includes(s)) {
        fullObserver.subjects.push(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers that depend on this subject recursively
    updateObserversRecursive(Array.from(observers))
    return s.value
  }

  return [read, write]
}
