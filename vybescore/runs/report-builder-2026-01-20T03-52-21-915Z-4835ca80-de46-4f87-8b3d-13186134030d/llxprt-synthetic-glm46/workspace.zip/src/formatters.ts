import type { ReportData, RenderOptions, Format } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

const FORMATTERS = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export function renderReport(data: ReportData, format: Format, options: RenderOptions): string {
  const formatter = FORMATTERS[format];
  return formatter(data, options);
}

export type { Format } from './types.js';