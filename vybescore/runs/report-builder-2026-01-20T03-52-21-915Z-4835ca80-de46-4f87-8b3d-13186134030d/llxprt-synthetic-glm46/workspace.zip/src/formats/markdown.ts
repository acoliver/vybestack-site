import type { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let result = `# ${title}\n\n${summary}\n\n## Entries\n`;

  for (const entry of entries) {
    result += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n**Total:** $${total.toFixed(2)}`;
  }

  return result;
}