import type { ReportData, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let result = `${title}\n${summary}\n\nEntries:\n`;

  for (const entry of entries) {
    result += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `Total: $${total.toFixed(2)}`;
  }

  return result;
}