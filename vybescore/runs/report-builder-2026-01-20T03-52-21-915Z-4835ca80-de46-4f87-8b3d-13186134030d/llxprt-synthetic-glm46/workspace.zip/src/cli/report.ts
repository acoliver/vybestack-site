#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { parseArguments } from '../utils/args.js';
import { loadJsonFile } from '../utils/validation.js';
import { renderReport } from '../formatters.js';

try {
  const args = parseArguments(process.argv);
  const data = loadJsonFile(args.inputFile);
  const output = renderReport(data, args.format, { includeTotals: args.includeTotals });

  if (args.outputPath) {
    writeFileSync(args.outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
} catch (error) {
  console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}
