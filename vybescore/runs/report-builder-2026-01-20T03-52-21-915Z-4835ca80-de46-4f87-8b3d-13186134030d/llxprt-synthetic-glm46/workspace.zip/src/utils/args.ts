import type { CliArgs, Format } from '../types.js';

const SUPPORTED_FORMATS = ['markdown', 'text'] as const;

function parseFormat(format: string): Format {
  if (!SUPPORTED_FORMATS.includes(format as Format)) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return format as Format;
}

export function parseArguments(argv: string[]): CliArgs {
  const args: CliArgs = {
    inputFile: '',
    format: 'markdown',
    includeTotals: false,
  };

  let i = 2; // Skip node and script name
  while (i < argv.length) {
    const arg = argv[i];

    switch (arg) {
      case '--format':
        i++;
        if (i >= argv.length) {
          throw new Error('Missing format argument');
        }
        args.format = parseFormat(argv[i]);
        break;
      case '--output':
        i++;
        if (i >= argv.length) {
          throw new Error('Missing output path argument');
        }
        args.outputPath = argv[i];
        break;
      case '--includeTotals':
        args.includeTotals = true;
        break;
      default:
        if (arg.startsWith('-')) {
          throw new Error(`Unknown option: ${arg}`);
        }
        if (args.inputFile) {
          throw new Error('Multiple input files specified');
        }
        args.inputFile = arg;
        break;
    }
    i++;
  }

  if (!args.inputFile) {
    throw new Error('Input file is required');
  }

  return args;
}