import { readFileSync } from 'fs';
import type { ReportData } from '../types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(
        `Invalid report data: entry at index ${index} is not an object`
      );
    }
    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${index} has invalid "label" field`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${index} has invalid "amount" field`
      );
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

export function loadJsonFile(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.startsWith('Invalid report data')) {
      throw error;
    }
    throw new Error(`Failed to read file ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
  }
}