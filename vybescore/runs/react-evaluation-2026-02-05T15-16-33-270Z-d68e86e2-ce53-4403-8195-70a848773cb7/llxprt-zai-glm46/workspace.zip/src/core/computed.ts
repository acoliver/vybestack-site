/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === false ? (() => false) : 
    undefined

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Computed values act as both Observer (observing inputs) and Subject (being observed by callbacks/computed)
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value!,
    equalFn,
  }
  
  let updating = false
  
  const getter: GetterFn<T> = () => {
    const active = getActiveObserver()
    if (active) {
      // Something is observing this computed value
      subject.observer = active
      
      // Recompute to ensure dependencies are up-to-date
      // This ensures that when sum() calls timesTwo(), timesTwo re-registers
      // its dependencies (like input) correctly
      if (!updating) {
        updateObserver(observer)
        subject.value = observer.value!
      }
    }
    
    return subject.value
  }
  
  // When the observer updates (because dependencies changed), 
  // notify our observer
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    if (updating) return originalUpdateFn(prevValue)
    
    updating = true
    try {
      const newValue = originalUpdateFn(prevValue)
      subject.value = newValue
      
      if (subject.observer) {
        // Notify whoever is observing this computed
        updateObserver(subject.observer as Observer<unknown>)
      }
      return newValue
    } finally {
      updating = false
    }
  }
  
  // Initial computation to establish dependencies
  updateObserver(observer)
  subject.value = observer.value!
  
  return getter
}
