import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const rawPage = options.page;
  const rawLimit = options.limit;

  const page = rawPage && rawPage > 0 ? Math.floor(rawPage) : 1;
  const limit = rawLimit && rawLimit > 0 ? Math.floor(rawLimit) : DEFAULT_LIMIT;

  if (rawPage !== undefined && (isNaN(rawPage) || rawPage <= 0 || !Number.isFinite(rawPage))) {
    return { items: [], page: 1, limit: DEFAULT_LIMIT, total, hasNext: false, error: 'Invalid page parameter' };
  }

  if (rawLimit !== undefined && (isNaN(rawLimit) || rawLimit <= 0 || !Number.isFinite(rawLimit))) {
    return { items: [], page: 1, limit: DEFAULT_LIMIT, total, hasNext: false, error: 'Invalid limit parameter' };
  }

  if (limit > 100) {
    return { items: [], page, limit: DEFAULT_LIMIT, total, hasNext: false, error: 'Limit exceeds maximum of 100' };
  }

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = (page + 1) * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
