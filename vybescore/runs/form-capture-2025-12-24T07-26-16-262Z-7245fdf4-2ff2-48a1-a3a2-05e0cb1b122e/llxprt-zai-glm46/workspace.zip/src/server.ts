import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

// Request body type
type RequestBody = {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
};

const app = express();
let db: Database | null = null;

// Validation functions
function validateNotEmpty(value: string, fieldName: string): string | null {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return null;
}

function validateEmail(email: string): string | null {
  const trimmed = email.trim();
  if (!trimmed) {
    return 'Email is required';
  }
  // Simple but effective email regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return 'Please enter a valid email address';
  }
  return null;
}

function validatePhone(phone: string): string | null {
  const trimmed = phone.trim();
  if (!trimmed) {
    return 'Phone number is required';
  }
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(trimmed)) {
    return 'Please enter a valid phone number';
  }
  return null;
}

function validatePostalCode(code: string): string | null {
  const trimmed = code.trim();
  if (!trimmed) {
    return 'Postal/Zip code is required';
  }
  // Allow alphanumeric strings with spaces (handles UK SW1A 1AA, Argentine C1000, etc.)
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  if (!postalRegex.test(trimmed)) {
    return 'Please enter a valid postal/zip code';
  }
  return null;
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  const firstNameError = validateNotEmpty(data.firstName || '', 'First name');
  if (firstNameError) errors.push(firstNameError);

  const lastNameError = validateNotEmpty(data.lastName || '', 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const streetAddressError = validateNotEmpty(data.streetAddress || '', 'Street address');
  if (streetAddressError) errors.push(streetAddressError);

  const cityError = validateNotEmpty(data.city || '', 'City');
  if (cityError) errors.push(cityError);

  const stateProvinceError = validateNotEmpty(data.stateProvince || '', 'State/Province/Region');
  if (stateProvinceError) errors.push(stateProvinceError);

  const postalCodeError = validatePostalCode(data.postalCode || '');
  if (postalCodeError) errors.push(postalCodeError);

  const countryError = validateNotEmpty(data.country || '', 'Country');
  if (countryError) errors.push(countryError);

  const emailError = validateEmail(data.email || '');
  if (emailError) errors.push(emailError);

  const phoneError = validatePhone(data.phone || '');
  if (phoneError) errors.push(phoneError);

  return {
    valid: errors.length === 0,
    errors,
  };
}

function parseFormData(body: RequestBody): Partial<FormData> {
  return {
    firstName: body.firstName?.trim() || '',
    lastName: body.lastName?.trim() || '',
    streetAddress: body.streetAddress?.trim() || '',
    city: body.city?.trim() || '',
    stateProvince: body.stateProvince?.trim() || '',
    postalCode: body.postalCode?.trim() || '',
    country: body.country?.trim() || '',
    email: body.email?.trim() || '',
    phone: body.phone?.trim() || '',
  };
}

// Initialize database
async function initializeDatabase(): Promise<Database> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let dbBytes: Uint8Array | null = null;

  // Load existing database if it exists
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbBytes = new Uint8Array(buffer);
  }

  const SQL = await initSqlJs();
  const database = dbBytes ? new SQL.Database(dbBytes) : new SQL.Database();

  // Initialize schema
  if (fs.existsSync(SCHEMA_PATH)) {
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
  }

  return database;
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    },
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = parseFormData(req.body);
  const validation = validateForm(formData);

  if (!validation.valid) {
    res.status(400);
    return res.render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName!,
      formData.lastName!,
      formData.streetAddress!,
      formData.city!,
      formData.stateProvince!,
      formData.postalCode!,
      formData.country!,
      formData.email!,
      formData.phone!,
    ]);

    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Configure EJS
app.set('view engine', 'ejs');
// When running from TypeScript/development, templates are in src/templates
// When running from compiled JS, we still use src/templates (templates aren't copied)
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;

async function closeServer(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
  if (server) {
    return new Promise<void>((resolve) => {
      server!.close(() => resolve());
    });
  }
}

// Start server
export async function startServer(port: number = 0): Promise<typeof server> {
  db = await initializeDatabase();
  return new Promise((resolve) => {
    server = app.listen(port, () => {
      const addr = server!.address();
      const actualPort = typeof addr === 'object' && addr ? addr.port : port;
      console.log(`Server listening on port ${actualPort}`);
      resolve(server);
    });
  });
}

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, closing server gracefully');
  await closeServer();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, closing server gracefully');
  await closeServer();
  process.exit(0);
});

// Start server if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  startServer(port).catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { closeServer, app };
