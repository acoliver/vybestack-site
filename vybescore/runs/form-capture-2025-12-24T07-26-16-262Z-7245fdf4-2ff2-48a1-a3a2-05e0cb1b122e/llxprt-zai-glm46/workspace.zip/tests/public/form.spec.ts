import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, closeServer, startServer } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  // Start the server on a test port (0 for random available port)
  await startServer(0);
});

afterAll(async () => {
  await closeServer();
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text);

    // Check for all form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check that labels are properly associated with inputs
    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('label[for="email"]').text()).toBe('Email');
    expect($('label[for="phone"]').text()).toBe('Phone number');

    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('shows validation errors for empty required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});

    expect(response.status).toBe(400);

    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'not-an-email',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);

    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone!',
      });

    expect(response.status).toBe(400);

    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('valid phone');
  });

  it('persists submission and redirects to thank you page', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Check thank you page
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);

    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain('identity');
  });

  it('accepts international postal codes', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678',
      });

    expect(response.status).toBe(302);
  });

  it('retains form values on validation error', async () => {
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test St',
      city: 'Testville',
      stateProvince: 'TS',
      postalCode: '12345',
      country: 'Testland',
      email: 'invalid-email', // Will cause validation error
      phone: '+1 555-999-8888',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(400);

    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('Test');
    expect($('input[name="city"]').val()).toBe('Testville');
    expect($('input[name="email"]').val()).toBe('invalid-email');
  });
});
