/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words that start with the prefix
  // Using word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z0-9]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  const filteredMatches = matches.filter(word => {
    return !exceptionsSet.has(word.toLowerCase());
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at the start
  // Return the full occurrences including the digit
  const digitTokenPattern = new RegExp(`\\d${token}`, 'g');
  const fullMatchesResult = text.match(digitTokenPattern) || [];

  return fullMatchesResult;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol using individual character checks
  const symbols = '!@#$%^&*()_+-=[]{};\':",.<>\\/';
  const hasSymbol = Array.from(value).some(char => symbols.includes(char));
  if (!hasSymbol) {
    return false;
  }
  
  // Check for no immediate repeated sequences like "abab"
  // Pattern to detect immediate repetitions (2+ characters repeating)
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's a pure IPv4 address (should not match)
  const ipv4Pattern = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false; // Pure IPv4 should not match IPv6 detection
  }
  
  // Check for IPv6 patterns anywhere in the string
  // IPv6 full notation pattern (8 groups of 1-4 hex digits)
  const fullIPv6 = /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/;
  
  // IPv6 with shorthand :: compression - look for :: anywhere
  const shorthandIPv6 = /[0-9a-fA-F]*::[0-9a-fA-F]*/;
  
  // IPv6 with embedded IPv4 at the end (like ::ffff:192.0.2.1)
  const ipv4Embedded = /::ffff:(\d{1,3}\.){3}\d{1,3}/;
  
  // Check for shorthand patterns like 2001:db8::1
  if (value.includes('::')) {
    // Additional validation - check for valid hex segments
    const segments = value.split('::')[0].split(':');
    const validSegments = segments.every(segment => {
      if (segment === '') return true; // Allow empty segments
      const hexNum = parseInt(segment, 16);
      return segment.length <= 4 && hexNum >= 0;
    });
    
    if (validSegments && !value.match(/\d+\.\d+\.\d+\.\d+/)) {
      return true;
    }
  }
  
  // Check for standard IPv6 format with colons
  if (value.includes(':')) {
    // Must not be pure numbers with dots (IPv4 format)
    if (!value.match(/\d+\.\d+\.\d+\.\d+/)) {
      // General IPv6 check - check for hex segments separated by colons
      const hexPattern = /^[0-9a-fA-F:]+$/;
      if (hexPattern.test(value)) {
        return true;
      }
      
      // Check for embedded IPv4
      if (ipv4Embedded.test(value)) {
        return true;
      }
      
      // Check for full IPv6 notation
      if (fullIPv6.test(value)) {
        return true;
      }
      
      // Check for shorthand IPv6
      if (shorthandIPv6.test(value)) {
        return true;
      }
    }
  }
  
  return false;
}
