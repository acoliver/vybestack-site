/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence boundaries followed by lowercase letters
  const sentenceBoundaryRegex = /([.!?]+)(\s*)([a-z])/g;
  
  // Replace sentence boundaries followed by lowercase with capitalized version
  let result = text.replace(
    sentenceBoundaryRegex, 
    (match, punctuation, spaces, letter) => {
      return punctuation + spaces + letter.toUpperCase();
    }
  );
  
  // Handle the first character of the text
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  // Ensure exactly one space after sentence endings, collapse extra spaces
  result = result.replace(/([.!?]+)\s{2,}/g, '$1 ');
  
  // Handle abbreviations to prevent unwanted capitalization
  const abbreviations = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'vs.', 'etc.', 'e.g.', 'i.e.'];
  
  abbreviations.forEach(abbrev => {
    // Don't capitalize after abbreviations
    const abbrevPattern = new RegExp(`(${abbrev.replace('.', '\\.')})\\s+([A-Z])`, 'g');
    result = result.replace(abbrevPattern, (match, abbrevText, nextLetter) => {
      return abbrevText + ' ' + nextLetter.toLowerCase();
    });
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern to match http/https URLs with optional www
  // Pattern captures the URL without trailing punctuation
  const urlRegex = /\b(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s\w.,!?]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation but preserve valid URL characters
    return url.replace(/[.,!?]+$/g, '');
  });
  
  // Filter out invalid or too short URLs
  const validUrls = cleanUrls.filter(url => {
    // Must contain at least one dot (domain separator)
    if (!url.includes('.')) {
      return false;
    }
    
    // Must have at least one character before the dot
    const parts = url.split('.');
    if (parts[0].length === 0) {
      return false;
    }
    
    return true;
  });
  
  return validUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs where the path begins with /docs/
  const docsUrlRegex = /http:\/\/([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/docs\/[^\s]*)/g;
  
  return text.replace(docsUrlRegex, (match, host, path) => {
    // Check for dynamic hints or legacy extensions
    const dynamicHints = /(cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    const hasDynamicHints = dynamicHints.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade the scheme, don't rewrite host
      return match.replace(/http:\/\//, 'https://');
    }
    
    // If path begins with /docs/, rewrite host to docs.example.com
    // Split host to get domain parts (e.g., "example.com" -> ["example", "com"])
    const hostParts = host.split('.');
    if (hostParts.length >= 2) {
      // Insert "docs" at the beginning: ["docs", "example", "com"] -> "docs.example.com"
      const docsHost = 'docs.' + host;
      return match
        .replace(/http:\/\//, 'https://')
        .replace(host, docsHost);
    }
    
    // Fallback - just upgrade scheme
    return match.replace(/http:\/\//, 'https://');
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // February allows 29 for simplicity
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Additional validation for February (month 2)
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // Validate that year is 4 digits (already ensured by regex, but good practice)
  if (yearStr.length !== 4) {
    return 'N/A';
  }
  
  return yearStr;
}
