export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email pattern that accepts typical formats but rejects invalid patterns
  // Rejects: double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9.+_-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot before @
  if (value.match(/\.@/)) {
    return false;
  }
  
  // Reject domain with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Note: _options parameter reserved for future extensions (intentionally unused)
  void _options; // Explicitly mark as intentionally unused
  // Remove common separators and spaces for validation
  const cleanValue = value.replace(/[\s().-]/g, '');
  
  // Check for optional +1 prefix
  const phoneRegex = /^(?:\+?1[\s.-]?)?(\([2-9][0-9][0-9]\)|[2-9][0-9][0-9])[\s.-]?[2-9][0-9][0-9][\s.-]?[0-9]{4}$/;
  
  if (!phoneRegex.test(cleanValue)) {
    return false;
  }
  
  // Extract area code for validation
  const areaCodeMatch = cleanValue.match(/^\+?1?(\([2-9][0-9][0-9]\)|[2-9][0-9][0-9])/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1].replace(/[()]/g, '');
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate total length (10 digits for US numbers without country code)
  const digitsOnly = cleanValue.replace(/\D/g, '');
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If there's a country code, it should be exactly 11 digits
  if (cleanValue.startsWith('+1') && digitsOnly.length !== 11) {
    return false;
  }
  
  // If no country code, should be exactly 10 digits
  if (!cleanValue.startsWith('+1') && digitsOnly.length !== 10) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators and spaces for validation
  const cleanValue = value.replace(/[\s().-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Group 1: Optional +54 country code (must be exactly +54 when present)
  // Group 2: Area code (2-4 digits, leading digit 1-9)
  // Group 3: Subscriber number (6-8 digits total)
  
  // First check if it's a valid format with country code
  const withCountryCode = /^\+54([1-9][0-9]{1,3})([0-9]{6,8})$/;
  const withoutCountryCode = /^0([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  let match = cleanValue.match(withCountryCode);
  let hasCountryCode = false;
  
  if (!match) {
    // Try without country code
    match = cleanValue.match(withoutCountryCode);
    hasCountryCode = false;
  } else {
    hasCountryCode = true;
  }
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Validate area code length
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate that there are no leading zeros in area code
  if (areaCode[0] === '0') {
    return false;
  }
  
  // If no country code was found, ensure the original had trunk prefix
  if (!hasCountryCode && !value.includes('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name should contain only letters, spaces, apostrophes, hyphens
  // Unicode letters and accents are allowed, but no digits or symbols
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that are too short (less than 2 characters)
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject names containing digits or unusual symbols (already caught by regex above)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with unusual patterns like "X Æ A-12"
  if (value.match(/[ÆØÅæøå]/) && !value.match(/[\p{L}]/u)) {
    return false;
  }
  
  // Reject names that are only spaces or special characters
  const cleanName = value.replace(/[\s'-]/g, '');
  if (cleanName.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').reverse().map(Number);
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    // Double every second digit starting from the second position
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Visa: 4 followed by 12-18 more digits
  const visaRegex = /^4[0-9]{12,18}$/;
  
  // Mastercard: 51-55 followed by 14 more digits
  const mastercardRegex = /^5[1-5][0-9]{14}$/;
  
  // American Express: 34 or 37 followed by 13 more digits
  const amexRegex = /^(?:34|37)[0-9]{13}$/;
  
  // Check if it matches any of the card type patterns
  if (!visaRegex.test(cleanValue) && 
      !mastercardRegex.test(cleanValue) && 
      !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Validate length (13-19 digits total)
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
