/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Rejects invalid Base64 input.
 */
export function decode(input: string): string {
  // Handle empty input as special case
  if (input.length === 0) {
    return '';
  }
  
  // Basic character validation - only allow valid Base64 characters
  // This catches obviously invalid inputs before attempting to decode
  const invalidCharRegex = /[^A-Za-z0-9+/=]/;
  if (invalidCharRegex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error('Invalid Base64 input: malformed encoding');
    }
    throw new Error('Invalid Base64 input: malformed encoding');
  }
}
