const BASE64_ALPHABET = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded Base64 input and validates the format.
 */
export function decode(input: string): string {
  // Add padding if missing
  let normalized = input;
  const missingPadding = normalized.length % 4;
  if (missingPadding > 0) {
    normalized = normalized.padEnd(normalized.length + (4 - missingPadding), '=');
  }

  // Validate that the input uses only valid Base64 characters
  if (!BASE64_ALPHABET.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
