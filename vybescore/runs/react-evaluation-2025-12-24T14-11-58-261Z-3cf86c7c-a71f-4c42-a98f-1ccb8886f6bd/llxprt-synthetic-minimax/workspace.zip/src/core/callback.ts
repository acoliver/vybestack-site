/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Import the registration functions from input module
import { registerObserver, unregisterObserver } from './input.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn
  }
  
  // Register this observer so it gets notified when dependencies change
  registerObserver(observer)
  
  // Immediately call the update function to establish dependencies
  updateObserver(observer)
  
  return () => {
    observer.disposed = true
    unregisterObserver(observer)
  }
}
