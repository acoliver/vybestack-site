/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Global registry for all observers
const observers: Observer<any>[] = []

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: equal
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      // Record this subject as being accessed by the current observer
      if (!observer.observedSubjects) {
        observer.observedSubjects = new Set()
      }
      observer.observedSubjects.add(s)
    }
    
    return s.value
  }

  const write: SetterFn<T> = (newValue: T) => {
    // Check if value actually changed
    let shouldUpdate = false
    if (s.equalFn) {
      shouldUpdate = !s.equalFn(s.value, newValue)
    } else {
      shouldUpdate = s.value !== newValue
    }
    
    if (shouldUpdate) {
      s.value = newValue
      
      // Notify all observers that depend on this subject
      // Create a snapshot to avoid issues during iteration
      const observersSnapshot = [...observers]
      for (const observer of observersSnapshot) {
        if (observer.observedSubjects?.has(s) && !observer.disposed) {
          updateObserver(observer)
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}

// Export functions for other modules to register/unregister observers
export function registerObserver<T>(observer: Observer<T>) {
  if (!observers.includes(observer)) {
    observers.push(observer)
  }
}

export function unregisterObserver<T>(observer: Observer<T>) {
  const index = observers.indexOf(observer)
  if (index > -1) {
    observers.splice(index, 1)
  }
}
