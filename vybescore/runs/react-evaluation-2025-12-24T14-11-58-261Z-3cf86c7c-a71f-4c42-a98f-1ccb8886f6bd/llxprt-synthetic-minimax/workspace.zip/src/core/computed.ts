/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

// Import the registration functions from input module
import { registerObserver } from './input.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observedSubjects: new Set()
  }
  
  // Register this observer so it can be notified when its dependencies change
  registerObserver(observer)
  
  const getter = (): T => {
    // Clear previous dependencies
    if (!observer.observedSubjects) {
      observer.observedSubjects = new Set()
    }
    observer.observedSubjects.clear()
    
    // Set this observer as the active observer so that when we call
    // input/computed getters, they will track this as a dependency
    const currentObserver = getActiveObserver()
    
    // Temporarily set this observer as active to track dependencies
    const previous = getActiveObserver()
    // Manually set active observer for dependency tracking
    ;(globalThis as any).activeObserver = observer
    
    try {
      // Call the update function, which will read dependencies
      observer.value = updateFn(observer.value)
    } finally {
      // Restore previous active observer
      ;(globalThis as any).activeObserver = previous
    }
    
    return observer.value as T
  }
  
  return getter
}
