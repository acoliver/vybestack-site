#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types/report.js';
import { getFormatter } from '../formatters.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const parsed: CliArgs = {
    inputFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format') {
      if (!nextArg) {
        throw new Error('--format requires a value');
      }
      parsed.format = nextArg;
      i++;
    } else if (arg === '--output') {
      if (!nextArg) {
        throw new Error('--output requires a value');
      }
      parsed.outputPath = nextArg;
      i++;
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!parsed.inputFile) {
      parsed.inputFile = arg;
    }
  }

  if (!parsed.inputFile) {
    throw new Error('Input file path is required');
  }

  if (!parsed.format) {
    throw new Error('--format is required');
  }

  return parsed;
}

function loadReportData(filePath: string): ReportData {
  const content = fs.readFileSync(filePath, 'utf-8');
  const data = JSON.parse(content) as unknown;

  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "label" field (expected string)`);
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArguments(process.argv.slice(2));

    const data = loadReportData(args.inputFile);
    const formatter = getFormatter(args.format);

    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
