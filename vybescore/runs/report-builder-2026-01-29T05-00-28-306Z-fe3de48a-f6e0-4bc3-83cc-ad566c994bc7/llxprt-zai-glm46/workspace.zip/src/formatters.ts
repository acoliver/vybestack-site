import type { Formatter } from './types/report.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

export const formatters: Record<string, Formatter['render']> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: string): Formatter['render'] {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
