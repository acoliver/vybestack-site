/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, updateObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const callbackObserver: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }
  
  // Execute the callback with dependency tracking initially
  const executeCallback = () => {
    if (!disposed) {
      updateObserver(callbackObserver)
    }
  }
  
  // Track dependencies and register this callback
  const trackerObserver: Observer<T> = {
    name: 'callback-tracker',
    value,
    updateFn: () => {
      if (!disposed) {
        executeCallback()
      }
      return value as T
    }
  }
  
  // Initial execution to track dependencies
  executeCallback()
  
  // Cleanup function to remove subscriptions and prevent memory leaks
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observers to stop further updates
    callbackObserver.value = undefined
    callbackObserver.updateFn = () => value!
    trackerObserver.value = undefined
    trackerObserver.updateFn = () => value!
  }
  
  return unsubscribe
}
