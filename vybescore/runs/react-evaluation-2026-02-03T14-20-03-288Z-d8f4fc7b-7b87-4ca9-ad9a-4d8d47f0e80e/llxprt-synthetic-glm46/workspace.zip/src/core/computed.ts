/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === false) return undefined
  if (equal === true || equal === undefined) return (lhs: T, rhs: T) => lhs === rhs
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn: createEqualFn(equal),
  }
  
  let computing = false
  
  const compute = () => {
    if (computing) return s.value
    computing = true
    try {
      const newValue = updateFn()
      const equalFn = s.equalFn
      if (equalFn && !equalFn(s.value, newValue)) {
        s.value = newValue
        if (s.observer) {
          updateObserver(s.observer as Observer<unknown>)
        }
      } else if (!equalFn) {
        s.value = newValue
        if (s.observer) {
          updateObserver(s.observer as Observer<unknown>)
        }
      }
    } finally {
      computing = false
    }
    return s.value
  }
  
  const getter: GetterFn<T> = () => {
    compute()
    const observer = getActiveObserver()
    if (observer && !computing) {
      s.observer = observer
    }
    return s.value
  }
  
  // Initial computation
  compute()
  
  return getter
}
