/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  disposed?: boolean
}

export interface Subject<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<unknown>>
}

let activeObserver: Observer<unknown> | undefined = undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): Observer<unknown> | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous as Observer<unknown> | undefined
  }
}

export function subscribe<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function unsubscribeFromSubject<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers?.delete(observer)
}

export function notifySubject<T>(subject: Subject<T>): void {
  if (subject.observers) {
    // Create a copy to avoid issues if observers are removed during iteration
    const observers = new Set(subject.observers)
    for (const observer of observers) {
      // Skip disposed observers
      if (!observer.disposed) {
        updateObserver(observer)
      }
    }
  }
}
