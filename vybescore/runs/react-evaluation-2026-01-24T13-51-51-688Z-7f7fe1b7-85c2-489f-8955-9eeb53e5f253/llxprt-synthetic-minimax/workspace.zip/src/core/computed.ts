/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  EqualFn,
  getActiveObserver,
  updateObserver,
  notifySubject,
  Subject,
  subscribe,
  unsubscribeFromSubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false
  }
  
  // Create a subject interface for this computed value
  // so callbacks can subscribe to computed value changes
  const computedSubject: Subject<T> = {
    name: options?.name,
    value: value!,
    observers: new Set(),
    equalFn: undefined
  }
  
  // Override the observer's update function to also notify subscribers
  const originalUpdateFn = o.updateFn
  o.updateFn = (newValue?: T) => {
    const result = originalUpdateFn(newValue)
    if (typeof result !== 'undefined') {
      computedSubject.value = result
      // Notify all subscribers that the computed value has changed
      notifySubject(computedSubject)
    }
    return result
  }
  
  // Create the getter that evaluates the computation
  const getter: GetterFn<T> = () => {
    // Set this observer as active to track dependencies during evaluation
    const previous = setActiveObserver(o as Observer<unknown>)
    try {
      // Evaluate the function to establish dependencies
      // This will call any reactive inputs accessed, which will subscribe this observer
      o.value = updateFn(o.value)
      computedSubject.value = o.value!
    } finally {
      // Restore previous active observer
      setActiveObserver(previous as Observer<unknown> | undefined)
    }
    
    return o.value!
  }
  
  return getter
}
