/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false
  }
  
  // Re-evaluate the callback function whenever dependencies notify
  observer.updateFn = () => {
    const currentActive = getActiveObserver()
    try {
      setActiveObserver(observer as Observer<unknown>)
      observer.value = updateFn(observer.value)
    } finally {
      setActiveObserver(currentActive)
    }
    return observer.value!
  }
  
  // Establish dependencies by evaluating the callback in observer context
  const previous = setActiveObserver(observer as Observer<unknown>)
  try {
    observer.value = updateFn(observer.value)
  } finally {
    setActiveObserver(previous as Observer<unknown> | undefined)
  }
  
  // Override the observer's update function to re-evaluate the callback when dependencies change
  observer.updateFn = () => {
    const currentActive = getActiveObserver()
    try {
      setActiveObserver(observer as Observer<unknown>)
      observer.value = updateFn(observer.value)
    } finally {
      setActiveObserver(currentActive)
    }
    return observer.value!
  }
  
  const unsubscribe = () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Disable this observer's update function
    observer.updateFn = () => observer.value!
  }
  
  return unsubscribe
}
