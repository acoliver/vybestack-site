import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sql: SqlJsStatic | null = null;
  private dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  private schemaPath = path.join(process.cwd(), 'db', 'schema.sql');

  async initialize(): Promise<void> {
    this.sql = await initSqlJs({
      locateFile: (file) => {
        return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    let buffer: Uint8Array | undefined;
    if (fs.existsSync(this.dbPath)) {
      buffer = new Uint8Array(fs.readFileSync(this.dbPath));
    }

    this.db = new this.sql.Database(buffer);

    // Initialize schema if it doesn't exist
    if (fs.existsSync(this.schemaPath)) {
      const schema = fs.readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schema);
    }
  }

  insertSubmission(submission: Omit<Submission, 'id'>): number {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();

    // Get the last inserted row ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    return result[0].values[0][0] as number;
  }

  getAllSubmissions(): Submission[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
    const submissions: Submission[] = [];

    while (stmt.step()) {
      const row = stmt.getAsObject() as unknown as Submission;
      submissions.push(row);
    }

    stmt.free();
    return submissions;
  }

  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();