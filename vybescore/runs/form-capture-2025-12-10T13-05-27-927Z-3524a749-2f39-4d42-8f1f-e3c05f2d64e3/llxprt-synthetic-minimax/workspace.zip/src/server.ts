import express, { Request, Response } from 'express';
import path from 'path';
import { dbManager, Submission } from './database';

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length <= 20;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings, spaces, dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3 && postalCode.length <= 10;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field.replace('_', ' ')} is required` });
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation
  if (data.postal_code && !validatePostalCode(data.postal_code)) {
    errors.push({ field: 'postal_code', message: 'Please enter a valid postal code' });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: {}, 
    errors: [],
    title: 'Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    first_name: req.body.first_name?.trim() || '',
    last_name: req.body.last_name?.trim() || '',
    street_address: req.body.street_address?.trim() || '',
    city: req.body.city?.trim() || '',
    state_province: req.body.state_province?.trim() || '',
    postal_code: req.body.postal_code?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400).render('form', { 
      data: formData, 
      errors,
      title: 'Contact Form - Please Fix Errors'
    });
    return;
  }

  try {
    const submission: Omit<Submission, 'id'> = {
      first_name: formData.first_name,
      last_name: formData.last_name,
      street_address: formData.street_address,
      city: formData.city,
      state_province: formData.state_province,
      postal_code: formData.postal_code,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    dbManager.insertSubmission(submission);
    dbManager.save();
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', { 
      data: formData, 
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      title: 'Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  dbManager.close();
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();