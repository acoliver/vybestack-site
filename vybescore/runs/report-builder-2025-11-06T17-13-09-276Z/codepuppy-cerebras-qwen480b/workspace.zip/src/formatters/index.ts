import type { ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

export type SupportedFormat = 'markdown' | 'text';

const formatters: Record<SupportedFormat, ReportRenderer['render']> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: string): ReportRenderer['render'] {
  const formatter = formatters[format as SupportedFormat];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

export { renderMarkdown, renderText };
export type { ReportData, RenderOptions, ReportRenderer } from '../types.js';