#!/usr/bin/env node

import { readFile } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getFormatter } from '../formatters/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next arg
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next arg
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    return false;
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function loadReportData(filePath: string): Promise<ReportData> {
  return new Promise((resolve, reject) => {
    readFile(filePath, 'utf8', (err, data) => {
      if (err) {
        reject(new Error(`Failed to read file: ${filePath}`));
        return;
      }
      
      try {
        const parsed = JSON.parse(data);
        if (!validateReportData(parsed)) {
          reject(new Error('Invalid report data format'));
          return;
        }
        resolve(parsed);
      } catch (parseError) {
        reject(new Error('Invalid JSON format'));
      }
    });
  });
}

async function main(): Promise<void> {
  try {
    const args = parseArgs();
    
    const data = await loadReportData(args.dataFile);
    
    const formatter = getFormatter(args.format);
    
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    
    const output = formatter(data, options);
    
    if (args.outputPath) {
      const { writeFile } = await import('node:fs');
      writeFile(args.outputPath, output, 'utf8', (err) => {
        if (err) {
          console.error(`Failed to write to file: ${args.outputPath}`);
          process.exit(1);
        }
      });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();