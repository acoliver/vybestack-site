import type { ReportData, ReportOptions } from '../types.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  // Calculate total if needed
  const total = includeTotals
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : 0;

  // Build the text report
  const lines: string[] = [];

  // Title
  lines.push(title);
  lines.push('');

  // Summary
  lines.push(summary);
  lines.push('');

  // Entries heading
  lines.push('Entries:');
  
  // List of entries
  for (const entry of entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }

  // Total if requested
  if (includeTotals) {
    lines.push('');
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}