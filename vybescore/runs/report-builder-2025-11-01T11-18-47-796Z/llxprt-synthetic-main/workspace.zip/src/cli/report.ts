#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatRenderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function printUsage(): void {
  console.log(
    'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
  );
  console.log('Supported formats: markdown, text');
}

function parseArgs(): {
  dataFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Error: Missing required arguments');
    printUsage();
    process.exit(1);
  }

  const dataFile = args[0];

  // Find format argument
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format is required');
    printUsage();
    process.exit(1);
  }

  const format = args[formatIndex + 1];

  // Find output argument
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : null;

  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function readReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field in data');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field in data');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field in data');
    }

    // Validate each entry
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label"');
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error('Invalid entry: missing or invalid "amount"');
      }
    }

    return data;
  } catch (error: Error | unknown) {
    if (error instanceof Error && (error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    } else if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}`);
    } else {
      throw error as Error;
    }
  }
}

async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const { dataFile, format, outputPath, includeTotals } = parseArgs();

    // Check if format is supported
    if (!formatRenderers[format]) {
      console.error(`Error: Unsupported format "${format}"`);
      printUsage();
      process.exit(1);
    }

    // Read and validate the report data
    const reportData = readReportData(dataFile);

    // Create options for the renderer
    const options: ReportOptions = {
      includeTotals,
    };

    // Render the report
    const reportContent = formatRenderers[format](reportData, options);

    // Write output
    if (outputPath) {
      writeFileSync(outputPath, reportContent);
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(reportContent);
    }
  } catch (error: Error | unknown) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run the CLI
main().catch((error: Error | unknown) => {
  console.error('Unexpected error:', error instanceof Error ? error.message : String(error));
  process.exit(1);
});