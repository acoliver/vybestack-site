#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  // Find --format argument
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  // Find --output argument (optional)
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  // Check for --includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string' || !obj.title.trim()) {
    throw new Error('Invalid report data: missing or empty title');
  }
  
  if (typeof obj.summary !== 'string' || !obj.summary.trim()) {
    throw new Error('Invalid report data: missing or empty summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error(`Invalid entry at index ${index}: missing or empty label`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${index}: amount must be a valid number`);
    }
  }
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as ReportData['entries']
  };
}

async function main(): Promise<void> {
  try {
    const args = parseArguments();
    
    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = await readFile(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file '${args.dataFile}': ${error.message}`);
      } else {
        console.error(`Error: Could not read file '${args.dataFile}': ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }
    
    // Validate data structure
    let reportData: ReportData;
    try {
      reportData = validateReportData(jsonData);
    } catch (error) {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    // Select formatter
    const formatters: Record<string, (data: ReportData, options?: RenderOptions) => string> = {
      markdown: renderMarkdown,
      text: renderText,
    };
    
    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Error: Unsupported format '${args.format}'. Supported formats: ${Object.keys(formatters).join(', ')}`);
      process.exit(1);
    }
    
    // Generate report
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter(reportData, options);
    
    // Write output
    if (args.outputPath) {
      try {
        await writeFile(args.outputPath, output, 'utf-8');
        console.log(`Report written to ${args.outputPath}`);
      } catch (error) {
        console.error(`Error: Could not write to file '${args.outputPath}': ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Unexpected error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(`Fatal error: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
});