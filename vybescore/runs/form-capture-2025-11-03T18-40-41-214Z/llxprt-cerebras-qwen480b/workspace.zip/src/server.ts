import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Constants
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

// Initialize database
let db: Database | null = null;

async function initDatabase() {
  const SQL = await initSqlJs();
  let dbData: Uint8Array | null = null;

  // Load existing database or create a new one
  if (fs.existsSync(DB_PATH)) {
    dbData = fs.readFileSync(DB_PATH);
  }

  db = new SQL.Database(dbData || new Uint8Array());

  // Create the table if it doesn't exist
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.run(schema);

  return db;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Support alphanumeric postal codes (e.g. UK SW1A 1AA or Argentine C1000)
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Initialize app
const app = express();

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = req.body;
  const errors: Record<string, string> = {};

  // Validation
  if (!formData.firstName) errors.firstName = 'First name is required';
  if (!formData.lastName) errors.lastName = 'Last name is required';
  if (!formData.streetAddress) errors.streetAddress = 'Street address is required';
  if (!formData.city) errors.city = 'City is required';
  if (!formData.stateProvince) errors.stateProvince = 'State/Province is required';
  if (!formData.postalCode) errors.postalCode = 'Postal code is required';
  if (!formData.country) errors.country = 'Country is required';
  if (!formData.email) errors.email = 'Email is required';
  else if (!validateEmail(formData.email)) errors.email = 'Please enter a valid email address';
  if (!formData.phone) errors.phone = 'Phone number is required';
  else if (!validatePhone(formData.phone)) errors.phone = 'Please enter a valid phone number';
  else if (!validatePostalCode(formData.postalCode)) errors.postalCode = 'Please enter a valid postal code';

  // If validation fails, render form with errors
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }

  // Save form data to database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    stmt.free();

    // Write database back to file
    const data = db.export();
    fs.writeFileSync(DB_PATH, data);
  }

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Server startup
let server: ReturnType<typeof app.listen> | null = null;
initDatabase().then(() => {
  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server and database');
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  if (db) {
    const data = db.export();
    fs.writeFileSync(DB_PATH, data);
    db.close();
    console.log('Database closed');
  }
});

export default app;