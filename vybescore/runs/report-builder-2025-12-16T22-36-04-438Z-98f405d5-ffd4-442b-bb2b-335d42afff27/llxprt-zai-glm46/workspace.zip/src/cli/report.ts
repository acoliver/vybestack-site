#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import type { ReportData, RenderOptions, Format } from '../types.js';

const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
} as const;

interface CliArgs {
  dataFile: string;
  format: Format;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  if (!dataFile) {
    throw new Error('Data file path is required');
  }

  let format: Format | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      const formatValue = args[i];
      if (!formatValue) {
        throw new Error('Format value is required after --format');
      }
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error('Unsupported format');
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      outputFile = args[i];
      if (!outputFile) {
        throw new Error('Output path is required after --output');
      }
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, outputFile, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid title field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid summary field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid entries field (expected array)');
  }

  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid label field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid amount field (expected number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Read and parse JSON data
    const dataPath = path.resolve(args.dataFile);
    let jsonData: unknown;

    try {
      const fileContent = fs.readFileSync(dataPath, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Malformed JSON in ${args.dataFile}: ${error.message}`);
      }
      throw error;
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const formatter = formatters[args.format];
    const output = formatter.render(reportData, options);

    // Write output
    if (args.outputFile) {
      fs.writeFileSync(path.resolve(args.outputFile), output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
