import type { ReportData, RenderOptions, Formatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const textFormatter: Formatter = {
  render(report: ReportData, options: RenderOptions): string {
    const lines = [];

    // Title
    lines.push(report.title);
    
    // Summary
    lines.push(report.summary);
    lines.push('');

    // Entries
    lines.push('Entries:');
    for (const entry of report.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }

    // Total if requested
    if (options.includeTotals) {
      const total = calculateTotal(report.entries);
      lines.push(`Total: ${formatAmount(total)}`);
    }

    return lines.join('\n');
  },
};