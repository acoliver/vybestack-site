import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs } from '../utils/args.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import type { ReportData } from '../types.js';

const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
};

function validateReportData(data: unknown): ReportData {
  if (
    !data ||
    typeof data !== 'object' ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    throw new Error('Invalid report data: missing required fields');
  }

  const reportData = data as Record<string, unknown>;

  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string'
  ) {
    throw new Error('Invalid report data: title and summary must be strings');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  for (const entry of reportData.entries) {
    if (
      !entry ||
      typeof entry !== 'object' ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      throw new Error('Invalid report data: entry missing required fields');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: entry label and amount have wrong types');
    }
  }

  return data as ReportData;
}

function loadReportData(path: string): ReportData {
  try {
    const content = readFileSync(path, { encoding: 'utf8' });
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON: ${error.message}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Check if format is supported
    const formatter = formatters[args.format as keyof typeof formatters];
    if (!formatter) {
      throw new Error(`Unsupported format: ${args.format}`);
    }

    // Load and validate the report data
    const reportData = loadReportData(args.dataFile);

    // Render the report
    const output = formatter.render(reportData, {
      includeTotals: args.includeTotals,
    });

    // Write output
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, { encoding: 'utf8' });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}