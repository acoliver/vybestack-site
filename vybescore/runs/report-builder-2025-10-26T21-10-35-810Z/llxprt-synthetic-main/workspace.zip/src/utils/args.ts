export interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(args: string[]): CliArgs {
  const defaultArgs: Partial<CliArgs> = {
    includeTotals: false,
  };

  const result = { ...defaultArgs } as CliArgs;

  // First argument should be the data file
  if (args.length < 1) {
    throw new Error('Missing data file argument');
  }
  result.dataFile = args[0];

  // Parse remaining arguments
  let i = 1;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing format value after --format flag');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing output path after --output flag');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }

    i++;
  }

  if (!result.format) {
    throw new Error('Missing required --format flag');
  }

  return result;
}