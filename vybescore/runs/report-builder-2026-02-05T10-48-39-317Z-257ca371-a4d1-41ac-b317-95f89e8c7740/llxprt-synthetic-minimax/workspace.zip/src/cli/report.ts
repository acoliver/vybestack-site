import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { ReportData, RenderOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  // Minimum required: [node, script, data.json, --format, <format>]
  if (argv.length < 5) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = argv[2];
  const formatFlag = argv[3];
  const formatValue = argv[4];
  
  // Validate format flag
  if (formatFlag !== '--format') {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  // Validate format value
  const validFormats: Format[] = ['markdown', 'text'];
  
  if (!validFormats.includes(formatValue as Format)) {
    throw new Error(`Unsupported format: ${formatValue}`);
  }

  let output: string | undefined;
  let includeTotals = false;
  
  // Parse remaining arguments starting from index 5
  for (let i = 5; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--output') {
      if (i + 1 >= argv.length) {
        throw new Error('--output requires a path');
      }
      output = argv[i + 1];
      i++; // Skip next argument as it's the path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return {
    dataFile,
    format: formatValue as Format,
    output,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  // Check required fields
  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!reportData.entries || !Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  // Validate entries
  const entries = reportData.entries as unknown[];
  
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount as number)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }

  // Return validated and typed data
  return {
    title: reportData.title as string,
    summary: reportData.summary as string,
    entries: (reportData.entries as unknown[]).map(entry => {
      const entryObj = entry as Record<string, unknown>;
      return {
        label: entryObj.label as string,
        amount: entryObj.amount as number
      };
    })
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse JSON file
    const dataPath = join(process.cwd(), args.dataFile);
    const rawData = readFileSync(dataPath, 'utf-8');
    const jsonData = JSON.parse(rawData);
    
    // Validate input data
    const reportData = validateReportData(jsonData);
    
    // Render report
    const renderOptions: RenderOptions = {
      includeTotals: args.includeTotals
    };

    const formatter = args.format === 'markdown' ? renderMarkdown : renderText;
    const output = formatter.render(reportData, renderOptions);
    
    // Output result
    if (args.output) {
      const outputPath = join(process.cwd(), args.output);
      writeFileSync(outputPath, output);
    } else {
      console.log(output);
    }
    
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else if (error instanceof Error) {
      console.error('Error:', error.message);
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

main();
