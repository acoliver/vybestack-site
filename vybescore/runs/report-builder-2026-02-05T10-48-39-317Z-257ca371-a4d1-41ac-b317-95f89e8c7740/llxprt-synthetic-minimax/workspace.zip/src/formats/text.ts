import { ReportData, RenderOptions, Formatter } from '../types.js';

export const renderText: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Calculate total
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = total.toFixed(2);
    
    // Entries list
    for (const entry of data.entries) {
      const amountFormatted = entry.amount.toFixed(2);
      lines.push(`- ${entry.label}: $${amountFormatted}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      lines.push('');
      lines.push(`Total: $${totalFormatted}`);
    }
    
    return lines.join('\n');
  }
};