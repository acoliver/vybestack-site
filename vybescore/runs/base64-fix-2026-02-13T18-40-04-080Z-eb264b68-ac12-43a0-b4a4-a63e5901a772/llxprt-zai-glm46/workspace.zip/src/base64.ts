/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that a string contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    if (buffer.length === 0 && input.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
