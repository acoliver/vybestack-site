export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn checksum validation helper function
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\s/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with robust regex
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // additional checks
  // no double dots
  if (value.includes('..')) {
    return false;
  }
  
  // no leading or trailing dot in local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // no underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // valid domain structure
  const domainRegex = /^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common separators and optional +1
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length: 10 digits (standard) or 11 digits with +1 prefix
  if (digits.length !== 10 && !(digits.length === 11 && digits.startsWith('1'))) {
    return false;
  }
  
  // Extract the last 10 digits for validation
  const lastTen = digits.length === 11 ? digits.slice(1) : digits;
  
  // Area code cannot start with 0 or 1
  const areaCode = lastTen.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check overall format with regex, allowing various separators
  const regex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return regex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile/landline formats
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Optional country code (+54)
  // Optional mobile indicator (9)
  // Trunk prefix (0) when no country code
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const regex = /^(\+54)?(9)?(0?[1-9]\d{0,3})\d{6,8}$/;
  
  if (!regex.test(normalized)) {
    return false;
  }
  
  // Extract parts if match succeeded
  const match = normalized.match(/^(\+54)?(9)?(0?[1-9]\d{0,3})(\d{6,8})$/);
  if (!match) {
    return false;
  }
  
  const [, countryCode, mobileIndicator, areaCode, subscriberNumber] = match;
  
  // Extract the area code part without the optional trunk prefix
  const cleanAreaCode = areaCode.startsWith('0') ? areaCode.slice(1) : areaCode;
  
  // Area code validation: 2-4 digits with leading digit 1-9 (not 0)
  if (!/^[1-9]\d{0,3}$/.test(cleanAreaCode) || cleanAreaCode.length < 2 || cleanAreaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits after area code
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix (0) before area code
  if (!countryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  // Mobile indicator (9) must be between country/trunk and area code
  // If mobile indicator is present but no country code, the pattern should be 0 9 XXX...
  if (mobileIndicator && !countryCode && !areaCode.startsWith('09')) {
    return false;
  }
  
  // Total digits validation
  const totalDigits = normalized.replace(/\+/g, '').length;
  // With country code: +54 (2) + optional 9 (1) + area code (2-4) + subscriber (6-8) = 11-15
  // Without country code: 0 (1) + optional 9 (1) + area code (2-4) + subscriber (6-8) = 10-13
  if (countryCode && (totalDigits < 11 || totalDigits > 15)) {
    return false;
  }
  if (!countryCode && (totalDigits < 10 || totalDigits > 14)) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation
 */
export function isValidName(value: string): boolean {
  // Regex for valid names: unicode letters, spaces, hyphens, apostrophes
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: must contain at least one letter
  const containsLetter = /[\p{L}\p{M}]/u.test(value);
  if (!containsLetter) {
    return false;
  }
  
  // Reject names that are too short (after trimming)
  const trimmed = value.trim();
  if (trimmed.length < 1) {
    return false;
  }
  
  // Reject names with digits or symbols (except allowed apostrophes and hyphens)
  if (/[0-9]|\p{S}|[^\p{L}\p{M}'’\-\s]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Check basic length and prefix patterns for major cards
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  if (!(visaRegex.test(normalized) || mastercardRegex.test(normalized) || amexRegex.test(normalized))) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(normalized);
}
