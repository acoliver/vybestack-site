/**
 * Capitalize the first character of each sentence, preserving spacing rules
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence boundaries
  const normalized = text.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, nextChar) => {
    // Ensure exactly one space between sentences
    return punctuation.replace(/\s+/g, ' ') + nextChar;
  });
  
  // Split by sentence endings, but keep the delimiter
  const sentences = normalized.split(/([.!?])/);
  let result = '';
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i] || '';
    const punctuation = sentences[i + 1] || '';
    
    // Skip empty segments
    if (!sentence.trim()) {
      result += sentence + punctuation;
      continue;
    }
    
    // Collapse multiple spaces within the sentence
    const cleanSentence = sentence.replace(/\s+/g, ' ');
    
    // Find the position of the first non-whitespace character
    const firstCharIndex = cleanSentence.search(/\S/);
    if (firstCharIndex === -1) {
      result += cleanSentence + punctuation;
      continue;
    }
    
    // Capitalize the first character
    const beforeFirstChar = cleanSentence.substring(0, firstCharIndex);
    const firstChar = cleanSentence.substring(firstCharIndex, firstCharIndex + 1).toUpperCase();
    const restOfSentence = cleanSentence.substring(firstCharIndex + 1);
    
    result += beforeFirstChar + firstChar + restOfSentence + punctuation;
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /(https?:\/\/[^\s/$.?#].[^\s]*|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/gi;
  
  const matches = text.match(urlRegex) || [];
  const results = [];
  
  for (const url of matches) {
    // Remove trailing punctuation like .,!? 
    const cleanUrl = url.replace(/[,.!?:;)\]}]+$/g, '');
    
    // Ensure it's a valid URL format
    if (cleanUrl) {
      if (/^https?:\/\//.test(cleanUrl)) {
        // Full URL with protocol
        results.push(cleanUrl);
      } else if (/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/.test(cleanUrl)) {
        // Domain without protocol, we skip these as per requirements
        continue;
      }
    }
  }
  
  return results;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/(http):\/\/([^\s/]+)(\/[^\s]*)?/gi, 'https://$2$3');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/(https?):\/\/example\.com(\/[^\s]*|)/gi, (match, protocol, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if the path starts with /docs/
    if (path.startsWith('/docs/')) {
// Check for conditions that would prevent host rewrite
      const suspiciousPatterns = [
        /\/(cgi-bin|api|ws)\//i,
        /\?/,
        /=/,
        /\.asp$/i,
        /\.do$/i,
        /\.cgi$/i,
        /\.pl$/i,
        /\.py$/i
      ];
      
      // If any suspicious pattern is found, don't change the host
      let shouldSkipHostRewrite = false;
      for (const pattern of suspiciousPatterns) {
        if (path.search(pattern) !== -1) {
          shouldSkipHostRewrite = true;
          break;
        }
      }
      
      if (!shouldSkipHostRewrite) {
        return `${newProtocol}://docs.example.com${path}`;
      }
    }
    
    // Default: just upgrade the protocol
    return `${newProtocol}://example.com${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
// Validate month/day combinations (basic validation)
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
