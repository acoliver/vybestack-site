#!/usr/bin/env node

import fs from 'fs';
import { parseArgs } from 'node:util';
import type { ReportData, CLIOptions, OutputFormat } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseCLIArguments(): { dataPath: string; options: CLIOptions } {
  const { values, positionals } = parseArgs({
    args: process.argv.slice(2),
    options: {
      format: {
        type: 'string',
      },
      output: {
        type: 'string',
      },
      includeTotals: {
        type: 'boolean',
      },
    },
    allowPositionals: true,
  });

  if (positionals.length !== 1) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = positionals[0];

  if (!values.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  const format = values.format as OutputFormat;
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  return {
    dataPath,
    options: {
      format,
      outputPath: values.output as string | undefined,
      includeTotals: values.includeTotals || false,
    },
  };
}

function loadReportData(dataPath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label"');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid "amount"');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${dataPath}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: OutputFormat, includeTotals: boolean): string {
  const options = { includeTotals };
  
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error('Unsupported format');
  }
}

function main(): void {
  const { dataPath, options } = parseCLIArguments();
  const data = loadReportData(dataPath);
  const output = renderReport(data, options.format, options.includeTotals);
  
  if (options.outputPath) {
    try {
      fs.writeFileSync(options.outputPath, output);
    } catch (error) {
      console.error(`Error writing to ${options.outputPath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
