import type { ReportData, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;
  
  data.entries.forEach(entry => {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  });
  
  if (options.includeTotals) {
    output += `Total: $${total.toFixed(2)}`;
  }
  
  return output;
}

export function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}