import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, closeDatabase, insertSubmission, FormData } from './database.js';
import { validateForm } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };
    
    // Validate form data
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      // Re-render form with errors and previously entered values
      res.render('form', {
        errors,
        values: formData,
      });
      return;
    }
    
    // Insert into database
    const submissionId = insertSubmission(formData);
    console.log(`Form submission ${submissionId} saved successfully.`);
    
    // Redirect to thank-you page with first name in query param
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'An error occurred while processing your submission. Please try again.' }],
      values: req.body,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    firstName: req.query.firstName || 'Friend',
  });
});

// Let the database get initialized on startup
let server: import('http').Server;

async function startServer() {
  try {
    await initDatabase();
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', async () => {
      console.log('SIGTERM received, shutting down gracefully');
      if (server) {
        server.close(async () => {
          console.log('Express server closed');
          await closeDatabase();
          process.exit(0);
        });
      }
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
