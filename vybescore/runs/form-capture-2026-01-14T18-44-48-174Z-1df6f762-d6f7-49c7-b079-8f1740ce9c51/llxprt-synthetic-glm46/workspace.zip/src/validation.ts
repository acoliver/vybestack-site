export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Validate required fields
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required.' });
  }
  
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required.' });
  }
  
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required.' });
  }
  
  if (!formData.city || formData.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required.' });
  }
  
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required.' });
  }
  
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal code is required.' });
  }
  
  if (!formData.country || formData.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required.' });
  }
  
  // Validate email format
  if (formData.email && formData.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address.' });
    }
  } else {
    errors.push({ field: 'email', message: 'Email is required.' });
  }
  
  // Validate phone number
  if (formData.phone && formData.phone.trim() !== '') {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number.' });
    }
  } else {
    errors.push({ field: 'phone', message: 'Phone number is required.' });
  }
  
  // Validate postal code (accept alphanumeric)
  if (formData.postalCode && formData.postalCode.trim() !== '') {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(formData.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal code can contain letters, numbers, spaces, and hyphens only.' });
    }
  }
  
  return errors;
}