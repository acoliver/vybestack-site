import * as sql from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const schemaPath = path.join(__dirname, '../db/schema.sql');

interface DatabaseState {
  db: sql.Database | null;
  filePath: string;
}

const dbState: DatabaseState = {
  db: null,
  filePath: dbPath,
};

// Initialize the database
export function initDatabase(): Promise<sql.Database> {
  return new Promise((resolve, reject) => {
    (async () => {
      try {
        // Initialize SQL.js
        const SQL = await sql.default();

        let db: sql.Database;

        // Check if database file exists
        if (fs.existsSync(dbPath)) {
          // Load existing database
          const filebuffer = fs.readFileSync(dbPath);
          db = new SQL.Database(filebuffer);
        } else {
          // Create new database
          db = new SQL.Database();
          
          // Read and execute schema
          const schema = fs.readFileSync(schemaPath, 'utf8');
          db.run(schema);

          // Create data directory if it doesn't exist
          const dataDir = path.dirname(dbPath);
          if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
          }

          // Save initial database
          const data = db.export();
          fs.writeFileSync(dbPath, Buffer.from(data));
        }

        dbState.db = db;
        console.log('Database initialized successfully.');
        resolve(db);
      } catch (error) {
        console.error('Failed to initialize database:', error);
        reject(error);
      }
    })();
  });
}

// Save the database to disk
export function saveDatabase(): void {
  if (!dbState.db) {
    throw new Error('Database not initialized');
  }

  try {
    const data = dbState.db.export();
    fs.writeFileSync(dbState.filePath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Close the database
export function closeDatabase(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (dbState.db) {
      try {
        saveDatabase();
        dbState.db.close();
        dbState.db = null;
        console.log('Database closed successfully.');
        resolve();
      } catch (error) {
        console.error('Error closing database:', error);
        reject(error);
      }
    } else {
      // Database is already closed or not initialized
      resolve();
    }
  });
}

// Get the database instance
export function getDatabase(): sql.Database {
  if (!dbState.db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return dbState.db;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Insert form submission into database
export function insertSubmission(formData: FormData): number {
  const db = getDatabase();
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    // Get the last inserted row ID
    const result = db.exec('SELECT last_insert_rowid() as id');
    return result[0].values[0][0] as number;
  } finally {
    stmt.free();
    saveDatabase();
  }
}