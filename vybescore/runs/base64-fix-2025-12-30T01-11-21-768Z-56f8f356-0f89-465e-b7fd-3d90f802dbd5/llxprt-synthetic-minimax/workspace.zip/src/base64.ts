/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) 
 * with proper padding (=) as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Add padding if missing - Base64 requires padding to multiple of 4
  const normalized = input.trim();
  
  // Validate that input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check if padding is missing and add it if necessary
  let paddedInput = normalized;
  if (!normalized.endsWith('==') && !normalized.endsWith('=')) {
    // Calculate required padding
    const missingPadding = (4 - (normalized.length % 4)) % 4;
    if (missingPadding > 0) {
      paddedInput = normalized + '='.repeat(missingPadding);
    }
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
