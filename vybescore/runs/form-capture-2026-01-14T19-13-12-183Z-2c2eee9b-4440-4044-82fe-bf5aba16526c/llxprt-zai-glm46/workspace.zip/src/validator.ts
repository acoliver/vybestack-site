export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvinceRegion?: string;
  postalZipCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export class FormValidator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhone(phone: string): boolean {
    const trimmedPhone = phone.trim();
    const phoneRegex = /^[+]?(?:[0-9][\d\s)\-+(]*)?$/;
    return phoneRegex.test(trimmedPhone) && trimmedPhone.replace(/[\s\-()+]/g, '').length >= 7;
  }

  static validatePostalCode(postalCode: string): boolean {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
  }

  static validateRequired(value: string, fieldName: string): string | null {
    if (!value || value.trim().length === 0) {
      return `${fieldName} is required`;
    }
    return null;
  }

  static validateForm(formData: FormData): ValidationResult {
    const errors: string[] = [];

    const firstName = formData.firstName || '';
    const lastName = formData.lastName || '';
    const streetAddress = formData.streetAddress || '';
    const city = formData.city || '';
    const stateProvinceRegion = formData.stateProvinceRegion || '';
    const postalZipCode = formData.postalZipCode || '';
    const country = formData.country || '';
    const email = formData.email || '';
    const phone = formData.phone || '';

    const requiredError = this.validateRequired(firstName, 'First name');
    if (requiredError) errors.push(requiredError);

    const lastNameError = this.validateRequired(lastName, 'Last name');
    if (lastNameError) errors.push(lastNameError);

    const streetError = this.validateRequired(streetAddress, 'Street address');
    if (streetError) errors.push(streetError);

    const cityError = this.validateRequired(city, 'City');
    if (cityError) errors.push(cityError);

    const stateError = this.validateRequired(stateProvinceRegion, 'State / Province / Region');
    if (stateError) errors.push(stateError);

    const postalError = this.validateRequired(postalZipCode, 'Postal / Zip code');
    if (postalError) {
      errors.push(postalError);
    } else if (!this.validatePostalCode(postalZipCode)) {
      errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens');
    }

    const countryError = this.validateRequired(country, 'Country');
    if (countryError) errors.push(countryError);

    const emailError = this.validateRequired(email, 'Email');
    if (emailError) {
      errors.push(emailError);
    } else if (!this.validateEmail(email)) {
      errors.push('Email must be a valid email address');
    }

    const phoneError = this.validateRequired(phone, 'Phone number');
    if (phoneError) {
      errors.push(phoneError);
    } else if (!this.validatePhone(phone)) {
      errors.push(
        'Phone number must be valid (can contain digits, spaces, parentheses, dashes, and a leading +)'
      );
    }

    return {
      isValid: errors.length === 0,
      errors,
    };
  }
}
