import initSqlJs, { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = join(__dirname, '../../data/submissions.sqlite');
    this.schemaPath = join(__dirname, '../../db/schema.sql');
  }

  async initialize(): Promise<void> {
    const SQL = await initSqlJs();

    if (existsSync(this.dbPath)) {
      const buffer = readFileSync(this.dbPath);
      this.db = new SQL.Database(buffer);
    } else {
      this.db = new SQL.Database();
      await this.runSchema();
    }
  }

  private async runSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = readFileSync(this.schemaPath, 'utf-8');
    this.db.run(schema);
    this.save();
  }

  insertSubmission(submission: Submission): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region,
        postal_zip_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalZipCode,
      submission.country,
      submission.email,
      submission.phone,
    ]);

    stmt.free();
    this.save();
  }

  getAllSubmissions(): Submission[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const results = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');

    if (results.length === 0) {
      return [];
    }

    const columns = results[0].columns;
    const values = results[0].values;

    return values.map((row: unknown[]) => ({
      firstName: row[columns.indexOf('first_name')] as string,
      lastName: row[columns.indexOf('last_name')] as string,
      streetAddress: row[columns.indexOf('street_address')] as string,
      city: row[columns.indexOf('city')] as string,
      stateProvinceRegion: row[columns.indexOf('state_province_region')] as string,
      postalZipCode: row[columns.indexOf('postal_zip_code')] as string,
      country: row[columns.indexOf('country')] as string,
      email: row[columns.indexOf('email')] as string,
      phone: row[columns.indexOf('phone')] as string,
    }));
  }

  private save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    const buffer = Buffer.from(data);

    const dir = dirname(this.dbPath);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }

    writeFileSync(this.dbPath, buffer);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  getDatabase(): Database | null {
    return this.db;
  }
}
