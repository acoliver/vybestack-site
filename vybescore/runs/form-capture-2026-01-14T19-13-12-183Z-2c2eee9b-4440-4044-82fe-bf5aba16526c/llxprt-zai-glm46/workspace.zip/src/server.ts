import express, { Request, Response, NextFunction } from 'express';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseManager } from './database.js';
import { FormValidator, FormData } from './validator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const dbManager = new DatabaseManager();
const PORT = process.env.PORT || '3535';

app.use(express.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'views'));

interface FormRequest extends Request {
  body: FormData;
}

app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    formData: {},
    errors: [],
  });
});

app.post('/submit', (req: FormRequest, res: Response) => {
  const formData = req.body;
  const validation = FormValidator.validateForm(formData);

  if (!validation.isValid) {
    res.status(400);
    res.render('form.ejs', {
      formData,
      errors: validation.errors,
    });
    return;
  }

  try {
    dbManager.insertSubmission({
      firstName: formData.firstName!,
      lastName: formData.lastName!,
      streetAddress: formData.streetAddress!,
      city: formData.city!,
      stateProvinceRegion: formData.stateProvinceRegion!,
      postalZipCode: formData.postalZipCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!,
    });

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500);
    res.render('form.ejs', {
      formData,
      errors: ['An error occurred while saving your submission. Please try again.'],
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you.ejs');
});

// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).send('Internal Server Error');
});

export default app;
export { app };

export async function startServer(): Promise<void> {
  await dbManager.initialize();

  return new Promise<void>((resolve, reject) => {
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      resolve();
    });

    server.on('error', (error: Error) => {
      console.error('Server error:', error);
      reject(error);
    });

    setupGracefulShutdown(server);
  });
}

function setupGracefulShutdown(server: ReturnType<typeof app.listen>): void {
  const shutdown = (signal: string): void => {
    console.log(`\n${signal} received, shutting down gracefully...`);
    server.close(() => {
      console.log('HTTP server closed');
      dbManager.close();
      console.log('Database closed');
      process.exit(0);
    });

    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      dbManager.close();
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
