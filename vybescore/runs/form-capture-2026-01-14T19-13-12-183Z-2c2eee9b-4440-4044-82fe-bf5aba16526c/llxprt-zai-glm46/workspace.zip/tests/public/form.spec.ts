import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';

let server: http.Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Dynamically import the compiled server
  const module = await import('../../dist/server.js');
  const express = module.default || module.app;

  server = http.createServer(express);
  await new Promise<void>((resolve) => {
    server.listen(0, () => {
      resolve();
    });
  });
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
