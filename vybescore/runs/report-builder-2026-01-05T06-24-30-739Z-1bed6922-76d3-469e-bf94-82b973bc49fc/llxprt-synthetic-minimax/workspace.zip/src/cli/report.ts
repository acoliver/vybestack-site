import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions } from '../types/report.js';
import { formatReport } from '../formats/index.js';

interface ParsedArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[++i] as 'markdown' | 'text';
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, output, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid JSON: entry ${i + 1} missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid JSON: entry ${i + 1} missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.startsWith('Invalid JSON')) {
      throw error;
    }
    throw new Error(`Error reading file ${filePath}: ${error}`);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const parsedArgs = parseArgs(args);
    const reportData = loadReportData(parsedArgs.dataFile);
    
    const options: ReportOptions = {
      format: parsedArgs.format,
      output: parsedArgs.output,
      includeTotals: parsedArgs.includeTotals
    };
    
    const output = formatReport(parsedArgs.format, reportData, options);
    
    if (parsedArgs.output) {
      writeFileSync(parsedArgs.output, output, 'utf8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
