import { ReportData, ReportOptions } from '../types/report.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export interface Formatter {
  format: (data: ReportData, options: ReportOptions) => string;
}

export const formatters: Record<'markdown' | 'text', Formatter> = {
  markdown: { format: renderMarkdown },
  text: { format: renderText }
};

export function formatReport(
  formatName: 'markdown' | 'text',
  data: ReportData,
  options: ReportOptions
): string {
  const formatter = formatters[formatName];
  if (!formatter) {
    throw new Error(`Unsupported format: ${formatName}`);
  }
  return formatter.format(data, options);
}