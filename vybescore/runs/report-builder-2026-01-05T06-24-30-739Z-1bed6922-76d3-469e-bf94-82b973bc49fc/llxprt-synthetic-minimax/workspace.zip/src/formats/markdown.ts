import { ReportData, ReportOptions } from '../types/report.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;
  
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };
  
  let output = `# ${title}\n\n`;
  output += `${summary}\n\n`;
  output += `## Entries\n\n`;
  
  for (const entry of entries) {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** ${formatAmount(total)}\n`;
  }
  
  return output;
}