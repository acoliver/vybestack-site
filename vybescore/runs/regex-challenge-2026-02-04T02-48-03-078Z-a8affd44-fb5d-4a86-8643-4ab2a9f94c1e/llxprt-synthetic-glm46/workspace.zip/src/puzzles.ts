/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with prefix
  const wordBoundary = '\b';
  const prefixPattern = prefix.replace(/[.*+?^${}()|[\]\]/g, '\$&');
  const wordPattern = new RegExp(`${wordBoundary}${prefixPattern}[a-zA-Z]+`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0];
    
    // Skip if in exceptions
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex to find token after a digit (but not at start)
  const tokenPattern = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const embeddedPattern = new RegExp(`(?<!^)(?<=\\d)(${tokenPattern})(?=\\s|$)`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = embeddedPattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab")
  for (let i = 0; i < value.length - 3; i++) {
    const chunk1 = value.substring(i, i + 2);
    const chunk2 = value.substring(i + 2, i + 4);
    
    if (chunk1 === chunk2) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern with support for shorthand (e.g., ::1)
  // First, exclude IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns
  const ipv6FullPattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  const ipv6CompressedPattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/;
  const ipv6LeadingCompressedPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/;
  const ipv6TrailingCompressedPattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/;
  const ipv6MiddleCompressedPattern = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:[0-9a-fA-F]{1,4}:){0,1}[0-9a-fA-F]{1,4}\b/;
  
  // Check for IPv4 first - if found, don't count as IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for various IPv6 patterns
  return ipv6FullPattern.test(value) ||
         ipv6CompressedPattern.test(value) ||
         ipv6LeadingCompressedPattern.test(value) ||
         ipv6TrailingCompressedPattern.test(value) ||
         ipv6MiddleCompressedPattern.test(value);
}
