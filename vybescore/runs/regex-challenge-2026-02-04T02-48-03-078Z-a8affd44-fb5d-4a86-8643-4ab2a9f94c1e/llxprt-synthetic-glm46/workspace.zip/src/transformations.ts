/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Empty or single character case
  if (!text || text.length === 1) {
    return text;
  }
  
  // Split into sentences using sentence delimiters
  const sentences = text.split(/([.?!])/);
  
  // Process each sentence
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    
    if (sentence.trim()) {
      // Capitalize first character
      const firstChar = sentence[0].toUpperCase();
      const restOfSentence = sentence.substring(1);
      sentences[i] = firstChar + restOfSentence;
    }
  }
  
  // Join back together with proper spacing
  let result = '';
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (i > 0 && ['.', '?', '!'].includes(part) && i < sentences.length - 1) {
      // Add space after sentence delimiters (unless it's the last part)
      result += part + ' ';
    } else {
      result += part;
    }
  }
  
  // Collapse multiple spaces into single spaces (except after sentence delimiters)
  result = result.replace(/([^.\?\!])\s+/g, '$1 ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern capturing protocol, domain, and path
  const urlRegex = /(https?:\/\/[^\s<>"'`]+|[^\s<>"'`]+\.[a-zA-Z]{2,}(?:\/[^\s<>"'`]*)?)/gi;
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?)]+$/);
    
    if (url && !matches.includes(url)) {
      matches.push(url);
    }
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but avoid matching already https URLs
  return text.replace(/(^|\s)(http:\/\/)/g, '$1https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to find URLs and capture components
  const urlPattern = /(https?):\/\/(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Force HTTPS
    protocol = 'https';
    
    // Check if we should rewrite the host to docs.example.com
    // Skip host rewrite if path contains dynamic hints or legacy extensions
    const skipHostRewrite = /\/(cgi-bin)|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    // If path starts with /docs/ and we shouldn't skip, rewrite host
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      host = 'docs.example.com';
    }
    
    return `${protocol}://${host}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Validate day based on month (simplified validation)
  const maxDay = parseInt(month) === 2 ? 29 : // February (simplified, ignoring leap years)
                 ([4, 6, 9, 11].includes(parseInt(month)) ? 30 : 31);
  
  if (parseInt(day) > maxDay) {
    return 'N/A';
  }
  
  return year;
}
