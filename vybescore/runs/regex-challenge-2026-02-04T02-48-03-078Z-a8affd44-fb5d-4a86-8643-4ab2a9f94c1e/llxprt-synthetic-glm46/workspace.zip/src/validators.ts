export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // No double dots in local part
  if (value.includes('..')) {
    return false;
  }
  
  // No dots at the start or end of local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot start or end with dash or have underscores
  const domain = value.split('@')[1];
  if (!domain || domain.includes('_') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // No consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove common separators
  const cleanValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Check for optional +1 country code
  const hasCountryCode = cleanValue.startsWith('+1');
  const phoneNumber = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  
  // Must be 10 digits after removing country code
  if (phoneNumber.length !== 10 || !/^\d+$/.test(phoneNumber)) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators
  const cleanValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code, optional 0 trunk prefix, optional 9 for mobile
  // Area code 2-4 digits starting with 1-9, subscriber 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  const match = cleanValue.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, mobileIndicator, areaCode, subscriber] = match;
  
  // If country code is omitted, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must start with 1-9 (not 0)
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Total digits after area code should be 6-8
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and "X Æ A-12" style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check basic format
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject digits and common symbols that might be in weird names
  if (/[0-9@#$%^&*()_+=\[\]{}|\:";<>,.?\/]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: 13 or 16 digits starting with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-5]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720)\d{12}$/;
  
  // American Express: 15 digits starting with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check format
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
