/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${prefix}\\w+`, 'g');
  
  // Find all matching words
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => {
    return !exceptions.some(exception => {
      return word.toLowerCase() === exception.toLowerCase();
    });
  });
  
  // Return unique results
  return [...new Set(filteredMatches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // We need to return the digit+token combination
  const tokenPattern = new RegExp(`\\d${token}`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for each required character type
  if (!/[A-Z]/.test(value)) {
    return false; // No uppercase
  }
  
  if (!/[a-z]/.test(value)) {
    return false; // No lowercase
  }
  
  if (!/\d/.test(value)) {
    return false; // No digit
  }
  
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
    return false; // No symbol
  }
  
  // Check for repeated sequences (like abab)
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check for valid IPv4 addresses to exclude them
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns
  // Full IPv6 with 8 groups of 4 hex digits
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand patterns with ::
  const shorthandIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/;
  
  // Special cases for :: at start or end
  const startEndShorthandPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}::\b/;
  
  // Just :: alone
  const justDoubleColon = /\b::\b/;
  
  // If it matches an IPv4 pattern, it's not IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for any IPv6 pattern
  return fullIPv6Pattern.test(value) || 
         shorthandIPv6Pattern.test(value) || 
         startEndShorthandPattern.test(value) || 
         justDoubleColon.test(value);
}
