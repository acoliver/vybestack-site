/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: ensure single spaces between sentences
  // Also ensure there's a space after sentence-ending punctuation if needed
  let processed = text
    .replace(/\s+/g, ' ')                        // Collapse multiple spaces
    .trim();
  
  // Capitalize first character of each sentence
  // First, capitalize the very first character
  processed = processed.replace(/^([a-z])/, (match, letter) => {
    return letter.toUpperCase();
  });
  
  // Then capitalize characters after sentence-ending punctuation followed by space
  processed = processed.replace(/([.!?]\s)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return processed;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with HTTP/HTTPS/FTP schemes
  const urlRegex = /(?:https?:\/\/|ftp:\/\/)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?(?=[\s.,;:!?]|$)/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[\s.,;:!?]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https:// (using negative lookahead)
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /http:\/\/([^\/]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    // Always upgrade scheme to https
    const secureScheme = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = path.match(/\/(cgi-bin|\?|&|=|.*\.jsp|.*\.php|.*\.asp|.*\.aspx|.*\.do|.*\.cgi|.*\.pl|.*\.py)/);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com for docs paths without dynamic hints
      return secureScheme + 'docs.' + host + path;
    } else {
      // Just upgrade to https for all other cases
      return secureScheme + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract month and day
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate days per month (simplified - not accounting for leap years)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  
  // Special case for February in leap years
  if (month === 2 && parseInt(year, 10) % 4 === 0) {
    if ((parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0)) {
      // February has 29 days in a leap year
      if (day > 29) {
        return 'N/A';
      }
    }
  } else if (day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
