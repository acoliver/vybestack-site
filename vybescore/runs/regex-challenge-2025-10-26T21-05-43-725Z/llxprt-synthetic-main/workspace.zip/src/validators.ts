export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  // Local part: letters, digits, +, ., -, _
  // Cannot have consecutive dots or leading/trailing dots
  // Domain: no underscores, valid domain structure
  
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9._+-]*[a-zA-Z0-9]+)?@[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?(\.[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?)*\.[a-zA-Z]{2,}$/;
  
  // Check for invalid patterns: double dots, trailing/leading dots, underscore in domain
  const invalidPatterns = [
    /\.\./,           // Double dots
    /^\./,            // Leading dot
    /\.$/,            // Trailing dot
    /_.*@|@.*_/,      // Underscore in domain
  ];
  
  // If basic regex doesn't match, return false
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  return !invalidPatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Normalize the input by removing non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for number, optional +1 for country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Extract area code and validate it
  let areaCode: string;
  
  if (digitsOnly.length === 11) {
    // Check if it starts with 1 (US country code)
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
    areaCode = digitsOnly.substring(1, 4);
  } else {
    areaCode = digitsOnly.substring(0, 3);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the phone format with separators
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))(?:[\s-]?)(\d{3})(?:[\s-]?)(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters to work with pure numbers
  const digitsOnly = value.replace(/\D/g, '');
  
  // Case 1: With country code +54
  if (digitsOnly.startsWith('54')) {
    // Format: +54 [9] [2-4 digit area code] [6-8 digit subscriber number]
    const afterCountryCode = digitsOnly.substring(2);
    
    // Check for mobile prefix (9) which is optional
    let remaining = afterCountryCode;
    if (remaining.startsWith('9')) {
      remaining = remaining.substring(1);
    }
    
    // Extract area code (2-4 digits)
    if (remaining.length < 8 || remaining.length > 12) {
      return false;
    }
    
    let areaCodeLength;
    for (let i = 2; i <= 4; i++) {
      if (remaining.length - i >= 6 && remaining.length - i <= 8) {
        areaCodeLength = i;
        break;
      }
    }
    
    if (!areaCodeLength) {
      return false;
    }
    
    const areaCode = remaining.substring(0, areaCodeLength as number);
    const subscriberNumber = remaining.substring(areaCodeLength as number);
    
    // Area code must start with non-zero digit
    if (areaCode.startsWith('0')) {
      return false;
    }
    
    // Subscriber number must be 6-8 digits
    return subscriberNumber.length >= 6 && subscriberNumber.length <= 8;
  }
  
  // Case 2: Without country code (must start with 0 trunk prefix)
  if (digitsOnly.startsWith('0')) {
    // Format: 0 [2-4 digit area code] [6-8 digit subscriber number]
    const afterTrunkPrefix = digitsOnly.substring(1);
    
    // Must have at least 8 digits total
    if (afterTrunkPrefix.length < 8 || afterTrunkPrefix.length > 12) {
      return false;
    }
    
    // Check for mobile prefix (9) after trunk prefix which is optional
    let remaining = afterTrunkPrefix;
    if (remaining.startsWith('9')) {
      remaining = remaining.substring(1);
    }
    
    // Extract area code (2-4 digits)
    let areaCodeLength;
    for (let i = 2; i <= 4; i++) {
      if (remaining.length - i >= 6 && remaining.length - i <= 8) {
        areaCodeLength = i;
        break;
      }
    }
    
    if (!areaCodeLength) {
      return false;
    }
    
    const areaCode = remaining.substring(0, areaCodeLength as number);
    const subscriberNumber = remaining.substring(areaCodeLength as number);
    
    // Area code must start with non-zero digit
    if (areaCode.startsWith('0')) {
      return false;
    }
    
    // Subscriber number must be 6-8 digits
    return subscriberNumber.length >= 6 && subscriberNumber.length <= 8;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  
  // Regex for valid name characters
  const nameRegex = /^[\p{L}\p{M}'.\-\s]+$/u;
  
  // Check for digits or special symbols
  const invalidPatterns = [
    /\d/,            // Digits
    /[^\p{L}\p{M}'.\-\s]/u  // Symbols other than ', -, and spaces
  ];
  
  // Must match valid pattern and not contain invalid patterns
  return nameRegex.test(value) && !invalidPatterns.some(pattern => pattern.test(value));
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  // Starting from rightmost digit, double every second digit
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if it's empty
  if (!cardNumber) {
    return false;
  }
  
  // Define card patterns for Visa, Mastercard, and AmEx
  const cardPatterns = [
    {
      name: 'Visa',
      regex: /^4[0-9]{12}(?:[0-9]{3})?$/,
      lengths: [13, 16]
    },
    {
      name: 'Mastercard',
      regex: /^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$/,
      lengths: [16]
    },
    {
      name: 'AmEx',
      regex: /^3[47][0-9]{13}$/,
      lengths: [15]
    }
  ];
  
  // Find matching card type
  const matchingCard = cardPatterns.find(card => 
    card.regex.test(cardNumber) && card.lengths.includes(cardNumber.length)
  );
  
  // If no matching card type, it's invalid
  if (!matchingCard) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cardNumber);
}
