import { isValidEmail, isValidName, isValidUSPhone, isValidArgentinePhone } from './dist/src/validators.js';

console.log('=== EMAIL TESTS ===');
console.log('test@domain_.com:', isValidEmail('test@domain_.com'));
console.log('.user@domain.com:', isValidEmail('.user@domain.com'));
console.log('user.@domain.com:', isValidEmail('user.@domain.com'));
console.log('user..name@domain.com:', isValidEmail('user..name@domain.com'));

console.log('\n=== NAME TESTS ===');
console.log('X Æ A-12:', isValidName('X Æ A-12'));
console.log('John123:', isValidName('John123'));
console.log('Mary @ Smith:', isValidName('Mary @ Smith'));
console.log('123:', isValidName('123'));

console.log('\n=== US PHONE TESTS ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('012-555-7890:', isValidUSPhone('012-555-7890'));
console.log('+1 (212) 555-7890:', isValidUSPhone('+1 (212) 555-7890'));

console.log('\n=== ARGENTINE PHONE TESTS ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('341 1234567:', isValidArgentinePhone('341 1234567'));
