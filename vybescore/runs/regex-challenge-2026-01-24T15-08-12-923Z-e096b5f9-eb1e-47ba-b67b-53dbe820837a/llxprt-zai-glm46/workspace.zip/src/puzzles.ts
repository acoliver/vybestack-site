/**
 * Find words starting with the prefix, excluding banned words.
 * Uses word boundaries to match complete words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }

  if (!Array.isArray(exceptions)) {
    exceptions = [];
  }

  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with prefix
  // Word boundary ensures we match complete words
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const filtered = matches.filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  );

  return [...new Set(filtered)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning.
 * Uses lookbehind to check for preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: token preceded by a digit (using lookbehind), not at start of string
  // Positive lookbehind (?<=\d) ensures there's a digit before the token
  // We want to match the digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to security policy.
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  if (value.length < 10) {
    return false;
  }

  if (/\s/.test(value)) {
    return false;
  }

  if (!/[A-Z]/.test(value)) {
    return false;
  }

  if (!/[a-z]/.test(value)) {
    return false;
  }

  if (!/\d/.test(value)) {
    return false;
  }

  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?~`]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, 1212, xyzxyz)
  // Look for patterns of length 2-4 that repeat
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i < value.length - 2 * len; i++) {
      const pattern = value.substring(i, i + len);
      const nextPattern = value.substring(i + len, i + 2 * len);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Excludes IPv4 addresses to avoid false positives.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 pattern (full and shorthand with ::)
  // Supports:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8::1
  // - Loopback: ::1
  // - All zones: fe80::1%eth0
  // Does NOT match IPv4 (which is purely dotted decimal like 192.168.1.1)
  
  // IPv6 pattern explanation:
  // - Starts with (?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4} - full form (8 groups)
  // - OR ::[0-9a-fA-F]{1,4} - shorthand at start
  // - OR [0-9a-fA-F]{1,4}:: - shorthand at end
  // - OR (?:[0-9a-fA-F]{1,4}:){1,7}: - shorthand in middle
  // - OR :: - all zeros shorthand
  const ipv6Pattern = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::|(?:[0-9a-fA-F]{1,4}:){1,7}:|::)/;

  // First check for pure IPv4 (dotted decimal) and exclude those
  // IPv4: 4 groups of 1-3 digits separated by dots
  const pureIPv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (pureIPv4Pattern.test(value.trim())) {
    return false;
  }

  // Check for IPv6
  return ipv6Pattern.test(value);
}
