/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after ., !, ?
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // First, normalize spaces: collapse multiple spaces into one
  let result = text.replace(/\s{2,}/g, ' ');

  // Ensure exactly one space after sentence endings if missing or too many
  result = result.replace(/([.!?])\s*/g, '$1 ');

  // Trim leading/trailing whitespace
  result = result.trim();

  // Capitalize first letter of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Capitalize letters after sentence endings, but avoid common abbreviations
  // We'll look for .!? followed by space and lowercase letter
  // Common abbreviations to avoid: Mr., Mrs., Ms., Dr., Prof., etc., Sr., Jr.
  const abbreviationPattern = /\b(?:Mr|Mrs|Ms|Dr|Prof|Rev|Gen|Rep|Sen|St|Sr|Jr)\.$/i;
  
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    // Check if the preceding word is an abbreviation
    const beforeSentence = result.substring(0, result.indexOf(match) + prefix.length);
    const words = beforeSentence.split(/\s+/);
    const lastWord = words[words.length - 2] || '';
    
    if (abbreviationPattern.test(lastWord)) {
      return prefix + letter; // Don't capitalize after abbreviation
    }
    return prefix + letter.toUpperCase();
  });

  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // URL pattern:
  // - Starts with http://, https://, www., or domain with TLD
  // - Matches domain, optional path, query, fragment
  // - Excludes trailing punctuation
  const urlPattern = /(?:https?:\/\/|www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9][a-zA-Z0-9-]*)+(?:\/[^\s.,!?;:()"']*)?/g;

  const matches = text.match(urlPattern) || [];

  // Clean up matches: remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    return url.replace(/[.,!?;:()"']+$/, '');
  });

  // Ensure www. URLs have http:// prefix for consistency
  const normalizedUrls = cleanedUrls.map(url => {
    if (url.startsWith('www.')) {
      return 'http://' + url;
    }
    return url;
  });

  // Filter out strings that are just domains without valid TLDs
  return normalizedUrls.filter(url => {
    const hasValidTld = /\.(?:com|org|net|edu|gov|mil|io|co|uk|us|ca|au|de|fr|es|it|nl|se|no|jp|kr|cn|in|br|ru|mx|za|be|ch|at|dk|pl|fi|gr|hu|ie|il|pt|ro|sk|si|ua|ar|cl|co\.uk|ac\.uk|gov\.uk)/i.test(url);
    return hasValidTld || url.startsWith('http://') || url.startsWith('https://');
  });
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints: cgi-bin, query strings, legacy extensions
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Pattern to match http://example.com/... URLs
  // Capture the full URL and its components
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should skip host rewrite
    // Dynamic hints: cgi-bin, query strings (?), legacy extensions
    const skipRewrite = /\/cgi-bin\/|[?&=]|\/(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i.test(path);
    
    if (path.startsWith('/docs/') && !skipRewrite) {
      // Rewrite host to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
