export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts standard formats like user@example.com, name@tag.example.co.uk
 * Rejects: double dots, trailing dots, underscores in domain, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic structure: local@domain.tld
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  // Check for forbidden patterns
  const hasDoubleDot = /\.\./.test(value);
  const hasTrailingDotAt = /@\.$/.test(value) || /\.\.$/.test(value);
  const hasTrailingDotLocal = /^[^@]*\.$/.test(value);
  const hasUnderscoreInDomain = /@[a-zA-Z0-9._-]*_[a-zA-Z0-9._-]*\./.test(value);
  const hasInvalidStart = /^[._%+-]/.test(value);
  const hasInvalidEnd = /[._%+-](?=@)/.test(value);

  if (!emailRegex.test(value)) {
    return false;
  }

  if (hasDoubleDot || hasTrailingDotAt || hasTrailingDotLocal || hasUnderscoreInDomain || hasInvalidStart || hasInvalidEnd) {
    return false;
  }

  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }

  const [local, domain] = parts;

  // Local part checks
  if (local.length === 0 || local.length > 64) {
    return false;
  }
  if (local.startsWith('.') || local.endsWith('.') || local.startsWith('-') || local.endsWith('-')) {
    return false;
  }

  // Domain part checks
  if (domain.length === 0 || domain.length > 255) {
    return false;
  }
  if (domain.startsWith('.') || domain.startsWith('-') || domain.endsWith('.') || domain.endsWith('-')) {
    return false;
  }
  if (domain.includes('_')) {
    return false;
  }

  // Check TLD
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2 || !/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
 * Rejects: area codes starting with 0 or 1, too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all whitespace and extensions
  let cleaned = value.trim();
  
  // Handle extension if allowed
  if (options?.allowExtensions) {
    cleaned = cleaned.split(/\s+(?:ext|ex|x)\s*/i)[0];
  }

  // Remove common separators
  cleaned = cleaned.replace(/[\s\-.()]/g, '');

  // Remove optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }

  // Check length: should be exactly 10 digits
  if (cleaned.length !== 10) {
    return false;
  }

  // Must be all digits
  if (!/^\d{10}$/.test(cleaned)) {
    return false;
  }

  const areaCode = cleaned.substring(0, 3);
  const exchange = cleaned.substring(3, 6);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code cannot start with 0 or 1
  if (exchange[0] === '0' || exchange[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When no country code, must start with 0 before area code
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove separators (spaces and hyphens) but keep the structure
  const normalized = value.trim().replace(/[-\s]/g, '');

  // Pattern breakdown:
  // ^(?:\+54)? - Optional country code +54
  // (?:0)? - Optional trunk prefix 0
  // (?:9)? - Optional mobile indicator 9
  // (\d{2,4}) - Area code (2-4 digits, will validate leading digit separately)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?(\d{2,4})(\d{6,8})$/;

  const match = normalized.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, areaCode, subscriber] = match;

  // Area code must be 2-4 digits and must start with 1-9 (not 0)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }

  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }

  // If no country code, must have trunk prefix 0 before area code
  const hasCountryCode = normalized.startsWith('+54');
  const hasTrunkPrefix = value.trim().startsWith('0') || /^0\d/.test(normalized);
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  // Total validation: ensure the normalized format makes sense
  // When country code is present: +54 [9] XXX XXXXXXX
  // When country code is absent: 0XXX XXXXXXX
  const totalLength = normalized.length;
  if (hasCountryCode) {
    // +54 + area + subscriber = 3 + area(2-4) + subscriber(6-8) = 11-15
    if (totalLength < 11 || totalLength > 15) {
      return false;
    }
  } else {
    // 0 + area + subscriber = 1 + area(2-4) + subscriber(6-8) = 9-13
    if (totalLength < 9 || totalLength > 13) {
      return false;
    }
  }

  return true;
}

/**
 * Validate personal names.
 * Allows: Unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: Digits, symbols, and "X Æ A-12" style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();

  if (trimmed.length === 0) {
    return false;
  }

  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u017F\u0400-\u04FF]/.test(trimmed)) {
    return false;
  }

  // Allow: unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject: digits and other symbols
  // Single letter names should be allowed
  const nameRegex = /^[\u00C0-\u017F\u0400-\u04FFa-zA-Z]([\u00C0-\u017F\u0400-\u04FFa-zA-Z\s'-]*[\u00C0-\u017F\u0400-\u04FFa-zA-Z])?$/u;

  if (!nameRegex.test(trimmed)) {
    return false;
  }

  // Check for invalid characters (digits, symbols other than allowed)
  const hasInvalidChars = /[0-9@#$%^&*()_+=[\]{};:"<>?/|`~]/.test(trimmed);
  if (hasInvalidChars) {
    return false;
  }

  // Check for "X Æ A-12" style names (has digits)
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Check for consecutive spaces or leading/trailing spaces (already trimmed, but check internal)
  if (/\s{2,}/.test(trimmed)) {
    return false;
  }

  // Check for consecutive apostrophes or hyphens (but single apostrophe in middle is ok)
  if (/--/.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa (starts with 4, 13-16 digits), Mastercard (starts with 51-55 or 2221-2720, 16 digits), 
 *          AmEx (starts with 34 or 37, 15 digits)
 * Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be numeric
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12,15}$/;

  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-9]{14})$/;

  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validFormat) {
    return false;
  }

  // Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn algorithm checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
