import { 
  isValidEmail, 
  isValidUSPhone, 
  isValidArgentinePhone, 
  isValidName, 
  isValidCreditCard 
} from './dist/src/validators.js';

import { 
  capitalizeSentences, 
  extractUrls, 
  enforceHttps, 
  rewriteDocsUrls, 
  extractYear 
} from './dist/src/transformations.js';

import { 
  findPrefixedWords, 
  findEmbeddedToken, 
  isStrongPassword, 
  containsIPv6 
} from './dist/src/puzzles.js';

console.log('========== VALIDATORS ==========');

// Email tests
console.log('\n--- Email ---');
const emails = [
  ['user@example.com', true],
  ['name@tag.example.co.uk', true],
  ['user@@example..com', false],
  ['user@domain_.com', false],
  ['.user@domain.com', false],
  ['user.@domain.com', false],
  ['user..name@domain.com', false],
];
emails.forEach(([e, expected]) => {
  const result = isValidEmail(e);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${e}: ${result} (expected ${expected})`);
});

// US Phone tests
console.log('\n--- US Phone ---');
const usPhones = [
  ['(212) 555-7890', true],
  ['212-555-7890', true],
  ['2125557890', true],
  ['+1 (212) 555-7890', true],
  ['012-555-7890', false],
  ['212-155-7890', false],
  ['555-7890', false],
];
usPhones.forEach(([p, expected]) => {
  const result = isValidUSPhone(p);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${p}: ${result} (expected ${expected})`);
});

// Argentine Phone tests
console.log('\n--- Argentine Phone ---');
const arPhones = [
  ['+54 9 11 1234 5678', true],
  ['011 1234 5678', true],
  ['+54 341 123 4567', true],
  ['0341 4234567', true],
  ['341 1234567', false],
];
arPhones.forEach(([p, expected]) => {
  const result = isValidArgentinePhone(p);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${p}: ${result} (expected ${expected})`);
});

// Name tests
console.log('\n--- Name ---');
const names = [
  ['Jane Doe', true],
  ['José María González', true],
  ["O'Connor", true],
  ['Smith-Jones', true],
  ['X Æ A-12', false],
  ['John123', false],
  ['Mary @ Smith', false],
  ['123', false],
];
names.forEach(([n, expected]) => {
  const result = isValidName(n);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${n}: ${result} (expected ${expected})`);
});

// Credit Card tests
console.log('\n--- Credit Card ---');
const cards = [
  ['4111111111111111', true],
  ['5500000000000004', true],
  ['340000000000009', true],
  ['4111111111111112', false],
];
cards.forEach(([c, expected]) => {
  const result = isValidCreditCard(c);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${c}: ${result} (expected ${expected})`);
});

console.log('\n========== TRANSFORMATIONS ==========');

// Capitalize Sentences
console.log('\n--- Capitalize Sentences ---');
console.log(capitalizeSentences('hello world. how are you? i am fine.'));
console.log(capitalizeSentences('mr. smith went to washington. he met dr. jones.'));

// Extract URLs
console.log('\n--- Extract URLs ---');
const urls = extractUrls('Visit https://example.com and www.test.com for info.');
console.log(urls);

// Enforce HTTPS
console.log('\n--- Enforce HTTPS ---');
console.log(enforceHttps('Visit http://example.com and https://secure.com'));

// Rewrite Docs URLs
console.log('\n--- Rewrite Docs URLs ---');
console.log(rewriteDocsUrls('See http://example.com/docs/guide and http://example.com/api'));

// Extract Year
console.log('\n--- Extract Year ---');
console.log('12/25/2024 ->', extractYear('12/25/2024'));
console.log('13/01/2024 ->', extractYear('13/01/2024'));
console.log('invalid ->', extractYear('invalid'));

console.log('\n========== PUZZLES ==========');

// Find Prefixed Words
console.log('\n--- Find Prefixed Words ---');
const words = findPrefixedWords('unrelated unknown undo undone', 'un', ['undo']);
console.log(words);

// Find Embedded Token
console.log('\n--- Find Embedded Token ---');
const embedded = findEmbeddedToken('abc123def 123ghi', '123');
console.log(embedded);

// Strong Password
console.log('\n--- Strong Password ---');
const passwords = [
  ['Weak1!', false],
  ['StrongPass123!', true],
  ['ababABAB12!', false],
];
passwords.forEach(([p, expected]) => {
  const result = isStrongPassword(p);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${p}: ${result} (expected ${expected})`);
});

// IPv6 Detection
console.log('\n--- IPv6 Detection ---');
const ipTests = [
  ['2001:0db8:85a3:0000:0000:8a2e:0370:7334', true],
  ['2001:db8::1', true],
  ['::1', true],
  ['192.168.1.1', false],
];
ipTests.forEach(([ip, expected]) => {
  const result = containsIPv6(ip);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${ip}: ${result} (expected ${expected})`);
});

console.log('\n========== END OF TESTS ==========');
