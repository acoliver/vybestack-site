/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Register observer to track dependencies and get initial value
  if (!disposed) {
    updateObserver(observer as Observer<unknown>)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark as disposed by setting a no-op update function
    observer.updateFn = () => (observer.value !== undefined ? observer.value : value) as T
    observer.value = undefined
  }
}
