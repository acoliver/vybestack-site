/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string } // _ prefix for unused parameter
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => Object.is(lhs, rhs)
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  let currentValue = value

  const getter: GetterFn<T> = () => {
    // Always call updateFn to handle default parameters correctly
    // The function should be pure and always return the same result for the same dependencies
    const newValue = updateFn()
    
    // Only update if the value changed
    if (!equalFn || !equalFn(currentValue as T, newValue)) {
      currentValue = newValue
    }
    
    return currentValue!
  }

  // Initial computation
  getter()

  return getter
}
