/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Subject<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<object>
}

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  name?: string
  value?: T
  equalFn?: EqualFn<T>
  observers?: Set<object>
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  equalFn?: EqualFn<T>
  subject?: object
  dependencies?: Set<object>
}

export type Observer<T> = ObserverR & ObserverV<T>

let activeObserver: object | undefined

export function getActiveObserver(): object | undefined {
  return activeObserver
}

export function updateObserver(observer: Observer<unknown>): void {
  const previous = activeObserver
  activeObserver = observer
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function registerDependency(observer: Observer<unknown>, subject: Subject<unknown>): void {
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject)
  
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function notifySubjects(subject: Subject<unknown>, newValue: unknown): void {
  const oldValue = subject.value
  subject.value = newValue
  
  // Only notify observers if the value actually changed
  if (!subject.equalFn || subject.equalFn(oldValue, newValue) === false) {
    if (subject.observers) {
      const observers = Array.from(subject.observers)
      for (const observer of observers) {
        updateObserver(observer as Observer<unknown>)
      }
    }
  }
}
