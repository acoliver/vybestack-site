/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Active observer that tracks which reactive values are being accessed
let activeObserver: ObserverR | undefined

// Get the currently active observer
export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Set the currently active observer
export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export type ObserverR = {
  name?: string
  // Store reference to the full observer for notifications
  fullObserver?: Observer<unknown>
  // Track all dependent observers that need to be notified when this changes
  dependentObservers?: ObserverR[]
  // Store the source that this observer tracks
  observer?: ObserverR
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Update an observer by calling its function
export function updateObserver<T>(observer: Observer<T>): void {
  observer.value = observer.updateFn(observer.value)
}

// Helper to notify an observer that their dependencies have changed
export function notifyObserver(observer: Observer<unknown>): void {
  updateObserver(observer)
}