/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR,
  UpdateFn
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equal parameter - if it's a boolean and true, use strict equality
  // If it's a function, use it directly, otherwise no equality checking
  const equalFn = 
    _equal === true ? ((a: T, b: T) => a === b) :
    _equal === false || _equal === undefined ? undefined :
    typeof _equal === 'function' ? (_equal as EqualFn<T>) :
    undefined

  const s: Subject<T> = {
    name: options?.name || 'input',
    observer: undefined,
    value,
    equalFn,
  }

  // Observers that depend on this input
  const observers = new Set<Observer<unknown>>()

  const read: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs && activeObs.fullObserver) {
      // Register dependency: this input is a dependency of the active observer
      observers.add(activeObs.fullObserver as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // If equalFn is provided, use it to determine if we should skip update
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers that this input has changed
    const observersArray = Array.from(observers)
    observersArray.forEach(observer => {
      try {
        // Re-execute the observer's update function
        updateObserver(observer as Observer<unknown>)
      } catch (e) {
        // Silently ignore errors
      }
    })
    
    // Direct notification for the old system (for compatibility)
    if (s.observer && typeof (s.observer as {updateFn?: UpdateFn<T>}).updateFn === 'function') {
      try {
        updateObserver(s.observer as Observer<unknown>)
      } catch (e) {
        // Ignore errors for observers without update functions
      }
    }
    
    return s.value
  }

  return [read, write]
}