/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Create a wrapper to reference this observer
  const observerRecord = { 
    name: `callback-${Date.now()}`,
    fullObserver: observer,
    updateFn: observer.updateFn
  }
  
  // Create wrapper that tracks dependencies when the update function is called
  const updateFnWithTracking = (currentValue?: T) => {
    // Track dependencies by setting this as the active observer
    setActiveObserver(observerRecord)
    try {
      return updateFn(currentValue)
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Replace the original update function with our tracking version
  observer.updateFn = updateFnWithTracking
  
  // Run once to establish initial dependencies
  try {
    updateObserver(observer)
  } catch (e) {
    // Ignore errors during initial setup
  }
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value! as T
  }
  
  return unsubscribe
}