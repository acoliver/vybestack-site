/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  setActiveObserver,
  ObserverR,
  ObserverV,
  notifyObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process equal parameter - if it's a boolean and true, use strict equality  
  // If it's a function, use it directly, otherwise no equality checking
  // Note: equalFn is stored for potential future use with value equality checking
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const equalFn = 
    _equal === true ? ((a: T, b: T) => a === b) :
    _equal === false || _equal === undefined ? undefined :
    typeof _equal === 'function' ? (_equal as EqualFn<T>) :
    undefined

  // Create the full observer that will execute the update function
  const observer: ObserverV<T> = {
    value,
    updateFn,
  }

  // Create a wrapper object for tracking dependencies
  const observerRecord: ObserverR & ObserverV<T> = { 
    name: options?.name || `computed-${Date.now()}`,
    // Attach the full observer for notification
    fullObserver: observer,
    dependentObservers: [],
    value: observer.value,
    updateFn: observer.updateFn
  }

  // Observers that depend on this computed value
  const dependentObservers = new Set<Observer<unknown>>()

  // Create a wrapper function for the getter
  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs && activeObs.fullObserver) {
      // Register dependency: this computed value is a dependency of the active observer
      dependentObservers.add(activeObs.fullObserver as Observer<unknown>)
    }
    
    // Recalculate value: set as active observer to track our dependencies
    const prevActiveObserver = getActiveObserver()
    setActiveObserver(observerRecord)
    try {
      // Execute original update function to compute the value
      observer.value = observer.updateFn(observer.value)
      return observer.value!
    } finally {
      // Restore the previous active observer
      setActiveObserver(prevActiveObserver)
    }
  }

  // Replace update function to handle notifications
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (currentValue?: T) => {
    // Recalculate value by calling the original function
    const prevActiveObserver = getActiveObserver()
    setActiveObserver(observerRecord)
    try {
      return originalUpdateFn(currentValue)
    } finally {
      // Restore the previous active observer
      setActiveObserver(prevActiveObserver)
      
      // Notify all dependent observers that this computed value has changed
      const observersArray = Array.from(dependentObservers)
      observersArray.forEach(obs => {
        try {
          updateObserver(obs as Observer<unknown>)
        } catch (e) {
          // Silently ignore errors
        }
      })
    }
  }

  return getter
}