/**
 * Encode plain text to Base64 using standard Base64 encoding with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts Base64 with or without padding and validates the input.
 */
export function decode(input: string): string {
  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Ensure proper padding (Base64 strings should have length divisible by 4)
  const normalized = input;
  const missingPadding = (4 - (normalized.length % 4)) % 4;
  const paddedInput = normalized + '='.repeat(missingPadding);

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
