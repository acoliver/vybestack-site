/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equal function parameter
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? (a: T, b: T) => a === b : 
    undefined;

  // Create subject with initial value and equal function
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Read function tracks which observer is accessing this subject
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  // Write function updates the value and notifies observers
  const write: SetterFn<T> = (nextValue) => {
    // If equalFn is defined, check if the value has actually changed
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    // Update value
    s.value = nextValue
    
    // If there's an observer, update it
    if (s.observer) updateObserver(s.observer as Observer<unknown>)
    
    return s.value
  }

  return [read, write]
}