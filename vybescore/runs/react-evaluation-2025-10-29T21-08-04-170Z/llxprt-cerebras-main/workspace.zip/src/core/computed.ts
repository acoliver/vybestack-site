/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process equal function parameter
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? (a: T, b: T) => a === b : 
    undefined;
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    equalFn,
    updateFn,
    dependencies: new Set(),
  }
  
  // Register observer to track dependencies
  updateObserver(o)
  
  // Getter function that returns the current value
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add this computed as a dependency of the active observer
      if (!activeObserver.dependencies) {
        activeObserver.dependencies = new Set()
      }
      activeObserver.dependencies.add(o)
    }
    return o.value!
  }
  
  return getter
}