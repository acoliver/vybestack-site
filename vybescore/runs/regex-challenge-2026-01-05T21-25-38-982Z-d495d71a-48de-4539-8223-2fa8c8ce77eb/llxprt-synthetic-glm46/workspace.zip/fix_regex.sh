#!/bin/bash
# Fix regex escape characters that are causing linting errors

# Fix validators.ts line 57 - unnecessary escape for parentheses and hyphen
sed -i 's|const normalized = value.replace(/\[\\\\s-\\\\(\\\\)\]/g, "");|const normalized = value.replace(/[\s-\(\)]/g, "");|' src/validators.ts

# Fix puzzles.ts line 18 - unnecessary escape in character class
sed -i 's|const escapedToken = token.replace(/\[.*\+\?\^\$\{\}\(\)\|\\\\\[\]\]/g, "\\\\\\\\\\\\$&");|const escapedToken = token.replace(/[.*+?^${}()|\[\]]/g, "\\\\\\$&");|' src/puzzles.ts

# Fix puzzles.ts line 48 - unnecessary escape in character class
sed -i 's|if \(!/v4(\s*\.\s*v4)?\s*\\\[\s*-\\\s*\]/i\.test(value)\) return false;|if (!/v4(\s*\.\s*v4)?\s*\[\s*-\s*\]/i.test(value)) return false;|' src/puzzles.ts