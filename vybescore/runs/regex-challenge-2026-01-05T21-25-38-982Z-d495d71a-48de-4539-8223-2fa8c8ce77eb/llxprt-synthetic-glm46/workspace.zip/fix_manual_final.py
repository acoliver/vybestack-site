#!/usr/bin/env python3

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Fix the line by simple string replacement
content = content.replace(
    'const normalized = value.replace(/[\\\\s-\\\\(\\\\)]/g, \'\');',
    'const normalized = value.replace(/[\\s-\\(\\)]/g, \'\');'
)

# Write back
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed validators.ts")

# Read puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    content = f.read()

# Fix the line by simple string replacement
content = content.replace(
    'if (!/[!@#$%^&*()_+\\\\-=\\\\[\\\\]{};':\\\"\\\\\\\\|,.<>\\\\/?]/.test(value)) return false;',
    'if (!/[!@#$%^&*()_+\\-=\\[\\]{};\':\\"\\\\|,.<>\\/?]/.test(value)) return false;'
)

# Write back
with open('src/puzzles.ts', 'w') as f:
    f.write(content)

print("Fixed puzzles.ts")