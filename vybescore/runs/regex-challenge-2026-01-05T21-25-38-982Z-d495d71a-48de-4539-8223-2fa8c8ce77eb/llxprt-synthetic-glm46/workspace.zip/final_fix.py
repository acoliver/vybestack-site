#!/usr/bin/env python3
import os

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    validators_content = f.read()

# Find and replace the problematic regex lines in validators.ts
lines = validators_content.split('\n')

# Find the function start and rewrite it
in_function = False
function_start = -1
function_end = -1

for i, line in enumerate(lines):
    if 'export function isValidUSPhone(value: string): boolean' in line:
        function_start = i
        in_function = True
    elif in_function and line.startswith('export function'):
        function_end = i
        break

# Replace the function
if function_start >= 0:
    new_function = '''export function isValidUSPhone(value: string): boolean {
  // Remove separators and normalize
  const normalized = value.replace(/[\s-\(\)]/g, '');

  // Check for optional +1 prefix
  const withoutCountryCode = normalized.startsWith('+1') ? normalized.substring(2) : normalized;

  // Must be 10 digits after removing country code
  if (!/^\\d{10}$/.test(withoutCountryCode)) return false;

  // Area code validation (can't start with 0 or 1)
  const areaCode = withoutCountryCode.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Accept any valid format with separators
  const phoneRegex = /^(\\+1\\s?)?(\\(\\d{3}\\)|\\d{3})[\\s-]?\\d{3}[\\s-]?\\d{4}$/;
  return phoneRegex.test(value);
}'''
    
    lines[function_start:function_end] = new_function.split('\n')

# Write back to file
with open('src/validators.ts', 'w') as f:
    f.write('\n'.join(lines))

print("Fixed validators.ts")

# Now fix puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    puzzles_content = f.read()

lines = puzzles_content.split('\n')

# Find the problematic line
for i, line in enumerate(lines):
    if 'if (!/[!@#$%^&*()_+\\\\-=\\\\[\\\\]' in line:
        lines[i] = '  if (!/[!@#$%^&*()_+\\-=\\[\\]{};\':\\"\\\\|,.<>\\/?]/.test(value)) return false;'
        break

# Write back to file
with open('src/puzzles.ts', 'w') as f:
    f.write('\n'.join(lines))

print("Fixed puzzles.ts")