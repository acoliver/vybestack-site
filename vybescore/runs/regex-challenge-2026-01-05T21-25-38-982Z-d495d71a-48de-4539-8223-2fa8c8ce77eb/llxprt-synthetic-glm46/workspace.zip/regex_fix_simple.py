#!/usr/bin/env python3
import re

# Read the validators.ts file
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Fix line 57 - remove unnecessary escape characters
# The problematic pattern is a character class with escaped characters that don't need escaping
content = content.replace(
    'const normalized = value.replace(/[\\\\s-\\\\(\\\\)]/g, \'\');',
    'const normalized = value.replace(/[\\s-\\(\\)]/g, \'\');'
)

# Write back to validators.ts
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed validators.ts")

# Now fix puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    content = f.read()

# Fix line 18 - remove unnecessary escape in character class
content = content.replace(
    'const escapedToken = token.replace(/[.*+?^${}()|\\\\[\\\\]]/g, \'\\\\\\\\$&\');',
    'const escapedToken = token.replace(/[.*+?^${}()|[\\]]/g, \'\\\\$&\');'
)

# Fix line 48 - remove unnecessary escape
content = content.replace(
    'if (!/v4(\\s*\\.\\s*v4)?\\s*\\\\[\\s*-\\s*]/i.test(value)) return false;',
    'if (!/v4(\\s*\\.\\s*v4)?\\s*[\\s*-\\s*]/i.test(value)) return false;'
)

# Write back to puzzles.ts
with open('src/puzzles.ts', 'w') as f:
    f.write(content)

print("Fixed puzzles.ts")