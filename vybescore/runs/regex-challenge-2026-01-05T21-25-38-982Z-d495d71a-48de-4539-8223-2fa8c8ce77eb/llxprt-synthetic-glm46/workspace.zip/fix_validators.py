#!/usr/bin/env python3

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Fix the line by simple string replacement
content = content.replace(
    'const normalized = value.replace(/[\\\\s-\\\\(\\\\)]/g, \'\');',
    'const normalized = value.replace(/[\\s-\\(\\)]/g, \'\');'
)

# Write back
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed validators.ts")