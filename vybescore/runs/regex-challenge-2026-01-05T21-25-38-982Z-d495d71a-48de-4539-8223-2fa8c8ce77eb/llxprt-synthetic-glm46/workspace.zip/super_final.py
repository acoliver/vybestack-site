#!/usr/bin/env python3
import re

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    validators_content = f.read()

# Replace the problematic line with proper escaping
validators_content = re.sub(
    r'const normalized = value\.replace\(/\[\\\\s-\\\\\(\\\)\]/g, \'\');',
    'const normalized = value.replace(/[\\s-\\(\\)]/g, \'\');',
    validators_content
)

# Write back to validators.ts
with open('src/validators.ts', 'w') as f:
    f.write(validators_content)

print("Fixed validators.ts")

# Read puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    puzzles_content = f.read()

# Replace the problematic line in puzzles.ts with proper escaping
puzzles_content = re.sub(
    r'if \(!/\[\!@#\$%\^\&\*\(\)_\+\\\\-=\\\\\[\\\\\]\{\}\;\'\:\\"\\\\\\\\\|\,\.\<\>\\\\\?\]/\.test\(value\)\) return false;',
    'if (!/[!@#$%^&*()_+\\-=\\[\\]{};\':\\"\\\\|,.<>\\/?]/.test(value)) return false;',
    puzzles_content
)

# Write back to puzzles.ts
with open('src/puzzles.ts', 'w') as f:
    f.write(puzzles_content)

print("Fixed puzzles.ts")