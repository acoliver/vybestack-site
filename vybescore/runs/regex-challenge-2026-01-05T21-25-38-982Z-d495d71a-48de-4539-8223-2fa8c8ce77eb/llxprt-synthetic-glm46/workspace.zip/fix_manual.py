#!/usr/bin/env python3

# Read the validators.ts file
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Find the problematic line by searching and replace with the correct version
lines = content.split('\n')
for i, line in enumerate(lines):
    if 'replace(/[\\\\s-\\\\(\\\\)]/g' in line:
        lines[i] = line.replace('/[\\\\s-\\\\(\\\\)]/', '/[\\s-\\(\\)]')
        content = '\\n'.join(lines)
        break

# Write back to validators.ts
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed validators.ts")

# Now fix puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    content = f.read()

lines = content.split('\n')
for i, line in enumerate(lines):
    if 'replace(/[.*+?^${}()|\\\\[\\\\]]/g' in line:
        # Fix line 18
        lines[i] = line.replace('/[.*+?^${}()|\\\\[\\\\]]/', '/[.*+?^${}()|[\\]]')
        content = '\\n'.join(lines)
        break

for i, line in enumerate(lines):
    if '/v4(\\s*\\.\\s*v4)?\\s*\\\\[\\s*-\\s*]/i' in line:
        # Fix line 48
        lines[i] = line.replace('\\s*\\\\[\\s*-\\s*]', '\\s*[\\s*-\\s*]')
        content = '\\n'.join(lines)
        break

# Write back to puzzles.ts
with open('src/puzzles.ts', 'w') as f:
    f.write(content)

print("Fixed puzzles.ts")