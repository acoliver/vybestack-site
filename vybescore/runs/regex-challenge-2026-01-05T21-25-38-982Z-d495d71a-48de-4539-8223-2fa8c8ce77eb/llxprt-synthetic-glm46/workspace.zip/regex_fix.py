#!/usr/bin/env python3
import re

# Read the file
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Fix line 57 - unnecessary escape characters
content = re.sub(
    r'const normalized = value\.replace\(/\[\\\\s-\\\\\(\\\\\)\]/g, ""\);',
    'const normalized = value.replace(/[\s-\(\)]/g, "");',
    content
)

# Write back to file
with open('src/validators.ts', 'w') as f:
    f.write(content)

# Fix puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    content = f.read()

# Fix line 18
content = re.sub(
    r'const escapedToken = token\.replace\(/\[\.\*\+\?\^\$\{\}\(\)\|\\\\\[\]\]/g, "\\\\\\\\\\\\\$&"\);',
    'const escapedToken = token.replace(/[.*+?^${}()|\[\]]/g, "\\\\\\\\$&");',
    content
)

# Fix line 48
content = re.sub(
    r'if \(!/v4\(\s*\.\s*v4\)?\s*\\\[\s*-\\\s*\]/i\.test\(value\)\) return false;',
    'if (!/v4(\s*\.\s*v4)?\s*\[\s*-\s*\]/i.test(value)) return false;',
    content
)

# Write back to file
with open('src/puzzles.ts', 'w') as f:
    f.write(content)

print("Fixed regex escape characters")