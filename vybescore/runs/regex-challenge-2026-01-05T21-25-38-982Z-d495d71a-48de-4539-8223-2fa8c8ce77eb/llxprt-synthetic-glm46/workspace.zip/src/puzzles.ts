/**
 * Finds words starting with the prefix but excluding exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Use word boundaries to match whole words starting with prefix
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.some((exception: string) => word.startsWith(exception)));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\\$&');
  
  // Use pattern to find token preceded by digit
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(regex) || [];
  
  // Return the full matches (including the digit)
  return matches;
}

/**
 * Validates passwords according to policy requirements.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
// At least one symbol - build character class properly
  const symbolChars = '!@#$%^&*()_+-=[]{};:\\",.<>/?';
  const symbolRegex = new RegExp(`[${symbolChars.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}]`);
  if (!symbolRegex.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab)
  if (/(\w{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns - simplified to avoid multiline regex issues
  const ipv6PatternFull = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  const ipv6PatternShorthand = /(?:[0-9a-fA-F]{1,4}:){1,7}:/;
  const ipv6PatternLeading = /:(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}/;
  const ipv6PatternGeneric = /[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}/;
  const ipv6PatternMiddle = /[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}/;
  const ipv6PatternLeadingOnly = /::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}/;
  
  // First check if it matches any IPv6 pattern
  const hasIPv6 = ipv6PatternFull.test(value) || 
                  ipv6PatternShorthand.test(value) || 
                  ipv6PatternLeading.test(value) || 
                  ipv6PatternGeneric.test(value) || 
                  ipv6PatternMiddle.test(value) || 
                  ipv6PatternLeadingOnly.test(value);
  
  if (!hasIPv6) return false;
  
  // Then ensure we don't have IPv4
  return !ipv4Pattern.test(value);
}