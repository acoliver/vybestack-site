/**
 * Capitalizes the first character of each sentence.
 */
export function capitalizeSentences(text: string): string {
  // Split on sentence boundaries and handle edge cases
  return text.replace(/([.!?]+)(\s*)([a-z])/g, (match, punctuation, spaces, firstChar) => {
    // Replace with capitalized first character and exactly one space
    return punctuation + ' ' + firstChar.toUpperCase();
  })
  // Handle start of string
  .replace(/^[a-z]/, char => char.toUpperCase())
  // Remove extra spaces after punctuation
  .replace(/(\s){2,}/g, ' ');
}

/**
 * Extracts URLs from text.
 */
export function extractUrls(text: string): string[] {
  // Match URLs including http, https, and www patterns, without trailing punctuation
  const urlRegex = /\b((https?:\/\/|www\.)[^\s<]+(?![\w-]))/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;)\]}]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't affect already https URLs
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites docs URLs to use https and docs subdomain.
 */
export function rewriteDocsUrls(text: string): string {
  // Use string replacement approach for http://example.com URLs
  return text.replace(/http:\/\/example\.com[^\s]*/g, (url) => {
    // Extract path from the URL
    const path = url.replace('http://example.com', '');
    
    // Check if it's a docs path that should go to docs subdomain
    // Skip rewrite for CGI-bin, query strings, or certain extensions
    if (path.startsWith('/docs/') && 
        !path.includes('cgi-bin') && 
        !path.includes('?') && 
        !/\.(jsp|php|asp|aspx|do|cgi|pl|py)/.test(path)) {
      return 'https://docs.example.com' + path;
    } else {
      // Just upgrade to https
      return 'https://example.com' + path;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month/day ranges
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    return match[3]; // Return the year
  }
  
  return 'N/A';
}
