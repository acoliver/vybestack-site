/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '').split('').map(Number);
  let sum = 0;
  let isSecond = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isSecond) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    isSecond = !isSecond;
  }
  
  return sum % 10 === 0;
}

export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic validation
  if (!emailRegex.test(value)) return false;
  
  // No consecutive dots
  if (value.includes('..')) return false;
  
  // No leading or trailing dots in local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain validation
  if (domain.includes('_')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  
  return true;
}

/**
 * Validates US phone numbers.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove separators and normalize
  const separatorPattern = new RegExp('[\\s-\\(\\)]', 'g');
  const normalized = value.replace(separatorPattern, '');

  // Check for optional +1 prefix
  const withoutCountryCode = normalized.startsWith('+1') ? normalized.substring(2) : normalized;

  // Must be 10 digits after removing country code
  if (!/^\d{10}$/.test(withoutCountryCode)) return false;

  // Area code validation (can't start with 0 or 1)
  const areaCode = withoutCountryCode.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Accept any valid format with separators
  const phonePattern = new RegExp('^(\\+1\\s?)?(\\(\\d{3}\\)|\\d{3})[\\s-]?\\d{3}[\\s-]?\\d{4}$');
  return phonePattern.test(value);
}

export function isValidArgentinePhone(value: string): boolean {
  // Remove separators and normalize for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Validate regex that covers all Argentine formats
  const argentinePhoneRegex = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(normalized)) return false;
  
  // Extract components
  const [, countryCode, , trunkPrefix, areaCode, subscriber] = normalized.match(argentinePhoneRegex) || [];
  
  // Area code must be 2-4 digits and start with 1-9
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber number must be 6-8 digits
  if (!subscriber || subscriber.length < 6 || subscriber.length > 8) return false;
  
  // When country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) return false;
  
  return true;
}

/**
 * Validates personal names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and obviously invalid names
  const nameRegex = /^[\p{L}\p{M}\p{N}][\p{L}\p{M}\p{N}\s'-]*[\p{L}\p{M}\p{N}]$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Check for digits explicitly
  if (/\d/.test(value)) return false;
  
  // Reject obvious joke names with many special characters
  const specialCharCount = (value.match(/['-]/g) || []).length;
  if (specialCharCount > 2) return false;
  
  return true;
}

/**
 * Validates credit card numbers.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // Check Mastercard (16 digits, starts with 51-55 or 2221-2720)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d|7([01]\d|20))\d{12}$/;
  // Check American Express (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check brand pattern
  const validBrand = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
  if (!validBrand) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
