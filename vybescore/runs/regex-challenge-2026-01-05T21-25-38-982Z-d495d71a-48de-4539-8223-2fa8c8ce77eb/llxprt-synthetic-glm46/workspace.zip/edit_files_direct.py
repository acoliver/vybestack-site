#!/usr/bin/env python3

# Read the entire validators.ts file
with open('src/validators.ts', 'r') as f:
    validators_lines = f.readlines()

# Fix line 57 (0-indexed would be 56)
for i, line in enumerate(validators_lines):
    if 'value.replace(/[\\s-\\(\\)]/g, \'\');' in line:
        # Replace the entire line with a version that has the correct escaping
        validators_lines[i] = '  const normalized = value.replace(/[\\s-\\(\\)]/g, \'\');\n'
        break

# Write back the file
with open('src/validators.ts', 'w') as f:
    f.writelines(validators_lines)

print("Fixed validators.ts")

# Read puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    puzzles_lines = f.readlines()

# Fix line 48 
for i, line in enumerate(puzzles_lines):
    if '!/[!@#$%^&*()_+\\-=\\[\\]' in line:
        puzzles_lines[i] = '  if (!/[!@#$%^&*()_+\\-=\\[\\]{};\':\\"\\\\|,.<>\\/?]/.test(value)) return false;\n'
        break

# Write back the file
with open('src/puzzles.ts', 'w') as f:
    f.writelines(puzzles_lines)

print("Fixed puzzles.ts")