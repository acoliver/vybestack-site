#!/usr/bin/env python3
import re

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    validator_content = f.read()

# Replace the line using regex pattern to match the exact line
validator_content = re.sub(
    r'const normalized = value\.replace(/\[\\\\s-\\\\(\\\\)\]/g, \'\');',
    'const normalized = value.replace(/[\\s-\\(\\)]/g, \'\');',
    validator_content
)

# Write back to validators.ts
with open('src/validators.ts', 'w') as f:
    f.write(validator_content)

print("Fixed validators.ts")

# Read puzzles.ts
with open('src/puzzles.ts', 'r') as f:
    puzzles_content = f.read()

# Fix line 18
puzzles_content = re.sub(
    r'const escapedToken = token\.replace(/\[.*\+\?\^\$\{\}\(\)\|\\\\\[\]\]/g, \'\\\\\\\\\\\\$&\');',
    'const escapedToken = token.replace(/[.*+?^${}()|[\\]]/g, \'\\\\\\\$&\');',
    puzzles_content
)

# Fix line 48
puzzles_content = re.sub(
    r'if \(!/v4\(\\s\*\\\\\. \\s\*v4\)\?\\s\*\\\\\[\\s\*-\\s\*\\\\\]/i\.test\(value\)\) return false;',
    'if (!/v4(\\s*\\.\\s*v4)?\\s*[\\s*-\\s*]/i.test(value)) return false;',
    puzzles_content
)

# Write back to puzzles.ts
with open('src/puzzles.ts', 'w') as f:
    f.write(puzzles_content)

print("Fixed puzzles.ts")