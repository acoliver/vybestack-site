export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper RFC compliance.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex matching local@domain.tld format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // More detailed validation
  const [localPart, domain] = value.split('@');
  
  // Check for consecutive dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Local part should not start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain validation
  // Should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain should not start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || 
      domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Last segment (TLD) should be at least 2 characters
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) {
    return false;
  }
  
  // Validate characters in local part (allow letters, digits, and special chars !#$%&'*+/=?^_`{|}~-)
  const localRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~.-]+$/;
  if (!localRegex.test(localPart)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers in various formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits
  // With country code: 11 digits, without: 10 digits
  if (digits.length === 11) {
    // If 11 digits, must start with country code 1
    if (!digits.startsWith('1')) {
      return false;
    }
    // Remove country code for further validation
    const phoneNumber = digits.substring(1);
    return isValidUSPhoneNumber(phoneNumber);
  } else if (digits.length === 10) {
    // 10 digits, validate as is
    return isValidUSPhoneNumber(digits);
  } else {
    // Wrong number of digits
    return false;
  }
}

/**
 * Helper function to validate a 10-digit US phone number.
 */
function isValidUSPhoneNumber(digits: string): boolean {
  // Area code (first 3 digits) should not start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Exchange code (next 3 digits) should not start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  // All remaining validations passed
  return true;
}

/**
 * Validate Argentine phone numbers in various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54.
 * Optional trunk prefix 0 immediately before the area code.
 * Optional mobile indicator 9 between country/trunk and the area code.
 * Area code must be 2–4 digits (leading digit 1–9).
 * Subscriber number must contain 6–8 digits in total.
 * When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * Allows single spaces or hyphens as separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Optional +54 country code, or 0 trunk prefix
  // Optional 9 for mobile numbers
  // Area code (2-4 digits, leading 1-9)
  // Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?([9])?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if matches pattern
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  // Extract components
  const [, , areaCode, subscriberNumber] = match;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4 || !areaCode.match(/^[1-9]\d*$/)) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8 || !subscriberNumber.match(/^\d+$/)) {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix 0 before area code
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa (13 or 16 digits, starts with 4), Mastercard (16 digits, starts with 51-55, 2221-2720), 
 * and American Express (15 digits, starts with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for valid length
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  if ((digits.length === 13 || digits.length === 16) && digits.startsWith('4')) {
    return runLuhnCheck(digits);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (digits.length === 16) {
    const starts51to55 = digits.match(/^5[1-5]/);
    const starts2221to2720 = digits.match(/^2(?:2[2-9]|3[0-9]|4[0-9]|5[0-9]|6[0-9]|7[0-1])/);
    
    if (starts51to55 || starts2221to2720) {
      return runLuhnCheck(digits);
    }
  }
  
  // American Express: 15 digits, starts with 34 or 37
  if (digits.length === 15 && (digits.startsWith('34') || digits.startsWith('37'))) {
    return runLuhnCheck(digits);
  }
  
  // Not a valid card format
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and other special characters
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Test the basic format first
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with just spaces or hyphens or apostrophes
  const cleanValue = value.replace(/['\-\s]/g, '');
  if (!cleanValue || cleanValue.length === 0) {
    return false;
  }
  
  // Reject names with consecutive special characters (not allowed)
  if (value.includes('--') || value.includes("''") || value.includes("  ")) {
    return false;
  }
  
  // Ensure the name starts and ends with a letter, not a special character
  if (value.match(/^['\-\s]/) || value.match(/['\-\s]$/)) {
    return false;
  }
  
  return true;
}
