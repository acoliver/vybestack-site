/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for use in regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all words with the prefix
  const allMatches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return allMatches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for use in regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, not at start of string
  const tokenRegex = new RegExp(`(?<!^)\\d(${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  // Find all matches
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]); // Return the full matched string (digit + token)
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\=\\[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Must not contain immediate repeated sequences (e.g., "abab")
  for (let i = 0; i < value.length; i++) {
    // Check for patterns like "ab" repeated
    if (i + 3 < value.length) {
      const pair1 = value.substring(i, i + 2);
      const pair2 = value.substring(i + 2, i + 4);
      if (pair1 === pair2) {
        return false;
      }
    }
    // Check for patterns like "abc" repeated
    if (i + 5 < value.length) {
      const triple1 = value.substring(i, i + 3);
      const triple2 = value.substring(i + 3, i + 6);
      if (triple1 === triple2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns (excluding IPv4 addresses)
  // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // Compressed: 2001:db8::8a2e:370:7334
  // Loopback: ::1
  // Compressed: ::
  // IPv6 with IPv4 embedded: 2001:db8::192.0.2.33
  
  // First, eliminate IPv4 patterns to avoid false positives
  // Standard IPv4: 192.168.0.1
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 pattern
  // 1. Full 8-part pattern: x:x:x:x:x:x:x:x
  // 2. Compressed with :: (at least one colon)
  // 3. IPv6 with IPv4 at the end: x:x:x:x:x:x:x:d.d.d.d
  const ipv6Pattern = /\b(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}\b|(?:[0-9a-f]{1,4}:){1,7}:(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4}\b|(?:[0-9a-f]{1,4}:){1,6}:[0-9]{1,3}(?:\.[0-9]{1,3}){1,3}\b|::1?\b/gi;
  
  // Check if there's an IPv4 address first
  if (ipv4Pattern.test(value)) {
    // Check if there's also IPv6 in the string
    // Remove IPv4 addresses and check for IPv6 patterns
    const withoutIPv4 = value.replace(ipv4Pattern, '');
    return ipv6Pattern.test(withoutIPv4);
  }
  
  return ipv6Pattern.test(value);
}
