/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence boundaries (. ? !) while preserving the delimiter
  const sentences = text.split(/([.?!])/);
  
  // Process pairs of content and delimiter
  const result = [];
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const delimiter = sentences[i + 1];
    
    if (sentence.trim()) {
      // Get the first word character to capitalize
      const firstWordChar = sentence.search(/\S/);
      if (firstWordChar !== -1) {
        // Capitalize the first letter and preserve the rest
        const before = sentence.substring(0, firstWordChar);
        const firstChar = sentence.charAt(firstWordChar).toUpperCase();
        const after = sentence.substring(firstWordChar + 1);
        
        result.push(before + firstChar + after);
      } else {
        result.push(sentence);
      }
      
      // Add the delimiter and ensure proper spacing
      if (delimiter) {
        result.push(delimiter);
        // Look ahead to see if the next sentence starts immediately or has space
        if (i + 2 < sentences.length && !sentences[i + 2].match(/^\s/)) {
          result.push(' ');
        }
      }
    } else if (delimiter) {
      // This handles cases like ". ! ." with no content
      result.push(sentence);
      result.push(delimiter);
    } else {
      result.push(sentence);
    }
  }
  
  // Collapse multiple spaces into single spaces, but preserve one space after sentence delimiters
  return result.join('').replace(/ {2,}/g, ' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Handles http, https, ftp protocols and www domains without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches:
  // - http://, https://, ftp:// protocols
  // - www. domains (treated as http://www.)
  // - domain names with subdomains
  // - paths, query strings, fragments
  // But exclude trailing punctuation like .,?!;:
  const urlRegex = /((https?:\/\/|ftp:\/\/|www\.)[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s\)\}\]"',.;!?]+)*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove common trailing punctuation characters, but keep punctuation within the URL
    return url.replace(/[.,;!?]+$/g, '').replace(/[)\]}']+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't modify https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlRegex = /(http:\/\/example\.com(\/[^?\s]*))/gi;
  
  return text.replace(urlRegex, (match, fullUrl, path) => {
    // Always upgrade scheme to https
    let result = 'https://docs.example.com' + path;
    
    // Skip host rewrite when path contains dynamic hints
    const skipPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i
    ];
    
    // If any skip pattern matches, just upgrade the scheme but keep the original host
    const shouldSkipHost = skipPatterns.some(pattern => pattern.test(path));
    
    if (shouldSkipHost) {
      result = 'https://example.com' + path;
    }
    
    return result;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const leapYear = (parseInt(year, 10) % 4 === 0 && 
                     parseInt(year, 10) % 100 !== 0) || 
                     parseInt(year, 10) % 400 === 0;
    
    if (day > (leapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
