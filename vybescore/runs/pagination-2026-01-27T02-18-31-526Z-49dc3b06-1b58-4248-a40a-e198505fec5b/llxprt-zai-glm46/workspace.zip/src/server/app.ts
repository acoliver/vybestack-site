import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function isValidPaginationParam(value: string | undefined): boolean {
  if (value === undefined) {
    return true;
  }
  // Must be numeric, positive, and reasonable (not excessive)
  const num = Number(value);
  if (!/^\d+$/.test(value)) {
    return false;
  }
  if (num <= 0 || num > 1000) {
    return false;
  }
  return true;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate pagination parameters
    if (!isValidPaginationParam(pageParam) || !isValidPaginationParam(limitParam)) {
      return res.status(400).json({
        error: 'Invalid pagination parameters. page and limit must be positive integers not exceeding 1000.'
      });
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
