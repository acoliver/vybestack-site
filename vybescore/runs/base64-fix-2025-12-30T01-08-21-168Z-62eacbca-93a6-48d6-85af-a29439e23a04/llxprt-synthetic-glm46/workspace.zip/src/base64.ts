/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

function validateBase64Input(input: string): void {
  // Validate the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }
  
  // Check if the padding is correct (if present)
  const padding = input.match(/=*$/);
  if (padding && padding[0].length > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Check for correct length for padding
  const paddingLength = padding ? padding[0].length : 0;
  if (paddingLength > 0 && input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect length for padding');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input uses the standard Base64 alphabet and rejects invalid payloads.
 */
export function decode(input: string): string {
  validateBase64Input(input);
  
  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: if the Buffer conversion resulted in empty string but input wasn't empty,
    // it might be an invalid Base64 string
    if (result === '' && input !== '' && input !== '==') {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
