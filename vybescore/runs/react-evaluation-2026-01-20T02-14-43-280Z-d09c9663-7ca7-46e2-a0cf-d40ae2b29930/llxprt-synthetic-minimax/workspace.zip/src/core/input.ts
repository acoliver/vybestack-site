/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  registerDependency,
  notifyDependency,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : 
    typeof equal === 'boolean' && !equal ? undefined :
    (a: T, b: T) => a === b

  const subject: Subject<T> = {
    value,
    observers: new Set(),
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (subject.equalFn && subject.equalFn(subject.value, nextValue)) {
      return subject.value
    }
    subject.value = nextValue
    notifyDependency(subject)
    return subject.value
  }

  return [read, write]
}
