/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value: undefined,
    updateFn: ((currentValue?: unknown): T => {
      return updateFn(currentValue as T)
    }) as UpdateFn<unknown>,
    callback: true,
    subjects: new Set()
  }
  
  let disposed = false
  
  // Set this observer as active and execute the callback to establish dependencies
  setActiveObserver(observer)
  try {
    const result = updateFn(_value)
    observer.value = result
  } finally {
    setActiveObserver(undefined)
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear references to prevent memory leaks
    if (observer.subjects) {
      observer.subjects.forEach(subject => {
        subject.observers.delete(observer)
      })
      observer.subjects.clear()
    }
    observer.updateFn = () => undefined
    observer.value = undefined
  }
  
  return unsubscribe
}
