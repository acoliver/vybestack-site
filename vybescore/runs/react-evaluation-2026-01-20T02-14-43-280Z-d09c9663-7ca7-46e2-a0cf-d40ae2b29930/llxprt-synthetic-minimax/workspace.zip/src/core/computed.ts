/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  getActiveObserver,
  registerDependency,
  updateObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof equal === 'function' ? equal : 
    typeof equal === 'boolean' && !equal ? undefined :
    (a: T, b: T) => a === b

  const subject: Subject<T> = {
    value: value!,
    observers: new Set(),
    equalFn,
  }

  const observer: Observer<T> = {
    value: value,
    updateFn: ((currentValue?: unknown): T => {
      const previous = getActiveObserver()
      setActiveObserver(observer)
      try {
        const result = updateFn(currentValue as T)
        subject.value = result
        return result
      } finally {
        setActiveObserver(previous)
      }
    }) as UpdateFn<unknown>,
    // Mark computed observers as dirty so they get re-evaluated
    dirty: true
  }

  const read: GetterFn<T> = () => {
    // Register as dependency when accessed by another observer
    const active = getActiveObserver()
    if (active) {
      registerDependency(subject, active)
    }
    
    // Always re-evaluate the computed value for consistency
    const result = updateObserver(observer)!
    return result
  }

  return read
}
