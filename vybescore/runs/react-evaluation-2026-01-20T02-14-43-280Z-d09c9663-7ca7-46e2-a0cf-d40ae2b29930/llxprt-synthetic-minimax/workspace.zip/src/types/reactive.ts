/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export interface Options {
  name?: string
}

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export interface Observer<T> {
  value?: T
  updateFn: UpdateFn<unknown>
  subjects?: Set<Subject<any>>
  callback?: boolean
  dirty?: boolean
  evaluating?: boolean
}

export interface Subject<T> {
  value: T
  observers: Set<Observer<any>>
  equalFn?: EqualFn<any>
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  if (!observer?.updateFn) {
    throw new Error('Invalid observer')
  }
  
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value) as T
    observer.value = result
    return result
  } finally {
    activeObserver = previous
  }
}

export function registerDependency<T>(subject: Subject<T>, observer: Observer<T>): void {
  subject.observers.add(observer)
  if (!observer.subjects) {
    observer.subjects = new Set()
  }
  observer.subjects.add(subject)
}

export function notifyDependency<T>(subject: Subject<T>): void {
  const observers = [...subject.observers]
  observers.forEach(observer => {
    if (observer.callback) {
      // Immediately trigger callbacks
      updateObserver(observer)
    } else {
      // Mark as dirty for later evaluation
      observer.dirty = true
    }
  })
}

// Keep the old function names for compatibility
export const notifyObservers = notifyDependency
export const registerObserver = registerDependency
