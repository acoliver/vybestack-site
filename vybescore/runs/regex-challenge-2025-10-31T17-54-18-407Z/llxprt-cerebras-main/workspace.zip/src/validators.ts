export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses and rejects obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with additional checks for dots and domain rules
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for double dots or trailing dots in local part or domain
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check if domain has underscores (not allowed)
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // Check if it starts with +1 and remove it
  let cleanDigits = digits;
  if (value.trim().startsWith('+1') && digits.startsWith('1')) {
    cleanDigits = digits.substring(1);
  }
  
  // Must be exactly 10 digits now
  if (cleanDigits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (cleanDigits[0] === '0' || cleanDigits[0] === '1') {
    return false;
  }
  
  // Valid formats: (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^(\+?1[-.\s]?)?\(?([2-9][0-9]{2})\)?[-.\s]?([2-9][0-9]{2})[-.\s]?([0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers (landlines and mobiles).
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Define regex patterns for Argentine phone numbers
  const patterns = [
    /^\+549[1-9]\d{2,3}\d{6,8}$/,         // +54 9 11 1234 5678 (mobile)
    /^\+54[1-9]\d{2,3}\d{6,8}$/,          // +54 341 123 4567 (landline)
    /^0[1-9]\d{2,3}\d{6,8}$/,             // 011 1234 5678 (trunk prefix)
  ];
  
  // Check if the value matches any of the patterns
  for (const pattern of patterns) {
    if (pattern.test(cleanValue)) {
      // Extract area code and subscriber number to validate lengths
      let areaCode, subscriber;
      
      if (cleanValue.startsWith('+549')) {
        // Mobile with country code
        const parts = cleanValue.substring(4).match(/^([1-9]\d{1,3})(\d{6,8})$/);
        if (!parts) return false;
        areaCode = parts[1];
        subscriber = parts[2];
      } else if (cleanValue.startsWith('+54')) {
        // Landline with country code
        const parts = cleanValue.substring(3).match(/^([1-9]\d{1,3})(\d{6,8})$/);
        if (!parts) return false;
        areaCode = parts[1];
        subscriber = parts[2];
      } else if (cleanValue.startsWith('0')) {
        // With trunk prefix
        const parts = cleanValue.substring(1).match(/^([1-9]\d{1,3})(\d{6,8})$/);
        if (!parts) return false;
        areaCode = parts[1];
        subscriber = parts[2];
      } else {
        return false;
      }
      
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) {
        return false;
      }
      
      // Subscriber number must be 6-8 digits
      if (subscriber.length < 6 || subscriber.length > 8) {
        return false;
      }
      
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 */
export function isValidName(value: string): boolean {
  // Name can contain unicode letters, spaces, hyphens, and apostrophes
  // But cannot contain digits or symbols except those allowed
  const nameRegex = /^[^\d\W][\w\s'-]*[^\d\W]$/u;
  
  // Special check for X Æ A-12 style names (must not contain digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must not be empty and must match pattern
  return value.length > 0 && nameRegex.test(value);
}

/**
 * Helper function to run Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Visa, Mastercard, and AmEx patterns
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starting with 4
  const mastercardPattern = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/; // 16 digits, starting with 5[1-5] or 2[2-7]
  const amexPattern = /^3[47]\d{13}$/; // 15 digits, starting with 34 or 37
  
  // Check if it matches any card pattern
  if (!(visaPattern.test(cleanValue) || mastercardPattern.test(cleanValue) || amexPattern.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanValue);
}