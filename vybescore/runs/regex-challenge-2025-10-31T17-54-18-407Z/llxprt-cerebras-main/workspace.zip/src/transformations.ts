/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  // If empty text, return as is
  if (!text) return text;
  
  // Split by sentence ending punctuation followed by space or end of string
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http, https, ftp) and remove trailing punctuation
  const urlRegex = /\b(?:https?|ftp):\/\/[^\s.!?;,"')\]}]+(?:[^\s!?;,"')\]}])*[^\s.!?;,"')\]}]/gi;
  const matches = text.match(urlRegex);
  return matches ? matches : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http(s)://domain/ without query parameters or certain extensions
  const docsUrlRegex = /https?:\/\/([^/\s]+)(\/docs\/[^?\s]*)(?![^\s]*[\?&=])/gi;
  
  return text.replace(docsUrlRegex, (match, domain, path) => {
    // Check if path contains dynamic elements we want to exclude
    const excludedElements = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', 'cgi-bin'];
    if (excludedElements.some(el => path.includes(el))) {
      return match.replace(/^http:/, 'https:');
    }
    
    // Rewrite to docs domain
    return `https://docs.${domain}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check if format is mm/dd/yyyy
  const dateRegex = /^\d{1,2}\/\d{1,2}\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract month and day to validate ranges
  const parts = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)!;
  const month = parts[1];
  const day = parts[2];
  
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12) and day (1-31)
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return match[1];
}