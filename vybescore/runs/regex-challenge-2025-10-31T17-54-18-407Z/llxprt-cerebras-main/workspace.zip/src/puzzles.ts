/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix but not in exceptions
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex with capturing group to find tokens following digits
  const regex = new RegExp(`\\d(${escapedToken})`, 'gi');
  const matches = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[0]); // Push the entire match (digit + token)
  }
  
  return matches;
}

/**
 * Validates passwords according to policy (at least 10 chars, uppercase, lowercase, digit, symbol, no whitespace, no repeated sequences).
 */
export function isStrongPassword(value: string): boolean {
  // Check basic requirements: length, uppercase, lowercase, digit, symbol
  if (value.length < 10) return false;
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/\d/.test(value)) return false;
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) return false;
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences like 'abab'
  // This pattern detects any sequence of 2 or more characters that repeat immediately
  if (/(.)\1{1,}|(..)\2|(...)\3/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // This regex matches valid IPv6 addresses including shorthand (::)
  // It ensures that it's not matching IPv4 addresses
  const ipv6Regex = /(?<!\d\.)(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?<!\d\.)(?:[0-9a-fA-F]{1,4}:)*::(?:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?(?!\.\d)/g;
  
  // Check if any matches are found that are not IPv4 addresses
  const matches = value.match(ipv6Regex);
  if (!matches) return false;
  
  // Ensure it's not an IPv4 address
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  return !ipv4Regex.test(value);
}