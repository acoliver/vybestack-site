#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import { ReportData } from '../types/report.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node path and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let dataFile = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  // First positional argument should be the data file
  if (!args[0]?.startsWith('--')) {
    dataFile = args[0];
  }

  // Parse flags
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[i + 1] || '';
      i++; // Skip next argument as it's the value
    } else if (arg === '--output') {
      outputPath = args[i + 1] || '';
      i++; // Skip next argument as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  // Validation
  if (!dataFile) {
    console.error('Error: data file path is required as the first argument');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string' || !reportData.title) {
    throw new Error('Invalid JSON: missing or invalid "title" field (string required)');
  }

  if (typeof reportData.summary !== 'string' || !reportData.summary) {
    throw new Error('Invalid JSON: missing or invalid "summary" field (string required)');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (array required)');
  }

  if (reportData.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" array cannot be empty');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i] as Record<string, unknown>;
    
    if (typeof entry.label !== 'string' || !entry.label) {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "label" field (string required)`);
    }

    if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "amount" field (number required)`);
    }
  }

  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf8');
    const parsedData = JSON.parse(rawData);
    
    if (validateReportData(parsedData)) {
      return parsedData as ReportData;
    }
    
    throw new Error('Validation failed');
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
      process.exit(1);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error(`Error: Failed to read file "${filePath}"`);
      process.exit(1);
    }
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    const reportData = loadReportData(args.dataFile);
    
    // Route to appropriate formatter
    const formatter = args.format === 'markdown' ? markdownFormatter : textFormatter;
    const output = formatter.format(reportData, { includeTotals: args.includeTotals });
    
    // Handle output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output);
      } catch (error) {
        console.error(`Error: Failed to write output file "${args.outputPath}": ${error instanceof Error ? error.message : 'Unknown error'}`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`);
    process.exit(1);
  }
}

main();
