/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Attempts to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence terminators
  // Ensure there's exactly one space after . ? ! when followed by text
  let normalized = text.replace(/([.!?])\s*([a-zA-Z])/g, '$1 $2');
  
  // Collapse multiple spaces into one (except newlines)
  normalized = normalized.replace(/[ \t]+/g, ' ');
  
  // Split into sentences, capitalize each, then rejoin
  // This regex splits on sentence boundaries while keeping the delimiter
  const sentences = normalized.split(/([.!?]\s+)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i];
    
    if (capitalizeNext && sentence.length > 0) {
      // Capitalize first letter
      sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      capitalizeNext = false;
    }
    
    result += sentence;
    
    // Check if this ends with sentence terminator
    if (/[.!?]\s*$/.test(sentence)) {
      capitalizeNext = true;
    }
  }
  
  return result;
}

/**
 * Extracts all URLs from the text.
 * Removes trailing punctuation from URLs.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, www.
  // Captures the URL without trailing punctuation
  const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+|www\.[^\s<>"{}|\\^`[\]]+/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation (but not part of URL)
    url = url.replace(/[.,;:!?]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Converts all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrites documentation URLs.
 * For http://example.com/... URLs:
 * - Always upgrades to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, ?, &, =, .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Still upgrades scheme for those dynamic URLs
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocolAndHost, path) => {
    // Check if path has dynamic hints that should prevent host rewrite
    const dynamicHints = /\/cgi-bin\/|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$|\.jsp\?|\.php\?|\.asp\?|\.aspx\?|\.do\?|\.cgi\?|\.pl\?|\.py\?/;
    
    // Always upgrade to https
    const secureProtocol = 'https://example.com';
    
    // Check if path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
      return `https://docs.example.com${path}`;
    }
    
    // Just upgrade scheme
    return secureProtocol + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified (leap year not checked)
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
