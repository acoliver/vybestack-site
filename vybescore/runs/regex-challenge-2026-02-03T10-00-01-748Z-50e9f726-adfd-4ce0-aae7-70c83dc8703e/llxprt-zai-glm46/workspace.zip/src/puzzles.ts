/**
 * Finds words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match words starting with prefix
  // \b word boundary, then prefix, then word characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and duplicates (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const uniqueWords = new Set<string>();
  
  matches.forEach(word => {
    const lowerWord = word.toLowerCase();
    if (!exceptionSet.has(lowerWord)) {
      uniqueWords.add(word);
    }
  });
  
  return Array.from(uniqueWords);
}

/**
 * Finds occurrences of a token only when it appears after a digit
 * and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookahead to ensure token is preceded by a digit
  // Use negative lookbehind equivalent to ensure not at start
  // Match: digit followed by token
  const pattern = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const results: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // The full match includes the digit and token
    results.push(match[0]);
  }
  
  return results;
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab, abcabc)
  // Look for patterns of length 2-4 that repeat immediately
  for (let patternLen = 2; patternLen <= 4; patternLen++) {
    for (let i = 0; i <= value.length - (patternLen * 2); i++) {
      const pattern = value.substr(i, patternLen);
      const nextPattern = value.substr(i + patternLen, patternLen);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (various formats)
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Compressed format with :: (allowed once)
  // Can include IPv4-mapped addresses (::ffff:192.168.1.1)
  
  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns:
  // 1. Full IPv6: 8 groups of hex digits
  const fullIPv6 = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // 2. IPv6 with :: at start or end
  const startCompressed = /^::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$/;
  const endCompressed = /^([0-9a-fA-F]{1,4}:){1,7}:$/;
  
  // 3. IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const embeddedIPv4 = /^([0-9a-fA-F]{1,4}:)*:([0-9a-fA-F]{1,4}:)*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  
  // 4. More precise patterns for common compressed formats
  // :: can appear once to replace one or more consecutive groups of zeros
  const generalCompressed = /^([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/;
  
  // Check if it matches any IPv6 pattern
  if (fullIPv6.test(value)) {
    return true;
  }
  
  if (startCompressed.test(value)) {
    return true;
  }
  
  if (endCompressed.test(value)) {
    return true;
  }
  
  if (generalCompressed.test(value)) {
    // Ensure it has at least some colons (not just empty)
    if (value.includes(':')) {
      return true;
    }
  }
  
  if (embeddedIPv4.test(value)) {
    return true;
  }
  
  // Also check for IPv6 within larger text
  const ipv6InText = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}/;
  
  return ipv6InText.test(value);
}
