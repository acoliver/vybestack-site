export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name@example.co.uk, name@tag.example.com
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  const email = value.trim();
  
  // Basic email regex that:
  // - Allows letters, digits, dots, hyphens, plus in local part (but not consecutive dots)
  // - Rejects double dots, leading/trailing dots in local part
  // - Requires @ symbol
  // - Domain: allows letters, digits, hyphens (no underscores in domain)
  // - TLD: at least 2 letters, allows multiple subdomains
  // - Rejects double dots, trailing dots in domain
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9+._%+-]*[a-zA-Z0-9])?@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // Check for double dots anywhere
  if (email.includes('..')) {
    return false;
  }
  
  // Check for underscores in domain
  const domainPart = email.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Check for trailing dot
  if (email.endsWith('.')) {
    return false;
  }
  
  // Check local part doesn't start or end with dot
  const localPart = email.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally with +1)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle +1 prefix
  let phoneNumber = digitsOnly;
  if (phoneNumber.length === 11 && phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.slice(1);
  } else if (phoneNumber.length > 11) {
    // Too long even with country code
    return false;
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces, hyphens) but keep structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers:
  // ^(?:\+54)? - Optional country code +54
  // (?:0)? - Optional trunk prefix 0
  // (?:9)? - Optional mobile indicator 9
  // (\d{2,4}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode) {
    // Must have trunk prefix 0
    if (!cleaned.startsWith('0')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow letters (including unicode), accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid lengths and prefixes for common card types
  // Visa: 13-16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{13})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return luhnCheck(cleaned);
}

/**
 * Luhn algorithm for credit card validation.
 */
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
