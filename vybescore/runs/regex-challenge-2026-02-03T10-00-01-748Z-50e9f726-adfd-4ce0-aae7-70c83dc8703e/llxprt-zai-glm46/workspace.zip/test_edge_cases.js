// Import the functions
import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/puzzles.js';

console.log('=== Testing Edge Cases ===\n');

console.log('--- isValidEmail ---');
console.log('name @tag@example.co.uk:', isValidEmail('name @tag@example.co.uk'));
console.log('user..name@example.com:', isValidEmail('user..name@example.com'));
console.log('user@sub_example.com:', isValidEmail('user@sub_example.com'));
console.log('.user@example.com:', isValidEmail('.user@example.com'));
console.log('user.@example.com:', isValidEmail('user.@example.com'));
console.log('');

console.log('--- isValidUSPhone ---');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890:', isValidUSPhone('012-555-7890'));  // Bad: area code starts with 0
console.log('212-155-7890:', isValidUSPhone('212-155-7890'));  // Bad: exchange code starts with 1
console.log('212555789:', isValidUSPhone('212555789'));  // Bad: too short
console.log('');

console.log('--- isValidArgentinePhone ---');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));
console.log('54 11 1234 5678:', isValidArgentinePhone('54 11 1234 5678'));  // Bad: no +, no 0 prefix
console.log('');

console.log('--- isValidName ---');
console.log('José María:', isValidName('José María'));
console.log("O'Connor:", isValidName("O'Connor"));
console.log('Jean-Claude:', isValidName('Jean-Claude'));
console.log('X Æ A-12:', isValidName('X Æ A-12'));
console.log('John123:', isValidName('John123'));
console.log('');

console.log('--- isValidCreditCard ---');
console.log('4111111111111111 (Visa):', isValidCreditCard('4111111111111111'));
console.log('5500000000000004 (Mastercard):', isValidCreditCard('5500000000000004'));
console.log('340000000000009 (AmEx):', isValidCreditCard('340000000000009'));
console.log('4111111111111112 (bad Luhn):', isValidCreditCard('4111111111111112'));
console.log('');

console.log('--- capitalizeSentences ---');
console.log('Test 1:', capitalizeSentences('hello.world.how are you?i am fine!'));
console.log('Test 2:', capitalizeSentences('this is a test.dr. smith is here.'));
console.log('');

console.log('--- extractUrls ---');
console.log('Text with URLs:', extractUrls('Visit https://example.com/path or www.test.com!'));
console.log('');

console.log('--- enforceHttps ---');
console.log('HTTP to HTTPS:', enforceHttps('Visit http://example.com and https://secure.com'));
console.log('');

console.log('--- rewriteDocsUrls ---');
console.log('Docs URL:', rewriteDocsUrls('See http://example.com/docs/api'));
console.log('Dynamic URL:', rewriteDocsUrls('See http://example.com/docs/file.jsp'));
console.log('CGI URL:', rewriteDocsUrls('See http://example.com/docs/script.cgi'));
console.log('Query URL:', rewriteDocsUrls('See http://example.com/docs/page?id=1'));
console.log('');

console.log('--- extractYear ---');
console.log('12/25/2023:', extractYear('12/25/2023'));
console.log('02/30/2023:', extractYear('02/30/2023'));
console.log('13/01/2023:', extractYear('13/01/2023'));
console.log('not-a-date:', extractYear('not-a-date'));
console.log('');

console.log('--- findPrefixedWords ---');
console.log('un- words:', findPrefixedWords('unhappy unknown undo under undo', 'un', ['undo']));
console.log('');

console.log('--- findEmbeddedToken ---');
console.log('Token after digit:', findEmbeddedToken('test123abc test abc', 'abc'));
console.log('');

console.log('--- isStrongPassword ---');
console.log('Strong P@ssw0rd:', isStrongPassword('Str0ng!Pass'));
console.log('abab repeated:', isStrongPassword('ababTest1!'));
console.log('No uppercase:', isStrongPassword('lowercase1!'));
console.log('Too short:', isStrongPassword('Sh0rt!'));
console.log('');

console.log('--- containsIPv6 ---');
console.log('Full IPv6:', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('Compressed IPv6:', containsIPv6('2001:db8::1'));
console.log('IPv4 (should be false):', containsIPv6('192.168.1.1'));
console.log('');
