#!/usr/bin/env node

import fs from 'fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const cliArgs: Partial<CliArgs> = {
    includeTotals: false
  };
  
  // First argument should be data file
  cliArgs.dataFile = args[0];
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        cliArgs.format = args[i];
        break;
      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        cliArgs.outputPath = args[i];
        break;
      case '--includeTotals':
        cliArgs.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }
  
  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return cliArgs as CliArgs;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (string required)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (string required)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (array required)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (string required)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (number required)`);
    }
  }
  
  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Load and validate data
    const reportData = loadReportData(args.dataFile);
    
    // Validate format
    const validFormats = ['markdown', 'text'];
    if (!validFormats.includes(args.format)) {
      console.error(`Unsupported format: ${args.format}. Supported formats: ${validFormats.join(', ')}`);
      process.exit(1);
    }
    
    // Render report
    const options: ReportOptions = {
      includeTotals: args.includeTotals
    };
    
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        // This should never happen due to the validation above
        console.error(`Unsupported format: ${args.format}`);
        process.exit(1);
    }
    
    // Write output
    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
        console.log(`Report written to ${args.outputPath}`);
      } catch (error) {
        console.error(`Error writing to file ${args.outputPath}: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
