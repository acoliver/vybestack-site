/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    // When accessed, track dependencies if there's an active observer
    const activeObs = getActiveObserver()
    if (activeObs) {
      addDependency(activeObs, o as Observer<unknown>)
    }
    
    return o.value!
  }
  
  return getter
}
