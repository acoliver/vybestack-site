/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies and execute initial effect
  const executeEffect = () => {
    const previous = getActiveObserver()
    setActiveObserver(observer as ObserverR)
    
    try {
      observer.value = updateFn(observer.value)
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Execute the effect initially
  executeEffect()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove all dependencies for this observer
    // Note: In a real implementation, we'd need to clean up from the global registry
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
