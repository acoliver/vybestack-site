/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create a minimal observer for this input
  const inputObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => value
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: inputObserver,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this input as a dependency to the active observer
      addDependency(observer, inputObserver as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (!hasChanged) return s.value
    
    s.value = nextValue
    inputObserver.value = nextValue
    
    // Notify all observers that depend on this input
    notifyObservers(s as Subject<unknown>)
    return s.value
  }

  return [read, write]
}
