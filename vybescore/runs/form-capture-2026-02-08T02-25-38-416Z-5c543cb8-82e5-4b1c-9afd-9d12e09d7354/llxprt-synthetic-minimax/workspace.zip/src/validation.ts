import { ContactFormData, ValidationErrors } from './types.js';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[+]?[\d\s()-]{7,}$/;
const POSTAL_REGEX = /^[A-Za-z0-9\s-]{3,12}$/;

export function validateFormData(data: ContactFormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!EMAIL_REGEX.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!PHONE_REGEX.test(data.phone.replace(/\s+/g, ' ').trim())) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (must accept alphanumeric like UK "SW1A 1AA")
  if (data.postalCode && !POSTAL_REGEX.test(data.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}