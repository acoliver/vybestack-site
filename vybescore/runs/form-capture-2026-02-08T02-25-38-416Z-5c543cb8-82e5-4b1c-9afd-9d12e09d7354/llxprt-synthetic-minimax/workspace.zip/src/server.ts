import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, closeDatabase, insertSubmission, getAllSubmissions } from './database.js';
import { validateFormData, hasErrors } from './validation.js';
import { ContactFormData } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// View engine setup
app.set('views', path.join(__dirname, '..', 'views'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Simple middleware to add common template variables
app.use((req: Request, res: Response) => {
  res.locals.currentPath = req.path;
  res.locals.siteName = 'International Contact Form';
});

// GET / - Contact form page
app.get('/', (req: Request, res: Response) => {
  res.status(200).render('contact', {
    title: 'Contact Us',
    formData: {},
    errors: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: ContactFormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const errors = validateFormData(formData);

  if (hasErrors(errors)) {
    // Validation failed, re-render form with errors
    res.status(400).render('contact', {
      title: 'Contact Us - Please Fix Errors',
      formData,
      errors
    });
    return;
  }

  try {
    // Validation passed, store in database
    insertSubmission(formData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('contact', {
      title: 'Contact Us - Server Error',
      formData,
      errors: { _global: 'Sorry, there was a server error. Please try again.' }
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.status(200).render('thank-you', {
    title: 'Thank You!'
  });
});

// Debug route to see submissions (optional, can be removed)
app.get('/submissions', (req: Request, res: Response) => {
  try {
    const submissions = getAllSubmissions();
    res.status(200).render('debug', {
      title: 'Submissions (Debug)',
      submissions
    });
  } catch (error) {
    console.error('Debug route error:', error);
    res.status(500).send('Error fetching submissions');
  }
});

// Health check route
app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString() 
  });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).send('Internal Server Error');
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).send('Page Not Found');
});

let server: import('http').Server | null = null;

async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the application`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('\nShutting down server gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  closeDatabase();
  console.log('Database closed');
  
  process.exit(0);
}

// Handle graceful shutdown signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, startServer };
