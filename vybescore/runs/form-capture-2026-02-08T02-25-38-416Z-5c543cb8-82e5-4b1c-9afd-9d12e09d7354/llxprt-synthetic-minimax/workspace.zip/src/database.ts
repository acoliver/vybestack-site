import initSqlJs, { SqlJsStatic, Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

let db: Database | null = null;
let sqlJsModule: SqlJsStatic | null = null;

export async function initializeDatabase(): Promise<void> {
  if (sqlJsModule === null) {
    sqlJsModule = await initSqlJs({
      locateFile: (file: string) => {
        return `node_modules/sql.js/dist/${file}`;
      }
    });
  }

  if (!fs.existsSync(DB_PATH)) {
    // Create empty database file
    fs.writeFileSync(DB_PATH, '');
  }

  const dbBuffer = fs.readFileSync(DB_PATH);
  if (dbBuffer.length === 0) {
    // Initialize with schema
    db = new sqlJsModule.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    if (db) {
      db.exec(schema);
    }
  } else {
    // Load existing database
    if (sqlJsModule) {
      db = new sqlJsModule.Database(dbBuffer);
    }
  }
}

export function getDatabase(): Database | null {
  return db;
}

export function saveDatabase(): void {
  if (db) {
    const binary = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(binary));
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(data: ContactSubmission): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone
  ]);

  stmt.free();
  saveDatabase();
}

export function getAllSubmissions(): ContactSubmission[] {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    SELECT first_name, last_name, street_address, city, 
           state_province, postal_code, country, email, phone
    FROM submissions 
    ORDER BY created_at DESC
  `);

  const results: ContactSubmission[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    results.push({
      firstName: row.first_name as string,
      lastName: row.last_name as string,
      streetAddress: row.street_address as string,
      city: row.city as string,
      stateProvince: row.state_province as string,
      postalCode: row.postal_code as string,
      country: row.country as string,
      email: row.email as string,
      phone: row.phone as string
    });
  }
  stmt.free();

  return results;
}