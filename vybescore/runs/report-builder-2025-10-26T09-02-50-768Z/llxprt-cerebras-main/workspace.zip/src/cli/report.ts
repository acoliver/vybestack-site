import { readFileSync } from 'fs';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const result: {
    dataPath: string;
    format: string;
    outputPath?: string;
    includeTotals: boolean;
  } = {
    dataPath: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      if (!result.dataPath) {
        result.dataPath = arg;
      }
      continue;
    }
    
    switch (arg) {
      case '--format':
        result.format = args[++i];
        break;
      case '--output':
        result.outputPath = args[++i];
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!result.dataPath) {
    throw new Error('Data file path is required');
  }
  
  if (!result.format) {
    throw new Error('Format is required');
  }
  
  return result;
}

function validateData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data format: data must be an object');
  }
  
  const reportData = data as Partial<ReportData>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data format: title must be a string');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data format: summary must be a string');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data format: entries must be an array');
  }
  
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid data format: each entry must be an object');
    }
    
    const reportEntry = entry as Partial<{ label: unknown; amount: unknown }>;
    if (typeof reportEntry.label !== 'string') {
      throw new Error('Invalid data format: each entry must have a string label');
    }
    
    if (typeof reportEntry.amount !== 'number') {
      throw new Error('Invalid data format: each entry must have a numeric amount');
    }
  }
}

function main() {
  try {
    const args = process.argv.slice(2);
    const { dataPath, format, outputPath, includeTotals } = parseArgs(args);
    
    // Read and parse data file
    const dataContent = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(dataContent);
    validateData(data);
    
    // Determine format renderer
    const renderers: Record<string, (data: ReportData, options: { includeTotals?: boolean }) => string> = {
      markdown: renderMarkdown,
      text: renderText,
    };
    
    const renderer = renderers[format];
    if (!renderer) {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    // Render report
    const output = renderer(data, { includeTotals });
    
    // Output result
    if (outputPath) {
      // In a real implementation, we'd write to the file
      // For this exercise, we'll just print to stdout as instructed
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

main();