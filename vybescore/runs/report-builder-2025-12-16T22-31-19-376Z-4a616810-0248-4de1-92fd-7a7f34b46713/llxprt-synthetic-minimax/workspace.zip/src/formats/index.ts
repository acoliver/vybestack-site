import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { Formatter, FormatType } from '../types.js';

export const formatters: Record<FormatType, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};