import { ReportData, RenderOptions, Formatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export const renderText: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    let output = `${data.title}\n\n`;
    output += `${data.summary}\n\n`;
    output += `Entries:\n\n`;

    for (const entry of data.entries) {
      output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
    }

    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `\nTotal: ${formatAmount(total)}\n`;
    }

    return output;
  },
};