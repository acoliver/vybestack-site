import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, FormatType } from '../types.js';
import { formatters } from '../formats/index.js';

function parseArgs(args: string[]): {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || !args[formatIndex + 1]) {
    console.error('Error: --format parameter is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1] as FormatType;
  
  if (!['markdown', 'text'].includes(format)) {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && args[outputIndex + 1] ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title (string)');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary (string)');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (array)');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'label' (string)`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'amount' (number)`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File '${filePath}' not found`);
      } else if (error.message.includes('JSON')) {
        console.error(`Error: Invalid JSON in '${filePath}': ${error.message}`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error(`Error: Failed to load data from '${filePath}'`);
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output to '${outputPath}'`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = process.argv;
  const { dataFile, format, outputPath, includeTotals } = parseArgs(args);
  
  const data = loadReportData(dataFile);
  const formatter = formatters[format];
  
  const result = formatter.render(data, { includeTotals });
  writeOutput(result, outputPath);
}

main();