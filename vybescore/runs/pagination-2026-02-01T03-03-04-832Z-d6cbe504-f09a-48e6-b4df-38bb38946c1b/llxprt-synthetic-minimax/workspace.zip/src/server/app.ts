import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const errors: string[] = [];
    let page: number | undefined;
    let limit: number | undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (Number.isNaN(pageNum) || !Number.isInteger(pageNum) || pageNum < 1) {
        errors.push('page must be a positive integer');
      } else if (pageNum > 10000) {
        errors.push('page value is excessive');
      } else {
        page = pageNum;
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (Number.isNaN(limitNum) || !Number.isInteger(limitNum) || limitNum < 1) {
        errors.push('limit must be a positive integer');
      } else if (limitNum > 100) {
        errors.push('limit value is excessive (maximum 100)');
      } else {
        limit = limitNum;
      }
    }

    // Return validation errors
    if (errors.length > 0) {
      res.status(400).json({ error: errors.join(', ') });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
