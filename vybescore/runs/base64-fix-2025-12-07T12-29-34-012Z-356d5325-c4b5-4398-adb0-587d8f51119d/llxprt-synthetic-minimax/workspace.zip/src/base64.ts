/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with proper validation.
 */
export function decode(input: string): string {
  // Remove whitespace and normalize
  const normalized = input.replace(/\s+/g, '').trim();
  
  if (!normalized) {
    throw new Error('Empty Base64 input');
  }

  // Validate Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Add padding if missing (Base64 strings should be divisible by 4)
  const padding = normalized.length % 4;
  
  let paddedInput = normalized;
  if (padding === 2) {
    paddedInput += '==';
  } else if (padding === 3) {
    paddedInput += '=';
  } else if (padding !== 0) {
    throw new Error('Invalid Base64 input: length not compatible with Base64 encoding');
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid characters or corrupted data');
  }
}
