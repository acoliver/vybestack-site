#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { parseReportData } from '../utils/json-parser.js';
import { ReportData, RenderOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

interface ParsedArgs {
  dataPath?: string;
  format?: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): CliArgs {
  const args: ParsedArgs = {
    includeTotals: false
  };
  
  // Parse command line arguments
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      args.format = argv[i + 1];
      i++; // Skip next argument as it's the value
    } else if (arg === '--output') {
      args.outputPath = argv[i + 1];
      i++; // Skip next argument as it's the value
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Positional argument - data file path
      args.dataPath = arg;
    }
  }
  
  // Validate required arguments
  if (!args.dataPath) {
    throw new Error('Missing required argument: <data.json>');
  }
  
  if (!args.format) {
    throw new Error('Missing required argument: --format <format>');
  }
  
  // Validate format
  if (args.format !== 'markdown' && args.format !== 'text') {
    throw new Error(`Unsupported format: ${args.format}`);
  }
  
  return {
    dataPath: args.dataPath,
    format: args.format,
    outputPath: args.outputPath,
    includeTotals: args.includeTotals
  };
}

function render(data: ReportData, format: string, options: RenderOptions): string {
  const formatters = {
    markdown: renderMarkdown,
    text: renderText
  };
  
  const formatter = formatters[format as keyof typeof formatters];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  return formatter.render(data, options);
}

function main() {
  try {
    // Parse command line arguments
    const cliArgs = parseArgs(process.argv);
    
    // Parse and validate JSON data
    const reportData = parseReportData(cliArgs.dataPath);
    
    // Render the report
    const renderOptions: RenderOptions = {
      includeTotals: cliArgs.includeTotals
    };
    
    const output = render(reportData, cliArgs.format, renderOptions);
    
    // Write output
    if (cliArgs.outputPath) {
      writeFileSync(cliArgs.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
