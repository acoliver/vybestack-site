import { readFileSync } from 'fs';
import { ReportData } from '../types/report.js';

interface RawReportEntry {
  label: string;
  amount: number;
}

interface RawReportData {
  title: string;
  summary: string;
  entries: RawReportEntry[];
}

export function parseReportData(jsonPath: string): ReportData {
  try {
    const content = readFileSync(jsonPath, 'utf-8');
    const raw = JSON.parse(content) as RawReportData;
    
    // Validate required fields
    if (!raw.title || typeof raw.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    
    if (!raw.summary || typeof raw.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    
    if (!raw.entries || !Array.isArray(raw.entries)) {
      throw new Error('Missing or invalid required field: entries');
    }
    
    // Validate entries
    for (let i = 0; i < raw.entries.length; i++) {
      const entry = raw.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: missing or invalid required field: label`);
      }
      
      if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
        throw new Error(`Entry ${i + 1}: missing or invalid required field: amount`);
      }
    }
    
    // Convert to typed data structure
    const reportData: ReportData = {
      title: raw.title,
      summary: raw.summary,
      entries: raw.entries.map(entry => ({
        label: entry.label,
        amount: entry.amount
      }))
    };
    
    return reportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    
    if (error instanceof Error && ('code' in error) && (error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${jsonPath}`);
    }
    
    throw error;
  }
}