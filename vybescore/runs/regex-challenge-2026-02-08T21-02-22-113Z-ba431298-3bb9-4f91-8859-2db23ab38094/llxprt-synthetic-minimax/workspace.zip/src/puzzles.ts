/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Match whole words starting with prefix using literal string matching
  const prefixLower = prefix.toLowerCase();
  const words = text.split(/\b/);
  const matches: string[] = [];
  
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    if (word.toLowerCase().startsWith(prefixLower) && /^[a-zA-Z]+$/.test(word)) {
      // Filter out exceptions (case-insensitive)
      if (!exceptions.some(exception => 
        exception.toLowerCase() === word.toLowerCase()
      )) {
        matches.push(word);
      }
    }
  }
  
  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Find complete words that start with a digit followed by the token
  // Pattern: digit + token (complete word)
  const embedRegex = new RegExp(`\\b\\d${token}\\b`, 'gi');
  
  const matches = text.match(embedRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>\\/]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // This pattern looks for any 2-character sequence that repeats immediately
  const hasRepeatingSequence = /([a-zA-Z0-9])\1/.test(value);
  
  if (hasRepeatingSequence) {
    return false;
  }
  
  // Also check for more complex patterns like "abab" (alternating)
  // Look for any 2-character pattern that appears with the same characters in same order
  const alternatingPattern = /([a-zA-Z0-9]{2})\1/.test(value);
  
  if (alternatingPattern) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, check if this looks like an IPv4 address
  // IPv4 pattern: x.x.x.x where x is 0-255
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it matches IPv4 pattern exactly, it's not IPv6
  if (ipv4Pattern.test(value) && value.match(/^(?:\d{1,3}\.){3}\d{1,3}$/)) {
    // Check if it's actually a valid IPv4 address (all octets 0-255)
    const parts = value.split('.');
    const isValidIPv4 = parts.length === 4 && parts.every(part => {
      const num = parseInt(part, 10);
      return !isNaN(num) && num >= 0 && num <= 255;
    });
    
    if (isValidIPv4) {
      return false;
    }
  }
  
  // IPv6 address pattern including shorthand ::
  // IPv6 consists of 8 groups of 4 hexadecimal digits, separated by colons
  // Groups can be separated by :: (zero compression)
  // Pattern: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // With shorthand: xxxx:xxxx::xxxx or ::xxxx
  
  // More comprehensive IPv6 regex that handles various cases
  const comprehensiveIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b|\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b|\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b|\b[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}\b|\b::[0-9a-fA-F]{1,4}\b/i;
  
  return comprehensiveIPv6.test(value);
}
