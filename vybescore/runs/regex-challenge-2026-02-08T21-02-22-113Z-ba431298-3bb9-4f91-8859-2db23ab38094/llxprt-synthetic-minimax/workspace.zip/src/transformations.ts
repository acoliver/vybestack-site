/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split by sentence endings, but preserve the endings
  const sentences = text.split(/([.?!]+)/);
  
  let result = '';
  let shouldCapitalize = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (/^[.?!]+$/.test(sentence)) {
      // This is a sentence ending, add it and mark next sentence for capitalization
      result += sentence;
      shouldCapitalize = true;
      
      // Ensure exactly one space after sentence endings (except if end of text)
      if (i + 1 < sentences.length && sentences[i + 1].length > 0) {
        // Remove any existing spaces and add exactly one
        result = result.replace(/[ ]*$/, ' ');
      }
    } else if (sentence.length > 0) {
      // This is text content
      let textPart = sentence;
      
      // Remove leading spaces for this sentence
      textPart = textPart.replace(/^[ ]+/, '');
      
      if (shouldCapitalize) {
        // Capitalize first letter
        textPart = textPart.replace(/^[a-zà-ÿ]/, (match) => match.toUpperCase());
        shouldCapitalize = false;
      }
      
      // Collapse multiple spaces to single space
      textPart = textPart.replace(/[ ]{2,}/g, ' ');
      
      result += textPart;
    }
  }
  
  // Clean up multiple spaces around sentence boundaries
  result = result.replace(/[ ]+([.?!]+)/g, '$1 ');
  result = result.replace(/([.?!]+)[ ]+$/g, '$1');
  result = result.replace(/[ ]{2,}/g, ' ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'()]+[^\s.,!?)<>"']/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) return [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;)]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://
  // Use word boundaries to avoid replacing http within other words
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs
  const httpUrlRegex = /\bhttp:\/\/[^\s<>"']+/gi;
  
  return text.replace(httpUrlRegex, (match) => {
    // Always upgrade scheme to https://
    let processedUrl = match.replace(/^http:\/\//i, 'https://');
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /[?&=]/.test(processedUrl) || /cgi-bin/.test(processedUrl);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?&#]|$)/i.test(processedUrl);
    
    // Only rewrite host for /docs/ paths without dynamic hints or legacy extensions
    if (/\/docs\/[^?&#]*/i.test(processedUrl) && !hasDynamicHints && !hasLegacyExtensions) {
      // Replace host with docs.host (keeping rest of URL)
      processedUrl = processedUrl.replace(
        /\/\/([^/]+)(\/docs\/.*)/i,
        '//docs.example.com$2'
      );
    }
    
    return processedUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, accounting for month lengths)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
      // Leap year
      if (day > 29) return 'N/A';
    } else {
      // Not leap year
      if (day > 28) return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Validate day range
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
