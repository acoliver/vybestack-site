export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with restrictions
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Check basic format and restrictions
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Ensure domain has at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Note: options parameter intentionally unused for now
  void options; // Suppress unused parameter warning
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must be at least 10 digits
  if (cleaned.length < 10) {
    return false;
  }
  
  // Optional +1 prefix
  const phoneRegex = /^\+?1?[\s-]?(\([2-9][0-8][0-9]\)|[2-9][0-8][0-9])[\s-]?[2-9][0-9]{2}[\s-]?[0-9]{4}$/;
  
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract area code to validate
  const areaCodeMatch = cleaned.match(/^\+?1?[\s-]?(?:\(([2-9][0-8][0-9])\)|([2-9][0-8][0-9]))/);
  
  if (areaCodeMatch) {
    const areaCode = areaCodeMatch[1] || areaCodeMatch[2];
    
    // Area codes must not start with 0 or 1
    if (!areaCode || areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
  } else {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and punctuation, keep only digits and +
  const cleaned = value.replace(/[\s-()]/g, '');
  
  // Pattern explanation:
  // ^\+?54?  - Optional country code +54
  // 9?       - Optional mobile indicator 9
  // 0?       - Optional trunk prefix 0
  // ([1-9][0-9]{1,3})  - Area code: 2-4 digits, first digit 1-9
  // ([0-9]{6,8})       - Subscriber number: 6-8 digits total
  
  const argentinePhoneRegex = /^\+?54?9?0?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract parts for validation
  const match = cleaned.match(/^\+?54?9?0?([1-9][0-9]{1,3})([0-9]{6,8})$/);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate total digits (area code + subscriber number)
  const totalDigits = areaCode.length + subscriberNumber.length;
  
  // Total must be 8-12 digits (area + subscriber)
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }
  
  // When country code is omitted, must begin with trunk prefix 0
  if (!value.trim().startsWith('+54') && !value.trim().startsWith('54')) {
    // Check if it starts with 0 (trunk prefix)
    if (!cleaned.startsWith('0') && !value.trim().match(/^[\s]*0/)) {
      return false;
    }
  }
  
  // Area code validation (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode[0] === '0') {
    return false; // Area code can't start with 0
  }
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject digits, symbols, and unusual names like "X Æ A-12"
  
  // Check for digits - names should not contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for unusual symbols (beyond allowed characters)
  // Allowed: letters (including accents), apostrophes, hyphens, spaces
  if (/[^A-Za-zÀ-ÿ\s'-]/.test(value)) {
    return false;
  }
  
  // Reject unusual combinations like "X Æ A-12" style names
  if (/[^\w\s'-]/.test(value)) {
    return false;
  }
  
  // Check for reasonable name patterns
  // Should not be all symbols or unusual characters
  const cleanName = value.replace(/[\s'-]/g, '');
  
  // Must contain at least some letters
  if (!/[A-Za-zÀ-ÿ]/.test(cleanName)) {
    return false;
  }
  
  // Must not be empty or just symbols/space
  if (value.trim().length === 0) {
    return false;
  }
  
  // Basic name length validation
  if (value.length > 100) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length === 0) {
    return false;
  }
  
  // Check card types and lengths
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19 digits
  if (/^4/.test(cleaned)) {
    isValidType = cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16 digits
  else if (/^(5[1-5]|2[2-7][0-9])/.test(cleaned)) {
    isValidType = cleaned.length === 16;
  }
  // AmEx: starts with 34 or 37, length 15 digits
  else if (/^3[47]/.test(cleaned)) {
    isValidType = cleaned.length === 15;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Luhn algorithm check
  return luhnCheck(cleaned);
}

// Luhn checksum algorithm
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
