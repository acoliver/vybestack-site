import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
let db: Database;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const schemaPath = path.join(__dirname, '../db/schema.sql');

async function initializeDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const SQL = await initSqlJs();
    
    let data: Uint8Array = new Uint8Array(0);
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    }
    
    db = new SQL.Database(data);
    
    // Create schema if needed
    if (!fs.existsSync(dbPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase() {
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// Validation functions
function validateRequired(value: string, fieldName: string): string | null {
  return value.trim() === '' ? `${fieldName} is required` : null;
}

function validateEmail(email: string): string | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
}

function validatePhone(phone: string): string | null {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone) || phone.trim() === '') {
    return 'Please enter a valid phone number';
  }
  return null;
}

function validatePostalCode(postalCode: string): string | null {
  // Allow alphanumeric postal codes like UK "SW1A 1AA" or Argentine "C1000"
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (!postalCodeRegex.test(postalCode) || postalCode.trim() === '') {
    return 'Please enter a valid postal code';
  }
  return null;
}

function validateFormData(formData: FormData): ValidationResult {
  const errors: string[] = [];
  
  // Validate all required fields
  let error = validateRequired(formData.firstName, 'First name');
  if (error) errors.push(error);
  
  error = validateRequired(formData.lastName, 'Last name');
  if (error) errors.push(error);
  
  error = validateRequired(formData.streetAddress, 'Street address');
  if (error) errors.push(error);
  
  error = validateRequired(formData.city, 'City');
  if (error) errors.push(error);
  
  error = validateRequired(formData.stateProvince, 'State/Province/Region');
  if (error) errors.push(error);
  
  error = validatePostalCode(formData.postalCode);
  if (error) errors.push(error);
  
  error = validateRequired(formData.country, 'Country');
  if (error) errors.push(error);
  
  error = validateEmail(formData.email);
  if (error) errors.push(error);
  
  error = validatePhone(formData.phone);
  if (error) errors.push(error);
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', {
    title: 'Friendly Contact Form',
    errors: [],
    values: {}
  });
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you', {
    title: 'Thank You!',
    firstName: req.query.firstName || 'Friend'
  });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      title: 'Friendly Contact Form',
      errors: validation.errors,
      values: formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      title: 'Friendly Contact Form',
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    
    const server = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
    
    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('Received SIGTERM, shutting down gracefully');
      server.close(() => {
        if (db) db.close();
        console.log('Server closed');
        process.exit(0);
      });
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
