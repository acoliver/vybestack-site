import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions, Formatter } from '../types.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';

interface ParsedArgs extends CLIOptions {
  dataFile: string;
}

function parseArguments(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 1) {
    throw new Error('Missing required argument: <data.json>');
  }
  
  const dataFile = args[0];
  
  if (!dataFile.endsWith('.json')) {
    throw new Error('Data file must be a JSON file');
  }
  
  // Parse named arguments
  let format: string | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!format) {
    throw new Error('Missing required argument: --format');
  }
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error('Unsupported format');
  }
  
  return {
    dataFile,
    format: format as 'markdown' | 'text',
    output,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid field: title');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid field: summary');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid field: entries');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON syntax');
    }
    if (error instanceof Error && error.message.startsWith('ENOENT:')) {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function getFormatter(format: 'markdown' | 'text'): Formatter {
  switch (format) {
    case 'markdown':
      return new MarkdownFormatter();
    case 'text':
      return new TextFormatter();
    default:
      throw new Error('Unsupported format');
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    const data = loadReportData(options.dataFile);
    const formatter = getFormatter(options.format);
    
    const output = formatter.render(data, options.includeTotals);
    
    if (options.output) {
      writeFileSync(options.output, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
