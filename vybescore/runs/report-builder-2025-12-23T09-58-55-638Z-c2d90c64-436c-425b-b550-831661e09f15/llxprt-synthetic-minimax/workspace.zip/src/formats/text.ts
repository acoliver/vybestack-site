import { Formatter, ReportData } from '../types.js';

export class TextFormatter implements Formatter {
  render(data: ReportData, includeTotals: boolean): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Entry list
    for (const entry of data.entries) {
      const amount = this.formatAmount(entry.amount);
      lines.push(`- ${entry.label}: ${amount}`);
    }
    
    // Total (if requested)
    if (includeTotals) {
      const total = this.calculateTotal(data.entries);
      const totalFormatted = this.formatAmount(total);
      lines.push(`Total: ${totalFormatted}`);
    }
    
    return lines.join('\n');
  }
  
  private formatAmount(amount: number): string {
    return `$${amount.toFixed(2)}`;
  }
  
  private calculateTotal(entries: Array<{ amount: number }>): number {
    return entries.reduce((sum, entry) => sum + entry.amount, 0);
  }
}