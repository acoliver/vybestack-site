/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

import { observerToDependencies, addObserverDependency, removeObserverDependencies, subjectToObservers } from './dependencyRegistry.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register this callback globally for cascade updates
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const trackedSubjects = new Set<any>()
  
  const wrappedUpdateFn = () => {
    try {
      return updateFn()
    } finally {
      // After execution, track new dependencies
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const currentDependencies = new Set<any>()
      for (const [, dependencies] of observerToDependencies!.entries()) {
        for (const dep of dependencies) {
          if (dep && subjectToObservers!.has(dep)) {
            currentDependencies.add(dep)
          }
        }
      }
      
      // Add this callback as observer to new dependencies
      for (const subject of currentDependencies) {
        if (!trackedSubjects.has(subject)) {
          addObserverDependency(observer, subject)
          trackedSubjects.add(subject)
        }
      }
    }
  }
  
  observer.updateFn = wrappedUpdateFn
  
  // Execute initial update
  updateObserver(observer)
  
  // The dependencies are tracked during updateObserver execution in reactive.ts
  
  // Callbacks track their dependencies separately by executing their updateFn
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value as T
    
    // Clear the observer's reference back to subjects
    // Note: The observer property is dynamically managed in dependency tracking
    
    // Remove from dependency map to prevent further updates
    removeObserverDependencies(observer)
  }
}
