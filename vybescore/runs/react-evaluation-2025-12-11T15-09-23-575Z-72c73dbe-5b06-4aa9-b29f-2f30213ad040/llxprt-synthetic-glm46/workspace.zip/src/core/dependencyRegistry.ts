/**
 * Central registry for tracking reactive dependencies and cascade updates
 */

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { Observer } from '../types/reactive.js'
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { Subject } from '../types/reactive.js'

// Global registry for tracking reactive relationships
// Maps observers to their dependencies (subjects they depend on)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const observerToDependencies = new Map<any, Set<any>>()
// Maps subjects to their observers (who depends on them)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const subjectToObservers = new Map<any, Set<any>>()

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function addObserverDependency(observer: any, subject: any): void {
  // Track observer -> dependencies
  if (!observerToDependencies.has(observer)) {
    observerToDependencies.set(observer, new Set())
  }
  observerToDependencies.get(observer)!.add(subject)
  
  // Track subject -> observers (reverse mapping)
  if (!subjectToObservers.has(subject)) {
    subjectToObservers.set(subject, new Set())
  }
  subjectToObservers.get(subject)!.add(observer)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function removeObserverDependencies(observer: any): void {
  // Remove from both mappings
  const dependencies = observerToDependencies.get(observer)
  if (dependencies) {
    for (const subject of dependencies) {
      const observers = subjectToObservers.get(subject)
      if (observers) {
        observers.delete(observer)
        if (observers.size === 0) {
          subjectToObservers.delete(subject)
        }
      }
    }
  }
  observerToDependencies.delete(observer)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function cascadeUpdate(subject: any): void {
  const observers = subjectToObservers.get(subject)
  if (!observers) return
  
  // Create a copy to avoid modification during iteration
  const observersToUpdate = Array.from(observers)
  
  for (const observer of observersToUpdate) {
    try {
      if (observer.updateFn) {
        observer.value = observer.updateFn(observer.value)
      }
    } catch (e) {
      // Prevent cascade errors from breaking the system
    }
  }
}