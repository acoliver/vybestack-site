/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

import { addObserverDependency } from './dependencyRegistry.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    _equal === true ? Object.is : 
    _equal === false || _equal === undefined ? undefined : 
    _equal

  // TODO: Implement equality checking for computed values optimization
  void equalFn // Mark as used to avoid linting error

const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Don't initialize here - let the first access determine the value
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Set this computed as dependency of the active observer
      addObserverDependency(observer, o)
    }
    
    // Re-compute when accessed to get fresh value
    updateObserver(o)
    return o.value as T
  }
  
  // Initialize the value with the update function
  updateObserver(o)
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Set this computed as dependency of the active observer
      addObserverDependency(observer, o)
    }
    
    // Re-compute when accessed to get fresh value
    updateObserver(o)
    return o.value as T
  }
  
  const compute = () => {
    // Re-compute when accessed to get fresh value
    updateObserver(o)
    return o.value as T
  }
  
  // Initialize the value
  compute()
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Set this computed as dependency of the active observer
      addObserverDependency(observer, o)
    }
    
    // Re-compute when accessed to get fresh value
    return compute()
  }
}
