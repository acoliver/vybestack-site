/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

import { addObserverDependency, cascadeUpdate } from './dependencyRegistry.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    _equal === true ? Object.is : 
    _equal === false || _equal === undefined ? undefined : 
    _equal

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // Track this dependency using centralized registry
      addObserverDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value // No change, return current value
    }
    
    s.value = nextValue
    
    // Cascade updates to all observers that depend on this input
    cascadeUpdate(s)
    
    return s.value
  }

  return [read, write]
}
