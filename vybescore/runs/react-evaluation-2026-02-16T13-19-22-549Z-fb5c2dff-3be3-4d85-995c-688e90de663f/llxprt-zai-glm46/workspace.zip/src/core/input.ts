/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function notifyObservers(observers: unknown[]): void {
  observers.forEach((obs) => {
    updateObserver(obs as Observer<unknown>)
    // If this observer has its own observers, notify them too
    const observer = obs as Observer<unknown>
    if (observer.observers && observer.observers.length > 0) {
      notifyObservers(observer.observers)
    }
  })
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add observer if not already tracking
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers (including nested computed observers)
    notifyObservers(s.observers)
    return s.value
  }

  return [read, write]
}
