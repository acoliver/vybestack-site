import { createInput, createComputed } from './src/index.ts'

console.log('=== Debug: observer identity ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)

console.log('timesTwo getter:', typeof timesTwo)
console.log('timesTwo._observer:', (timesTwo as any)._observer)

const sum = createComputed(() => {
  console.log('  Inside sum updateFn:')
  console.log('    timesTwo:', typeof timesTwo)
  console.log('    timesTwo._observer:', (timesTwo as any)._observer)
  console.log('    Calling timesTwo()...')
  const result = timesTwo()
  console.log('    Result:', result)
  return result + timesThirty()
})

console.log('\nInitial sum:', sum())

setInput(3)
console.log('\nAfter setInput(3), sum:', sum())
