import { createInput, createComputed } from './src/index.ts'

console.log('=== Debugging sum dependencies ===')
const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('  Computing sum:')
  console.log('    timesTwo() =', timesTwo())
  console.log('    timesThirty() =', timesThirty())
  const result = timesTwo() + timesThirty()
  console.log('    sum =', result)
  return result
})

console.log('\n=== Initial ===')
console.log('sum() =', sum())

console.log('\n=== Checking subjects on sum observer ===')
// @ts-ignore
console.log('sum has subjects?', sum.observer?.subjects)
// @ts-ignore
console.log('Number of subjects?', sum.observer?.subjects?.size)

console.log('\n=== After setInput(3) ===')
setInput(3)
console.log('sum() =', sum())
