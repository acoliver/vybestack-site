import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Debugging dependency tracking ===')
const [input, setInput] = createInput(1)

console.log('\nCreating timesTwo computed...')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})

console.log('Creating timesThirty computed...')
const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})

console.log('\nCreating sum computed...')
const sum = createComputed(() => {
  console.log('  Computing sum, timesTwo =', timesTwo(), ', timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('\n=== Initial values ===')
console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())

console.log('\n=== After setInput(3) ===')
setInput(3)
console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
