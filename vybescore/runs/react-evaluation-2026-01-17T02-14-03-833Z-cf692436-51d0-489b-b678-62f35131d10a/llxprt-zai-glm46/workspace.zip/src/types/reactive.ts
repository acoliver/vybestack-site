/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<ObserverR>  // Who this observer depends on
  dependents?: Set<ObserverR>    // Who depends on this observer
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

const globalActiveObserver = Symbol('activeObserver')

export function getActiveObserver(): ObserverR | undefined {
  return (globalThis as Record<symbol, ObserverR | undefined>)[globalActiveObserver]
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  (globalThis as Record<symbol, ObserverR | undefined>)[globalActiveObserver] = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = (globalThis as Record<symbol, ObserverR | undefined>)[globalActiveObserver]
  ;(globalThis as Record<symbol, ObserverR | undefined>)[globalActiveObserver] = observer

  // Initialize tracking sets if not present
  if (!observer.dependencies) {
    observer.dependencies = new Set<ObserverR>()
  }
  if (!observer.dependents) {
    observer.dependents = new Set<ObserverR>()
  }

  // Clear old dependencies and remove this observer from their dependents sets
  for (const dep of observer.dependencies) {
    if (dep.dependents) {
      dep.dependents.delete(observer)
    }
  }
  observer.dependencies.clear()

  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    ;(globalThis as Record<symbol, ObserverR | undefined>)[globalActiveObserver] = previous
  }
}
