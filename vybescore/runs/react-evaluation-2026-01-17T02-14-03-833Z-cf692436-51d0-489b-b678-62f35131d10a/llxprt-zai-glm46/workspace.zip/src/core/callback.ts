/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, ObserverR, updateObserver } from '../types/reactive.js'

const globalActiveObserver = Symbol.for('activeObserver')

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set<ObserverR>(),
    dependents: new Set<ObserverR>(),
  }

  let disposed = false

  // Initialize the callback by running updateFn once to track dependencies
  updateObserver(observer)

  return () => {
    if (disposed) return
    disposed = true
    ;(observer as { disposed?: boolean }).disposed = true
    // Clean up: remove this observer from all dependencies
    for (const dep of observer.dependencies) {
      if (dep.dependents) {
        dep.dependents.delete(observer)
      }
    }
  }
}
