/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  ObserverR,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

const globalActiveObserver = Symbol.for('activeObserver')

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set<ObserverR>(),
    dependents: new Set<ObserverR>(),
  }

  // Create the getter function - this tracks dependencies when accessed
  function getter(): T {
    // When this computed is accessed by another observer, track the dependency
    const active = (globalThis as Record<symbol, ObserverR | undefined>)[globalActiveObserver] as ObserverR | undefined
    if (active) {
      if (!active.dependencies) {
        active.dependencies = new Set<ObserverR>()
      }
      // Active observer depends on this computed
      active.dependencies.add(o)
      // This computed is tracked by the active observer
      if (!o.dependents) {
        o.dependents = new Set<ObserverR>()
      }
      o.dependents.add(active)
    }
    return o.value!
  }

  // Attach observer to getter for internal access
  ;(getter as any)._observer = o

  // Initialize the computed value by evaluating the update function
  updateObserver(o)

  return getter as GetterFn<T>
}
