import { createInput, createComputed } from './src/index.ts'
import { getActiveObserver } from './src/types/reactive.ts'

console.log('=== Debug: detailed tracking of when dependencies are added ===')

const [input, setInput] = createInput(1)

let timesTwoObs: any
let timesThirtyObs: any
let sumObs: any

const timesTwo = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [timesTwo updateFn] activeObserver:', active ? 'YES' : 'NO', 'name:', active?.name)
  return input() * 2
})
timesTwoObs = (timesTwo as any)._observer

const timesThirty = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [timesThirty updateFn] activeObserver:', active ? 'YES' : 'NO', 'name:', active?.name)
  return input() * 30
})
timesThirtyObs = (timesThirty as any)._observer

console.log('\n=== Creating sum ===')
const sum = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [sum updateFn] START, activeObserver:', active ? 'YES' : 'NO', 'name:', active?.name)

  console.log('    BEFORE timesTwo(): sum.dependencies.size =', sumObs?.dependencies?.size)
  console.log('    BEFORE timesTwo(): timesTwo.dependents.size =', timesTwoObs?.dependents?.size)

  const t2 = timesTwo()

  console.log('    AFTER timesTwo(): sum.dependencies.size =', sumObs?.dependencies?.size)
  console.log('    AFTER timesTwo(): timesTwo.dependents.size =', timesTwoObs?.dependents?.size)

  console.log('    BEFORE timesThirty(): timesThirty.dependents.size =', timesThirtyObs?.dependents?.size)

  const t30 = timesThirty()

  console.log('    AFTER timesThirty(): sum.dependencies.size =', sumObs?.dependencies?.size)
  console.log('    AFTER timesThirty(): timesTwo.dependents.size =', timesTwoObs?.dependents?.size)
  console.log('    AFTER timesThirty(): timesThirty.dependents.size =', timesThirtyObs?.dependents?.size)

  return t2 + t30
})
sumObs = (sum as any)._observer

console.log('\n=== Initial state ===')
console.log('  sum:', sum())
console.log('  sum.dependencies.size:', sumObs.dependencies.size)
console.log('  timesTwo.dependents.size:', timesTwoObs.dependents.size)
console.log('  timesThirty.dependents.size:', timesThirtyObs.dependents.size)
