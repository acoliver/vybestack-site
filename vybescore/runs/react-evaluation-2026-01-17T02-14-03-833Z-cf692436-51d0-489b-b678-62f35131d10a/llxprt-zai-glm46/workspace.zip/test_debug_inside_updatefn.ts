import { createInput, createComputed } from './src/index.ts'
import { getActiveObserver } from './src/types/reactive.ts'

console.log('=== Debug: active observer INSIDE updateFn vs getter ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [timesTwo updateFn] activeObserver:', active ? 'YES' : 'NO', 'name:', active?.name)
  return input() * 2
})

const timesThirty = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [timesThirty updateFn] activeObserver:', active ? 'YES' : 'NO', 'name:', active?.name)
  return input() * 30
})

const sum = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [sum updateFn] activeObserver:', active ? 'YES' : 'NO', 'name:', active?.name)

  console.log('    About to call timesTwo() getter...')
  const t2 = timesTwo()

  console.log('    About to call timesThirty() getter...')
  const t30 = timesThirty()

  return t2 + t30
})

console.log('\n=== createComputed calls updateObserver, which calls updateFn ===')
console.log('Result:', sum())

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After setInput(3), call sum() again ===')
console.log('Result:', sum())
