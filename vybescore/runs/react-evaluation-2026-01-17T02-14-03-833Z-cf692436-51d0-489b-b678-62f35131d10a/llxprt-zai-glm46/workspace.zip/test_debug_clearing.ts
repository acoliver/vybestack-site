import { createInput, createComputed } from './src/index.ts'

console.log('=== Debug: checking dependency clearing ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  const val = input() * 2
  console.log('  [timesTwo updateFn] input =', input(), ', result =', val)
  return val
})

const timesThirty = createComputed(() => {
  const val = input() * 30
  console.log('  [timesThirty updateFn] input =', input(), ', result =', val)
  return val
})

// Create sum - should track dependencies on timesTwo and timesThirty
const sum = createComputed(() => {
  console.log('  [sum updateFn] called, accessing timesTwo and timesThirty')
  const t2 = timesTwo()
  const t30 = timesThirty()
  console.log('    timesTwo() =', t2, ', timesThirty() =', t30)
  return t2 + t30
})

console.log('\n=== Initial state ===')
console.log('  sum:', sum())

console.log('\n=== Setting input to 3 ===')
console.log('This should update timesTwo and timesThirty, then sum should be updated too')
setInput(3)

console.log('\n=== After setInput(3) ===')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())

console.log('\n=== Setting input to 5 ===')
setInput(5)

console.log('\n=== After setInput(5) ===')
console.log('  sum:', sum())
