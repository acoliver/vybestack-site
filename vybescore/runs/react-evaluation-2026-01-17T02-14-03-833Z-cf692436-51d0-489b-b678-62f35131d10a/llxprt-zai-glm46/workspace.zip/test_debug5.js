import { createInput, createComputed } from './src/index.ts'

console.log('=== Store observer references ===')
const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})

// Store the observer for timesTwo
const getter = timesTwo as any
// The observer is stored in the closure scope

const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('  Computing sum:')
  const tt = timesTwo()
  const ttt = timesThirty()
  console.log('    timesTwo() =', tt, ', timesThirty() =', ttt)
  return tt + ttt
})

console.log('\n=== Initial ===')
console.log('sum() =', sum())

console.log('\n=== Manually trigger input update ===')
setInput(3)
console.log('sum() =', sum())
