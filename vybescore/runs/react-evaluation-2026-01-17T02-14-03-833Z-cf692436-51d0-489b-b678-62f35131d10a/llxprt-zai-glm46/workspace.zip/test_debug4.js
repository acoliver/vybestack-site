import { createInput, createComputed } from './src/index.ts'

console.log('=== Debugging: Store observer references ===')
const [input, setInput] = createInput(1)

// Store references to the observers
let timesTwoObserver: any = null
let timesThirtyObserver: any = null
let sumObserver: any = null

const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  const result = input() * 2
  // @ts-ignore
  if (!timesTwoObserver) timesTwoObserver = window.__debug_timesTwo
  return result
})

const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  const result = input() * 30
  // @ts-ignore
  if (!timesThirtyObserver) timesThirtyObserver = window.__debug_timesThirty
  return result
})

const sum = createComputed(() => {
  console.log('  Computing sum:')
  const tt = timesTwo()
  const ttt = timesThirty()
  console.log('    timesTwo() =', tt, ', timesThirty() =', ttt)
  const result = tt + ttt
  console.log('    sum =', result)
  // @ts-ignore
  if (!sumObserver) sumObserver = window.__debug_sum
  return result
})

// Monkey-patch to expose observers
// @ts-ignore
;(globalThis as any).__observers = { timesTwo, timesThirty, sum }

console.log('\n=== Initial ===')
console.log('sum() =', sum())
console.log('Observers:', Object.keys((globalThis as any).__observers || {}))

console.log('\n=== Checking observer properties ===')
const obs = (globalThis as any).__observers
if (obs) {
  for (const [name, fn] of Object.entries(obs)) {
    console.log(`\n${name}:`)
    console.log('  type:', typeof fn)
    console.log('  has observer?', (fn as any).observer)
    console.log('  has subjects?', (fn as any).observer?.subjects)
    console.log('  subjects size:', (fn as any).observer?.subjects?.size)
  }
}

console.log('\n=== After setInput(3) ===')
setInput(3)
console.log('sum() =', sum())
