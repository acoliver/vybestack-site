# Current State Analysis

The reactive system is partially working:
- Input creates subjects correctly
- Computed creates observers that track dependencies during initialization
- The `subjects` Set on observers stores which other observers they depend on

## The Problem

When updating:
1. `setInput(3)` triggers `updateObserverRecursive` for timesTwo and timesThirty
2. Both get updated correctly (6 and 90)
3. BUT: The sum observer has 0 subjects when it should have 2

Looking at the initialization:
- sum correctly tracks timesTwo and timesThirty in its subjects Set (size: 2)
- But when timesTwo/timesThirty are updated, they report 0 subjects

## The Issue

The problem is that we're clearing `observer.subjects` at the start of each update:
```typescript
if (observer.subjects) {
  observer.subjects.clear()
}
```

This clears the WRONG Set. `observer.subjects` should contain:
- For timesTwo/timesThirty: The observers that depend on them (like sum)
- For sum: The observers it depends on (timesTwo, timesThirty)

But we're clearing it, so sum loses track of timesTwo/timesThirty after the first update.

## The Solution

We need TWO separate tracking mechanisms:
1. `dependencies` - who this observer depends on (inputs and other computeds)
2. `dependents` - who depends on this observer (reverse mapping)

Currently we only have one Set (`subjects`) and we're using it for both purposes, which doesn't work.

Let me refactor to use both tracking directions.
