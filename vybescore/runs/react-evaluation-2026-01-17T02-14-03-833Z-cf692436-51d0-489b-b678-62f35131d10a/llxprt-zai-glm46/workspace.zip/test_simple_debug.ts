import { createInput, createComputed } from './src/index.ts'

console.log('=== Testing simple computed ===')

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => input() * 2)
console.log('Initial timesTwo:', timesTwo())

const timesThirty = createComputed(() => input() * 30)
console.log('Initial timesThirty:', timesThirty())

const sum = createComputed(() => timesTwo() + timesThirty())
console.log('Initial sum:', sum())

setInput(3)
console.log('After setInput(3):')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
