import { createInput, createComputed } from './src/index.ts'

console.log('=== Debugging dependencies ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)

// Access sum to trigger dependency tracking
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial state:')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())

// Now let's inspect what sum's dependencies are
// We need to access this through internal structure
console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\nAfter setInput(3):')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())

// Try forcing re-computation of sum by calling it
console.log('\n=== Calling sum() again to see if it updates ===')
const sumResult = sum()
console.log('  sum:', sumResult)
