import { createInput, createComputed } from './src/index.ts'

console.log('=== Detailed debugging of dependencies ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)

console.log('\nBefore accessing sum:')
console.log('  timesTwo value:', timesTwo())
console.log('  timesThirty value:', timesThirty())

// Now create sum - this should track dependencies on timesTwo and timesThirty
const sum = createComputed(() => {
  console.log('  [sum updateFn] called')
  const t2 = timesTwo()
  const t30 = timesThirty()
  console.log('    timesTwo() =', t2, ', timesThirty() =', t30)
  return t2 + t30
})

console.log('\nAfter creating sum:')
console.log('  sum value:', sum())

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\nAfter setInput(3):')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
