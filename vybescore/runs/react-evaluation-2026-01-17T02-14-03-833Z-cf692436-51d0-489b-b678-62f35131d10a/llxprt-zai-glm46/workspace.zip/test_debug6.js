import { createInput, createComputed } from './src/index.ts'

console.log('=== Checking observer identity ===')
const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('  Computing sum:')
  const tt = timesTwo()
  const ttt = timesThirty()
  console.log('    timesTwo() =', tt, ', timesThirty() =', ttt)
  const result = tt + ttt
  console.log('    sum =', result)
  return result
})

console.log('\n=== Initial ===')
console.log('sum() =', sum())

console.log('\n=== Checking observers ===')
const subjectObservers = (input as any).observers || new Set()
console.log('Input subject has observers:', subjectObservers.size)
console.log('Observers:', Array.from(subjectObservers).map((o: any) => ({ name: o.name, value: o.value, dependents: o.dependents?.size })))

// Find the sum observer
const sumObserver = Array.from(subjectObservers).find((o: any) => o.value === 32)
if (sumObserver) {
  console.log('\nSum observer:')
  console.log('  value:', sumObserver.value)
  console.log('  dependencies:', sumObserver.dependencies?.size)
  console.log('  dependents:', sumObserver.dependents?.size)
}

console.log('\n=== After setInput(3) ===')
setInput(3)
console.log('sum() =', sum())
