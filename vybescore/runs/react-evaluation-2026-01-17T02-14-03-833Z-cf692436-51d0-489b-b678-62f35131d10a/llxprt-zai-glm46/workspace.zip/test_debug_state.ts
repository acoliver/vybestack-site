import { createInput, createComputed } from './src/index.ts'

console.log('=== Debug: tracking sum observer state ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  console.log('  [timesTwo updateFn] input =', input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('  [timesThirty updateFn] input =', input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('  [sum updateFn] timesTwo() =', timesTwo(), ', timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
})

// Access internal observer to check state
const sumObserver = (sum as any)._observer

console.log('\n=== Initial state ===')
console.log('  sum:', sum())
console.log('  sum.observer.value:', sumObserver?.value)
console.log('  sum.observer.dependencies:', sumObserver?.dependencies?.size)
console.log('  sum.observer.dependents:', sumObserver?.dependents?.size)

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After setInput(3) ===')
console.log('  sum:', sum())
console.log('  sum.observer.value:', sumObserver?.value)
