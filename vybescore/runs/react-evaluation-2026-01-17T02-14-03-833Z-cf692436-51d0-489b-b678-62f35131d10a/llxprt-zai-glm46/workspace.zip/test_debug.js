import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Test 1: Compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 32')

console.log('\nSetting input to 3...')
setInput(3)
console.log('After update - input:', input())
console.log('After update - timesTwo:', timesTwo())
console.log('After update - timesThirty:', timesThirty())
console.log('After update - sum:', sum())
console.log('Expected sum: 96')

console.log('\n=== Test 2: Compute cells fire callbacks ===')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => (value = output()))

console.log('Initial input:', input2())
console.log('Initial output:', output())
console.log('Initial value:', value)

console.log('\nSetting input to 3...')
setInput2(3)
console.log('After update - input:', input2())
console.log('After update - output:', output())
console.log('After update - value:', value)
console.log('Expected value: 4')
