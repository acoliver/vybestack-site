import { createInput, createComputed } from './src/index.ts'
import { getActiveObserver } from './src/types/reactive.ts'

console.log('=== Debug: checking active observer during getter access ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [timesTwo getter] activeObserver:', active ? 'YES' : 'NO')
  return input() * 2
})

const timesThirty = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [timesThirty getter] activeObserver:', active ? 'YES' : 'NO')
  return input() * 30
})

const sum = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [sum updateFn] activeObserver:', active ? 'YES' : 'NO')
  console.log('    Accessing timesTwo...')
  const t2 = timesTwo()
  console.log('    Accessing timesThirty...')
  const t30 = timesThirty()
  return t2 + t30
})

console.log('\n=== Initial call to sum() ===')
console.log('Result:', sum())

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After setInput(3), call sum() again ===')
console.log('Result:', sum())
