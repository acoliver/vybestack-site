import { createInput, createComputed } from './src/index.ts'

console.log('=== Verbose debugging ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  const val = input() * 2
  console.log('  [timesTwo computed] input() =', input(), ', result =', val)
  return val
})

const timesThirty = createComputed(() => {
  const val = input() * 30
  console.log('  [timesThirty computed] input() =', input(), ', result =', val)
  return val
})

const sum = createComputed(() => {
  const t2 = timesTwo()
  const t30 = timesThirty()
  const val = t2 + t30
  console.log('  [sum computed] timesTwo() =', t2, ', timesThirty() =', t30, ', result =', val)
  return val
})

console.log('\n=== Initial state ===')
console.log('Initial values from getters:')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After setInput(3) ===')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
