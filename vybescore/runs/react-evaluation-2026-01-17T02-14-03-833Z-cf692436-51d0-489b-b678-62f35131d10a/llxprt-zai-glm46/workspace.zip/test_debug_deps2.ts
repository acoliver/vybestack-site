import { createInput, createComputed } from './src/index.ts'

console.log('=== Debug: checking dependency tracking ===')

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  const val = input() * 2
  console.log('  [timesTwo updateFn] input =', input(), ', result =', val)
  return val
})

const timesThirty = createComputed(() => {
  const val = input() * 30
  console.log('  [timesThirty updateFn] input =', input(), ', result =', val)
  return val
})

const sum = createComputed(() => {
  console.log('  [sum updateFn] called')
  const t2 = timesTwo()
  const t30 = timesThirty()
  console.log('    timesTwo() =', t2, ', timesThirty() =', t30, ', sum =', t2 + t30)
  return t2 + t30
})

// Check internal state
const timesTwoObs = (timesTwo as any)._observer
const timesThirtyObs = (timesThirty as any)._observer
const sumObs = (sum as any)._observer

console.log('\n=== Initial state ===')
console.log('  sum:', sum())
console.log('  sum.dependencies size:', sumObs.dependencies.size)
console.log('  sum.dependents size:', sumObs.dependents.size)
console.log('  timesTwo.dependents size:', timesTwoObs.dependents.size)
console.log('  timesThirty.dependents size:', timesThirtyObs.dependents.size)

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After setInput(3) ===')
console.log('  sum:', sum())
console.log('  sum.dependencies size:', sumObs.dependencies.size)
console.log('  timesTwo.dependents size:', timesTwoObs.dependents.size)
console.log('  timesThirty.dependents size:', timesThirtyObs.dependents.size)
