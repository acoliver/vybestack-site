export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive regex.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  // Additional checks for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');

  // Handle optional +1 prefix
  const digits = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;

  // Check if we have exactly 10 digits for the main number
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code and validate it doesn't start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // Validate the basic phone number format
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Regex pattern for Argentine phone numbers
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(?:0?[1-9]\d{1,3})\d{6,8}$/;

  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }

  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCodeMatch: RegExpMatchArray | null = null;

  // Handle different formats
  if (cleaned.startsWith('+54')) {
    areaCodeMatch = cleaned.match(/^\+54(?:9)?(0?[1-9]\d{1,3})/);
  } else {
    areaCodeMatch = cleaned.match(/^(0?[1-9]\d{1,3})/);
  }

  if (!areaCodeMatch) {
    return false;
  }

  const areaCode = areaCodeMatch[1].replace(/^0/, ''); // Remove trunk prefix for validation
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Check that subscriber number has 6-8 digits
  const subscriberMatch = cleaned.match(/(?:\+54)?(?:9)?(?:0?[1-9]\d{1,3})(\d{6,8})$/);
  return subscriberMatch !== null;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Regex that allows unicode letters, spaces, apostrophes, and hyphens
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\s'-]+$/;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Reject names with consecutive symbols or that start/end with symbols
  if (/['-]{2,}/.test(value) || /^[ '-]/.test(value) || /[ '-]$/.test(value)) {
    return false;
  }

  // Reject names with too many consecutive spaces or no letters
  if (/\s{3,}/.test(value) || !/[A-Za-zÀ-ÖØ-öø-ÿ]/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx formats.
 * Accepts valid prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');

  // Check basic length (13-19 digits)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }

  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;

  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;

  // Amex: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  // Check if the card matches any of the accepted formats
  const isValidFormat = visaRegex.test(digits) || 
                       mastercardRegex.test(digits) || 
                       amexRegex.test(digits);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(digits);
}