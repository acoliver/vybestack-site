/**
 * Matches words starting with the prefix but excluding banned words.
 * Uses regex with word boundaries and negative lookahead for exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex usage
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Build a regex to match words starting with prefix
  const prefixRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'g');

  const matches = text.match(prefixRegex) || [];

  // Filter out exceptions (case-sensitive exact matches)
  const filteredMatches = matches.filter(match => !exceptions.includes(match));

  // Remove duplicates and return
  return [...new Set(filteredMatches)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses positive lookbehind to require a digit before the token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Find token occurrences that are preceded by a digit and not at string start
  const results: string[] = [];
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');

  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    results.push(match[0]);
  }

  // Remove duplicates and return
  return [...new Set(results)];
}

/**
 * Validates passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This regex looks for patterns where a sequence of 2+ characters is repeated immediately
  const repeatedSequenceRegex = /(.+)\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }

  // Additional check for simple repetitive patterns (like aaaa, 1111)
  const simpleRepeatRegex = /(.)\1{3,}/;
  if (simpleRepeatRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Uses comprehensive regex for IPv6 format validation.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that matches various formats including shorthand
  // This pattern matches:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1
  // - IPv4 embedded: ::ffff:192.0.2.128
  const ipv6Regex = /(?:^|(?<=\s))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::ffff:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])(?:$|(?=\s))/;

  // First check if we have any IPv6-like pattern
  const potentialIPv6Match = value.match(ipv6Regex);
  if (!potentialIPv6Match) {
    return false;
  }

  // Now verify that we don't have pure IPv4 addresses that might match
  // IPv4 regex for exclusion
  const ipv4Regex = /(?:^|(?<=\s))(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:$|(?=\s))/;

  // Check if our match is actually IPv4-only
  for (const match of potentialIPv6Match) {
    if (!ipv4Regex.test(match.trim())) {
      return true; // Found a genuine IPv6 address
    }
  }

  return false;
}