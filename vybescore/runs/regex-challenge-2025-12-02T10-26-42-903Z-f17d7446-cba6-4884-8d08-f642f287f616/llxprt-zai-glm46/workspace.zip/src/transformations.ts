/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences even if the input omitted it,
 * and collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that should not trigger sentence breaks
  const abbreviations = /(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|etc|e\.g|i\.e|vs|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\.?$/i;

  // First, normalize spacing: collapse multiple spaces to single, ensure single space after sentence endings
  const normalized = text
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .replace(/([.!?])(?=[A-Za-z])/g, '$1 ') // Ensure space after punctuation if followed by letter
    .trim(); // Trim leading/trailing spaces

  // Split into sentences, being careful about abbreviations
  const sentences: string[] = [];
  let current = '';

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    current += char;

    // Check if we have a sentence ending
    if (/[.!?]/.test(char)) {
      // Look ahead to see if this might be an abbreviation
      const beforePunct = normalized.slice(0, i).match(/(\S+)\s*$/);
      const word = beforePunct ? beforePunct[1] : '';

      // If it's not an abbreviation and next character is space or end of string, treat as sentence end
      if (!abbreviations.test(word) && (i === normalized.length - 1 || normalized[i + 1] === ' ')) {
        sentences.push(current.trim());
        current = '';
      }
    }
  }

  // Add any remaining text
  if (current.trim()) {
    sentences.push(current.trim());
  }

  // Capitalize first letter of each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return '';
    return sentence[0].toUpperCase() + sentence.slice(1);
  });

  return capitalizedSentences.join('. ').replace(/\.\s*\./g, '.').trim();
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https, www, and domain-only URLs
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;

  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation and clean up URLs
  return matches.map(url => {
    // Remove trailing punctuation but not part of the URL
    return url.replace(/[.,;:!?)]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https://, rewrites host when path starts with /docs/,
 * skips host rewrite for dynamic hints or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  const result = enforceHttps(text);

  // Pattern to match URLs, capturing host and path
  const urlPattern = /(https:\/\/)([^/\s]+)(\/[^\s]*)/g;

  return result.replace(urlPattern, (match, protocol, host, path) => {
    // Skip host rewrite for dynamic hints or legacy extensions
    const dynamicPatterns = [
      /\/cgi-bin/i,
      /[?&=]/,      // Query parameters
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?/]|$)/i  // Legacy extensions
    ];

    const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));

    // If path starts with /docs/ and we shouldn't skip, rewrite host
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return `${protocol}docs.${host}${path}`;
    }

    return match;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format and capture year, month, day
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;

  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }

  const [, month, day, year] = match;

  // Validate that month and day make sense together
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);

  // Days in each month (accounting for leap years in February)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  // Check for leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  if (isLeapYear) {
    daysInMonth[1] = 29; // February has 29 days in leap years
  }

  // Validate day against month
  if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }

  return year;
}