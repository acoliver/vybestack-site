/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T = unknown> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  dependents?: Observer[]
  value?: unknown
  updateFn: UpdateFn
}

export interface Subject {
  name?: string
  value: unknown
  equalFn?: EqualFn<unknown>
  observers?: Observer[]
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}
// Track which observer is currently being accessed to build dependency graph
export function addObserverToSubject(subject: Subject, observer: Observer): void {
  if (!subject.observers) {
    subject.observers = []
  }
  if (!subject.observers.includes(observer)) {
    subject.observers.push(observer)
  }
}

export function addSubjectToObserver(observer: Observer, subject: Subject): void {
  if (!observer.dependents) {
    observer.dependents = []
  }
  const observerWithTracking = observer as Observer & { trackedSubjects?: Subject[] }
  observerWithTracking.trackedSubjects = observerWithTracking.trackedSubjects || []
  if (!observerWithTracking.trackedSubjects.includes(subject)) {
    observerWithTracking.trackedSubjects.push(subject)
  }
}

export function updateObserver(observer: Observer, visited: Set<Observer> = new Set()): void {
  // Prevent infinite recursion
  if (visited.has(observer)) return
  
  visited.add(observer)
  
  const parentObserver = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // Process dependents
    if (observer.dependents && observer.dependents.length > 0) {
      // Create a copy to avoid issues with dependency modification during iteration
      const dependents = [...observer.dependents]
      for (const dependent of dependents) {
        // Recursively update any dependents of this dependent
        updateObserver(dependent, new Set(visited))
      }
    }
  } finally {
    activeObserver = parentObserver
  }
}