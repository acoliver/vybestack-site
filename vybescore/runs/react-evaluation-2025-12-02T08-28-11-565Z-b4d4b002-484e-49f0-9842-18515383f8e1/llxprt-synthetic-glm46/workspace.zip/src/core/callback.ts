/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, Subject, getActiveObserver, setActiveObserver } from '../types/reactive'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer = {
    value,
    updateFn: updateFn as UpdateFn,
    dependents: [],
  }
  
  let disposed = false
  
  // Execute the callback to establish dependencies and perform side effects
  const executeCallback = (): void => {
    if (disposed) return
    
    const prevObserver = getActiveObserver()
    
    try {
      // Set this callback as the active observer to track dependencies
      setActiveObserver(observer)
      
      // Execute the update function to perform side effects
      const newValue = updateFn(value)
      
      // Store the new value for the next execution
      if (newValue !== undefined) {
        observer.value = newValue
      }
    } finally {
      // Restore the previous observer
      setActiveObserver(prevObserver)
    }
  }
  
  // Execute the callback once to establish dependencies and perform initial side effects
  executeCallback()
  
  // Return unsubscribe function
  const unsubscribe = (): void => {
    disposed = true
    // Clear dependencies - important for cleanup
    observer.dependents = []
    
    // Remove observer from tracked subjects
    // This properly implements the cleanup
    const observerWithTracking = observer as Observer & { trackedSubjects?: Subject[] }
    if (observerWithTracking.trackedSubjects) {
      for (const subject of observerWithTracking.trackedSubjects) {
        if (subject && subject.observers) {
          const index = subject.observers.indexOf(observer)
          if (index !== -1) {
            subject.observers.splice(index, 1)
          }
        }
      }
      observerWithTracking.trackedSubjects = []
    }
  }
  
  return unsubscribe
}