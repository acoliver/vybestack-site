/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  // Create the subject with initial value
  const s: Subject = {
    name: options?.name,
    value,
    equalFn: equalFn as EqualFn<unknown> | undefined,
    observers: [],
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer to the subject's observers list
      if (!s.observers) {
        s.observers = []
      }
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
      }
      
      // Track this subject so we can clean up the observer later
      const observerWithTracking = observer as Observer & { trackedSubjects?: Subject[] }
      observerWithTracking.trackedSubjects = observerWithTracking.trackedSubjects || []
      if (!observerWithTracking.trackedSubjects!.includes(s)) {
        observerWithTracking.trackedSubjects.push(s)
      }
    }
    return s.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check equality to avoid unnecessary updates
    if (equalFn && equalFn(s.value as T, nextValue)) {
      return s.value as T
    }
    
    s.value = nextValue
    
    // Update all observers
    if (s.observers && s.observers.length > 0) {
      // Create a copy to avoid infinite recursion if cycles are introduced
      const observers = [...s.observers]
      for (const observer of observers) {
        updateObserver(observer)
      }
    }
    
    return nextValue
  }

  return [read, write]
}