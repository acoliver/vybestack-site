/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine equality function (unused for now, but kept for future implementation)
  const _equalFn: EqualFn<T> | undefined = (() => {
    if (equal === true) {
      return (a: T, b: T) => a === b
    } else if (equal === false) {
      return undefined
    } else if (typeof equal === 'function') {
      return equal
    } else {
      return undefined
    }
  })()

  const o: Observer = {
    name: options?.name,
    value,
    updateFn: updateFn as UpdateFn,
    dependents: [],
  }

  const computeValue = (): T => {
    const prevObserver = getActiveObserver()
    
    try {
      // Set this computed as the active observer to track dependencies
      setActiveObserver(o)
      
      // Execute the update function to compute the new value
      const newValue = updateFn(o.value as T)
      o.value = newValue
      
      return newValue
    } finally {
      // Restore the previous observer
      setActiveObserver(prevObserver)
    }
  }

  // Initialize the value on first computation
  if (o.value === undefined && value !== undefined) {
    o.value = value
  }

  // Return the getter function that updates the computed value
  return computeValue
}