#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (result.inputFile === '') {
      result.inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }

    i++;
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error("Invalid report data: missing or invalid 'title' field (expected string)");
  }

  if (typeof obj.summary !== 'string') {
    throw new Error("Invalid report data: missing or invalid 'summary' field (expected string)");
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error("Invalid report data: missing or invalid 'entries' field (expected array)");
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid 'label' field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid 'amount' field (expected number)`);
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON file: ${error.message}`);
    }
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Unknown error occurred while reading file');
  }
}

function getRenderer(format: string) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));

    if (args.inputFile === '') {
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (args.format === '') {
      console.error('Error: --format is required');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    const data = loadReportData(args.inputFile);

    const renderer = getRenderer(args.format);
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = renderer(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
