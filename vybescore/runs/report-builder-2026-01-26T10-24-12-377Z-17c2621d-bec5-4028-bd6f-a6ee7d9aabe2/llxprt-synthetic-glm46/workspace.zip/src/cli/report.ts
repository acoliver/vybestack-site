#!/usr/bin/env node

import fs from 'fs';
import { formatters } from '../formats/index.js';
import type { ReportData, ReportEntry, RenderOptions, Format } from '../types.js';

/**
 * Parse command line arguments
 */
function parseArgs(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } = {
    dataPath: args[0],
    format: '',
    outputPath: undefined,
    includeTotals: false
  };
  
  let i = 1;
  while (i < args.length) {
    switch (args[i]) {
      case '--format':
        result.format = args[i + 1];
        i += 2;
        break;
      case '--output':
        result.outputPath = args[i + 1];
        i += 2;
        break;
      case '--includeTotals':
        result.includeTotals = true;
        i += 1;
        break;
      default:
        console.error(`Unknown argument: ${args[i]}`);
        process.exit(1);
    }
  }
  
  return result;
}

/**
 * Validate and parse report data from JSON
 */
function loadReportData(dataPath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Basic validation
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: root must be an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    const entries = reportData.entries as unknown[];
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label"`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount"`);
      }
    }
    
    return {
      title: reportData.title,
      summary: reportData.summary,
      entries: reportData.entries as ReportEntry[]
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Malformed JSON: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Get formatter by format name
 */
function getFormatter(format: string): typeof formatters[string] {
  const formatter = formatters[format as Format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${Object.keys(formatters).join(', ')}`);
  }
  return formatter;
}

/**
 * Main execution function
 */
function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs();
    
    // Load and validate data
    const reportData = loadReportData(dataPath);
    
    // Get formatter and render report
    const formatter = getFormatter(format);
    const options: RenderOptions = { includeTotals };
    const output = formatter.render(reportData, options);
    
    // Write output
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
