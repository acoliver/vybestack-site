/**
 * Interface for a single report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering
 */
export interface RenderOptions {
  includeTotals?: boolean;
}

/**
 * Common interface for report formatters
 */
export interface Formatter {
  render(data: ReportData, options?: RenderOptions): string;
}

/**
 * Supported output formats
 */
export type Format = 'markdown' | 'text';