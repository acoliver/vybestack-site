import type { Formatter } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Map of format names to their corresponding formatters
 */
export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};