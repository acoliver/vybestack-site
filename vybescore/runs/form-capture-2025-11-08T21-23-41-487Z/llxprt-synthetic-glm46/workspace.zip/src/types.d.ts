declare module 'sql.js' {
  class Database {
    constructor(data?: Uint8Array);
    export(): Uint8Array;
    run(sql: string, params?: unknown[]): unknown;
    get(sql: string, params?: unknown[]): unknown;
    exec(sql: string): unknown[];
    close(): void;
  }

  export function initSqlJs(): Promise<{ Database: typeof Database }>;
}