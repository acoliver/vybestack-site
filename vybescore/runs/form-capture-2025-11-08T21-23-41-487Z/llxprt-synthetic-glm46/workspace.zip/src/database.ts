import fs from 'node:fs/promises';
import path from 'node:path';
// @ts-ignore
import initSqlJs = require('sql.js');

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

interface Database {
  db: unknown;
  dbPath: string;
  export: () => Promise<void>;
  run: (query: string, params?: unknown[]) => unknown;
  get: (query: string, params?: unknown[]) => unknown;
  all: (query: string, params?: unknown[]) => unknown[];
  close: () => void;
}

export async function initializeDatabase(): Promise<Database> {
  try {
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
  } catch (error) {
    console.error('Error creating data directory:', error);
  }

  let dbBuffer: Buffer | Uint8Array = new Uint8Array(0);
  let isNewDb = false;

  try {
    await fs.stat(DB_PATH);
    dbBuffer = await fs.readFile(DB_PATH);
  } catch (error) {
    console.log('Database file does not exist, creating new database');
    isNewDb = true;
  }

  // @ts-ignore
  const initSqlJsResult = await initSqlJs();
  const db = new initSqlJsResult.Database(dbBuffer);

  if (isNewDb) {
    const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
    const schema = await fs.readFile(schemaPath, 'utf8');
    
    db.run(schema);
    console.log('Database schema initialized');
  }

  return {
    db,
    dbPath: DB_PATH,
    export: async () => {
      try {
        const data = db.export();
        await fs.writeFile(DB_PATH, Buffer.from(data));
      } catch (error) {
        console.error('Error exporting database:', error);
      }
    },
    run: (query: string, params?: unknown[]) => {
      return db.run(query, params || []);
    },
    get: (query: string) => {
      return db.get(query);
    },
    all: (query: string) => {
      return db.exec(query).map((result: { columns: string[]; values: unknown[][] }) => {
        const columns = result.columns;
        const values = result.values;
        
        return values.map((row: unknown[]) => {
          const obj: Record<string, unknown> = {};
          columns.forEach((col: string, index: number) => {
            obj[col] = row[index];
          });
          return obj;
        });
      }).flat();
    },
    close: () => {
      db.close();
    }
  };
}