import express, { type Request, type Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase } from './database.js';
import { validate, type FormData, type ValidationError } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

let db: Awaited<ReturnType<typeof initializeDatabase>> | null = null;

async function startServer() {
  try {
    db = await initializeDatabase();
    
    app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        title: 'Contact Form',
        formData: {},
        errors: {}
      });
    });

    app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        street_address: req.body.street_address,
        city: req.body.city,
        state_province: req.body.state_province,
        postal_code: req.body.postal_code,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone
      };

      const validationErrors = validate(formData);
      
      if (validationErrors.length > 0) {
        const errorsMap: Record<string, string> = {};
        validationErrors.forEach((err: ValidationError) => {
          errorsMap[err.field] = err.message;
        });
        
        return res.status(400).render('form', {
          title: 'Contact Form',
          formData,
          errors: errorsMap
        });
      }

      if (db) {
        db.run(
          `INSERT INTO submissions 
          (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            formData.first_name,
            formData.last_name,
            formData.street_address,
            formData.city,
            formData.state_province,
            formData.postal_code,
            formData.country,
            formData.email,
            formData.phone
          ]
        );

        db.export();
      }

      res.redirect('/thank-you');
    });

    app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', {
        title: 'Thank You!'
      });
    });

    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    return server;
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
}

const server = await startServer();

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  
  if (db) {
    db.close();
  }
  
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export { server, app };