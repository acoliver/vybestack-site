export interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

export function validatePostalCode(postalcode: string): boolean {
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalcode) && postalcode.trim().length > 0;
}

export function validate(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.first_name || formData.first_name.trim().length === 0) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  if (!formData.last_name || formData.last_name.trim().length === 0) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  if (!formData.street_address || formData.street_address.trim().length === 0) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }

  if (!formData.city || formData.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.state_province || formData.state_province.trim().length === 0) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }

  if (!formData.postal_code || formData.postal_code.trim().length === 0) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(formData.postal_code)) {
    errors.push({ field: 'postal_code', message: 'Invalid postal code format' });
  }

  if (!formData.country || formData.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email || formData.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }

  if (!formData.phone || formData.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone number format' });
  }

  return errors;
}