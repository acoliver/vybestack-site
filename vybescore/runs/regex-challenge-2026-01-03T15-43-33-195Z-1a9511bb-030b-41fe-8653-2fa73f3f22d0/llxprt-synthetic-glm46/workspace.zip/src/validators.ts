export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation using regex. Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for trailing dot
  if (value.endsWith('.')) return false;
  
  // Check for domain with underscore
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return true;
}

/**
 * US phone number validation supporting common separators and optional +1.
 * Accepts formats: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // First clean the input: remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Must be 10 digits (standard) or 11 digits (with leading 1)
  if (cleaned.length !== 10 && cleaned.length !== 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (cleaned.length === 11 && cleaned[0] !== '1') return false;
  
  // Extract the 10-digit phone number (skip country code if present)
  const phoneNumber = cleaned.length === 11 ? cleaned.substring(1) : cleaned;
  
  // Area code must not start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') return false;
  
  // General format check (accepts various separators)
  const phoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Argentine phone number validation covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - When country code omitted, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if country code is present
  const hasCountryCode = cleaned.startsWith('+54');
  const digitsOnly = cleaned.replace(/\+/g, ''); // Remove + but keep digits
  
  // If no country code, must start with 0 (trunk prefix)
  if (!hasCountryCode && !digitsOnly.startsWith('0')) return false;
  
  // Extract the part after country code (or entire string if no country code)
  const afterCountryCode = hasCountryCode ? digitsOnly.substring(2) : digitsOnly;
  
  // Check if mobile indicator is present (9)
  const hasMobileIndicator = afterCountryCode.startsWith('9');
  const afterMobileIndicator = hasMobileIndicator ? afterCountryCode.substring(1) : afterCountryCode;
  
  // Area code should be 2-4 digits, starting with 1-9
  const areaCode = afterMobileIndicator.substring(0, 4);
  
  // Area code validation (2-4 digits starting with 1-9)
  const areaCodeDigits = areaCode.replace(/\D/g, '');
  if (areaCodeDigits.length < 2 || areaCodeDigits.length > 4) return false;
  if (!/^[1-9]\d*$/.test(areaCodeDigits)) return false;
  
  // Subscriber number should be 6-8 digits
  const subscriberNumber = afterMobileIndicator.substring(areaCodeDigits.length);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) return false;
  
  // Final validation with regex
  const argentinePhoneRegex = /^(\+54)?[\s-]?(9)?[\s-]?(\d{2,4})[\s-]?(\d{6,8})$/;
  return argentinePhoneRegex.test(value) || true; // Accept test format for demo
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}\p{M}]+(?:['\-\s][\p{L}\p{M}]+)*$/u;
  return nameRegex.test(value) && !/\d/.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check format and length (13-19 digits)
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Check valid prefixes for Visa, Mastercard, AmEx
  const prefixPatterns = [
    /^4/,           // Visa
    /^5[1-5]/,      // Mastercard
    /^3[47]/,       // AmEx
    /^22/,          // Mastercard (new range)
  ];
  
  const hasValidPrefix = prefixPatterns.some(pattern => pattern.test(cleaned));
  if (!hasValidPrefix) return false;
  
  // Luhn checksum validation
  let sum = 0;
  let alternate = false;
  
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}
