/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find all words starting with the prefix
  const words = text.match(/\b\w+/g) || [];
  
  // Filter words that start with prefix and aren't in exceptions
  const filteredWords = words.filter(word => 
    word.startsWith(prefix) && !exceptions.includes(word)
  );
  
  // Remove duplicates
  return [...new Set(filteredWords)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\\$&');
  // Lookbehind to ensure token isn't at the start of the string and
  // lookahead to ensure it's preceded by a digit
  const regex = new RegExp(String.raw`(?<!^)\d${escapedToken}`, 'g');
  const matches = [...text.matchAll(regex)];
  return matches.map(match => match[0]);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+=\[\]{};':"|,.<>\/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  if (/(.{2,})\1/.test(value)) return false;
  
  // If all checks pass, it's a strong password
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that matches standard IPv6 formats including shorthand
  const ipv6Regex = /(?:^|[^0-9])(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))(?:$|[^0-9a-fA-F])/;
  
  // First filter out obvious IPv4 addresses to avoid false positives
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  if (ipv4Regex.test(value)) return false;
  
  return ipv6Regex.test(value);
}
