/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text
    .replace(/([.!?])\s*([a-z])/g, '$1 $2')
    .split(/([.!?]\s)/)
    .map((sentence, index, array) => {
      if (index === 0 && sentence.trim() === '') return sentence;
      if (index % 2 === 0 && array[index - 1] && array[index - 1].match(/[.!?]\s/)) {
        return sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
      if (index === 0 && sentence.length > 0) {
        return sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
      return sentence;
    })
    .join('')
    .replace(/\s{2,}/g, ' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_.~#?&//=]*)/gi;
  const matches = text.match(urlRegex) || [];
  return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  text = text.replace(/http:\/\//g, 'https://');
  
  // Define URL patterns to exclude from host rewrite
  const excludePatterns = [
    /\/cgi-bin\//,
    /[?]/,
    /[&]/,
    /[=]/,
    /\.jsp$/,
    /\.php$/,
    /\.asp$/,
    /\.aspx$/,
    /\.do$/,
    /\.cgi$/,
    /\.pl$/,
    /\.py$/
  ];
  
  // Pattern to match example.com URLs and capture the path
  const exampleUrlRegex = /(https?:\/\/)(example\.com)(\/.*)/g;
  
  return text.replace(exampleUrlRegex, (match, protocol, host, path) => {
    // Check if path should be excluded from host rewrite
    const shouldExclude = excludePatterns.some(pattern => pattern.test(path));
    
    if (shouldExclude) {
      // Only upgrade to https
      return `https://${host}${path}`;
    } else {
      // Rewrite host to docs.example.com for docs paths
      if (path.startsWith('/docs/')) {
        return `https://docs.example.com${path}`;
      } else {
        // Just upgrade to https
        return `https://${host}${path}`;
      }
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Validate month/day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Simple validation
  if (monthNum === 2 && dayNum > 29) return 'N/A';
  if ((monthNum === 4 || monthNum === 6 || monthNum === 9 || monthNum === 11) && dayNum > 30) return 'N/A';
  
  return year;
}
