import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// @ts-expect-error - No types available for sql.js
import * as initSqlJsModule from 'sql.js';

// Type declarations for sql.js
interface Database {
  run(sql: string, ...params: unknown[]): unknown;
  prepare(sql: string): {
    run(params?: unknown[]): unknown;
    getAsObject(params?: unknown[]): unknown;
    free(): void;
  };
  export(): Uint8Array;
  close(): void;
}

interface InitSqlJs {
  Database: new (data?: Uint8Array) => Database;
}

interface InitFunction {
  (options?: { locateFile?: (file: string) => string }): Promise<InitSqlJs>;
}

// Setup EJS directory for ES modules
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Types for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

// Initialize variables
let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3000;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Helper function to validate email
const isValidEmail = (email: string): boolean => {
  // Simple email regex for basic validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Helper function to validate phone number
const isValidPhone = (phone: string): boolean => {
  // Phone numbers can contain digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
};

// Helper function to validate postal code
const isValidPostalCode = (postalCode: string): boolean => {
  // Postal codes can be alphanumeric, supporting UK "SW1A 1AA" and Argentine format "C1000"
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length > 0;
};

// Form validation function
const validateForm = (data: FormData): ValidationResult => {
  const errors: string[] = [];

  // Check required fields
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  } else if (!isValidPostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }

  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!isValidEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!isValidPhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const initSqlJs = initSqlJsModule as unknown as InitFunction;
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Create or load database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Database loaded from file');
    } else {
      db = new SQL.Database();
      console.log('New database created');
    }

    // Apply schema if needed
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
    console.log('Database schema initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      // console.log('Database saved to disk');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  // Insert into database
  if (db) {
    try {
      const stmt = db?.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt?.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      stmt?.free();
      saveDatabase();
    } catch (error) {
      console.error('Failed to insert submission:', error);
      return res.status(500).render('form', {
        errors: ['Failed to save your submission. Please try again.'],
        values: formData
      });
    }
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Since we're using server-side rendering and redirects,
  // we need to get the first name from the last submission
  let firstName = 'friend';
  
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const result = stmt.getAsObject(['first_name']) as Record<string, string>;
      if (result && result.first_name) {
        firstName = result.first_name;
      }
      stmt.free();
    } catch (error) {
      console.error('Failed to retrieve submission:', error);
    }
  }
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function closeServer(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      saveDatabase();
      db.close();
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Handle graceful shutdown
  process.on('SIGTERM', closeServer);
  process.on('SIGINT', closeServer);
}

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;