import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error sql.js doesn't have types but it's necessary
import initSqlJs from 'sql.js';

// Type declarations for sql.js
interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(params: unknown[]): void;
  getAsObject(columnNames: string[]): Record<string, unknown>;
  free(): void;
}

// Helper to get __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const port = process.env.PORT || 3535;

// Initialize Express app
const app = express();

// SQLite database instance
let db: Database | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');
const schemaPath = path.resolve('db', 'schema.sql');

// Function to initialize database with sql.js (WASM build)
async function initializeDatabase(): Promise<void> {
  try {
    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create a new one
    if (fs.existsSync(dbPath)) {
      try {
        const dbFile = fs.readFileSync(dbPath);
        db = new SQL.Database(dbFile);
        console.log('Loaded existing database');
      } catch (error) {
        console.error('Error loading database, creating new one:', error);
        db = null;
      }
    }
    
    // Create new database if doesn't exist or couldn't load
    if (!db) {
      db = new SQL.Database();
      
      // Read and execute the schema
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db!.run(schema);
        console.log('Created new database with schema');
      } else {
        throw new Error(`Schema file not found at ${schemaPath}`);
      }
        
      // Save the new database
      await saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Function to save data to persistent storage
async function saveDatabase(): Promise<void> {
  if (!db) {
    console.error('Database not initialized');
    return;
  }
  
  try {
    // Export the database to binary format
    const data = db!.export();
    
    // Write the database to disk
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Error saving database:', error);
    throw error;
  }
}

// Middleware for parsing request body
app.use(express.urlencoded({ extended: false }));
app.use(express.json());;

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// GET / route - render the contact form
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

// POST /submit route with server-side validation
app.post('/submit', async (req, res) => {
  try {
    // Extract form data
    const {
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    } = req.body;
    
    // Validation errors array
    const errors: string[] = [];
    
    // Server-side validation
    if (!firstName || firstName.trim() === '') {
      errors.push('First name is required');
    }
    
    if (!lastName || lastName.trim() === '') {
      errors.push('Last name is required');
    }
    
    if (!streetAddress || streetAddress.trim() === '') {
      errors.push('Street address is required');
    }
    
    if (!city || city.trim() === '') {
      errors.push('City is required');
    }
    
    if (!stateProvince || stateProvince.trim() === '') {
      errors.push('State / Province / Region is required');
    }
    
    if (!postalCode || postalCode.trim() === '') {
      errors.push('Postal / Zip code is required');
    }
    
    if (!country || country.trim() === '') {
      errors.push('Country is required');
    }
    
    // Email validation
    if (!email || email.trim() === '') {
      errors.push('Email is required');
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        errors.push('Email must be a valid email address');
      }
    }
    
    // Phone number validation
    if (!phone || phone.trim() === '') {
      errors.push('Phone number is required');
    } else {
      // Allow digits, spaces, parentheses, dashes, and a leading +
      const phoneRegex = /^\+?[0-9\s()\-.]+$/;
      if (!phoneRegex.test(phone)) {
        errors.push('Phone number can contain digits, spaces, parentheses, dashes, and a leading +');
      }
    }
    
    // If validation errors, re-render the form with errors and values
    if (errors.length > 0) {
      return res.render('form', {
        errors,
        values: req.body
      });
    }
    
    // If validation passes, insert into database
    const insertStmt = db!.prepare('INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    insertStmt.run([
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]);
    insertStmt.free();
    
    // Save the database to disk
    await saveDatabase();
    
    // Redirect to thank-you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error in /submit route:', error);
    const errors = ['An unexpected error occurred. Please try again.'];
    res.render('form', {
      errors,
      values: req.body
    });
  }
});

// GET /thank-you route with humorous message
app.get('/thank-you', (req, res) => {
  // Try to get the first name from the most recent submission
  let firstName = 'friend';
  
  if (db) {
    try {
      const stmt = db!.prepare('SELECT first_name FROM submissions ORDER BY rowid DESC LIMIT 1');
      const result = stmt.getAsObject(['first_name']);
      stmt.free();
      
      if (result && result.first_name) {
        firstName = String(result.first_name);
      }
    } catch (error) {
      console.error('Error retrieving first name:', error);
      // Use default if error
    }
  }
  
  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<ReturnType<typeof app.listen>> {
  try {
    await initializeDatabase();
    
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Graceful shutdown
    process.on('SIGTERM', async () => {
      console.log('SIGTERM received, shutting down gracefully');
      
      if (db) {
        await saveDatabase();
        db.close(); // Close database connection
      }
      
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();