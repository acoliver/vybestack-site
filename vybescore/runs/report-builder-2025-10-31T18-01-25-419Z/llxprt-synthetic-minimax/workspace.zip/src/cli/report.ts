import { readFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  const parsed: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing value for --format');
      }
      parsed.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing value for --output');
      }
      parsed.output = args[i];
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (!parsed.dataFile) {
        parsed.dataFile = arg;
      }
    }
    
    i++;
  }

  if (!parsed.dataFile) {
    throw new Error('Missing data file argument');
  }

  if (!parsed.format) {
    throw new Error('Missing --format argument');
  }

  return parsed;
}

function parseReportData(filePath: string): ReportData {
  let rawData: string;
  try {
    rawData = readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file ${filePath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(rawData);
  } catch (error) {
    throw new Error(`Invalid JSON: ${error instanceof Error ? error.message : 'Parse error'}`);
  }

  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON structure: root must be an object');
  }

  const reportData = data as Partial<ReportData>;

  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid "title" field');
  }

  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry ${i} is invalid`);
    }
    
    const { label, amount } = entry;
    
    if (!label || typeof label !== 'string') {
      throw new Error(`Entry ${i} has invalid "label" field`);
    }
    
    if (typeof amount !== 'number' || isNaN(amount)) {
      throw new Error(`Entry ${i} has invalid "amount" field (must be a number)`);
    }
  }

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries: reportData.entries as { label: string; amount: number }[],
  };
}

function render(data: ReportData, format: string, options: RenderOptions): string {
  const formatters: Record<string, { render: (data: ReportData, options: RenderOptions) => string }> = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return formatter.render(data, options);
}

function main(args: string[]): void {
  try {
    const parsedArgs = parseArgs(args.slice(2));
    const data = parseReportData(parsedArgs.dataFile);
    const output = render(data, parsedArgs.format, { includeTotals: parsedArgs.includeTotals });
    
    if (parsedArgs.output) {
      // TODO: Write to file if needed
      // For now, output to stdout
      process.stdout.write(output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

// Only run main if this file is being executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main(process.argv);
}