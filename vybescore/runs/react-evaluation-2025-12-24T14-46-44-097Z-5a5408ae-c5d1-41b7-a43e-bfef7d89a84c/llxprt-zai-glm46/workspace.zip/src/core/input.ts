/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Listener,
  ObserverR,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    listeners: new Set<Listener>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // This input is being accessed within an observer (computed/callback)
      // The observer will add this input to its dependencies via the input's setter
      
      // We need to ensure the observer knows about this input
      // We do this by having the input register a listener with the observer
      
      // But we need to avoid double-registration, so we check if this observer
      // has already registered with this input
      
      // Check if we've already seen this observer
      let alreadyRegistered = false
      for (const listener of s.listeners) {
        // Each listener is associated with a specific observer
        // We can check if the listener was created by this observer
        if ((listener as { observer?: ObserverR }).observer === observer) {
          alreadyRegistered = true
          break
        }
      }
      
      if (!alreadyRegistered) {
        // Create a listener that will update the observer when this input changes
        // Store reference to observer for later deduplication
        const listener = Object.assign(() => {
          // Update the observer - we know it's a full Observer since it has listeners
          updateObserver(observer as Observer<unknown>)
        }, { observer })
        s.listeners.add(listener)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = (typeof _equal === 'function') ? _equal : undefined
    const shouldCompare = typeof _equal === 'boolean' ? _equal : true
    
    if (shouldCompare && equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    if (shouldCompare && !equalFn && s.value === nextValue) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all listeners - this will trigger all observers to update
    for (const listener of s.listeners) {
      listener()
    }
    return s.value
  }

  return [read, write]
}
