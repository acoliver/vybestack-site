/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  Listener,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    listeners: new Set<Listener>(),
    value,
    updateFn,
  }
  
  // Track which observers (computeds/callbacks) have already registered with this computed
  const registeredObservers = new WeakSet<ObserverR>()
  
  const getter = (): T => {
    // Check if this getter is being accessed within another observer
    // (e.g., another computed or callback)
    const parentObserver = getActiveObserver()
    
    if (parentObserver && !registeredObservers.has(parentObserver)) {
      registeredObservers.add(parentObserver)
      
      // Create a listener that will notify the PARENT observer when THIS computed changes
      // When this computed's value changes (due to its dependencies changing),
      // we need to notify any observers that depend on this computed
      const updateParentListener = () => {
        // The parent observer should update when this computed changes
        updateObserver(parentObserver as Observer<unknown>)
      }
      
      // Add this listener to THIS computed's listeners
      // When this computed updates, it will notify all its listeners (including parent)
      o.listeners?.add(updateParentListener)
    }
    
    return o.value!
  }
  
  // Override the updateFn to set this computed as active while computing
  // This allows dependencies (inputs, other computeds) to register with us
  const originalUpdateFn = updateFn
  o.updateFn = (v?: T) => {
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      return originalUpdateFn(v)
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Perform initial computation
  updateObserver(o)
  
  return getter
}
