/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = () => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  updateFn: () => unknown
}

export interface Subject<T = unknown> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer>
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined) {
  activeObserver = observer
}

export function updateObserver(observer: Observer): unknown {
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn()
    return newValue
  } finally {
    activeObserver = previous
  }
}
