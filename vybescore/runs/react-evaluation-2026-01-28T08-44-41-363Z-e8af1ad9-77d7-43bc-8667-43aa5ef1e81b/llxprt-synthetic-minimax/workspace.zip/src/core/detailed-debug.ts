/**
 * Detailed debug implementation to trace the reactive system
 */

import { createInput, createComputed, createCallback } from '../index.js'

export function detailedDebugTest() {
  console.log('\n=== DETAILED DEBUG REACTIVE TEST ===')
  
  // Test the failing callback scenario
  console.log('\n1. Testing callback scenario from failing test:')
  
  const [input, setInput] = createInput(1, undefined, { name: 'input' })
  console.log('   Created input with value:', input())
  
  const output = createComputed(() => {
    const computedValue = input() + 1
    console.log('   Computed: input() + 1 =', computedValue)
    return computedValue
  }, { name: 'output' })
  
  console.log('   Initial output value:', output())
  
  let value = 0
  console.log('   Initial callback capture value:', value)
  
  console.log('   Creating callback...')
  createCallback(() => {
    console.log('     Callback executing...')
    value = output()
    console.log('     Callback captured value:', value)
  })
  
  console.log('   After callback creation, captured value:', value)
  console.log('   Current output value:', output())
  
  console.log('   Setting input to 3...')
  setInput(3)
  
  console.log('   After input change:')
  console.log('     Output value:', output())
  console.log('     Callback captured value:', value)
  console.log('     Expected captured value: 4')
  
  // Test dependency establishment
  console.log('\n2. Testing dependency establishment:')
  
  const [input2, setInput2] = createInput(11, undefined, { name: 'input2' })
  console.log('   Created second input with value:', input2())
  
  const output2 = createComputed(() => {
    const computedValue = input2() + 1
    console.log('   Second computed: input2() + 1 =', computedValue)
    return computedValue
  }, { name: 'output2' })
  
  console.log('   Initial second output value:', output2())
  
  const values1: number[] = []
  console.log('   Creating first callback...')
  const unsubscribe1 = createCallback(() => {
    console.log('     First callback executing...')
    const captured = output2()
    values1.push(captured)
    console.log('     First callback captured:', captured)
    console.log('     First callback values1:', values1)
  })
  
  const values2: number[] = []
  console.log('   Creating second callback...')
  const unsubscribe2 = createCallback(() => {
    console.log('     Second callback executing...')
    const captured = output2()
    values2.push(captured)
    console.log('     Second callback captured:', captured)
    console.log('     Second callback values2:', values2)
  })
  
  console.log('   Initial state after callback creation:')
  console.log('     values1 length:', values1.length)
  console.log('     values2 length:', values2.length)
  
  console.log('   Setting input2 to 31...')
  setInput2(31)
  
  console.log('   After first input change:')
  console.log('     values1 length:', values1.length)
  console.log('     values2 length:', values2.length)
  console.log('     unsubscribe1() called...')
  unsubscribe1()
  
  console.log('   Setting input2 to 41...')
  setInput2(41)
  
  console.log('   After second input change:')
  console.log('     values1 length:', values1.length)
  console.log('     values2 length:', values2.length)
  console.log('     Expected values1 length: > 0')
  console.log('     Expected values2 length: > values1.length')
  
  return {
    input, setInput, output,
    input2, setInput2, output2,
    unsubscribe1, unsubscribe2,
    values1, values2, value
  }
}