/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as depending on this subject
      subject.observers.add(observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const previousValue = subject.value
    
    // Determine if values are different
    let valuesEqual = false
    if (subject.equalFn) {
      valuesEqual = subject.equalFn(previousValue, nextValue)
    } else if (typeof equal === 'boolean') {
      valuesEqual = equal
    } else {
      valuesEqual = Object.is(previousValue, nextValue)
    }
    
    const valueChanged = !valuesEqual
    subject.value = nextValue
    
    // Notify all dependent observers when the input changes
    if (valueChanged) {
      // Make a copy to avoid issues during iteration
      const currentObservers = Array.from(subject.observers)
      currentObservers.forEach(obs => {
        updateObserver(obs)
      })
    }
    
    return subject.value
  }

  return [read, write]
}
