/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const subject: Subject<unknown> = {
    name: options?.name,
    value: undefined,
    equalFn: undefined,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this computed subject as being depended upon
      subject.observers.add(activeObserver)
    }

    // Re-evaluate the computed function
    const result = updateFn()
    subject.value = result
    return result
  }

  return read
}
