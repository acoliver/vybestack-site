/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Subject, getActiveObserver, setActiveObserver, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: () => T, _value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create the subject that will be depended upon
  const subject: Subject<unknown> = {
    value: _value ?? undefined,
    equalFn: undefined,
    observers: new Set()
  }

  // Create observer that executes the callback
  const observer = {
    updateFn: () => {
      if (disposed) return subject.value
      
      // Execute the callback function
      const result = updateFn()
      subject.value = result
      return result
    },
  }
  
  // Execute initially to establish dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    updateObserver(observer)
  } finally {
    setActiveObserver(previousObserver)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    // Cleanup would go here if needed
  }
}
