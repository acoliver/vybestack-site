// Debug script to understand the reactive system flow
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing Reactive System Flow ===')

const [input, setInput] = createInput(1)
console.log('1. Created input with value 1')

const output = createComputed(() => {
  const result = input() + 1
  console.log(`2. Computed input() + 1 = ${result}`)
  return result
})
console.log('3. Created computed value')

let value = 0
console.log('4. Initial callback value:', value)

console.log('5. Creating callback...')
const unsubscribe = createCallback(() => {
  value = output()
  console.log(`6. Callback executed, value = ${value}`)
})

console.log('7. Initial call to output():', output())
console.log('8. Current value after callback:', value)

console.log('9. Setting input to 3...')
setInput(3)

console.log('10. Calling output after input change:', output())
console.log('11. Final callback value:', value)

console.log('=== End Test ===')