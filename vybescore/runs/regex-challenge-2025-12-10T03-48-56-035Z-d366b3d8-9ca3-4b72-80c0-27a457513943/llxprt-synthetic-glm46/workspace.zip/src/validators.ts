/**
 * Validates email addresses with proper structure.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with proper structure
  // Local part: alphanumeric chars, special chars (+._%-), no consecutive dots
  // Domain: alphanumeric chars and hyphens, no underscores, at least one dot
  const emailRegex = /^[a-zA-Z0-9]+([+._%-][a-zA-Z0-9]+)*@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*(\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*)+$/;
  
  // Quick check for common invalid patterns
  if (!value || value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscore in domain (invalid)
  const localAndDomain = value.split('@');
  if (localAndDomain.length !== 2 || localAndDomain[1].includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value) return false;
  
  // Remove all common separators and spaces for validation
  const cleanValue = value.replace(/[\s-()]/g, '');
  
  // Check for optional +1 prefix
  const hasCountryCode = cleanValue.startsWith('+1');
  const phoneNumber = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  
  // US phone numbers should be 10 digits after removing country code
  if (phoneNumber.length !== 10 || !/^\d+$/.test(phoneNumber)) {
    return false;
  }
  
  // Area code should not start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  const hasCountryCode = cleanValue.startsWith('+54');
  const phoneNumber = hasCountryCode ? cleanValue.substring(3) : cleanValue;
  
  // When country code is omitted, the number must start with 0
  if (!hasCountryCode && !phoneNumber.startsWith('0')) {
    return false;
  }
  
  // Check for optional mobile indicator 9
  const hasMobileIndicator = phoneNumber.startsWith('09');
  const adjustedNumber = hasMobileIndicator ? phoneNumber.substring(1) : phoneNumber;
  
  // Use regex to extract area code and subscriber number
  const match = adjustedNumber.match(/^([1-9]\d{1,3})(\d{6,8})$/);
  
  if (!match) {
    return false;
  }
  
  // Extract area code
  const areaCode = match[1];
  const subscriberNumber = match[2];

  
  // Verify area code is 2-4 digits and starts with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Verify subscriber number is 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Check overall format with separators
  const formatRegex = /^(?:\+54\s?)?(?:0\s?)?(?:9\s?)?[1-9]\d{1,3}(?:[\s-]?\d{2,4}){2,3}$/;
  
  return formatRegex.test(value);
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, spaces
  // Excludes digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!value || !nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with just spaces or hyphens or apostrophes
  const trimmedValue = value.trim();
  if (trimmedValue === '' || /^[\s'-]+$/.test(trimmedValue)) {
    return false;
  }
  
  // Ensure at least 2 letters (not just special characters)
  const letterCount = (trimmedValue.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letterCount < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for numeric only
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard (16 digits, starts with 51-55 or 2221-2720)
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[0-1]\d|72[0-8])\d{12})$/;
  
  // Check AmEx (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Validate format and prefix
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Luhn algorithm check
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}