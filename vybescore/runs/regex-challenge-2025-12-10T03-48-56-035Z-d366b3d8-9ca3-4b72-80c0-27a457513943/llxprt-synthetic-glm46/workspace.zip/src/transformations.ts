/**
 * Capitalizes the first character of each sentence.
 * After period, question mark or exclamation mark.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Split text into sentences (including the delimiter)
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i] || '';
    const delimiter = sentences[i + 1] || '';
    
    if (sentence.trim()) {
      // Capitalize the first non-space character
      const trimmed = sentence.trim();
      if (trimmed.length > 0) {
        const spacePrefix = sentence.substring(0, sentence.indexOf(trimmed[0]));
        const capitalized = spacePrefix + trimmed[0].toUpperCase() + trimmed.substring(1);
        result += capitalized;
      }
    }
    
    // Add the delimiter
    if (delimiter) {
      result += delimiter + ' ';
    }
  }
  
  // Clean up extra spaces and return
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern
  const urlPattern = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  const urls = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return urls.map(url => url.replace(/[.,!?;:)]+$/g, ''));
}

/**
 * Replaces all http:// URLs with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // First upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match URLs and extract components
  const urlRegex = /(https:\/\/)([^\/\s]+)(\/[^\s]*)/g;
  
  // Legacy extensions that should trigger host rewrite skip
  const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  const dynamicElements = ['cgi-bin', '?', '&', '='];
  
  result = result.replace(urlRegex, (match, protocol, hostname, path) => {
    // Check if we should skip host rewrite
    const skipHostRewrite = 
      dynamicElements.some(el => path.includes(el)) ||
      legacyExtensions.some(ext => path.includes(ext));
      
    // If path starts with /docs/ and we shouldn't skip, rewrite hostname
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Transform http://example.com/docs/... to https://docs.example.com/...
      return `${protocol}docs.${hostname}${path}`;
    }
    
    return match;
  });
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns "N/A" if the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Check for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (match && match[3]) {
    return match[3];
  }
  
  return 'N/A';
}