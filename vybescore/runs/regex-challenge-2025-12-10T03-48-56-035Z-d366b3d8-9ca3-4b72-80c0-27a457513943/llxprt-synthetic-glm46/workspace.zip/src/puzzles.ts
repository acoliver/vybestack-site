/**
 * Finds words starting with the given prefix, excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]]/g, '$&');
  
  // Create a pattern to match words with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9_]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
}

/**
 * Finds occurrences of token that appear after a digit and not at string start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '$&');
  
  // Pattern to find token after a digit (not at start)
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validates passwords against strong password criteria.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (/\d/.test(value) === false) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/]/.test(value)) return false;
  
  // Check for immediate repeated sequences (pattern repeats, like abab)
  const repeatedPattern = /(..).*\1/;
  if (repeatedPattern.test(value)) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses while not matching IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex pattern (simplified but effective)
  // This matches most forms of IPv6 including shorthand :: notation
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9]))/;
  
  // Check for IPv4 pattern first to avoid false positives
  const ipv4Pattern = /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check for IPv6 but not IPv4
  return ipv6Pattern.test(value) && !ipv4Pattern.test(value);
}