#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData } from '../types.js';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format' && i + 1 < argv.length) {
      format = argv[i + 1];
      i++;
    } else if (arg === '--output' && i + 1 < argv.length) {
      output = argv[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('--format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error('Unsupported format');
    process.exit(1);
  }

  return { dataFile, format, output, includeTotals };
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: "entries[${i}]" must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: "entries[${i}].label" must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: "entries[${i}].amount" must be a number`);
    }
  }
}

function readAndParseJSON(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.startsWith('JSON')) {
        console.error(`Error: ${error.message}`);
      } else {
        console.error(`Error reading file: ${error.message}`);
      }
    } else {
      console.error('Error reading or parsing file');
    }
    process.exit(1);
  }
}

function formatReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return formatMarkdown(data, { includeTotals });
    case 'text':
      return formatText(data, { includeTotals });
    default:
      console.error('Unsupported format');
      process.exit(1);
  }
}

// Main execution
const args = parseArguments(process.argv);
const reportData = readAndParseJSON(args.dataFile);
const formattedOutput = formatReport(reportData, args.format, args.includeTotals);

if (args.output) {
  try {
    writeFileSync(args.output!, formattedOutput);
  } catch (error) {
    console.error(`Error writing to file: ${args.output}`);
    process.exit(1);
  }
} else {
  process.stdout.write(formattedOutput);
}