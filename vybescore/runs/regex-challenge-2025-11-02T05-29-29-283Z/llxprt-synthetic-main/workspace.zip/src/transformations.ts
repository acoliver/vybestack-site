/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure we have the right spacing between sentences
  // Insert exactly one space after sentence terminators if missing
  // Then collapse multiple spaces into one
  let normalized = text.replace(/([.!?])(?=\S)/g, '$1 ');
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Process the string character by character to handle proper sentence capitalization
  let result = '';
  let inSentence = false;
  let needSpace = false;
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized.charAt(i);
    
    // Check for sentence terminators
    if (/[.!?]/.test(char)) {
      result += char;
      inSentence = false;
      needSpace = true;
      continue;
    }
    
    // Handle spacing after terminators
    if (needSpace && char === ' ') {
      result += char;
      needSpace = false;
      continue;
    } else if (needSpace) {
      // Missing space, insert it
      result += ' ' + char;
      needSpace = false;
      continue;
    }
    
    // Capitalize the first character of each sentence
    if (!inSentence && /\S/.test(char)) {
      result += char.toUpperCase();
      inSentence = true;
    } else {
      result += char;
    }
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches most common URL formats
  // This pattern matches:
  // - Protocol (http, https, ftp, etc.)
  // - Optional www
  // - Domain name with subdomains
  // - Optional port
  // - Path, query string, and fragment
  const urlPattern = /\b((?:https?|ftp):\/\/(?:www\.)?[^\s/$.?#].[^\s]*|www\.[^\s/$.?#].[^\s]*)/gi;
  
  // Find all matches
  const matches = text.match(urlPattern);
  
  if (!matches) {
    return [];
  }
  
  // Clean each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like . , ; : ) ] } ? ! etc.
    return url.replace(/[.,;:)\]\}\?!]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://, but not https://
  // Using a negative lookahead to ensure we don't match https://
  const httpPattern = /http:\/\/(?!https:)/gi;
  return text.replace(httpPattern, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This function handles specific URL transformations:
  // 1. Always upgrade http to https
  // 2. If path starts with /docs/, rewrite host to docs.example.com
  // 3. Skip host rewrite when path contains dynamic hints or legacy extensions
  
  // Match http URLs to http://example.com pattern
  // Negative lookahead to ensure we don't match https
  const httpUrlPattern = /http:\/\/(?!https:)([^\/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlPattern, (match, host, path = '') => {
    // Make sure path is present, if not we still upgrade the scheme
    if (!path) path = '/';
    
    // Legacy extensions that should prevent host rewrite
    const legacyExtensionPattern = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i;
    
    // Dynamic hints that should prevent host rewrite
    const hasDynamicHints = /\/cgi-bin\/|\?|&|=/i.test(path);
    
    // Check if we should skip the host rewrite
    const shouldSkipHostRewrite = legacyExtensionPattern.test(path) || hasDynamicHints;
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    // Always upgrade scheme to https://
    let newUrl = `https://${host}${path}`;
    
    // If it's a docs path and we should not skip the host rewrite
    if (isDocsPath && !shouldSkipHostRewrite) {
      // Extract the full URL (including protocol) to do the replacement
      // We need to ensure we're only modifying the host part, not the entire URL
      let domainHost = host;
      
      // For example.com -> docs.example.com
      // For subdomain.example.com -> docs.subdomain.example.com
      // We're preserving everything except the first domain segment
      const hostParts = host.split('.');
      if (hostParts.length >= 2) {
        domainHost = `docs.${hostParts.join('.')}`;
      } else {
        domainHost = `docs.${host}`;
      }
      
      newUrl = `https://${domainHost}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  // Month: 01-12
  // Day: 01-31 (simplified, doesn't account for month-specific max days)
  // Year: 4 digits
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  // Extract components
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string to maintain formatting
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let maxDay = daysInMonth[month - 1];
  
  // Check for leap year for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    // Leap year if divisible by 4, but not by 100 unless also by 400
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear) {
      maxDay = 29;
    }
  }
  
  if (day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
