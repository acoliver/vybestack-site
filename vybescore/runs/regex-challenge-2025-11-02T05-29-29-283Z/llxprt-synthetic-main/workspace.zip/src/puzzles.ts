/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex usage
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find words starting with the prefix
  // \b ensures we match whole words only
  // [a-zA-Z]+ matches the rest of the word
  const prefixedWordsPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(prefixedWordsPattern);
  
  if (!matches) {
    return [];
  }
  
  // Create a Set of exceptions for faster lookup (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Filter out exceptions
  const filteredWords = matches.filter(word => 
    !exceptionsSet.has(word.toLowerCase())
  );
  
  // Sort and remove duplicates
  return [...new Set(filteredWords)].sort((a, b) => a.localeCompare(b));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Get indices of all matches for detailed verification
  const result: string[] = [];
  let match;
  const tokenPattern = new RegExp(escapedToken, 'g');
  
  while ((match = tokenPattern.exec(text)) !== null) {
    const index = match.index;
    
    // Skip if at the beginning of the string
    if (index === 0) {
      continue;
    }
    
    // Check if the character before the token is a digit
    const precedingChar = text.charAt(index - 1);
    if (/\d/.test(precedingChar)) {
      // Include the preceding digit in the result
      result.push(precedingChar + match[0]);
    }
  }
  
  return result;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex catches patterns where a sequence of 2+ characters appears twice in a row
  // e.g., abab, abcabc, xyxyxy, etc.
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Additional check for consecutive repeated characters (e.g., aaa, 111)
  // This is less strict than the repeated sequence check above, but catches obvious weak patterns
  const consecutiveRepeats = /(.)\1{2,}/;
  if (consecutiveRepeats.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches:
  // - Full IPv6 address (8 groups of 4 hex digits)
  // - Compressed IPv6 with ::
  // - Leading zeros omitted
  // - IPv4 embedded in IPv6
  // But excludes IPv4 addresses
  
  // First, check if it might be an IPv4 address and exclude it
  // IPv4 pattern: 4 numbers (0-255) separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern that matches various forms
  // This pattern matches most valid IPv6 formats
  const ipv6Pattern = /((?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9]))/;
  
  // Test for IPv6 pattern
  return ipv6Pattern.test(value);
}