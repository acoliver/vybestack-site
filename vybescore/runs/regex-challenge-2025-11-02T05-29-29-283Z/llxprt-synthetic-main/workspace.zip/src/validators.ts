export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern that validates:
  // - Local part: allowing letters, digits, +, -, ., underscores, and apostrophes
  // - No consecutive dots
  // - No leading/trailing dots
  // - Domain: letters, digits, hyphens (no underscores)
  // - Top-level domain: at least 2 letters
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional check for consecutive dots in the entire email
  if (/\.\./.test(value)) {
    return false;
  }
  
  // Check if local part starts or ends with a dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check if domain has underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Run the primary pattern test
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first for easy validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for minimum length - must have at least 10 digits (US phone number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // For longer numbers, check if they start with country code +1
  let actualPhoneNumber = digitsOnly;
  if (digitsOnly.length > 10 && digitsOnly.startsWith('1')) {
    actualPhoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length > 10 && !digitsOnly.startsWith('1')) {
    // Too many digits but not starting with country code
    return false;
  }
  
  // At this point, actualPhoneNumber should be exactly 10 digits
  if (actualPhoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = actualPhoneNumber.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Now validate the format using regex
  // Formats we support:
  // - (212) 555-7890
  // - 212-555-7890
  // - 2125557890
  // - +1 212 555 7890
  // - +1(212)555-7890
  const usPhonePattern = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)?\d{3}[\s-]?\d{4}$/;
  
  return usPhonePattern.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Argentine phone pattern:
  // Optional +54 country code
  // When country code is omitted, must start with 0 (trunk prefix)
  // Optional 9 (mobile indicator)
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits
  const argPhonePattern = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  // Check the basic pattern first
  if (!argPhonePattern.test(cleanValue)) {
    return false;
  }
  
  // More detailed validation
  let digits = cleanValue;
  
  // Check if includes country code
  const hasCountryCode = cleanValue.startsWith('+54');
  if (hasCountryCode) {
    digits = cleanValue.substring(3); // Remove +54
  }
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !digits.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Check for mobile indicator (9)
  const isMobile = digits.startsWith('9');
  if (isMobile) {
    digits = digits.substring(1);
  }
  
  // Now digits should start with area code
  if (!digits) return false;
  
  // Extract area code (first 2-4 digits)
  let areaCodeLength = 0;
  for (let i = 2; i <= 4 && i < digits.length; i++) {
    const subscriberLength = digits.length - i;
    if (subscriberLength >= 6 && subscriberLength <= 8) {
      areaCodeLength = i;
      break;
    }
  }
  
  if (areaCodeLength === 0) return false;
  
  const areaCode = digits.substring(0, areaCodeLength);
  const subscriberNumber = digits.substring(areaCodeLength);
  
  // Area code must not start with 0
  if (areaCode.startsWith('0')) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation pattern:
  // Allow unicode letters (\p{L}), including accented characters
  // Allow apostrophes and hyphens
  // Allow spaces between name parts
  // Reject: digits, symbols, and special characters like @, #, $, etc.
  const namePattern = /^[\p{L}']+([\p{L}'\- ]*[\p{L}'])?$/u;
  
  // Additional check for names that start or end with hyphen or apostrophe
  if (/^[ '\-]|[ '\-]$/.test(value)) {
    return false;
  }
  
  // Check for consecutive non-letter characters
  if (/[ '\-]{2,}/.test(value)) {
    return false;
  }
  
  // Ensure the name contains at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return namePattern.test(value);
}

/**
 * Helper function to run Luhn algorithm checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let doubleDigit = false;

  // Process each digit from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9; // Sum the digits or subtract 9
      }
    }

    sum += digit;
    doubleDigit = !doubleDigit;
  }

  // Valid if sum modulo 10 is 0
  return (sum % 10) === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens first
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Check if we have only digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check length (13-19 digits for common card types)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check Visa pattern (starts with 4, length 13 or 16)
  const visaPattern = /^4\d{12}(\d{3})?$/;
  if (visaPattern.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Check Mastercard pattern (starts with 51-55, 2221-2720, length 16)
  const mcPattern = /^((5[1-5]\d{4})|(2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{3}))\d{10}$/;
  if (mcPattern.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Check American Express pattern (starts with 34 or 37, length 15)
  const amexPattern = /^3[47]\d{13}$/;
  if (amexPattern.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // If none of the specific patterns matched, it's an unsupported card type
  return false;
}
