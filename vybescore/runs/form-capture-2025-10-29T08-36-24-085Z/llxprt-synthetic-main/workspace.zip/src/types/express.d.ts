declare global {
  namespace Express {
    interface Request {
      body: {
        [key: string]: string;
      };
      query: {
        [key: string]: string | string[];
      };
    }
    
    interface Response {
      render(template: string, locals?: Record<string, unknown>): void;
      redirect(status: number, url: string): void;
      status(code: number): Response;
    }
  }
}

export {};