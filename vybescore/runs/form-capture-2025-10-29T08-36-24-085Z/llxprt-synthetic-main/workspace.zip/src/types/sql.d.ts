declare module 'sql.js' {
  export interface Database {
    close(): void;
    export(): Uint8Array;
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
  }
  
  export interface Statement {
    bind(params: unknown[]): void;
    step(): boolean;
    getAsObject(): { [key: string]: unknown };
    free(): void;
  }
  
  export interface InitOptions {
    locateFile: (file: string) => string;
  }
  
  export default function initSqlJs(options?: InitOptions): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
  
  export const SqlJs: {
    Database: new (data?: Uint8Array) => Database;
  };
}

// Re-export for use in our code
export interface Database {
  close(): void;
  export(): Uint8Array;
  run(sql: string, params?: unknown[]): void;
  prepare(sql: string): Statement;
}

export interface Statement {
  bind(params: unknown[]): void;
  step(): boolean;
  getAsObject(): { [key: string]: unknown };
  free(): void;
}