import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
/// <reference path="./types/sql.d.ts" />
// @ts-expect-error: sql.js doesn't have type definitions
import initSqlJs from 'sql.js';
/// <reference path="./types/sql.d.ts" />
import { Database } from './types/sql.js';

// Get the current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define types for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define validation errors
interface ValidationErrors {
  [key: string]: string;
}

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Configure middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files from public directory
app.use('/public', express.static(path.join(__dirname, '../public')));

// Database instance
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Function to initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read and execute schema
      const schema = fs.readFileSync(
        path.join(__dirname, '../db/schema.sql'),
        'utf8'
      );
      if (db) {
        db.run(schema);
      }
      
      // Save initial database
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Function to save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Form validation function
function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};
  
  // Required field validations
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State / Province / Region is required';
  }
  
  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal / Zip code is required';
  }
  
  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email regex validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone number validation: digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s()\-]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }
  
  // Postal code validation: allow alphanumeric characters, spaces, dashes
  // This handles UK formats like "SW1A 1AA" and Argentine formats like "C1000" or "B1675"
  if (data.postalCode.trim()) {
    const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalCodeRegex.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: null, values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };
  
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    // If validation fails, re-render the form with errors
    res.status(400).render('form', {
      errors: Object.values(errors),
      values: formData,
    });
    return;
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    // Insert form data into the database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.bind([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    stmt.step();
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error saving form data:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'there';
  res.render('thank-you', { firstName });
});

// Function to gracefully shut down the server
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    db.close();
    db = null;
  }
  
  if (server) {
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', gracefulShutdown);

// Start the server
let server: import('http').Server | null = null;
async function startServer() {
  await initializeDatabase();
  
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Handle unhandled rejections
  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    gracefulShutdown();
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export default app;