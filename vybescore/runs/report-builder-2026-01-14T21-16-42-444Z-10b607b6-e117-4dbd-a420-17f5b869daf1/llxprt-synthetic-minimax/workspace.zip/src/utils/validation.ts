import { ReportData } from '../types/index.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as Record<string, unknown>;
  
  // Validate title
  if (typeof report.title !== 'string' || !report.title.trim()) {
    throw new Error('Invalid JSON: "title" must be a non-empty string');
  }

  // Validate summary
  if (typeof report.summary !== 'string' || !report.summary.trim()) {
    throw new Error('Invalid JSON: "summary" must be a non-empty string');
  }

  // Validate entries
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  if (report.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" must be a non-empty array');
  }

  // Validate each entry
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i + 1} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error(`Invalid JSON: entry ${i + 1} "label" must be a non-empty string`);
    }

    if (typeof entryObj.amount !== 'number' || !isFinite(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry ${i + 1} "amount" must be a finite number`);
    }
  }

  // Type assertion is safe after validation
  return data as ReportData;
}

export function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}