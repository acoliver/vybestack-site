import { readFileSync } from 'fs';
import { join } from 'path';
import { ReportData, RenderOptions } from '../types/index.js';
import { validateReportData } from '../utils/validation.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const args = argv.slice(2);
  const dataPath = args[0];

  if (!dataPath || dataPath.startsWith('--')) {
    console.error('Error: data file path is required as the first argument');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: unknown option '${arg}'`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadAndValidateData(dataPath: string): ReportData {
  try {
    const fullPath = join(process.cwd(), dataPath);
    const fileContent = readFileSync(fullPath, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    return validateReportData(jsonData);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: data file '${dataPath}' not found`);
      } else if (error.message.includes('JSON')) {
        console.error('Error: invalid JSON format');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: failed to read data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
      process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    const fullPath = join(process.cwd(), outputPath);
    try {
      import('fs').then(fs => {
        fs.writeFileSync(fullPath, content, 'utf-8');
      });
    } catch (error) {
      console.error(`Error: failed to write output file '${outputPath}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(content + '\n');
  }
}

// Main execution
const args = parseArgs(process.argv);
const data = loadAndValidateData(args.dataPath);
const report = renderReport(data, args.format, { includeTotals: args.includeTotals });
writeOutput(report, args.outputPath);
