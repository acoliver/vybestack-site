import { describe, expect, it } from 'vitest';
import { execSync } from 'child_process';

function normalize(text: string): string {
  return text.trim().replace(/\s+/g, ' ');
}

describe('report CLI (public smoke)', () => {
  it('should render markdown format without totals', () => {
    const result = execSync('node dist/cli/report.js fixtures/data.json --format markdown', { encoding: 'utf-8' });
    const expectedText = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('should render markdown format with totals', () => {
    const result = execSync('node dist/cli/report.js fixtures/data.json --format markdown --includeTotals', { encoding: 'utf-8' });
    const expectedText = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('should render text format without totals', () => {
    const result = execSync('node dist/cli/report.js fixtures/data.json --format text', { encoding: 'utf-8' });
    const expectedText = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('should render text format with totals', () => {
    const result = execSync('node dist/cli/report.js fixtures/data.json --format text --includeTotals', { encoding: 'utf-8' });
    const expectedText = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34`;

    expect(normalize(result)).toBe(normalize(expectedText));
  });
});
