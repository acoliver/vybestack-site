import { ReportData } from '../types/report.js';
import { readFileSync } from 'node:fs';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} is missing or has invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry at index ${i} is missing or has invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

export function parseJsonFile(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(content);
    return validateReportData(parsed);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.includes('ENOENT')) {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}