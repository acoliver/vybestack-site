#!/usr/bin/env node

import { parseJsonFile } from '../utils/validation.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';
import { ReportOptions, OutputFormat } from '../types/report.js';
import { writeFileSync, existsSync } from 'node:fs';

interface CliArgs {
  dataFile: string;
  format: OutputFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const validFormats: OutputFormat[] = ['markdown', 'text'];
  
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  if (!dataFile) {
    throw new Error('Data file path is required');
  }

  // Find format flag
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex >= args.length - 1) {
    throw new Error('--format flag requires a value');
  }

  const format = args[formatIndex + 1] as OutputFormat;
  if (!validFormats.includes(format)) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${validFormats.join(', ')}`);
  }

  // Find output flag
  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;

  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function getRenderer(format: OutputFormat) {
  switch (format) {
    case 'markdown':
      return markdownRenderer;
    case 'text':
      return textRenderer;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Validate input file exists
    if (!existsSync(args.dataFile)) {
      throw new Error(`File not found: ${args.dataFile}`);
    }

    // Parse and validate JSON data
    const data = parseJsonFile(args.dataFile);

    // Get appropriate renderer
    const renderer = getRenderer(args.format);

    // Render report
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    const output = renderer.render(data, options);

    // Output to file or stdout
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}