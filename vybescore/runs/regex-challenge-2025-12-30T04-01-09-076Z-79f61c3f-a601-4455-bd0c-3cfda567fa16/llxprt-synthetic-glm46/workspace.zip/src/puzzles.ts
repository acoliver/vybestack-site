/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Build regex to find words with the given prefix
  const prefixWithBoundary = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b(${prefixWithBoundary}[a-zA-Z]*)\\b`, 'g');

  const matches = text.match(wordRegex) || [];
  const uniqueMatches = new Set(matches);

  // Filter out exceptions (case-insensitive)
  const results = Array.from(uniqueMatches).filter(word =>
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );

  return results;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use regex to match digit + token pattern
  const tokenRegex = new RegExp(`\\d(${escapedToken})`, 'g');

  const results = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the full match including the digit
    results.push(match[0]);
  }
  
  return results;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol
  if (!/[!@#$%^&*()_+=\n{};':"\\|,.<>]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab should fail)
  // Look for patterns where a 2-4 character sequence repeats immediately
  if (/(.{2,4})\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Standard IPv6 patterns
  const fullIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;

  // IPv6 with :: shorthand (compressing zeros)
  const shorthandIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){0,6}:[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{1,4}){0,6}/;

  // IPv6 with IPv4 embedded (like ::ffff:192.168.0.1)
  const embeddedIPv4Pattern = /:(?::ffff:(?:\d{1,3}\.){3}\d{1,3})/;

  // Check for IPv4 addresses first to exclude them
  const ipv4Pattern = /b(?:d{1,3}.){3}d{1,3}b/;

  // If we find an IPv4 address pattern, this doesn't count as IPv6
  if (ipv4Pattern.test(value)) {
    // But it could be IPv6 with embedded IPv4
    return embeddedIPv4Pattern.test(value);
  }

  return fullIPv6Pattern.test(value) || shorthandIPv6Pattern.test(value) || embeddedIPv4Pattern.test(value);
}