/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text.replace(/(^\s*|[.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    // Ensure exactly one space after sentence-ending punctuation
    const separator = /[.!?]$/.test(punctuation) ? punctuation.trim() + ' ' : punctuation;
    return separator + letter.toUpperCase();
  }).replace(/\s+/g, ' ').replace(/\s+[.!?]/g, (match) => match.trim());
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs with common protocols (http, https, ftp)
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like .,?! etc.
  return matches.map(url => url.replace(/[.,;!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:/g, 'https:');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http://example.com structure
  const urlPattern = /(http:\/\/)([^\/:]+)(\/.+?)(?=[\s]|$)/g;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Check if this should only upgrade scheme but not rewrite host
    const shouldNotRewriteHost = /[?.&]/.test(path) || // Contains query string
                                /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=\/|$)/.test(path) || // Has dynamic file extension
                                /\/cgi-bin\//.test(path); // Has cgi-bin
    
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // If path starts with /docs/, and we shouldn't skip host rewrite
    if (path.startsWith('/docs/') && !shouldNotRewriteHost) {
      // Rewrite to docs.example.com
      return newProtocol + 'docs.' + domain + path;
    } else {
      // Just upgrade the scheme
      return newProtocol + domain + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for February
  if (month === 2) {
    // Check leap year
    const isLeapYear = (parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || parseInt(year) % 400 === 0;
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  }
  // April, June, September, November have 30 days
  else if ([4, 6, 9, 11].includes(month) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
