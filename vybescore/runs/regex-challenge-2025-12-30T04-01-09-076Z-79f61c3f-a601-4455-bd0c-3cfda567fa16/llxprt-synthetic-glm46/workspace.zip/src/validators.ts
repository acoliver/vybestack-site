export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC standards.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid formats.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[\w.%+-]+@[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (/\.\./.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting formats like (212) 555-7890, 212-555-7890, 2125557890
 * Accepts optional +1 prefix. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (should be at least 10 digits)
  if (digits.length < 10) {
    return false;
  }
  
  // Remove country code if present
  const phoneNumber = digits.length > 10 ? digits.slice(-10) : digits;
  
  // Ensure we have exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // US phone validation with country code
  // Format: +1 optional, area code (3 digits), prefix (3 digits), line number (4 digits)
  // Area code cannot start with 0 or 1
  const phoneRegex = /^(?:\+1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers supporting mobile and landline formats.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
// When country code is omitted, must begin with trunk prefix 0
  if (!value.startsWith('+54') && !value.replace(/[-\s]/g, '').startsWith('0')) {
    return false;
  }
  
  // Argentine phone regex
  // Optional country code (+54), optional trunk prefix (0), optional mobile indicator (9)
  // Area code (2-4 digits, can't start with 0), subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = value.replace(/[-\s]/g, '').match(argentinePhoneRegex);
  if (!match) return false;
  
  // Validate area code length (2-4 digits) and subscriber number length (6-8 digits)
  const areaCode = match[1] || '';
  const subscriberNumber = match[2] || '';
  
  return areaCode.length >= 2 && areaCode.length <= 4 && 
         subscriberNumber.length >= 6 && subscriberNumber.length <= 8;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Names can contain unicode letters including accented characters and non-ASCII letters
  // Allow spaces, apostrophes, and hyphens
  // Should not contain digits or symbols
  const nameRegex = /^[\p{L}][\p{L}\p{M}\s'-]*[\p{L}]$/u;
  
  return nameRegex.test(value);
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex1 = /^5[1-5]\d{14}$/;
  const mastercardRegex2 = /^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanValue) && 
      !mastercardRegex1.test(cleanValue) && 
      !mastercardRegex2.test(cleanValue) && 
      !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Luhn checksum algorithm
  let sum = 0;
  const cleanValueForValidation = cleanValue;
  const digits = cleanValueForValidation.split('').map(Number);
  
  for (let i = digits.length - 1; i >= 0; i--) {
    const digit = digits[i];
    if ((digits.length - i) % 2 === 0) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
  }
  
  return sum % 10 === 0;
}