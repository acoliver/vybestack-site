/**
 * Capitalize the first character of each sentence, preserving spacing rules:
 * - Capitalizes first letter after .?!
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // Common English abbreviations to handle
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Mt', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e'];
  const abbrevPattern = abbreviations.join('|');
  
  // Add a space after sentence endings that don't have one
  let result = text.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Collapse multiple spaces into one
  result = result.replace(/\s+/g, ' ').trim();
  
  // Capitalize sentences, careful not to capitalize after abbreviations
  const capitalizeRegex = new RegExp(`(?:^|(?<!\\b(?:${abbrevPattern})\\.)[.!?]\\s+|^\\b)([a-z])`, 'gi');
  
  result = result.replace(capitalizeRegex, (match) => match.toUpperCase());
  
  return result;
}

/**
 * Extract all URLs from the text, removing trailing punctuation if present.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https and domain names
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+|www\.[^\s<>"']+/gi;
  
  // Find all URL matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)}"']+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but skip if already https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/:
 * - Always upgrade to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints like cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // First, ensure all URLs use HTTPS
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Legacy extensions to skip (cgi-bin, query strings, etc.)
  const legacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i;
  
  // Dynamic path indicators (skip host rewrite)
  const dynamicIndicators = [/\bcgi-bin\b/i, /[?&=]/];
  
  // Match both http and https URLs to example.com
  const urlRegex = /\bhttps?:\/\/example\.com(\/[^\s]*)?/gi;
  
  result = result.replace(urlRegex, (match, path) => {
    if (!path) return `https://example.com`;
    
    // Check if we should skip host rewrite (dynamic content)
    const isDynamic = dynamicIndicators.some(indicator => 
      indicator.test(path) || indicator.test(match)
    ) || legacyExtensions.test(path);
    
    if (isDynamic) {
      // Just ensure https, no host rewrite
      return match.replace(/^http:/, 'https:');
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
    
    // Default: ensure https with same host
    return match.replace(/^http:/, 'https:');
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // mm/dd/yyyy format with strict validation
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate day/month combinations (basic validation)
  const validDays = {
    1: 31, 2: (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 29 : 28,
    3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31,
    11: 30, 12: 31
  };
  
  if (day < 1 || day > validDays[month as keyof typeof validDays]) {
    return 'N/A';
  }
  
  return year.toString();
}