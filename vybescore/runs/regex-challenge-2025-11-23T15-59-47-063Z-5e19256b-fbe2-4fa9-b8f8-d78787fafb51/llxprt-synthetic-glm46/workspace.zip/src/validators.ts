export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Robust email validation supporting:
 * - Standard formats: user@domain.com, user+tag@domain.co.uk
 * - International domain names
 * - Rejects: double dots, trailing dots, domains with underscores, obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check using a comprehensive regex
  // Local part: alphanumerics and special chars, but not starting/ending with dot
  // Domain part: no underscores, valid TLD formats
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?<!\.)@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional validation checks
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject consecutive dots in entire email
  if (value.includes('..') || value.includes('.@') || value.includes('@.')) {
    return false;
  }
  
  // Reject domain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation supporting:
 * - Formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Rejects: impossible area codes (starting with 0 or 1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Allow for optional country code
  let digits = cleaned;
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1);
  }
  
  // Should have exactly 10 digits for a valid US number
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Additional check for invalid area codes (like 555 historically used for examples)
  // but this could be valid in some cases, so keeping it flexible
  
  return true;
}

/**
 * Argentine phone number validation covering mobile/landline formats:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits (leading digit 1-9)
 * - Subscriber: 6-8 digits
 * - Separators: spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Comprehensive regex for Argentine phone numbers
  const argentinaPhoneRegex = /^(\+54)?0?(9)?(\d{2,4})(\d{6,8})$/;
  
  const match = normalized.match(argentinaPhoneRegex);
  if (!match) {
    return false;
  }
  
  const hasCountryCode = !!match[1];
  const hasMobilePrefix = !!match[2];
  const areaCode = match[3];
  const subscriber = match[4];
  
  // Area code must be 2-4 digits and start with 1-9 (not 0)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !normalized.startsWith('0')) {
    return false;
  }
  
  // Ensure proper structure: mobile prefix (9) should only appear after country code or trunk prefix
  if (hasMobilePrefix) {
    // If there's a mobile prefix (9), it must be preceded by country code or trunk prefix
    if (!hasCountryCode && !normalized.startsWith('09')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Personal name validation allowing:
 * - Unicode letters and accented characters
 * - Apostrophes, hyphens, spaces
 * - Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Regex allowing unicode letters, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u024F]/.test(value)) {
    return false;
  }
  
  // Reject names with consecutive punctuation
  if (/''|--/.test(value)) {
    return false;
  }
  
  // Reject names starting or ending with punctuation
  if (/^['\s-]|['\s-]$/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Credit card validation:
 * - Accepts Visa/Mastercard/AmEx prefixes and lengths
 * - Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and non-digit characters
  const normalized = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits for most cards)
  if (normalized.length < 13 || normalized.length > 19) {
    return false;
  }
  
  // Card prefix patterns
  const visaRegex = /^4/;
  const mastercardRegex = /^5[1-5]|^2[2-7]/;
  const amexRegex = /^3[47]/;
  
  // Check if card matches any supported pattern
  if (!visaRegex.test(normalized) && !mastercardRegex.test(normalized) && !amexRegex.test(normalized)) {
    return false;
  }
  
  // Length checks for specific card types
  if (visaRegex.test(normalized) && (normalized.length !== 13 && normalized.length !== 16)) {
    return false;
  }
  
  if (mastercardRegex.test(normalized) && normalized.length !== 16) {
    return false;
  }
  
  if (amexRegex.test(normalized) && normalized.length !== 15) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(normalized);
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}