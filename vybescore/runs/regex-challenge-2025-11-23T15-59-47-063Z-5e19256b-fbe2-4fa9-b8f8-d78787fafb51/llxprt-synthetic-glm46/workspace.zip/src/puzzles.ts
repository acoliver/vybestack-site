/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matching words
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and unique values
  return [...new Set(matches.filter(word => !exceptions.includes(word.toLowerCase())))];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a more direct approach to match digit+token pattern
  // We need to return the full match (digit+token) as expected by the test
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  // Return unique full matches (digit+token)
  return [...new Set(matches)];
}

/**
 * Strong password validation requiring:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value); // Any non-alphanumeric character
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212, etc.)
  // This pattern finds any sequence of 2 characters repeated consecutively
  const repeatedSequenceRegex = /(.{2,4})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns to match:
  // 1. Full format: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // 2. Shorthand: 2001:db8:85a3::8a2e:370:7334
  // 3. Loopback: ::1
  // 4. Unspecified: ::
  // 5. IPv4 embedded: ::ffff:192.0.2.128
  
  // IPv6 regex patterns
  // Full format with 8 groups of 4 hex digits
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand with :: compression
  const shorthandIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/;
  
  // Loopback or unspecified
  const loopbackRegex = /\b::\d{0,3}\b/;
  
  // IPv4 embedded in IPv6
  const ipv4EmbeddedRegex = /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check for IPv6 patterns first
  const isIPv6 = (
    fullIPv6Regex.test(value) ||
    shorthandIPv6Regex.test(value) ||
    loopbackRegex.test(value) ||
    ipv4EmbeddedRegex.test(value)
  );
  
  // If not IPv6, return false immediately
  if (!isIPv6) {
    return false;
  }
  
  // If it matches IPv6 patterns, also check if it's an IPv4 address
  // and exclude it if it is
  const ipv4Regex = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  return true;
}