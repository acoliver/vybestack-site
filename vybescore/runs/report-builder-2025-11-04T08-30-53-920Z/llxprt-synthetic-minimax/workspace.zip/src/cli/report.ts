import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
function parseArgs(argv: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Error: Missing required arguments');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Parse remaining arguments
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

// Validate and parse JSON data
function validateData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: must be an object');
  }
  
  const reportData = data as Partial<ReportData>;
  
  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
  }
  
  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }
  
  const entries = reportData.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }
    
    const typedEntry = entry as Partial<{ label: string; amount: number }>;
    
    if (!typedEntry.label || typeof typedEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label must be a string`);
    }
    
    if (typeof typedEntry.amount !== 'number' || isNaN(typedEntry.amount)) {
      throw new Error(`Invalid JSON: entries[${index}].amount must be a number`);
    }
    
    return {
      label: typedEntry.label,
      amount: typedEntry.amount
    };
  });
  
  return {
    title: reportData.title,
    summary: reportData.summary,
    entries
  };
}

// Read and parse JSON file
function readDataFile(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content);
    return validateData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found: ${path}`);
      } else if (error.message.includes('JSON')) {
        console.error(`Error: ${error.message}`);
      } else {
        console.error(`Error reading file: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read or parse file');
    }
    process.exit(1);
  }
}

// Main execution
function main(): void {
  const args = parseArgs(process.argv);
  const { dataPath, format, outputPath, includeTotals } = args;
  
  // Load and validate data
  const reportData = readDataFile(dataPath);
  
  // Select formatter
  let formatter: { format: (data: ReportData, options: RenderOptions) => string };
  
  if (format === 'markdown') {
    formatter = renderMarkdown;
  } else if (format === 'text') {
    formatter = renderText;
  } else {
    console.error(`Error: Unsupported format: ${format}`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }
  
  // Render report
  const output = formatter.format(reportData, { includeTotals });
  
  // Write output
  if (outputPath) {
    try {
      writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing to file: ${error.message}`);
      } else {
        console.error('Error: Failed to write output file');
      }
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Run the CLI
main();