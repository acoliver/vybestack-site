import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        // Fixed: Added page and limit parameters to the request
        const url = `/inventory?page=${page}&limit=${limit}`;
        const response = await fetch(url);
        if (!response.ok) {
          // Handle validation errors from the server
          const errorData = await response.json();
          throw new Error(errorData.error || `Request failed with status ${response.status}`);
        }
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    // Fixed: Always load data when page or limit changes
    load();

    return () => {
      cancelled = true;
    };
    // Fixed: Added page and limit to dependency array to trigger reloads
  }, [page, limit]);

  // Function to manually reset the state to idle for a fresh load
  const reset = () => setState(INITIAL_STATE);

  return { ...state, reset };
}
