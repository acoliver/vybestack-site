export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: alphanumeric + special chars (!#$%&'*+/=?^_`{|}~-), plus tags allowed
  // but no dots at start/end or consecutive dots
  // Domain part: no underscores, subdomains allowed
  
  // Check for invalid patterns first
  // Double dots, dots at start/end of local part
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Domain with underscores
  if (value.includes('@') && value.split('@')[1] && value.split('@')[1].includes('_')) {
    return false;
  }
  
  // Main email validation regex
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Normalize by removing common separators
  const cleaned = value.replace(/[\s\-.()]/g, '');
  
  // Check for optional +1 prefix
  const hasCountryCode = cleaned.startsWith('+1');
  let digitsOnly = hasCountryCode ? cleaned.substring(2) : cleaned;
  
  // If extensions are allowed, anything after # is ok
  if (options?.allowExtensions && digitsOnly.includes('#')) {
    const [mainPart] = digitsOnly.split('#');
    if (!/^\d+$/.test(mainPart)) return false;
    digitsOnly = mainPart;
  }
  
  // Verify it's all digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check minimum length (10 digits for US phone numbers)
  if (digitsOnly.length < 10) return false;
  
  // Extract area code and check it doesn't start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Main validation regex that matches common US phone formats
  const phoneRegex = /^(?:\+1\s*)?(?:\(\s*(\d{3})\s*\)|(\d{3}))[\s.-]*?(\d{3})[\s.-]*(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check for the main structure first
  // With country code: +54 [9] [area code] [subscriber]
  // Without country code: 0 [area code] [subscriber]
  const hasCountryCode = normalized.startsWith('+54');
  
  // Extract main components
  let mainNumber = normalized;
  if (hasCountryCode) {
    mainNumber = normalized.substring(3); // Remove +54
  }
  
  // Check for mobile indicator (9) after country code or trunk prefix
  const hasMobileIndicator = mainNumber.startsWith('9');
  if (hasMobileIndicator) {
    mainNumber = mainNumber.substring(1); // Remove mobile indicator
  }
  
  // Check for trunk prefix (0)
  const hasTrunkPrefix = mainNumber.startsWith('0');
  if (hasTrunkPrefix) {
    mainNumber = mainNumber.substring(1); // Remove trunk prefix
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode = '';
  let subscriberNumber = '';
  
  // Try 4-digit area code first
  if (mainNumber.length >= 8 && mainNumber.length <= 12) {
    // Try to extract area code (2-4 digits)
    for (let len = 4; len >= 2; len--) {
      const potentialAreaCode = mainNumber.substring(0, len);
      if (/^[1-9]\d{0,3}$/.test(potentialAreaCode)) {
        areaCode = potentialAreaCode;
        subscriberNumber = mainNumber.substring(len);
        break;
      }
    }
  }
  
  // Validate components
  if (!areaCode || !subscriberNumber) {
    return false;
  }
  
  // Area code validation (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]\d{0,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  // When country code is omitted, trunk prefix (0) must be present
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Basic structure validation - allows unicode letters, accents, apostrophes, hyphens, and spaces
  const basicFormat = /^[^\d\s][\p{L}\p{M}'\- ]+[^\d\s]$/u;
  
  // Check for valid structure and reject digits and symbols
  return basicFormat.test(value) && !/\d|[^\p{L}\p{M}'\- ]/u.test(value);
}

// Helper function to run Luhn checksum algorithm
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    // Double every second digit from the right
    if ((digits.length - 1 - i) % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2(22[1-9]|2[3-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any of the supported patterns
  const validPrefix = visaRegex.test(cardNumber) || mastercardRegex.test(cardNumber) || amexRegex.test(cardNumber);
  
  if (!validPrefix) return false;
  
  // Pass through Luhn checksum
  return runLuhnCheck(cardNumber);
}
