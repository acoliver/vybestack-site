/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern that matches words with the given prefix
  // \b ensures we're matching whole words
  // Escape the prefix to handle special regex characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}[\\w-]*`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    return !exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token to handle special regex characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern that matches the token only when:
  // 1. It's preceded by a digit (using lookbehind)
  // 2. It's not at the beginning of the string
  const pattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches and collect the full match including the preceding digit
  const matches = text.match(pattern);
  
  if (!matches) return [];
  
  // For each match, we need to find it again with the preceding digit
  const results = [];
  let match;
  
  // Create a more specific pattern to capture the digit + token
  const fullPattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  while ((match = fullPattern.exec(text)) !== null) {
    // Ensure we're not at the start of the string
    if (match.index > 0) {
      results.push(match[1]);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password validation according to policy:
  // - At least 10 characters
  // - One uppercase
  // - One lowercase
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., abab should fail)
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // Check for repeated sequences (pattern of 2 characters repeated immediately)
  const repeatedPattern = /(.{2})\1/;
  if (repeatedPattern.test(value)) return false;
  
  // Also check for repeating patterns like abab, abcabc, etc.
  const patternRepetition = /(.{3,})\1/;
  if (patternRepetition.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this is just an IPv4 address
  const ipv4Regex = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  
  // Extract potential IPv6 addresses from the text
  // This regex handles various IPv6 formats including shorthand notation
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|(?:[0-9a-fA-F]{1,4}:){6}[0-9a-fA-F]{1,4}:(?:\d{1,3}\.){3}\d{1,3}/g;
  
  // Look for IPv6 patterns in the text
  const matches = value.match(ipv6Regex);
  
  if (!matches) return false;
  
  // If we have matches, check if any of them are not just IPv4 addresses
  for (const match of matches) {
    // Clean up the match - remove surrounding characters that aren't part of the address
    const cleanMatch = match;
    
    // Skip if this is clearly just an IPv4 address
    if (ipv4Regex.test(cleanMatch)) {
      continue;
    }
    
    // Check if it has at least one colon (indicative of IPv6)
    if (cleanMatch.includes(':')) {
      return true;
    }
  }
  
  return false;
}
