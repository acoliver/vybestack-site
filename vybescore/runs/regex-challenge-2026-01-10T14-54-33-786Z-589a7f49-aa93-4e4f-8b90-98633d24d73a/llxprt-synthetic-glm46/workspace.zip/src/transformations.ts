/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Replace multiple sentence terminators with a single one to handle cases like "...?!?!?"
  const cleanedText = text.replace(/([.?!])\1+/g, '$1');
  
  // Split sentences by sentence terminators (.?!)
  const sentences = cleanedText.split(/([.?!])/);
  
  // Process each sentence fragment
  for (let i = 0; i < sentences.length; i++) {
    // Every odd index is a sentence terminator, every even index is sentence text
    if (i % 2 === 0) {
      // Trim leading spaces but keep track for later
      const spaceMatch = sentences[i].match(/^\s+/);
      const leadingSpaces = spaceMatch ? spaceMatch[0] : '';
      
      // Get the sentence content without leading spaces
      const sentenceContent = sentences[i].replace(/^\s+/, '');
      
      // Capitalize the first letter if it exists and is a letter
      if (sentenceContent) {
        sentences[i] = leadingSpaces + sentenceContent.charAt(0).toUpperCase() + sentenceContent.slice(1);
      }
    } else {
      // Ensure exactly one space after sentence terminators before next sentence
      if (i < sentences.length - 1) {
        sentences[i] += ' ';
      }
    }
  }
  
  // Join all parts back together
  return sentences.join('').replace(/\s{2,}/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches most common URL formats
  // Matches protocol://domain/path with optional ports, query strings, and fragments
  const urlRegex = /(?:https?:\/\/)(?:[\da-z.-]+)\.(?:[a-z.]{2,6})(?:[/\w.?%&=~#-]*)*/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) return [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using word boundaries to avoid replacing inside other text
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This will match: http://example.com/... 
  // And capture the protocol (http), the domain part (example.com), and the path
  const urlPattern = /(https?):\/\/(example\.com)(\/[^?\s]*)([^?\s]*)/gi;
  
  const rewrittenText = text.replace(urlPattern, (match, protocol, domain, path, rest) => {
    // Always upgrade to HTTPS
    protocol = 'https';
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    // Patterns that should prevent host rewrite
    const hasDynamicHints = /\/(cgi-bin)|(\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/i.test(path) ||
                             rest.includes('?') || rest.includes('&') || rest.includes('=');
    
    // Rewrite host if it's a docs path and doesn't contain any skip patterns
    const newDomain = (isDocsPath && !hasDynamicHints) ? 'docs.example.com' : domain;
    
    return `${protocol}://${newDomain}${path}${rest}`;
  });
  
  return rewrittenText;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with capturing groups
  const datePattern = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day/month combinations
  // Days in month: Jan(31), Feb(28/29), Mar(31), Apr(30), May(31), Jun(30), Jul(31), Aug(31), Sep(30), Oct(31), Nov(30), Dec(31)
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (February)
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  if (month === 2 && isLeapYear) {
    maxDays[1] = 29;
  }
  
  // Validate day is within range for the month
  if (day > maxDays[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
