import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let app: express.Application;
let serverModule: { start: () => Promise<express.Application>; close: () => Promise<void> };
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start the server
  serverModule = await import('../../dist/server.js');
  app = await serverModule.start();
});

afterAll(async () => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  if (serverModule && serverModule.close) {
    await serverModule.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.statusCode).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check form action
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit valid form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'john@example.com',
      phone: '+1 212-555-1234'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank you page
    expect(response.statusCode).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Database should be created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('displays thank you page with submitted name', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.statusCode).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Thank you');
    // The page should display some humorous text about data usage
    expect($('body').text()).toMatch(/data|information|stranger|internet/i);
  });
});