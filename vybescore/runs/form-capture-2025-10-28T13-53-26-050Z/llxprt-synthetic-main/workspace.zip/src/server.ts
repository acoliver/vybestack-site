import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { SqlJsDatabase, PreparedStatement } from './types.js';

// Import sql.js for WASM SQLite support
// @ts-expect-error - sql.js doesn't have full TypeScript definitions
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Interface for form submission data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Create Express app
const app = express();

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set up EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: SqlJsDatabase | null = null;

async function initializeDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();

    // Load existing database or create new one
    let databaseBuffer: Buffer | null = null;
    if (fs.existsSync(dbPath)) {
      databaseBuffer = fs.readFileSync(dbPath);
    }

    db = new SQL.Database(databaseBuffer) as SqlJsDatabase;

    // Create the submissions table if it doesn't exist
    const schema = fs.readFileSync(
      path.join(__dirname, '..', 'db', 'schema.sql'),
      'utf8'
    );
    if (db) {
      db.run(schema);
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Function to save database to disk
function saveDatabase() {
  try {
    if (db) {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved to disk');
    }
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.length >= 3;
}

function validateForm(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!formData.firstName.trim()) {
    errors.push('First name is required');
  }

  if (!formData.lastName.trim()) {
    errors.push('Last name is required');
  }

  if (!formData.streetAddress.trim()) {
    errors.push('Street address is required');
  }

  if (!formData.city.trim()) {
    errors.push('City is required');
  }

  if (!formData.stateProvince.trim()) {
    errors.push('State/Province/Region is required');
  }

  if (!formData.postalCode.trim()) {
    errors.push('Postal/Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }

  if (!formData.country.trim()) {
    errors.push('Country is required');
  }

  if (!formData.email.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!formData.phone.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Define routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { values: {}, errors: [] });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    // Return to form with errors and entered values
    return res.status(400).render('form', {
      values: formData,
      errors: validation.errors
    });
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `) as PreparedStatement;

    stmt.run(
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    );

    stmt.free();
    saveDatabase();

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.render('form', {
      values: formData,
      errors: ['An error occurred while processing your submission. Please try again.']
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the first name from the most recent submission
  // In a real app, we might use a session or query parameter
  // For simplicity, we'll fetch the most recent submission
  let firstName = 'friend';

  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      SELECT first_name FROM submissions 
      ORDER BY id DESC 
      LIMIT 1
    `) as PreparedStatement;
    const result = stmt.get();
    stmt.free();

    if (result && (result as { first_name: string }).first_name) {
      firstName = (result as { first_name: string }).first_name;
    }
  } catch (error) {
    console.error('Error fetching recent submission:', error);
  }

  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  await initializeDatabase();

  const server = app.listen(port, () => {
    console.log(`Friendly Form server running on http://localhost:${port}`);
  });

  // Handle graceful shutdown
  const shutdown = () => {
    console.log('Shutting down gracefully...');
    if (db) {
      db.close();
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return server;
}

// Export functions for testing
export const start = async () => {
  await initializeDatabase();
  return app;
};

export const close = async () => {
  if (db) {
    db.close();
  }
};

export const getApp = () => {
  return app;
};

// Start the server if running directly
if (import.meta.url === `file://${process.argv[1]}`) {
  // If running directly, start the server
  startServer();
}