// Define types for sql.js which doesn't have complete TypeScript definitions
export interface SqlJsDatabase {
  prepare(sql: string): PreparedStatement;
  run(sql: string, ...params: unknown[]): unknown;
  export(): Uint8Array;
  close(): void;
}

export interface PreparedStatement {
  run(...params: unknown[]): unknown;
  get(): unknown;
  free(): void;
}