/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix) return [];
  
  // Create regex pattern that matches words starting with prefix but not in exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  
  // Pattern to match words that start with prefix but are not in exceptions list
  const pattern = escapedExceptions.length > 0
    ? `\\b(?!${escapedExceptions.join('|')})${escapedPrefix}\\w*\\b`
    : `\\b${escapedPrefix}\\w*\\b`;
    
  const regex = new RegExp(pattern, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exact matches with exceptions (in case they are substrings)
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token) return [];

  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token only when it appears after a digit but including the digit in the match
  // Using positive lookbehind to ensure it's preceded by a digit
  const pattern = `\\d${escapedToken}`;
  const regex = new RegExp(pattern, 'g');
  
  return text.match(regex) || [];
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Check minimum length
  if (value.length < 10) return false;

  // Check for at least one uppercase, lowercase, digit, and symbol
  if (!/[A-Z]/.test(value) || 
      !/[a-z]/.test(value) || 
      !/\d/.test(value) || 
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }

  // Check for no whitespace
  if (/\s/.test(value)) return false;

  // Check for immediate repeated sequences (like abab)
  // This pattern looks for any sequence of 2+ characters that immediately repeats
  if (/(\w{2,})\1/.test(value)) return false;

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // IPv6 regex pattern 
  // This pattern accounts for standard IPv6 addresses and shorthand notation (::)
  const ipv6Pattern = /(?:^|(?<=\s)|\b)(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:$|(?=\s)|\b)|(?:^|(?<=\s)|\b)(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}(?:$|(?=\s)|\b)|(?:^|(?<=\s)|\b)::(?:$|(?=\s)|\b)/g;
  
  // Match IPv6 addresses
  const ipv6Matches = value.match(ipv6Pattern) || [];
  
  // Ensure we don't match IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  const ipv4Matches = value.match(ipv4Pattern) || [];
  
  // Return true if we found IPv6 but not IPv4
  return ipv6Matches.length > 0 && ipv4Matches.length === 0;
}