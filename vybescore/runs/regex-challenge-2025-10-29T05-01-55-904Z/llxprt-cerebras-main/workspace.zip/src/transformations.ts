/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Split text on sentence ending punctuation
  return text
    .replace(/([.?!])\s*(\w)/g, (match, punctuation, nextChar) => {
      return punctuation + ' ' + nextChar.toUpperCase();
    })
    .replace(/^\s*\w/, (match) => match.toUpperCase())
    .replace(/\s+/g, ' ') // Collapse multiple spaces into single space
    .trim(); // Remove leading/trailing whitespace
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // Regex pattern to match URLs
  const urlPattern = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.?!;,:]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Replace all http:// with https://, but don't touch https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * When the path begins with /docs/, rewrite the host to docs.example.com
 * Skip host rewrite for dynamic paths with cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Match URLs with http scheme and optionally rewrite host to docs. subdomain
  // Skip rewrite if path contains dynamic hints like cgi-bin, query strings, or legacy extensions
  return text.replace(/http:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/g, (match, host, path) => {
    // Upgrade to https
    let newUrl = `https://${host}${path}`;
    
    // Check if should rewrite host to docs.domain.com
    if (path.startsWith('/docs/')) {
      // Don't rewrite if path contains dynamic hints
      const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
      const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
      
      if (!hasDynamicHint) {
        // Rewrite host to docs.domain.com
        const domain = host.replace(/^www\./, ''); // Remove www. if present
        newUrl = `https://docs.${domain}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month and day ranges
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) return 'N/A';
  
  return year;
}
