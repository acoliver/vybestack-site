export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email format
  if (!value || typeof value !== 'string') return false;
  
  // Email regex - allow name+tag@example.co.uk patterns, reject double dots, trailing dots, etc.
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if email matches the basic pattern
  if (!emailRegex.test(value)) return false;
  
  // Additional checks:
  // 1. No double dots
  if (value.includes('..')) return false;
  
  // 2. No trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) return false;
  
  // 3. No underscores in domain part
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all non-digit characters for length and pattern checking
  const digitsOnly = value.replace(/\D/g, '');

  // Check if it starts with +1 and remove it for further validation
  let phoneDigits = digitsOnly;
  if (digitsOnly.startsWith('1') && digitsOnly.length === 11) {
    phoneDigits = digitsOnly.substring(1);
  }

  // Phone must have exactly 10 digits now
  if (phoneDigits.length !== 10) return false;

  // Area code can't start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;

  // Valid formats regex (covers all specified formats)
  const validFormats = [
    /^\(\d{3}\) \d{3}-\d{4}$/,  // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,     // 212-555-7890
    /^\d{10}$/,                // 2125557890
    /^\+1\d{10}$/,             // +12125557890
    /^\+1 \(\d{3}\) \d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1-\d{3}-\d{3}-\d{4}$/  // +1-212-555-7890
  ];

  // Check if input matches at least one valid format
  return validFormats.some(format => format.test(value));
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Supports optional country code, trunk prefix, mobile indicator, and various separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // For format +54 341 123 4567, we allow spaces or hyphens as separators
  // Country code is optional, but if present it should be +54
  // Area code must be 2-4 digits with first digit 1-9
  // Subscriber number must be 6-8 digits total
  
  // Extract only the digits
  const digits = value.replace(/\D/g, '');
  
  // Try different formats
  // With country code +54: 11 digits (54 + 341 + 1234567) or 12 digits with mobile indicator 9 (549 + 11 + 12345678)
  if (value.startsWith('+54')) {
    if (digits.length === 12 && digits.startsWith('549')) {
      // Format: +54 9 XX XXXX XXXX
      const areaCode = digits.substring(3, 5);
      const subscriber = digits.substring(5);
      
      return areaCode[0] >= '1' && areaCode[0] <= '9' && subscriber.length === 8;
    } else if (digits.length === 12 && digits.startsWith('54')) {
      // Format: +54 XXX XXX XXX or +54 XXXX XXX XXX
      // In this case we have 54 + 341 + 1234567 = 12 digits
      const areaCodeLength = 
        digits.substring(2, 4)[0] >= '1' && digits.substring(2, 4)[0] <= '9' ? 2 :
        digits.substring(2, 5)[0] >= '1' && digits.substring(2, 5)[0] <= '9' ? 3 :
        digits.substring(2, 6)[0] >= '1' && digits.substring(2, 6)[0] <= '9' ? 4 : 0;
      
      if (areaCodeLength === 0) return false;
      
      const areaCode = digits.substring(2, 2 + areaCodeLength);
      const subscriber = digits.substring(2 + areaCodeLength);
      
      return subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  // Without country code, must start with 0 (trunk prefix)
  else if (value.startsWith('0')) {
    if (digits.length >= 8 && digits.length <= 10 && digits.startsWith('0')) {
      // Format: 0XX XXXX XXXX or 0XXX XXX XXX
      const areaCodeLength = 
        digits.substring(1, 3)[0] >= '1' && digits.substring(1, 3)[0] <= '9' ? 2 :
        digits.substring(1, 4)[0] >= '1' && digits.substring(1, 4)[0] <= '9' ? 3 :
        digits.substring(1, 5)[0] >= '1' && digits.substring(1, 5)[0] <= '9' ? 4 : 0;
      
      if (areaCodeLength === 0) return false;
      
      const areaCode = digits.substring(1, 1 + areaCodeLength);
      const subscriber = digits.substring(1 + areaCodeLength);
      
      return subscriber.length >= 6 && subscriber.length <= 8;
    }
  }

  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Allow unicode letters, spaces, apostrophes, hyphens, and accents
  // Reject digits, symbols (except apostrophe and hyphen), and X Æ A-12 style names
  const nameRegex = /^[^\d\W][\w\s'-]*[^\d\W]$/u;
  
  // Special handling for single character names (like "A")
  if (value.length === 1) {
    return /^[^\d\W]$/u.test(value);
  }

  return nameRegex.test(value) && !/^\s*$/.test(value);
}

/**
 * Helper function to run the Luhn algorithm check on credit card numbers.
 * @param value The credit card number as a string
 * @returns True if valid, false otherwise
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;

  // Loop through values starting from the rightmost side
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/;

  // Mastercard: starts with 5[1-5], length 16
  const mastercardPattern = /^5[1-5][0-9]{14}$/;

  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47][0-9]{13}$/;

  // Check if the number matches any of the card types
  if (!(visaPattern.test(digitsOnly) || mastercardPattern.test(digitsOnly) || amexPattern.test(digitsOnly))) {
    return false;
  }

  // Run Luhn algorithm check
  return runLuhnCheck(digitsOnly);
}