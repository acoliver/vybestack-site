#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
function parseArgs(args: string[]): { dataFile: string; options: CLIOptions } {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;

  // Parse flags
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 < args.length) {
          format = args[i + 1] as 'markdown' | 'text';
          i++; // Skip next argument as it's the format value
        }
        break;
      case '--output':
        if (i + 1 < args.length) {
          output = args[i + 1];
          i++; // Skip next argument
        }
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        // Ignore unknown arguments for now
        break;
    }
  }

  // Validate required arguments
  if (!format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return {
    dataFile,
    options: {
      format,
      output,
      includeTotals,
    },
  };
}

// Validate and parse JSON data
function parseReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      console.error('Error: Invalid JSON structure. Required fields: title (string), summary (string), entries (array)');
      process.exit(1);
    }
    
    // Validate entries structure
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.amount !== 'number') {
        console.error(`Error: Invalid entry at index ${i}. Required fields: label (string), amount (number)`);
        process.exit(1);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File '${filePath}' not found`);
    } else {
      console.error('Error: Failed to parse JSON file - invalid JSON format');
    }
    process.exit(1);
  }
}

// Main CLI logic
function main(): void {
  const args = process.argv;
  const { dataFile, options } = parseArgs(args);
  
  if (!dataFile) {
    console.error('Error: JSON data file is required as first argument');
    process.exit(1);
  }
  
  const data = parseReportData(dataFile);
  const renderOptions = {
    includeTotals: options.includeTotals,
  };
  
  let output: string;
  
  switch (options.format) {
    case 'markdown':
      output = renderMarkdown(data, renderOptions);
      break;
    case 'text':
      output = renderText(data, renderOptions);
      break;
    default:
      console.error(`Error: Unsupported format '${options.format}'. Supported formats: markdown, text`);
      process.exit(1);
  }
  
  // Write output
  if (options.output) {
    try {
      writeFileSync(options.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${options.output}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

// Run the CLI
main();
