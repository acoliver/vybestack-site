import { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  // Format amounts to exactly 2 decimal places without thousands separators
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;

  // Add bullet list entries
  data.entries.forEach(entry => {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  });

  // Add totals if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** ${formatAmount(total)}\n`;
  }

  return output;
}