/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  Subject,
  EqualFn,
  setActiveObserver,
  getActiveObserver,
  notifySubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value

  const o: Observer<T> = {
    name: options?.name,
    value: computedValue,
    updateFn,
    observers: new Set()
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: computedValue,
    equalFn: undefined
  }

  const getter = (): T => {
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      // Re-compute the value by running the update function
      computedValue = o.updateFn(computedValue)
      s.value = computedValue
      o.value = computedValue
    } finally {
      setActiveObserver(previous)
    }

    // Notify all observers that depend on this computed value
    notifySubject(s)

    return computedValue!
  }

  return getter
}
