/**
 * Callback closure implementation for reactive side effects.
 */

import {
  UnsubscribeFn,
  Observer,
  UpdateFn,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observerValue = value

  const observer: Observer<T> = {
    value: observerValue,
    updateFn,
    observers: new Set()
  }

  // Set this callback observer as the active observer
  // so that input reads can register this as a dependency
  const previous = getActiveObserver()
  setActiveObserver(observer)
  try {
    // Execute the callback to establish dependencies
    updateFn(observer.value)
  } finally {
    // Restore the previous active observer
    setActiveObserver(previous)
  }

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true

    // Clear update function to prevent further execution
    observer.updateFn = () => observerValue!
  }
}
