const VALID_BASE64_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
const VALID_BASE64_NO_PADDING_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}|[A-Za-z0-9+/]{3}|[A-Za-z0-9+/])?$/;

/**
 * Validate that the padding is correctly placed (only at the end)
 */
function hasValidPadding(input: string): boolean {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return true; // No padding is valid
  }
  // Check that padding only appears at the end
  const afterPadding = input.substring(paddingIndex).replace(/=/g, '');
  return afterPadding.length === 0;
}

/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 * Includes padding as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace from the input
  const trimmed = input.replace(/\s/g, '');

  if (trimmed.length === 0) {
    return '';
  }

  // Check that padding is only at the end
  if (!hasValidPadding(trimmed)) {
    throw new Error('Invalid Base64 input: padding must be at the end');
  }

  // Check if input has padding
  const hasPadding = trimmed.includes('=');

  // Validate based on whether padding is present
  if (hasPadding) {
    if (!VALID_BASE64_REGEX.test(trimmed)) {
      throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
    }
  } else {
    // For input without padding, check if it matches the pattern for unpadded base64
    if (!VALID_BASE64_NO_PADDING_REGEX.test(trimmed)) {
      throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
    }
  }

  // Add padding if needed for decoding (Buffer.from with 'base64' encoding requires proper padding)
  const padded = trimmed.length % 4 === 0 
    ? trimmed 
    : trimmed + '='.repeat(4 - (trimmed.length % 4));

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
