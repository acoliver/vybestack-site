export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with proper format checking.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing domain dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // No consecutive dots in local part or domain
  const [localPart] = value.split('@');
  if (localPart && localPart.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Optional +1 prefix is allowed. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleanedValue = value.replace(/[^\d+]/g, '');
  
  // Check for +1 prefix
  let digits = cleanedValue;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // Must have exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Basic regex validation for common formats
  const phoneRegex = /^(\+?1\s?)?(\(\d{3}\)[\s.-]?|\d{3}[\s.-]?)\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0 before area code, optional mobile indicator 9.
 * Area code: 2-4 digits (leading digit 1-9). Subscriber number: 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation (but keep +)
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Extract digits and + for processing
  let digits = cleanedValue.replace(/[^\d+]/g, '');
  
  let hasCountryCode = false;
  if (digits.startsWith('+54')) {
    hasCountryCode = true;
    digits = digits.substring(3);
  }
  
  // If no country code, must start with trunk prefix 0 before area code
  if (!hasCountryCode) {
    if (!digits.startsWith('0')) {
      return false;
    }
  }
  
  // Optional mobile indicator 9 after country code or trunk prefix
  let hasMobileIndicator = false;
  if (digits[hasCountryCode ? 0 : 1] === '9') {
    hasMobileIndicator = true;
    if (hasCountryCode) {
      digits = '0' + digits.substring(1); // Replace +54 with 0 for validation
    }
  }
  
  // Extract area code (2-4 digits, cannot start with 0 or 1)
  const areaCode = digits.substring(hasCountryCode ? 0 : 1, hasCountryCode ? 3 : 4);
  
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Area code leading digit cannot be 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate remaining digits (subscriber number should be 6-8 digits)
  const remainingDigits = digits.substring(areaCode.length + (hasCountryCode ? (hasMobileIndicator ? 2 : 1) : (hasMobileIndicator ? 2 : 1)));
  if (remainingDigits.length < 6 || remainingDigits.length > 8) {
    return false;
  }
  
  // Use regex for pattern validation
  let pattern: RegExp;
  if (hasCountryCode) {
    // +54 [9] area_code subscriber
    pattern = /^\+54(9)?\d{2,4}\d{6,8}$/;
  } else {
    // 0 area_code subscriber
    pattern = /^0\d{2,4}\d{6,8}$/;
  }
  
  return pattern.test(cleanedValue);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual format like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented), apostrophes, hyphens, and spaces
  // Must have at least one letter character
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check basic pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names containing only special characters or spaces
  const lettersOnly = value.replace(/['\-\s]/g, '');
  if (!lettersOnly) {
    return false;
  }
  
  // Reject digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject certain symbols like "@", "#", "$", etc.
  if (/[¡¢£¤¥¦§¨©ª«¬®¯°±²³µ¶·¸¹»¼½¾¿×÷]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + Math.floor(digit / 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers by checking prefix, length, and Luhn checksum.
 * Accepts Visa (13 or 16 digits, starts with 4), Mastercard (16 digits, starts with 51-55),
 * and American Express (15 digits, starts with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanedCard = value.replace(/[\s-]/g, '');
  
  // Check for non-digit characters
  if (!/^\d+$/.test(cleanedCard)) {
    return false;
  }
  
  // Check Visa cards: 13 or 16 digits, starts with 4
  if ((cleanedCard.length === 13 || cleanedCard.length === 16) && cleanedCard.startsWith('4')) {
    return runLuhnCheck(cleanedCard);
  }
  
  // Check Mastercard: 16 digits, starts with 51-55
  if (cleanedCard.length === 16 && /^5[1-5]/.test(cleanedCard)) {
    return runLuhnCheck(cleanedCard);
  }
  
  // Check American Express: 15 digits, starts with 34 or 37
  if (cleanedCard.length === 15 && /^3[47]/.test(cleanedCard)) {
    return runLuhnCheck(cleanedCard);
  }
  
  return false;
}
