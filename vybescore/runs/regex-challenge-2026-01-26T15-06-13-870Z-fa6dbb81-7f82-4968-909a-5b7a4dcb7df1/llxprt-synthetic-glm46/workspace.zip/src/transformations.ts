/**
 * Transforms text by capitalizing the first character of each sentence.
 * After .?! markers, inserts exactly one space between sentences, 
 * and collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Add spacing between sentences if missing
  const spacedText = text.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Capitalize first letter after sentence markers and at start
  return spacedText.replace(/(^|[.!?]\s+)([a-z])/g, (_, prefix, letter) => 
    prefix + letter.toUpperCase()
  );  
}

/**
 * Finds and returns all URLs in the text without trailing punctuation.
 * Supports http(s), ftp, and other common URL protocols.
 */
export function extractUrls(text: string): string[] {
  // Match URLs followed by closing punctuation
  const urlRegex = /(https?:\/\/[^\s)]+|ftp:\/\/[^\s)]+)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * Replaces all http:// URLs with https:// while leaving https URLs unchanged.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Transforms URLs that start with http://example.com:
 * - Upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic paths (cgi-bin, query strings, certain extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/(https?:\/\/example\.com(\/[\w\/\-_]*))/g, (match, fullUrl, path) => {
    // Always upgrade to HTTPS
    let newUrl = match.replace('http://', 'https://');
    
    // Check if we should rewrite the host
    const shouldRewriteHost = 
      path.startsWith('/docs/') && 
      !path.match(/(cgi-bin|[?&=]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/);
    
    if (shouldRewriteHost) {
      newUrl = newUrl.replace('https://example.com/', 'https://docs.example.com/');
    } else if (match.startsWith('http://')) {
      // Just upgrade to HTTPS without changing host
      newUrl = 'https://example.com' + path;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  return dateMatch[3]; // Return the year
}
