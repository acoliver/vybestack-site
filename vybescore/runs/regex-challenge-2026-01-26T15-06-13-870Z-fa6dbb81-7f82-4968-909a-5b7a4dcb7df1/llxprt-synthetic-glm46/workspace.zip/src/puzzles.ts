/**
 * Finds words beginning with the prefix but excluding specified exceptions.
 * Uses lookahead and word boundaries.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches.filter(match => !exceptions.includes(match.toLowerCase()));
}

/**
 * Returns occurrences where the token appears after a digit and not at the start.
 * Uses lookahead and lookbehind to match token positions.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\d${escapedToken}(?=\\D|$)`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validates password strength: at least 10 chars, one uppercase, one lowercase, one digit, 
 * one symbol, no whitespace, and no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab)
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) and ensures IPv4 addresses don't trigger false positives.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns (not IPv4)
  // Full pattern: 8 groups of 1-4 hex digits separated by :, with optional ::
  // Also includes IPv6 addresses embedded in IPv4 format
  const ipv6Pattern = /^(?!.*\.\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  return ipv6Pattern.test(value);
}
