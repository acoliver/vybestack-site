import express from 'express';
import path from 'node:path';
import { initDatabase } from './database.js';
import { validateForm, sanitizeInput, FormSubmission } from './validators.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
initDatabase().catch(console.error);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    title: 'Friendly Contact Form',
    errors: [],
    formData: {}
  });
});

app.post('/submit', async (req, res) => {
  const sanitizedData = sanitizeInput(req.body);
  const validation = validateForm(sanitizedData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      title: 'Friendly Contact Form',
      errors: validation.errors,
      formData: sanitizedData
    });
  }

  try {
    const submissionData = sanitizedData as FormSubmission;
    await insertSubmission(submissionData);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      title: 'Friendly Contact Form',
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      formData: sanitizedData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Import dependencies at the bottom to avoid circular dependency
import { insertSubmission, closeDatabase } from './database.js';

// Start server
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  server.close(() => {
    console.log('HTTP server closed');
    closeDatabase();
    console.log('Database connection closed');
    process.exit(0);
  });
});