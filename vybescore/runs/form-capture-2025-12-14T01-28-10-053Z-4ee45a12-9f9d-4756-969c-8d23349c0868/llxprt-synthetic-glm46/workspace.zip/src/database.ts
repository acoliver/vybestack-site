import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';
import { FormSubmission } from './validators.js';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

interface Database {
  exec: (sql: string) => void;
  run: (sql: string, ...params: unknown[]) => { changes: number; lastInsertRowid: number };
  export: () => Uint8Array;
  prepare: (sql: string) => Statement;
  close: () => void;
}

interface Statement {
  run: (...params: unknown[]) => { changes: number; lastInsertRowid: number };
  get?: (...params: unknown[]) => Record<string, unknown>;
  all?: (...params: unknown[]) => Record<string, unknown>[];
  free: () => void;
}

let db: Database | null = null;

/**
 * Initialize the database. Creates it if it doesn't exist.
 */
export const initDatabase = async (): Promise<Database> => {
  if (db) {
    return db;
  }

  const SQL = await initSqlJs();
  
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  let isNewDb = false;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
    db = new SQL.Database(arrayBuffer);
  } else {
    db = new SQL.Database();
    isNewDb = true;
  }

  // Always check if schema exists and apply if needed
  try {
    const checkTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='submissions'");
    const hasTable = checkTable.get?.();
    checkTable.free();
    
    if (!hasTable) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      saveDatabase();
      console.log('Database schema initialized');
    }
  } catch (error) {
    console.error('Error checking database schema:', error);
    if (isNewDb) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      saveDatabase();
      console.log('Database schema initialized on error recovery');
    }
  }

  return db as Database;
};

/**
 * Save the database to disk
 */
const saveDatabase = (): void => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
};

/**
 * Insert a form submission into the database
 */
export const insertSubmission = async (data: FormSubmission): Promise<number> => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    const result = stmt.run(
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    );
    
    saveDatabase();
    return result.lastInsertRowid as number;
  } finally {
    stmt.free();
  }
};

/**
 * Close the database connection
 */
export const closeDatabase = (): void => {
  if (db) {
    db.close();
    db = null;
  }
};