declare module 'sql.js' {
  export default function initSqlJs(options?: Record<string, unknown>): Promise<SqlJsStatic>;
  
  interface SqlJsStatic {
    Database: DatabaseConstructor;
  }
  
  interface DatabaseConstructor {
    new(data?: ArrayBuffer): Database;
  }
  
  interface Database {
    export(): Uint8Array;
    run(sql: string, ...params: unknown[]): { changes: number; lastInsertRowid: number };
    exec(sql: string): void;
    prepare(sql: string): Statement;
    close(): void;
  }
  
  interface Statement {
    run(...params: unknown[]): { changes: number; lastInsertRowid: number };
    get(...params: unknown[]): Record<string, unknown>;
    all(...params: unknown[]): Record<string, unknown>[];
    free(): void;
  }
}