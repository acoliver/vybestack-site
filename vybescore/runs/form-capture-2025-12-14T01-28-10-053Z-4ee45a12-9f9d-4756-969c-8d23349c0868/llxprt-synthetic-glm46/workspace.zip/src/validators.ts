/**
 * Server-side validation utilities for form fields
 */

export interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: keyof FormSubmission;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

/**
 * Validate a form submission
 */
export const validateForm = (data: Partial<FormSubmission>): ValidationResult => {
  const errors: ValidationError[] = [];

  // First name validation
  if (!data.first_name || data.first_name.trim() === '') {
    errors.push({
      field: 'first_name',
      message: 'First name is required'
    });
  } else if (data.first_name.trim().length > 100) {
    errors.push({
      field: 'first_name',
      message: 'First name must be less than 100 characters'
    });
  }

  // Last name validation
  if (!data.last_name || data.last_name.trim() === '') {
    errors.push({
      field: 'last_name',
      message: 'Last name is required'
    });
  } else if (data.last_name.trim().length > 100) {
    errors.push({
      field: 'last_name',
      message: 'Last name must be less than 100 characters'
    });
  }

  // Street address validation
  if (!data.street_address || data.street_address.trim() === '') {
    errors.push({
      field: 'street_address',
      message: 'Street address is required'
    });
  } else if (data.street_address.trim().length > 255) {
    errors.push({
      field: 'street_address',
      message: 'Street address must be less than 255 characters'
    });
  }

  // City validation
  if (!data.city || data.city.trim() === '') {
    errors.push({
      field: 'city',
      message: 'City is required'
    });
  } else if (data.city.trim().length > 100) {
    errors.push({
      field: 'city',
      message: 'City must be less than 100 characters'
    });
  }

  // State/Province validation
  if (!data.state_province || data.state_province.trim() === '') {
    errors.push({
      field: 'state_province',
      message: 'State/Province/Region is required'
    });
  } else if (data.state_province.trim().length > 100) {
    errors.push({
      field: 'state_province',
      message: 'State/Province/Region must be less than 100 characters'
    });
  }

  // Postal code validation
  if (!data.postal_code || data.postal_code.trim() === '') {
    errors.push({
      field: 'postal_code',
      message: 'Postal/Zip code is required'
    });
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postal_code.trim())) {
    errors.push({
      field: 'postal_code',
      message: 'Postal code can only contain letters, numbers, spaces, and hyphens'
    });
  } else if (data.postal_code.trim().length > 20) {
    errors.push({
      field: 'postal_code',
      message: 'Postal code must be less than 20 characters'
    });
  }

  // Country validation
  if (!data.country || data.country.trim() === '') {
    errors.push({
      field: 'country',
      message: 'Country is required'
    });
  } else if (data.country.trim().length > 100) {
    errors.push({
      field: 'country',
      message: 'Country must be less than 100 characters'
    });
  }

  // Email validation
  if (!data.email || data.email.trim() === '') {
    errors.push({
      field: 'email',
      message: 'Email is required'
    });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  } else if (data.email.trim().length > 255) {
    errors.push({
      field: 'email',
      message: 'Email must be less than 255 characters'
    });
  }

  // Phone validation (international formats: digits, spaces, parentheses, dashes, leading +)
  if (!data.phone || data.phone.trim() === '') {
    errors.push({
      field: 'phone',
      message: 'Phone number is required'
    });
  } else if (!/^\+?[0-9\s()\-]{7,20}$/.test(data.phone.trim())) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

/**
 * Sanitize form input by trimming whitespace
 */
export const sanitizeInput = (data: Record<string, unknown>): FormSubmission => {
  return {
    first_name: data.first_name && typeof data.first_name === 'string' ? data.first_name.trim() : '',
    last_name: data.last_name && typeof data.last_name === 'string' ? data.last_name.trim() : '',
    street_address: data.street_address && typeof data.street_address === 'string' ? data.street_address.trim() : '',
    city: data.city && typeof data.city === 'string' ? data.city.trim() : '',
    state_province: data.state_province && typeof data.state_province === 'string' ? data.state_province.trim() : '',
    postal_code: data.postal_code && typeof data.postal_code === 'string' ? data.postal_code.trim() : '',
    country: data.country && typeof data.country === 'string' ? data.country.trim() : '',
    email: data.email && typeof data.email === 'string' ? data.email.trim() : '',
    phone: data.phone && typeof data.phone === 'string' ? data.phone.trim() : ''
  };
};