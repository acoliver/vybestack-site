/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
// Helper function to create equality function
function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === true) {
    return (a: T, b: T) => a === b
  }
  if (equal === false || equal === undefined) {
    return undefined
  }
  return equal
}

// Helper function to check if values are equal
function isEqual<T>(a: T, b: T, equalFn?: EqualFn<T>): boolean {
  if (equalFn) {
    return equalFn(a, b)
  }
  return a === b
}

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  let lastValue = value
  
  // Store observers that depend on this computed value
  const dependentObservers = new Set<Observer<T>>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value: lastValue,
    updateFn: (currentValue) => {
      const newValue = updateFn(currentValue)
      if (lastValue === undefined || !isEqual(lastValue, newValue, equalFn)) {
        lastValue = newValue
        
        // Notify all dependent observers
        for (const dependent of dependentObservers) {
          updateObserver(dependent)
        }
      }
      return newValue
    },
  }

  // Perform initial computation to establish dependencies
  updateObserver(observer)
  
  // Return getter function that will track dependencies
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver() as Observer<T> | undefined
    
    // If this computed value is being accessed during another observer's computation,
    // we should recompute to ensure we have the latest value from dependencies
    if (activeObserver && activeObserver !== observer) {
      dependentObservers.add(activeObserver)
      // Force recomputation by running the update function
      updateObserver(observer)
    }
    
    return observer.value!
  }
  
  return getter
}