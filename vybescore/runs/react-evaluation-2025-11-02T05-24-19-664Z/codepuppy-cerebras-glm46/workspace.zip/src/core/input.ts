/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
// Helper function to create equality function
function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === true) {
    return (a: T, b: T) => a === b
  }
  if (equal === false || equal === undefined) {
    return undefined
  }
  return equal
}

// Helper function to check if values are equal
function isEqual<T>(a: T, b: T, equalFn?: EqualFn<T>): boolean {
  if (equalFn) {
    return equalFn(a, b)
  }
  return a === b
}

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn = createEqualFn(equal)
  
  // Store multiple observers to support the reactive pattern
  const observers = new Set<Observer<T>>()
  
  const read: GetterFn<T> = () => {
    // When reading, if there's an active observer, add it to our observers set
    const activeObserver = getActiveObserver() as Observer<T> | undefined
    if (activeObserver) {
      observers.add(activeObserver)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value actually changed
    if (!isEqual(value, nextValue, equalFn)) {
      value = nextValue
      
      // Notify all observers of the change
      for (const observer of observers) {
        updateObserver(observer)
      }
    }
    return value
  }

  return [read, write]
}
