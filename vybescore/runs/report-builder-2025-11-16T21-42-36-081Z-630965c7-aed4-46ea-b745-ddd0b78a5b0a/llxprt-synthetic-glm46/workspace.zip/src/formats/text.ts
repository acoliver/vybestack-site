import type { ReportData, RenderOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const lines = [
    data.title,
    data.summary,
    'Entries:',
    ...data.entries.map(entry => `- ${entry.label}: ${formatAmount(entry.amount)}`)
  ];
  
  if (options.includeTotals) {
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }
  
  return lines.join('\\n');
}