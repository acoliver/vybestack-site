import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { ReportData, RenderOptions } from '../types.js';

export function renderReport(data: ReportData, format: 'markdown' | 'text', options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
  }
}