import type { ReportEntry } from './types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function validateReportData(data: unknown): string | null {
  if (typeof data !== 'object' || data === null) {
    return 'Report data must be an object';
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string' || !report.title.trim()) {
    return 'Report must have a non-empty title string';
  }

  if (typeof report.summary !== 'string' || !report.summary.trim()) {
    return 'Report must have a non-empty summary string';
  }

  if (!Array.isArray(report.entries) || report.entries.length === 0) {
    return 'Report must have a non-empty entries array';
  }

  for (const [index, entry] of report.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      return `Entry at index ${index} must be an object`;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      return `Entry at index ${index} must have a non-empty label string`;
    }

    if (typeof entryObj.amount !== 'number' || !Number.isFinite(entryObj.amount)) {
      return `Entry at index ${index} must have a valid amount number`;
    }
  }

  return null;
}