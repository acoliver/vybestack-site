#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, CommandOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): { inputPath: string; options: CommandOptions } | never {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputIndex = args.findIndex(arg => !arg.startsWith('--'));
  if (inputIndex === -1) {
    console.error('Error: Input file path is required');
    process.exit(1);
  }
  
  const inputPath = args[inputIndex];
  
  let format: 'markdown' | 'text' = 'markdown';
  let output: string | undefined;
  let includeTotals = false;
  
  const argsCopy = [...args];
  argsCopy.splice(inputIndex, 1);
  
  for (let i = 0; i < argsCopy.length; i++) {
    const arg = argsCopy[i];
    if (arg === '--format') {
      const formatValue = argsCopy[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      format = formatValue as 'markdown' | 'text';
      i++;
    } else if (arg === '--output') {
      output = argsCopy[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  return {
    inputPath,
    options: { format, output, includeTotals }
  };
}

function loadReportData(inputPath: string): ReportData {
  try {
    const content = readFileSync(inputPath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    if (typeof data.title !== 'string' || !data.title) {
      throw new Error('Invalid or missing title');
    }
    if (typeof data.summary !== 'string' || !data.summary) {
      throw new Error('Invalid or missing summary');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing entries array');
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string' || !entry.label) {
        throw new Error('Invalid or missing entry label');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid or missing entry amount');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in ${inputPath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error reading file ${inputPath}`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CommandOptions): string {
  const renderOptions = {
    includeTotals: options.includeTotals
  };
  
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, renderOptions);
    case 'text':
      return renderText(data, renderOptions);
  }
}

function main(): void {
  const { inputPath, options } = parseArguments();
  const data = loadReportData(inputPath);
  const output = renderReport(data, options);
  
  if (options.output) {
    writeFileSync(options.output, output, 'utf-8');
    console.log(`Report written to ${options.output}`);
  } else {
    console.log(output);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}