import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function isValidPaginationValue(value: string | undefined, allowZero: boolean): boolean {
  if (value === undefined) {
    return true;
  }

  // Check if the value is numeric
  if (!/^\d+$/.test(value)) {
    return false;
  }

  const num = Number(value);
  if (allowZero) {
    return num >= 0;
  } else {
    return num > 0;
  }
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    if (!isValidPaginationValue(pageParam, false)) {
      return res.status(400).json({
        error: 'Invalid page parameter. Must be a positive integer greater than 0.'
      });
    }

    // Validate limit parameter
    if (!isValidPaginationValue(limitParam, false)) {
      return res.status(400).json({
        error: 'Invalid limit parameter. Must be a positive integer greater than 0.'
      });
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Additional validation for limit not exceeding max
    if (limit !== undefined && limit > MAX_LIMIT) {
      return res.status(400).json({
        error: `Limit cannot exceed ${MAX_LIMIT}.`
      });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
