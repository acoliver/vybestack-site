import { ReportData, FormatOptions } from './types.js';

export function renderText(data: ReportData, options: FormatOptions = {}): string {
  let result = `${data.title}\n\n${data.summary}\n\nEntries:\n`;
  
  for (const entry of data.entries) {
    result += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\nTotal: $${total.toFixed(2)}\n`;
  }
  
  return result;
}