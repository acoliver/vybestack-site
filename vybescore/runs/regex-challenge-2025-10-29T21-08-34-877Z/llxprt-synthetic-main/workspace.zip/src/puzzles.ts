/**
 * Finds words beginning with a specific prefix, excluding defined exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Ensure exceptions is an array
  const exceptionsSet = exceptions ? new Set(exceptions) : new Set();
  
  // Create regex to find whole words starting with the prefix
  // \b ensures we match whole words only
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and remove duplicates
  const filteredWords = [...new Set(matches)].filter(word => !exceptionsSet.has(word));
  
  return filteredWords;
}

/**
 * Finds occurrences of a token that appear after a digit, excluding matches at the string start.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind and a capturing group to match the digit and token
  // Ensure it's not at the start of the string
  const tokenRegex = new RegExp(`(?<!^)(?<digit>\\d)${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Include the digit in the result
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates password strength according to specific requirements:
 * - At least 10 characters
 * - Contains at least one uppercase letter
 * - Contains at least one lowercase letter
 * - Contains at least one digit
 * - Contains at least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // Check for required character types
  const hasLowercase = /[a-z]/.test(value);
  const hasUppercase = /[A-Z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  
  if (!hasLowercase || !hasUppercase || !hasDigit || !hasSymbol) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // We'll check for patterns that repeat immediately after themselves
  const repeatedPatternRegex = /(..+)\1+/;
  if (repeatedPatternRegex.test(value)) return false;
  
  // Check for repeating characters (e.g., aaaa)
  if (/(.)\1{3,}/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses in text, including shorthand IPv6 notation (::).
 * Excludes IPv4 addresses from detection.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: (compressed zeros)
  // Cases:
  // 1. :: at start: ::(1-7 groups of 1-4 hex digits)
  // 2. :: in middle: (1-7 groups):(0-6 groups) - with :: in between
  // 3. :: at end: (1-7 groups)::(0-6 groups)
  const compressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 embedded with IPv4: x:x:x:x:x:x:d.d.d.d
  const embeddedIPv4Regex = /\b(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Regex to explicitly exclude IPv4 addresses
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if there's an IPv6 pattern and it's not part of a pure IPv4
  const hasIPv6 = fullIPv6Regex.test(value) || 
                 compressedIPv6Regex.test(value) || 
                 embeddedIPv4Regex.test(value);
  
  if (!hasIPv6) return false;
  
  // If the text also contains IPv4, make sure we're not just matching that
  if (ipv4Regex.test(value) && !compressedIPv6Regex.test(value) && !fullIPv6Regex.test(value)) {
    return false; // Only IPv4 present
  }
  
  return true;
}