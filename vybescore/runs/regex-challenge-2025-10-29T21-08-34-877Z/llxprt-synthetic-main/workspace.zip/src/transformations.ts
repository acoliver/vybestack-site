/**
 * Capitalizes the first character of each sentence, preserving abbreviations when possible.
 * Ensures proper spacing between sentences while collapsing extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // First normalize whitespace: collapse multiple spaces to single
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence terminators (., ?, !)
  normalized = normalized.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Split into sentences and capitalize the first letter of each
  // Using regex to split on sentence terminators followed by space or end of string
  const sentences = normalized.split(/([.?!]\s*)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (segment.match(/^[.?!]\s*$/)) {
      // Sentence terminator, add as is with proper spacing
      result = result.trimEnd() + segment;
      capitalizeNext = true;
    } else if (capitalizeNext && segment.length > 0) {
      // This is the beginning of a new sentence
      // Handle common abbreviations to avoid over-capitalizing
      const isAbbreviation = /^(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|etc|e\.g|i\.e|vs|approx)\.?$/i.test(segment.trim());
      
      if (isAbbreviation) {
        result += segment;
        capitalizeNext = false;  // Don't capitalize after an abbreviation
      } else {
        // Capitalize first letter of the sentence
        result += segment.charAt(0).toUpperCase() + segment.slice(1);
        capitalizeNext = false;
      }
    } else if (segment.length > 0) {
      result += segment;
    }
  }
  
  // Clean up any extra spaces at the beginning or between sentences
  result = result.replace(/\s+/g, ' ');
  result = result.replace(/^([.?!])\s+/, '$1 ');
  
  return result;
}

/**
 * Extracts URLs from the given text, returning an array of matched URLs.
 * Removes common trailing punctuation like periods and commas.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // Regex to match URLs with http/https protocols
  // We'll check for various components including subdomains, paths, query strings, and fragments
  const urlRegex = /(https?:\/\/)([^\s<>"]+)(?=[\s<>"]|$)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?)\]\}]<>"']*$/g, '');
  });
}

/**
 * Converts all http:// URLs to https:// while leaving existing https:// URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // Replace all http:// URLs with https://
  // Use negative lookahead to ensure we don't match https://
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... to https://..., with special handling for docs paths.
 * - Always upgrades the scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints like cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // First match all example.com URLs (both http and https)
  const urlRegex = /(https?):\/\/example\.com(\/[^\s]*)?/gi;

  return text.replace(urlRegex, (match, protocol, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';

    // Check if we should skip the docs rewrite
    const shouldSkipHostRewrite = 
      path.includes('/cgi-bin') ||
      path.includes('?') || 
      path.includes('&') || 
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path.split('?')[0]);

    // If path starts with /docs/, and we're not skipping, rewrite the host
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return `${secureProtocol}docs.example.com${path}`;
    }

    // Otherwise, just upgrade the protocol
    return `${secureProtocol}example.com${path}`;
  });
}

/**
 * Extracts the year component from mm/dd/yyyy formatted dates.
 * Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format and extract the year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  // Extract the year from the capture group
  return match[3];
}
