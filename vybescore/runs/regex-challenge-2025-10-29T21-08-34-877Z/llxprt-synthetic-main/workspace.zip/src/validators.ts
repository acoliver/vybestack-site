export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // RFC 5322-ish validation using regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  if (!emailRegex.test(value)) return false;

  // Additional validation rules
  // No double dots anywhere
  if (value.includes('..')) return false;
  
  // No trailing dot in local or domain part
  if (value.endsWith('.')) return false;
  
  // No underscore in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  // Domain must have at least one dot (except local development)
  if (domain && !domain.includes('.') && !domain.startsWith('localhost')) return false;

  // Check TLD is not just numbers
  const tld = domain.split('.').pop();
  if (tld && /^\d+$/.test(tld)) return false;

  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;

  // Strip common separators and spaces
  const cleaned = value.replace(/[\s()-]/g, '');
  
  // Remove optional +1 country code if present
  const noCountryCode = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Check if it's now exactly 10 digits
  if (!/^\d{10}$/.test(noCountryCode)) {
    // Handle extensions if allowed
    if (options?.allowExtensions) {
      // Try with extension (e.g., 212-555-7890 x123)
      const withExt = noCountryCode.match(/^(\d{10})(.*)$/);
      if (withExt) {
        return /^(\d{10})(\s*[x#]\s*\d+)?$/.test(value);
      }
    }
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = noCountryCode.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (/^[01]/.test(areaCode)) {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all spaces and hyphens to validate the number structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Full regex for Argentine phone numbers
  // +54 [9] [2-4 digit area code] [6-8 digit subscriber number]
  // or
  // 0 [2-4 digit area code] [6-8 digit subscriber number]
  const argentinePhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, hasCountryCode, , areaCode, subscriberNumber] = match;
  
  // Validation rules:
  
  // If country code is omitted, must start with trunk prefix 0
  // But we already stripped all formatting, so we check the original value
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits and start with 1-9
  if (!areaCode || !/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!subscriberNumber || !/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // If the original value had country code, check it doesn't start with 0
  if (hasCountryCode && cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove leading and trailing spaces
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Names should contain only unicode letters, spaces, apostrophes, and hyphens
  const validNameRegex = /^[\p{L}\s'-]+$/u;
  if (!validNameRegex.test(trimmed)) return false;
  
  // Check for numeric characters
  if (/\d/.test(trimmed)) return false;
  
  // Check for certain symbols that shouldn't be in names
  /// Note: This will exclude symbols like @, #, $, %, etc.
  const disallowedSymbolsRegex = /[!@#$%^&*()_+=\[\]{}|\\:";<>\/?,.0-9]/;
  if (disallowedSymbolsRegex.test(trimmed)) return false;
  
  // Name should contain at least one letter
  const containsLetter = /[\p{L}]/u.test(trimmed);
  if (!containsLetter) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Checks prefix, length, and passes Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  if (visaRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mcRegex1 = /^5[1-5]\d{14}$/;
  const mcRegex2 = /^2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720)\d{12}$/;
  if (mcRegex1.test(cleaned) || mcRegex2.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Card doesn't match any supported format
  return false;
}

/**
 * Helper function to run the Luhn checksum algorithm.
 */
function runLuhnCheck(num: string): boolean {
  if (!/^\d+$/.test(num)) return false;
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = num.length - 1; i >= 0; i--) {
    let digit = parseInt(num.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return (sum % 10) === 0;
}
