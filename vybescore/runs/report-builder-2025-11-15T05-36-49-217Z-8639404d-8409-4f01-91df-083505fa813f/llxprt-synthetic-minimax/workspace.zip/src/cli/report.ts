import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): CLIOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (!args.includes('--format')) {
    console.error('Missing required --format argument');
    process.exit(1);
  }
  
  const formatIndex = args.indexOf('--format');
  const format = args[formatIndex + 1];
  
  if (!format || (format !== 'markdown' && format !== 'text')) {
    console.error(`Unsupported format: ${format}. Supported formats: markdown, text`);
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format: format as 'markdown' | 'text',
    output,
    includeTotals
  };
}

function readAndValidateData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: "title" must be a string');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: "summary" must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: "entries" must be an array');
    }
    
    // Validate entries
    for (const [index, entry] of data.entries.entries()) {
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: "label" must be a string`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: "amount" must be a number`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON file: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('Error reading data file');
    }
    process.exit(1);
  }
}

function main(): void {
  const options = parseArguments();
  const data = readAndValidateData(options.dataFile);
  
  let output: string;
  
  if (options.format === 'markdown') {
    output = renderMarkdown(data, options.includeTotals);
  } else {
    output = renderText(data, options.includeTotals);
  }
  
  if (options.output) {
    // Write to file
    writeFileSync(options.output, output);
  } else {
    // Write to stdout
    console.log(output);
  }
}

main();