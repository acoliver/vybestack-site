export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses including plus tags and subdomains.
 * Rejects double dots, trailing dots, domains with underscores, and invalid formats.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic structure check
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Reject invalid patterns
  const invalidPatterns = [
    /\.\./,           // Double dots
    /\.$/,            // Trailing dot
    /@.*_/,           // Underscore in domain
    /@[.-]/,          // Domain starts with dash or dot
    /@.*[-.]$/,       // Domain ends with dash or dot
    /^[.-]/,          // Local part starts with dot or dash
    /[.-]@/,          // Local part ends with dot or dash
  ];

  // Check basic structure
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }

  // Split into local and domain parts
  const [, domain] = value.split('@');
  
  // Validate domain has at least one dot
  if (!domain.includes('.')) {
    return false;
  }

  // Validate TLD is at least 2 characters
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if too short (minimum 10 digits for US numbers)
  if (digitsOnly.length < 10) {
    return false;
  }

  // Extract country code if present
  let phoneNumber: string;
  
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length === 10) {
    phoneNumber = digitsOnly;
  } else {
    // Invalid length - should be either 10 digits or 11 digits starting with 1
    return false;
  }

  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Validate exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate format using regex for more precise checking
  const usPhoneRegex = /^(\+1[\s\-]?)?(\(\d{3}\)|\d{3})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules: optional +54 country code, optional 0 trunk prefix, optional 9 mobile indicator.
 * Area codes are 2-4 digits (leading digit 1-9), subscriber numbers are 6-8 digits total.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove separators (spaces, hyphens) for validation
  const cleanNumber = value.replace(/[\s\-]/g, '');
  
  // Validate using comprehensive regex
  const argentinePhoneRegex = /^(\+54)?(9)?(0?[1-9]\d{1,3})\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleanNumber)) {
    return false;
  }

  // Extract components for additional validation
  const match = cleanNumber.match(/^(\+54)?(9)?(0?[1-9]\d{1,3})(\d{6,8})$/);
  
  if (!match) {
    return false;
  }

  const [, countryCode, , areaCodeWithPrefix, subscriberNumber] = match;
  
  // When country code is omitted, must have trunk prefix (0)
  if (!countryCode && !areaCodeWithPrefix.startsWith('0')) {
    return false;
  }

  // Validate area code (2-4 digits, leading digit 1-9)
  const areaCode = areaCodeWithPrefix.startsWith('0') 
    ? areaCodeWithPrefix.substring(1) 
    : areaCodeWithPrefix;
  
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]/.test(areaCode)) {
    return false;
  }

  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and invalid name formats like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Trim whitespace
  const trimmedName = value.trim();
  
  // Check if empty after trimming
  if (!trimmedName) {
    return false;
  }

  // Check for digits or invalid symbols
  if (/\d/.test(trimmedName)) {
    return false;
  }

  // Regex pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, spaces
  // - Must contain at least one letter
  // - Cannot start or end with apostrophe, hyphen, or space
  // - Cannot have consecutive spaces, apostrophes, or hyphens
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmedName)) {
    return false;
  }

  // Check for consecutive separators
  if (/['\-\s]{2,}/.test(trimmedName)) {
    return false;
  }

  // Cannot start or end with separator
  if (/^['\-\s]|[\s'\-]$/.test(trimmedName)) {
    return false;
  }

  // Must contain at least one letter
  if (!/\p{L}/u.test(trimmedName)) {
    return false;
  }

  // Additional check to reject names like "X Æ A-12" (too many special characters)
  // Allow reasonable use of special characters but not excessive
  const specialCharCount = (trimmedName.match(/['\-\s]/g) || []).length;
  const letterCount = (trimmedName.match(/\p{L}/gu) || []).length;
  
  if (specialCharCount > letterCount * 0.5) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers for major card types.
 * Accepts Visa (13, 16 digits starting with 4), Mastercard (16 digits starting with 51-55 or 2221-2720),
 * and American Express (15 digits starting with 34 or 37).
 * Validates length, prefix, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s\-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }

  // Check card type patterns
  const visaPattern = /^4(\d{12}|\d{15})$/; // 13 or 16 digits starting with 4
  const mastercardPattern1 = /^5[1-5]\d{14}$/; // 16 digits starting with 51-55
  const mastercardPattern2 = /^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/; // 16 digits starting with 2221-2720
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37

  const isValidPattern = visaPattern.test(cleanNumber) ||
                        mastercardPattern1.test(cleanNumber) ||
                        mastercardPattern2.test(cleanNumber) ||
                        amexPattern.test(cleanNumber);

  if (!isValidPattern) {
    return false;
  }

  // Perform Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn algorithm checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  // Double every second digit from the right
  for (let i = digits.length - 2; i >= 0; i -= 2) {
    let doubled = digits[i] * 2;
    
    // If the result is greater than 9, sum the digits
    if (doubled > 9) {
      doubled = doubled - 9;
    }
    
    digits[i] = doubled;
  }
  
  // Sum all digits
  const sum = digits.reduce((acc, digit) => acc + digit, 0);
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
