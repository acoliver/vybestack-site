/**
 * Capitalizes the first character of each sentence.
 * After sentence-ending punctuation (.?!), ensures exactly one space and capitalizes the next letter.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // First, normalize spaces: ensure exactly one space after punctuation, collapse multiple spaces
  let processed = text
    // Handle sentence endings with no space - add exactly one space
    .replace(/([.?!])([A-Za-z])/g, '$1 $2')
    // Collapse multiple spaces into one
    .replace(/\s+/g, ' ')
    // Trim leading/trailing spaces
    .trim();

  // Capitalize first letter of the text
  processed = processed.charAt(0).toUpperCase() + processed.slice(1);

  // Capitalize after sentence-ending punctuation
  // Common abbreviations that don't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e'];
  
  // Process each sentence more simply
  processed = processed.replace(/([.?!]\s+)([a-z])/g, (match, punctuation, letter) => {
    // Check if this letter might be part of an abbreviation
    const contextBefore = processed.substring(0, processed.indexOf(match));
    const words = contextBefore.split(/\s+/);
    const lastWord = words[words.length - 1];
    
    // Check if the previous word is a common abbreviation
    const isAbbreviation = abbreviations.some(abbr => 
      lastWord.toLowerCase() === abbr.toLowerCase()
    );
    
    if (!isAbbreviation) {
      return punctuation + letter.toUpperCase();
    }
    
    return match;
  });
  
  return processed;
}

/**
 * Extracts all URLs from the given text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // URL regex pattern - matches http, https, and ftp protocols
  // Includes optional www, domain names, paths, query strings, and fragments
  const urlRegex = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+?(?=[,.!?;:]?\s|$|[,.!?;:)](?:\s|$))/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,!?;:)]+$/, '');
  });
}

/**
 * Forces all http:// URLs to https:// while leaving already secure URLs untouched.
 * Replaces only the scheme, preserving the rest of the URL.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https://, but not https://
  // Use negative lookbehind to avoid replacing https://
  // Note: negative lookbehind not supported in all environments, use alternative approach
  return text.replace(/https:\/\//g, 'https://TEMP').replace(/http:\/\//g, 'https://').replace(/https:\/\/TEMP/g, 'https://');
}

/**
 * Rewrites URLs for example.com domain according to specific rules:
 * - Always upgrades http:// to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for URLs containing dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // First, upgrade all http:// to https://
  const processed = text.replace(/http:\/\//g, 'https://');

  // Pattern to match example.com URLs with their full structure
  // Captures: scheme://subdomain.domain/path
  const urlRegex = /(https:\/\/)([^\/]*example\.com)(\/[^\s]*)/gi;
  
  return processed.replace(urlRegex, (match, scheme, domain, path) => {
    // Check if this is a docs path and should be rewritten
    if (path.toLowerCase().startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = [
        'cgi-bin',
        '?',
        '&',
        '=',
        '.jsp',
        '.php',
        '.asp',
        '.aspx',
        '.do',
        '.cgi',
        '.pl',
        '.py'
      ];
      
      const hasDynamicHint = dynamicHints.some(hint => 
        path.toLowerCase().includes(hint.toLowerCase())
      );
      
      if (!hasDynamicHint) {
        // Rewrite to docs.example.com
        return `${scheme}docs.example.com${path}`;
      }
    }
    
    // Return original URL with just the scheme upgrade
    return match;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (simple validation)
  const daysInMonth = [
    31, // January
    28, // February (non-leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  // Check for leap year February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
