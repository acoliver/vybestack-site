/**
 * Finds words beginning with the given prefix, excluding specified exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }

  // Create word boundary regex pattern for the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*\\b', 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches
    .filter(word => !exceptionsLower.includes(word.toLowerCase()))
    .filter((word, index, array) => array.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to match the specified conditions.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: token preceded by a digit, but not at the start of the string
  // Since lookbehind may not be supported, use alternative approach
  const pattern = new RegExp('\\d' + escapedToken, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Remove duplicates and return
  return matches.filter((match, index, array) => array.indexOf(match) === index);
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc)
  // This checks for patterns where a sequence of 2+ characters repeats immediately
  const repeatedSequencePattern = /(.{2,})\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }

  // Additional check for repeated characters (like aaa, bbb)
  const repeatedCharPattern = /(.)\1\1+/;
  if (repeatedCharPattern.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation (::) while excluding IPv4 addresses.
 * Returns true if the text contains a valid IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 regex patterns - handles various IPv6 formats including shorthand
  const ipv6Patterns = [
    // Standard IPv6: 8 groups of 4 hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // IPv6 with :: (compressed zeros)
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/,
    /\b:(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b/,
    /\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\b/,
    /\b:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)\b/,
    
    // IPv6 with embedded IPv4
    /\b(?:[0-9a-fA-F]{1,4}:){6}:(?:\d{1,3}\.){3}\d{1,3}\b/,
    /\b::(?:\d{1,3}\.){3}\d{1,3}\b/
  ];

  // First, check if any IPv6 pattern matches
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Ensure this is not an IPv4 address that somehow matched
      const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
      const matches = value.match(pattern);
      
      if (matches) {
        for (const match of matches) {
          // If the match contains IPv4 pattern but also has IPv6 characteristics (like :), it's IPv6
          if (ipv4Pattern.test(match) && !match.includes(':')) {
            continue; // This is just IPv4, skip
          }
          return true; // Found valid IPv6
        }
      }
    }
  }

  return false;
}