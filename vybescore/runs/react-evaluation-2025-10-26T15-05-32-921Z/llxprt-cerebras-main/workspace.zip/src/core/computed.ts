/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize the equal function
  const normalizedEqualFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === false ? () => false : 
    equal === true ? Object.is : 
    undefined

  // Track dependencies for this computed value
  const dependencies = new Set<Observer<unknown>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Track dependencies as the computed value is updated
      const currentDependencies = new Set<Observer<unknown>>()

      // Wrap the updateFn to track dependencies during its execution
      const trackedUpdateFn = () => {
        const previousObserver = getActiveObserver()
        try {
          const newValue = updateFn(prevValue)
          // Check if value actually changed using the equal function
          if (!normalizedEqualFn || !prevValue || !normalizedEqualFn(prevValue, newValue)) {
            return newValue
          }
          return prevValue
        } finally {
          // No need to restore since updateObserver handles this
        }
      }

      // While computing, collect dependencies
      const previousObserver = getActiveObserver()
      // Set this computed as the active observer so that any reads during updateFn 
      // register it as a dependency
      const result = trackedUpdateFn()
      return result
    }
  }
  
  // Initialize the computed value by tracking dependencies
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    // Register the current active observer (if any) as dependent on this computed value
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      dependencies.add(currentObserver)
    }
    return o.value!
  }
  
  return read
}