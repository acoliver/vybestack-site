/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize the equal function
  const normalizedEqualFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === false ? () => false : 
    equal === true ? Object.is : 
    undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: normalizedEqualFn,
  }

  const observers = new Set<Observer<unknown>>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value has actually changed using the equal function
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    
    if (hasChanged) {
      s.value = nextValue
      
      // Update all registered observers
      observers.forEach(observer => {
        updateObserver(observer)
      })
    }
    
    return s.value
  }

  return [read, write]
}