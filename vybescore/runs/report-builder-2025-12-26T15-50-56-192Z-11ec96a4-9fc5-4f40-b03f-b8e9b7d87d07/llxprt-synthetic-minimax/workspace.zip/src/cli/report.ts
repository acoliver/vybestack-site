import { readFileSync, writeFileSync } from 'node:fs';
import { formatters } from '../formats/index.js';
import type { ReportData, ReportOptions } from '../types.js';

function printError(message: string): void {
  console.error(message);
  process.exit(1);
}

function parseArgs(argv: string[]): { dataFile: string; options: ReportOptions } {
  if (argv.length < 4) {
    printError('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = argv[2];
  const args = argv.slice(3);
  
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        printError('Error: --format requires a value');
      }
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        printError(`Unsupported format: ${nextArg}`);
      }
      format = nextArg as 'markdown' | 'text';
      i++; // Skip the value
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        printError('Error: --output requires a value');
      }
      output = nextArg;
      i++; // Skip the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      printError(`Unknown option: ${arg}`);
    }
  }

  if (!format) {
    printError('Error: --format is required');
  }

  return { dataFile, options: { format: format!, output, includeTotals } };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);

    // Validate required fields
    if (typeof data.title !== 'string' || !data.title) {
      throw new Error('Missing or invalid "title" field');
    }
    if (typeof data.summary !== 'string' || !data.summary) {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string' || !entry.label) {
        throw new Error(`Entry ${i}: Missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i}: Missing or invalid "amount" field`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        printError(`Error: Cannot read file "${filePath}"`);
        throw error; // This won't be reached but satisfies TypeScript
      }
      printError(`Error parsing JSON: ${error.message}`);
    } else {
      printError(`Error parsing JSON: ${String(error)}`);
    }
    throw error; // This won't be reached but satisfies TypeScript
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      printError(`Error writing to file: ${String(error)}`);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const { dataFile, options } = parseArgs(process.argv);
  
  const reportData = loadReportData(dataFile);
  const formatter = formatters[options.format];
  
  if (!formatter) {
    printError(`Unsupported format: ${options.format}`);
  }

  const output = formatter(reportData, options);
  writeOutput(output, options.output);
}

main();
