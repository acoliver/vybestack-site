import type { ReportData, ReportOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function formatMarkdown(data: ReportData, options: ReportOptions): string {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  const lines: string[] = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries'
  ];
  
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  if (options.includeTotals) {
    lines.push('', `**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}