import { formatMarkdown } from './markdown.js';
import { formatText } from './text.js';
import type { Formatter } from '../types.js';

export const formatters: Record<string, Formatter> = {
  'markdown': formatMarkdown,
  'text': formatText
};