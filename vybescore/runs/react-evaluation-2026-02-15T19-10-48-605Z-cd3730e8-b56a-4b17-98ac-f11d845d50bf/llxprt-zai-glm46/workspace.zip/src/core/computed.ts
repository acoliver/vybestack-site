/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: Set<ObserverR> = new Set()
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read = (): T => {
    const active = getActiveObserver()
    if (active) {
      observers.add(active)
    }
    return o.value!
  }
  
  // Wrap the update function to track dependencies and notify observers
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    setActiveObserver(o)
    try {
      const newValue = updateFn(prevValue)
      o.value = newValue
      // Notify all observers that depend on this computed value
      for (const observer of observers) {
        updateObserver(observer as Observer<unknown>)
      }
      return newValue
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  o.updateFn = wrappedUpdateFn
  updateObserver(o)
  
  return read
}
