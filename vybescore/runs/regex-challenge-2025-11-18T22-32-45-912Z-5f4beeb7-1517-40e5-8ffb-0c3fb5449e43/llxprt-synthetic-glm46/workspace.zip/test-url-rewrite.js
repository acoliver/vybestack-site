// Create a test script to debug the URL rewrite issue
const { rewriteDocsUrls } = require('./dist');
console.log('Testing rewriteDocsUrls on "http://example.com/docs/guide"');
console.log(rewriteDocsUrls('http://example.com/docs/guide'));