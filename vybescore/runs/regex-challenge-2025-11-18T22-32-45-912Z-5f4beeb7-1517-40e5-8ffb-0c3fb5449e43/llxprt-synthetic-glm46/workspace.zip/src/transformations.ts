/**
 * Capitalizes the first character of each sentence.
 * Insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Define common abbreviations to avoid breaking sentences at these points
  const abbreviations = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'etc.', 'e.g.', 'i.e.', 'vs.', 'U.S.', 'U.K.'];
  
  let result = text;
  
  // First, ensure proper spacing after sentence terminators
  // Add space after . ? ! if not followed by space and not an abbreviation
  result = result.replace(/([^.])([.?!])([^.\s])/g, '$1$2 $3');
  
  // Collapse multiple spaces to a single space, but keep newlines
  result = result.replace(/[ \t]+/g, ' ');
  
  // Capitalize the first letter of the text
  result = result.replace(/^[a-z]/, match => match.toUpperCase());
  
  // Capitalize after sentence terminators, but not after abbreviations
  const terminatorRegex = /[.?!]/g;
  let match;
  
  while ((match = terminatorRegex.exec(result)) !== null) {
    const index = match.index;
    let nextCharIndex = index + 1;
    
    // Skip any whitespace
    while (nextCharIndex < result.length && result[nextCharIndex] === ' ') {
      nextCharIndex++;
    }
    
    if (nextCharIndex < result.length) {
      // Check if the character before the terminator is part of an abbreviation
      const beforeTerminator = result.substring(Math.max(0, index - 10), index);
      const isAbbreviation = abbreviations.some(abbr => 
        beforeTerminator.includes(abbr)
      );
      
      // If it's not an abbreviation, capitalize the next character
      if (!isAbbreviation) {
        const nextChar = result[nextCharIndex];
        if (/[a-z]/.test(nextChar)) {
          result = result.substring(0, nextCharIndex) + 
                   nextChar.toUpperCase() + 
                   result.substring(nextCharIndex + 1);
          // Update the regex index to account for our change
          terminatorRegex.lastIndex = nextCharIndex + 1;
        }
      }
    }
  }
  
  return result;
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Comprehensive URL regex
  // Matches protocols (http://, https://, ftp://, etc.)
  // Also matches URLs without protocol (www.example.com)
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+\/?([^\s<>"']*[\w/&#-])?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Process each URL to remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,!?;:
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs to use https:// and modify the host to docs.example.com.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com.
 * - Skip the host rewrite when the path contains dynamic hints like cgi-bin, query strings,
 *   or legacy extensions (.jsp, .php, etc.), but still upgrade the scheme to https://.
 * - Preserve nested paths.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  let result = text;
  
  // First upgrade all http to https
  result = result.replace(/http:\/\//g, 'https://');
  
  // Regex to find URLs to rewrite
  // This looks for URLs to example.com (or subdomains) with paths starting with /docs/
  const docsUrlRegex = /(https:\/\/)(([a-zA-Z0-9-]+\.)?example\.com(?:\.[a-z]{2,})?)(\/docs\/[^\s]*)/gi;
  
  // Define skip patterns (cgi-bin, query strings, legacy extensions)
  const skipPatterns = [
    /\/cgi-bin\//,
    /[?&]/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[/?&]|$)/i
  ];
  
  result = result.replace(docsUrlRegex, (match, protocol, fullHost, subdomain, path) => {
    // Check if we should skip host rewrite
    const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
    
    if (shouldSkip) {
      // Keep the original host
      return `${protocol}${fullHost}${path}`;
    } else {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  });
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns the four-digit year or "N/A" if invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const maxDaysByMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Special check for February (leap year)
  let maxDay = maxDaysByMonth[month - 1];
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    maxDay = isLeapYear ? 29 : 28;
  }
  
  if (day < 1 || day > maxDay) return 'N/A';
  
  return year;
}