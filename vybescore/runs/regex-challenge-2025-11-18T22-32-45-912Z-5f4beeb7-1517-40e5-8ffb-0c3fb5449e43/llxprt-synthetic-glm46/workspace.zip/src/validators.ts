export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address with comprehensive format checking.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure: local@domain
  const atParts = value.split('@');
  if (atParts.length !== 2) return false;
  
  const [localPart, domain] = atParts;
  
  // Validate local part
  if (!localPart || localPart.length > 64) return false;
  
  // Local part can contain letters, digits, and special characters !#$%&'*+/=?^_`{|}~-
  // But let's use a more permissive regex that accepts common email patterns
  const localRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
  if (!localRegex.test(localPart)) return false;
  
  // Reject leading or trailing dots, consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Validate domain part
  if (!domain || domain.length > 253) return false;
  
  // Domain cannot have underscores or consecutive dots
  if (domain.includes('_')) return false;
  if (domain.includes('..')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Domain should consist of labels separated by dots
  const domainLabels = domain.split('.');
  if (domainLabels.length < 2) return false; // Need at least one subdomain and TLD
  
  // Each domain label must be valid
  const labelRegex = /^[a-zA-Z0-9-]+$/;
  const topLevelDomainRegex = /^[a-zA-Z]{2,}$/;
  
  for (let i = 0; i < domainLabels.length; i++) {
    const label = domainLabels[i];
    
    // Each label must be between 1 and 63 characters
    if (!label || label.length === 0 || label.length > 63) return false;
    
    // Labels can't start or end with hyphens
    if (label.startsWith('-') || label.endsWith('-')) return false;
    
    // Check label format
    if (i === domainLabels.length - 1) {
      // Top-level domain should only contain letters
      if (!topLevelDomainRegex.test(label)) return false;
    } else {
      if (!labelRegex.test(label)) return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters except + at the beginning
  const cleaned = value.startsWith('+') ? '+' + value.replace(/[^\d]/g, '') : value.replace(/[^\d]/g, '');
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    // If it starts with 1 and has 11 digits, treat 1 as country code
    digits = digits.substring(1);
  }
  
  // US phone numbers should have exactly 10 digits (after removing country code)
  if (digits.length !== 10) return false;
  
  // Extract area code, prefix, and line number
  const areaCode = digits.substring(0, 3);
  const prefix = digits.substring(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Additional validation: some specific requirements for North American Numbering Plan
  // Area codes starting with 2-9, with the second digit being 0-9 except 9 for certain cases
  // But for simplicity, we'll just check that the area code is valid
  if (!/^[2-9]\d{2}$/.test(areaCode)) return false;
  
  // Prefix cannot start with 0 or 1
  if (prefix[0] === '0' || prefix[0] === '1') return false;
  
  // Check if extension handling is enabled if provided in options
  // This would need to be implemented when parsing extensions
  if (options?.allowExtensions && value.includes('ext')) {
    // Extension validation logic would go here
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, etc.
 * 
 * Rules:
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2-4 digits (leading digit 1-9).
 * - Subscriber number must contain 6-8 digits in total.
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters to simplify validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Optional country code +54
  let hasCountryCode = false;
  let digits = digitsOnly;
  
  if (digits.startsWith('54')) {
    hasCountryCode = true;
    digits = digits.substring(2);
  }
  
  // When country code is omitted, must start with trunk prefix 0
  if (!hasCountryCode && !digits.startsWith('0')) {
    return false;
  }
  
  // Optional trunk prefix 0
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Optional mobile indicator 9
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (digits.length < 8) { // Minimum: 2-digit area code + 6-digit subscriber number
    return false;
  }
  
  let areaCodeLength;
  
  // Try different area code lengths (2-4 digits)
  for (let i = 2; i <= 4; i++) {
    if (digits.length > i) {
      areaCodeLength = i;
      break;
    }
  }
  
  if (!areaCodeLength) return false;
  
  const areaCode = digits.substring(0, areaCodeLength);
  const subscriberNumber = digits.substring(areaCodeLength);
  
  // Area code validation: first digit must be 1-9
  if (!/^[1-9]\d{0,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // Additional check: for Buenos Aires area code (11), the subscriber number is typically 8 digits with mobile prefix 15
  // But to keep it simple, we'll accept any valid 6-8 digit subscriber number
  
  return true;
}

/**
 * Validates a person's name.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Reject names that are too short or too long
  if (value.trim().length < 1 || value.length > 100) return false;
  
  // Name can contain unicode letters (including accented characters), spaces, hyphens, and apostrophes
  // This regex matches unicode letters, spaces, hyphens, and apostrophes
  // \p{L} matches any kind of letter from any language (Unicode property)
  // Using 'u' flag for Unicode support
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // Reject names with consecutive non-letter characters (like "--" or "''")
  if (value.includes('--') || value.includes("''")) {
    return false;
  }
  
  // Reject names that start or end with non-letter characters
  if (/^[\s'-]+$/.test(value[0]) || /[\s'-]$/.test(value[value.length - 1])) {
    return false;
  }
  
  // Reject names with no letters at all (like just spaces or hyphens)
  if (!/[^\s'-]/.test(value)) {
    return false; // No non-space/hyphen/apostrophe characters
  }
  
  // Ensure there's at least one letter in the name
  const hasLetter = /\p{L}/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper function for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  let sum = 0;
  let isEven = false;
  
  // Loop through digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Check if the value contains only digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check length based on card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // Amex: 15 digits, starts with 34 or 37
  
  if (/^4/.test(digitsOnly)) {
    // Visa
    if (digitsOnly.length !== 13 && digitsOnly.length !== 16) {
      return false;
    }
  } else if (/^5[1-5]/.test(digitsOnly)) {
    // Mastercard (51-55)
    if (digitsOnly.length !== 16) {
      return false;
    }
  } else if (/^2(2[2-9]|[3-6]\d|7[01])/.test(digitsOnly)) {
    // Mastercard (2221-2720)
    if (digitsOnly.length !== 16) {
      return false;
    }
  } else if (/^3[47]/.test(digitsOnly)) {
    // Amex
    if (digitsOnly.length !== 15) {
      return false;
    }
  } else {
    // Not a supported card type
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}