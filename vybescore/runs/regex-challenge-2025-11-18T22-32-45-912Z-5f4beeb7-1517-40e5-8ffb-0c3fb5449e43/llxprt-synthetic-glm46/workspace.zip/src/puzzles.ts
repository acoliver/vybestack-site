/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  if (!Array.isArray(exceptions)) return [];
  
  // Escape any special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to match words starting with the prefix
  // \b ensures we match whole words
  // [a-zA-Z]* matches remaining letters in the word
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  // Manual approach since lookbehind might not be supported in all environments
  const results: string[] = [];
  let index = 0;
  
  while (index < text.length) {
    // Find the next occurrence of the token
    const tokenIndex = text.indexOf(token, index);
    if (tokenIndex === -1) break;
    
    // Check if there's a digit immediately before this token
    const charBefore = text.charAt(tokenIndex - 1);
    
    // Token must not be at the start of the string and must be preceded by a digit
    if (tokenIndex > 0 && /\d/.test(charBefore)) {
      results.push(charBefore + token);
    }
    
    // Move to the next position after the current token
    index = tokenIndex + token.length;
  }
  
  return results;
}

/**
 * Validates if a password is strong.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences (e.g., abab).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Password must be at least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, testtest)
  // This pattern matches repeated sequences of 2 or more characters
  const repeatedPattern = /((.{2,})\2+)/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that matches:
  // 1. Full IPv6 address: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // 2. Shortened IPv6 with zeros removed: 2001:db8:85a3::8a2e:370:7334
  // 3. IPv6 with embedded IPv4: 2001:db8:85a3::8a2e:370:192.0.2.33
  // 4. Loopback address: ::1
  // 5. Unspecified address: ::
  
  // Basic IPv6 address pattern
  const ipv6Pattern = /(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))(?:$|(?=\s))/;
  
  // Check for IPv6 addresses
  if (ipv6Pattern.test(value)) {
    return true;
  }
  
  // Check for shorthand IPv6 with double colon
  const shorthandPattern = /(?:^|(?<=\s))([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}(?:$|(?=\s))|(?:^|(?<=\s))::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}(?:$|(?=\s))/;
  if (shorthandPattern.test(value)) {
    return true;
  }
  
  // Check for ::1 and ::
  const specialPattern = /(?:^|(?<=\s))(::1?)(?:$|(?=\s))/;
  if (specialPattern.test(value)) {
    return true;
  }
  
  return false;
}