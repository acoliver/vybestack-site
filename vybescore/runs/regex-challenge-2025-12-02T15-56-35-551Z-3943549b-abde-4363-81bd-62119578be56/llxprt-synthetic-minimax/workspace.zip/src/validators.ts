export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email pattern that:
  // - Allows typical characters in local part (letters, numbers, + tags)
  // - Requires @ symbol
  // - Validates domain (no underscores, no double/trailing dots)
  // - Allows multi-level TLD (.co.uk, etc.)
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  // Check basic pattern match
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional validation for specific invalid patterns
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dots in domain
  const domain = value.split('@')[1];
  if (domain && domain.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to check length and area code
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 11 digits (with +1) or 10 digits (without)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // If 11 digits, must start with 1
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract area code (first 3 digits of the 10-digit number)
  const areaCode = digitsOnly.slice(-10, -7);
  
  // Area code cannot start with 0 or 1 (NANP rules)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Now check the actual format using regex
  // This pattern handles:
  // - Optional +1 prefix
  // - Optional parentheses around area code
  // - Various separators (spaces, dashes)
  // - Digits only format
  const phonePattern = /^(?:\+1[\s.-]?)?(?:\(?([2-9]\d{2})\)?[\s.-]?)?([2-9]\d{2})[\s.-]?(\d{4})$/;
  
  const match = value.match(phonePattern);
  if (!match) {
    return false;
  }
  
  // Ensure area code is present and valid
  const matchedAreaCode = match[1] || areaCode;
  if (!matchedAreaCode || matchedAreaCode.startsWith('0') || matchedAreaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have between 10-13 digits (depending on format)
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }
  
  // Simple digit-based validation
  if (digitsOnly.startsWith('54')) {
    // Has country code: 54 + area(2-4) + subscriber(6-8) = 12-15 digits
    const areaCode = digitsOnly.slice(2, 6); // Take up to 4 digits for area code
    const subscriber = digitsOnly.slice(areaCode.length + 2);
    
    // Area code validation (2-4 digits, first digit not 0/1)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
    
    // Subscriber validation (6-8 digits)
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    
    return true;
  } else {
    // No country code: must start with 0 (trunk prefix) or 9 (mobile)
    if (!digitsOnly.startsWith('0') && !digitsOnly.startsWith('9')) {
      return false;
    }
    
    // Remove trunk/mobile prefix and validate area + subscriber
    const withoutPrefix = digitsOnly.replace(/^[09]/, '');
    if (withoutPrefix.length < 9 || withoutPrefix.length > 12) {
      return false;
    }
    
    const areaCode = withoutPrefix.slice(0, 4); // Take up to 4 digits
    const subscriber = withoutPrefix.slice(areaCode.length);
    
    // Area code validation (2-4 digits, first digit not 0/1)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
    
    // Subscriber validation (6-8 digits)
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    
    return true;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Pattern allowing:
  // - Unicode letters (including accented characters)
  // - Spaces
  // - Apostrophes
  // - Hyphens
  // Rejecting:
  // - Digits
  // - Other symbols
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional validation: must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Must not be all spaces, hyphens, and apostrophes
  const cleaned = value.replace(/[\s'-]/g, '');
  if (cleaned.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have between 13-19 digits
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid credit card patterns
  // Visa: starts with 4, 16 digits
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits  
  // AmEx: starts with 34 or 37, 15 digits
  const visaPattern = /^4\d{15}$/;
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(digitsOnly) && 
      !mastercardPattern.test(digitsOnly) && 
      !amexPattern.test(digitsOnly)) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
