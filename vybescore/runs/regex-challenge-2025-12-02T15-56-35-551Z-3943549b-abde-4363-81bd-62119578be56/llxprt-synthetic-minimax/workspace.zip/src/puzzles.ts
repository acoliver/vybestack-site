/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  // Using word boundaries to ensure we match whole words
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(match => {
    const matchLower = match.toLowerCase();
    return !exceptionsLower.includes(matchLower);
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find digit followed by token
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'gi');
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]); // This will be like "1foo", "2bar", etc.
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one of each: uppercase, lowercase, digit, symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  // Simplified symbol pattern to avoid escape character issues
  const hasSymbol = /[^a-zA-Z0-9\s]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This pattern looks for any 4-character sequence that repeats immediately
  // e.g., "abab", "1212", "xyzxyz", etc.
  for (let i = 0; i <= value.length - 4; i++) {
    const sequence = value.substring(i, i + 4);
    const repeated = sequence + sequence;
    if (value.includes(repeated.substring(1))) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First check if this looks like an IPv4 address - if so, return false
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}(?:\/.*)?$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern with shorthand support
  // Allows:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Single or double colon shorthand (::) representing multiple zero groups
  // - Mixed case hex digits (a-f, A-F)
  const fullIpv6Pattern = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  const shorthandPattern = /^([0-9a-fA-F]{1,4}:)*([0-9a-fA-F]{0,4})?::([0-9a-fA-F]{1,4}:)*([0-9a-fA-F]{0,4})?$/;
  const doubleColonOnly = /^::$/;
  
  // Test against different IPv6 patterns
  if (fullIpv6Pattern.test(value.trim()) || 
      shorthandPattern.test(value.trim()) || 
      doubleColonOnly.test(value.trim())) {
    return true;
  }
  
  // Also check for IPv6 addresses in larger text
  const ipv6InTextPattern = /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?![0-9a-fA-F:])/;
  const shorthandInTextPattern = /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:)*([0-9a-fA-F]{0,4})?::([0-9a-fA-F]{1,4}:)*([0-9a-fA-F]{0,4})?(?![0-9a-fA-F:])/;
  
  return ipv6InTextPattern.test(value) || shorthandInTextPattern.test(value);
}