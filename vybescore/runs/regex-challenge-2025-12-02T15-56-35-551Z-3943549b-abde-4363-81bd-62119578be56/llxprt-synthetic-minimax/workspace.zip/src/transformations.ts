/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Replace the first character of the string if it's a letter
  return text.replace(/^([a-z])/, (match, letter) => letter.toUpperCase())
    // Replace any letter that follows a sentence ending punctuation
    .replace(/([.!?]\s+)([a-z])/g, (match, punct, letter) => punct + letter.toUpperCase());
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];

  // URL pattern that matches http:// or https:// URLs
  const urlPattern = /https?:\/\/[^\s]+/gi;

  const matches = text.match(urlPattern) || [];

  // Clean up URLs - remove trailing punctuation that might have been captured
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?]+$/, '');
  }).filter(url => {
    // Only return valid URLs
    return /^https?:\/\//i.test(url);
  });
}

/**
 * Replace http:// with https:// but leave https:// untouched
 */
export function enforceHttps(text: string): string {
  if (!text) return text;

  // This pattern matches http:// and replaces it
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;

  // Pattern to match http:// URLs and capture host and path
  const httpUrlPattern = /http:\/\/([^\/\s]+)([^\s]*)/gi;

  return text.replace(httpUrlPattern, (match, host, path = '') => {
    let result = 'https://' + host + path;
    
    // If path starts with /docs/, rewrite host to docs.hostname
    if (path.startsWith('/docs/')) {
      // Check if path contains dynamic hints or legacy extensions
      const hasDynamicHints = /[?=&]|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      if (!hasDynamicHints) {
        result = 'https://docs.' + host + path;
      }
    }
    
    return result;
  });
}

/**
 * Extract year from mm/dd/yyyy format. Return 'N/A' if invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(绪{4})$/;
  const match = value.match(datePattern);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}