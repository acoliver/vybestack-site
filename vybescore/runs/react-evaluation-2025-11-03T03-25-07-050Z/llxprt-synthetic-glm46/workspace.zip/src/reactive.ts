/**
 * React-like reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { Observer, UpdateFn, updateObserver, getActiveObserver } from './types/reactive.js'

// Global tracking system for reactive dependencies
const allObservers = new Set<Observer<any>>()
const observerGraph = new Map<Observer<any>, Set<any>>()

/**
 * Tracks dependencies when observer is active
 */
function trackDependencies(observer: Observer<any>, dependencies: Set<any>): void {
  observerGraph.set(observer, dependencies)
}

/**
 * Notifies all observers that depend on a particular dependency
 */
function notifyDependents(dependency: any): void {
  for (const [observer, dependencies] of observerGraph.entries()) {
    if (dependencies.has(dependency)) {
      updateObserver(observer)
    }
  }
}

// Export everything from types
export * from './types/reactive.js'

// Export core functions
export { createInput } from './core/input.js'
export { createComputed } from './core/computed.js'
export { createCallback } from './core/callback.js'

// New utility exports
export { trackDependencies, notifyDependents, allObservers, observerGraph }