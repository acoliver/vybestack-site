/**
 * Input implementation v2 - with proper reactive updates
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  setActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive-v2.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  
  if (equal === true || equal === false) {
    equalFn = () => equal
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    // Default equality check using ===
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  }

  // All observers that depend on this input
  const observers = new Set<Observer<any>>()

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers,
  }

  const read: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Register the active observer as a dependent of this subject
      const observer = activeObs as Observer<any>
      
      // Add to this subject's observers
      if (!observers.has(observer)) {
        observers.add(observer)
      }
      
      // Add this subject to the observer's dependencies
      if (!observer.dependents) {
        observer.dependents = new Set()
      }
      if (!observer.dependents.has(subject)) {
        observer.dependents.add(subject)
      }
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed
    if (!equalFn(subject.value, nextValue)) {
      subject.value = nextValue
      
      // Create a copy to avoid issues with modifications during iteration
      const observersToUpdate = Array.from(observers)
      
      // Notify all dependent observers
      observersToUpdate.forEach(observer => {
        updateObserver(observer)
      })
    }
    return subject.value
  }

  return [read, write]
}