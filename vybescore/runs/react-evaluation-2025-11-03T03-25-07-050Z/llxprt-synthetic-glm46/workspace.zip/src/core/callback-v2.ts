/**
 * Callback implementation v2 - with proper reactive updates
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive-v2.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set(),
  }
  
  // Set up the callback as an active observer to track dependencies
  const previousActive = getActiveObserver()
  try {
    updateObserver(observer)
  } finally {
    // Restore previous active observer
    // Don't use setActiveObserver here as it's only needed for our v2 types
    ;(getActiveObserver as any)(previousActive)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = value
    observer.updateFn = () => value!
    
    // Clear dependencies to prevent further updates
    if (observer.dependents) {
      observer.dependents.clear()
    }
  }
}