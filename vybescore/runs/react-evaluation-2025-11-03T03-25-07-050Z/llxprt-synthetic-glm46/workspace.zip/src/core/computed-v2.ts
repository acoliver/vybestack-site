/**
 * Computed implementation v2 - with proper reactive dependencies
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive-v2.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // All observers that depend on this computed value
  const observers = new Set<Observer<any>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
  }
  
  const read: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    
    // If being read by an observer, track this computed as a dependency
    if (activeObs) {
      const observer = activeObs as Observer<any>
      
      // Add the observer to this computed's dependents
      if (!observers.has(observer)) {
        observers.add(observer)
      }
      
      // Add this computed to the observer's dependencies
      if (!observer.dependents) {
        observer.dependents = new Set()
      }
      if (!observer.dependents.has(o)) {
        observer.dependents.add(o)
      }
    }
    
    return o.value!
  }
  
  // Compute the value and track dependencies
  const compute = () => {
    // Clear previous dependencies by setting this as the active observer
    const previousActive = getActiveObserver()
    setActiveObserver(o)
    
    try {
      // This will automatically register dependencies
      o.value = o.updateFn(o.value)
    } finally {
      setActiveObserver(previousActive)
    }
    
    // Notify all dependents when this value changes
    const dependentsToUpdate = Array.from(observers)
    dependentsToUpdate.forEach(observer => {
      updateObserver(observer)
    })
  }
  
  // Initial computation
  compute()
  
  return read
}