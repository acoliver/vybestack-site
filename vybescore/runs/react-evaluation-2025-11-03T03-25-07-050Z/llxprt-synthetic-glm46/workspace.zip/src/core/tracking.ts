/**
 * Dependency tracking system for reactive programming
 * Inspired by React's dependency tracking
 * MIT License - Original by Exercism community, adapted for educational purposes
 */

import { updateObserver } from '../types/reactive.js'

// Global tracking system for reactive dependencies
const dependencyGraph = new Map<any, Set<any>>()

/**
 * Adds a dependency - observer depends on subject
 */
export function addDependency(observer: any, subject: any): void {
  if (!dependencyGraph.has(subject)) {
    dependencyGraph.set(subject, new Set())
  }
  dependencyGraph.get(subject)!.add(observer)
}

/**
 * Removes a dependency
 */
export function removeDependency(observer: any, subject: any): void {
  const observers = dependencyGraph.get(subject)
  if (observers) {
    observers.delete(observer)
    if (observers.size === 0) {
      dependencyGraph.delete(subject)
    }
  }
}

/**
 * Notifies all observers that depend on a particular subject
 */
export function notifyDependents(subject: any): void {
  const observers = dependencyGraph.get(subject)
  if (observers) {
    // Create a copy to avoid issues with modification during iteration
    const observersToNotify = Array.from(observers)
    for (const observer of observersToNotify) {
      updateObserver(observer)
    }
  }
}