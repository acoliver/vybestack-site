/**
 * Shared dependency tracking system for reactive programming
 */

// Track which observers depend on which subjects 
export const observerDependencies = new Map<Observer<any>, Set<any>>()

/**
 * Registers a dependency between an observer and a subject
 */
export function addDependency(observer: Observer<any>, subject: any): void {
  const deps = observerDependencies.get(observer) || new Set<any>()
  deps.add(subject)
  observerDependencies.set(observer, deps)
}

/**
 * Notifies all observers that depend on a particular subject
 */
export function notifyDependents(subject: any): void {
  // Use a direct approach - import and call updateObserver function
  import('../types/reactive.js').then(({ updateObserver }) => {
    for (const [observer, dependencies] of observerDependencies.entries()) {
      if (dependencies.has(subject)) {
        updateObserver(observer)
      }
    }
  }).catch(() => {
    // If import fails, try a simple require approach
    try {
      const { updateObserver } = require('../types/reactive.js')
      for (const [observer, dependencies] of observerDependencies.entries()) {
        if (dependencies.has(subject)) {
          updateObserver(observer)
        }
      }
    } catch {
      // If both approaches fail, fallback to a synchronous call
      // This might happen during module initialization
    }
  })
}

/**
 * Removes all dependencies for an observer
 */
export function clearDependencies(observer: Observer<any>): void {
  observerDependencies.delete(observer)
}

// Forward declare Observer type if not already imported
type Observer<T> = {
  value?: T
  updateFn: (value?: T) => T
}