import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import { app, initializeDatabase, closeDatabase } from '../../src/server.js';

let server: ReturnType<typeof app.listen> | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize database for tests without starting the main server
  await initializeDatabase();
  
  // Start server for testing
  server = app.listen(0); // Use random port for testing
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    // Check if response contains HTML with form fields
    expect(response.text).toContain('form');
    expect(response.text).toContain('first_name');
    expect(response.text).toContain('last_name');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    // Remove existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit form data using proper URL-encoded form data format
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'Test City',
        state_province: 'Test State',
        postal_code: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555-123-4567'
      })
      .expect(302);
    
    // Check redirect to thank you page
    expect(response.headers.location).toBe('/thank-you?first_name=John');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  }
  
  // Close the database connection
  closeDatabase();
});