import initSqlJs from './node_modules/sql.js/dist/sql-wasm.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function testSqlJs() {
  try {
    const SQL = await initSqlJs();
    
    // Create database
    const db = new SQL.Database();
    
    // Read schema
    const schemaPath = path.join(__dirname, 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Run schema
    db.run(schema);
    
    // Create and run a test statement
    const stmt = db.prepare('SELECT name FROM sqlite_master WHERE type=\'table\'');
    const result = stmt.getAsObject();
    console.log('Tables:', result);
    
    // Test insertion
    const insertStmt = db.prepare(`INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    
    insertStmt.run([
      'Test', 'User', '123 Test St', 'Test City',
      'Test State', '12345', 'Test Country', 'test@example.com', '+1 555-123-4567'
    ]);
    
    // Query the data
    const queryStmt = db.prepare('SELECT * FROM submissions');
    const rows = [];
    while(queryStmt.step()) {
      rows.push(queryStmt.getAsObject());
    }
    
    console.log('Insert test data:', rows);
    
    // Export and save
    const data = db.export();
    fs.writeFileSync('test.sqlite', Buffer.from(data));
    
    console.log('Test completed successfully');
  } catch (error) {
    console.error('Error:', error);
  }
}

testSqlJs();