import http from 'http';

// Test function to check form endpoints
async function testServer() {
  const serverHost = 'localhost';
  const serverPort = 3535;

  // Test GET request to the form
  const getForm = () => {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: serverHost,
        port: serverPort,
        path: '/',
        method: 'GET'
      };

      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => {
          data += chunk;
        });
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            body: data
          });
        });
      });

      req.on('error', (e) => {
        reject(e);
      });

      req.end();
    });
  };

  // Test POST request to submit form
  const submitForm = (formData) => {
    return new Promise((resolve, reject) => {
      const postData = new URLSearchParams(formData).toString();

      const options = {
        hostname: serverHost,
        port: serverPort,
        path: '/submit',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      };

      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => {
          data += chunk;
        });
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: data
          });
        });
      });

      req.on('error', (e) => {
        reject(e);
      });

      req.write(postData);
      req.end();
    });
  };

  // Test GET request to thank you page
  const getThankYou = (firstName) => {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: serverHost,
        port: serverPort,
        path: `/thank-you?firstName=${encodeURIComponent(firstName)}`,
        method: 'GET'
      };

      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => {
          data += chunk;
        });
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            body: data
          });
        });
      });

      req.on('error', (e) => {
        reject(e);
      });

      req.end();
    });
  };

  try {
    console.log('Testing server...');

    // Test GET form
    console.log('\nTesting GET /');
    const formResponse = await getForm();
    console.log(`Status: ${formResponse.statusCode}`);
    if (formResponse.statusCode !== 200) {
      console.error('Error: Form endpoint returned non-200 status');
      return;
    }

    // Test form submissions
    const testCases = [
      {
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1 555-123-4567'
      },
      {
        firstName: 'María',
        lastName: 'García',
        streetAddress: 'Calle de la Luna 45',
        city: 'Madrid',
        stateProvince: 'Madrid',
        postalCode: '28013',
        country: 'Spain',
        email: 'maria.garcia@example.es',
        phone: '+34 91 123 45 67'
      },
      {
        firstName: 'Li',
        lastName: 'Wei',
        streetAddress: '123 Wangfujing St',
        city: 'Beijing',
        stateProvince: 'Beijing',
        postalCode: '100001',
        country: 'China',
        email: 'li.wei@example.cn',
        phone: '+86 10 1234 5678'
      }
    ];

    for (let i = 0; i < testCases.length; i++) {
      const formData = testCases[i];
      console.log(`\nTesting submission ${i + 1}: ${formData.firstName} ${formData.lastName}`);
      const submitResponse = await submitForm(formData);
      console.log(`Status: ${submitResponse.statusCode}`);
      
      // Check for redirect
      if (submitResponse.statusCode === 302 || submitResponse.statusCode === 302) {
        if (submitResponse.headers && submitResponse.headers.location) {
          console.log(`Redirect to: ${submitResponse.headers.location}`);
          
          // Follow redirect to thank-you page
          const location = submitResponse.headers.location;
          if (location.includes('/thank-you')) {
            const thankYouResponse = await getThankYou(formData.firstName);
            console.log(`Thank you page status: ${thankYouResponse.statusCode}`);
          }
        }
      }
    }

    console.log('\nServer tests completed successfully!');
  } catch (error) {
    console.error('Error testing server:', error.message);
  }
}

// Wait for server to start then test
setTimeout(testServer, 2000);