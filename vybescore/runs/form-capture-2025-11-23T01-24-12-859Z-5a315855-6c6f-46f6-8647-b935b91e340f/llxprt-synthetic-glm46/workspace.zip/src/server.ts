import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const app = express();
const port = process.env.PORT || 3535;

// Get __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
// Using type interface for sql.js which doesn't have proper TypeScript definitions
interface SqlJsDb {
  run: (sql: string, params?: (string | number)[]) => void;
  prepare: (sql: string, params?: (string | number)[]) => SqlJsStmt;
  export: () => Uint8Array;
  close: () => void;
}

interface SqlJsStmt {
  run: (params?: (string | number)[]) => void;
  free: () => void;
}

let db: SqlJsDb | null = null;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Function to initialize the database
async function initializeDatabase(): Promise<void> {
  try {
    // Read schema file
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Check if database file exists
    let dbBuffer: Uint8Array | undefined;
    try {
      dbBuffer = fs.readFileSync(dbPath);
    } catch (err) {
      // Database doesn't exist yet, will create new one
      console.log('Database file not found. Creating new database.');
    }

    // Initialize SQL.js
    // @ts-expect-error - sql.js doesn't have proper TypeScript definitions
    const initSqlJs = (await import('sql.js')).default;
    const SQL = await initSqlJs();
    
    // Create or open database
    db = new SQL.Database(dbBuffer);
    
    // Apply schema to ensure tables exist
    if (db) {
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Function to close database gracefully
function closeDatabase(): void {
  if (db) {
    try {
      // Save database to disk before closing
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      
      // Close the database
      db.close();
      console.log('Database closed and saved successfully');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
}

// Interface for form data
interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Form validation function
function validateForm(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required field validation
  if (!formData.first_name?.trim()) {
    errors.push('First name is required');
  }
  
  if (!formData.last_name?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!formData.street_address?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!formData.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!formData.state_province?.trim()) {
    errors.push('State/Province/Region is required');
  }
  
  if (!formData.postal_code?.trim()) {
    errors.push('Postal/Zip code is required');
  }
  
  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }
  
  if (!formData.email?.trim()) {
    errors.push('Email is required');
  }
  
  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  }
  
  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (formData.email && !emailRegex.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
// Phone validation (international format) - simplified pattern
  const phoneRegex = /^[\+]?[0-9\s\-\(\)]+$/;
  if (formData.phone && !phoneRegex.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
}
  
  // Postal code validation (alphanumeric)
const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (formData.postal_code && !postalCodeRegex.test(formData.postal_code)) {
    errors.push('Please enter a valid postal/zip code');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}
// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData = req.body;
  
  // Debug logging
  console.log('Received form data:', JSON.stringify(formData, null, 2));
  
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', { 
      errors: validation.errors, 
      values: formData 
    });
  }
  
  try {
    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    if (!db) {
      throw new Error('Database not initialized');
    }
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    
    // Redirect to thank you page
    res.redirect(`/thank-you?first_name=${encodeURIComponent(formData.first_name)}`);
  } catch (error) {
    console.error('Database error:', error);
    const errors = ['An error occurred while saving your submission. Please try again.'];
    res.status(500).render('form', { 
      errors, 
      values: formData 
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.first_name || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function handleShutdown(): void {
  console.log('Shutting down server...');
  closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', handleShutdown);
process.on('SIGINT', handleShutdown);

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, startServer, initializeDatabase, closeDatabase };

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}