/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  disposed?: boolean // Track if observer has been disposed
  dependencies?: Set<Subject<unknown>> // Track which subjects this observer depends on
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<Observer<unknown>> // Track all observers that depend on this subject
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: any | undefined

export function getActiveObserver(): any {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip disposed observers
  if (observer.disposed) return
  
  const previous = activeObserver as Observer<T> | undefined
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addSubjectObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function removeSubjectObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers?.delete(observer)
}

export function notifySubjectObservers<T>(subject: Subject<T>): void {
  subject.observers?.forEach((observer) => {
    updateObserver(observer)
  })
}
