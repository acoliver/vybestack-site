/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, removeSubjectObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set()
  }
  
  // Execute the callback immediately to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark observer as disposed to prevent further updates
    observer.disposed = true
    
    // Remove this observer from all subject dependencies
    observer.dependencies?.forEach((subject) => {
      removeSubjectObserver(subject, observer)
    })
  }
}
