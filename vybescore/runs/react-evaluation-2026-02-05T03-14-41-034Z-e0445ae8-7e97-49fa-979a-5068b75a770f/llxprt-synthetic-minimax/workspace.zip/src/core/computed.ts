/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  notifySubjectObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined
  }
  
  const getter: GetterFn<T> = () => {
    const oldValue = o.value
    
    // Execute update function to establish dependencies and compute new value
    updateObserver(o)
    const newValue = o.value
    
    // If the value changed, update the subject and notify observers
    if (newValue !== undefined && newValue !== oldValue) {
      s.value = newValue
      notifySubjectObservers(s)
    }
    
    // For computed values, we assume the update function returns a valid value
    // The non-null assertion is safe here because computed functions should
    // always return a value when called properly
    return newValue as T
  }
  
  return getter
}
