const BASE64_ALPHABET = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_CHARS = /[^A-Za-z0-9+/=]/;

function validateBase64Input(input: string): void {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for invalid characters
  if (INVALID_CHARS.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check overall structure (valid Base64 pattern)
  if (!BASE64_ALPHABET.test(input)) {
    throw new Error('Invalid Base64 input: malformed format');
  }

  // Check padding length rules
  const paddingLength = (input.match(/=/g) || []).length;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }

  // Check for padding in wrong positions
  if (paddingLength > 0 && !input.endsWith('='.repeat(paddingLength))) {
    throw new Error('Invalid Base64 input: padding not at end');
  }
}

/**
 * Encode plain text to Base64 using the canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid input: input must be a non-empty string');
  }

  try {
    return Buffer.from(input, 'utf8').toString('base64');
  } catch (error) {
    throw new Error('Failed to encode input as Base64');
  }
}

/**
 * Decode Base64 text to plain text, accepting both padded and unpadded input.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  validateBase64Input(input);

  try {
    const buffer = Buffer.from(input, 'base64');
    const decoded = buffer.toString('utf8');
    
    // Validate that the decoded content is valid UTF-8
    if (buffer.length === 0 && input.length > 0) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input:')) {
      throw error;
    }
    throw new Error('Invalid Base64 input: corrupted data');
  }
}