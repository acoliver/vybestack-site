import { createInput, createComputed, createCallback } from './src/index.js';

// Test scenario similar to failing test
console.log('Testing unsubscribe functionality...');

const [input, setInput] = createInput(11);
const output = createComputed(() => input() + 1);

const values1 = [];
const unsubscribe1 = createCallback(() => values1.push(output()));

const values2 = [];
createCallback(() => values2.push(output()));

// First change - both callbacks should fire
console.log('First change to 31');
setInput(31);
console.log('values1:', values1);
console.log('values2:', values2);

// Unsubscribe first callback
console.log('Unsubscribing first callback...');
unsubscribe1();

// Second change - only second callback should fire
console.log('Second change to 41');
setInput(41);
console.log('values1:', values1);
console.log('values2:', values2);

console.log(`values1.length: ${values1.length}`);
console.log(`values2.length > values1.length: ${values2.length > values1.length}`);