/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  trackDependency,
  notifyDependents
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    equalFn = () => false
  } else if (equal === true || equal === undefined) {
    equalFn = (a, b) => a === b
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    // Track this subject as a dependency for the current observer
    trackDependency(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (!shouldUpdate) return s.value
    
    s.value = nextValue
    
    // Notify all observers that depend on this subject
    notifyDependents(s)
    
    return s.value
  }

  return [read, write]
}