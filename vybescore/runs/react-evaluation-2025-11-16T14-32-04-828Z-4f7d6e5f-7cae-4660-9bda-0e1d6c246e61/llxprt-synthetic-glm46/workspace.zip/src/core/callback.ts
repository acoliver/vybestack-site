/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, clearDependencies, setActiveObserver, disposeObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Wrap the update function to handle the effect and dependency tracking
  const wrappedUpdateFn: UpdateFn<T> = (currentValue) => {
    if (disposed) return currentValue!
    
    // Clear previous dependencies before each run
    clearDependencies(observer)
    
    // Set this observer as active to track its dependencies
    setActiveObserver(observer)
    
    try {
      // Run the actual effect function (which may access reactive values)
      return updateFn(currentValue)
    } finally {
      // Reset active observer
      setActiveObserver(undefined)
    }
  }
  
  observer.updateFn = wrappedUpdateFn
  
  // Register observer to track dependencies (initial run)
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark observer as disposed to prevent further notifications
    disposeObserver(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}