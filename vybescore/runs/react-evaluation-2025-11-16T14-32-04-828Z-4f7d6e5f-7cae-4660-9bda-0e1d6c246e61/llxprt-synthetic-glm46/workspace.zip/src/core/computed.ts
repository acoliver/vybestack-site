/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  trackDependency,
  notifyDependents,
  clearDependencies
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    equalFn = () => false
  } else if (equal === true || equal === undefined) {
    equalFn = (a, b) => a === b
  }
  
  let lastValue: T | undefined
  let isComputing = false
  let hasRun = false
  
  // Create a virtual subject for this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }
  
  const computedObserver: Observer<T> = {
    name: options?.name ? `${options.name}:observer` : undefined,
    value: lastValue,
    updateFn: (currentValue) => {
      if (isComputing) return currentValue as T
      
      isComputing = true
      
      // Clear previous dependencies to avoid stale ones
      clearDependencies(computedObserver)
      
      try {
        // For computed values, always use the provided currentValue
        const newValue = updateFn(currentValue)
        
        // Update both internal state and the subject
        lastValue = newValue
        computedSubject.value = newValue
        
        if (hasRun) {
          // Only notify dependents after the initial run
          notifyDependents(computedSubject)
        }
        hasRun = true
        
        return newValue
      } finally {
        isComputing = false
      }
    },
  }
  
  computedSubject.observer = computedObserver
  
  const computedGetter: GetterFn<T> = () => {
    trackDependency(computedSubject)
    
    // Update the computed value if dependencies have changed
    updateObserver(computedObserver)
    
    return computedSubject.value
  }
  
  // Initialize with the provided value if given
  if (value !== undefined) {
    lastValue = value
    computedSubject.value = value
    computedObserver.value = value
    hasRun = true
  }
  
  return computedGetter
}