/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global state for tracking reactive dependencies
let activeObserver: ObserverR | undefined
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const dependencyMap = new Map<Observer<any>, Set<Subject<any>>>()
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const disposedObservers = new Set<Observer<any>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if (disposedObservers.has(observer)) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function trackDependency(subject: Subject<any>): void {
  const observer = activeObserver
  if (!observer) return
  
  // Don't track dependencies for disposed observers
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if (disposedObservers.has(observer as Observer<any>)) return
  
  // Record that this observer depends on this subject
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  let subjects = dependencyMap.get(observer as Observer<any>)
  if (!subjects) {
    subjects = new Set()
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    dependencyMap.set(observer as Observer<any>, subjects)
  }
  subjects.add(subject)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function clearDependencies(observer: Observer<any>): void {
  dependencyMap.delete(observer)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function disposeObserver(observer: Observer<any>): void {
  disposedObservers.add(observer)
  dependencyMap.delete(observer)
}

export function notifyDependents<T>(subject: Subject<T>): void {
  // Find observers that depend on this subject
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const toNotify: Observer<any>[] = []
  for (const [observer, subjects] of dependencyMap.entries()) {
    if (subjects.has(subject) && !disposedObservers.has(observer)) {
      toNotify.push(observer)
    }
  }
  
  // Update all dependent observers
  for (const observer of toNotify) {
    updateObserver(observer)
  }
}
