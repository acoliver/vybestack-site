// Simple test file to debug reactive system
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing simple reactive case...')

const [getter, setter] = createInput(1)
const double = createComputed(() => getter() * 2)

console.log('Initial values:')
console.log('input:', getter())
console.log('double:', double())

console.log('\nUpdating input to 5...')
setter(5)

console.log('After update:')
console.log('input:', getter())
console.log('double:', double())

console.log('\nTesting cascading updates...')
const triple = createComputed(() => getter() * 3)
const sum = createComputed(() => double() + triple())

console.log('Before update:')
console.log('input:', getter())
console.log('double:', double())
console.log('triple:', triple())
console.log('sum:', sum())

setter(2)
console.log('\nAfter updating to 2:')
console.log('input:', getter())
console.log('double:', double())
console.log('triple:', triple())
console.log('sum:', sum())