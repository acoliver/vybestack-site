#!/usr/bin/env node

import fs from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';

/**
 * CLI arguments interface
 */
interface CLIArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments
 */
function parseArgs(argv: string[]): CLIArgs {
  if (argv.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const args: CLIArgs = {
    dataPath: argv[2],
    format: '',
    includeTotals: false,
  };

  // Parse arguments
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      args.format = argv[++i];
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      args.outputPath = argv[++i];
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument ${arg}`);
      process.exit(1);
    }
  }

  if (!args.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return args;
}

/**
 * Map format names to renderer functions
 */
const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  const entries = obj.entries.map((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

/**
 * Main function
 */
async function main(): Promise<void> {
  try {
    const args = parseArgs(process.argv);

    // Check if format is supported
    if (!formatters[args.format]) {
      console.error(`Error: Unsupported format "${args.format}"`);
      process.exit(1);
    }

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const jsonContent = fs.readFileSync(args.dataPath, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in ${args.dataPath}: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error reading file ${args.dataPath}: ${error.message}`);
      } else {
        console.error(`Error reading file ${args.dataPath}`);
      }
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Prepare render options
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    // Render the report
    const formatter = formatters[args.format];
    const output = formatter(reportData, options);

    // Write output
    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error writing to ${args.outputPath}: ${error.message}`);
        } else {
          console.error(`Error writing to ${args.outputPath}`);
        }
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

// Run the CLI
main().catch((error) => {
  console.error('Unhandled error:', error);
  process.exit(1);
});
