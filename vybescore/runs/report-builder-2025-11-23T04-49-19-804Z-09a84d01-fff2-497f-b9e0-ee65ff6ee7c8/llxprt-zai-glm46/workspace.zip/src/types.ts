/**
 * Report data structure matching the JSON schema
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Function signature for report formatters
 */
export type ReportFormatter = (data: ReportData, options: RenderOptions) => string;