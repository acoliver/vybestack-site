import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function isValidPaginationParam(value: string | undefined): boolean {
  if (value === undefined || value === '') {
    return true;
  }
  const num = Number(value);
  return !isNaN(num) && Number.isInteger(num) && num > 0;
}

function isExcessiveLimit(value: string | undefined): boolean {
  if (value === undefined || value === '') {
    return false;
  }
  const num = Number(value);
  return num > MAX_LIMIT;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs: reject non-numeric, negative, zero, or excessive values
    if (!isValidPaginationParam(pageParam) || !isValidPaginationParam(limitParam)) {
      return res.status(400).json({
        error: 'Invalid pagination parameters. Page and limit must be positive integers.'
      });
    }

    if (isExcessiveLimit(limitParam)) {
      return res.status(400).json({
        error: `Limit cannot exceed ${MAX_LIMIT}.`
      });
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
