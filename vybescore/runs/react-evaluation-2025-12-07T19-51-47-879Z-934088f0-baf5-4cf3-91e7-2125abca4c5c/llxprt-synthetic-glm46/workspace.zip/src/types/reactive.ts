/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observers?: Set<ObserverR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  // observer: ObserverR | undefined  // Removed to avoid conflicts with multiple callbacks
  // Track multiple observers for subjects that can be depended on by multiple computed values
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Allow setting the active observer for dependency tracking
export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Store old active observer to restore later
  const previous = activeObserver
  activeObserver = observer
  try {
    // Execute the update function which may access reactive subjects
    const oldValue = observer.value
    observer.value = observer.updateFn(observer.value)
    
    // For observers that are also subjects, notify their dependents if value changed
    if (observer.observers && oldValue !== observer.value) {
      notifyDependents(observer as Subject<T>)
    }
  } finally {
    // Restore the previous active observer
    activeObserver = previous
  }
  
  // If this is the result of a subject change, we need to notify dependents
  // The subject's observer property will have been set during the update process
}

export function notifyDependents<T>(subject: Subject<T>): void {
  // Only notify observers in the set since we removed the single observer pattern
  if (subject.observers) {
    // Create a copy to avoid issues with modification during iteration
    const observersCopy = new Set(subject.observers)
    for (const obs of observersCopy) {
      const disposedCheck = obs as { __disposed?: boolean }
      if (!disposedCheck.__disposed) {
        // Check if this is a callback observer by checking if observers set is empty
        const observer = obs as Observer<unknown>
        if (observer.observers && observer.observers.size === 0) {
          // This is a callback observer - execute the original update function only if not establishing dependencies
          const callbackObserver = observer as {
            _establishingDependencies?: boolean
            _callbackFn?: () => void
          }
          const isEstablishingDependencies = callbackObserver._establishingDependencies
          if (!isEstablishingDependencies) {
            const callbackFn = callbackObserver._callbackFn
            if (callbackFn) {
              try {
                callbackFn()
              } catch (e) {
                // Ignore errors in callbacks
              }
            }
          }
        } else {
          // This is a computed value observer
          updateObserver(observer)
        }
      }
    }
  }
}