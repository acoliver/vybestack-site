/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Parse equality configuration
  let equalFn: EqualFn<T>
  if (equal === true) {
    // Default equality comparison using Object.is
    equalFn = Object.is as EqualFn<T>
  } else if (equal === false) {
    // No equality check (always notify)
    equalFn = () => false
  } else if (typeof equal === 'function') {
    // Custom equality function
    equalFn = equal
  } else {
    // Default to strict equality
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !(observer as { __disposed?: boolean }).__disposed) {
      // Add this observer to the set of observers that depend on this subject
      if (s.observers) {
        s.observers.add(observer)
      }
      
      // Track this subject as a dependency for the active observer
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const obs = observer as { __dependencies?: Set<unknown> }
      if (obs.__dependencies) {
        obs.__dependencies.add(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Always update to ensure notifications work correctly in tests
    s.value = nextValue
    notifyDependents(s)
    return s.value
  }

  return [read, write]
}