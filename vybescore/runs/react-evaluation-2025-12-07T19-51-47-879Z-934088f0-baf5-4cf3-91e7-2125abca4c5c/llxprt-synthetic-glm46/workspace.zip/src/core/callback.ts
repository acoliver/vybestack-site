/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false

  // Create the observer for this callback
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue as T
      // Don't execute on notification
      return value as T
    },
    observers: new Set(), // Empty set to identify as callback observer
  }
  
  // Store the original callback function for notification purposes
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(observer as any)._callbackFn = updateFn
  
  // Store dependencies tracking on observer for cleanup
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const dependencies = new Set()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(observer as any).__dependencies = dependencies

  // Manually establish dependencies by accessing reactive values
  const previousActiveObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // This will track dependencies when reactive values are accessed
    // But we don't execute the callback here
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (observer as any)._establishingDependencies = true
    updateFn(value)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ;(observer as any)._establishingDependencies = false
  } finally {
    setActiveObserver(previousActiveObserver)
  }
  // Now execute the callback normally again for the initial execution
  // This will ensure proper initial execution without duplicate tracking
  try {
    updateFn(value)
  } catch (e) {
    // Ignore errors in initial callback execution
  }
  
  // Create unsubscribe function
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ;(observer as any).__disposed = true
    
    // Remove this observer from all subjects it's observing
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    dependencies.forEach((subject: any) => {
      if (subject.observers && subject.observers.has(observer)) {
        subject.observers.delete(observer)
      }
    })
    
    // Clear dependencies
    dependencies.clear()
  }
  
  return unsubscribe
}