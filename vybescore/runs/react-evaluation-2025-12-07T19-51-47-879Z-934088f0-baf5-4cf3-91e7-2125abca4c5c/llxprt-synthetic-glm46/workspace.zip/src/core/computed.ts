/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Initialize dependency tracking
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(o as any).__dependencies = new Set()

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && !(activeObserver as { __disposed?: boolean }).__disposed) {
      // Add this observer to the computed's dependency tracking
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(activeObserver)
      
      // Store this subject in the computed's observer so we can clean up later
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const obs = activeObserver as { __dependencies?: Set<unknown> }
      if (obs.__dependencies) {
        obs.__dependencies.add(o)
      }
    }
    
    // Always recompute when accessed - this is the key for reactive behavior
    updateObserver(o)
    return o.value!
  }
  
  // Don't do initial computation here - let it happen on first access
  return getter
}