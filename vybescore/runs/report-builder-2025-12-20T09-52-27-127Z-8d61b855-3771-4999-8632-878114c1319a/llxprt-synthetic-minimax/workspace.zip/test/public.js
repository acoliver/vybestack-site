const { spawn } = require('child_process');
const { readFileSync, writeFileSync, unlinkSync } = require('fs');
const { join } = require('path');

function runCommand(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn('node', ['dist/cli/report.js', ...args], {
      cwd: process.cwd(),
      env: process.env
    });

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    proc.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    proc.on('close', (code) => {
      resolve({ code, stdout, stderr });
    });

    proc.on('error', (error) => {
      reject(error);
    });
  });
}

function normalizeOutput(output) {
  return output.trim().replace(/\n\n\n+/g, '\n\n').trim();
}

function assertEqual(actual, expected, testName) {
  const actualNormalized = normalizeOutput(actual);
  const expectedNormalized = normalizeOutput(expected);
  
  if (actualNormalized !== expectedNormalized) {
    console.error(`[ERROR] Test failed: ${testName}`);
    console.error(`Expected:\n${expectedNormalized}`);
    console.error(`Actual:\n${actualNormalized}`);
    process.exit(1);
  } else {
    console.log(`[OK] Test passed: ${testName}`);
  }
}

async function runTests() {
  console.log(' Running public tests...\n');

  // Test markdown format without totals
  const { code: code1, stdout: output1 } = await runCommand([
    'fixtures/data.json',
    '--format', 'markdown'
  ]);
  
  if (code1 !== 0) {
    console.error('[ERROR] Test failed: Command failed');
    process.exit(1);
  }
  
  const expected1 = `# Quarterly Financial Summary

Highlights include record revenue and strong regional performance across all markets.

## Entries

- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;
  
  assertEqual(output1, expected1, 'Markdown format without totals');

  // Test markdown format with totals
  const { code: code2, stdout: output2 } = await runCommand([
    'fixtures/data.json',
    '--format', 'markdown',
    '--includeTotals'
  ]);
  
  if (code2 !== 0) {
    console.error('[ERROR] Test failed: Command with totals failed');
    process.exit(1);
  }
  
  const expected2 = `# Quarterly Financial Summary

Highlights include record revenue and strong regional performance across all markets.

## Entries

- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34`;
  
  assertEqual(output2, expected2, 'Markdown format with totals');

  // Test text format without totals
  const { code: code3, stdout: output3 } = await runCommand([
    'fixtures/data.json',
    '--format', 'text'
  ]);
  
  if (code3 !== 0) {
    console.error('[ERROR] Test failed: Text format command failed');
    process.exit(1);
  }
  
  const expected3 = `Quarterly Financial Summary
Highlights include record revenue and strong regional performance across all markets.
Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;
  
  assertEqual(output3, expected3, 'Text format without totals');

  // Test text format with totals
  const { code: code4, stdout: output4 } = await runCommand([
    'fixtures/data.json',
    '--format', 'text',
    '--includeTotals'
  ]);
  
  if (code4 !== 0) {
    console.error('[ERROR] Test failed: Text format with totals command failed');
    process.exit(1);
  }
  
  const expected4 = `Quarterly Financial Summary
Highlights include record revenue and strong regional performance across all markets.
Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89
Total: $70370.34`;
  
  assertEqual(output4, expected4, 'Text format with totals');

  // Test output to file
  const outputFile = 'test-output.txt';
  const { code: code5 } = await runCommand([
    'fixtures/data.json',
    '--format', 'markdown',
    '--output', outputFile
  ]);
  
  if (code5 !== 0) {
    console.error('[ERROR] Test failed: Output to file command failed');
    process.exit(1);
  }
  
  const fileContent = readFileSync(outputFile, 'utf-8');
  assertEqual(fileContent, expected1, 'Output to file');
  
  // Clean up
  unlinkSync(outputFile);

  console.log('\n All tests passed!');
}

runTests().catch((error) => {
  console.error('[ERROR] Test suite failed:', error);
  process.exit(1);
});