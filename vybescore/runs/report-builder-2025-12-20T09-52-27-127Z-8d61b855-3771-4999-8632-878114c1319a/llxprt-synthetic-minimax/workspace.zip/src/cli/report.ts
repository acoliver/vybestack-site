import * as fs from 'fs';
import * as path from 'path';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown, renderText } from '../formats/index.js';

function parseArguments(): CLIOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  
  if (!dataFile.endsWith('.json')) {
    console.error('Error: Data file must be a JSON file');
    process.exit(1);
  }

  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      
      if (nextArg === 'markdown' || nextArg === 'text') {
        format = nextArg;
      } else {
        console.error(`Unsupported format: ${nextArg}`);
        process.exit(1);
      }
      i++; // Skip the next argument since it's the format value
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = nextArg;
      i++; // Skip the next argument since it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      console.error(`Unknown option: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataFile,
    format,
    output,
    includeTotals
  };
}

function loadReportData(dataFile: string): ReportData {
  try {
    const filePath = path.resolve(dataFile);
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Basic validation
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      throw new Error('Invalid report data structure');
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry structure');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON file: ${error.message}`);
    } else if (error instanceof Error && error.message.includes('ENOENT')) {
      console.error(`Error: File not found: ${dataFile}`);
    } else {
      console.error(`Error loading data: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown.render(data, { includeTotals });
    case 'text':
      return renderText.render(data, { includeTotals });
    default:
      throw new Error('Unsupported format');
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error writing output file: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  const options = parseArguments();
  const data = loadReportData(options.dataFile);
  const output = renderReport(data, options.format, options.includeTotals);
  writeOutput(output, options.output);
}

if (require.main === module) {
  main();
}
