import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        // FIXED: Pass page and limit parameters to the API call
        const url = `/inventory?page=${encodeURIComponent(page)}&limit=${encodeURIComponent(limit)}`;
        const response = await fetch(url);
        
        if (!response.ok) {
          // Try to get error message from response body
          let errorMessage = `Request failed with status ${response.status}`;
          try {
            const errorData = await response.json();
            if (errorData.error) {
              errorMessage = errorData.error;
            }
          } catch {
            // Use default error message if JSON parsing fails
          }
          throw new Error(errorMessage);
        }
        
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    // FIXED: Always load when page or limit changes, not just when idle
    load();

    return () => {
      cancelled = true;
    };
    // FIXED: Add page and limit as dependencies
  }, [page, limit]);

  return state;
}
