import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100; // Prevent excessive limit values

export interface PaginationError {
  message: string;
  code: 'INVALID_PAGE' | 'INVALID_LIMIT';
}

function validatePaginationParams(page?: number, limit?: number): { page: number; limit: number } | PaginationError {
  // Validate page
  if (page !== undefined) {
    if (!Number.isInteger(page) || page <= 0) {
      return { message: 'Page must be a positive integer', code: 'INVALID_PAGE' };
    }
  }
  const validatedPage = page && page > 0 ? Math.floor(page) : 1;
  
  // Validate limit
  if (limit !== undefined) {
    if (!Number.isInteger(limit) || limit <= 0) {
      return { message: 'Limit must be a positive integer', code: 'INVALID_LIMIT' };
    }
    if (limit > MAX_LIMIT) {
      return { message: `Limit cannot exceed ${MAX_LIMIT}`, code: 'INVALID_LIMIT' };
    }
  }
  const validatedLimit = limit && limit > 0 ? Math.floor(limit) : DEFAULT_LIMIT;
  
  return { page: validatedPage, limit: validatedLimit };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage | PaginationError {
  // Validate pagination parameters first
  const validation = validatePaginationParams(options.page, options.limit);
  if ('code' in validation) {
    return validation;
  }
  
  const { page, limit } = validation;
  
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // FIXED: offset should be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = (page * limit) < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
