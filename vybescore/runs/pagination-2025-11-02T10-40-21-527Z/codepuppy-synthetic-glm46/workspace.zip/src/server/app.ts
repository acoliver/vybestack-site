import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate that parameters are numeric if provided
    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;
    
    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Page parameter must be a valid number' });
      }
      page = Number(pageParam);
    }
    
    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Limit parameter must be a valid number' });
      }
      limit = Number(limitParam);
    }

    const result = listInventory(db, { page, limit });
    
    if ('code' in result) {
      // Return validation errors with HTTP 400
      return res.status(400).json({ error: result.message });
    }
    
    res.json(result);
  });

  return app;
}
