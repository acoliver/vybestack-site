import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Awaited<ReturnType<typeof createDatabase>>;
  let app: Awaited<ReturnType<typeof createApp>>;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns default pagination (page 1, limit 5)', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBe(5); // default limit
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15); // from seed data
    expect(response.body.hasNext).toBe(true);
    
    // Verify first item is ID 1 (Notebook)
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[0].name).toBe('Notebook');
    
    // Verify last item is ID 5 (Monitor 24")
    expect(response.body.items[4].id).toBe(5);
    expect(response.body.items[4].name).toBe('Monitor 24"');
  });

  it('returns page 2 with proper offset', async () => {
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    
    // Verify first item is ID 6 (USB-C Hub)
    expect(response.body.items[0].id).toBe(6);
    expect(response.body.items[0].name).toBe('USB-C Hub');
    
    // Verify last item is ID 10 (Ergonomic Chair)
    expect(response.body.items[4].id).toBe(10);
    expect(response.body.items[4].name).toBe('Ergonomic Chair');
  });

  it('returns last page with no next page', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
    
    // Verify first item is ID 11 (4K Monitor)
    expect(response.body.items[0].id).toBe(11);
    expect(response.body.items[0].name).toBe('4K Monitor');
    
    // Verify last item is ID 15 (Portable Charger)
    expect(response.body.items[4].id).toBe(15);
    expect(response.body.items[4].name).toBe('Portable Charger');
  });

  it(' accepts custom limit parameter', async () => {
    const response = await request(app).get('/inventory?page=1&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(3);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    
    // Should only return first 3 items
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[1].id).toBe(2);
    expect(response.body.items[2].id).toBe(3);
  });

  it('rejects invalid page parameter (non-numeric)', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page parameter must be a valid number');
  });

  it('rejects invalid page parameter (negative)', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page must be a positive integer');
  });

  it('rejects invalid page parameter (zero)', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page must be a positive integer');
  });

  it('rejects invalid limit parameter (non-numeric)', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit parameter must be a valid number');
  });

  it('rejects invalid limit parameter (negative)', async () => {
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer');
  });

  it('rejects invalid limit parameter (zero)', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer');
  });

  it('rejects excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit cannot exceed 100');
  });

  it('allows maximum valid limit', async () => {
    const response = await request(app).get('/inventory?limit=100');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(15); // all items
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(100);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });

  it('handles page beyond existing data gracefully', async () => {
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0); // no items
    expect(response.body.page).toBe(100);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });
});
