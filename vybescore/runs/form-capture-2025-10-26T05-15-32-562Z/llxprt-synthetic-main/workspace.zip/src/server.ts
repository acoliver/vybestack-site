import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createServer } from 'http';
import initSqlJs, { Database } from 'sql.js';

// Type definitions for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

// Initialize Express app
const app = express();
const server = createServer(app);
const port = process.env.PORT || 3000;

// Initialize database
let db: Database | null = null;

// Initialize sql.js and load database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });
    
    const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    // Create data directory if it doesn't exist
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
      console.log('Database loaded from disk');
    } else {
      // Create new database
      db = new SQL.Database();
      console.log('New database created');
    }
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(
      path.resolve(process.cwd(), 'db', 'schema.sql'),
      'utf8'
    );
    db!.run(schema);
    console.log('Database initialized with schema');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateFormData(data: Partial<FormData>): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  // Required fields
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation: allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }
  
  // Postal code validation: accept alphanumeric strings
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    const errorMessages = Object.values(validation.errors);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    // Insert data into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while submitting your form. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
      
      if (db) {
        db.close();
        console.log('Database connection closed');
        process.exit(0);
      }
    });
  }
}

// Handle SIGTERM
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  server.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export { app, server };