// Type definitions for sql.js
declare module 'sql.js' {
  export class Database {
    constructor(data?: ArrayBuffer);
    run(sql: string, params?: unknown[]): unknown;
    exec(sql: string): unknown[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class Statement {
    run(params?: unknown[]): unknown;
    get(params?: unknown[]): unknown;
    all(params?: unknown[]): unknown[];
    free(): void;
  }
  
  export function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<typeof SqlJs>;
  
  export namespace SqlJs {
    export const Database: typeof Database;
    export const Statement: typeof Statement;
  }
  
  export default initSqlJs;
}