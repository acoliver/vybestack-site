import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, server } from '../../dist/server.js';
import initSqlJs from 'sql.js';
import * as cheerio from 'cheerio';

let db: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(async () => {
  if (server && server.close) {
    // For the test, we'll close the server
    await new Promise((resolve) => {
      server.close(resolve);
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
        const $ = cheerio.load(response.text);
    
    // Check that all required form fields exist
    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('#firstName')).toHaveLength(1);
    
    expect($('label[for="lastName"]').text()).toBe('Last name');
    expect($('#lastName')).toHaveLength(1);
    
    expect($('label[for="streetAddress"]').text()).toBe('Street address');
    expect($('#streetAddress')).toHaveLength(1);
    
    expect($('label[for="city"]').text()).toBe('City');
    expect($('#city')).toHaveLength(1);
    
    expect($('label[for="stateProvince"]').text()).toBe('State / Province / Region');
    expect($('#stateProvince')).toHaveLength(1);
    
    expect($('label[for="postalCode"]').text()).toBe('Postal / Zip code');
    expect($('#postalCode')).toHaveLength(1);
    
    expect($('label[for="country"]').text()).toBe('Country');
    expect($('#country')).toHaveLength(1);
    
    expect($('label[for="email"]').text()).toBe('Email');
    expect($('#email')).toHaveLength(1);
    
    expect($('label[for="phone"]').text()).toBe('Phone number');
    expect($('#phone')).toHaveLength(1);
    
    // Check form submission endpoint
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const testFormData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test Street',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'T3ST T3ST',
      country: 'Test Country',
      email: `${Date.now()}@example.com`, // Use unique email for each test run
      phone: '+1 234 567 8901'
    };
    
    // Submit form data
    const response = await request(app)
      .post('/submit')
      .send(testFormData)
      .expect(302);
    
    // Check for redirect to thank you page
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=Test/);
    
    // Wait a bit to ensure database is written to disk
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Verify database file exists
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify data was saved correctly by querying the database
    if (fs.existsSync(dbPath)) {
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });
      
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
      
      const result = db.exec(`SELECT * FROM submissions WHERE email = "${testFormData.email}"`);
      expect(result).toHaveLength(1);
      expect(result[0].values).toHaveLength(1);
      
      const row = result[0].values[0];
      expect(row[1]).toBe('Test'); // first_name
      expect(row[2]).toBe('User'); // last_name
      expect(row[3]).toBe('123 Test Street'); // street_address    
      expect(row[4]).toBe('Test City'); // city
      expect(row[5]).toBe('Test State'); // state_province
      expect(row[6]).toBe('T3ST T3ST'); // postal_code
      expect(row[7]).toBe('Test Country'); // country
      expect(row[8]).toBe(testFormData.email); // email
      expect(row[9]).toBe('+1 234 567 8901'); // phone
      
      db.close();
    }
  });
});
