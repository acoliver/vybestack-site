/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

// Use a more specific type for our registry keys
type RegistryKey = object

// Global registry to track which subjects depend on which observers
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const subjectObserverRegistry = new WeakMap<RegistryKey, Set<Observer<any>>>()

// Track observers that are currently being updated to prevent infinite recursion
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const updatingObservers = new Set<Observer<any>>()

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function registerObserverForSubject(subject: RegistryKey, observer: Observer<any>): void {
  if (!subjectObserverRegistry.has(subject)) {
    subjectObserverRegistry.set(subject, new Set())
  }
  const observers = subjectObserverRegistry.get(subject)!
  observers.add(observer)
}

export function notifySubjectObservers(subject: RegistryKey): void {
  const observers = subjectObserverRegistry.get(subject)
  if (observers) {
    // Create a copy to avoid issues with notifications modifying the set
    const observersToUpdate = Array.from(observers)
    
    observersToUpdate.forEach(observer => {
      // Prevent infinite recursion
      if (!updatingObservers.has(observer)) {
        updatingObservers.add(observer)
        try {
          updateObserver(observer)
        } finally {
          updatingObservers.delete(observer)
        }
      }
    })
  }
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let activeObserver: Observer<any> | undefined

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}