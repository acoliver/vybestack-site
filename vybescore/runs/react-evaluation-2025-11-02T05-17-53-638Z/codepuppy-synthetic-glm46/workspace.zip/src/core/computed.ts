/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  registerObserverForSubject,
  notifySubjectObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equal function parameter (not used in current implementation)
  const _equalFn: EqualFn<T> | undefined = (() => {
    if (equal === false) {
      return undefined
    } else if (equal === true || equal === undefined) {
      return (a: T, b: T) => a === b
    } else {
      return equal
    }
  })()

  // Create a unique identifier for this computed value to track observers
  const computedId = Object.freeze({ name: options?.name, id: Math.random() })
  
  // Create the observer that will compute the value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  let isDirty = true
  let currentValue: T | undefined = value

  const getter: GetterFn<T> = (): T => {
    // If we're being called as part of another observer's update,
    // register this computed as a dependency for the current observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      registerObserverForSubject(computedId, activeObserver)
    }
    
    // Update our value if dirty
    if (isDirty) {
      updateObserver(observer)
      currentValue = observer.value
      isDirty = false
    }

    return currentValue as T
  }

  // Initialize the computed value
  updateObserver(observer)
  currentValue = observer.value
  isDirty = false

  // Make this computed value observable by updating its own observer
  // when its dependencies change. We need to mark it as dirty when
  // its dependencies notify it of changes.
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    // When this computed is updated (due to dependency changes)
    // mark it as dirty so the next access will recalculate
    isDirty = true
    
    // Run the original computation
    const result = originalUpdateFn(prevValue)
    
    // Notify any observers that depend on this computed value
    notifySubjectObservers(computedId)
    
    return result
  }

  return getter
}