import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1];
  
  if (!format) {
    console.error('Error: --format requires a value');
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, output, includeTotals };
}

function loadAndValidateJson(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Entry ${i + 1}: missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${filePath}: ${error.message}`);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${filePath}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

function getFormatter(format: string): (data: ReportData, options: CliOptions) => string {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
      process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const { dataFile, format, output, includeTotals } = parseArgs(args);
  
  const data = loadAndValidateJson(dataFile);
  
  const options: CliOptions = {
    format: format.toLowerCase() as 'markdown' | 'text',
    output,
    includeTotals
  };
  
  const formatter = getFormatter(format);
  const report = formatter(data, options);
  
  if (output) {
    try {
      writeFileSync(output, report, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(report);
  }
}

main();