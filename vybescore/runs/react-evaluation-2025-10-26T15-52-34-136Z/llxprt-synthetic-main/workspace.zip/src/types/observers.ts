/**
 * Observer management for reactive programming system
 */

export interface ObserverNode<T = unknown> {
  value?: T
  updateFn: (value?: T) => T
  name?: string
  dependencies?: Set<ObserverNode<any>>
  dependents?: Set<ObserverNode<any>>
}

const activeObservers = new Array<ObserverNode<any>>()

export function getActiveObserver(): ObserverNode<any> | undefined {
  return activeObservers[activeObservers.length - 1]
}

export function withActiveObserver<T, R>(observer: ObserverNode<T>, fn: () => R): R {
  activeObservers.push(observer)
  try {
    return fn()
  } finally {
    activeObservers.pop()
  }
}

export function addDependency<T>(observer: ObserverNode<T>, dependency: ObserverNode<any>): void {
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(dependency)

  // Add this observer as a dependent of the dependency
  if (!dependency.dependents) {
    dependency.dependents = new Set()
  }
  dependency.dependents.add(observer)
}

export function notifyDependents<T>(observer: ObserverNode<T>): void {
  if (!observer.dependents) return

  for (const dependent of observer.dependents) {
    // Update the dependent observer
    dependent.value = dependent.updateFn(dependent.value)
    // Recursively notify its dependents
    notifyDependents(dependent)
  }
}