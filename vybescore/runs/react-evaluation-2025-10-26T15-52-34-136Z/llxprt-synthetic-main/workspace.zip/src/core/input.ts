/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

import {
  ObserverNode,
  getActiveObserver,
  addDependency,
  notifyDependents
} from '../types/observers.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create a subject to track this input's state
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  // Handle the equal parameter
  if (equal === true) {
    s.equalFn = Object.is as EqualFn<T>
  } else if (typeof equal === 'function') {
    s.equalFn = equal
  }

  // Create observer node for this input
  const inputObserver: ObserverNode<T> = {
    value,
    updateFn: () => s.value,
    name: options?.name
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // This input is a dependency of the current observer
      addDependency(activeObserver, inputObserver)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has changed
    const hasChanged = !s.equalFn ? true : !s.equalFn(s.value, nextValue)
    
    if (hasChanged) {
      s.value = nextValue
      inputObserver.value = nextValue

      // Notify all observers that depend on this input
      notifyDependents(inputObserver)
    }
    
    return s.value
  }

  return [read, write]
}