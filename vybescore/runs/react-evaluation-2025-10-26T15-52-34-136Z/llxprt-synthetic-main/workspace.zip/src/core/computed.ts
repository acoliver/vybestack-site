/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn
} from '../types/reactive.js'

import {
  ObserverNode,
  getActiveObserver,
  withActiveObserver,
  addDependency
} from '../types/observers.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create observer node for this computed value
  const computedObserver: ObserverNode<T> = {
    value,
    updateFn,
    name: options?.name
  }

  // Initialize the computed value
  // This will register any dependencies
  const initialValue = withActiveObserver(computedObserver, () => updateFn(value))
  computedObserver.value = initialValue

  return (): T => {
    const activeObserver = getActiveObserver()
    
    // If another observer is accessing this computed value,
    // establish a dependency relationship
    if (activeObserver) {
      addDependency(activeObserver, computedObserver)
    }
    
    // Always return the current value
    return computedObserver.value!
  }
}