/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, UpdateFn } from '../types/reactive.js'

import {
  ObserverNode,
  withActiveObserver
} from '../types/observers.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: ObserverNode<T> = {
    value,
    updateFn,
  }

  // Register observer to track dependencies
  withActiveObserver(observer, () => {
    // Initially execute to track dependencies
    observer.value = updateFn(value)
  })
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    
    // Replace with a no-op function to prevent side effects
    observer.updateFn = () => {
      // This empty function won't be called since we're disposed
      return value!
    }
  }
}