import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination', () => {
  it('accepts page and limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test pagination with page=1 and limit=5
    const response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeLessThanOrEqual(5);
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('validates page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test non-numeric page
    const response1 = await request(app).get('/inventory?page=abc&limit=5');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toContain('Page must be a positive number');
    
    // Test negative page
    const response2 = await request(app).get('/inventory?page=-1&limit=5');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toContain('Page must be a positive number');
    
    // Test zero page
    const response3 = await request(app).get('/inventory?page=0&limit=5');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toContain('Page must be a positive number');
  });

  it('validates limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test non-numeric limit
    const response1 = await request(app).get('/inventory?page=1&limit=abc');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toContain('Limit must be a positive number');
    
    // Test negative limit
    const response2 = await request(app).get('/inventory?page=1&limit=-1');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toContain('Limit must be a positive number');
    
    // Test zero limit
    const response3 = await request(app).get('/inventory?page=1&limit=0');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toContain('Limit must be a positive number');
    
    // Test excessive limit
    const response4 = await request(app).get('/inventory?page=1&limit=101');
    expect(response4.status).toBe(400);
    expect(response4.body.error).toContain('not exceeding 100');
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page with a small limit to test pagination
    const limit = 3;
    const response = await request(app).get(`/inventory?page=1&limit=${limit}`);
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(limit);
    
    // Check for hasNext flag
    if (response.body.total > limit) {
      expect(response.body.hasNext).toBe(true);
      
      // Test second page
      const secondPage = await request(app).get(`/inventory?page=2&limit=${limit}`);
      expect(secondPage.status).toBe(200);
      expect(secondPage.body.items.length).toBeLessThanOrEqual(limit);
    }
  });

  it('returns different items for different pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const limit = 2;
    const firstPage = await request(app).get(`/inventory?page=1&limit=${limit}`);
    const secondPage = await request(app).get(`/inventory?page=2&limit=${limit}`);
    
    expect(firstPage.status).toBe(200);
    expect(secondPage.status).toBe(200);
    
    // If there are items on both pages, they should be different
    if (firstPage.body.items && secondPage.body.items &&
        firstPage.body.items.length > 0 && secondPage.body.items.length > 0) {
      const firstItem = firstPage.body.items[0];
      const secondItem = secondPage.body.items[0];
      
      // The items should have different IDs (assuming database has more than limit items)
      expect(firstItem.id).not.toBe(secondItem.id);
    }
  });

  it('handles pages beyond the data range', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get a very high page number
    const response = await request(app).get('/inventory?page=999&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toBeDefined();
    expect(response.body.items.length).toBe(0);
    expect(response.body.page).toBe(999);
    expect(response.body.hasNext).toBe(false);
  });
});