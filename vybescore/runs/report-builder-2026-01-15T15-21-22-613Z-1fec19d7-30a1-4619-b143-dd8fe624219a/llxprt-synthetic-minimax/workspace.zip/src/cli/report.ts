#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';

function parseArguments(argv: string[]): CliOptions {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  let format: CliOptions['format'] | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = nextArg as CliOptions['format'];
      i++; // Skip next arg as it's the value
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = nextArg;
      i++; // Skip next arg as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}. Supported formats: markdown, text`);
    process.exit(1);
  }
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

function readAndValidateJson(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    // Validate entries
    data.entries.forEach((entry, index) => {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${index + 1} missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry ${index + 1} missing or invalid "amount" field`);
      }
    });
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to read or parse data file');
    }
    process.exit(1);
  }
}

function renderAndOutput(data: ReportData, options: CliOptions): void {
  let output: string;
  
  if (options.format === 'markdown') {
    output = formatMarkdown(data, options.includeTotals);
  } else {
    output = formatText(data, options.includeTotals);
  }
  
  if (options.outputPath) {
    try {
      writeFileSync(options.outputPath, output, 'utf-8');
    } catch (error) {
      console.error('Error: Failed to write output file');
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

// Main execution
function main(): void {
  const options = parseArguments(process.argv);
  const data = readAndValidateJson(options.dataPath);
  renderAndOutput(data, options);
}

main();
