import { ReportData } from '../types.js';

export function formatMarkdown(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title with markdown heading
  lines.push(`# ${data.title}`);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries section
  lines.push('## Entries');
  
  // Format each entry as bullet list with label bolded and amount
  data.entries.forEach(entry => {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  });
  
  // Include totals if requested
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}