#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { Report, RenderOptions } from '../types.js';
import { formatters, supportedFormats } from '../formatters.js';

function parseArguments(): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Find format flag
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format flag is required and must specify a format');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  
  // Find output flag
  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex !== args.length - 1 ? args[outputIndex + 1] : undefined;
  
  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReport(data: unknown): Report {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be array)');
  }
  
  const entries = obj.entries.map((entry: unknown, index: number) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry ${index} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${index} missing or invalid "label" field (must be string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${index} missing or invalid "amount" field (must be number)`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();
    
    // Validate format
    if (!supportedFormats.includes(format)) {
      console.error(`Error: Unsupported format "${format}". Supported formats: ${supportedFormats.join(', ')}`);
      process.exit(1);
    }
    
    // Read and parse JSON
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`Error reading or parsing "${dataPath}": ${message}`);
      process.exit(1);
    }
    
    // Validate report structure
    const report = validateReport(jsonData);
    
    // Render report
    const options: RenderOptions = { includeTotals };
    const formatter = formatters[format];
    const output = formatter(report, options);
    
    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf8');
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`Error writing to "${outputPath}": ${message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();