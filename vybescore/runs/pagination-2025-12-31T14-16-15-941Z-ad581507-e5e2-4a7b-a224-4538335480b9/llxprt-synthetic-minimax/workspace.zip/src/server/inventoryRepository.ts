import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationParams(page?: number, limit?: number): { 
  valid: boolean; 
  error?: string;
  page: number;
  limit: number;
} {
  // Default values
  let validatedPage = 1;
  let validatedLimit = DEFAULT_LIMIT;

  // Validate page parameter
  if (page !== undefined) {
    if (!Number.isInteger(page) || page < 1) {
      return { valid: false, error: 'Invalid page parameter. Must be a positive integer (1-1000).', page: 1, limit: DEFAULT_LIMIT };
    }
    validatedPage = page;
  }

  // Validate limit parameter
  if (limit !== undefined) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) {
      return { valid: false, error: 'Invalid limit parameter. Must be a positive integer (1-100).', page: 1, limit: DEFAULT_LIMIT };
    }
    validatedLimit = limit;
  }

  return { valid: true, page: validatedPage, limit: validatedLimit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): { data: InventoryPage } | { error: string } {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const validation = validatePaginationParams(options.page, options.limit);
  if (!validation.valid) {
    return { error: validation.error! };
  }

  const { page, limit } = validation;
  
  // Fixed: offset should be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    data: {
      items: rows,
      page,
      limit,
      total,
      hasNext
    }
  };
}
