#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const result: Partial<CliArgs> = {};
  
  // Default values
  result.includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];
    
    if (arg === '--format') {
      if (!nextArg) {
        throw new Error('Missing format argument after --format');
      }
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        throw new Error('Unsupported format');
      }
      result.format = nextArg;
      i++;
    } else if (arg === '--output') {
      if (!nextArg) {
        throw new Error('Missing output path after --output');
      }
      result.outputPath = nextArg;
      i++;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!result.dataFile) {
      result.dataFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }
  
  if (!result.dataFile) {
    throw new Error('Missing data file argument');
  }
  
  if (!result.format) {
    throw new Error('Missing required --format option');
  }
  
  return result as CliArgs;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Missing or invalid title field (expected string)');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Missing or invalid summary field (expected string)');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Missing or invalid entries field (expected array)');
    }
    
    const entries = obj.entries.map((entry, index) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid entry at index ${index}: expected object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid label (expected string)`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid amount (expected number)`);
      }
      
      return {
        label: entryObj.label,
        amount: entryObj.amount
      };
    });
    
    return {
      title: obj.title,
      summary: obj.summary,
      entries
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, options: ReportOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

async function main(): Promise<void> {
  try {
    const args = parseArguments(process.argv.slice(2));
    const data = loadReportData(args.dataFile);
    
    const options: ReportOptions = {
      format: args.format,
      includeTotals: args.includeTotals
    };
    
    const output = renderReport(data, options);
    
    if (args.outputPath) {
      await writeFile(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
