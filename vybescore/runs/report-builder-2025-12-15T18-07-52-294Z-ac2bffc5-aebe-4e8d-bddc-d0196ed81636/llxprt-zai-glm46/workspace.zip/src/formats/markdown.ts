import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

export const renderMarkdown: ReportRenderer = (data: ReportData, options: ReportOptions): string => {
  const lines: string[] = [];
  
  // Add title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries section
  lines.push('## Entries');
  
  // Add each entry as a bullet point
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  }
  
  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalAmount = total.toFixed(2);
    lines.push(`\n**Total:** $${totalAmount}`);
  }
  
  return lines.join('\n');
};