import { ReportData } from '../types/report.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Each entry as bullet with colon separator
  for (const entry of data.entries) {
    const amount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- ${entry.label}: ${amount}`);
  }
  
  // Optional totals line
  if (includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}