#!/usr/bin/env node

// TODO: implement the report CLI as described in problem.md
import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CliOptions {
  if (args.length < 1) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  let format: 'markdown' | 'text' = 'markdown';
  let output: string | undefined;
  let includeTotals = false;

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        format = args[i + 1] as 'markdown' | 'text';
        if (format !== 'markdown' && format !== 'text') {
          throw new Error('Unsupported format');
        }
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        output = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (i === 1) {
          // First argument after dataPath is the data.json, already captured
          continue;
        }
        throw new Error(`Unexpected argument: ${args[i]}`);
    }
  }

  return { dataPath, format, output, includeTotals };
}

function readAndValidateJson(dataPath: string): ReportData {
  try {
    const fileContent = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(fileContent);

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing required field: title');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Missing required field: summary');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing required field: entries');
    }

    // Validate entries structure
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string') {
        throw new Error(`Missing required field in entry ${i}: label`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Missing required field in entry ${i}: amount`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${dataPath}`);
    }
    throw new Error(`Invalid JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

function writeOutput(content: string, output?: string): void {
  if (output) {
    writeFileSync(output, content, 'utf-8');
  } else {
    console.log(content);
  }
}

function main(args: string[]): void {
  try {
    const options = parseArgs(args);
    
    const reportData = readAndValidateJson(options.dataPath);
    
    let rendered: string;
    if (options.format === 'markdown') {
      rendered = renderMarkdown(reportData, options.includeTotals);
    } else {
      rendered = renderText(reportData, options.includeTotals);
    }
    
    writeOutput(rendered, options.output);
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

const args = process.argv.slice(2);
main(args);
