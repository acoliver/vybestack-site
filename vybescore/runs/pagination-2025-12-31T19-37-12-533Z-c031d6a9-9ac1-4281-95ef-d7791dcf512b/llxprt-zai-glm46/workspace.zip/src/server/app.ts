import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    if (pageParam !== undefined && (isNaN(Number(pageParam)) || Number(pageParam) < 1 || !Number.isInteger(Number(pageParam)))) {
      res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      return;
    }

    if (limitParam !== undefined && (isNaN(Number(limitParam)) || Number(limitParam) < 1 || !Number.isInteger(Number(limitParam)))) {
      res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer.' });
      return;
    }

    const MAX_LIMIT = 100;
    if (limit !== undefined && limit > MAX_LIMIT) {
      res.status(400).json({ error: `Limit cannot exceed ${MAX_LIMIT}.` });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
